# AI Production Director — Knowledge Pack 3/7

Generated from `aiproductiondirectorcompleto.zip`.
Each source file is preserved with its original relative path.


<!-- SOURCE_FILE_START: repo/package-lock.json -->
# SOURCE FILE: `repo/package-lock.json`

{
  "name": "ejecutor-produccion",
  "lockfileVersion": 3,
  "requires": true,
  "packages": {
    "": {
      "name": "ejecutor-produccion",
      "dependencies": {
        "openai": "^7.10.0"
      },
      "engines": {
        "node": ">=20"
      }
    },
    "node_modules/openai": {
      "version": "7.10.0",
      "resolved": "https://registry.npmjs.org/openai/-/openai-7.10.0.tgz",
      "integrity": "sha512-sn9t2Kls7O52PwuF9BUTYNu4Gk/r0lXJyrgaNht4TNRlZFb3dJIGO0RciSgjARGCBRtWjySubAQFJttlzUvGQQ==",
      "license": "Apache-2.0",
      "engines": {
        "node": ">=22.0.0"
      },
      "peerDependencies": {
        "@aws-sdk/credential-provider-node": ">=3.972.0 <4",
        "@smithy/hash-node": ">=4.3.0 <5",
        "@smithy/signature-v4": ">=5.4.0 <6",
        "undici": ">=5 <9",
        "ws": "^8.21.0",
        "zod": "^3.25 || ^4.0"
      },
      "peerDependenciesMeta": {
        "@aws-sdk/credential-provider-node": {
          "optional": true
        },
        "@smithy/hash-node": {
          "optional": true
        },
        "@smithy/signature-v4": {
          "optional": true
        },
        "undici": {
          "optional": true
        },
        "ws": {
          "optional": true
        },
        "zod": {
          "optional": true
        }
      }
    }
  }
}

<!-- SOURCE_FILE_END: repo/package-lock.json -->


<!-- SOURCE_FILE_START: repo/package.json -->
# SOURCE FILE: `repo/package.json`

{
  "name": "ejecutor-produccion",
  "private": true,
  "type": "module",
  "engines": { "node": ">=20" },
  "dependencies": {
    "openai": "^7.10.0"
  }
}

<!-- SOURCE_FILE_END: repo/package.json -->
