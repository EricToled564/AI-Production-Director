# Etapa 1 — Creative Strategy

Este módulo es la autoridad de la Etapa 1 del pipeline. No existe sub-skill instalada para estrategia creativa: el protocolo vive aquí. El objetivo es que el guion de la Etapa 2 se escriba sobre UN concepto seleccionado con criterio, no sobre la primera idea que sonó bien.

Profundidad por track: FILM ejecuta todo. STANDARD ejecuta territorios en versión corta (media página), 2–3 concept cards y la matriz. EXPRESS no ejecuta esta etapa.

## 1. Lectura del brief

Antes de idear, extrae del brief y deja por escrito:

- **Problema de negocio** (qué debe cambiar en el mundo real si el video funciona)
- **Audiencia** (quién, en qué momento, con qué fricción — no demografía vacía)
- **Single-minded proposition**: la única cosa que el video debe dejar instalada. Una frase. Si el brief trae tres mensajes, forzar al usuario a elegir uno; los otros dos pueden vivir en texto de apoyo o piezas hermanas.
- **Tono de marca** (del brand-lock si existe)
- **Restricciones duras** (legales, de plataforma, de presupuesto de generación)

Si el single-minded proposition no se puede escribir en una frase, la Etapa 1 no puede continuar. Resuélvelo con el usuario primero.

## 2. Territorios creativos

Un territorio es un espacio conceptual desde el cual se puede contar la proposición — no una idea todavía. Explora 3–4 territorios genuinamente distintos entre sí. Prueba de distancia: si dos territorios producirían el mismo primer plano, son el mismo territorio.

Formato por territorio (4–6 líneas):

```
### Territorio: [nombre evocador]
- Ángulo: desde dónde se mira la proposición (el ritual, el antagonista, el después, el detalle invisible…)
- Tensión que explota: qué fricción humana real usa como motor
- Textura: cómo se ve y suena este territorio (2 líneas sensoriales, sin vocabulario prohibido)
- Riesgo: por qué podría fallar o ya estar quemado en la categoría
```

Registros útiles para forzar distancia entre territorios: emocional vs. funcional · íntimo vs. épico de escala · humor vs. gravedad · protagonista humano vs. producto/entorno como personaje · tiempo real vs. elipsis.

## 3. Big ideas y concept cards

De los territorios más fuertes, baja 3–5 conceptos (FILM) o 2–3 (STANDARD). Cada concepto es UNA película posible, no una variación de la anterior. Formato obligatorio:

```
## Concept Card [N] — [Nombre]
**Territorio de origen:** [cuál]
**Logline:** [la película en 1–2 frases: quién quiere qué, qué lo impide, qué vemos]
**Insight:** [la verdad humana sobre la que se para — algo que la audiencia reconoce como cierto]
**Arco en 3 beats:** [apertura → quiebre → resolución, una línea cada uno]
**Imagen final:** [el último frame, concreto — es lo que el espectador se lleva]
**Por qué vende la proposición:** [mecánica explícita: cómo este concepto instala la single-minded proposition]
**Riesgo principal:** [producción, tono, o percepción — y su mitigación en una línea]
**Complejidad de generación AI:** [Baja/Media/Alta — nº de personajes con continuidad, entornos, física difícil, diálogo lip-sync]
```

El campo de complejidad AI no es decorativo: un concepto brillante con 4 personajes en continuidad a través de 12 shots es un riesgo de producción real en video generativo, y el usuario debe elegirlo sabiéndolo.

## 4. Matriz de selección

Presenta los conceptos en una matriz 1–5, sin promediar a ciegas — el usuario pondera:

| Concepto | Fuerza del insight | Distintividad vs. categoría | Fit de marca | Claridad de la proposición | Viabilidad AI | Riesgo |
|---|---|---|---|---|---|---|

Debajo de la matriz, tu recomendación argumentada en un párrafo: cuál elegirías y por qué, nombrando el trade-off que implica. Recomendar es parte del trabajo; decidir es del usuario.

**Gate de la etapa:** el usuario selecciona un concepto (puede pedir un híbrido — trátalo como concepto nuevo con su propia card antes de avanzar).

## 5. Dirección narrativa del concepto ganador

Puente hacia `screenwriter`. Media página que fija, para el concepto elegido:

- **Estructura**: nº de escenas/actos y función de cada una (usar la three-jobs rule como criterio: cada escena cambia emoción, avanza acción o sube presión)
- **Punto de vista**: desde quién se cuenta y por qué
- **Los 5 anclas preliminares** (se refinan en Etapa 3): una emoción dominante, un motivo recurrente, un objeto, un quiebre, una imagen final
- **Reglas del mundo**: qué existe y qué no en esta pieza (época, lugar, nivel de realismo, presencia del producto)
- **Duración objetivo y densidad**: cuántos segundos por beat, dónde vive la pausa

Este documento + la concept card son la entrada completa de la Etapa 2. Si `screenwriter` tuviera que preguntar algo estructural, esta etapa quedó corta — corrígela aquí.
