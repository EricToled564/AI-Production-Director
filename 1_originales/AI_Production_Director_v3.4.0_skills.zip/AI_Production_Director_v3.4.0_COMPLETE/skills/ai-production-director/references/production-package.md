# Etapa 7 — Final AI Video Production Package

Spec del entregable final del pipeline. El paquete debe permitir que un editor, una agencia o el propio usuario dentro de tres meses produzca el video sin hacer una sola pregunta de contexto.

## 1. Estructura del paquete

```
production-package/
├── 00-README.md                  # Índice, track usado, resumen de decisiones, créditos
├── 01-strategy/
│   ├── brief.md                  # Brief original o su reconstrucción
│   ├── territories.md            # Territorios explorados (STANDARD/FILM)
│   ├── concept-cards.md          # Todas las cards + matriz + concepto seleccionado marcado
│   └── narrative-direction.md
├── 02-script/
│   ├── treatment.md              # Solo FILM
│   └── script.md                 # Escenas XML-tagged de screenwriter
├── 03-direction/
│   └── cinematic-direction.md    # Blocking, cámara, luz, color, 5 anclas, por escena
├── 04-shots/
│   ├── storyboard.md
│   ├── shots.json                # FUENTE DE VERDAD
│   ├── text-overlays.json
│   ├── run.json
│   └── brand-lock.snapshot.md
├── 05-anchors/
│   ├── anchor-plan.md            # Qué refs se necesitan y para qué shots
│   ├── prompts/round-N/          # Prompts de imagen por modelo, por ronda
│   ├── frames/round-N/           # Renders aprobados/evaluados
│   └── critiques/round-N/        # critique.json por shot evaluado
├── 06-video-prompts/
│   ├── prompts/                  # Un archivo por shot: shot_NN.<modelo>.txt
│   └── continuity-notes.md       # Bloques de continuidad entre clips
├── 07-delivery/
│   ├── preview.html              # storyboard-html-preview, single-file
│   └── post-production.md        # Checklist de post (ver §3)
└── brand-lock.md                 # Si existió Etapa 0
```

En EXPRESS el paquete se comprime a: README, shot list, prompts y checklist de post — misma trazabilidad, menos carpetas.

## 2. Reglas de trazabilidad

1. Todo prompt (imagen o video) lleva en comentario su `shot_id`.
2. Todo shot en shots.json referencia su escena del script (`scene` field o nota).
3. El script referencia la concept card ganadora en su encabezado.
4. Cambios: si un prompt necesita cambiar algo que su shot fija (encuadre, acción, luz), el cambio se hace en shots.json y se regenera hacia abajo. El paquete nunca contiene un prompt que contradiga su shot.
5. Verificación de cierre: muestrea 3 prompts al azar y traza la cadena prompt → shot → escena → concepto. Si un eslabón falta, el paquete no se entrega.

## 3. Checklist de post-producción (07-delivery/post-production.md)

Adaptar al proyecto, con specs concretos — no placeholders:

```
- [ ] Generar los N shots en [modelo(s)] con los prompts de 06-video-prompts/
- [ ] Verificar cada clip contra su shot card (encuadre, acción, luz) antes de editar
- [ ] Ensamblar en [NLE] siguiendo el orden y duraciones de shots.json
- [ ] Aplicar grade de consistencia: [referencia de color del brand-lock o Visual Theme]
- [ ] Transiciones: [tipo y duración definidos en dirección, no "al gusto"]
- [ ] Audio: [música género/BPM/posición de beats + VO + ambientes según dirección de audio por shot]
- [ ] Overlays de texto según text-overlays.json (tipografía del brand-lock)
- [ ] Export: [resolución, aspect ratio, fps, códec, loudness según plataforma destino]
- [ ] QA final contra los 5 anclas: ¿la pieza terminada conserva emoción, motivo, objeto, quiebre e imagen final?
```

## 4. Checklist maestro del pipeline (gate de la Etapa 7)

- [ ] Concepto seleccionado por el usuario documentado en 01-strategy
- [ ] Cada escena del script pasa fórmula de escena + three-jobs rule
- [ ] Dirección cinematográfica sin vocabulario prohibido
- [ ] shots.json validado (`validate_shots.py` limpio) y auditoría de 3 detalles por shot
- [ ] Anchors críticos con critique ACCEPT (≤2 rondas)
- [ ] Prompts de video en sintaxis del modelo destino, con los dos checks de `video` pasados
- [ ] `aurora-prompt-linter` limpio sobre todos los prompts (si está instalada)
- [ ] Trazabilidad muestreada (§2.5)
- [ ] preview.html abre offline y refleja el estado final
- [ ] Créditos en 00-README.md: atribución *Serge Shima — github.com/smixs/visual-skills* si se usó la capa smixs; licencias de sub-skills anotadas
- [ ] 00-README.md explica en ≤1 página qué es el proyecto, qué track se usó y dónde está cada cosa
