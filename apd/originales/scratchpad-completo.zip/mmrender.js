const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
  for (const f of ['flujo-spot.html','flujo-anclas.html']) {
    const page = await browser.newPage({ viewport:{width:1200,height:900} });
    const src = fs.readFileSync(f,'utf8');
    const html = '<!doctype html><html><head><meta charset="utf-8"></head><body>' + src.replace(/<link rel="stylesheet"[^>]*>/,'') + '</body></html>';
    await page.setContent(html, { waitUntil: 'load' });
    await page.addScriptTag({ path: 'mermaid.min.js' });
    const svgs = await page.evaluate(async () => {
      mermaid.initialize({ startOnLoad:false, theme:'neutral', flowchart:{ htmlLabels:true, useMaxWidth:false, curve:'basis' }, fontFamily:'IBM Plex Sans, system-ui, sans-serif' });
      const pres = [...document.querySelectorAll('pre.mermaid')];
      const out = [];
      for (let i=0;i<pres.length;i++) {
        const { svg } = await mermaid.render('mm'+i, pres[i].textContent);
        out.push(svg);
      }
      return out;
    });
    let out = src, k = 0;
    out = out.replace(/<pre class="mermaid">[\s\S]*?<\/pre>/g, () => {
      let s = svgs[k++];
      s = s.replace(/<svg /, '<svg style="max-width:100%;height:auto;display:block" ');
      return s;
    });
    fs.writeFileSync(f, out);
    console.log(f, 'diagramas incrustados:', k, 'bytes:', out.length);
    await page.close();
  }
  // screenshot check of anclas
  const page = await browser.newPage({ viewport:{width:1200,height:900} });
  const src = fs.readFileSync('flujo-anclas.html','utf8');
  await page.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body>' + src.replace(/<link rel="stylesheet"[^>]*>/,'') + '</body></html>', { waitUntil:'load' });
  await page.screenshot({ path:'anclas-check.png', fullPage:false });
  const h = await page.evaluate(() => document.body.scrollHeight);
  console.log('anclas altura total px', h);
  await page.evaluate(() => window.scrollTo(0, 1500));
  await page.screenshot({ path:'anclas-check2.png' });
  await browser.close();
})();
