const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
  for (const f of ['flujo-spot.html','flujo-anclas.html']) {
    const page = await browser.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push('pageerror: '+e.message));
    page.on('console', m => { if (m.type()==='error') errs.push('console: '+m.text()); });
    const html = '<!doctype html><html><head><meta charset="utf-8"></head><body>' + fs.readFileSync(f,'utf8') + '</body></html>';
    await page.setContent(html, { waitUntil: 'load' });
    await page.addScriptTag({ path: 'mermaid.min.js' });
    const results = await page.evaluate(async () => {
      const out = [];
      const pres = [...document.querySelectorAll('pre.mermaid')];
      for (let i=0;i<pres.length;i++) {
        const src = pres[i].textContent;
        try { await mermaid.parse(src); out.push({i, ok:true, len:src.length}); }
        catch (e) { out.push({i, ok:false, err:String(e.message||e).slice(0,400)}); }
      }
      return out;
    });
    console.log('==', f, '==');
    for (const r of results) console.log(JSON.stringify(r));
    for (const e of errs) console.log(e.slice(0,300));
    await page.close();
  }
  await browser.close();
})();
