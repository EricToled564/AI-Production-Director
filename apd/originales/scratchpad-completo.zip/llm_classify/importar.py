#!/usr/bin/env python3
"""Importa resultado_0..5.json (clasificacion por lectura real) a regla_faceta con origen='llm'.

Valida cada valor contra catalogo.json antes de insertar; cualquier fila invalida
(id desconocido, dimension no pedida, valor fuera del catalogo) se reporta y se
descarta, nunca se inserta a ciegas.
"""
import json, sqlite3, sys
from datetime import datetime, timezone
from pathlib import Path

SCRATCH = Path(__file__).parent
DB = sys.argv[1] if len(sys.argv) > 1 else "rules.sqlite"

catalogo = json.loads((SCRATCH / "catalogo.json").read_text(encoding="utf-8"))
valores_validos = {dim: set(meta["valores"].keys()) for dim, meta in catalogo.items()}

pendientes = json.loads((SCRATCH / "reglas_pendientes.json").read_text(encoding="utf-8"))
faltan_por_id = {r["id"]: set(r["faltan"]) for r in pendientes}
ids_conocidos = set(faltan_por_id)

con = sqlite3.connect(DB)
fecha = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

total_filas = 0
insertadas = 0
descartadas = []
dudas = 0
por_dim_valor = {}
ids_vistos = set()

for i in range(6):
    path = SCRATCH / f"resultado_{i}.json"
    if not path.exists():
        print(f"AVISO: falta {path}")
        continue
    items = json.loads(path.read_text(encoding="utf-8"))
    for item in items:
        rid = item.get("id")
        total_filas += 1
        if rid not in ids_conocidos:
            descartadas.append((rid, None, None, "id_desconocido"))
            continue
        ids_vistos.add(rid)
        if item.get("duda"):
            dudas += 1
        valores = item.get("valores", {})
        for dim, valor in valores.items():
            if dim not in faltan_por_id[rid]:
                descartadas.append((rid, dim, valor, "dimension_no_pedida"))
                continue
            if dim not in valores_validos or valor not in valores_validos[dim]:
                descartadas.append((rid, dim, valor, "valor_fuera_de_catalogo"))
                continue
            con.execute("INSERT OR IGNORE INTO regla_faceta VALUES (?,?,?,?,?)",
                        (rid, dim, valor, "llm", fecha))
            con.execute("INSERT OR IGNORE INTO facetas_catalogo (dimension, valor, descripcion, cerrada) "
                        "VALUES (?,?,?,1)", (dim, valor, catalogo[dim]["valores"][valor]))
            insertadas += 1
            por_dim_valor.setdefault(dim, {}).setdefault(valor, 0)
            por_dim_valor[dim][valor] += 1

con.commit()

faltan_ids = ids_conocidos - ids_vistos

print(f"filas leidas de los 6 resultados: {total_filas}")
print(f"reglas distintas cubiertas: {len(ids_vistos)} / {len(ids_conocidos)} esperadas")
print(f"valores insertados (origen='llm'): {insertadas}")
print(f"marcadas 'duda': {dudas}")
print(f"descartadas por validacion: {len(descartadas)}")
for rid, dim, valor, razon in descartadas[:30]:
    print(f"  descartada: id={rid} dim={dim} valor={valor} razon={razon}")
if faltan_ids:
    print(f"\nreglas esperadas que NINGUN resultado cubrio ({len(faltan_ids)}):")
    for rid in list(faltan_ids)[:30]:
        print(f"  {rid}")

print("\npor dimension -> valor -> conteo:")
for dim in sorted(por_dim_valor):
    print(f"  {dim}:")
    for valor, n in sorted(por_dim_valor[dim].items(), key=lambda kv: -kv[1]):
        print(f"    {valor:20} {n}")
