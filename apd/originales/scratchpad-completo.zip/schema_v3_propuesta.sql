-- PROPUESTA v3 (no ejecutada). Extiende rules.sqlite v1/v2 sin romper build_app.py.
-- Grano: 1 fila = 1 enunciado normativo (id = sha1(ruta+texto), ya existente).

-- 1. NÚCLEO (determinista, se regenera desde los skills)
CREATE TABLE reglas (
  id          TEXT PRIMARY KEY,          -- sha1 12 hex, estable
  skill       TEXT NOT NULL,
  archivo     TEXT NOT NULL,
  linea       INTEGER NOT NULL,
  seccion     TEXT NOT NULL,             -- breadcrumb H1 > H2 > H3 (100% de cobertura medida)
  texto       TEXT NOT NULL,
  idioma      TEXT NOT NULL CHECK (idioma IN ('en','es','ru')),
  marcadores  TEXT NOT NULL,             -- prohibition,obligation,... (auditables)
  fuerza      TEXT NOT NULL CHECK (fuerza IN ('PROHIBICION','OBLIGACION','RECOMENDACION','EJEMPLO','ESTRUCTURA')),
  ambito      TEXT NOT NULL CHECK (ambito IN ('PIPELINE','EJEMPLO','HERRAMIENTA','META')),  -- derivado de la ruta
  medio       TEXT NOT NULL CHECK (medio IN ('IMAGEN','VIDEO','AMBOS','TEXTO','PROCESO')),
  fase        TEXT NOT NULL CHECK (fase IN ('PLANEACION','REDACCION','QA_RENDER','ENTREGA','TRANSVERSAL')),
  prioridad   INTEGER NOT NULL CHECK (prioridad BETWEEN 1 AND 5),  -- 1 veto §6.1 ... 5 ejemplo
  verificable TEXT NOT NULL CHECK (verificable IN ('MECANICA','MANUAL','NO_VERIFICABLE')),
  gate        TEXT,                      -- gate_image | gate_dramaturgy | validate_shots | aurora | audit_gi2 | ...
  texto_emb   TEXT NOT NULL,             -- "skill · archivo · sección · texto": lo que se vectoriza
  sha_archivo TEXT NOT NULL,             -- obsolescencia
  extraido    TEXT NOT NULL
);

-- 2. DIMENSIONES (N:M, taxonomías cerradas)
CREATE TABLE casos   (codigo TEXT PRIMARY KEY, descripcion TEXT NOT NULL, texto_emb TEXT);   -- T1..T5, PROD, GRAF, MULTI, REF, CLIP, SHOT, GUION, MARCA, QA, ENTREGA, NINGUNO
CREATE TABLE tareas  (codigo TEXT PRIMARY KEY, nombre TEXT NOT NULL, tracks TEXT, texto_emb TEXT); -- E0..E7, PROMPT_IMAGEN, PROMPT_VIDEO, REF, ESTRATEGIA, DOC
CREATE TABLE modelos (codigo TEXT PRIMARY KEY, familia TEXT NOT NULL, medio TEXT NOT NULL);   -- nano-banana-pro, gpt-image-2, kling-3, veo-3.1, seedance-2.5, ..., AGNOSTICO

CREATE TABLE regla_caso   (regla_id TEXT REFERENCES reglas(id), caso   TEXT REFERENCES casos(codigo),
  origen TEXT NOT NULL CHECK (origen IN ('archivo','regla','auditoria','nblm','vector')),
  confianza REAL, auditor TEXT, fecha TEXT NOT NULL, PRIMARY KEY (regla_id, caso));
CREATE TABLE regla_tarea  (regla_id TEXT REFERENCES reglas(id), tarea  TEXT REFERENCES tareas(codigo),
  origen TEXT NOT NULL CHECK (origen IN ('directa','derivada_caso','derivada_skill')), fecha TEXT NOT NULL,
  PRIMARY KEY (regla_id, tarea));
CREATE TABLE regla_modelo (regla_id TEXT REFERENCES reglas(id), modelo TEXT REFERENCES modelos(codigo),
  origen TEXT NOT NULL CHECK (origen IN ('archivo','mencion','manual')), fecha TEXT NOT NULL,
  PRIMARY KEY (regla_id, modelo));

-- 3. CAPA VECTORIAL + LÉXICA
CREATE TABLE embeddings (
  regla_id   TEXT NOT NULL REFERENCES reglas(id),
  modelo_emb TEXT NOT NULL,              -- 'intfloat/multilingual-e5-large' | 'text-embedding-3-large'
  dim        INTEGER NOT NULL,
  vector     BLOB NOT NULL,              -- float32 little-endian, normalizado (coseno = producto punto)
  texto_sha  TEXT NOT NULL,              -- sha del texto_emb vectorizado; distinto => re-embed
  PRIMARY KEY (regla_id, modelo_emb)
);
CREATE TABLE prototipos (                -- centroides de facetas para clasificar el brief
  tipo TEXT NOT NULL CHECK (tipo IN ('caso','tarea','modelo')), codigo TEXT NOT NULL,
  modelo_emb TEXT NOT NULL, vector BLOB NOT NULL, PRIMARY KEY (tipo, codigo, modelo_emb)
);
CREATE VIRTUAL TABLE reglas_fts USING fts5(id UNINDEXED, skill, seccion, texto, tokenize='unicode61 remove_diacritics 2');

-- 4. TRAZA DE CONSULTA (lo que hace auditable la extracción)
CREATE TABLE briefs (
  id TEXT PRIMARY KEY, texto TEXT NOT NULL, fecha TEXT NOT NULL,
  casos TEXT, tareas TEXT, modelos TEXT, medio TEXT, track TEXT,   -- facetas detectadas
  confirmado_por TEXT,                                             -- 'usuario' | 'agente' | 'nblm'
  total_filtro INTEGER, devueltas INTEGER, fuera_presupuesto INTEGER
);
CREATE TABLE brief_regla (
  brief_id TEXT REFERENCES briefs(id), regla_id TEXT REFERENCES reglas(id),
  rank INTEGER, score_bm25 REAL, score_cos REAL, score_final REAL,
  estado TEXT CHECK (estado IN ('APLICADA','NA','OMITIDA')), nota TEXT,
  PRIMARY KEY (brief_id, regla_id)
);

-- 5. SE CONSERVAN DE v2: skills, archivos (hash), prompts, prompt_regla, violaciones, conflictos, generaciones.
-- conflictos.gana se resuelve por reglas.prioridad (director §6): 1 vence a 2 vence a 3...

-- Vistas clave
CREATE VIEW v_sin_faceta AS      -- la propiedad "no puede callar": lo que no tiene caso/tarea/modelo se ve, no desaparece
  SELECT r.id, r.skill, r.archivo, r.texto FROM reglas r
  WHERE NOT EXISTS (SELECT 1 FROM regla_caso rc WHERE rc.regla_id = r.id)
     OR NOT EXISTS (SELECT 1 FROM regla_tarea rt WHERE rt.regla_id = r.id);
CREATE VIEW v_clasificacion_gruesa AS  -- las 556 con origen 'archivo': lo que hay que auditar primero
  SELECT r.*, GROUP_CONCAT(rc.caso) casos FROM reglas r JOIN regla_caso rc ON rc.regla_id = r.id
  WHERE rc.origen = 'archivo' GROUP BY r.id;
