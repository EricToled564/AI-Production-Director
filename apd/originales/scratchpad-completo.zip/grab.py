import re,html,sys,subprocess,hashlib,os,json
# usage: grab.py <dir> <url> <key1> <key2> ...
d,u=sys.argv[1],sys.argv[2]; keys=sys.argv[3:]
os.makedirs(d,exist_ok=True)
n=hashlib.md5(u.encode()).hexdigest()[:8]; f=os.path.join(d,n+'.html')
if not os.path.exists(f) or os.path.getsize(f)<500:
    subprocess.run(['curl','-sL','--max-time','45','-A','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',u,'-o',f])
s=open(f,encoding='utf-8',errors='ignore').read()
s=re.sub(r'<script.*?</script>|<style.*?</style>|<noscript.*?</noscript>','',s,flags=re.S)
s=re.sub(r'<[^>]+>',' ',s); s=html.unescape(s); s=re.sub(r'\s+',' ',s)
print('=====',u,'bytes',os.path.getsize(f),'textlen',len(s))
seen=set()
for k in keys:
    for m in re.finditer(re.escape(k),s,flags=re.I):
        a=max(0,m.start()-220); b=min(len(s),m.end()+260); t=s[a:b]
        if t[:50] in seen: continue
        seen.add(t[:50]); print('['+k+'] ...',t,'...\n')
