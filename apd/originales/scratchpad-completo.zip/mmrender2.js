const { chromium } = require('playwright');
const fs = require('fs');
const D = require('./diagrams.js');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
  const page = await browser.newPage({ viewport:{width:1200,height:900} });
  await page.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body></body></html>');
  await page.addScriptTag({ path: 'mermaid.min.js' });
  for (const f of Object.keys(D)) {
    const svgs = await page.evaluate(async (srcs) => {
      mermaid.initialize({ startOnLoad:false, theme:'neutral', securityLevel:'loose', flowchart:{ htmlLabels:false, useMaxWidth:false, curve:'basis', nodeSpacing:40, rankSpacing:50 }, themeVariables:{ fontSize:'15px', fontFamily:'IBM Plex Sans, system-ui, sans-serif' } });
      const out = [];
      for (let i=0;i<srcs.length;i++) {
        const { svg } = await mermaid.render('mmx'+i+'_'+Math.floor(Math.random()*1e6), srcs[i]);
        out.push(svg);
      }
      return out;
    }, D[f]);
    let html = fs.readFileSync(f,'utf8'), k = 0;
    html = html.replace(/<div class="diagram"><svg[\s\S]*?<\/svg><\/div>/g, () => {
      let s = svgs[k++];
      const m = s.match(/viewBox="[\d.\-]+ [\d.\-]+ ([\d.]+) ([\d.]+)"/);
      const w = m ? parseFloat(m[1]) : 0;
      const style = w > 1060 ? `width:${Math.round(w)}px;max-width:none;height:auto;display:block` : 'max-width:100%;height:auto;display:block;margin:0 auto';
      s = s.replace(/<svg /, `<svg style="${style}" `).replace(/ width="[^"]*"/, '').replace(/ height="[^"]*"/, '');
      console.log(f, 'diagrama', k, 'ancho', Math.round(w), 'alto', m?Math.round(parseFloat(m[2])):'?');
      return `<div class="diagram">${s}</div>`;
    });
    if (k !== D[f].length) throw new Error(f+': reemplazados '+k+' de '+D[f].length);
    fs.writeFileSync(f, html);
    console.log(f, 'bytes', html.length);
  }
  // element screenshots for visual check
  for (const [f, idx] of [['flujo-spot.html',0],['flujo-spot.html',2],['flujo-anclas.html',0],['flujo-anclas.html',1]]) {
    const p = await browser.newPage({ viewport:{width:1200,height:900} });
    const src = fs.readFileSync(f,'utf8').replace(/<link rel="stylesheet"[^>]*>/,'');
    await p.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body>'+src+'</body></html>', { waitUntil:'load' });
    await p.locator('.diagram').nth(idx).screenshot({ path: `chk-${f.replace('.html','')}-${idx}.png` });
    await p.close();
  }
  await browser.close();
})();
