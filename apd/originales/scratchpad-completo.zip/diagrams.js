module.exports = {
'flujo-spot.html': [
`flowchart TD
  BRIEF([Brief del cliente]) --> TRACK{Clasificar track<br/>duración · marca · narrativa}
  TRACK -->|≤30s, sin marca formal| EXPRESS[EXPRESS: entra en E4]
  TRACK -->|30–90s, spot de campaña| E0
  TRACK -->|90s–10min| E0
  EXPRESS --> E4
  E0[E0 Brand Lock<br/>brand-lock-extractor] --> G0{Usuario confirma<br/>valores estimados}
  G0 --> E1[E1 Creative Strategy<br/>references/creative-strategy.md]
  E1 --> G1{Usuario elige<br/>UN concepto}
  G1 --> E2[E2 Screenwriting<br/>screenwriter]
  E2 --> G2{Fórmula de escena<br/>+ three-jobs rule}
  G2 --> E3[E3 Cinematic Direction<br/>video: dramaturgy + universal-rules]
  E3 --> G3{Cero vocabulario prohibido<br/>cámara con razón escrita}
  G3 --> E4[E4 Shot Planning<br/>storyboard-architect]
  E4 --> G4{validate_shots limpio<br/>6 puntos + 3 detalles por shot}
  G4 --> OK4{OK del director<br/>al storyboard}
  OK4 --> SOT[(shots.json<br/>fuente de verdad)]
  SOT --> E5[E5 Anchor Images<br/>génesis → maestros → cuadros → keyframes]
  E5 --> G5{Cada anchor crítico<br/>critique ACCEPT ≤ 2 rondas}
  G5 -->|3ª falla| REPLAN[Replantear el shot<br/>en shots.json]
  REPLAN --> SOT
  G5 --> E6[E6 Video Prompts<br/>forge → video archivo del modelo]
  E6 --> G6{Dramaturgy check 6 puntos<br/>+ 3 detalles + aurora-prompt-linter}
  G6 --> E7[E7 Package y Delivery<br/>storyboard-html-preview + production-package.md]
  E7 --> G7{Checklist maestro<br/>3 prompts trazan hasta el concepto}
  G7 --> PKG([Final AI Video<br/>Production Package])
  PKG --> POST[Post-producción<br/>generar clips · NLE · grade · audio · export]
  POST --> QA{QA final contra<br/>los 5 anclas}
  QA --> SPOT([Spot publicado])
  classDef gate fill:#f8e1df,stroke:#a8332f,color:#1c2230
  classDef user fill:#dfe9f4,stroke:#2f5f8f,color:#1c2230
  classDef seed fill:#fbead0,stroke:#c9821a,color:#1c2230,stroke-width:2px
  class G0,G1,G2,G3,G4,G5,G6,G7,QA gate
  class OK4 user
  class E5 seed`,
`flowchart TD
  PLAN[E5.1 Plan de anchors<br/>lee series_lock + 5 anclas + script] --> Q{¿Qué clase de sujeto<br/>hay que fijar?}
  Q --> PER[PERSONA<br/>paso 1: rostro T1 sin refs<br/>paso 2: cuerpo entero T2 con el rostro adjunto]
  Q --> LUG[LUGAR GENÉRICO<br/>exterior · interior]
  Q --> EDI[EDIFICACIÓN / LANDMARK<br/>arquitectura real, punto geográfico]
  Q --> ANI[ANIMAL<br/>especie real o personaje]
  Q --> PRO[PRODUCTO<br/>packaging, comida, bebida, device]
  Q --> OBJ[OBJETO / PROP<br/>el objeto ancla de los 5 anclas]
  PER --> PERm[Modelo: NB2 o NBP, probar ambos en rostros<br/>GPT Image 2 quality high para piel<br/>Grounding: NO funciona en personas<br/>Bloques SW30: light_hard · skin_doc · usecase_doc · clean_doc<br/>Patrón: portrait-cinema · character-design]
  LUG --> LUGm[Modelo: cualquiera<br/>Placa VACÍA, sin persona: SW30 R7<br/>Texto = series_lock.environment verbatim<br/>Presión ambiental de dramaturgy §9<br/>Patrón: dimensional.md para plano → interior/exterior]
  EDI --> EDIm[Modelo: NB2 obligatorio si la arquitectura debe ser fiel<br/>Image Grounding: edificios, puentes, plazas<br/>GPT Image 2 solo para anclas de época: Havana 1957<br/>Patrón: city-across-two-centuries · city food map]
  ANI --> ANIm[Modelo: NB2 con grounding para la especie correcta<br/>NBP si hay física compleja: agua, pelo, plumas<br/>Consistencia: refs de personaje NB2 hasta 4, NBP hasta 5<br/>Patrón: peacock botanical · underwater]
  PRO --> PROm[Modelo: GPT Image 2 quality high para etiquetas y materiales<br/>NBP para distorsión física<br/>Logo SOLO de asset aprobado: SW30 R10, forge R6<br/>Patrón: ecommerce · food-beverage · smartphone hero]
  OBJ --> OBJm[Modelo: cualquiera<br/>Debe ser reconocible en macro y en plano general<br/>Se canoniza porque reaparece en cada shot como motivo<br/>Patrón: cinematic verbose, micro-texturas]
  PERm --> GATE{¿Producto o logo de marca<br/>sin foto real?}
  PROm --> GATE
  GATE -->|sí| STOP[No es génesis:<br/>pedir la foto del producto o del logo<br/>y entrar por el flujo con referencia]
  GATE -->|no| GEN[[Subflujo atómico<br/>Nivel 4]]
  LUGm --> GEN
  EDIm --> GEN
  ANIm --> GEN
  OBJm --> GEN
  classDef seed fill:#fbead0,stroke:#c9821a,color:#1c2230,stroke-width:2px
  classDef cls fill:#fff7ea,stroke:#c9821a,color:#1c2230
  classDef gate fill:#f8e1df,stroke:#a8332f,color:#1c2230
  class PER,LUG,EDI,ANI,PRO,OBJ seed
  class PERm,LUGm,EDIm,ANIm,PROm,OBJm cls
  class GATE gate`,
`flowchart LR
  subgraph GEN[Génesis sin referencias · solo texto]
    T1[Persona: rostro T1]
    PL[Lugar: placa vacía]
    ED[Edificación / landmark<br/>grounded]
    AN[Animal]
    PR[Producto genérico]
    OB[Objeto ancla]
  end
  T1 -->|paso 2: rostro adjunto como Image 1<br/>keep facial features exactly the same| T2[Persona: cuerpo entero T2<br/>same face and clothes + deltas]
  AN -->|refs de personaje| AN2[Animal en otras poses]
  T2 -->|ref persona| T3[Cuadro 1 sujeto T3<br/>use only the person from image N]
  AN2 --> T3
  PL -->|keep the world untouched| T3
  ED -->|placa de establecimiento| T3
  PR -->|producto en manos o en mesa| T3
  OB -->|motivo visible| T3
  T3 -->|keyframe fija la anatomía| T4[Cuadro 2 sujetos T4<br/>un sujeto por generación]
  T3 -->|≥80% correcto| T5[Edición quirúrgica T5<br/>Move / Replace / Add / Remove]
  T4 --> T5
  T5 -->|start / tail| KF[Keyframes por shot]
  T3 --> KF
  PR -->|hero shot macro| KF
  OB -->|macro insert| KF
  KF -->|The tail image defines X, inherit exactly| CLIP[Clip de video E6<br/>Kling · Veo · Seedance]
  CLIP -->|continuity block U7 + roles U13| CLIP2[Clip siguiente]
  CLIP2 --> EDIT[Ensamble en NLE · POST]
  EDIT --> SPOT([Spot])
  classDef seed fill:#fbead0,stroke:#c9821a,color:#1c2230,stroke-width:2px
  classDef inherit fill:#fff7ea,stroke:#c9821a,color:#1c2230,stroke-dasharray:4 3
  class T1,PL,ED,AN,PR,OB seed
  class T2,AN2,T3,T4,T5,KF inherit`,
`flowchart TD
  A[Catalogar clase y tipo<br/>persona · lugar · edificación · animal · producto · objeto] --> B{¿Necesita fidelidad a algo real?<br/>arquitectura, especie, planta}
  B -->|sí| C0[Nano Banana 2 con Image Grounding<br/>nano-banana.md]
  B -->|no| B2[Elegir modelo<br/>image/models.md]
  B2 -->|Nano Banana Pro o NB2| C1[Leer nano-banana.md<br/>prosa natural, sin números de lente]
  B2 -->|GPT Image 2| C2[Leer gpt-image.md<br/>5 slots, anti-slop, quality]
  C0 --> D
  C1 --> D[golden-rules.md<br/>verbo inicial · positivo · hex · texto entre comillas]
  C2 --> D
  D --> E[Referencias por clase<br/>persona: characters + portrait-cinema<br/>producto: ecommerce · food-beverage<br/>lugar: dimensional · creative-direction<br/>animal: patterns con grounding]
  E --> F[Definir secciones del tipo<br/>persona: light_hard · skin_doc · usecase_doc · clean_doc<br/>producto: optics · surface · colour · clean<br/>lugar: geometría · luz · presión ambiental · sin persona<br/>~250 palabras]
  F --> G[Ensamblar por bloques<br/>P scene, subject, details, mood, usecase, constraints]
  G --> H{Lints mecánicos<br/>audit_gi2 · gate_image · gate_dramaturgy<br/>vocabulario prohibido · sin logos}
  H -->|falla| G
  H --> I{Pregunta de avance<br/>¿todas las reglas del caso? SÍ sin matices}
  I -->|NO| D
  I --> J[Micro-gate: 3 líneas<br/>SKILL · RIESGOS · TÉCNICA]
  J --> K[Preflight de costo<br/>créditos estimados]
  K --> L[Generar barato<br/>NB 0.5K · GPT quality low]
  L --> M[Seleccionar la mejor]
  M --> N[Regenerar en alta<br/>NB 2K/4K · GPT quality high]
  N --> O[Inspección propia<br/>zoom 100%: rostro, manos, anatomía, etiqueta, arquitectura]
  O --> P[visual-asset-critic<br/>6 capas → critique.json]
  P -->|ACCEPT| Q[(Canonizar con hash<br/>SW30 R11)]
  P -->|REVISE ≥80%| R[Editar, no re-tirar<br/>hasta 3 ediciones apiladas]
  R --> O
  P -->|REJECT o 2ª falla| S{Cambio de método<br/>con causa declarada}
  S -->|otro modelo o bloque| F
  S -->|3ª falla| T[Replantear el shot<br/>en shots.json]
  Q --> U([Referencia para T2, T3, keyframes, roles U13 en video])
  classDef gate fill:#f8e1df,stroke:#a8332f,color:#1c2230
  classDef seed fill:#fbead0,stroke:#c9821a,color:#1c2230,stroke-width:2px
  class B,H,I,S gate
  class Q,U seed`
],
'flujo-anclas.html': [
`flowchart TD
  A0[A0 Inventario desde shots.json<br/>series_lock · shot card · function tag · 5 anclas] --> A1[A1 Tarjeta de ancla<br/>nueve dimensiones D1 a D9 llenas]
  A1 --> G1{¿Algún campo vacío<br/>o beat no nombrable en una frase?}
  G1 -->|sí| A1
  G1 --> A2[A2 Plan de dependencias<br/>qué génesis y qué refs deben existir antes]
  A2 --> G2{¿Existen canonizados<br/>persona, placa, producto que este ancla necesita?}
  G2 -->|no| GEN[[Correr génesis faltantes<br/>flujo del mapa del spot, nivel 4]]
  GEN --> A2
  G2 --> A3{A3 Ruta por tipo de acción D2}
  A3 -->|A pose| RA[Quietud deliberada<br/>cero blur, bordes duros, vector de postura]
  A3 -->|B instante pico| RB[Blur parcial congelado<br/>estado posterior + consecuencia física]
  A3 -->|C movimiento continuo| RC[Presupuesto de velocidad<br/>≥3 de 5 cues, héroe nítido, mundo barrido]
  A3 -->|D fenómeno de luz| RD[El evento es la fuente de luz<br/>núcleo blanco, halación, mundo a contraluz]
  A3 -->|E interacción| RE[Staging de poder<br/>placa → inserto A → inserto B → contacto]
  A3 -->|F multitud| RF[Multitud como entorno<br/>placa anónima + héroes canonizados]
  RA --> A4
  RB --> A4
  RC --> A4
  RD --> A4
  RE --> A4
  RF --> A4
  A4[A4 Tratamiento, paleta, cámara, ángulo, luz D4 a D7 y D9<br/>defaults por tratamiento y por tipo de acción] --> A5[A5 Modelo y resolución D8<br/>ratio destino desde el inicio]
  A5 --> A6[A6 Ensamblar por bloques<br/>encuadre+lente · sujeto en su umbral · 3 planos con trabajo<br/>cue de movimiento congelado · luz+paleta · textura · regla de rostro · ratio]
  A6 --> G3{A7 Lints mecánicos<br/>gate_image · gate_dramaturgy · validate_prompts<br/>aurora caso 1 o 2 · sin texto · sin logos · tercio, POV, dirección}
  G3 -->|falla| A6
  G3 --> G4{Pregunta de avance<br/>¿todas las reglas del caso? SÍ sin matices}
  G4 -->|no| A4
  G4 --> A8[A8 Micro-gate 3 líneas + preflight de costo]
  A8 --> A9[A9 Generar barato → seleccionar → regenerar en alta<br/>NB 0.5K → 2K/4K · GPT low → high]
  A9 --> A10[A10 Inspección 100% + crítica 6 capas<br/>+ checks específicos del tipo de acción]
  A10 -->|ACCEPT| A11[(A11 Canonizar con hash<br/>registrar en shot.assets.generated)]
  A10 -->|REVISE ≥80%| ED[Editar, no re-tirar<br/>un cambio por iteración, preserve list repetida]
  ED --> A10
  A10 -->|REJECT o 2ª falla| G5{Cambio de método<br/>otro modelo, otro bloque, otra técnica de sujetos}
  G5 --> A3
  G5 -->|3ª falla| RP[Replantear el shot en shots.json]
  A11 --> A12[A12 Motion brief para el video<br/>Preserve cues · roles FF/LF · un movimiento · sin re-describir]
  classDef gate fill:#f8e1df,stroke:#a8332f,color:#1c2230
  classDef seed fill:#fbead0,stroke:#c9821a,color:#1c2230,stroke-width:2px
  classDef cold fill:#dde9f0,stroke:#2a5d7c,color:#1c2230
  class G1,G2,G3,G4,G5 gate
  class A11,A12 seed
  class A3,RA,RB,RC,RD,RE,RF cold`,
`flowchart TD
  S{¿Cuántas personas<br/>lleva el ancla?} -->|0| S0[Placa de entorno<br/>series_lock.environment verbatim<br/>una presión ambiental]
  S -->|1| S1[Sujeto canonizado + placa<br/>insert: use only the person from image N<br/>keep the world untouched]
  S -->|2| S2{¿Hay contacto físico?}
  S2 -->|no| S2a[Placa → inserto A → inserto B<br/>eyelines y staging de poder<br/>posición por ancla legible de la imagen]
  S2 -->|sí| S2b[Cuadro T4 desde keyframe aprobado<br/>un sujeto por generación<br/>manos nombradas: which hand<br/>el keyframe fija la anatomía]
  S -->|3 o más| S3{¿Todas las identidades<br/>deben reconocerse?}
  S3 -->|sí: quinteto, K-pop, equipo| EN[GRUPO ENSAMBLE<br/>génesis por miembro: rostro T1 → cuerpo T2<br/>placa con anclas de posición<br/>inserción secuencial, un miembro por generación]
  EN --> ENm{¿Miembros ≤ refs de personaje del modelo?<br/>NB2 4 · NBP 5 · GPT Image 2 hasta 16 con rol}
  ENm -->|sí| EN1[Una sola pasada con todos los maestros adjuntos<br/>cada uno con rol nombrado · verificar miembro por miembro]
  ENm -->|no| EN2[Subgrupos o inserción secuencial<br/>nunca N rostros desde texto]
  S3 -->|no: solo 1 a 3 héroes| S3a[Héroes canonizados uno a uno<br/>cada uno con su ref y su rol U13<br/>resto como figuras anónimas sin rostro legible]
  S3 -->|nadie: estadio, manifestación, calle| S6[MULTITUD ANÓNIMA como entorno<br/>placa con extras sin rostro legible<br/>profundidad FG textura · MG héroes · BG escala<br/>en movimiento: cues de velocidad del tipo C]
  S1 --> D[Diferenciación forzada<br/>ropa, pelo, rasgos distintos<br/>no identical clones · poses iguales solo en ensamble]
  S2a --> D
  S2b --> D
  EN1 --> D
  EN2 --> D
  S3a --> D
  S6 --> D
  D --> V{Crítico: contar rostros legibles}
  V -->|cada rostro legible corresponde a un maestro| OK[(ACCEPT candidato)]
  V -->|hay rostro legible sin maestro| R[Multitud: convertir a silueta, espalda, desenfoque<br/>Ensamble: REJECT, rehacer la inserción de ese miembro]
  classDef cold fill:#dde9f0,stroke:#2a5d7c,color:#1c2230
  classDef gate fill:#f8e1df,stroke:#a8332f,color:#1c2230
  classDef seed fill:#fbead0,stroke:#c9821a,color:#1c2230,stroke-width:2px
  class S,S2,S3,ENm cold
  class EN seed
  class V gate
  class OK seed`
]};
