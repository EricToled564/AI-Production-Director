import json,subprocess,sys,datetime
UA='research-bot/0.1'
for pid in sys.argv[1:]:
    r=subprocess.run(['curl','-sL','--max-time','60','-A',UA,f'https://api.pullpush.io/reddit/search/submission/?ids={pid}'],capture_output=True,text=True)
    try: d=json.loads(r.stdout)['data']
    except Exception as e: print('=====',pid,'SUBMISSION FAILED',r.stdout[:150]); continue
    if not d: print('=====',pid,'no submission'); continue
    p=d[0]; ts=datetime.datetime.utcfromtimestamp(p.get('created_utc',0)).date()
    print('=====',pid,'r/'+str(p.get('subreddit')),'|',p.get('title'),'| ups',p.get('score'),'|',ts,'| https://www.reddit.com'+str(p.get('permalink')))
    print('BODY:',(p.get('selftext') or '')[:1800].replace('\n',' '))
    r=subprocess.run(['curl','-sL','--max-time','60','-A',UA,f'https://api.pullpush.io/reddit/search/comment/?link_id={pid}&size=60'],capture_output=True,text=True)
    try: cs=json.loads(r.stdout)['data']
    except Exception: print('  comments failed'); continue
    cs.sort(key=lambda c:-(c.get('score') or 0))
    for c in cs[:8]:
        print(f"  -- ({c.get('score')}) u/{c.get('author')}: {(c.get('body') or '')[:800].replace(chr(10),' ')}")
