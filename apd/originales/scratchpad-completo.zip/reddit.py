import json,subprocess,sys,re,hashlib,os
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
for u in sys.argv[1:]:
    ju=u.rstrip('/')+'.json?limit=40'
    for host in [ju.replace('www.reddit.com','old.reddit.com'), ju]:
        r=subprocess.run(['curl','-sL','--max-time','40','-A',UA,'-H','Accept: application/json',host],capture_output=True,text=True)
        try:
            d=json.loads(r.stdout); break
        except Exception: d=None
    n=hashlib.md5(u.encode()).hexdigest()[:8]
    if not d: print('=====',u,'FAILED', r.stdout[:120].replace('\n',' ')); continue
    open(f'reddit/{n}.json','w').write(r.stdout)
    post=d[0]['data']['children'][0]['data']
    print('=====',u); print('TITLE:',post.get('title'),'| sub:',post.get('subreddit'),'| ups:',post.get('ups'),'| created_utc:',post.get('created_utc'))
    print('BODY:',(post.get('selftext') or '')[:1500].replace('\n',' '))
    cs=[c['data'] for c in d[1]['data']['children'] if c['kind']=='t1']
    cs.sort(key=lambda c:-(c.get('ups') or 0))
    for c in cs[:8]:
        print(f"  -- ({c.get('ups')}) u/{c.get('author')}: {(c.get('body') or '')[:700].replace(chr(10),' ')}")
