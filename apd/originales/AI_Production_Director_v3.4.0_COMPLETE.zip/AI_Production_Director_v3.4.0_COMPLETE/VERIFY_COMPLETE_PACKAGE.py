#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys, tempfile, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CRITICAL = [
    'repo/.claude/settings.json',
    'repo/.mcp.json',
    'repo/package.json',
    'repo/package-lock.json',
    'repo/.claude/rules/v3/build/ruleset-3.4.0.json',
    'repo/.claude/rules/v3/build/model-routing.canonical-v3.3.json',
    'repo/.claude/rules/v3/case-fingerprint.schema.json',
    'repo/.claude/hooks/rule_matcher_v3.py',
    'repo/.claude/hooks/case_validate.py',
    'repo/.claude/hooks/model_router_v33.py',
    'repo/.claude/hooks/brief_freeze_v34.py',
    'repo/.claude/hooks/brief_apply_delta_v34.py',
    'repo/.claude/hooks/prompt_ast_gate_v34.py',
    'repo/.claude/hooks/prompt_patch_v34.py',
    'repo/.claude/hooks/prompt_render_v34.py',
    'repo/.claude/hooks/prompt_revision_gate_v34.py',
    'repo/production-package/RULES_MATRIX.md',
    'repo/production-package/template_engine.py',
    'repo/production-package/audit_gi2.py',
    'repo/production-package/dependency_closure.py',
    'repo/production-package/RECONSTRUCTION_MANIFEST.json',
    'original_source/aiproductiondirectorcompleto.zip',
    'project_knowledge_pack/AI_Production_Director_Knowledge_01.md',
    'project_knowledge_pack/AI_Production_Director_Knowledge_02.md',
    'project_knowledge_pack/AI_Production_Director_Knowledge_03.md',
    'project_knowledge_pack/AI_Production_Director_Knowledge_04.md',
    'project_knowledge_pack/AI_Production_Director_Knowledge_05.md',
    'project_knowledge_pack/AI_Production_Director_Knowledge_06.md',
    'project_knowledge_pack/AI_Production_Director_Knowledge_07.md',
    'project_knowledge_pack/KNOWLEDGE_MANIFEST.md',
]
SKILLS = {
    'ai-production-director','ai-video-storyboard','aurora-prompt-linter',
    'brand-lock-extractor','image','produccion-visual-sw30','screenwriter',
    'storyboard-architect','storyboard-html-preview','video',
    'visual-asset-critic','visual-media','visual-prompt-forge'
}

def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def run(cmd, cwd=None, timeout=120):
    p=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=timeout)
    return {'cmd':' '.join(map(str,cmd)), 'returncode':p.returncode, 'stdout':p.stdout.strip(), 'stderr':p.stderr.strip()}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--run-tests',action='store_true')
    ap.add_argument('--json',action='store_true')
    a=ap.parse_args()
    errors=[]; checks=[]

    missing=[x for x in CRITICAL if not (ROOT/x).is_file()]
    checks.append({'name':'critical_files','pass':not missing,'missing':missing})
    if missing: errors.append(f'{len(missing)} critical files missing')

    actual_skills={p.name for p in (ROOT/'skills').iterdir() if p.is_dir()} if (ROOT/'skills').is_dir() else set()
    miss_skills=sorted(SKILLS-actual_skills)
    checks.append({'name':'skills_13','pass':not miss_skills and len(SKILLS)==13,'actual_count':len(actual_skills),'missing':miss_skills})
    if miss_skills: errors.append('skills missing: '+', '.join(miss_skills))

    rs_path=ROOT/'repo/.claude/rules/v3/build/ruleset-3.4.0.json'
    try:
        rs=json.loads(rs_path.read_text(encoding='utf-8'))
        ok=rs.get('published') is True and rs.get('ruleset_version')=='3.4.0' and rs.get('rule_count')==1704 and len(rs.get('rules',[]))==1704
        checks.append({'name':'ruleset_3_4_0','pass':ok,'version':rs.get('ruleset_version'),'rule_count':rs.get('rule_count'),'published':rs.get('published')})
        if not ok: errors.append('ruleset 3.4.0 metadata/count mismatch')
    except Exception as e:
        checks.append({'name':'ruleset_3_4_0','pass':False,'error':str(e)}); errors.append('ruleset unreadable')

    src_hash_file=ROOT/'original_source/ORIGINAL_SOURCE_SHA256.txt'
    try:
        expected=src_hash_file.read_text().split()[0]
        actual=sha256(ROOT/'original_source/aiproductiondirectorcompleto.zip')
        ok=expected==actual
        checks.append({'name':'original_source_hash','pass':ok,'sha256':actual})
        if not ok: errors.append('original source hash mismatch')
    except Exception as e:
        checks.append({'name':'original_source_hash','pass':False,'error':str(e)}); errors.append('original source hash unavailable')

    manifest=ROOT/'MANIFEST_SHA256.txt'
    manifest_errors=[]; manifest_count=0
    if manifest.is_file():
        for line in manifest.read_text(encoding='utf-8').splitlines():
            if not line.strip(): continue
            try: expected, rel=line.split('  ',1)
            except ValueError: manifest_errors.append('malformed: '+line); continue
            p=ROOT/rel; manifest_count+=1
            if not p.is_file(): manifest_errors.append('missing: '+rel)
            elif sha256(p)!=expected: manifest_errors.append('hash mismatch: '+rel)
    else: manifest_errors.append('MANIFEST_SHA256.txt missing')
    checks.append({'name':'package_manifest','pass':not manifest_errors,'entries':manifest_count,'errors':manifest_errors[:20]})
    if manifest_errors: errors.append(f'manifest errors={len(manifest_errors)}')

    closure=run([sys.executable,str(ROOT/'repo/production-package/dependency_closure.py'),'--json'])
    closure_ok=closure['returncode']==0
    checks.append({'name':'dependency_closure','pass':closure_ok,'result':closure})
    if not closure_ok: errors.append('dependency closure failed')

    if a.run_tests:
        # Some legacy verification scripts republish build artifacts. Run the entire
        # regression suite on a disposable copy so verification never mutates the package.
        with tempfile.TemporaryDirectory(prefix='apd_verify_') as td:
            test_root=Path(td)/'package'
            test_root.mkdir(parents=True, exist_ok=True)
            test_repo=test_root/'repo'
            shutil.copytree(ROOT/'repo', test_repo, symlinks=True)
            # Legacy KB compiler resolves the canonical skill tree as ../skills.
            shutil.copytree(ROOT/'skills', test_root/'skills', symlinks=True)
            tests=[
                [sys.executable,'-m','unittest','discover','-s','tests/v3.4','-p','test*.py'],
                [sys.executable,'tests/v3.3.2/test_production_package_reconstruction.py'],
                [sys.executable,'tests/v3.3/test_decision_routing_v33.py'],
                [sys.executable,'tests/v3.2/test_learning_patch_v32.py'],
                ['bash','.claude/hooks/verify_v31.sh'],
                ['bash','.claude/hooks/verify_v3.sh'],
            ]
            for cmd in tests:
                r=run(cmd,cwd=test_repo,timeout=300)
                ok=r['returncode']==0
                checks.append({'name':'test:'+(' '.join(cmd)),'pass':ok,'result':r})
                if not ok: errors.append('test failed: '+' '.join(cmd))

    out={'status':'PASS' if not errors else 'FAIL','version':'3.4.0','errors':errors,'checks':checks}
    if a.json: print(json.dumps(out,ensure_ascii=False,indent=2))
    else:
        print('AI PRODUCTION DIRECTOR COMPLETE PACKAGE:',out['status'])
        for c in checks: print(('PASS' if c.get('pass') else 'FAIL').ljust(5),c['name'])
        if errors:
            print('\nERRORS:')
            for e in errors: print('-',e)
    return 0 if not errors else 1

if __name__=='__main__': raise SystemExit(main())
