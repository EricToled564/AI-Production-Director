# AI Production Director v3.4 — Frozen Brief / Authorized Delta

## Problem fixed
Repeated prompt revisions were able to rewrite unrelated prompt content while supposedly changing only one requested field. Examples observed in production included changing wardrobe, camera wording, composition, background or expression while resolving a single field such as player age.

## v3.4 invariant
A revision is no longer a free-text rewrite.

`frozen brief -> authorized delta -> updated frozen brief -> same immutable Prompt AST -> deterministic render`

If the Prompt AST, model, parameters, templates, block structure, or provenance changes during a normal brief-value revision, delivery is blocked.

## New deterministic controls

- `brief_freeze_v34.py` — freezes facts and states, produces SHA-256.
- `brief_preflight_v34.py` — blocks compilation when a prompt-required field is OPEN.
- `brief_apply_delta_v34.py` — applies only an explicit delta against the exact prior brief hash.
- `prompt_ast_gate_v34.py` — requires locked brief bindings and rule/adapter provenance.
- `prompt_patch_v34.py` — advances only the brief hash/revision; does not rewrite prompt content.
- `prompt_render_v34.py` — deterministically renders immutable templates from frozen facts.
- `prompt_revision_gate_v34.py` — blocks any AST/model/parameter/template drift.

## Ruleset

Base: `ruleset-3.3.2.json` — 1,700 rules.
Learned deterministic controls added: 4.
Published: `ruleset-3.4.0.json` — 1,704 rules.

Rules added:
1. Frozen brief is immutable source of truth.
2. Required unresolved fields block prompt compilation.
3. Every revision requires an explicit authorized delta against the prior brief hash.
4. Revisions re-render the same immutable Prompt AST; no free-text rewrite.

## Tennis regression

The included `repo/examples/v3.4/tennis/` fixture reproduces the failure mode.

- Missing required age -> **BLOCKED**.
- Authorized age resolution -> **PASS**.
- Age-only revision -> only the age string changes in rendered prompt.
- Attempt to add `white tournament tennis kit` and alter camera during age-only revision -> **BLOCKED: UNAUTHORIZED PROMPT DRIFT**.
- Attempt to change 16:9 to 1:1 during age-only revision -> **BLOCKED**.

## Verification

- v3.4 tests: **7/7 PASS**
- v3.3.2 dependency reconstruction: **PASS**
- v3.3 decision routing: **PASS**
- v3.2 learning patch: **PASS**
- v3.1 exhaustive regression: **13/13 PASS**
- legacy v3 regression: **18/18 PASS**

## Operational rule

For a normal revision, the assistant is not permitted to write a replacement prompt. It may only create an authorized brief delta. The patch engine and deterministic renderer produce the revised prompt.

A structural prompt change requires a separate, explicit structural-revision authorization and must not be smuggled into a normal field delta.
