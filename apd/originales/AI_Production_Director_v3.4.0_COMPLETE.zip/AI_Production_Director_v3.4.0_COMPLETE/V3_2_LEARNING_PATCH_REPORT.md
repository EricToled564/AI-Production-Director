# AI Production Director v3.2 — Production Learning Patch Report

## Scope
Controlled learning patch from the Olympic 10 m platform-diving split-level image trial. Canonical KB extraction/classification remains frozen at v3.1.1. Production evidence is added as a separate, versioned `LEARNED_PRODUCTION` overlay.

## Ruleset
- Canonical KB rules: 1,649
- Learned production rules: 12
- Runtime total: 1,661
- Ruleset: `3.2.0`

## Integrated learnings
1. Lock preservation across revisions.
2. Small-delta revision rather than whole-prompt rewrites.
3. Preserve sufficiently precise domain-native pose/technique wording.
4. Reference-role isolation with explicit ignored dimensions.
5. Aspect ratio/size treated as generator parameters, not prompt prose only.
6. Output aspect-ratio QA: exact preferred; <=1% minor; >1% blocking unless accepted.
7. No amplification of unspecified quantity/density/intensity.
8. Physically justified underwater occlusion may hide non-critical anatomy while preserving silhouette/proportions.
9. Camera-relative scene geometry: objects behind camera may not appear in frame.
10. QA required before declaring an asset/model successful; mechanical vs semantic checks stay separate; non-visually-verifiable demographic facts are not certified from pixels.
11. Accepted asset + localized changes => surgical edit, preserve all unaffected locks/pixels.
12. Empirical routing: Nano Banana Pro preferred by default for complex split-level underwater human anatomy / Olympic-platform-diving cases, unless the user locks another model or later benchmark evidence supersedes it.

## Runtime additions
- `learned/production-learnings.v3.2.json`
- `learned/model-routing.v3.2.json`
- `learned/LEARNING_REGISTRY_v3.2.md`
- `ruleset-3.2.0.json`
- `model_router_v32.py`
- `output_geometry_check_v32.py`
- `revision_delta_check_v32.py`
- `templates/v3.2/underwater-human-reference-policy.md`
- `templates/v3.2/surgical-image-edit.md`

## Validation
- v3.2 learning-patch suite: PASS
- v3.1 regression: 13 passed / 0 failed
- legacy v3 regression: 18 passed / 0 failed
- Diver v3.2 runtime: 1,661 rules evaluated with 0 unresolved and 0 unresolved conflicts.

## Policy
These learnings do not modify the canonical KB extractor. If a later production result contradicts an empirical heuristic, it must be versioned and regression-tested rather than silently overwritten.

## v3.2.1 — Tennis composition trial correction

Two additional learned-production rules were promoted after the tennis composition trial:

13. `lrn321_composition_abstraction_no_ref` — When an uploaded image is supplied only to study/follow composition, extract a composition specification and do not attach the image to generation unless the user explicitly requests reference-image use.
14. `lrn321_no_cross_task_attribute_leak` — New tasks may not inherit subject demographics, nationality, ethnicity, gender, wardrobe, brand, or other content locks from prior tasks unless explicitly inherited by the current brief.

A reusable template was added at `repo/templates/v3.2/composition-only-source.md`.
Ruleset `3.2.1` contains 1,649 canonical KB rules + 14 learned-production rules = 1,663 total.
