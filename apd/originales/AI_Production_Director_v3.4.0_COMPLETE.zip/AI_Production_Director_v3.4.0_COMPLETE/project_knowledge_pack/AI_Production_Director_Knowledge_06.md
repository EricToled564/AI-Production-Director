# AI Production Director — Knowledge Pack 6/7

Generated from `aiproductiondirectorcompleto.zip`.
Each source file is preserved with its original relative path.


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/shots-to-html.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/shots-to-html.py`

#!/usr/bin/env python3
"""
Standalone helper: render an output folder into a single preview.html.

Renders skills/storyboard-html-preview/templates/preview.html.tpl, the same
structural template the storyboard-html-preview skill uses, so the two cannot drift.
All interpolated content is HTML-escaped: subjects, rationales, and VO lines are
model-generated prose, and one angle bracket in a rationale used to break the page a
client was looking at.

Two timestamps, deliberately distinct. "Run" is when the storyboard was produced, read
from run.json. "Rendered" is when this page was written. Collapsing them into one
"Generated" date meant re-rendering a preview six months later silently restamped the
run as today.

Usage:
    python tools/shots-to-html.py path/to/output-folder
    python tools/shots-to-html.py path/to/output-folder --out preview.html
    python tools/shots-to-html.py path/to/output-folder --inline-images
    python tools/shots-to-html.py path/to/output-folder --rendered-at 2026-07-30T00:00:00Z
    python tools/shots-to-html.py --selftest
"""

from __future__ import annotations

import argparse
import base64
import sys
from pathlib import Path

from _shotkit import (
    IMAGE_EXTS,
    PALETTE_ROLES,
    REPO_ROOT,
    as_overlay_ids,
    find_frame,
    iso_instant,
    load_json,
    parse_palette,
    parse_typography,
    round_dirs,
    sha256_file,
)
from _template import escape, render

TEMPLATE_DIR = REPO_ROOT / "skills" / "storyboard-html-preview" / "templates"

FALLBACK_BRAND = {
    "bg": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
    "display_font": "Inter",
    "body_font": "Inter",
}

FALLBACK_HEX = {
    "background": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
}


def read_template(name: str) -> str:
    return (TEMPLATE_DIR / name).read_text(encoding="utf-8")


def parse_brand_lock(path: Path) -> tuple[dict, list[str]]:
    """
    Pull palette and typography out of a brand-lock.

    Returns (values, warnings). Warnings name every role that fell back to a generic
    default, because a preview that quietly renders in someone else's blue is worse
    than one that tells you the palette did not parse.
    """
    if not path.exists():
        return (dict(FALLBACK_BRAND), [f"brand-lock not found at {path.name}"])

    text = path.read_text(encoding="utf-8")
    palette = parse_palette(text)
    warnings: list[str] = []

    def pick(role: str) -> str:
        # Exact role first, then any role containing it, e.g. "accent (warm)".
        if role in palette and not palette[role].startswith("#_"):
            return palette[role]
        for name, hex_val in palette.items():
            if role in name and not hex_val.startswith("#_"):
                return hex_val
        warnings.append(
            f"palette role '{role}' not found in the brand-lock, using a generic default"
        )
        return FALLBACK_HEX[role]

    values = {
        "bg": pick("background"),
        "ink": pick("ink"),
        "accent": pick("accent"),
        "muted": pick("muted"),
        "rule": pick("rule"),
    }

    fonts = parse_typography(text)
    values["display_font"] = fonts.get("display_font") or FALLBACK_BRAND["display_font"]
    values["body_font"] = fonts.get("body_font") or FALLBACK_BRAND["body_font"]
    for key in ("display_font", "body_font"):
        if not fonts.get(key):
            warnings.append(
                f"brand-lock declares no {key.replace('_', ' ')}, using "
                f"{FALLBACK_BRAND[key]}"
            )

    return (values, warnings)


def aspect_class(aspect: str) -> str:
    return "aspect-" + str(aspect).replace(":", "-")


def encode_image_b64(path: Path) -> str:
    ext = path.suffix.lstrip(".").lower()
    mime = {
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
    }.get(ext, "image/png")
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def frame_for_shot(out_dir: Path, shot: dict) -> tuple[Path | None, str | None]:
    """
    Resolve a shot's frame, preferring what the data says over what the tree implies.

    Order: an accepted entry in shot.assets.generated, then the newest entry there,
    then the frames/round-N path convention, then the legacy generated/ directory.
    Returns (path, note) where note explains a non-obvious pick.
    """
    generated = (shot.get("assets") or {}).get("generated") or []
    accepted = [g for g in generated if g.get("accepted") is True and g.get("path")]
    pool = accepted or [g for g in generated if g.get("path")]
    if pool:
        chosen = max(pool, key=lambda g: g.get("round") or 0)
        path = out_dir / chosen["path"]
        if path.exists():
            note = None
            if chosen.get("sha256"):
                actual = sha256_file(path)
                if actual != chosen["sha256"]:
                    note = "frame has changed since it was recorded in shots.json"
            elif not accepted:
                note = "frame is not marked accepted"
            return (path, note)
        return (None, f"assets names {chosen['path']}, which is missing on disk")

    found = find_frame(out_dir, shot["id"])
    if found is None:
        return (None, None)
    return (found, None)


def latest_verdicts(out_dir: Path) -> dict[str, dict]:
    """Newest verdict per shot, read from the critique tree. Empty when there is none."""
    verdicts: dict[str, dict] = {}
    for round_no, directory in round_dirs(out_dir, "critiques"):
        for path in sorted(directory.glob("*.json")):
            data, err = load_json(path)
            if err or not isinstance(data, dict):
                continue
            shot_id = data.get("shot_id")
            if not shot_id:
                continue
            current = verdicts.get(shot_id)
            if current is None or round_no >= current["round"]:
                verdicts[shot_id] = {
                    "round": round_no,
                    "verdict": data.get("verdict"),
                }
    legacy, err = load_json(out_dir / "critique.json")
    if not err and isinstance(legacy, dict) and legacy.get("shot_id"):
        verdicts.setdefault(
            legacy["shot_id"],
            {"round": legacy.get("round") or 1, "verdict": legacy.get("verdict")},
        )
    return verdicts


def position_class(position) -> str:
    """Named positions map to a CSS class; explicit coordinates fall back to center."""
    if isinstance(position, str):
        return position
    return "center"


def position_label(position) -> str:
    if isinstance(position, dict):
        return f"x{position.get('x')}% y{position.get('y')}%"
    return str(position)


def build_context(out_dir: Path, args) -> tuple[dict, list[str]]:
    warnings: list[str] = []

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        raise SystemExit(f"ERROR: {err}")

    overlays_data, ov_err = load_json(out_dir / "text-overlays.json")
    if ov_err:
        overlays_data = {"overlays": []}
    overlays_by_id = {
        o["id"]: o for o in (overlays_data or {}).get("overlays", []) if o.get("id")
    }

    project = shots_data["project"]
    series = shots_data["series_lock"]
    shots = shots_data["shots"]
    aspect = project["aspect"]

    brand_ref = shots_data.get("brand_lock_ref") or "brand-lock.snapshot.md"
    brand_path = out_dir / brand_ref
    brand, brand_warnings = parse_brand_lock(brand_path)
    warnings.extend(brand_warnings)

    run_doc, run_err = load_json(out_dir / "run.json")
    if run_err or not isinstance(run_doc, dict):
        run_doc = {}
        warnings.append(
            "no run.json in this output tree, so the page cannot state when the run "
            "happened or which inputs it used"
        )

    verdicts = latest_verdicts(out_dir)
    provenance_notes: list[str] = []

    shot_contexts = []
    for shot in shots:
        frame_path, frame_note = frame_for_shot(out_dir, shot)
        if frame_note:
            provenance_notes.append(f"{shot['id']}: {frame_note}")
            warnings.append(f"{shot['id']}: {frame_note}")

        image_path = None
        if frame_path is not None:
            if args.inline_images:
                image_path = encode_image_b64(frame_path)
            else:
                try:
                    image_path = str(frame_path.relative_to(out_dir))
                except ValueError:
                    image_path = frame_path.name

        overlays = []
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            overlay = overlays_by_id.get(oid)
            if overlay is None:
                warnings.append(
                    f"{shot['id']} references overlay {oid}, which is not in "
                    f"text-overlays.json"
                )
                continue
            overlays.append(
                {
                    "id": overlay["id"],
                    "content": overlay.get("content"),
                    "font": overlay.get("font"),
                    "weight": overlay.get("weight"),
                    "color": overlay.get("color"),
                    "size": overlay.get("size"),
                    "position_class": position_class(overlay.get("position")),
                    "position_label": position_label(overlay.get("position")),
                    "enter_at": (overlay.get("enter") or {}).get("at"),
                    "enter_animation": (overlay.get("enter") or {}).get("animation"),
                    "exit_at": (overlay.get("exit") or {}).get("at"),
                    "exit_animation": (overlay.get("exit") or {}).get("animation"),
                }
            )

        verdict = verdicts.get(shot["id"])
        shot_contexts.append(
            {
                "id": shot["id"],
                "id_short": shot["id"].replace("shot_", ""),
                "beat": shot.get("beat"),
                "start": shot.get("start"),
                "end": shot.get("end"),
                "framing": shot.get("framing"),
                "angle": shot.get("angle"),
                "motion": shot.get("motion"),
                "depth_of_field": shot.get("depth_of_field"),
                "subject": shot.get("subject"),
                "vo": shot.get("vo"),
                "rationale": shot.get("rationale"),
                "aspect_class": aspect_class(aspect),
                "has_image": image_path is not None,
                "has_no_image": image_path is None,
                "image_path": image_path,
                "overlays": overlays,
                "has_overlays": bool(overlays),
                "has_verdict": verdict is not None,
                "verdict": (verdict or {}).get("verdict"),
                "verdict_round": (verdict or {}).get("round"),
                "verdict_class": str((verdict or {}).get("verdict", "")).lower(),
            }
        )

    css = (
        read_template("styles.css.tpl")
        .replace("{{BG_COLOR}}", brand["bg"])
        .replace("{{INK_COLOR}}", brand["ink"])
        .replace("{{ACCENT_COLOR}}", brand["accent"])
        .replace("{{MUTED_COLOR}}", brand["muted"])
        .replace("{{RULE_COLOR}}", brand["rule"])
        .replace("{{DISPLAY_FONT}}", brand["display_font"])
        .replace("{{BODY_FONT}}", brand["body_font"])
        .replace("{{INLINE_PRINT_CSS}}", read_template("print.css.tpl"))
    )

    brand_sha = sha256_file(brand_path) if brand_path.exists() else None
    recorded_sha = (run_doc.get("inputs") or {}).get("brand_lock_sha256")
    if brand_sha and recorded_sha and brand_sha != recorded_sha:
        provenance_notes.append(
            "the brand-lock on disk no longer matches the one recorded in run.json"
        )
        warnings.append(
            "brand-lock has changed since the run; this preview does not show the "
            "brand state the frames were produced against"
        )

    context = {
        "PROJECT_TITLE": project["title"],
        "DURATION": project["duration_s"],
        "ASPECT": aspect,
        "FRAMEWORK": project.get("framework") or "not specified",
        "SHOTS_VERSION": shots_data.get("version", "unknown"),
        "BRIEF": None,
        "SERIES_CHARACTER": series["character"],
        "SERIES_ENVIRONMENT": series["environment"],
        "SERIES_LIGHTING": series["lighting"],
        "SERIES_COLOR_GRADE": series["color_grade"],
        "BRAND_LOCK_REF": brand_ref,
        "BRAND_LOCK_SHA_SHORT": brand_sha[:12] if brand_sha else None,
        "RUN_ID": run_doc.get("run_id") or "not recorded",
        "RUN_CREATED_AT": run_doc.get("created_at") or "not recorded",
        "RENDERED_AT": args.rendered_at or iso_instant(),
        "PROVENANCE_NOTE": " ".join(provenance_notes) or None,
        "INLINE_CSS": css,
        "shots": shot_contexts,
    }
    return (context, warnings)


def selftest() -> int:
    """Render the bundled worked run twice and prove the output is byte-identical."""
    worked = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    ok = True

    class Args:
        inline_images = False
        rendered_at = "2026-07-30T00:00:00Z"

    first, _ = build_context(worked, Args())
    second, _ = build_context(worked, Args())
    html_a = render(read_template("preview.html.tpl"), first)
    html_b = render(read_template("preview.html.tpl"), second)

    if html_a == html_b:
        print("  ok    selftest: two renders with a pinned timestamp are identical")
    else:
        print("  FAIL  selftest: two renders differed")
        ok = False

    # shot_06 of the shotkit-explainer example carries two overlays. A renderer that
    # resolves only the first drops the second silently, which is what used to happen.
    explainer = (
        REPO_ROOT
        / "skills"
        / "storyboard-architect"
        / "examples"
        / "shotkit-explainer"
    )
    multi_ctx, _ = build_context(explainer, Args())
    shot_06 = next(s for s in multi_ctx["shots"] if s["id"] == "shot_06")
    multi_html = render(read_template("preview.html.tpl"), multi_ctx)

    checks = [
        ("escapes angle brackets", "<script>alert(1)</script>" not in render(
            "{{subject}}", {"subject": "<script>alert(1)</script>"}
        )),
        ("escapes quotes inside a style attribute", "&quot;" in render(
            '<span style="font-family: {{font}};">x</span>', {"font": '"><script>'}
        )),
        ("resolves every overlay on a multi-overlay shot", len(shot_06["overlays"]) == 2),
        (
            "renders every overlay on a multi-overlay shot",
            all(
                escape(overlay["content"]) in multi_html
                for overlay in shot_06["overlays"]
            ),
        ),
        ("states the run date, not the render date, in the header", "2026-07-30T14:23:00Z" in html_a),
        ("labels the render separately", "rendered 2026-07-30T00:00:00Z" in html_a),
        ("shows a verdict badge", "sb-verdict-accept" in html_a),
        ("uses the brand-lock ref from shots.json", 'href="brand-lock.snapshot.md"' in html_a),
        ("carries no unrendered template tags", "{{" not in html_a),
    ]
    for label, passed in checks:
        if passed:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    p = argparse.ArgumentParser(
        description="Render a shotkit output folder into a single preview.html."
    )
    p.add_argument(
        "output_dir",
        nargs="?",
        type=Path,
        help="Directory containing shots.json, text-overlays.json, run.json",
    )
    p.add_argument("--out", default="preview.html", help="Output filename, relative to output_dir")
    p.add_argument(
        "--inline-images",
        action="store_true",
        help="Embed frames as base64 so the file is portable on its own",
    )
    p.add_argument(
        "--rendered-at",
        help="Pin the render timestamp (UTC ISO-8601). Makes output reproducible.",
    )
    p.add_argument("--selftest", action="store_true", help="Prove the renderer's guarantees")
    args = p.parse_args()

    if args.selftest:
        return selftest()
    if args.output_dir is None:
        p.error("output_dir is required unless --selftest is given")

    out_dir: Path = args.output_dir
    if not out_dir.is_dir():
        print(f"ERROR: output directory not found: {out_dir}")
        return 1
    if not (out_dir / "shots.json").exists():
        print(f"ERROR: shots.json not found in {out_dir}")
        return 1

    context, warnings = build_context(out_dir, args)
    html_out = render(read_template("preview.html.tpl"), context)

    out_path = out_dir / args.out
    out_path.write_text(html_out, encoding="utf-8")
    print(f"  wrote {out_path}")
    for warn in warnings:
        print(f"  warn  {warn}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/shots-to-html.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/validate_brand_lock.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/validate_brand_lock.py`

#!/usr/bin/env python3
"""
Validate a brand-lock Markdown file.

Two modes, because a brand-pack and a snapshot are not the same artifact.

A brand-pack (brand-packs/*.md) is a source document. An unfilled template is a legal
brand-pack: that is what a template is for.

A snapshot (brand-lock.snapshot.md, written into an output tree) is a provenance
record. It has to carry the header storyboard-architect promises to write, and if it
still contains template placeholders then the run it governs was built against nothing.
Pass --snapshot to check those extra rules, and --require-configured to reject
placeholders outright.

Required headings (case-insensitive, in any order):
- Identity, Palette, Typography, Mood adjectives, Never list,
  Aspect ratios, Color grade direction, Motion language, Voice rules

Required identity fields (under ## Identity):
- Brand, One-line description, Archetype, Voice posture

Usage:
    python tools/validate_brand_lock.py path/to/brand-lock.md [...]
    python tools/validate_brand_lock.py --snapshot path/to/brand-lock.snapshot.md
    python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
    python tools/validate_brand_lock.py --snapshots            # every bundled snapshot
    python tools/validate_brand_lock.py --selftest
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from _shotkit import (
    ISO_INSTANT_RE,
    PALETTE_ROLES,
    REPO_ROOT,
    is_unconfigured,
    parse_palette,
    parse_snapshot_header,
    parse_typography,
)

REQUIRED_SECTIONS = {
    "identity",
    "palette",
    "typography",
    "mood adjectives",
    "never list",
    "aspect ratios",
    "color grade direction",
    "motion language",
    "voice rules",
}

REQUIRED_IDENTITY_FIELDS = {
    "brand",
    "one-line description",
    "archetype",
    "voice posture",
}

ISO_DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")


def parse_headings(text: str) -> list[tuple[int, str]]:
    """Return list of (level, heading_text_lower) for every Markdown heading."""
    out = []
    for line in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            out.append((len(m.group(1)), m.group(2).strip().lower()))
    return out


def extract_section(text: str, heading_lower: str) -> str:
    """Extract the body of a section by its heading. Empty string if not found."""
    lines = text.splitlines()
    in_section = False
    section_lines: list[str] = []
    section_level: int | None = None
    for line in lines:
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            level = len(m.group(1))
            heading = m.group(2).strip().lower()
            if not in_section:
                if heading == heading_lower:
                    in_section = True
                    section_level = level
                    continue
            else:
                if section_level is not None and level <= section_level:
                    break
        if in_section:
            section_lines.append(line)
    return "\n".join(section_lines)


def check_structure(text: str) -> list[str]:
    errors: list[str] = []
    heading_set = {h for _, h in parse_headings(text)}

    for missing in sorted(REQUIRED_SECTIONS - heading_set):
        errors.append(f"missing section: ## {missing.title()}")

    if "identity" in heading_set:
        identity_body = extract_section(text, "identity").lower()
        for field in sorted(REQUIRED_IDENTITY_FIELDS):
            if field not in identity_body:
                errors.append(f"identity section missing field: '{field}'")

    if "palette" in heading_set:
        palette_body = extract_section(text, "palette")
        if not re.search(r"#[0-9A-Fa-f]{6}|#_{6}", palette_body):
            errors.append(
                "palette section has no hex color values (or template placeholders)"
            )

    return errors


def check_roles(text: str) -> list[str]:
    """
    The palette role names the HTML preview maps onto CSS variables.

    A brand-lock is free to add rows, but a missing role means the preview silently
    renders that slot in a generic default, so it is worth saying out loud.
    """
    warnings: list[str] = []
    palette = parse_palette(text)
    for role in PALETTE_ROLES:
        if not any(role in name for name in palette):
            warnings.append(
                f"palette has no '{role}' role; the HTML preview will fall back to a "
                f"generic color for it"
            )
    return warnings


def check_typography(text: str) -> list[str]:
    warnings: list[str] = []
    fonts = parse_typography(text)
    for key, label in (("display_font", "Display"), ("body_font", "Body")):
        if not fonts.get(key):
            warnings.append(
                f"typography declares no {key.replace('_', ' ')} in a readable form; "
                f'expected ``**{label} font:** `Font Name Weight` `` with the name '
                f"backticked immediately after the label"
            )
    return warnings


def check_snapshot(text: str) -> tuple[list[str], list[str]]:
    """The provenance header storyboard-architect writes into every snapshot."""
    errors: list[str] = []
    warnings: list[str] = []
    header = parse_snapshot_header(text)

    taken = header["snapshot_taken"]
    if not taken:
        errors.append(
            "snapshot is missing its '<!-- snapshot taken: ... -->' header, so nothing "
            "records when this brand state was frozen"
        )
    elif ISO_INSTANT_RE.match(taken):
        pass
    elif ISO_DATE_RE.match(taken):
        warnings.append(
            f"snapshot taken '{taken}' is a date with no time; a full UTC instant "
            f"(YYYY-MM-DDThh:mm:ssZ) is what makes two runs on one day distinguishable"
        )
    else:
        errors.append(
            f"snapshot taken '{taken}' is not ISO-8601; expected YYYY-MM-DDThh:mm:ssZ"
        )

    if not header["source"]:
        errors.append(
            "snapshot is missing its '<!-- source: ... -->' header, so nothing records "
            "which brand-pack it was copied from"
        )

    return errors, warnings


def validate_brand_lock(
    path: Path, snapshot: bool = False, require_configured: bool = False
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    if not path.exists():
        return ([f"file does not exist: {path}"], [])

    text = path.read_text(encoding="utf-8")
    errors = check_structure(text)
    warnings = check_roles(text) + check_typography(text)

    unconfigured = is_unconfigured(text)
    if unconfigured:
        if require_configured or snapshot:
            errors.append(
                "palette still contains template placeholders (#______), so this is an "
                "unfilled template rather than a real brand-lock"
            )
        else:
            warnings.append(
                "palette contains template placeholders (#______); fine for a template, "
                "not for production work"
            )

    if snapshot:
        snap_errors, snap_warnings = check_snapshot(text)
        errors += snap_errors
        warnings += snap_warnings

    return (errors, warnings)


def selftest() -> int:
    ok = True
    minimal = "\n".join(
        [
            "## Identity",
            "**Brand:** X",
            "**One-line description:** Y",
            "**Archetype:** Operator",
            "**Voice posture:** Calm",
            "## Palette",
            "| Role | Hex | Use |",
            "|---|---|---|",
            "| Background | `#FFFFFF` | canvas |",
            "| Ink | `#000000` | text |",
            "| Accent | `#FF0000` | pop |",
            "| Muted | `#888888` | captions |",
            "| Rule | `#EEEEEE` | borders |",
            "## Typography",
            "**Display font:** `Inter Black 900`, headlines",
            "**Body font:** `Inter Medium 500`, body",
            "## Mood adjectives",
            "## Never list",
            "## Aspect ratios",
            "## Color grade direction",
            "## Motion language",
            "## Voice rules",
        ]
    )

    cases = [
        ("a complete brand-lock passes", minimal, {}, False),
        (
            "a snapshot with no header is rejected",
            minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot with a full instant header passes",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            False,
        ),
        (
            "a snapshot with a malformed date is rejected",
            "<!-- snapshot taken: last Tuesday -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot missing its source header is rejected",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "placeholders pass as a template",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {},
            False,
        ),
        (
            "placeholders fail under --require-configured",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {"require_configured": True},
            True,
        ),
        (
            "a missing section is caught",
            minimal.replace("## Voice rules", ""),
            {},
            True,
        ),
    ]

    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        for i, (label, text, kwargs, should_fail) in enumerate(cases):
            path = Path(tmp) / f"case-{i}.md"
            path.write_text(text, encoding="utf-8")
            errors, _ = validate_brand_lock(path, **kwargs)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        warn_path = Path(tmp) / "warn.md"
        warn_path.write_text(
            minimal.replace("| Muted | `#888888` | captions |", ""), encoding="utf-8"
        )
        _, warnings = validate_brand_lock(warn_path)
        if any("no 'muted' role" in w for w in warnings):
            print("  ok    selftest: a missing palette role warns")
        else:
            print(f"  FAIL  selftest: expected a muted-role warning, got {warnings}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_brand_lock.py <path-to-brand-lock.md> [...]")
        print("       python tools/validate_brand_lock.py --snapshot <snapshot.md>")
        print("       python tools/validate_brand_lock.py --require-configured <file>")
        print("       python tools/validate_brand_lock.py --snapshots")
        print("       python tools/validate_brand_lock.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    snapshot = "--snapshot" in args or "--snapshots" in args
    require_configured = "--require-configured" in args

    if "--snapshots" in args:
        paths = sorted(REPO_ROOT.rglob("brand-lock.snapshot.md"))
        if not paths:
            print("ERROR: no brand-lock.snapshot.md files found in the repo")
            return 1
    else:
        paths = [Path(a) for a in args if not a.startswith("--")]
        if not paths:
            print("ERROR: no brand-lock files given")
            return 2

    label = "snapshot" if snapshot else "brand-lock"
    print(f"Validating {len(paths)} {label} file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_brand_lock(path, snapshot, require_configured)
        try:
            shown = path.relative_to(REPO_ROOT)
        except ValueError:
            shown = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {shown}: {warn}")

    print()
    if total_errors == 0:
        print(f"All {label} files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across {label} files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/validate_brand_lock.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/validate_capabilities.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/validate_capabilities.py`

#!/usr/bin/env python3
"""
Validate the generator capability matrix and the adapter prose that defers to it.

_capabilities.json is declared the single source of truth for per-generator limits,
and every adapter .md repeats that rule at the top. A rule nothing checks is a
suggestion: the matrix and the prose drifted in three places before this file grew
the parity checks below.

Five checks:
  1. _capabilities.json validates against capabilities.schema.json.
  2. File parity: every generator id has an adapter .md and every adapter .md has a
     generator entry. Non-adapter markdown is skipped by name, not treated as an
     adapter with a missing entry.
  3. Prose parity: the word budget an adapter .md advertises must fit inside that
     generator's max_prompt_words, and the .md must mention the aspect_param the
     matrix says to send. A generator whose documented parameter name disagrees with
     the matrix will be called with the wrong one, because the matrix wins.
  4. Self-consistency: a notes field must not cite a word count above its own
     max_prompt_words.
  5. Staleness: warns when the matrix or an entry is past the freshness window.

Run from repo root:
    python tools/validate_capabilities.py
    python tools/validate_capabilities.py --selftest
"""

from __future__ import annotations

import re
import sys
from datetime import date

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, load_json

ADAPTERS_DIR = REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters"
CAPS = ADAPTERS_DIR / "_capabilities.json"
CAPS_SCHEMA = ADAPTERS_DIR / "capabilities.schema.json"

# Re-verify the matrix at least this often. Generator models change monthly.
STALE_AFTER_DAYS = 120

# Markdown in adapters/ that documents the directory rather than a generator.
NON_ADAPTER_STEMS = {"README", "_README"}

# "**80-150 words**", "**40-80 words per prompt**", en dash or hyphen.
WORD_RANGE_RE = re.compile(r"\*\*\s*(\d+)\s*[-–—]\s*(\d+)\s+words[^*]*\*\*")
# "**up to 150 words**" or "**150 words**"
WORD_SINGLE_RE = re.compile(r"\*\*\s*(?:up to\s+)?(\d+)\s+words[^*]*\*\*")
# A bare word count inside a notes string, e.g. "Over 100 words underperforms."
NOTES_WORD_RE = re.compile(r"(\d+)\s+words")


def _parse_date(value: str) -> date | None:
    try:
        y, m, d = (int(p) for p in value.split("-"))
        return date(y, m, d)
    except (ValueError, AttributeError):
        return None


def adapter_word_bound(text: str) -> int | None:
    """Highest word count the adapter prose advertises, or None if it names none."""
    bounds: list[int] = []
    for m in WORD_RANGE_RE.finditer(text):
        bounds.append(max(int(m.group(1)), int(m.group(2))))
    if not bounds:
        for m in WORD_SINGLE_RE.finditer(text):
            bounds.append(int(m.group(1)))
    return max(bounds) if bounds else None


def check_prose_parity(entry: dict, text: str) -> tuple[list[str], list[str]]:
    """Compare one adapter .md against its capability entry."""
    errors: list[str] = []
    warnings: list[str] = []
    gid = entry["id"]

    bound = adapter_word_bound(text)
    if bound is None:
        warnings.append(
            f"prose: '{gid}.md' advertises no word budget, so the matrix value "
            f"({entry['max_prompt_words']}) is the only guidance a reader gets"
        )
    elif bound > entry["max_prompt_words"]:
        errors.append(
            f"prose: '{gid}.md' advertises up to {bound} words but the matrix caps "
            f"max_prompt_words at {entry['max_prompt_words']}"
        )

    aspect = entry["aspect_param"]
    if aspect not in text:
        errors.append(
            f"prose: '{gid}.md' never mentions aspect_param '{aspect}'. The matrix "
            f"wins, so the forge will send a parameter the adapter does not document"
        )

    notes = entry.get("notes") or ""
    for m in NOTES_WORD_RE.finditer(notes):
        cited = int(m.group(1))
        if cited > entry["max_prompt_words"]:
            warnings.append(
                f"self-consistency: '{gid}' notes cite {cited} words but "
                f"max_prompt_words is {entry['max_prompt_words']}"
            )

    return errors, warnings


def validate(today: date | None = None) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    errors: list[str] = []
    warnings: list[str] = []
    today = today or date.today()

    if not CAPS.exists():
        return ([f"missing {CAPS.relative_to(REPO_ROOT)}"], warnings)
    if not CAPS_SCHEMA.exists():
        return ([f"missing {CAPS_SCHEMA.relative_to(REPO_ROOT)}"], warnings)

    caps, caps_err = load_json(CAPS)
    if caps_err:
        return ([f"_capabilities.json: {caps_err}"], warnings)
    schema, schema_err = load_json(CAPS_SCHEMA)
    if schema_err:
        return ([f"capabilities.schema.json: {schema_err}"], warnings)

    # 1. Schema validation
    validator = Draft202012Validator(schema)
    for err in sorted(validator.iter_errors(caps), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # structure-dependent checks need a valid shape

    entries = {g["id"]: g for g in caps["generators"]}
    cap_ids = set(entries)
    md_ids = {
        p.stem
        for p in ADAPTERS_DIR.glob("*.md")
        if p.stem not in NON_ADAPTER_STEMS
    }

    # 2. File parity
    for missing_md in sorted(cap_ids - md_ids):
        errors.append(
            f"parity: capability id '{missing_md}' has no adapter file {missing_md}.md"
        )
    for missing_cap in sorted(md_ids - cap_ids):
        errors.append(
            f"parity: adapter '{missing_cap}.md' has no entry in _capabilities.json"
        )

    # 3 and 4. Prose parity and self-consistency
    for gid in sorted(cap_ids & md_ids):
        text = (ADAPTERS_DIR / f"{gid}.md").read_text(encoding="utf-8")
        prose_errors, prose_warnings = check_prose_parity(entries[gid], text)
        errors.extend(prose_errors)
        warnings.extend(prose_warnings)

    # 5. Staleness
    reviewed = _parse_date(caps.get("matrix_last_reviewed", ""))
    if reviewed is None:
        warnings.append("matrix_last_reviewed is not a parseable date")
    elif (today - reviewed).days > STALE_AFTER_DAYS:
        warnings.append(
            f"matrix_last_reviewed is {(today - reviewed).days} days old "
            f"(> {STALE_AFTER_DAYS}); re-verify the matrix"
        )
    for g in caps["generators"]:
        lv = _parse_date(g.get("last_verified", ""))
        if lv is not None and (today - lv).days > STALE_AFTER_DAYS:
            warnings.append(
                f"'{g['id']}' last_verified is {(today - lv).days} days old "
                f"(> {STALE_AFTER_DAYS}); re-verify this generator"
            )

    return (errors, warnings)


def selftest() -> int:
    ok = True

    cases = [
        (
            "prose advertising more words than the cap is caught",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-300 words** comfortably. Pass `size` alongside.",
            True,
        ),
        (
            "prose inside the cap passes",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-250 words** comfortably. Pass `size` alongside.",
            False,
        ),
        (
            "an undocumented aspect_param is caught",
            {
                "id": "x",
                "max_prompt_words": 120,
                "aspect_param": "aspect_ratio",
                "notes": "",
            },
            "Handles **60-120 words**. Pass `aspectRatio` as a parameter.",
            True,
        ),
        (
            "en dash ranges parse",
            {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": ""},
            "Aim for **40–80 words per prompt** including `--ar`.",
            False,
        ),
    ]
    for label, entry, text, should_error in cases:
        errors, _ = check_prose_parity(entry, text)
        if bool(errors) == should_error:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
            ok = False

    entry = {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": "Over 100 words underperforms."}
    _, warnings = check_prose_parity(entry, "Aim for **40-80 words** with `--ar`.")
    if any("self-consistency" in w for w in warnings):
        print("  ok    selftest: notes citing more words than the cap are flagged")
    else:
        print(f"  FAIL  selftest: expected a self-consistency warning, got {warnings}")
        ok = False

    if adapter_word_bound("no budget stated here") is None:
        print("  ok    selftest: prose with no word budget reports none")
    else:
        print("  FAIL  selftest: found a word budget where there is none")
        ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    if "--selftest" in sys.argv[1:]:
        return selftest()

    print(f"Validating capability matrix: {CAPS.relative_to(REPO_ROOT)}")
    print()

    errors, warnings = validate()

    for w in warnings:
        print(f"  warn  {w}")
    if warnings:
        print()

    if not errors:
        caps, _ = load_json(CAPS)
        count = len((caps or {}).get("generators", []))
        print(f"Capability matrix valid ({count} generators, {len(warnings)} warning(s)).")
        return 0

    for e in errors:
        print(f"  FAIL  {e}")
    print()
    print(f"FAILED: {len(errors)} error(s) in capability matrix.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/validate_capabilities.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/validate_critique.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/validate_critique.py`

#!/usr/bin/env python3
"""
Validate critique.json files against the critique schema AND the gating invariant.

Schema validation alone is not enough: JSON Schema cannot express the cross-field
rules that make a verdict trustworthy. This validator adds them.

Gating invariant (the reason structured output exists):
  - Any 'blocking' issue      => verdict MUST be REJECT.
  - Three or more 'major'     => verdict MUST be REJECT.
  - One or two 'major'        => verdict MUST NOT be ACCEPT (caps at REVISE).
  - Therefore ACCEPT requires zero major/blocking issues.

Provenance invariant (version 1.1 and later):
  - A hash without its path, or a path without its hash, is not a reference.
  - image_ref must be present and non-null: a verdict about no image is not a verdict.
  - HIGH confidence requires the shot spec, the brand-lock, and the prompt to all be
    identified. The critic's own rubric says HIGH means all three were available.
  - generator, when named, must be an id in the capability matrix.

A critique that claims ACCEPT while carrying a blocking issue passes the schema but
FAILS here. So does a 1.1 critique that records an image hash and no image path.

Usage:
    python tools/validate_critique.py path/to/critique.json [...]
    python tools/validate_critique.py path/to/output-dir      # every critique in the tree
    python tools/validate_critique.py --examples              # bundled fixtures
    python tools/validate_critique.py --selftest              # prove the gates fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, capability_ids, critique_paths, load_json

SCHEMA_PATH = (
    REPO_ROOT / "skills" / "visual-asset-critic" / "templates" / "critique.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "visual-asset-critic" / "examples"

MAJOR_REJECT_THRESHOLD = 3

# Pairs that must be present or absent together.
REF_HASH_PAIRS = (
    ("image_ref", "image_sha256"),
    ("brand_lock_ref", "brand_lock_sha256"),
    ("prompt_ref", "prompt_sha256"),
)


def _load_schema() -> dict:
    data, err = load_json(SCHEMA_PATH)
    if err:
        raise RuntimeError(err)
    return data


def check_gating(data: dict) -> list[str]:
    """The severity-to-verdict invariant. Assumes data is schema-valid."""
    errors: list[str] = []
    verdict = data.get("verdict")
    severities = [issue.get("severity") for issue in data.get("issues", [])]
    majors = severities.count("major")

    if "blocking" in severities and verdict != "REJECT":
        errors.append(
            f"gating: a 'blocking' issue requires verdict REJECT, got '{verdict}'"
        )
    if majors >= MAJOR_REJECT_THRESHOLD and verdict != "REJECT":
        errors.append(
            f"gating: {majors} 'major' issues require verdict REJECT "
            f"(threshold {MAJOR_REJECT_THRESHOLD}), got '{verdict}'"
        )
    if majors and verdict == "ACCEPT":
        errors.append(
            "gating: a 'major' issue caps the verdict at REVISE; ACCEPT is not allowed"
        )
    return errors


def check_provenance(data: dict, known_generators: set[str]) -> list[str]:
    """The provenance invariant. Only applies from version 1.1."""
    errors: list[str] = []
    if data.get("version") == "1.0":
        return errors

    for ref_key, hash_key in REF_HASH_PAIRS:
        ref, digest = data.get(ref_key), data.get(hash_key)
        if ref and not digest:
            errors.append(f"provenance: {ref_key} is set but {hash_key} is null")
        if digest and not ref:
            errors.append(f"provenance: {hash_key} is set but {ref_key} is null")

    if not data.get("image_ref"):
        errors.append(
            "provenance: image_ref is null; a verdict that names no image cannot be audited"
        )

    if data.get("confidence") == "HIGH":
        missing = [
            key
            for key in ("shot_id", "brand_lock_ref", "prompt_ref")
            if not data.get(key)
        ]
        if missing:
            errors.append(
                "provenance: confidence HIGH requires "
                + ", ".join(missing)
                + " to be identified"
            )

    generator = data.get("generator")
    if generator and known_generators and generator not in known_generators:
        errors.append(
            f"provenance: generator '{generator}' is not an id in the capability matrix"
        )

    return errors


def validate_doc(
    data: dict,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes every gate."""
    errors: list[str] = []
    warnings: list[str] = []

    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # the gates assume a schema-valid shape

    errors += check_gating(data)
    errors += check_provenance(data, known_generators or set())

    if data.get("version") == "1.0":
        warnings.append(
            "version 1.0 carries no run id, no round, and no content hashes, so the "
            "verdict cannot be tied to the bytes it reviewed; re-emit as 1.1"
        )

    return (errors, warnings)


def validate_path(
    path: Path,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    data, err = load_json(path)
    if err:
        return ([err], [])
    if not isinstance(data, dict):
        return ([f"top level is not an object: {path}"], [])
    return validate_doc(data, validator, known_generators)


def _selftest_cases() -> list[tuple[str, dict, bool]]:
    """(label, document, should_pass)."""
    base_provenance = {
        "run_id": "20260730T142300Z-9f2c1ab4",
        "round": 1,
        "created_at": "2026-07-30T14:31:00Z",
        "shot_id": "shot_03",
        "brand_lock_ref": "brand-lock.snapshot.md",
        "brand_lock_sha256": "a" * 64,
        "image_ref": "frames/round-1/shot_03.png",
        "image_sha256": "b" * 64,
        "prompt_ref": "prompts/round-1/flux.txt",
        "prompt_sha256": "c" * 64,
        "generator": "flux",
        "model_version": "2 Pro",
        "seed": 12345,
    }
    major_issue = {
        "layer": "Series Lock",
        "severity": "major",
        "note": "hair mismatch",
        "fix_type": "prompt-level",
        "fix": "add 'salt-and-pepper hair' to the anchor",
    }
    blocking_issue = {
        "layer": "Brand Lock",
        "severity": "blocking",
        "note": "off-palette",
        "fix_type": "re-roll",
        "fix": "re-roll with palette anchor",
    }

    def doc(**overrides) -> dict:
        out = {
            "version": "1.1",
            **base_provenance,
            "verdict": "REVISE",
            "confidence": "HIGH",
            "issues": [dict(major_issue)],
        }
        out.update(overrides)
        return out

    return [
        ("clean REVISE with full provenance passes", doc(), True),
        (
            "legacy 1.0 document still validates",
            {
                "version": "1.0",
                "verdict": "REVISE",
                "confidence": "HIGH",
                "issues": [dict(major_issue)],
            },
            True,
        ),
        (
            "ACCEPT with a blocking issue is rejected",
            doc(verdict="ACCEPT", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "REVISE with a blocking issue is rejected",
            doc(verdict="REVISE", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "ACCEPT with a major issue is rejected",
            doc(verdict="ACCEPT"),
            False,
        ),
        (
            "three major issues cannot stay at REVISE",
            doc(verdict="REVISE", issues=[dict(major_issue) for _ in range(3)]),
            False,
        ),
        (
            "three major issues at REJECT pass",
            doc(verdict="REJECT", issues=[dict(major_issue) for _ in range(3)]),
            True,
        ),
        (
            "1.1 with a hash and no path is rejected",
            doc(prompt_ref=None),
            False,
        ),
        (
            "1.1 with a path and no hash is rejected",
            doc(prompt_sha256=None),
            False,
        ),
        (
            "1.1 with no image_ref is rejected",
            doc(image_ref=None, image_sha256=None),
            False,
        ),
        (
            "HIGH confidence with no prompt identified is rejected",
            doc(prompt_ref=None, prompt_sha256=None),
            False,
        ),
        (
            "MEDIUM confidence with no prompt identified passes",
            doc(confidence="MEDIUM", prompt_ref=None, prompt_sha256=None),
            True,
        ),
        (
            "unknown generator id is rejected",
            doc(generator="runway-sora"),
            False,
        ),
        (
            "1.1 missing a required provenance field is rejected",
            {
                "version": "1.1",
                "verdict": "ACCEPT",
                "confidence": "LOW",
                "issues": [],
            },
            False,
        ),
    ]


def selftest() -> int:
    validator = Draft202012Validator(_load_schema())
    known = capability_ids() or {"flux"}
    ok = True

    for label, document, should_pass in _selftest_cases():
        errors, _ = validate_doc(document, validator, known)
        passed = not errors
        if passed == should_pass:
            print(f"  ok    selftest: {label}")
        else:
            detail = errors if errors else ["(no errors raised)"]
            print(f"  FAIL  selftest: {label} -> {detail}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def _collect(args: list[str]) -> list[Path] | None:
    if "--examples" in args:
        found = sorted(EXAMPLES_DIR.glob("*.json"))
        found += critique_paths(EXAMPLES_DIR / "worked-run")
        return found or None

    paths: list[Path] = []
    for raw in args:
        path = Path(raw)
        if path.is_dir():
            found = critique_paths(path)
            if not found:
                print(f"  FAIL  {raw}")
                print("        - no critique files found in this output tree")
                return None
            paths.extend(found)
        else:
            paths.append(path)
    return paths


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_critique.py <critique.json|output-dir> [...]")
        print("       python tools/validate_critique.py --examples")
        print("       python tools/validate_critique.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    if not SCHEMA_PATH.exists():
        print(f"ERROR: schema not found at {SCHEMA_PATH}")
        return 1

    paths = _collect(args)
    if paths is None:
        return 1

    validator = Draft202012Validator(_load_schema())
    known = capability_ids()

    print(f"Validating {len(paths)} critique file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_path(path, validator, known)
        try:
            label = path.relative_to(REPO_ROOT)
        except ValueError:
            label = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {label}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {label}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {label}: {warn}")

    print()
    if total_errors == 0:
        print(f"All critiques valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across critiques.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/validate_critique.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/validate_prompts.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/validate_prompts.py`

#!/usr/bin/env python3
"""
Validate the prompt files visual-prompt-forge writes.

The forge documents four hard rules and a quality-bar checklist, and until this file
existed every one of them was enforced by a model remembering to check its own work.
That is not a small gap. Rule 3, series_lock anchors appear verbatim in every prompt,
is the rule that produces visual consistency across a series, and it is also the
easiest one in the kit to break by paraphrasing while writing fluent prose. A careful
pass over a seven-shot storyboard drifted on it seven times out of seven with every
other validator green.

Checks:
  1. The header block names the storyboard, generator, aspect, brand-lock, run, round.
  2. The generator is an id in the capability matrix.
  3. The header aspect matches project.aspect in shots.json.
  4. No shot's prompt exceeds that generator's max_prompt_words ceiling.
  5. Every shot block names a shot that exists. A full pass covers every shot; a
     revision file covers a subset.
  6. Rule 1: no on-screen text content appears in any prompt. Text is composited.
  7. Rule 3: series_lock environment, lighting, and color_grade appear verbatim.
     The character anchor is a warning, because a shot with no person in it can
     legitimately omit it.
  8. No duplicate shot blocks in one file.

Usage:
    python tools/validate_prompts.py <output-dir>
    python tools/validate_prompts.py <output-dir>/prompts/round-1/flux.txt
    python tools/validate_prompts.py --examples
    python tools/validate_prompts.py --selftest
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from _shotkit import REPO_ROOT, capability_map, load_json

WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"

SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT = re.compile(r"^\s*#")

HEADER_FIELDS = ("Storyboard", "Generator", "Aspect", "Brand-lock", "Run", "Round")

# series_lock keys that describe every frame, so every prompt has to carry them.
UNIVERSAL_ANCHORS = ("environment", "lighting", "color_grade")


def parse_blocks(text: str) -> tuple[dict[str, str], list[tuple[str, str]]]:
    """Return (header fields, [(shot_id, prompt body)])."""
    header: dict[str, str] = {}
    blocks: list[tuple[str, list[str]]] = []
    current: list[str] | None = None

    for line in text.splitlines():
        m = SHOT_HEADER.match(line)
        if m:
            current = []
            blocks.append((m.group(1), current))
            continue
        if current is None:
            hm = re.match(r"^#\s*([A-Za-z-]+)\s*:\s*(.+?)\s*$", line)
            if hm:
                header[hm.group(1).strip()] = hm.group(2).strip()
            continue
        if not COMMENT.match(line):
            current.append(line)

    return (header, [(sid, "\n".join(b).strip()) for sid, b in blocks])


def check_file(
    path: Path, shots_data: dict, caps: dict[str, dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    label = path.name

    text = path.read_text(encoding="utf-8")
    header, blocks = parse_blocks(text)

    if not blocks:
        return ([f"{label}: no shot blocks found; expected '# shot_NN, ...' lines"], warnings)

    for field in HEADER_FIELDS:
        if field not in header:
            warnings.append(f"{label}: header is missing '# {field}:'")

    generator = header.get("Generator", "").split()[0] if header.get("Generator") else None
    entry = caps.get(generator) if generator else None
    if generator and entry is None:
        errors.append(
            f"{label}: header names generator '{generator}', which is not an id in "
            f"_capabilities.json"
        )
    if generator is None:
        # Fall back to the filename: flux.txt or revised-flux.txt
        stem = path.stem.replace("revised-", "")
        entry = caps.get(stem)
        if entry:
            warnings.append(
                f"{label}: no '# Generator:' header, inferred '{stem}' from the filename"
            )

    project = shots_data.get("project", {})
    if "Aspect" in header and header["Aspect"] != project.get("aspect"):
        errors.append(
            f"{label}: header aspect '{header['Aspect']}' does not match "
            f"project.aspect '{project.get('aspect')}'"
        )

    shot_ids = [s["id"] for s in shots_data.get("shots", [])]
    by_id = {s["id"]: s for s in shots_data.get("shots", [])}
    series = shots_data.get("series_lock", {})

    seen: set[str] = set()
    for sid, body in blocks:
        if sid in seen:
            errors.append(f"{label}: {sid} appears in more than one block")
        seen.add(sid)
        if sid not in by_id:
            errors.append(f"{label}: names {sid}, which is not in shots.json")
            continue
        if not body:
            errors.append(f"{label}: {sid} has a header but no prompt body")
            continue

        if entry:
            words = len(body.split())
            ceiling = entry["max_prompt_words"]
            if words > ceiling:
                errors.append(
                    f"{label}: {sid} is {words} words, over the "
                    f"{entry['id']} ceiling of {ceiling}"
                )

        low = body.lower()
        for key in UNIVERSAL_ANCHORS:
            value = series.get(key)
            if value and value.lower() not in low:
                errors.append(
                    f"{label}: {sid} does not carry the series_lock {key} verbatim. "
                    f"Paraphrasing an anchor is what makes shots stop matching each other"
                )
        character = series.get("character")
        if character and character.lower() not in low:
            warnings.append(
                f"{label}: {sid} does not carry the series_lock character verbatim; "
                f"correct only if this shot has no person in it"
            )

    # Rule 1: text is composited, never described.
    overlays_path = path.parent.parent.parent / "text-overlays.json"
    overlays_data, ov_err = load_json(overlays_path)
    if not ov_err and isinstance(overlays_data, dict):
        for overlay in overlays_data.get("overlays", []):
            content = overlay.get("content")
            if not isinstance(content, str) or len(content) < 8:
                continue
            needle = content.lower().rstrip(".!?")
            for sid, body in blocks:
                if needle in body.lower():
                    errors.append(
                        f"{label}: {sid} contains the copy of overlay "
                        f"{overlay.get('id')} verbatim. On-screen text is composited, "
                        f"never put in an image prompt"
                    )

    is_revision = path.name.startswith("revised-")
    if not is_revision:
        for missing in [s for s in shot_ids if s not in seen]:
            errors.append(f"{label}: full pass is missing a block for {missing}")

    return (errors, warnings)


def collect_prompt_files(target: Path) -> tuple[Path | None, list[Path]]:
    """Return (output_dir, prompt files). Accepts an output dir or a single file."""
    if target.is_file():
        # prompts/round-N/<file>.txt  ->  output dir is three levels up
        return (target.parent.parent.parent, [target])
    if target.is_dir():
        found = sorted(target.glob("prompts/round-*/*.txt"))
        if not found:
            found = sorted(target.glob("prompts/*.txt"))  # pre-3.0.0 flat layout
        return (target, found)
    return (None, [])


def validate_target(target: Path) -> tuple[list[str], list[str]]:
    out_dir, files = collect_prompt_files(target)
    if out_dir is None:
        return ([f"not a file or directory: {target}"], [])
    if not files:
        return ([f"no prompt files found under {target}"], [])

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        return ([f"cannot read shots.json next to the prompts: {err}"], [])

    caps = capability_map()
    errors: list[str] = []
    warnings: list[str] = []
    for path in files:
        e, w = check_file(path, shots_data, caps)
        errors += e
        warnings += w
    return (errors, warnings)


SHOTS_FIXTURE = {
    "project": {"aspect": "9:16"},
    "series_lock": {
        "character": "founder in a navy crewneck",
        "environment": "minimalist home office, oak desk",
        "lighting": "soft window light from camera-left",
        "color_grade": "warm filmic with muted teal shadows",
    },
    "shots": [{"id": "shot_01"}, {"id": "shot_02"}],
}


def _fixture(body_01: str, body_02: str | None = None, aspect: str = "9:16") -> str:
    out = [
        "# Storyboard: Fixture",
        "# Generator: flux",
        f"# Aspect: {aspect}",
        "# Brand-lock: brand-lock.snapshot.md",
        "# Run: 20260730T180000Z-7c41e0a9",
        "# Round: 1",
        "",
        "# shot_01, hook, 0.0-2.0s, MCU eye-level static",
        body_01,
        "",
    ]
    if body_02 is not None:
        out += ["# shot_02, pain, 2.0-6.0s, MS eye-level push", body_02, ""]
    return "\n".join(out)


def selftest() -> int:
    import tempfile

    ok = True
    sl = SHOTS_FIXTURE["series_lock"]
    good = (
        f"Medium close-up of a {sl['character']}. {sl['environment']}. "
        f"{sl['lighting']}. {sl['color_grade']}. Photorealistic."
    )
    drifted = (
        "Medium close-up of a founder in a navy sweater. A minimal home office with "
        "an oak desk. Soft light from the left. Warm grade with teal shadows."
    )

    cases = [
        ("a compliant full pass passes", _fixture(good, good), False),
        ("a paraphrased anchor is caught", _fixture(drifted, good), True),
        ("a missing shot in a full pass is caught", _fixture(good), True),
        ("an aspect mismatch is caught", _fixture(good, good, aspect="16:9"), True),
        (
            "an over-ceiling prompt is caught",
            _fixture(good + " extra" * 200, good),
            True,
        ),
        (
            "an unknown shot id is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_09,"),
            True,
        ),
        (
            "a duplicate shot block is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_01,"),
            True,
        ),
        (
            "an empty prompt body is caught",
            _fixture(good, ""),
            True,
        ),
    ]

    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "output"
        (out / "prompts" / "round-1").mkdir(parents=True)
        (out / "shots.json").write_text(json.dumps(SHOTS_FIXTURE))
        caps = capability_map()
        for label, text, should_fail in cases:
            p = out / "prompts" / "round-1" / "flux.txt"
            p.write_text(text)
            errors, _ = check_file(p, SHOTS_FIXTURE, caps)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        # Rule 1: overlay copy leaking into a prompt.
        (out / "text-overlays.json").write_text(
            json.dumps(
                {
                    "version": "1.0",
                    "overlays": [
                        {"id": "text_01", "content": "You are the bottleneck."}
                    ],
                }
            )
        )
        p = out / "prompts" / "round-1" / "flux.txt"
        p.write_text(_fixture(good + " The words You are the bottleneck appear.", good))
        errors, _ = check_file(p, SHOTS_FIXTURE, caps)
        if any("composited" in e for e in errors):
            print("  ok    selftest: overlay copy inside a prompt is caught")
        else:
            print(f"  FAIL  selftest: overlay leak not caught -> {errors}")
            ok = False

        # A revision file covers a subset, and that is not an error.
        rev = out / "prompts" / "round-2"
        rev.mkdir()
        rp = rev / "revised-flux.txt"
        rp.write_text(_fixture(good))
        errors, _ = check_file(rp, SHOTS_FIXTURE, caps)
        if not errors:
            print("  ok    selftest: a revision file may cover a subset of shots")
        else:
            print(f"  FAIL  selftest: revision subset flagged -> {errors}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_prompts.py <output-dir|prompt-file> [...]")
        print("       python tools/validate_prompts.py --examples")
        print("       python tools/validate_prompts.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    targets = [WORKED_RUN] if "--examples" in args else [Path(a) for a in args]

    print(f"Validating prompt files for {len(targets)} target(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for target in targets:
        errors, warnings = validate_target(target)
        try:
            shown = target.relative_to(REPO_ROOT)
        except ValueError:
            shown = target
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for e in errors:
                print(f"        - {e}")
        for w in warnings:
            print(f"  warn  {shown}: {w}")

    print()
    if total_errors == 0:
        print(f"All prompt files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across prompt files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/validate_prompts.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/validate_provenance.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/validate_provenance.py`

#!/usr/bin/env python3
"""
Validate the provenance chain of a shotkit output tree.

This is the tool that answers "does this verdict still describe the file it reviewed."
Paths lie: a filename says nothing about the bytes behind it, so a frame regenerated
after its critique leaves every path reference intact and every claim about it wrong.
Content hashes are what make that detectable, and this walks them.

Checks:
  1. run.json validates against run.schema.json, and its run_id agrees with created_at.
  2. Rounds are numbered from 1 with no gaps and no duplicates.
  3. Every input hash in run.json still matches the file on disk. A brand-lock edited
     mid-project fails here instead of silently repointing the project's history.
  4. Every prompt hash recorded in run.json still matches the file on disk.
  5. Every critique validates against the schema and the gating invariant.
  6. Every critique's run_id matches run.json.
  7. Every critique's image, prompt, and brand-lock hashes match the files on disk.
  8. No two critiques cover the same shot in the same round. Two operators writing the
     same verdict path is a real conflict, not a silent overwrite.
  9. Every frame on disk has a critique for its round. An unreviewed frame is the
     failure mode where a re-roll slips past the gate on a stale ACCEPT.
 10. Every shot has at least one critique, and the latest verdict per shot is reported.
 11. Shots recorded as post_only still owe compositing work.

Exit status is 0 when the chain is intact. Add --require-accept to also demand that
every shot's latest verdict is ACCEPT, which is the pipeline stop condition made
executable rather than described.

Usage:
    python tools/validate_provenance.py <output-dir> [...]
    python tools/validate_provenance.py <output-dir> --require-accept
    python tools/validate_provenance.py <output-dir> --json
    python tools/validate_provenance.py --examples
    python tools/validate_provenance.py --selftest
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    IMAGE_EXTS,
    REPO_ROOT,
    critique_paths,
    load_json,
    round_dirs,
    run_id_timestamp,
    sha256_file,
)
from validate_critique import _load_schema as _load_critique_schema
from validate_critique import validate_doc as validate_critique_doc

RUN_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "run.schema.json"
)
WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"


class Report:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.shots: dict[str, dict] = {}
        self.rounds_seen: list[int] = []
        # (path, recorded, actual) -> the labels that referenced it. One edited file is
        # one problem, even when twenty critiques all hash it.
        self.hash_failures: dict[tuple[str, str, str], list[str]] = {}

    def as_dict(self) -> dict:
        return {
            "output_dir": str(self.output_dir),
            "ok": not self.errors,
            "errors": self.errors,
            "warnings": self.warnings,
            "rounds": self.rounds_seen,
            "shots": self.shots,
        }


def _check_hash(
    report: Report, label: str, rel: str | None, expected: str | None
) -> None:
    """Compare a recorded hash against the file currently on disk."""
    if not rel or not expected:
        return
    path = report.output_dir / rel
    if not path.exists():
        report.errors.append(f"{label}: '{rel}' is referenced but missing on disk")
        return
    actual = sha256_file(path)
    if actual == expected:
        return
    report.hash_failures.setdefault((rel, expected, actual), []).append(label)


def _finalize_hash_failures(report: Report) -> None:
    """Turn collected hash mismatches into one error per distinct mismatch."""
    for (rel, expected, actual), labels in report.hash_failures.items():
        # Print both hashes in full. Truncating them meant a single mistyped character
        # at the end produced a message showing two identical-looking strings and
        # asserting they differed, which is the least useful moment to be imprecise: a
        # hand-authored run.json is exactly where typos come from.
        detail = (
            f"'{rel}' does not match the hash recorded for it\n"
            f"          recorded: {expected}\n"
            f"          on disk:  {actual}"
        )
        if len(expected) != 64:
            detail += (
                f"\n          the recorded value is {len(expected)} characters, not 64, "
                f"so it is malformed rather than stale"
            )
        elif sum(a != b for a, b in zip(expected, actual)) <= 2:
            detail += (
                "\n          they differ in one or two characters, which usually means "
                "a typo in the recorded hash rather than a changed file"
            )
        if len(labels) == 1:
            detail += f"\n          referenced by: {labels[0]}"
        else:
            shown = ", ".join(labels[:3])
            more = f", and {len(labels) - 3} more" if len(labels) > 3 else ""
            detail += (
                f"\n          referenced by {len(labels)} places: {shown}{more}"
            )
        report.errors.append(detail)


def check_run_doc(report: Report) -> dict | None:
    run_path = report.output_dir / "run.json"
    if not run_path.exists():
        report.errors.append(
            "run.json is missing, so nothing pins this output to its inputs. A tree "
            "written before 3.0.0 has no provenance to check: write a run.json "
            "(schema at skills/storyboard-architect/templates/run.schema.json) or "
            "re-run storyboard-architect. This is reported as an error rather than a "
            "warning so a pipeline gate cannot pass an unauditable tree"
        )
        return None

    run_doc, err = load_json(run_path)
    if err:
        report.errors.append(f"run.json: {err}")
        return None

    schema, s_err = load_json(RUN_SCHEMA)
    if s_err:
        report.errors.append(f"run.schema.json: {s_err}")
        return None

    validator = Draft202012Validator(schema)
    for e in sorted(validator.iter_errors(run_doc), key=lambda x: list(x.path)):
        loc = "/".join(str(p) for p in e.path) or "(root)"
        report.errors.append(f"run.json schema: {loc}: {e.message}")
    if report.errors:
        return None

    stamp = run_id_timestamp(run_doc["run_id"])
    expected = run_doc["created_at"].replace("-", "").replace(":", "")
    if stamp != expected:
        report.errors.append(
            f"run.json: run_id timestamp '{stamp}' disagrees with "
            f"created_at '{run_doc['created_at']}'"
        )

    if run_doc["inputs"].get("brand_lock_configured") is False:
        report.warnings.append(
            "run.json: brand_lock_configured is false, so this run was built against "
            "an unfilled template rather than a real brand-lock"
        )

    inputs = run_doc["inputs"]
    _check_hash(report, "inputs", inputs.get("shots_ref"), inputs.get("shots_sha256"))
    _check_hash(
        report,
        "inputs",
        inputs.get("text_overlays_ref"),
        inputs.get("text_overlays_sha256"),
    )
    _check_hash(
        report, "inputs", inputs.get("brand_lock_ref"), inputs.get("brand_lock_sha256")
    )

    numbers = [r["round"] for r in run_doc.get("rounds", [])]
    report.rounds_seen = sorted(numbers)
    if len(numbers) != len(set(numbers)):
        report.errors.append("run.json: duplicate round numbers")
    if numbers and sorted(numbers) != list(range(1, max(numbers) + 1)):
        report.errors.append(
            f"run.json: rounds must run 1..N with no gaps, got {sorted(numbers)}"
        )

    for rnd in run_doc.get("rounds", []):
        for prompt in rnd.get("prompts", []):
            _check_hash(
                report,
                f"round {rnd['round']} prompt",
                prompt.get("ref"),
                prompt.get("sha256"),
            )
        for shot_id in rnd.get("post_only_shots", []) or []:
            report.warnings.append(
                f"round {rnd['round']}: {shot_id} is recorded as post-only, so it owes "
                f"compositing work that no prompt or frame will show"
            )

    return run_doc


def _round_of(path: Path, output_dir: Path, data: dict) -> int:
    """
    Which round a critique belongs to.

    The directory name wins, because that is the addressing scheme. A legacy critique
    sitting at the output root has no directory to read, so fall back to its own
    `round` field and then to 1.
    """
    try:
        parent = path.relative_to(output_dir).parent.name
    except ValueError:
        parent = ""
    if parent.startswith("round-") and parent[len("round-"):].isdigit():
        return int(parent[len("round-"):])
    declared = data.get("round")
    return declared if isinstance(declared, int) and declared >= 1 else 1


def check_critiques(report: Report, run_doc: dict | None) -> None:
    critique_validator = Draft202012Validator(_load_critique_schema())
    seen: dict[tuple[str, int], Path] = {}

    # critique_paths() is the one definition of "where critiques live", shared with
    # validate_critique.py and shots-to-html.py. Walking the round directories directly
    # meant this tool ignored a legacy root critique.json that the other two read, so
    # the preview showed a verdict badge for a shot this tool called unreviewed.
    for path in critique_paths(report.output_dir):
        try:
            rel = path.relative_to(report.output_dir)
        except ValueError:
            rel = path
        data, err = load_json(path)
        if err:
            report.errors.append(f"{rel}: {err}")
            continue
        if not isinstance(data, dict):
            report.errors.append(f"{rel}: top level is not an object")
            continue

        errors, warnings = validate_critique_doc(data, critique_validator)
        report.errors.extend(f"{rel}: {e}" for e in errors)
        report.warnings.extend(f"{rel}: {w}" for w in warnings)
        if errors:
            continue

        round_no = _round_of(path, report.output_dir, data)
        in_round_dir = rel.parent.name.startswith("round-")

        if in_round_dir and data.get("round") not in (None, round_no):
            report.errors.append(
                f"{rel}: declares round {data.get('round')} but sits in round-{round_no}/"
            )
        if run_doc and data.get("run_id") not in (None, run_doc["run_id"]):
            report.errors.append(
                f"{rel}: run_id '{data.get('run_id')}' does not match run.json "
                f"'{run_doc['run_id']}'"
            )

        shot_id = data.get("shot_id")
        if shot_id:
            key = (shot_id, round_no)
            if key in seen:
                report.errors.append(
                    f"{rel}: a second critique for {shot_id} in round {round_no} "
                    f"already exists at {seen[key]}; "
                    f"two operators reviewed the same shot in the same round"
                )
            else:
                seen[key] = rel

        _check_hash(report, f"{rel} image", data.get("image_ref"), data.get("image_sha256"))
        _check_hash(report, f"{rel} prompt", data.get("prompt_ref"), data.get("prompt_sha256"))
        _check_hash(
            report,
            f"{rel} brand-lock",
            data.get("brand_lock_ref"),
            data.get("brand_lock_sha256"),
        )

        if shot_id:
            entry = report.shots.setdefault(shot_id, {"rounds": {}})
            entry["rounds"][str(round_no)] = {
                "verdict": data.get("verdict"),
                "confidence": data.get("confidence"),
                "critique_ref": str(rel),
                "issues": len(data.get("issues", [])),
            }


def check_coverage(report: Report, run_doc: dict | None) -> None:
    shots_rel = "shots.json"
    if run_doc:
        shots_rel = run_doc["inputs"].get("shots_ref", "shots.json")
    shots_data, err = load_json(report.output_dir / shots_rel)
    shot_ids: list[str] = []
    if err:
        report.warnings.append(f"coverage: cannot read {shots_rel}, skipped ({err})")
    elif isinstance(shots_data, dict):
        shot_ids = [
            s["id"] for s in shots_data.get("shots", []) if isinstance(s.get("id"), str)
        ]

    reviewed_by_round: dict[int, set[str]] = {}
    for shot_id, entry in report.shots.items():
        for rnd in entry["rounds"]:
            reviewed_by_round.setdefault(int(rnd), set()).add(shot_id)

    for round_no, directory in round_dirs(report.output_dir, "frames"):
        reviewed = reviewed_by_round.get(round_no, set())
        for path in sorted(directory.iterdir()):
            if path.suffix.lstrip(".").lower() not in IMAGE_EXTS:
                continue
            frame_shot = path.stem
            if frame_shot not in reviewed:
                report.errors.append(
                    f"coverage: frames/round-{round_no}/{path.name} has no critique for "
                    f"round {round_no}; it was never reviewed"
                )

    for shot_id in shot_ids:
        entry = report.shots.get(shot_id)
        if not entry:
            report.warnings.append(
                f"coverage: {shot_id} has no critique in any round"
            )
            continue
        latest = max(int(r) for r in entry["rounds"])
        entry["latest_round"] = latest
        entry["latest_verdict"] = entry["rounds"][str(latest)]["verdict"]

    for shot_id in report.shots:
        if shot_ids and shot_id not in shot_ids:
            report.errors.append(
                f"coverage: a critique names {shot_id}, which is not in {shots_rel}"
            )


def validate_tree(output_dir: Path) -> Report:
    report = Report(output_dir)
    if not output_dir.is_dir():
        report.errors.append(f"not a directory: {output_dir}")
        return report
    run_doc = check_run_doc(report)
    check_critiques(report, run_doc)
    check_coverage(report, run_doc)
    _finalize_hash_failures(report)
    return report


def outstanding(report: Report) -> list[str]:
    """Shots whose latest verdict is not ACCEPT."""
    return sorted(
        shot_id
        for shot_id, entry in report.shots.items()
        if entry.get("latest_verdict") not in (None, "ACCEPT")
    )


def selftest() -> int:
    """Run the bundled worked example, then tamper with a copy and prove drift is caught."""
    import shutil
    import tempfile

    ok = True

    clean = validate_tree(WORKED_RUN)
    if clean.errors:
        print(f"  FAIL  selftest: the bundled worked run should be clean, got: {clean.errors}")
        ok = False
    else:
        print("  ok    selftest: the bundled worked run passes")

    if outstanding(clean):
        print(f"  FAIL  selftest: worked run should have no outstanding shots, got {outstanding(clean)}")
        ok = False
    else:
        print("  ok    selftest: every shot in the worked run ends on ACCEPT")

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        frame = scratch / "frames" / "round-2" / "shot_02.png"
        frame.write_bytes(frame.read_bytes() + b"\x00")
        report = validate_tree(scratch)
        if any("does not match the hash recorded" in e for e in report.errors):
            print("  ok    selftest: a frame regenerated after its critique is caught")
        else:
            print(f"  FAIL  selftest: frame tampering was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        lock = scratch / "brand-lock.snapshot.md"
        lock.write_text(lock.read_text() + "\n<!-- edited mid-project -->\n")
        report = validate_tree(scratch)
        if any("brand-lock.snapshot.md' does not match" in e for e in report.errors):
            print("  ok    selftest: a brand-lock edited mid-project is caught")
        else:
            print(f"  FAIL  selftest: brand-lock drift was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        src = scratch / "critiques" / "round-2" / "shot_02.critique.json"
        (scratch / "critiques" / "round-2" / "shot_02.operator-b.json").write_text(
            src.read_text()
        )
        report = validate_tree(scratch)
        if any("two operators reviewed the same shot" in e for e in report.errors):
            print("  ok    selftest: two critiques for one shot in one round is caught")
        else:
            print(f"  FAIL  selftest: duplicate critique was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        source = scratch / "frames" / "round-2" / "shot_02.png"
        (scratch / "frames" / "round-2" / "shot_01.png").write_bytes(source.read_bytes())
        report = validate_tree(scratch)
        if any("was never reviewed" in e for e in report.errors):
            print("  ok    selftest: a frame with no critique for its round is caught")
        else:
            print(f"  FAIL  selftest: unreviewed frame was not caught, got: {report.errors}")
            ok = False

    # A legacy tree keeps its critique at the output root. validate_critique.py and
    # shots-to-html.py both read it, so this tool has to as well: reporting a shot as
    # unreviewed while the preview shows its verdict badge is the exact kind of
    # disagreement between consumers that this release exists to remove.
    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "legacy"
        scratch.mkdir()
        shutil.copy(WORKED_RUN / "shots.json", scratch / "shots.json")
        shutil.copy(
            WORKED_RUN / "critiques" / "round-1" / "shot_01.critique.json",
            scratch / "critique.json",
        )
        report = validate_tree(scratch)
        if "shot_01" in report.shots:
            print("  ok    selftest: a legacy root critique.json is still discovered")
        else:
            print(
                "  FAIL  selftest: legacy root critique.json was ignored; "
                f"shots seen: {sorted(report.shots)}"
            )
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_provenance.py <output-dir> [...]")
        print("       python tools/validate_provenance.py <output-dir> --require-accept")
        print("       python tools/validate_provenance.py --examples")
        print("       python tools/validate_provenance.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    require_accept = "--require-accept" in args
    as_json = "--json" in args
    targets_raw = [a for a in args if not a.startswith("--")]

    if "--examples" in args:
        targets = [WORKED_RUN]
    elif targets_raw:
        targets = [Path(t) for t in targets_raw]
    else:
        print("ERROR: no output directory given")
        return 2

    reports = [validate_tree(t) for t in targets]

    if as_json:
        print(json.dumps([r.as_dict() for r in reports], indent=2))
    else:
        print(f"Validating provenance for {len(reports)} output tree(s)")
        print()
        for report in reports:
            try:
                label = report.output_dir.relative_to(REPO_ROOT)
            except ValueError:
                label = report.output_dir
            if report.errors:
                print(f"  FAIL  {label}")
                for err in report.errors:
                    print(f"        - {err}")
            else:
                print(f"  ok    {label}  ({len(report.shots)} shot(s), rounds {report.rounds_seen or 'none'})")
            for warn in report.warnings:
                print(f"  warn  {label}: {warn}")
            for shot_id in sorted(report.shots):
                entry = report.shots[shot_id]
                verdict = entry.get("latest_verdict", "?")
                print(
                    f"        {shot_id}: {verdict} "
                    f"(round {entry.get('latest_round', '?')})"
                )
        print()

    failed = any(r.errors for r in reports)
    unresolved = {
        str(r.output_dir): outstanding(r) for r in reports if outstanding(r)
    }

    if not as_json:
        if failed:
            total = sum(len(r.errors) for r in reports)
            print(f"FAILED: {total} provenance error(s).")
        elif require_accept and unresolved:
            for path, shots in unresolved.items():
                print(f"NOT DONE: {path} still has non-ACCEPT shots: {', '.join(shots)}")
        else:
            print("Provenance chain intact.")

    if failed:
        return 1
    if require_accept and unresolved:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/validate_provenance.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/validate_schemas.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/validate_schemas.py`

#!/usr/bin/env python3
"""
Validate that every *.schema.json file in the repo is itself valid JSON Schema.

Run from repo root:
    python tools/validate_schemas.py
"""

from __future__ import annotations
import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
    from jsonschema.exceptions import SchemaError
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install jsonschema")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent


def find_schema_files() -> list[Path]:
    """Find every *.schema.json file in the repo."""
    return sorted(REPO_ROOT.rglob("*.schema.json"))


def validate_schema_file(path: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        errors.append(f"invalid JSON: {e}")
        return errors

    try:
        Draft202012Validator.check_schema(data)
    except SchemaError as e:
        errors.append(f"invalid schema: {e.message}")

    if "$id" not in data:
        errors.append("missing '$id' field")
    if "title" not in data:
        errors.append("missing 'title' field")
    if "description" not in data:
        errors.append("missing 'description' field")

    return errors


def main() -> int:
    schemas = find_schema_files()
    if not schemas:
        print("ERROR: no *.schema.json files found in repo")
        return 1

    print(f"Validating {len(schemas)} schema file(s)")
    print()

    total_errors = 0
    for path in schemas:
        rel = path.relative_to(REPO_ROOT)
        errors = validate_schema_file(path)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All schemas valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across schemas.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/validate_schemas.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/validate_shots.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/validate_shots.py`

#!/usr/bin/env python3
"""
Validate a storyboard output set: shots.json and text-overlays.json, as instances.

Schema validation alone was never enough here. Every rule below is documented in
skills/storyboard-architect/SKILL.md as a quality-bar checkbox, which means it was
enforced by a model remembering to check it. These are the same rules, executable.

Checks:
  1. shots.json validates against shots.schema.json.
  2. text-overlays.json validates against text-overlays.schema.json.
  3. Timing: end > start, no duplicate ids, no gaps, no overlaps, and the covered
     span matches project.duration_s within TIMING_TOLERANCE_S.
  4. Reference integrity, both directions: every shot.on_screen_text resolves to an
     overlay, every overlay.shot_id resolves to a shot, and every overlay is
     reachable from at least one shot.
  5. Overlay timing sits inside its shot window and exit is after enter.
  6. Every overlay color appears in the brand-lock palette.
  7. brand_lock_ref resolves on disk.
  8. Every assets.generated[].generator is a real id in the capability matrix.
  9. Warnings for prose leaks: on-screen copy repeated in a shot subject, raw hex in
     a shot subject, shot ids out of chronological order, overlay fonts not named in
     the brand-lock typography section.

Usage:
    python tools/validate_shots.py <output-dir> [...]
    python tools/validate_shots.py path/to/shots.json [...]
    python tools/validate_shots.py --examples          # every bundled example
    python tools/validate_shots.py --selftest          # prove the checks fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    HEX_RE,
    REPO_ROOT,
    as_overlay_ids,
    as_shot_ids,
    capability_ids,
    load_json,
    palette_hexes,
    parse_typography,
)

SHOTS_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "shots.schema.json"
)
OVERLAYS_SCHEMA = (
    REPO_ROOT
    / "skills"
    / "storyboard-architect"
    / "templates"
    / "text-overlays.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "storyboard-architect" / "examples"

TIMING_TOLERANCE_S = 0.1


def _schema_errors(data, validator: Draft202012Validator, label: str) -> list[str]:
    out = []
    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        out.append(f"{label} schema: {loc}: {err.message}")
    return out


def check_timing(shots: list[dict], duration_s: float) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    seen: set[str] = set()
    for shot in shots:
        sid = shot.get("id", "?")
        if sid in seen:
            errors.append(f"timing: duplicate shot id '{sid}'")
        seen.add(sid)
        start, end = shot.get("start"), shot.get("end")
        if isinstance(start, (int, float)) and isinstance(end, (int, float)):
            if end <= start:
                errors.append(
                    f"timing: {sid} has end ({end}) not after start ({start})"
                )

    timed = [
        s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    ]
    if not timed:
        return errors, warnings

    ordered = sorted(timed, key=lambda s: (s["start"], s["end"]))
    for a, b in zip(ordered, ordered[1:]):
        if b["start"] > a["end"] + 1e-9:
            errors.append(
                f"timing: gap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )
        elif b["start"] < a["end"] - 1e-9:
            errors.append(
                f"timing: overlap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )

    span = max(s["end"] for s in timed) - min(s["start"] for s in timed)
    if abs(span - duration_s) > TIMING_TOLERANCE_S:
        errors.append(
            f"timing: covered span {span:g}s does not match project.duration_s "
            f"{duration_s:g}s (tolerance {TIMING_TOLERANCE_S}s)"
        )

    if [s["id"] for s in timed] != [s["id"] for s in ordered]:
        warnings.append(
            "timing: shot ids are not in chronological order; readers assume they are"
        )

    return errors, warnings


def check_version_features(shots: list[dict], version: str) -> list[str]:
    """Features may not be used below the version that introduced them."""
    errors: list[str] = []
    if version in ("1.0", "1.1"):
        for shot in shots:
            if isinstance(shot.get("on_screen_text"), list):
                errors.append(
                    f"version: {shot.get('id')} uses the array form of on_screen_text, "
                    f"which requires version 1.2 (file declares {version})"
                )
    if version == "1.0":
        for shot in shots:
            if shot.get("assets") is not None:
                errors.append(
                    f"version: {shot.get('id')} carries an assets block, which "
                    f"requires version 1.1 or later (file declares 1.0)"
                )
    return errors


def check_references(
    shots: list[dict], overlays: list[dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    shot_ids = {s.get("id") for s in shots}
    overlay_ids: set[str] = set()
    for overlay in overlays:
        oid = overlay.get("id")
        if oid in overlay_ids:
            errors.append(f"reference: duplicate overlay id '{oid}'")
        overlay_ids.add(oid)

    referenced: set[str] = set()
    for shot in shots:
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            referenced.add(oid)
            if oid not in overlay_ids:
                errors.append(
                    f"reference: {shot.get('id')}.on_screen_text '{oid}' has no "
                    f"entry in text-overlays.json"
                )

    for overlay in overlays:
        oid = overlay.get("id")
        for sid in as_shot_ids(overlay.get("shot_id")):
            if sid not in shot_ids:
                errors.append(
                    f"reference: overlay {oid}.shot_id '{sid}' has no entry in shots.json"
                )
        if oid not in referenced:
            errors.append(
                f"reference: overlay {oid} is not reachable from any "
                f"shot.on_screen_text, so no renderer will show it"
            )

    return errors, warnings


def check_overlay_windows(shots: list[dict], overlays: list[dict]) -> list[str]:
    errors: list[str] = []
    by_id = {
        s["id"]: s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    }

    for overlay in overlays:
        oid = overlay.get("id")
        enter = (overlay.get("enter") or {}).get("at")
        exit_at = (overlay.get("exit") or {}).get("at")
        if not isinstance(enter, (int, float)) or not isinstance(exit_at, (int, float)):
            continue
        if exit_at <= enter:
            errors.append(
                f"overlay: {oid} exit ({exit_at}) is not after enter ({enter})"
            )
        windows = [by_id[s] for s in as_shot_ids(overlay.get("shot_id")) if s in by_id]
        if not windows:
            continue
        lo = min(w["start"] for w in windows)
        hi = max(w["end"] for w in windows)
        if enter < lo - 1e-9 or exit_at > hi + 1e-9:
            errors.append(
                f"overlay: {oid} timing {enter}-{exit_at}s falls outside its shot "
                f"window {lo:g}-{hi:g}s"
            )

    return errors


def check_brand_alignment(
    shots: list[dict], overlays: list[dict], brand_lock_text: str | None
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if brand_lock_text is None:
        warnings.append(
            "brand: brand_lock_ref did not resolve, so palette and font checks were skipped"
        )
        return errors, warnings

    allowed = palette_hexes(brand_lock_text)
    for overlay in overlays:
        color = overlay.get("color")
        if isinstance(color, str) and color.lower() not in allowed:
            errors.append(
                f"brand: overlay {overlay.get('id')} color {color} is not in the "
                f"brand-lock palette"
            )

    fonts = {v.lower() for v in parse_typography(brand_lock_text).values() if v}
    if fonts:
        for overlay in overlays:
            font = overlay.get("font")
            if isinstance(font, str) and font.lower() not in fonts:
                warnings.append(
                    f"brand: overlay {overlay.get('id')} font '{font}' is not a font "
                    f"declared in the brand-lock typography section"
                )

    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        for hex_val in HEX_RE.findall(subject):
            warnings.append(
                f"brand: {shot.get('id')}.subject names a raw hex ({hex_val}); "
                f"colors belong in series_lock and the brand-lock"
            )

    return errors, warnings


def check_text_leak(shots: list[dict], overlays: list[dict]) -> list[str]:
    """On-screen copy repeated inside a shot subject. Text is a separate layer."""
    warnings: list[str] = []
    contents = {
        o.get("id"): o.get("content")
        for o in overlays
        if isinstance(o.get("content"), str) and len(o.get("content", "")) >= 8
    }
    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        lowered = subject.lower()
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            content = contents.get(oid)
            if content and content.lower().rstrip(".!?") in lowered:
                warnings.append(
                    f"text: {shot.get('id')}.subject repeats overlay {oid} copy "
                    f"verbatim; on-screen text is composited, never described"
                )
    return warnings


def check_assets(shots: list[dict], known_generators: set[str]) -> list[str]:
    errors: list[str] = []
    if not known_generators:
        return errors
    for shot in shots:
        for entry in (shot.get("assets") or {}).get("generated", []) or []:
            gen = entry.get("generator")
            if isinstance(gen, str) and gen not in known_generators:
                errors.append(
                    f"assets: {shot.get('id')} generated frame names generator "
                    f"'{gen}', which is not in the capability matrix"
                )
            if entry.get("accepted") is True and not entry.get("critique_ref"):
                errors.append(
                    f"assets: {shot.get('id')} has an accepted frame with no "
                    f"critique_ref, which is an unsourced approval"
                )
    return errors


def validate_set(shots_path: Path) -> tuple[list[str], list[str]]:
    """Validate one shots.json plus the siblings it points at."""
    errors: list[str] = []
    warnings: list[str] = []

    shots_data, err = load_json(shots_path)
    if err:
        return ([err], warnings)
    if not isinstance(shots_data, dict):
        return ([f"{shots_path}: top level is not an object"], warnings)

    shots_schema, s_err = load_json(SHOTS_SCHEMA)
    overlays_schema, o_err = load_json(OVERLAYS_SCHEMA)
    if s_err or o_err:
        return ([s_err or o_err], warnings)

    errors += _schema_errors(
        shots_data, Draft202012Validator(shots_schema), "shots.json"
    )

    base = shots_path.parent
    overlays_path = base / "text-overlays.json"
    overlays: list[dict] = []
    if overlays_path.exists():
        overlays_data, ov_err = load_json(overlays_path)
        if ov_err:
            errors.append(f"text-overlays.json: {ov_err}")
        else:
            errors += _schema_errors(
                overlays_data,
                Draft202012Validator(overlays_schema),
                "text-overlays.json",
            )
            overlays = overlays_data.get("overlays", []) or []
    else:
        for shot in shots_data.get("shots", []) or []:
            if as_overlay_ids(shot.get("on_screen_text")):
                errors.append(
                    "reference: shots.json references on-screen text but "
                    "text-overlays.json is missing"
                )
                break

    if errors:
        # Structure-dependent checks assume schema-valid input.
        return (errors, warnings)

    shots = shots_data.get("shots", []) or []
    duration = shots_data.get("project", {}).get("duration_s")

    errors += check_version_features(shots, shots_data.get("version", ""))

    if isinstance(duration, (int, float)):
        t_err, t_warn = check_timing(shots, float(duration))
        errors += t_err
        warnings += t_warn

    r_err, r_warn = check_references(shots, overlays)
    errors += r_err
    warnings += r_warn
    errors += check_overlay_windows(shots, overlays)

    brand_ref = shots_data.get("brand_lock_ref")
    brand_text: str | None = None
    if isinstance(brand_ref, str):
        brand_path = base / brand_ref
        if brand_path.exists():
            brand_text = brand_path.read_text(encoding="utf-8")
        else:
            errors.append(
                f"brand: brand_lock_ref '{brand_ref}' does not resolve from {base}"
            )
    b_err, b_warn = check_brand_alignment(shots, overlays, brand_text)
    errors += b_err
    warnings += b_warn

    warnings += check_text_leak(shots, overlays)
    errors += check_assets(shots, capability_ids())

    return (errors, warnings)


def _resolve_target(raw: str) -> Path | None:
    path = Path(raw)
    if path.is_dir():
        candidate = path / "shots.json"
        return candidate if candidate.exists() else None
    return path if path.exists() else None


def selftest() -> int:
    """Prove the cross-field checks fire. Fixtures are in-memory, no files touched."""
    ok = True
    cases = [
        (
            "end not after start",
            lambda: check_timing(
                [{"id": "shot_01", "start": 5.0, "end": 3.0}], 30.0
            )[0],
        ),
        (
            "gap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 2.0},
                    {"id": "shot_02", "start": 4.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "overlap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 5.0},
                    {"id": "shot_02", "start": 3.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "span disagrees with duration",
            lambda: check_timing(
                [{"id": "shot_01", "start": 0.0, "end": 10.0}], 30.0
            )[0],
        ),
        (
            "dangling on_screen_text",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": "text_09"}], []
            )[0],
        ),
        (
            "unreachable overlay",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": None}],
                [{"id": "text_01", "shot_id": "shot_01"}],
            )[0],
        ),
        (
            "overlay outside its shot window",
            lambda: check_overlay_windows(
                [{"id": "shot_01", "start": 0.0, "end": 2.0}],
                [
                    {
                        "id": "text_01",
                        "shot_id": "shot_01",
                        "enter": {"at": 0.0},
                        "exit": {"at": 9.0},
                    }
                ],
            ),
        ),
        (
            "off-palette overlay color",
            lambda: check_brand_alignment(
                [],
                [{"id": "text_01", "color": "#ABCDEF"}],
                "## Palette\n\n| Role | Hex |\n|---|---|\n| Ink | `#2A2A32` |\n",
            )[0],
        ),
        (
            "accepted frame with no critique_ref",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {"generated": [{"path": "a.png", "accepted": True}]},
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "unknown generator id",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {
                            "generated": [{"path": "a.png", "generator": "runway-sora"}]
                        },
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "1.2 feature used in a 1.0 file",
            lambda: check_version_features(
                [{"id": "shot_01", "on_screen_text": ["text_01", "text_02"]}], "1.0"
            ),
        ),
    ]

    for label, fn in cases:
        produced = fn()
        if produced:
            print(f"  ok    selftest: {label} is caught")
        else:
            print(f"  FAIL  selftest: {label} was not caught")
            ok = False

    clean, clean_warn = check_timing(
        [
            {"id": "shot_01", "start": 0.0, "end": 2.0},
            {"id": "shot_02", "start": 2.0, "end": 30.0},
        ],
        30.0,
    )
    if clean or clean_warn:
        print(f"  FAIL  selftest: a clean shot list should pass, got: {clean + clean_warn}")
        ok = False
    else:
        print("  ok    selftest: a clean shot list passes")

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_shots.py <output-dir|shots.json> [...]")
        print("       python tools/validate_shots.py --examples")
        print("       python tools/validate_shots.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    if "--examples" in args:
        targets = sorted(EXAMPLES_DIR.glob("*/shots.json"))
        if not targets:
            print(f"ERROR: no bundled examples found under {EXAMPLES_DIR}")
            return 1
    else:
        targets = []
        for raw in args:
            resolved = _resolve_target(raw)
            if resolved is None:
                print(f"  FAIL  {raw}")
                print("        - no shots.json found at this path")
                return 1
            targets.append(resolved)

    print(f"Validating {len(targets)} storyboard set(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for shots_path in targets:
        try:
            rel = shots_path.relative_to(REPO_ROOT)
        except ValueError:
            rel = shots_path
        errors, warnings = validate_set(shots_path)
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {rel}: {warn}")

    print()
    if total_errors == 0:
        print(f"All storyboard sets valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across storyboard sets.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/validate_shots.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/validate_skills.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/validate_skills.py`

#!/usr/bin/env python3
"""
Validate every SKILL.md in the repo has the required frontmatter.

Required fields:
- name (string, matches the directory name)
- description (string, non-empty)

Run from repo root:
    python tools/validate_skills.py
"""

from __future__ import annotations
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML not installed. Run: pip install pyyaml")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent
SKILLS_DIR = REPO_ROOT / "skills"


def parse_frontmatter(path: Path) -> dict | None:
    """Extract YAML frontmatter from a Markdown file. Returns None if absent."""
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    parts = text.split("---", 2)
    if len(parts) < 3:
        return None
    try:
        return yaml.safe_load(parts[1])
    except yaml.YAMLError as e:
        print(f"  YAML parse error: {e}")
        return None


def validate_skill(skill_dir: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    skill_md = skill_dir / "SKILL.md"

    if not skill_md.exists():
        errors.append(f"missing SKILL.md")
        return errors

    fm = parse_frontmatter(skill_md)
    if fm is None:
        errors.append("missing or invalid YAML frontmatter")
        return errors

    if "name" not in fm:
        errors.append("frontmatter missing 'name'")
    elif not isinstance(fm["name"], str) or not fm["name"].strip():
        errors.append("frontmatter 'name' must be a non-empty string")
    elif fm["name"] != skill_dir.name:
        errors.append(
            f"frontmatter name '{fm['name']}' does not match directory name '{skill_dir.name}'"
        )

    if "description" not in fm:
        errors.append("frontmatter missing 'description'")
    elif not isinstance(fm["description"], str) or not fm["description"].strip():
        errors.append("frontmatter 'description' must be a non-empty string")
    elif len(fm["description"]) < 50:
        errors.append(
            f"frontmatter description is too short ({len(fm['description'])} chars). "
            "Aim for >= 50 chars to support skill triggering."
        )

    return errors


def main() -> int:
    if not SKILLS_DIR.exists():
        print(f"ERROR: skills directory not found at {SKILLS_DIR}")
        return 1

    skill_dirs = sorted([d for d in SKILLS_DIR.iterdir() if d.is_dir()])
    if not skill_dirs:
        print(f"ERROR: no skill directories found in {SKILLS_DIR}")
        return 1

    print(f"Validating {len(skill_dirs)} skill(s) in {SKILLS_DIR.relative_to(REPO_ROOT)}/")
    print()

    total_errors = 0
    for skill_dir in skill_dirs:
        errors = validate_skill(skill_dir)
        rel = skill_dir.relative_to(REPO_ROOT)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All skills valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across skills.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/validate_skills.py -->


<!-- SOURCE_FILE_START: skills/video/LICENSE -->
# SOURCE FILE: `skills/video/LICENSE`

Attribution 4.0 International

=======================================================================

Creative Commons Corporation ("Creative Commons") is not a law firm and
does not provide legal services or legal advice. Distribution of
Creative Commons public licenses does not create a lawyer-client or
other relationship. Creative Commons makes its licenses and related
information available on an "as-is" basis. Creative Commons gives no
warranties regarding its licenses, any material licensed under their
terms and conditions, or any related information. Creative Commons
disclaims all liability for damages resulting from their use to the
fullest extent possible.

Using Creative Commons Public Licenses

Creative Commons public licenses provide a standard set of terms and
conditions that creators and other rights holders may use to share
original works of authorship and other material subject to copyright
and certain other rights specified in the public license below. The
following considerations are for informational purposes only, are not
exhaustive, and do not form part of our licenses.

     Considerations for licensors: Our public licenses are
     intended for use by those authorized to give the public
     permission to use material in ways otherwise restricted by
     copyright and certain other rights. Our licenses are
     irrevocable. Licensors should read and understand the terms
     and conditions of the license they choose before applying it.
     Licensors should also secure all rights necessary before
     applying our licenses so that the public can reuse the
     material as expected. Licensors should clearly mark any
     material not subject to the license. This includes other CC-
     licensed material, or material used under an exception or
     limitation to copyright. More considerations for licensors:
    wiki.creativecommons.org/Considerations_for_licensors

     Considerations for the public: By using one of our public
     licenses, a licensor grants the public permission to use the
     licensed material under specified terms and conditions. If
     the licensor's permission is not necessary for any reason--for
     example, because of any applicable exception or limitation to
     copyright--then that use is not regulated by the license. Our
     licenses grant only permissions under copyright and certain
     other rights that a licensor has authority to grant. Use of
     the licensed material may still be restricted for other
     reasons, including because others have copyright or other
     rights in the material. A licensor may make special requests,
     such as asking that all changes be marked or described.
     Although not required by our licenses, you are encouraged to
     respect those requests where reasonable. More considerations
     for the public:
    wiki.creativecommons.org/Considerations_for_licensees

=======================================================================

Creative Commons Attribution 4.0 International Public License

By exercising the Licensed Rights (defined below), You accept and agree
to be bound by the terms and conditions of this Creative Commons
Attribution 4.0 International Public License ("Public License"). To the
extent this Public License may be interpreted as a contract, You are
granted the Licensed Rights in consideration of Your acceptance of
these terms and conditions, and the Licensor grants You such rights in
consideration of benefits the Licensor receives from making the
Licensed Material available under these terms and conditions.


Section 1 -- Definitions.

  a. Adapted Material means material subject to Copyright and Similar
     Rights that is derived from or based upon the Licensed Material
     and in which the Licensed Material is translated, altered,
     arranged, transformed, or otherwise modified in a manner requiring
     permission under the Copyright and Similar Rights held by the
     Licensor. For purposes of this Public License, where the Licensed
     Material is a musical work, performance, or sound recording,
     Adapted Material is always produced where the Licensed Material is
     synched in timed relation with a moving image.

  b. Adapter's License means the license You apply to Your Copyright
     and Similar Rights in Your contributions to Adapted Material in
     accordance with the terms and conditions of this Public License.

  c. Copyright and Similar Rights means copyright and/or similar rights
     closely related to copyright including, without limitation,
     performance, broadcast, sound recording, and Sui Generis Database
     Rights, without regard to how the rights are labeled or
     categorized. For purposes of this Public License, the rights
     specified in Section 2(b)(1)-(2) are not Copyright and Similar
     Rights.

  d. Effective Technological Measures means those measures that, in the
     absence of proper authority, may not be circumvented under laws
     fulfilling obligations under Article 11 of the WIPO Copyright
     Treaty adopted on December 20, 1996, and/or similar international
     agreements.

  e. Exceptions and Limitations means fair use, fair dealing, and/or
     any other exception or limitation to Copyright and Similar Rights
     that applies to Your use of the Licensed Material.

  f. Licensed Material means the artistic or literary work, database,
     or other material to which the Licensor applied this Public
     License.

  g. Licensed Rights means the rights granted to You subject to the
     terms and conditions of this Public License, which are limited to
     all Copyright and Similar Rights that apply to Your use of the
     Licensed Material and that the Licensor has authority to license.

  h. Licensor means the individual(s) or entity(ies) granting rights
     under this Public License.

  i. Share means to provide material to the public by any means or
     process that requires permission under the Licensed Rights, such
     as reproduction, public display, public performance, distribution,
     dissemination, communication, or importation, and to make material
     available to the public including in ways that members of the
     public may access the material from a place and at a time
     individually chosen by them.

  j. Sui Generis Database Rights means rights other than copyright
     resulting from Directive 96/9/EC of the European Parliament and of
     the Council of 11 March 1996 on the legal protection of databases,
     as amended and/or succeeded, as well as other essentially
     equivalent rights anywhere in the world.

  k. You means the individual or entity exercising the Licensed Rights
     under this Public License. Your has a corresponding meaning.


Section 2 -- Scope.

  a. License grant.

       1. Subject to the terms and conditions of this Public License,
          the Licensor hereby grants You a worldwide, royalty-free,
          non-sublicensable, non-exclusive, irrevocable license to
          exercise the Licensed Rights in the Licensed Material to:

            a. reproduce and Share the Licensed Material, in whole or
               in part; and

            b. produce, reproduce, and Share Adapted Material.

       2. Exceptions and Limitations. For the avoidance of doubt, where
          Exceptions and Limitations apply to Your use, this Public
          License does not apply, and You do not need to comply with
          its terms and conditions.

       3. Term. The term of this Public License is specified in Section
          6(a).

       4. Media and formats; technical modifications allowed. The
          Licensor authorizes You to exercise the Licensed Rights in
          all media and formats whether now known or hereafter created,
          and to make technical modifications necessary to do so. The
          Licensor waives and/or agrees not to assert any right or
          authority to forbid You from making technical modifications
          necessary to exercise the Licensed Rights, including
          technical modifications necessary to circumvent Effective
          Technological Measures. For purposes of this Public License,
          simply making modifications authorized by this Section 2(a)
          (4) never produces Adapted Material.

       5. Downstream recipients.

            a. Offer from the Licensor -- Licensed Material. Every
               recipient of the Licensed Material automatically
               receives an offer from the Licensor to exercise the
               Licensed Rights under the terms and conditions of this
               Public License.

            b. No downstream restrictions. You may not offer or impose
               any additional or different terms or conditions on, or
               apply any Effective Technological Measures to, the
               Licensed Material if doing so restricts exercise of the
               Licensed Rights by any recipient of the Licensed
               Material.

       6. No endorsement. Nothing in this Public License constitutes or
          may be construed as permission to assert or imply that You
          are, or that Your use of the Licensed Material is, connected
          with, or sponsored, endorsed, or granted official status by,
          the Licensor or others designated to receive attribution as
          provided in Section 3(a)(1)(A)(i).

  b. Other rights.

       1. Moral rights, such as the right of integrity, are not
          licensed under this Public License, nor are publicity,
          privacy, and/or other similar personality rights; however, to
          the extent possible, the Licensor waives and/or agrees not to
          assert any such rights held by the Licensor to the limited
          extent necessary to allow You to exercise the Licensed
          Rights, but not otherwise.

       2. Patent and trademark rights are not licensed under this
          Public License.

       3. To the extent possible, the Licensor waives any right to
          collect royalties from You for the exercise of the Licensed
          Rights, whether directly or through a collecting society
          under any voluntary or waivable statutory or compulsory
          licensing scheme. In all other cases the Licensor expressly
          reserves any right to collect such royalties.


Section 3 -- License Conditions.

Your exercise of the Licensed Rights is expressly made subject to the
following conditions.

  a. Attribution.

       1. If You Share the Licensed Material (including in modified
          form), You must:

            a. retain the following if it is supplied by the Licensor
               with the Licensed Material:

                 i. identification of the creator(s) of the Licensed
                    Material and any others designated to receive
                    attribution, in any reasonable manner requested by
                    the Licensor (including by pseudonym if
                    designated);

                ii. a copyright notice;

               iii. a notice that refers to this Public License;

                iv. a notice that refers to the disclaimer of
                    warranties;

                 v. a URI or hyperlink to the Licensed Material to the
                    extent reasonably practicable;

            b. indicate if You modified the Licensed Material and
               retain an indication of any previous modifications; and

            c. indicate the Licensed Material is licensed under this
               Public License, and include the text of, or the URI or
               hyperlink to, this Public License.

       2. You may satisfy the conditions in Section 3(a)(1) in any
          reasonable manner based on the medium, means, and context in
          which You Share the Licensed Material. For example, it may be
          reasonable to satisfy the conditions by providing a URI or
          hyperlink to a resource that includes the required
          information.

       3. If requested by the Licensor, You must remove any of the
          information required by Section 3(a)(1)(A) to the extent
          reasonably practicable.

       4. If You Share Adapted Material You produce, the Adapter's
          License You apply must not prevent recipients of the Adapted
          Material from complying with this Public License.


Section 4 -- Sui Generis Database Rights.

Where the Licensed Rights include Sui Generis Database Rights that
apply to Your use of the Licensed Material:

  a. for the avoidance of doubt, Section 2(a)(1) grants You the right
     to extract, reuse, reproduce, and Share all or a substantial
     portion of the contents of the database;

  b. if You include all or a substantial portion of the database
     contents in a database in which You have Sui Generis Database
     Rights, then the database in which You have Sui Generis Database
     Rights (but not its individual contents) is Adapted Material; and

  c. You must comply with the conditions in Section 3(a) if You Share
     all or a substantial portion of the contents of the database.

For the avoidance of doubt, this Section 4 supplements and does not
replace Your obligations under this Public License where the Licensed
Rights include other Copyright and Similar Rights.


Section 5 -- Disclaimer of Warranties and Limitation of Liability.

  a. UNLESS OTHERWISE SEPARATELY UNDERTAKEN BY THE LICENSOR, TO THE
     EXTENT POSSIBLE, THE LICENSOR OFFERS THE LICENSED MATERIAL AS-IS
     AND AS-AVAILABLE, AND MAKES NO REPRESENTATIONS OR WARRANTIES OF
     ANY KIND CONCERNING THE LICENSED MATERIAL, WHETHER EXPRESS,
     IMPLIED, STATUTORY, OR OTHER. THIS INCLUDES, WITHOUT LIMITATION,
     WARRANTIES OF TITLE, MERCHANTABILITY, FITNESS FOR A PARTICULAR
     PURPOSE, NON-INFRINGEMENT, ABSENCE OF LATENT OR OTHER DEFECTS,
     ACCURACY, OR THE PRESENCE OR ABSENCE OF ERRORS, WHETHER OR NOT
     KNOWN OR DISCOVERABLE. WHERE DISCLAIMERS OF WARRANTIES ARE NOT
     ALLOWED IN FULL OR IN PART, THIS DISCLAIMER MAY NOT APPLY TO YOU.

  b. TO THE EXTENT POSSIBLE, IN NO EVENT WILL THE LICENSOR BE LIABLE
     TO YOU ON ANY LEGAL THEORY (INCLUDING, WITHOUT LIMITATION,
     NEGLIGENCE) OR OTHERWISE FOR ANY DIRECT, SPECIAL, INDIRECT,
     INCIDENTAL, CONSEQUENTIAL, PUNITIVE, EXEMPLARY, OR OTHER LOSSES,
     COSTS, EXPENSES, OR DAMAGES ARISING OUT OF THIS PUBLIC LICENSE OR
     USE OF THE LICENSED MATERIAL, EVEN IF THE LICENSOR HAS BEEN
     ADVISED OF THE POSSIBILITY OF SUCH LOSSES, COSTS, EXPENSES, OR
     DAMAGES. WHERE A LIMITATION OF LIABILITY IS NOT ALLOWED IN FULL OR
     IN PART, THIS LIMITATION MAY NOT APPLY TO YOU.

  c. The disclaimer of warranties and limitation of liability provided
     above shall be interpreted in a manner that, to the extent
     possible, most closely approximates an absolute disclaimer and
     waiver of all liability.


Section 6 -- Term and Termination.

  a. This Public License applies for the term of the Copyright and
     Similar Rights licensed here. However, if You fail to comply with
     this Public License, then Your rights under this Public License
     terminate automatically.

  b. Where Your right to use the Licensed Material has terminated under
     Section 6(a), it reinstates:

       1. automatically as of the date the violation is cured, provided
          it is cured within 30 days of Your discovery of the
          violation; or

       2. upon express reinstatement by the Licensor.

     For the avoidance of doubt, this Section 6(b) does not affect any
     right the Licensor may have to seek remedies for Your violations
     of this Public License.

  c. For the avoidance of doubt, the Licensor may also offer the
     Licensed Material under separate terms or conditions or stop
     distributing the Licensed Material at any time; however, doing so
     will not terminate this Public License.

  d. Sections 1, 5, 6, 7, and 8 survive termination of this Public
     License.


Section 7 -- Other Terms and Conditions.

  a. The Licensor shall not be bound by any additional or different
     terms or conditions communicated by You unless expressly agreed.

  b. Any arrangements, understandings, or agreements regarding the
     Licensed Material not stated herein are separate from and
     independent of the terms and conditions of this Public License.


Section 8 -- Interpretation.

  a. For the avoidance of doubt, this Public License does not, and
     shall not be interpreted to, reduce, limit, restrict, or impose
     conditions on any use of the Licensed Material that could lawfully
     be made without permission under this Public License.

  b. To the extent possible, if any provision of this Public License is
     deemed unenforceable, it shall be automatically reformed to the
     minimum extent necessary to make it enforceable. If the provision
     cannot be reformed, it shall be severed from this Public License
     without affecting the enforceability of the remaining terms and
     conditions.

  c. No term or condition of this Public License will be waived and no
     failure to comply consented to unless expressly agreed to by the
     Licensor.

  d. Nothing in this Public License constitutes or may be interpreted
     as a limitation upon, or waiver of, any privileges and immunities
     that apply to the Licensor or You, including from the legal
     processes of any jurisdiction or authority.


=======================================================================

Creative Commons is not a party to its public
licenses. Notwithstanding, Creative Commons may elect to apply one of
its public licenses to material it publishes and in those instances
will be considered the “Licensor.” The text of the Creative Commons
public licenses is dedicated to the public domain under the CC0 Public
Domain Dedication. Except for the limited purpose of indicating that
material is shared under a Creative Commons public license or as
otherwise permitted by the Creative Commons policies published at
creativecommons.org/policies, Creative Commons does not authorize the
use of the trademark "Creative Commons" or any other trademark or logo
of Creative Commons without its prior written consent including,
without limitation, in connection with any unauthorized modifications
to any of its public licenses or any other arrangements,
understandings, or agreements concerning use of licensed material. For
the avoidance of doubt, this paragraph does not form part of the
public licenses.

Creative Commons may be contacted at creativecommons.org.


<!-- SOURCE_FILE_END: skills/video/LICENSE -->


<!-- SOURCE_FILE_START: skills/video/NOTICE -->
# SOURCE FILE: `skills/video/NOTICE`

Visual Skills — AI film director skills for Claude agents
Copyright (c) 2026 Serge Shima

Licensed under Creative Commons Attribution 4.0 International (CC BY 4.0).
Any use, copy, or derivative of these skills must credit the author:

  Serge Shima — https://t.me/aimastersme · https://sergeshima.com · https://aimasters.me
  Source: https://github.com/smixs/visual-skills

Full license text: LICENSE file or https://creativecommons.org/licenses/by/4.0/

<!-- SOURCE_FILE_END: skills/video/NOTICE -->


<!-- SOURCE_FILE_START: skills/video/SKILL.md -->
# SOURCE FILE: `skills/video/SKILL.md`

---
name: video
license: CC-BY-4.0 (attribution required — Serge Shima, github.com/smixs/visual-skills)
description: Use this skill whenever the user asks to create, improve, audit, or split prompts for AI video generators (Seedance, Kling, Veo, Runway, Luma, Pika, Sora, any image-to-video system). The skill also covers storyboards, shot lists, director treatments, dynamic montage, multi-clip story structure, camera direction, lighting, blocking, pacing, character continuity, dialogue, and sound design. Trigger even when the user says things like "придумай сцену для видео", "разбей на склейки", "сделай раскадровку", "улучши промпт для Kling", "переведи сценарий в промпты", "как снять X в AI-видео", or shares a prompt and asks to fix it.
---

# AI Director, Screenwriter & Editor

Hybrid role. You direct (see frame, emotion, motivated camera), write (build beat, action, consequence, final image), and edit (cut rhythm, protect continuity, drive montage). Prompt engineering is fourth — it serves the first three.

A beautiful frame without dramaturgy is wallpaper. A dramaturgically clean prompt without details is mush. The whole craft of this skill lives in the reference files. The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone.

## Route first — is this actually a video-prompt task?

- **No idea or script yet** (user wants a concept, a Big Idea, a campaign, an ad scenario — not a prompt): if the `creative-director` skill is installed, start there — it develops ideas and scripts for commercials and beyond ([github.com/smixs/creative-director-skill](https://github.com/smixs/creative-director-skill)). Come back here once there is a script to shoot.
- **Still keyframes, character sheets, animatic panels** to feed the video pipeline: use the sibling `image` skill, then return with the keyframes.
- **A script or scene exists and needs prompts** — this skill. Continue below.

---

# Mandatory reading order — DO NOT WRITE A PROMPT WITHOUT THIS

Past attempts to write prompts directly from this skill body produced lazy, mush-prone results. The fix is structural: the process lives only in the reference files, and you load them in this order before producing output. Skipping a step **silently** degrades the result — the model cannot tell that a shot is wallpaper, only the writer can, and only by applying the rules from these files.

For every video prompt request, load the files in this order:

### Step 1 — always read first → [dramaturgy.md](references/dramaturgy.md)

Scene formula. Details Law (the second core law, most violated). Murch Rule of Six. Three-jobs rule. Five anchors. Blocking, staging, environment as pressure. Three-layer storyboard. 14-field shot card. Rhythm ladder. Dramaturgy check.

You cannot decide whether a prompt is ready without running the dramaturgy check from this file.

### Step 2 — always read second → [universal-rules.md](references/universal-rules.md)

U1–U12 universal rules that apply to every video model: prompt skeleton, weight-at-start, show-don't-tell, lens language, character anchor, contradictions, duration discipline, final image rule, three-detail check.

### Step 3 — pick the model and read **one** model file

Use this short selector. The full reasoning is in the chosen file.

| Cue from the user / task | Read |
|---|---|
| Seedance, ByteDance, Doubao, Jimeng, multi-shot in one clip, `--resolution`, `--duration`, `--camerafixed`, "Cut to", `@img1`, fast multi-shot drama | [seedance.md](references/seedance.md) |
| **Seedance 2.5 production work**: 30s single-pass, 50-slot reference kits, video editing / partial re-render, extension, Ultra Long (30-180s), 3D blockout / green screen, `@Image N`, `{ }` dialogue markers | [seedance.md](references/seedance.md) **+** [seedance-25.md](references/seedance-25.md) |
| Kling, Kuaishou, Element Binding, Motion Brush, Motion Control, dedicated negative prompt field, **Kling 3.0 multi-shot with `[Character A: ...]` labels, native dialogue + lip-sync, 15s, Turbo (cheap lip-sync), Omni (references + editing, 4K)** | [kling.md](references/kling.md) |
| Veo, Google video, dialogue / lip-sync, JSON prompts, synchronized SFX, commercial polish with voiceover | [veo.md](references/veo.md) |

Default if nothing in the request hints at a model:
- Multi-shot narrative or fast montage drama → Seedance, or Kling 3.0 if dialogue is involved.
- Dialogue / commercial polish / synchronized SFX → Veo, or Kling 3.0 for multi-character dialogue scenes up to 15s.
- Character consistency across many social clips → Kling 2.6 Pro (cheaper) or Kling 3.0 (with in-prompt `[Character A: ...]` labels).
- 10-15s continuous narrative with audio → Kling 3.0.
- 15-30s continuous single-generation arc, heavy reference kits (up to 50 assets), editing or extending existing footage, 30-180s long-form → Seedance 2.5.
- Face-heavy drama → Seedance 2.5 (realistic humans + lip-sync are its headline feature), Kling, or Veo. On a 2.0-only pipeline route faces to 1.5 Pro (2.0 filters human faces aggressively).

For a more detailed comparison (max clip length, audio support, character lock methods, motion brush, etc.), read the model file you picked. Do not load all three.

### Step 4 — task-shaped reading (load only those that match)

- Storyboard / shot list / director treatment / "разбей на склейки" → [role-modes.md](references/role-modes.md). Determines whether you operate as Director, Screenwriter, or Editor for this turn.
- Storyboard keyframes / опорные кадры / аниматик / animatic / still panels / key visuals to pitch a sequence → [animatic-keyframes.md](references/animatic-keyframes.md). The general method for turning a beat sheet into still panels (and then image-gen prompts) that read as story, drama and emotion without motion or faces.
- Race / drift / drag / chase / speed / dynamic / kinetic montage, "гонщик", "раскадровка гонки", authentic-speed spot → [race-and-speed.md](references/race-and-speed.md). Specializes `animatic-keyframes.md` for the race domain — read that file first.
- Commercial, music video, drama, action, fashion, UGC, product film, escalation / anxiety / discovery / catastrophe / product-drama montage → [patterns-and-genres.md](references/patterns-and-genres.md).
- Multi-clip continuity, fixing a broken prompt, known failure modes (one-take, face drift, melted hands, dialogue too fast) → [fixes-and-skeletons.md](references/fixes-and-skeletons.md).
- Need precise framing / lens / movement / light / sound terms → [camera-lighting-vocabulary.md](references/camera-lighting-vocabulary.md).

If none match — proceed with steps 1-3 only.

### Step 5 — apply the dramaturgy check and the three-detail check

Before returning anything, run both checks:

- Dramaturgy check (`dramaturgy.md` §15): scene formula complete, three-detail check on every shot, three-jobs rule on every shot, motivated camera, readable geometry, five anchors named.
- Three-detail audit (`universal-rules.md` §13): each shot owns environmental pressure + physical micro-action + sound or visual motif.

If any shot fails, fix before sending. This is the step the user has had to enforce repeatedly. Do not skip it.

---

# Output

Choose the format the request actually asks for. Default to **A** if unclear.

- **A. Single prompt.** One ready-to-copy prompt for one generation. Lead with model name + parameters in a short header.
- **B. Multi-clip prompts.** Sequence of self-contained prompts, each repeating the full identity / style / continuity block (see `universal-rules.md` U7).
- **C. Storyboard.** Table — Time, Shot, Function, Action, Camera, Light, Sound, Emotion. Every row is a 14-field shot card from `dramaturgy.md` §11, compressed.
- **D. Prompt audit.** Given a user prompt, return: What works, What breaks generation, Missing direction, Continuity risks, Model-specific mismatches, Stronger version (rewritten prompt).
- **E. Director treatment.** Core idea, Emotional arc, Visual motif, Rhythm, Camera language, Lighting, Sound, Ending image. (Treatment ≠ prompt.)
- **F. JSON (Veo only).** Structured scene-by-scene continuity. See `veo.md`.

Default output language follows the user. The final AI prompt itself goes in English unless the user asks otherwise — Seedance, Kling, and Veo all perform better in English.

---

# Final response style

Prefer: ready-to-copy prompts, clear section labels, production language, motivated camera and light direction, strict continuity blocks, model-specific syntax, direct fixes.

Avoid: long theory unless asked, academic lectures, vague inspiration, decorative jargon, "cinematic masterpiece" filler, prompts without camera and light, prompts without continuity, stacking more than two director references, abstract emotions without physical translation.

When in doubt about a model-specific detail — re-read the model file before writing the final prompt. It costs nothing and prevents bad output.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/SKILL.md -->


<!-- SOURCE_FILE_START: skills/video/references/animatic-keyframes.md -->
# SOURCE FILE: `skills/video/references/animatic-keyframes.md`

# Keyframes for an animatic (opornye kadry)

This is the still-panel layer. A storyboard keyframe is not a frame grab of footage — it is a single drawn image that must carry one story-beat with **no motion and (usually) no face**. The animatic hangs off these panels. A panel that only looks good is wallpaper; a panel must report its story function, its drama, and the motion it cannot show, all frozen.

This file converts a beat sheet / treatment into **opornye kadry**, then into image-generation prompts. It sits on top of `dramaturgy.md` (§2 Details Law, §10 three-layer method, §11 shot card, §12 rhythm ladder, §15 check) and `universal-rules.md` (U1 skeleton, U11 final image). Pairs with `camera-lighting-vocabulary.md` for framing/lens/light tokens, `role-modes.md` §4 for the function taxonomy, `patterns-and-genres.md` (Action genre, Escalation pattern) for the spatial-clarity spine, and `seedance.md` / `kling.md` / `veo.md` to animate each locked frame. Output stays compatible with Storyboard format C: `Time | Shot | Function | Action | Camera | Light | Sound | Emotion`.

The running brief through every example below: drag/drift race spot, cold combative palette (steel blue, cyan, magenta, mercury-white; **red and green as accents only**; amber only as the start-tree's alien pulse or a toxic spill), faces absent or unusably fragmented. Swap subject as the task demands — the method holds.

## Contents

1. What an animatic keyframe must do
2. The keyframe card (a still extension of the shot card)
3. How many keyframes per beat (density ladder)
4. Composing a still that reads as MOTION
5. Emotion without faces in a still
6. The loaded frame for one panel
7. From keyframe to image-gen prompt
8. Worked keyframe board for a 30s race spot
9. Checklist: does this keyframe earn its place

---

## 1. What an animatic keyframe must do

In an animatic the **panel is the unit, not the shot.** A shot has duration, motion, and sound to carry its function across time. A keyframe has one frozen image and must carry the same function in a single glance. So every panel does four things at once, in one still:

- **One readable story-beat** — name it in one sentence before generating. If you cannot, the panel is not ready (`dramaturgy.md` §1).
- **One function tag** — Establish / Reveal / Power / Pressure / Detail / Reaction / Shift / Impact / Aftermath / Exit (`role-modes.md` §4). The tag is the question the panel answers. In a faceless spot **Reaction** is reassigned from a human face to the *machine's* face — the needle jumping, the slick wrinkling, the nose squatting. Treat gauges and rubber as the actor.
- **One emotion** — routed through metal, rubber, light, or anatomy, never named (`dramaturgy.md` §2). Mixed signals = no signal.
- **One implied motion** — the movement the still cannot perform, frozen as its physical residue (§4).

A panel that carries a beat, a function, an emotion, and an implied motion earns its place. A panel missing any of the four is a *fantik* — wrapper without candy (`dramaturgy.md` §3). The discipline of this whole file is: **you cannot prompt "motion" or "emotion" into a still — you prompt the physical consequence each leaves behind.**

---

## 2. The keyframe card

The shot card in `dramaturgy.md` §11 describes a moving shot. A keyframe needs a *still*-specific card: every field describes a frozen image, and three fields are new (implied camera, emotion-via-object, motion-rendered-as-still). Fill every field before generating. Empty fields reveal missing direction.

```text
KEYFRAME CARD
- Panel ID.            01, 02, 03
- Timecode.            on-screen life in the animatic (e.g. 0:10.5, HOLD 2s)
- Function tag.        Establish / Reveal / Power / Pressure / Detail /
                       Reaction / Shift / Impact / Aftermath / Exit
- Beat.                what changes in the story in this one still
- Framing + lens.      ECU / CU / MCU / wide / macro insert / POV + lens token
                       (24mm immersive ... 100mm macro — camera-lighting-vocabulary.md §3)
- Subject / anchor.    the ONE object or anatomy the eye lands on in 0.3s
- Depth layers.        FG job (frame / obstruct / put us inside)
                       MG job (the subject / the act)
                       BG job (stakes / context / rival)
- Implied camera.      the move this still is the first frame OF
                       (push-in, whip, bumper-POV, joust) — what it would do if it ran
- Light + palette.     one motivated source + direction + the surface it rims;
                       concrete colors, amber-ban repeated
- Emotion-via-object.  the feeling a face would show, mapped to an object's state (§5)
- Motion-as-still.     which frozen cue carries the missing movement (§4):
                       smear / partial blur / streak / vector / sharp-blur / held stillness
- Caption / label.     one word: setup / commitment / mistake / recovery /
                       proof-of-speed / result
- Sound.               what audio sits under the held frame, where the cut bites
                       (fill even though it is a still — dramaturgy.md §11)
- Production note.      prop, rig, continuity anchor
```

The card maps straight onto format C: `Function`, `Framing`, `Implied camera`, `Light`, `Sound`, `Emotion-via-object` become the table columns. The three still-specific fields — **implied camera, emotion-via-object, motion-as-still** — are the ones a normal shot card does not force you to name, and they are exactly the ones that keep a panel from going flat.

---

## 3. How many keyframes per beat — the density ladder

**Loudness in the audio = panel count in the board.** Silence gets one held panel; a bang gets a burst. This is the still-panel reading of `dramaturgy.md` §12 (rhythm ladder) and `role-modes.md` §3 (editor density: 3-4 beats/5s drama, 4-7 narrative, 6-9 fast montage). The full 30s beat map is the worked board in §8; split it per `patterns-and-genres.md` §3 (30s = 6×5s).

| Beat | Density | Panels | Why |
|---|---|---|---|
| **Ritual / staging** (quiet) | 1 hero panel, held | 1 panel living 1.5-2.5s | A silent beat is monolithic. Do not subdivide it — its power is that nothing moves while the world holds its breath. One symmetric "breath" frame, most negative space, least motion. |
| **Pressure climbing** (amber stagger) | escalating singles | 3 panels, collapsing length | The Sportsman tree fires three ambers 0.5s apart — three drawable panels, each tighter than the last, cut length collapsing toward the green. |
| **Launch / impact** (bang) | 3-panel micro-burst → up to 6-9 | 6-9 panels at 8fr → 4fr | The audio bang is rendered as panel *density*, not one big image. Hip-hop montage: bumper-POV smear, side wheelspin, tach flare, clutch hand, lane-stripe strobe. |
| **Contest** (sustained roar) | alternating | fragment-cluster ↔ one held detail | Never two bang-clusters back to back. Between every burst, one held quiet panel — loud only works next to quiet. |
| **Aftermath / exit** (cut to silence) | 1 hero panel, held | 1-2 panels, ~2s hold | End on consequence, not explanation. One held still: drifting smoke, hand unclenching, car nosing into dark. |

**Allocation rule.** A 30s spot lands at ~18-26 panels. Plot the board as a descending duration staircase (≈2.5s → 0.5s → 4fr), broken only by the one pre-launch pause and the one post-finish hold. The board should *read* as an accelerating tachometer even on mute. Give a beat a micro-burst only when the audio detonates; everywhere else, one panel that holds is stronger than three that scatter.

---

## 4. Composing a still that reads as MOTION

A keyframe cannot ramp, cut, or whip. Each missing move resolves into one of **six frozen cues**. Never write "motion" — write the artifact motion leaves behind. State the cue in the card's *Motion-as-still* field and again in the prompt's camera/light clause; models default to over-clean stabilization and will sand the speed off unless told (§7).

| Cue | What it is in a still | Renders the implied move |
|---|---|---|
| **Directional motion-blur smear** | Background streaked along the travel axis, subject sharp. Guardrail, lane stripes, tree lamps pulled into horizontal light-rods. | tracking pass, POV launch, the whip-pan aftermath |
| **Frozen partial blur** | One moving element blurred (tyre sidewall, smoke bloom, shift hand mid-throw) while the anchor stays crisp — proof of a single arrested instant. | speed-ramp peak, launch, shift |
| **Streak-frame (implied whip)** | The whole panel raked into motion-streaks with one readable shape surviving (a wheel arc, the shifter) — a "between two shots" blur panel. | whip pan, transition beat |
| **Posture / trajectory vector** | A body or car locked in a pose that can only resolve forward — wrist cocked over the shifter, front wheels lifting, weight slung onto the rear axle. The eye finishes the move. | charged pose, freeze frame, launch |
| **Sharp-subject / blurred-field separation** | Shallow-DOF macro: knuckle, needle, latch razor-sharp, everything else dissolved. Isolation = the cut-to-detail frozen. | insert chain, crash-zoom arrival, hip-hop CU |
| **Freeze-frame stillness** | Deliberately *zero* blur, hard edges, held breath — reads as a stopped clock against the blurred panels around it. | the pre-launch held beat, the loaded spring |

Per-technique kit (triad + the still application):

- **Frozen motion blur** — what it does to emotion: differential blur reads as velocity made tactile, the world torn past a steady subject — where seen: Dod Mantle whip-panned every overtake in *Rush* so the background dissolves. — *in a keyframe* [Shift/Impact]: hero car tack-sharp, entire background raked into horizontal streaks, foreground objects elongated into light-rods. The most powerful single-panel speed trick: **sharp hero + fully smeared world.** Equal blur everywhere = soft photo; differential blur = speed.
- **Tyre wrinkle / partial blur** — emotion: physics you can feel, force arrested at its peak — seen: Goodyear's deliberately silent slow-mo of the slick sidewall folding; Ritchie's speed-ramp as the exclamation mark. — *in a keyframe* [Detail/Reaction]: macro into the rear sidewall, the wrinkle caught at its deepest fold, smoke just blooming at the contact patch, everything else crisp. One arrested ten-thousandth of a second. The hero detail to *hold*.
- **Smoke / debris / spray shape** — emotion: force given a visible body, dread made airborne — seen: NHRA burnout-cam, "a wall of smoke" backlit at ground level. — *in a keyframe* [Pressure/Power]: backlit tyre smoke as a luminous wall (front-lit smoke is dead gray nothing); water-box spray frozen as a constellation of specular droplets, each rimmed on its leading edge. Atmosphere only reads when light passes through it (§5).
- **Posture / lean vector** — emotion: a stillness that can only resolve forward; the eye does the launching — seen: Vaughn's charged poses (*Kingsman*, *Layer Cake*) — every frame loaded with a trajectory. — *in a keyframe* [Power/Shift]: **no neutral panels.** Car at idle = front wheels micro-lifting, body slung onto the rear axle. Hand on wheel = fingers mid-clench. Compose the negative space *ahead* of the subject, the direction it is about to fire into.
- **Leading lines / light streak** — emotion: a rail for the eye that also encodes direction and speed — seen: Papamichael's asphalt-in-frame (*Ford v Ferrari*), the road as the speedometer. — *in a keyframe* [Power/Impact]: lane centerline raking to a vanishing point, sodium/mercury practicals smeared as long reflections down wet asphalt. Keep the texture (chevrons, tar seams, rubber marks) so the streak has something to streak.
- **Off-balance dutch** — emotion: imbalance, loss of grip, threat — seen: Raimi's canted attack frames (*Evil Dead II*). — *in a keyframe* [Impact]: cant the horizon hard at the one loss-of-traction beat — tyre breaking away, car stepping sideways. Reserve it for a single instability beat so it stays loud; dutch as wallpaper reads as bad framing.

**The speed-budget rule** (from the race-truth school): a still sells velocity when **at least three of five coexist in one frame** — (a) camera at/below bumper height, (b) asphalt streaking the lower frame, (c) a near foreground reference passing the edge, (d) sharp hero against motion-blurred background, (e) a mechanical-vibration cue (trembling mirror, doubled needle, smeared rim). One cue is a car photo. Three is velocity. If a "fast" panel cannot name three, reframe lower, drag the camera to the asphalt, throw a cone or barrier into the foreground.

---

## 5. Emotion without faces in a still

A face does four jobs: shows the feeling, shows where it looks, shows the cost, shows the decision. Faces banned, redistribute: **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space** (§6 and `dramaturgy.md` §2). Assign one job per panel and tag it. The emotion must already be frozen *inside the object* — a still cannot let motion blur do the emotional work for it.

Two load-bearing rules:

- **Anatomy only on a decision.** A hand at rest is filler; a hand *deciding* is a shot. Before drawing any hand/foot panel, name the verb — grip / latch / shift / preload / release. No verb, no panel. Render tendons raised, glove leather creasing, one hard side-light carving knuckle texture, the rest in shadow (Leone's hands-before-the-draw; Nike *Take It to the Next Level*, first-person, no hero face).
- **Objects only when they change state.** A static gear-lever says "car stuff" and flatlines. Board the **after** state of a threshold-crossing; the before is implied (Honda *Cog*: every object does something irreversible). Tach pinned in the red, not idling. Ignition lamp blooming live, not dark. Slick caught mid-fold.

Use the substitution table as the core deliverable — when the script wants an emotion and no face is available, render this object at this crop. Cold palette throughout.

| Emotion (a face would show) | Object substitute | Crop | Render note (the still) | Label / tag |
|---|---|---|---|---|
| **Fear / dread** | sweat bead on knuckle; tremor in the mirror reflection (not eyes) | macro / ECU | one hard specular highlight on the bead, cold rim, deep black around it; mirror edge doubled to imply vibration | setup → Pressure |
| **Resolve / commitment** | knuckles whitening on wheel or shifter; foot pinning throttle | CU / MCU | tendons raised, glove leather creasing, grip at maximum; one side-light, cabin in shadow | commitment → Shift |
| **Focus / lock-in** | start-lights reflected in lacquer / headlight glass (not a human eye) | MCU | staging bulbs mirrored as cold points on paint or chrome; tight, centered, still | setup → Detail |
| **Strain (machine at limit)** | tach needle pinned in red arc; slick sidewall wrinkling; exhaust flame | ECU / CU | needle hard against redline, motion-still but unmistakably max; sidewall at deepest fold | proof-of-speed → Pressure |
| **Mistake / panic** | tyre shake (sidewall "goes square"), wheel kicking back, revs over-flared | CU | sidewall deformed wrong, blur direction fighting the lane; tach spiked past the band | mistake → Impact |
| **Triumph / release** | grip relaxing; chute blooming; one nose past the stripe; smoke through headlight beams | CU → WS | fingers unfurling off the wheel; or distant clean geometry of the win, cold backlight through smoke | result → Aftermath / Exit |
| **Anticipation (pre-launch)** | finger over ignition / line-lock; pre-stage bulb lit; held shifter | ECU / CU | finger a hair off the button, bulb just lit cold, everything frozen — the "silence" panel | setup → Pressure |

State-change cheat-sheet (board the live state; the dead is implied): ignition dark → lamp blooming; tach idle → needle pinned red; slick round → wrinkle folded deep; water-box mirror-still → shredded by launch; front wheels planted → lifting; chassis level → squatted; chute packed → bloomed at the trap.

---

## 6. The loaded frame for one panel

A keyframe is a diagram the viewer solves in 0.3s and re-reads with pleasure at 1s. With no face, the geometry and the depth stack do the acting.

> **Core law of the loaded panel.** One focal point, one emotion, three working depth layers, zero dead objects. Answer one question in the first glance; reward a second look.

**Depth-layer jobs (FG / MG / BG).** Write the prompt in three explicit depth clauses, each with a stated job. This is the engine of "reads in one glance, rewards a second" (extends `dramaturgy.md` §10 into a single still). If all three planes carry the same blur or scale, you have one plane, not three — force a sharp MG subject against a soft FG frame and a soft BG stake (shallow DOF is the panel's hierarchy tool, `camera-lighting-vocabulary.md` §3).

| Plane | Default job | Drag-race objects | Function it serves |
|---|---|---|---|
| **Foreground** | frame / obstruct / put us inside | roll-cage bar, mirror edge, harness strap, smoke wisp, wet glass | Pressure, Power |
| **Midground** | the subject / the act | hand on shifter, knuckles on wheel, foot on pedal, tach face | Detail, Shift, Impact |
| **Background** | stakes / context / rival | staging bulb, rival lane headlight, finish line, narrowing barrier | Establish, Reveal, Pressure |

**One-glance + reward** — what it does to emotion: an instantly readable frame creates trust; a frame that rewards re-reading creates density and worth. With no face to anchor on, a muddy panel collapses to nothing. — *in a keyframe*: name the single focal point before generating (tach needle / staging bulb / knuckle), put it on a strong line, demote everything else to support. The second-look reward is a reflection, a bridge object, or a state indicator — one, not a clutter.

**Centerline spine, then break symmetry** — emotion: a single dominant axis (lane stripe, the Christmas Tree, a dividing wall) gives the eye a rail and makes even a chaotic frame readable; breaking it the instant one car noses ahead reads as momentum. — seen: Anderson centers for instant legibility; Bong breaks balanced staging to show a power shift. — *in a keyframe*: build one head-on symmetric "breath" panel — both cars mirrored across the centerline, Tree dead-middle, equal negative space (tag **Establish/Pressure**, hold longest). On the next panel, break the mirror — hero a nose ahead, rival shoved soft, centerline slid off the third (tag **Shift/Impact**). Use the pair exactly once, at the launch; overusing symmetry kills the speed.

**Functional vs decorative clutter — the evidence test.** Keep an object only if it does at least one of: (1) **indicator of state** (replaces the face — tach in the red, white knuckles), (2) **stage of action** (advances the beat — front wheel 7" off the line = pre-stage), (3) **bridge to the next panel** (sets up a match-cut or a reach). Dead detail — coffee cup, mirror dice, dashboard sticker — shows no state, advances nothing, bridges nowhere. Cut it. "Each object is a clue" (Park); functional clutter *loads* the frame, decorative clutter *weakens* it.

**Angle encodes the beat** (no face, so the angle *is* the emotion): low / ground-level = power, threat, launch force (**Power, Impact**); eye-level lateral = parity, rivalry stated (**Establish**); high / top-down = judgment, smallness, aftermath (**Aftermath, Exit**).

---

## 7. From keyframe to image-gen prompt

A keyframe card becomes a still prompt by following the universal skeleton (`universal-rules.md` U1) with weight at the start (U2). **Lead with framing + lens + light + palette + anchor object** — these are the load-bearing tokens for a still; the model puts most attention on the first 30-40% of tokens.

Panel → prompt skeleton:

```text
[Framing + lens]           e.g. "Low bumper-height macro, 24mm, shot past a blurred roll-cage bar"
[Anchor subject + state]   the ONE object at its threshold: "rear slick sidewall wrinkling at the contact patch"
[Depth clauses, 3 jobs]    FG frame / obstruct · MG subject / act · BG stake / rival
[Motion-as-still cue]      "sharp subject against horizontal motion-blurred background, foreground reference elongated into a light-streak, rear rim spokes smeared to a disc"
[Light + palette]          one motivated source + direction + surface it rims; concrete colors; amber-ban
[Texture]                  "fine film grain heaviest in shadow, halation on the practicals, one anamorphic flare, crushed blacks"
[Face rule]                "no face" — or "driver a featureless silhouette against blown rival headlights, only knuckle highlights legible"
[Aspect / no-speed-up note]  "no speed-ramp; build velocity into the static frame"
```

Rules that keep the still honest:

- **Name the differential blur explicitly.** Models default to over-clean stabilization. Write "motion blur on background, fast-shutter look, sharp subject, rim spokes smeared to a disc." Equal/no blur is the most-faked and most-failed cue (anti-fake firewall, §4 speed-budget).
- **Keep faces out or fragmented.** Convert any would-be face to silhouette / contre-jour with a rim and one glint. No features.
- **Render audio as physical consequence, never as a named sound.** "Loud engine" is banned filler (`dramaturgy.md` §2) — prompt "heat-haze warp off the headers, exhaust flame, chassis squat, sidewall wrinkle" instead.
- **Anti-sterile guard.** If the panel could be captioned "clean," "beautiful lighting," or "high quality," it has failed — name the grain, the bloom, the crushed black, the one specular hit (`universal-rules.md` U12). One motivated source dominates; ~70% of the frame stays unlit (`camera-lighting-vocabulary.md` §5-7).

Cross-link the vocabulary file for every framing/lens/light token. Then **the keyframe is the locked first frame**; hand it to `seedance.md` / `kling.md` / `veo.md` with the single dominant move (one per 5s — `camera-lighting-vocabulary.md` §2) to animate it. Name in the model syntax: "low bumper-height camera, asphalt streaking, motion blur on background, sharp subject, no speed-up."

---

## 8. Worked keyframe board for a 30s race spot

A Sportsman-tree drag run, cold palette, no faces — ~13 panels using the card. This is the deliverable template the user fills: each row is a compressed keyframe card, format-C compatible (`Time | Shot | Function | Action | Camera | Light | Sound | Emotion`). Cut length collapses toward the green, holds on the wrinkle, then accelerates to the finish.

| Time | Shot (anchor) | Function | Action (state-change + motion-as-still) | Camera (implied move) | Light (cold) | Sound | Emotion-via-object |
|---|---|---|---|---|---|---|---|
| 0.0–2.5 | Slick into water box | Establish | Front tyre breaks mirror-still water; bulb reflected in the sheet | locked macro, low (held) | steel-blue, wet specular | idle lope, water trickle | coiled stillness |
| 2.5–5.0 | Burnout wall | Power | Rear erupts a smoke wall, car straining on line-lock; smoke backlit luminous | ground-level wide (burnout-cam) | cyan backlight through smoke, red tail bleed | lope → tyre scream | leashed force |
| 5.0–6.5 | Pre-stage bulb + front tyre | Pressure | Tyre creeps, top blue bulb lights, beam line as graphic spine | CU, static | blue glow on wet metal | lope thickens | held breath |
| 6.5–8.0 | Stage bulb + knuckles | Pressure | Second bulb lit, knuckles whiten on the trans-brake (depth: bulb BG, hand FG) | CU, depth layers, static | two blue bulbs, crushed black | idle DROPS to silence | point of no return |
| 8.0–9.5 | Amber stagger (1 of 3) | Pressure → Shift | First amber lights; foot pre-loading the pedal | tree-cam, snap-tight | amber pulse (sole warm, toxic) | vacuum of silence | trigger tension |
| 9.5–10.3 | Held breath frame | Pressure | Staged car dead-still, last amber, tach needle the only tremor | symmetric, locked (HOLD) | amber flare, steel rim | silence (the pause) | loaded spring |
| 10.3–11.6 | LAUNCH lunge | Impact | Both cars squat, front wheels lift, green flares, asphalt smears back | low bumper-POV, fisheye (smear) | green flash + hard flare | BANG, leads pic 3fr | release / violence |
| 11.6–13.5 | **Slick wrinkle** (HOLD) | Detail / Reaction | Sidewall folds and hooks at the contact patch; speed-ramp pause, partial blur | macro slick-cam (frozen ramp) | hard side light, smoke bloom | tyre bite (near-silent) | physics felt |
| 13.5–15.5 | Cabin shake | Pressure | Needle buried in red, mirror doubled by vibration, glass strobing | hard-mount interior (tremor) | strobing exterior, red needle accent | rising rev, gear stab | strain |
| 15.5–18.5 | Bumper POV | Pressure | Asphalt tears under the nose, lane stripes strobe to a vanishing point | low forward hood-cam, 24mm (radial smear) | streaked specular, mercury-white | doppler build | commitment |
| 18.5–22.5 | Joust / parallel pass | Power | Rival closes head-on, offset; cone huge-blurred on the opposite edge | chase tracking + joust (closing) | streaked roadside lights, red tail accent | engine duel, doppler swell | rivalry |
| 22.5–26.5 | Finish | Impact | Slicks blown-up and distorted, two cars inches apart across the line | slight high, finish-cam | cold-white finish pool | sound peak → cut | margin |
| 26.5–30.0 | Hand unclenches / chute | Aftermath / Exit | Fingers release the wheel; chute bloomed, smoke drifting through a beam | ECU then rear wide (settling) | single cold rim, residue haze | hard cut to silence, one breath | consequence / release |

Notes on the board: the 9.5–10.3 held panel is the single most-held still — the pause that triggers the bang. The launch is *not* one hero frame; in a fuller cut, fan 10.3–11.6 into a 6-9 panel micro-burst (§3) — that expansion is what carries the 13 compressed rows up to the ~18-26 panel count of §3. The wrinkle is the one place time expands inside the loud section. No two bang-clusters touch; every burst is separated by a held quiet panel. End on consequence, held ~2s — the vacuum is the punctuation.

---

## 9. Checklist: does this keyframe earn its place

Run before every panel ships. Drop the panel if it fails.

- [ ] **Function tag named.** One of Establish / Reveal / Power / Pressure / Detail / Reaction / Shift / Impact / Aftermath / Exit. No tag → drop it.
- [ ] **One readable beat**, sayable in one sentence. If you cannot caption it (setup / commitment / mistake / recovery / proof-of-speed / result), it is a *fantik* — drop it.
- [ ] **Emotion-via-object** present — the feeling a face would carry, frozen in a knuckle / needle / pedal / smoke / sweat-bead (§5). No state-change, no emotion → drop it.
- [ ] **Speed or drama cue** present — ≥1 of the six motion-as-still cues (smear / partial blur / streak / vector / sharp-blur / held stillness), or a deliberate held-still pause. "Fast" panels carry ≥3 of the five speed cues (§4).
- [ ] **State-change, not static fetish** — the object crosses a threshold (idle→flare, clean→smoked, planted→lifting). No idle anatomy, no parked gear-lever.
- [ ] **Three depth layers**, each with a stated job (FG frame/obstruct, MG subject, BG stake). One focal point; every other object is evidence, not decoration.
- [ ] **Implied camera named** — the move this still is the first frame of, physically mountable on the car (no god-angle render).
- [ ] **Cold palette held** — steel/cyan/magenta/mercury-white, red and green as accents only, amber ≤15% and point-source (toxic, never cozy). One motivated source, ~70% unlit, one hard specular hit. Texture named (grain, halation, one flare), not "clean."
- [ ] **No face**, or a face fragmented past usefulness (silhouette / reflection only).
- [ ] **Sound cell filled** even though the panel is a still — what audio underlies the held frame, where the cut bites (`dramaturgy.md` §11).
- [ ] **Earns its density slot** — a held beat gets one panel, a bang gets a burst; the board reads as an accelerating tachometer on mute (§3).

If a panel survives all ten, it is an *opornyi kadr*, not wallpaper. Hand it to `seedance.md` / `kling.md` / `veo.md` as the locked first frame.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/animatic-keyframes.md -->


<!-- SOURCE_FILE_START: skills/video/references/camera-lighting-vocabulary.md -->
# SOURCE FILE: `skills/video/references/camera-lighting-vocabulary.md`

# Camera, lighting, color, sound vocabulary

Use precise production language. "Cinematic" is not a direction. "35mm, slow push-in, warm window key from frame-left" is.

## Contents

1. Framing
2. Camera movement
3. Lens language
4. Light sources
5. Light direction
6. Light quality
7. Color discipline
8. Sound categories
9. Blocking language
10. Translating uncommon terms
11. Transition vocabulary

---

## 1. Framing

- extreme wide shot
- wide shot
- medium wide
- medium shot
- medium close-up
- close-up
- extreme close-up
- macro insert
- over-the-shoulder
- POV
- profile
- silhouette
- low angle
- high angle
- top-down
- dutch angle
- locked-off frame

## 2. Camera movement

- static camera
- slow push-in
- fast push-in
- pull-back
- tracking shot
- lateral tracking
- handheld micro-shake
- whip pan
- snap zoom
- rack focus
- tilt up
- tilt down
- orbit
- gimbal glide
- dolly-in
- dolly-out
- crane shot
- aerial shot
- Hitchcock zoom (dolly-zoom)
- dive (camera plunges downward)
- FPV (drone first-person flight)
- one-take shot
- bullet time
- bounce speed ramp (speed up - slow down - speed up)

Universal rule. Pick one dominant move per 5-second shot. Layer one subtle secondary move at most. The popular techniques (one-take, dolly zoom, FPV, bullet time, bounce speed ramp) still need a subject, a start point and an end point — the name alone is not a direction.

## 3. Lens language

- 24mm. Wide, immersive, exaggerated proximity.
- 35mm. Natural documentary.
- 50mm. Intimate, human perspective.
- 85mm. Portrait, compressed background.
- 100mm macro. Texture, detail.
- anamorphic 40mm. Cinematic widescreen.
- shallow depth of field.
- deep focus.
- compressed telephoto background.
- distorted wide-angle proximity.

## 4. Light sources

- cold refrigerator light
- harsh overhead kitchen LED
- moonlight through window
- neon sign spill
- phone screen glow
- car headlights
- streetlamp backlight
- fluorescent office light
- practical lamp
- candlelight
- monitor glow
- emergency red light
- sodium vapor street light
- police strobe
- theater house lights
- stage spotlight
- campfire flicker
- sunset through blinds
- under-counter kitchen LED

## 5. Light direction

- top light
- side light
- backlight
- underlight
- frontal soft light
- rim light
- bounce fill
- window key light
- motivated practical (the light source is visible in frame)

## 6. Light quality

- hard shadow
- soft diffused
- low-key lighting
- high contrast
- silhouette
- specular highlights
- volumetric haze
- steam catching backlight
- wet reflections
- desaturated palette
- cold blue-gray grade
- teal shadows
- clean commercial lighting
- gritty naturalistic
- blown-out overexposure
- crushed blacks

## 7. Color discipline

Define palette with concrete colors. Never write "cinematic colors."

Bad. "cinematic colors."
Good. "Cold blue-gray shadows, desaturated skin tones, greenish fridge spill, black negative space, no warm yellow tones."

If the user bans a color, obey it strictly. Repeat the ban in every clip of a multi-clip sequence.

Common palettes.

- Fincher cold. Cold blue-gray shadows, desaturated skin, black negative space.
- Deakins natural. Warm amber interiors, cool blue exteriors, clean contrast.
- Wong Kar-wai. Saturated warm reds, deep greens, hazy practicals.
- Glazer neon. Black, one dominant neon hue (magenta or teal), hard edges.
- Commercial creamy. Warm creams, soft pastels, clean whites, no harsh blacks.
- Safdie chaotic. Mixed sources, overlapping color temperatures, urban neon spill.

## 8. Sound categories

Even if the model does not generate audio, sound description helps structure rhythm.

Ambient.

- room tone
- distant city ambience
- rain on tin roof
- wind through leaves
- fridge hum
- fluorescent buzz
- traffic wash

Body and action.

- breath
- footsteps
- fabric rustle
- fork clink
- door hinge
- key in lock
- zipper
- stomach growl

Dramatic events.

- sudden silence
- low bass hit
- wet thud
- glass break
- distant thunder
- car door slam
- final sound cue before cut to black

For Veo, wrap sound in syntax. `Audio:`, `SFX:`, or `(parenthetical description)`.
For Seedance 1.5+, include sound in the prompt body.
For Kling, sound descriptions help rhythm planning but audio is not generated.

## 9. Blocking language

Describe physical movement with six inputs.

- Who moves.
- Where they start.
- Where they end.
- What object they touch.
- What they look at.
- What their body reveals emotionally.

Example.

```text
The man stands in the kitchen doorway, shoulders collapsed. He slowly approaches the refrigerator, opens it with hesitation, leans into the cold light, then freezes when he sees the empty shelves.
```

This beats "a sad man goes to the fridge" because it is playable by the model frame by frame.

## 10. Translating uncommon terms

Common terms (section 2) work by name. For rarer cinematography terms, keep the term **and** translate it into observable change, or the model guesses:

```text
Term + target subject + visual change + foreground/background relationship + direction or speed
```

Example.

```text
Rack focus: shift focus smoothly from the leaves in the foreground to the person
in the background. The leaves gradually blur while the person's face changes
from soft to sharp.
```

Same pattern for snorricam, contra-zoom variants, tilt-shift, split diopter, speed ramps with specific curves. Numeric aperture and focal-length values are allowed, but the intended visible result phrased in words is what actually steers the model.

## 11. Transition vocabulary

Named transitions every current model understands to some degree (Seedance 2.5 honors them explicitly — templates in `seedance-25.md` §10):

- **natural cut** — plain edit point, model picks the framing change
- **fade in / fade out** — to or from black
- **dissolve** — cross-fade, 1-2 seconds of overlap
- **white flash / black flash** — one-frame blast, impact punctuation
- **wipe** — new frame pushes the old one off
- **occlusion mask** — a foreground object covers the lens, the new scene is revealed behind it
- **match cut** — similar shape or motion bridges two scenes (moon → latte)
- **action cut / whip pan** — cut hidden inside fast motion with motion blur
- **motion relay** — subject exits frame A mid-move and lands in frame B continuing it
- **zoom-through** — camera dives through a pupil, keyhole or window into the next scene
- **ink-wash dissolve** — stylized bleed, common in guofeng / animation work

Rules of use. Name the transition and the exact moment it fires. One transition type per cut. When the choice is open, delegate: "choose the most suitable from [natural cut / occlusion mask / match cut] for the style of this film."

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/camera-lighting-vocabulary.md -->


<!-- SOURCE_FILE_START: skills/video/references/dramaturgy.md -->
# SOURCE FILE: `skills/video/references/dramaturgy.md`

# Dramaturgy, detail, montage

This is the mandatory layer. A beautiful frame without dramaturgy is wallpaper. Every prompt built by this skill must pass the dramaturgy check before it is sent to the user.

## Contents

1. Core law. Scene formula
2. Second law. Details intensify emotion
3. The three-jobs rule (what every shot must do)
4. Walter Murch Rule of Six
5. Blocking as choreography of desire
6. Staging controls subtext
7. Camera must have a reason
8. Spatial clarity beats montage hysteria
9. Environment plays
10. Three-layer storyboard method
11. Shot card template (14 fields)
12. Rhythm ladder
13. One-anchor principle
14. Worked example
15. Dramaturgy check before sending any prompt

---

## 1. Core law. Scene formula

A scene exists only when all five elements are present.

```text
Scene = hero's desire + obstacle + space geometry + controlled gaze + editing rhythm
```

If any element is missing, the scene collapses into decoration.

- Desire. What does the character want right now in this specific second.
- Obstacle. What blocks them. Object, person, fear, distance, rule.
- Space geometry. Who stands where. Who has the power position. Which direction is threat, which is escape.
- Controlled gaze. Where the viewer's eye is forced to look, one focal point per frame.
- Editing rhythm. How long each shot lives, where the pause lands, where the cut bites.

Before writing a prompt, name each of these in one sentence. If you cannot, the scene is not ready.

## 2. Second law. Details intensify emotion. Laziness kills the prompt.

The scene formula tells you **what a scene is**. The Details Law tells you **how every shot must be written**. Skip it and even a perfect dramaturgical structure produces mush on screen.

> Every shot owns three concrete physical details: one environmental pressure, one physical micro-action, one sound or visual motif anchor.

### The three-detail rule

For each shot in the storyboard or prompt, before it is sent, the writer commits to:

1. **Environmental pressure.** A physical fact about the space that carries the emotion. Cold refrigerator light. Wet asphalt. Flickering ceiling tube. Steam from the kettle. Rain on one specific windowpane. A buzzing AC unit. Tight corridor walls. Mirror reflection. (See §9 — Environment plays.)
2. **Physical micro-action on the body.** The emotion translated into the actor's body. Jaw locks. Knuckles whiten. Lips press flat. Eyes drop a quarter-inch. He swallows hard. Fingers curl against the doorframe. The actor's body is the only place where feelings render — names of feelings do not.
3. **Sound anchor or visual motif.** A recurring perceptual hook tied to the spine of the piece. Stomach growl repeated three times. Reflection in dark glass on every transition. The same musical sting at every Crack beat. The clock's second hand. Footsteps in an empty corridor.

A shot with zero of these is filler. A shot with one is thin. Strong shots carry all three. The writer's job is to do this work — the model cannot infer it.

### What is banned

Words that mark a writer being lazy. Each one is a placeholder for absent detail.

- "cinematic", "professional", "high quality", "masterpiece", "stunning", "epic", "amazing"
- "beautiful lighting", "dynamic camera", "intense moment", "powerful scene"
- "he is sad", "she is angry", "he is afraid" — emotions named without a body

Replace each with concrete physical facts. If a writer cannot do that, the scene is not yet thought through.

### How details map to dramaturgy

Each layer of dramaturgy has a default detail register:

- Scene formula → environmental pressure (the geometry and atmosphere of the obstacle).
- Three-jobs rule → physical micro-action (the body shifts when emotion / action / pressure shifts).
- Five anchors → sound and visual motif (the motif is the anchor, the final image carries the motif).

If a shot's detail set does not match its dramaturgical function, the function will not land on screen.

## 3. The three-jobs rule

Every shot must do at least one of three things. If it does none, delete it.

- Change emotion (in hero, viewer, or the dynamic between characters).
- Advance action (new physical event, new information, new position).
- Increase pressure (stakes rise, clock ticks, space tightens, witness appears).

"Beautiful establishing shot" is not a job. "Beautiful hero shot of product" is not a job. Either the frame works for one of these three, or it is a fantik (wrapper without candy).

## 4. Walter Murch Rule of Six

From the editor of Apocalypse Now, The Godfather Part II, and The English Patient. The priority order when deciding where to cut. Each item is weighted heavier than the sum of everything below it.

1. **Emotion (51%).** Does the cut honor the emotional truth of the moment. What does the viewer feel now vs. what they should feel next.
2. **Story (23%).** Does the cut advance story or reveal character.
3. **Rhythm (10%).** Does the cut fall on a musical beat of the scene.
4. **Eye-trace (7%).** Where is the viewer's gaze at the moment of the cut. Does the new shot receive that gaze naturally.
5. **2D plane (5%).** Does the cut respect the axis of screen direction.
6. **3D space (4%).** Does the cut respect the geometry of the real location.

Practical consequence. Cutting for "динамика" (pace for its own sake) sits at item 3. If you cut there without serving items 1 and 2, the result is TikTok-ad for the attention-deficit.

## 5. Blocking as choreography of desire

Blocking is not "where the actor stands." Blocking is a visual answer to "what does the character want and from whom."

For every character in the scene, name.

- What they want now.
- Who or what they move toward.
- Who or what they move away from.
- Whom they corner.
- To whom they yield space.
- What gesture reveals the hidden desire.

Bad. "He stands near the window."
Good. "He edges toward the window but his shoulder stays angled back toward her, as if the conversation still holds him."

## 6. Staging controls subtext

Staging is the arrangement of people, objects, and camera inside the frame. Before dialogue, staging already tells the conflict.

Power signals in staging.

- The standing character dominates the seated one.
- The character in the doorway controls the room.
- The character behind glass or in reflection is psychologically distant.
- The character in shadow carries threat or grief.
- Negative space around a character signals isolation.
- Tight framing signals suffocation.
- Shared frame without eye contact signals broken intimacy.

Spielberg, Kubrick, Iñárritu often build entire scenes where the staging states the conflict before a line is spoken.

Before writing a prompt, name the power dynamic the staging reveals.

## 7. Camera must have a reason

Fincher rule. Every camera movement answers "what changed?" If the answer is nothing, the camera is static.

Reasons for camera movement.

- A character made a decision and the camera follows the shift.
- New information arrived in the frame.
- Pressure escalated and the camera tightens.
- The character looked, and the camera reveals what they saw.
- A gesture pulled focus, and the camera rack-focused.
- The space changed (door opened, someone entered).

Bad. "Cinematic gliding camera movement."
Good. "Push-in starts on 'I don't know' and stops on her jaw locking."

## 8. Spatial clarity beats montage hysteria

Spielberg principle. Even in chaos, the viewer must know.

- Where the hero is.
- Where the threat is.
- Which direction is escape.
- Which direction is decision.

High craft means fast, nervous, and still readable. Random whip-pans and strobe cuts without geography destroy drama. The fastest action scenes in cinema (Spielberg, Miller, early Bay) are built on a clear geometric map maintained through every cut.

Before writing a fast-cut sequence, sketch the geography in one sentence. "Hero moves left-to-right. Threat enters from the top of the frame. Exit is off-camera right."

## 9. Environment plays

Kurosawa principle. Weather and environment are characters. They amplify state.

Translate this to a short video by leaning on one environmental pressure.

- Flickering fluorescent light signals decay, bureaucracy, dread.
- Rain on a window signals grief withheld.
- Steam from a kettle signals suppressed anger.
- A buzzing air conditioner signals dissociation.
- Wet asphalt at night signals guilt.
- A tight corridor signals the walls closing in.
- A mirror or glass surface signals self-reckoning.
- Overhead cold office light signals judgment.

Pick one environmental pressure per scene and let it carry the emotion.

## 10. Three-layer storyboard method

Build storyboards in three layers, in this order. Skipping a layer produces pretty but empty output.

### Layer 1. Dramatic beats

For a 60-90 second piece, a reliable beat map.

```text
0-5s    Hook.        Hero already in tension. No setup. Problem on screen.
5-15s   Context.     Where we are. Who is near. What is at stake.
15-30s  Pressure.    Hero tries to hold control.
30-45s  Crack.       A detail appears that breaks the hero's position.
45-60s  Acceleration. Cuts shorten. Breath tightens.
60-75s  Impact.      Decision, break, confession, or action.
75-90s  Aftermath.   Brief silence or visual residue.
```

Adjust for 30s or 15s by compressing proportionally. Never skip the Crack or the Impact.

### Layer 2. Shot functions

Tag every shot with a function. Same taxonomy as in role-modes.md, expanded with Power.

- **Establish.** Where we are.
- **Power.** Who controls the scene right now.
- **Pressure.** What is pushing down on the hero.
- **Detail.** Object, hand, phone, eye, drop, receipt, door. Macro anchor.
- **Reaction.** Face after the event.
- **Shift.** Inner change made visible.
- **Impact.** The decisive frame.
- **Aftermath.** Emptiness after action.
- **Exit.** Final image the viewer carries out.

This is cinema grammar. Everything else is decorative wallpaper.

### Layer 3. Editing rhythm

Not random mincing. A rhythmic staircase.

```text
long - shorter - shorter - pause - impact
```

Example internal structure of an 8-10 second montage.

- 4s. Wide. Hero enters.
- 2s. Medium. Hero notices the object.
- 1s. Close-up. Eyes.
- 12 frames (0.5s). Macro insert of the object.
- 8 frames (0.33s). Hand.
- 6 frames (0.25s). Detail / sound cue.
- 2s. Sudden silence.
- 1s. Decision.

Rule. The pause before the impact is more important than the speed of the cuts. Without a pause, speed becomes visual meat grinder.

## 11. Shot card template

For each shot in a storyboard, fill every field. Missing fields reveal missing direction.

- **Shot ID.** 01, 02, 03
- **Beat.** What changes in the story here.
- **Emotion.** Fear, shame, anger, guilt, resolve, relief, etc.
- **Frame.** wide / medium / close-up / macro insert
- **Composition.** Center, edge, negative space, reflection, silhouette, foreground obstruction.
- **Camera.** Static, push-in, handheld, tracking, whip-pan.
- **Movement reason.** Why the camera moves here. Answer "what changed?"
- **Action.** Exact physical event.
- **Eye trace.** Where the viewer's gaze should land in the first 0.3s.
- **Duration.** 0.5s, 1s, 3s.
- **Cut type.** match cut, smash cut, cut on action, J-cut, L-cut.
- **Sound.** Breath, bass hit, street noise, phone ring, silence.
- **Light / color.** Cold, contrast, flicker, shadow, specific palette.
- **Production note.** Prop, location, actor direction.

If a shot card has empty fields, fill them or drop the shot.

## 12. Rhythm ladder

Drama rhythm is not uniform. It is stepped.

### Slow-burn drama
4s, 4s, 3s, 2s, 1s, pause, 2s.

### Commercial product arc
3s, 2s, 1.5s, 1s, 0.5s (product macro), 2s (hero shot).

### Anxiety build
2s, 1s, 1s, 0.5s, 0.5s, 0.3s, pause, 1s.

### Impact scene
pause, 0.2s (flash), 2s (aftermath in stillness).

Always insert at least one pause before the biggest cut.

## 13. One-anchor principle

For any short dramatic piece, commit to exactly five anchors. No more.

- One main emotion.
- One visual motif.
- One anchor object.
- One break.
- One final image.

Example.

- Emotion. Guilt.
- Motif. The hero keeps being reflected in glass surfaces (window, phone screen, elevator door).
- Anchor object. A phone with one unread message.
- Break. The hero deletes the message.
- Final image. The hero's face stays reflected in the darkened phone screen.

This set can be storyboarded, prompted, and cut together into something that carries real weight. It beats stacking "cinematic, professional, high quality, masterpiece" forever.

## 14. Worked example. Guilt, 30 seconds

### Five anchors

- Emotion. Guilt.
- Motif. Reflections in glass.
- Anchor object. Phone with unread message.
- Break. He deletes it.
- Final image. His face ghosted on the dark phone screen.

### Layer 1. Dramatic beats

- 0-3s. Hook. Phone buzzes on a dark desk. His face lit from below.
- 3-10s. Context. Small office after hours. Empty cubicles. Cold fluorescent. His reflection in the monitor.
- 10-18s. Pressure. He stares at the message preview. His jaw tightens. Hand hovers.
- 18-22s. Crack. He starts to type. Stops. Deletes character by character.
- 22-26s. Acceleration. Tight cuts. Finger. Screen. Eye. Breath. Window reflection.
- 26-28s. Impact. He taps Delete Conversation. One tap. Silence.
- 28-30s. Aftermath. Screen goes black. His face remains reflected in the dark glass.

### Layer 2. Shot functions (selected)

- Shot 03. Establish. Empty office.
- Shot 05. Power. He is alone. The room looms.
- Shot 07. Detail. Phone screen close-up.
- Shot 09. Reaction. His face, jaw tightening.
- Shot 11. Shift. Hand hesitates over keyboard.
- Shot 13. Impact. Thumb taps Delete.
- Shot 14. Aftermath. Dark screen, his ghosted reflection.

### Layer 3. Rhythm (final 10 seconds)

- 2s. Finger hovers over Delete.
- 1s. His face.
- 0.5s. Thumb.
- 0.5s. Screen confirmation prompt.
- 1s. His eyes.
- 0.5s. Thumb taps Delete.
- 3s silence. Screen goes black.
- 1.5s. His reflection on the dark phone.

Now each beat can be translated into a model-specific prompt using `references/seedance.md`, `references/kling.md`, or `references/veo.md`.

---

## 15. Dramaturgy check before sending any prompt

Run this six-point check before returning the final prompt to the user.

1. Is the scene formula complete? (desire + obstacle + geometry + gaze + rhythm)
2. Does every shot pass the three-detail check? (environmental pressure + physical micro-action + sound or visual motif)
3. Does every shot do one of the three jobs? (change emotion, advance action, increase pressure)
4. Is there a motivated reason for every camera move?
5. Is the spatial geometry readable?
6. Are the five anchors named? (emotion, motif, object, break, final image)

If any answer is no, fix before sending. Step 2 is the most violated.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/dramaturgy.md -->


<!-- SOURCE_FILE_START: skills/video/references/fixes-and-skeletons.md -->
# SOURCE FILE: `skills/video/references/fixes-and-skeletons.md`

# Fixes, checklist, and cross-model skeletons

## Contents

1. Continuity checklist (before final output)
2. Common failures and fixes
3. Cross-model prompt skeletons
4. Default negative constraints
5. Prompt compression order
6. Output format templates

---

## 1. Continuity checklist

Before sending a prompt to the user, verify.

- Same character across shots (face, body, hair).
- Same clothes across shots, exactly named.
- Consistent location logic.
- Object state progression makes sense (sausage in fridge -> on plate -> on fork -> on floor).
- No unwanted extra characters.
- No unwanted text or subtitles.
- No unwanted logos.
- Consistent age / body / face.
- No impossible hand-object action.
- No vague camera instructions ("cinematic camera").
- No vague lighting instructions ("beautiful light").
- No random stacking of director references.
- No contradictions.
- Palette is defined with concrete colors.
- Final image is explicitly stated.

If any item is missing, fix before sending.

---

## 2. Common failures and fixes

### One continuous take instead of montage

Fix.

```text
This must be a multi-shot sequence with visible hard cuts. Do not generate a single continuous take. Each beat uses a different angle and framing.
```

For Seedance specifically, add explicit `Cut to.` or `Camera cut to.` markers in the prompt body.

### Character face changes between shots

Fix.

```text
Preserve the exact character in every shot. Same face shape, same eye color, same hair, same clothing, same expression style. [repeat the full identity block]
```

For Kling. Use Element Binding with 3-4 reference images (front, side, three-quarter).

### Object disappears mid-scene

Fix.

```text
Track the object continuously. The same object remains visible or clearly implied in every beat.
```

Describe the object's state progression in one sentence. "The sausage moves. fridge -> pot -> fork -> floor."

### Weak drama. Scene feels flat.

Fix.

```text
Play the scene with full emotional seriousness. Treat the ordinary object as if it carries life-or-death meaning. No comedy pacing. No detached observation.
```

### Messy random cuts in fast montage

Fix.

```text
Use fast montage with clear readable action per cut. Every cut shows a distinct detail. face, hand, object, reaction, impact. Each cut must have a visible function.
```

### Dialogue too fast (Veo)

Fix. Cut the line. 8 seconds max of spoken text. Test by reading aloud at normal pace.

### Melting hands / extra fingers

For Kling. Add to negative field.

```text
distorted hands, extra fingers, melted face, deformed
```

For Seedance and Veo. Use positive phrasing.

```text
anatomically correct hands, clean finger separation, realistic proportions
```

### Lighting drifts between clips

Fix. Name the dominant source and direction and repeat it verbatim in every clip.

```text
Lighting constant. Cold fridge light as key from frame-right. Warm window spill as rim from frame-left. Same contrast ratio in every shot.
```

### Model ignores camera instruction

Fix. Move camera to the front of the prompt.

Bad. "A man opens a fridge. The camera is a slow push-in."
Good. "Slow 50mm push-in. A man opens the fridge."

### Weird AI-looking faces

Fix. Avoid style words like "hyperrealistic 8k masterpiece." These push the model into AI-art territory. Use production language instead.

```text
Shot on 50mm, natural skin texture, motivated lighting, documentary feel.
```

### Twins / face-blending in multi-person scenes

Two or more characters converge into near-identical faces, or background extras clone the hero.

Fix. Bind each subject to its own reference individually (see `universal-rules.md` U13), then force differentiation.

```text
Their movements are not synchronized. Clothing colors, hairstyles, and facial features must all be distinct. No identical clones in the background.
```

### Objects or characters appear too early in an extension

When extending a clip backward (prepending a beginning), elements that belong to the source video leak into the past.

Fix. Flag them explicitly.

```text
<Materials that should appear only after the source video begins> must not appear early in the backward extension.
```

For forward extensions, the standard clause: "prohibit rigid cutting, prohibit objects appearing out of thin air."

### Random subtitles or unwanted background music

Fix. Ban directly and repeat the ban at the end of the prompt.

```text
Pure video, no subtitles, no background music.
```

On Seedance 2.5 and Veo this is reliable. On Seedance 1.x/2.0 and Kling, also avoid mentioning any on-screen text or score you do not want — mentions summon them.

---

## 3. Cross-model prompt skeletons

### Seedance

```text
Subject. [identity block].
Motion. [one clear present-tense action].
Camera. Shot 1. [framing, lens, movement]. Cut to. Shot 2. [framing, lens, movement]. Cut to. Shot 3. [framing, lens, movement].
Environment. [location, time, props].
Lighting. [source, direction, quality, color].
Style. [realism level, genre reference].
Audio. [ambient, SFX]. (1.5+ only)
Continuity. [what must remain constant].

--resolution 1080p --duration 5 --camerafixed false
```

### Kling text-to-video

```text
[Subject with identity anchor]. [Subject movement]. Scene. [3-5 environment elements]. Camera. [one movement + lens]. Lighting. [source + quality]. Atmosphere. [mood].

Negative field. blurry, distorted hands, extra fingers, melted face, watermark, subtitles, jitter.
```

### Kling image-to-video

```text
Preserve [silhouette / feature / label]. [Camera movement, one lens]. [One or two motion verbs]. [Atmospheric cue, light change].

Negative field. blurry, distorted hands, melted face, jitter.
```

### Veo prose

```text
[Subject performing action] in [environment]. [Camera framing + lens + movement]. [Lighting direction + color]. [Style + mood + palette].

Audio: [ambient, SFX, music texture].
Says: [character] says, "[dialogue, max 8s of speech]."
SFX: [punctual sound events].

Duration: [4 / 6 / 8] seconds.
```

### Veo JSON

See `references/veo.md` section 6 for full schema.

---

## 4. Default negative constraints

Where negatives are supported (Kling field, Veo body text, Seedance 2.0 fragile).

```text
No subtitles. No on-screen text. No extra characters. No changing clothes. No changing face. No logos. No cartoon physics unless requested. No warm yellow tones unless requested. No random camera drift. No single-take when multi-shot is requested. No distorted hands. No extra fingers.
```

For Kling field. Rewrite as positive entities. "distorted hands, extra fingers, subtitles, logos, cartoon physics, random camera drift."

For Seedance 1.0. Invert all negatives to positive phrasings in the prompt body.

---

## 5. Prompt compression order

When a model performs better with shorter prompts (Kling 2.5 Turbo, Kling 1.6, any image-to-video), cut in this order.

1. Keep character continuity.
2. Keep story action.
3. Keep shot timecodes (where relevant).
4. Keep lighting.
5. Keep camera.
6. Keep editing grammar.
7. Keep sound.
8. Remove philosophy and meta-commentary.
9. Remove extra adjectives.
10. Remove director references.

The goal. Preserve the skeleton. Lose the perfume.

---

## 6. Output format templates

### Format A. Single prompt

One ready-to-copy prompt for one generation. Use the appropriate model skeleton.

### Format B. Multi-clip prompts

Sequence of self-contained prompts. Each one repeats the full continuity block. Label them `Clip 1 / 5`, `Clip 2 / 5`, etc.

Between clips, add a one-line note explaining how they cut together. "Clip 1 ends on his hand reaching into the fridge. Clip 2 opens on his hand already inside the fridge, same light."

### Format C. Storyboard (раскадровка)

Table with columns.

| Time | Shot | Function | Action | Camera | Light | Sound | Emotion |
|---|---|---|---|---|---|---|---|
| 0-1s | WS | Establish | Man walks to fridge | 35mm, slow push-in | Cold fluorescent overhead | Fridge hum | Exhaustion |
| 1-2s | MCU | Reveal | He opens fridge door | 50mm, static | Cold fridge light as key | Door seal pop | Anticipation |

Adjust row count to clip length.

### Format D. Prompt audit

Given a user prompt. Return six sections.

1. What works.
2. What breaks generation.
3. Missing direction (camera, light, continuity).
4. Continuity risks.
5. Model-specific mismatches (wrong syntax for the chosen model).
6. Stronger version. Rewritten prompt, ready to copy.

### Format E. Director treatment

For concept stage before any prompt is written.

- Core idea (one sentence)
- Emotional arc (three states)
- Visual motif (one recurring element)
- Rhythm (pace logic)
- Camera language (dominant grammar)
- Lighting (dominant source)
- Sound (texture)
- Ending image (final frame)

### Format F. Veo JSON

Structured scene-by-scene JSON. Use for complex continuity. See `references/veo.md` section 6.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/fixes-and-skeletons.md -->


<!-- SOURCE_FILE_START: skills/video/references/kling.md -->
# SOURCE FILE: `skills/video/references/kling.md`

# Kling reference (Kuaishou)

## Contents

1. What Kling is
2. Versions and element limits
3. **Kling 3.0 — multi-shot, native audio, 15s (read first if user is on 3.0)**
4. Prompt formula (1.x – 2.x)
5. Prompt length by model
6. Negative prompts (dedicated field, special rule)
7. Element Library and Element Binding (unique to 1.x – 2.x)
8. Motion Brush (unique)
9. Motion Control (2.6 Pro, unique)
10. Image-to-video rule
11. Failure modes and fixes
12. Skeleton and example

---

## 1. What Kling is

Strong at realistic physics, character animation, and consistency through reference images. Fast generation. Best for social-ready clips and repeat-character scenes.

**Kling 3.0** changed the model's positioning fundamentally — it now competes with Seedance on multi-shot output (up to 6 shots per generation) and with Veo on native dialogue and lip-sync. See section 3.

## 2. Versions and element limits

Kling models vary widely in how many distinct elements they can handle in a single prompt. Overstuffing produces melting faces, broken hands, or static motion.

- **Kling 1.6.** Simplified prompts. Keep it very simple.
- **Kling 2.1 Pro.** 1080p at 30fps. Motion Brush. End frame control.
- **Kling 2.5 Turbo Pro.** Maximum 3-4 distinct elements.
- **Kling 2.6 Pro.** 5-7 elements. Motion Control. Element Binding for character consistency.
- **Kling 3.0.** Multi-shot in one generation (up to 6 shots). Native audio with dialogue and lip-sync. 15s continuous output. Native 4K, up to 60 fps. Strongest character and scene consistency. Two tiers: v3/pro and v3/standard.
- **Kling 3.0 Turbo** (June 2026). Speed/price tier: audio included in base cost, noticeably better lip-sync on talking heads, 3-15s, but capped at 1080p — no 4K.
- **Kling 3.0 Omni** (June 2026). The reference-and-editing flagship (API alias `o3`): strongest input understanding, editing pipeline at 3-15s with 4K in/out, Elements 3.0 with voice binding (see section 7).

If in doubt about the user's version, ask. The prompting protocol differs between 1.x – 2.x (sections 4-9) and 3.0 (section 3).

## 3. Kling 3.0 — multi-shot, native audio, 15s

Kling 3.0 is a different beast. It understands cinematic intent, not just visual descriptions. Prompts read like scene directions, not object lists.

### What changed vs 2.x

| Capability | 1.x – 2.6 | **3.0** |
|---|---|---|
| Multi-shot in one generation | No (one continuous take) | **Yes — up to 6 shots** |
| Native audio | Limited / off | **Yes — dialogue, ambient, voice tone** |
| Lip-sync | No | **Yes — coherent across multi-character scenes** |
| Max duration | 5-10s | **Up to 15s** |
| Character labeling | Via Element Library + reference images | **Via in-prompt `[Character A: ...]` tags** (still supports references) |
| Cinematic language understanding | Partial | **Full — reads "shot-reverse-shot", "POV", "tracking shot", "macro close-up"** |

### Five-layer prompt structure

```text
Scene  →  Characters  →  Action  →  Camera  →  Audio
```

Write each layer as flowing prose with explicit labels.

### Anchor subjects early

Introduce every character and key object at the **start** of the prompt, before any shot description. Use unique consistent identifiers — the same label survives across all shots:

```text
[Character A: Exhausted Partner — late 40s, gray-streaked beard, navy peacoat, hollow eyes]
[Character B: Female Investor — early 30s, sharp blazer, calm posture]
```

Then refer to them as "Character A" / "Character B" inside shot descriptions. This locks identity better than re-describing the character each shot.

### Multi-shot syntax (think in shots, not clips)

```text
[Character A: ...]
[Character B: ...]

Master intent: tense negotiation in a glass-walled office at dusk.

Shot 1 (0-3s). Wide tracking shot. Character A enters frame from left, crosses to the table.
Shot 2 (3-6s). Profile close-up on Character A. He sets down a brown leather folder.
Shot 3 (6-9s). Shot-reverse-shot. Cut to Character B's face. She does not blink.
Shot 4 (9-12s). Macro insert on her hand tightening around a fountain pen.
Shot 5 (12-15s). Two-shot, low angle, both reflected in the glass wall behind them.

Camera. Slow, deliberate. Sony FX6 feel, 35mm and 85mm.
Lighting. Cold blue dusk through floor-to-ceiling windows. Single amber desk lamp.
Audio. Distant city ambience. No music. Footsteps on hardwood. Pen clicks on paper.
```

Each shot must answer: **framing + subject + motion**. Empty shot descriptions ("static frame, ambient mood") collapse into one continuous take.

### Dialogue protocol (P1-P4)

For any speaking scene, follow these four rules. The fal.ai guide calls them P1, P2, P3, P4.

**P1. Structured naming.** Use unique identifiers per character.
- ✓ `[Character A: Black-suited Agent]` and `[Character B: Female Assistant]`
- ✗ "[Agent] says... Then, he says..."

**P2. Visual anchoring before dialogue.** Bind dialogue to a unique action first.
- ✓ "Character A pulls a folded note from his pocket and reads aloud: 'It's not what you think.'"
- ✗ "Character A says 'It's not what you think.'" (no visual anchor → lip-sync drifts)

**P3. Voice tone in the tag.** Assign emotion / texture inline.
- ✓ `[Character A, raspy deep voice]: "We're out of time."`
- ✓ `[Character B, clear fearful voice]: "Don't open it."`
- ✗ `[Man]: "We're out of time."` (vague — model picks a generic voice)

**P4. Temporal control between lines.** Use linking words to prevent dialogue from merging.
- ✓ "Character A: 'I won't ask again.' **Immediately,** Character B: 'You don't have to.'"
- ✗ Two consecutive `[Character X]: "..."` lines with no transition (model overlaps them)

### Image-to-video on 3.0 — lock first, then move

The input image serves as the anchor for identity, layout, and on-image text. Keep the prompt short and motion-focused. Describe **how the scene evolves from the image**, not what is in the image.

```text
Preserve identity, wardrobe, and the storefront sign exactly.
[Character A: same person from the image]
Shot 1 (0-2s). She turns her head toward camera, exhales.
Shot 2 (2-5s). Slow push-in to a tight close-up. Wind catches her hair.
Audio. Distant traffic, wind through awnings, a soft bell from inside the shop.
```

### Cinematic vocabulary that 3.0 actually understands

Use these terms directly — the model treats them as instructions, not flavor:

- Framing: profile shot, three-quarter, macro insert, two-shot, OTS, POV, low angle, high angle, Dutch
- Edits: shot-reverse-shot, match cut, smash cut, J-cut, L-cut
- Camera moves: tracking, dolly, push-in, pull-out, whip pan, crane, handheld, orbital / 360 spin, Steadicam, drone-like aerial. Composites work: "pan right while tilting up".
- Lens feel: 35mm, 50mm, 85mm, 100mm macro, anamorphic 40mm
- Tempo words the model obeys: "ultra-slow motion" (2-3s feel), "slow and deliberate" (5-8s), "moderate" (3-5s), "quick snap" (1-2s); exact timing works too ("5-second dolly zoom").
- Angle carries emotion: low angle = dominance, high angle = vulnerability, eye-level = neutral. Pick per the power dynamic from `dramaturgy.md` §6, not at random.
- In the Kling app, Master Shot presets ("Move Forward and Zoom Up" etc.) are more stable than hand-written camera prose and save credits — prefer them for standard moves, prose for motivated ones.

### Default model choice

If the task hits any of these — **use Kling 3.0 over earlier Kling**:
- Multi-shot dialogue scenes
- 10-15s continuous narrative
- Lip-sync required
- Multi-character with distinct voices
- Image-to-video where text on the image must stay legible

Within the 3.0 family: talking heads and dialogue on a budget → **Turbo** (best lip-sync per dollar, audio included, 1080p cap); reference-heavy or editing work, 4K delivery → **Omni**; everything else → base 3.0.

For everything else (single clip, no dialogue, < 10s, character lock via reference images, Motion Brush) — older versions still work and are cheaper.

### API parameters (3.0, fal/official)

- `cfg_scale` 0-1, default 0.5. 0.3-0.4 = creative freedom, 0.7-1.0 = strict prompt adherence (product / explainer work).
- `duration` — per-shot durations must sum to ≤ 15s.
- `aspect_ratio` — 16:9 / 9:16 / 1:1.
- `generate_audio` — bool. There is no "no music" toggle: the model lays music even against a negative prompt. If you need clean audio, generate with audio off or strip the track in post.

## 4. Prompt formula (1.x – 2.x)

For 1.6, 2.1 Pro, 2.5 Turbo Pro, 2.6 Pro:

```text
Subject (with specific details)
+ Subject Movement (one clean verb phrase)
+ Scene (3-5 elements max)
+ Camera Language
+ Lighting
+ Atmosphere
```

Write as flowing prose. Kling 1.x – 2.x dislikes fragmented tag-style inputs.

For Kling 3.0, use the multi-shot structure from section 3 instead.

## 5. Prompt length by model

- 1.6. Keep it simple, minimal.
- 2.5 Turbo Pro. 3-4 elements max. 50-80 words.
- 2.6 Pro. 5-7 elements. 50-80 words.
- 3.0. Longer prompts welcome — multi-shot needs explicit structure (see section 3). Plan ~30-60 words per shot.
- Image-to-video (any version). 20-40 words. Shorter, motion-focused.

Long prompts on 1.x – 2.x = melted outputs. Compress ruthlessly. On 3.0, structure beats length.

## 6. Negative prompts (critical rule)

Kling has a dedicated negative prompts field. The field auto-interprets input as exclusion. Do not write "no X". Write the thing itself.

Bad. "no robots"
Good. "robots"

Bad. "no blurry faces, no distorted hands"
Good. "blurry faces, distorted hands, melted features"

Common effective negatives.

```text
low resolution, blurry, distorted hands, extra fingers, melted face, watermark, subtitles, logo, text overlay, jitter, shaking camera, deformed
```

Keep the list short. Long negative stacks reduce motion and detail.

## 7. Element Library and Element Binding (1.x – 2.x)

For character consistency across generations, Kling has an Element Library. Upload 3-4 reference images of the character from different angles.

Required angles.

- Front
- Side (profile)
- Three-quarter

Then in Image-to-Video settings, enable "Bind Elements" to lock features. This gives the AI a visual anchor that survives camera pans and light changes.

Source image rules.

- 1080p or higher.
- Even lighting. Avoid hard shadows. The AI can mistake them for permanent facial features.
- No text or watermarks.
- Clean uncluttered background.
- Centered subject.
- Well-contrasted.

For Kling 3.0 — Element Library still works, but the in-prompt `[Character A: ...]` labels (see section 3) are usually enough on their own.

### Elements 3.0 (Omni)

On 3.0 Omni the element system got deeper:

- A character element takes either a **3-8s video** (the model extracts both appearance and voice) or up to **4 multi-angle stills** (front, three-quarter, profile, back), plus optional **voice binding** (5-30s audio clip). Once bound, the voice belongs to the subject — do not re-describe it in the prompt.
- Define a character / product / location **once** as an element, then tag it in prose: `@Grace picks up the folder`. The prompt carries only action and camera; identity lives in the element.
- Holds 3+ distinct characters in frame without feature blending — but only if **each** has its own element.
- Cost of the feature: several practitioners report visible image-quality degradation the moment elements/references are enabled. Use elements only when consistency actually matters; for one-off clips, in-prompt labels are cleaner.

## 8. Motion Brush (unique)

Animate up to 6 regions of a single image independently. Each region gets its own motion path.

Critical rule. The text prompt MUST match the brush motion. If you brush a river flowing and write "stagnant pond" the model tears itself apart. Align prompt verbs with brush directions.

## 9. Motion Control (2.6 Pro, unique)

Copy motion from a reference video. Use when you need specific performance or choreography (dance, martial arts, specific gait). The prompt then focuses on subject description only, the reference handles motion.

## 10. Image-to-video rule

Keep the prompt short (20-40 words). Focus only on motion. Do not re-describe static elements the model already sees.

Include explicit continuity cues. Kling responds well to "preserve X" instructions.

Example.

```text
Preserve silhouette and label text. Slow tracking shot from the side. She turns her head toward camera. Wind catches her hair. 35mm, golden hour rim light.
```

For Kling 3.0 image-to-video — see section 3 ("Image-to-video on 3.0 — lock first, then move").

## 11. Failure modes and fixes

### Random camera drift in static scenes

Fix. Say "locked static frame" or "camera fixed, no movement."

### Prompt exceeds model capacity, output melts

Fix. Cut to model-appropriate element count. 3-4 for Turbo, 5-7 for 2.6 Pro.

### Character face changes between generations

Fix. Upload 3-4 reference images to Element Library. Use Bind Elements in the settings.

### Negative prompts ignored

Fix. Rewrite "no X" as "X" in the negative field.

### Motion Brush artifact

Fix. Check that the text prompt verbs match the brush direction. Rewrite the text if it contradicts the motion.

### Element overload melts hands

Fix. Simplify. Combine elements where possible. Cut secondary descriptions.

### Kling 3.0 collapses multi-shot into one continuous take

Fix. Make shot boundaries explicit: `Shot 1 (0-3s). ... Shot 2 (3-6s). ...`. Each shot description must include a different framing or camera angle. If two adjacent shots share both framing and angle, the model merges them.

### Kling 3.0 dialogue lip-sync drifts

Fix. Apply P2 — bind dialogue to a unique visual action ("Character A pulls a folded note from his pocket and reads aloud:") before the line itself. Then add P4 linking words ("Immediately,") between consecutive lines.

### Kling 3.0 picks the wrong voice

Fix. Apply P3 — put voice tone inside the speaker tag: `[Character A, raspy deep voice]:`. Generic `[Man]:` / `[Woman]:` tags get a generic voice.

### Image quality drops when Elements / references are enabled

Fix. Strip references to the essential ones only; for one-off clips prefer in-prompt `[Character A: ...]` labels over elements. Accept the trade: elements buy consistency, not fidelity.

### Two similar characters blend features in one frame

Fix. Give each character its own element (or its own labeled identity block). Never let two speaking characters share one visual description.

### Morphing artifacts on fast motion

Fix. Generate the action in slow motion and speed it up in post — the model holds geometry at slower internal motion.

### Music appears even though the prompt says "no music"

Fix. Negative-prompting music is unreliable. Generate with `generate_audio` off and add sound in post, or strip the music track.

## 12. Skeleton

### Text-to-video (1.x – 2.x)

```text
[Subject with identity anchor]. [Subject movement in one clean verb phrase]. Scene. [3-5 environment elements]. Camera. [one movement + lens]. Lighting. [source + quality]. Atmosphere. [mood].

Negative field. blurry, distorted hands, extra fingers, melted face, watermark, subtitles, jitter.
```

### Image-to-video

```text
Preserve [silhouette / label / specific feature]. [Camera movement, one lens]. [One or two motion verbs]. [Atmospheric cue, light change].

Negative field. blurry, distorted hands, melted face, jitter.
```

### Worked example. Fashion, image-to-video (2.6 Pro)

```text
Preserve silhouette and fabric texture. Slow lateral tracking, 85mm. She turns her head toward camera, exhales through her nose, hair catches golden hour wind. Warm rim light. Confident stillness.

Negative field. blurry, distorted hands, extra fingers, melted face, watermark, motion blur, jitter.
```

### Multi-shot with dialogue (Kling 3.0)

```text
[Character A: Investigator — late 30s, navy raincoat, tired blue eyes, three-day stubble]
[Character B: Witness — early 20s, oversized hoodie, hands wrapped around a paper cup, eyes red from crying]

Master intent: a 12-second interrogation in a fluorescent-lit precinct break room at 2am. The investigator holds back, the witness breaks.

Shot 1 (0-3s). Two-shot, eye level, 35mm. Character A sits across from Character B. Static frame.
Shot 2 (3-6s). OTS over Character A's shoulder. Character B's hands tighten on the paper cup.
Shot 3 (6-9s). Profile close-up on Character A. He slides a photo across the table.
[Character A, low even voice]: "You were there."
Shot 4 (9-12s). Reverse — close-up on Character B. She does not look up.
Immediately, [Character B, fragile broken voice]: "I didn't see anything."

Camera. Locked frames, no movement except the slide of the photo. Sony FX6 feel.
Lighting. Cold overhead fluorescent, slight flicker. Pale skin, hard shadows under the eyes.
Audio. Distant police radio chatter, the buzz of the fluorescent tube, a vending machine humming in the corridor. No music.

Negative field. blurry, distorted hands, extra fingers, melted face, watermark, subtitles, jitter, dialogue overlap.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/kling.md -->


<!-- SOURCE_FILE_START: skills/video/references/patterns-and-genres.md -->
# SOURCE FILE: `skills/video/references/patterns-and-genres.md`

# Montage patterns and genre modules

## Contents

1. Montage patterns (6 ready structures)
2. Genre modules (7 archetypes)
3. Multi-clip story structure

---

## 1. Montage patterns

These are pre-built structures that solve common scene types. Pick one, fill with your specifics.

### Pattern 1. Escalation

Use for tension builds, reveals, dramatic emphasis.

```text
wide -> medium -> close-up -> macro -> reaction close-up -> impact
```

### Pattern 2. Anxiety

Use for psychological pressure, internal conflict, impending bad news.

```text
face -> object -> hand -> face -> object closer -> sound cue -> sudden stillness
```

### Pattern 3. Discovery

Use for revealing a hidden element, exploration, search.

```text
POV -> empty space -> searching hand -> hidden object -> rack focus -> emotional reaction
```

### Pattern 4. Catastrophe

Use for comedic or dramatic disaster. Tiny object failures play bigger than explosions.

```text
anticipation -> object instability -> reaction -> object falling -> impact -> silence -> emotional collapse
```

### Pattern 5. Commercial product drama

Use for ads with a hero product.

```text
lifestyle setup -> product reveal -> macro texture -> human reaction -> use moment -> hero product shot
```

### Pattern 6. Music video loop

Use for rhythmic repetition, transformation, performance.

```text
gesture A -> cut -> gesture A from new angle -> cut -> transformation -> repeat gesture A -> release
```

---

## 2. Genre modules

Each genre has a distinct visual grammar. Match style and rhythm to the genre.

### Domestic tragedy

Ordinary objects treated with extreme seriousness. Tiny event as cosmic disaster.

- Style. Cold night interior. Mundane location. Dramatic close-ups. Slow push-ins. Macro inserts. Sudden silence.
- Tone. Tragicomic. Absurd sincerity.
- Pace. Slow build, longer reaction shots.
- Example. A man discovering his fridge is empty, played like a Greek tragedy.

### Music video

Rhythm. Repetition. Visual motif. Transformation.

- Style. Repeated gestures. Match cuts. Performance fragments. Visual loops. Color-coded sections. Aggressive lens changes.
- Tone. Emotional intensity. Sensory overload with readable structure.
- Pace. Fast, beat-driven.

### Commercial

Clarity. Product logic. Sensory detail.

- Style. Clean lighting. Intentional macro. Clear product visibility. Controlled movement. Readable final hero shot.
- Tone. Desire. Transformation. Benefit shown through action.
- Pace. Medium, building to hero shot.

### Psychological drama

Pressure. Stillness. Negative space.

- Style. Locked frames. Long close-ups. Reflections. Obstructed framing. Quiet sound design.
- Tone. Internal conflict. Hidden tension. Emotional compression.
- Pace. Slow, sustained.

### Action

Spatial clarity above all else.

- Style. Establishing geography. Clear direction of movement. Impact inserts. Wide shots between close-ups. Strong eyeline continuity.
- Tone. Urgency. Force. Readable chaos.
- Pace. Fast but geometrically clear.

### Race / speed

Authentic velocity. Faceless detail-as-emotion. Cold combative palette.

- Style. Low bumper-height. Asphalt streaking in frame. Foreground reference objects passing. Hard light on metal/rubber/sweat. Beat-locked cutting that collapses toward the launch.
- Tone. Threat, not glamour. Force transmission over shiny bodywork.
- Pace. Silence-then-bang. Held ritual, exploding launch, dense contest, one held aftermath.
- For the full grammar (schools, start-line ritual, 5 shot families, drift adaptation, anti-fake guard) load `race-and-speed.md`; for turning it into still panels load `animatic-keyframes.md`.

### Fashion

Symmetric framing. Controlled palette. Repeated silhouettes.

- Style. Slow motion micro-beats. Macro fabric detail. Confident stillness. Rim light.
- Tone. Assured. Sensual.
- Pace. Slow, intentional.

### UGC / Social

Authentic. Vertical. Quick.

- Style. Handheld. Natural light. 9:16. Vertical compositions. Direct-to-camera gestures. Quick beats.
- Tone. Immediate. Casual. Urgent relevance.
- Pace. Rapid, thumbnail-readable.

---

## 3. Multi-clip story structure

AI video generators have no memory between generations. Longer videos live in multiple clips stitched in the edit.

### Default splits

- 10s. 2 clips x 5s
- 15s. 3 clips x 5s
- 30s. 6 clips x 5s
- 45s. 9 clips x 5s
- 60s. 12 clips x 5s

Exception. Seedance multi-shot can pack 2-3 shots into a single 5-10s clip.

### What every clip must repeat

Every clip is self-contained. The model has no memory. Repeat this block in every clip.

- Character identity (face, hair, clothing, distinguishing marks)
- Clothing items, exactly named
- Location description
- Visual style (palette, grade, reference)
- Camera language (dominant grammar of the whole piece)
- Lighting logic (dominant source and direction)
- Continuity rules (what must remain constant)
- Color palette with specific colors

Yes, every single clip. Yes, even if it feels repetitive. That repetition is the only thing keeping the output consistent.

### Timecoded internal beats

Inside each 5-second prompt, use timecodes.

```text
0.0-0.8. [action / camera / light]
0.8-1.6. [action / camera / light]
1.6-2.5. [action / camera / light]
2.5-3.7. [action / camera / light]
3.7-5.0. [action / camera / light]
```

Density by genre.

- Emotional drama. 3-4 beats per 5s. Longer reactions.
- Standard narrative. 4-7 beats per 5s.
- Fast montage / music video. 6-9 beats per 5s.

Use timecoded structure for Seedance and Veo. Kling prefers flowing prose.

### Continuity across clips

When moving from clip N to clip N+1, the first beat of the new clip should match the final beat of the previous clip. Character in same pose. Same light. Same color temperature. This is what makes them cut together cleanly in the editor.

Example. Clip 1 ends on him reaching into the fridge. Clip 2 opens on his hand inside the fridge at the same height and light.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/patterns-and-genres.md -->


<!-- SOURCE_FILE_START: skills/video/references/race-and-speed.md -->
# SOURCE FILE: `skills/video/references/race-and-speed.md`

# Race, speed and faceless kinetic montage

Domain grammar for dynamic race spots — drag, drift, chase, drag-strip, kinetic montage. The brief is brutal: faces are banned, the deliverable is **still keyframes (opornye kadry)** for an animatic, and a frozen panel must read as lethal velocity at a glance. Speed is not a post effect — it is a photographic fact built from spatial cues that imply the missing motion. Emotion does not live on a face; it rides on metal, rubber, road, gauges and light. Load this file when the task involves racing, drift, drag, chase, speed, dynamic or kinetic montage, "гонщик", or "раскадровка гонки".

This file **specializes `animatic-keyframes.md` for the race domain.** That file owns the general still-panel method and is the prerequisite read: the keyframe card, the **six motion-as-still cues** (§4), the **5-cue speed budget** (§4), the **EMOTION→OBJECT substitution table** and state-change cheat-sheet (§5), the loaded-frame depth method (§6), the **density ladder** (§3), the **keyframe→image-gen prompt skeleton** (§7), the worked 30s board (§8), and the **master per-panel checklist** (§9). This file does **not** repeat them — it adds the race grammar on top: the schools, the start-line liturgy, the shot families, the drift ritual, the Christmas-Tree light logic, and the cold-combat palette. Where the method is general, this file points; where it is race-specific, it teaches.

Sits on top of `dramaturgy.md` (§2 Details Law, §3 fantik, §9 environment, §11 shot card, §12 rhythm ladder, §15 check), `universal-rules.md` (U1–U12), `role-modes.md` §4 (shot-function taxonomy). Pairs with `camera-lighting-vocabulary.md` for framing/lens/light tokens, `patterns-and-genres.md` for the action/escalation arc, and `seedance.md` / `kling.md` / `veo.md` to animate each locked keyframe.

## Contents

1. Core laws (the non-negotiables)
2. Four schools worth stealing
3. Selling speed in a single frame
4. Storytelling without faces — the race captioning system
5. The race ritual (liturgy) + the 5 shot families
6. Camera grammar for speed
7. Light & color for speed without faces
8. Sound & rhythm
9. 30-second structure (beat map)
10. Anti-fake guard

---

## 1. Core laws (the non-negotiables)

Six laws govern every race panel. Break one and the spot collapses to a car commercial.

1. **Authentic speed, never CGI-clean or sped-up.** Build velocity into the static composition (§3); never lean on a ramp to rescue a dead frame. Over-crank, glass-smooth stabilization and post speed-ramps read subconsciously as "ad-speed" and drain all threat. Squat, lifted nose, slick wrinkle, smeared rim — the physics has to be visible in the still.
2. **Detail is the emotion.** Faces banned, feeling renders only on a knuckle, a needle, a pedal, smoke, or a sweat bead (`dramaturgy.md` §2; the full substitution method is `animatic-keyframes.md` §5). A hand mid-grip is the no-face equivalent of a close-up on the eyes. No abstract "motion", no named feeling.
3. **One governing visual promise per piece.** A 30s cut earns cohesion from a single conceit: everything through reflections in painted metal, or everything through circles (tach → headlight → bulb → wheel), or everything as machine-talks / no-music. Kon's "one visual principle". Name it before boarding.
4. **Beat-locked cutting.** Loudness in the audio = shot count on the board (§8; the density ladder itself is `animatic-keyframes.md` §3). Silence = one held panel. Bang = a burst of 4–8-frame micro-panels. Cut length is engine RPM made visual: idle = long panels, redline = collapsing panels toward the green.
5. **Cold combative palette** (§7). Steel blue, cyan, magenta, dirty mercury-white; **red as danger accent only** (brake glow, redline, tail-lights, the Tree's bulbs). No warm cozy amber wash — warmth appears only as toxin. Steal Tony Scott's grain, contrast and overexposure; **discard his warm grade.**
6. **Every insert is load-bearing.** Each detail panel must be captionable with one race label — *setup / commitment / mistake / recovery / proof-of-speed / result* (§4). If you cannot label it, it is a *fantik* (`dramaturgy.md` §3) — drop it. A board that is all proof-of-speed with no commitment/mistake/recovery is a reel, not a story.

---

## 2. Four schools worth stealing

Four traditions, compressed. Each ends in its one transferable rule.

**Kinetic montage (Wright, Ritchie, Boyle, Scott, Vaughn, Raimi, Aronofsky).** Time is elastic, every prop is a trigger, prep is an event. A keyframe cannot ramp or whip — so each moving trick compresses into one frozen cue (the six cues are catalogued in `animatic-keyframes.md` §4). Aronofsky's hip-hop montage is the single most transferable engine for prep-without-faces: a 6–9-panel ultra-CU strip of the start ritual, each panel one beat with a locked sound cue, the cluster **repeated two-to-three times with escalation** (calm → strained → violent). Repetition is memory; memory is emotion.
→ **Rule:** never write "motion" — write the artifact motion leaves behind, and never board a neutral panel (every frame carries a forward vector, negative space ahead of the subject).

**Race-truth (Frankenheimer, Lelouch, Mangold/Papamichael, Howard/Dod Mantle, Refn).** Speed is a fact you earn by putting the camera where a real rig could bolt — bumper, hood lip, hostess-tray, axle, cabin. Low, wide and close, hard-mounted without vibration isolation so "cheeks shake", asphalt streaking in frame as the speedometer, mini-cams next to pistons and swelling tires for "an electron-microscope view of the car at its limit". Refn's cocoon: silence and stillness inside the shell, chaos outside, so the launch detonates. Refuse the crank — *Grand Prix* oiled tires for real smoke rather than fake the burnout.
→ **Rule:** if the implied camera could not physically mount on the car, the panel reads as render — drop it to bumper height and bolt it on.

**Loaded composition (Bong, Park, Anderson, Kon).** With no faces, geometry and the depth stack do the acting (the FG/MG/BG depth method is `animatic-keyframes.md` §6). One geometric spine (centerline or Christmas Tree as the axis); every object an evidence (Park: "each object is a clue") or it is cut. Symmetry is handwriting — one held symmetric "breath" frame says balanced rivalry; break it the instant one car noses ahead. Kon's graphic-match pairs compress time across two adjacent keyframes sharing a shape at the same size and screen position.
→ **Rule:** a panel answers one question in the first glance and rewards a second look — one focal point, one emotion, three depth layers, zero dead objects.

**Rule-based ad (Honda *Cog*, Audi Quattro, Nike/Ritchie, Goodyear).** The drama is pure mechanism: every object does something irreversible, "let the machine talk" (no music), the entire spot first-person with no hero face. Tension is "will it fire". A static fetish shot of a gear lever flatlines; an object crossing a threshold says a decision just happened.
→ **Rule:** objects carry feeling only when they visibly **change state** — board the "after" (needle pinned in the red, ignition lamp blooming live, slick caught mid-fold), the "before" is implied.

---

## 3. Selling speed in a single frame

A still has no engine note and zero motion. It sells velocity through the **speed-budget rule** — a frame reads fast only when **≥3 of five cues coexist** (camera at/below bumper height · asphalt streaking the lower frame · a near foreground reference passing the edge · sharp hero against motion-blurred background · a mechanical-vibration cue). The full rule, with the anti-fake firewall, lives in `animatic-keyframes.md` §4; do not re-derive it. One cue is a car photo; three is velocity; five and even a parked car reads dangerous. If a "fast" panel can't name three, reframe lower, drag the camera to the asphalt, throw a barrier into the foreground.

Two race-domain extensions the general file does not carry:

**The foreground reference catalog** (cue *c*, the cheapest and strongest speed multiplier). Place the reference *near the lens* (so it smears most) and *passing the edge* (so it reads as transiting, not parked). Keep one near object tack-sharp so the brain measures the smear against it.

| Reference object | Where to place it | Speed it implies |
|---|---|---|
| Cone / timing block | near edge, elongated/smeared | lane-level rush |
| Armco barrier / wall | scraping the near side, streaked | proximity + velocity |
| Lane stripe / chevron | lower frame, smeared toward bottom | ground speed |
| Christmas-Tree pylon | foreground, sharp anchor; car blurred | launch reference + timer |
| Tree / lamp post / grandstand | whipping past, motion-rod | open-road pace |
| Tire smoke / spray | raked by backlight across frame | force + air movement |
| Marshal / crowd at periphery | blurred, fragmented | scale + danger |

**Long-lens compression** — the second speed register and the antidote to "only blur sells speed". Frankenheimer's 1000mm stacked distant cars onto the hero so closing distance reads as collapse. Pair compression panels with low-wide panels in the cut; never board the whole spot on one lens. In `seedance.md`/`veo.md` syntax name "motion blur, fast-shutter look on background, sharp subject" explicitly — models default to over-clean stabilization (the prompt skeleton is `animatic-keyframes.md` §7).

(The full "what kills the speed" audit lives once, in §10.)

---

## 4. Storytelling without faces — the race captioning system

A face does four jobs: internal state, where it looks, the cost, the decision. Banned, those jobs redistribute — **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space.** The mechanism, the EMOTION→OBJECT substitution table and the state-change cheat-sheet are owned by `animatic-keyframes.md` §5; do not duplicate them. Two filters before you draw: name the **verb** on any hand/foot panel (grip / latch / shift / preload / release — no verb, no panel), and board only the **after** state of any object threshold (Honda *Cog*). Pick ONE hero object and board it three times at rising intensity — beats twelve unrelated inserts (`dramaturgy.md` §13).

What this file owns is the **race captioning system** — the margin label that proves an insert is load-bearing (Law 6). Every detail keyframe gets exactly one. If you cannot assign one, drop the panel.

| Label | Story job | Typical object / crop | Skill tag (`role-modes.md` §4) |
|---|---|---|---|
| **setup** | establishes capability / readiness | glove pull, harness latch, ignition dead | Establish / Detail |
| **commitment** | point of no return chosen | foot pins throttle, shifter rammed home, ignition live | Shift / Impact |
| **mistake** | something slips / over-limit | tire shake, wheel fights back, revs flare wrong | Pressure / Impact |
| **recovery** | control reclaimed | hand catches the correction, tach settles back into band | Shift |
| **proof-of-speed** | force is real, not staged | chassis squat, slick wrinkle, exhaust flame, asphalt streak | Power / Pressure |
| **result** | who won the inch | finish stripe, slicks ballooned at trap, one nose ahead, chute bloom | Impact / Aftermath |

(Banned panels are consolidated in §10.)

---

## 5. The race ritual (liturgy) + the 5 shot families

The race is not a chase, it is a *liturgy*. Every phase is a legible, irreversible state-change a knowing viewer reads instantly — muddle the order and the spot dies. The countdown *tightens cut length toward the green*, then explodes: the drag-specific instance of the `dramaturgy.md` §12 rhythm staircase. Draw one anchor keyframe per beat. In a faceless spot **Reaction** is reassigned from a human face to the *machine's* face — the needle jumping, the slick wrinkling, the nose squatting. Gauges and rubber are the actor.

| # | Ritual beat | Function | Keyframe to draw (still) | Light (cold) | Emotion |
|---|---|---|---|---|---|
| 1 | Water box entry | Establish | Front slick easing into mirror-still water, chalk/box edge in frame, bulbs reflected in the sheet | Steel-blue dusk, wet specular | coiled stillness |
| 2 | Burnout (white→blue) | Power | Ground-level wall of smoke off the rear, plume backlit; car straining on line-lock | Hard cyan backlight through smoke | barely-leashed force |
| 3 | Reverse settle | Pressure | Rear rolling back through its own drifting smoke toward the beams, tail-lights bleeding red into haze | Smoke haze, low key, red tail wash | deliberate menace |
| 4 | Pre-stage bulb | Pressure | Front tyre creeping, top blue bulb lit as anchor, beam line as a graphic spine on asphalt | Blue bulb glow on wet metal | held breath |
| 5 | Stage bulb | Pressure | Second blue bulb lit, tyre on the line, knuckles whitening on wheel/trans-brake (depth: bulb BG, hand FG) | Two blue bulbs, deep black | point of no return |
| 6 | Amber countdown | Pressure→Shift | The Tree as timer — three ambers, sequential (see below) | Amber pulse (the only narrative warm light) | trigger tension |
| 7 | Green / launch | Impact | Both cars squatting on rear suspension, front wheels lifting, asphalt streaking back | Green flash + hard flare | release / violence |
| 8 | Slick wrinkle (hero) | Detail/Reaction | Macro into rear sidewall folding/wrinkling as it hooks — *the* hero detail, the held/ramp beat | Hard side light, smoke bloom | physics made visible |
| 9 | Shift / exhaust flame | Detail | Hand slamming shifter with chassis twist, OR header pipe spitting flame | Flame as warm spark in cold frame | escalation |
| 10 | The pass | Power | Joust / parallel tracking, asphalt streaking, rival lane in frame | Streaked specular, motion-rod lights | duel |
| 11 | Finish | Impact | Top-end: slicks "blown up"/distorted, cars inches apart crossing the line, one nose ahead | Cold-white finish pool | margin |
| 12 | Chutes / aftermath | Aftermath/Exit | Parachutes blooming, smoke drifting through headlight beams, OR hand unclenching off the wheel | Falling light, residue haze | consequence |

**Amber logic (decision point).** Choose the **Sportsman / full tree** for an ad: three ambers fire *sequentially 0.5s apart* — three drawable keyframes, a stretched drum-roll of dread with cut length collapsing toward the green. The Pro tree fires all three at once — one panel, brutal but no build. Draw the Sportsman stagger. Always leave on the **last amber, not the green** (holeshot): the launch keyframe precedes the green-lit panel by a frame, which makes it read as *anticipation*, not reaction.

**Drift adaptation — the slip-angle liturgy.** Drift swaps the countdown for a *continuous angle ritual*: **approach → entry → clutch-kick initiation → counter-steer hold → clipping point (wall proximity) → smoke wall → transition (flick) → exit.** The **counter-steer** replaces the slick-wrinkle as the "physics made visible" anchor — ECU/CU of hands wound into opposite lock, forearms crossed, wheel at full angle, cold side-light on knuckles, the steering angle drawn large and unmistakable. **Wall proximity** is danger without a face: barrier hard and sharp in the foreground layer, car door a hand's-width away, motion-streak on the wall texture — the gap *is* the emotion. The **transition flick** is yawed mid-switch, smoke crossing the frame diagonally, both exit directions readable.

### The 5 shot families

Rotate among all five across the 30s — speed reads through *changing perspective*, not long takes. Each family has one job and a default composition.

| # | Family | Job (function) | Put in the still panel | Authenticity tell |
|---|---|---|---|---|
| 1 | **Hostess-tray side profile** | Detail / Power | Side-mounted outside the door: hand on wheel/shifter, or rear-quarter wheel filling frame; asphalt streaking behind | door/window line anchors scale; rubber works in frame |
| 2 | **Hood / bumper low forward POV** | Pressure / Impact | Predatory low forward look: asphalt rushing under the nose, cones/Tree/markers growing fast, lane stripe strobing; fisheye edge optional | road texture under the car = velocity |
| 3 | **Hard-mounted cabin shake** | Pressure / Reaction | Rigid interior mount: dash/needle/hands vibrating, mirror trembling, world shuddering through glass | visible micro-vibration; never perfectly stable |
| 4 | **Tracking / chase parallel + joust** | Power / Reveal | Camera car alongside (parallel) or closing head-on offset (joust); rival lane in frame, roadside lights as streaks | closing distance + streaked surroundings |
| 5 | **Distant proof shot** | Establish / Aftermath | Long locked lens: two cars as small hard shapes crossing huge space, smoke trail, barriers narrowing perspective | space covered brutally fast; one breath of stillness |

---

## 6. Camera grammar for speed

The **six motion-as-still cues** (smear / partial blur / streak / vector / sharp-blur separation / held stillness) are catalogued in `animatic-keyframes.md` §4. This table is the complementary layer: the camera *move* the user names, resolved into one still composition. Format: technique — what it does to emotion — application in a keyframe/panel.

| Technique | What it does to emotion | Keyframe application (the still) | Tag |
|---|---|---|---|
| **Whip pan** | instant transfer of attention, reads as motion not a cut | Streak-frame between two clean panels: whole frame raked into horizontal streaks (Tree lamps, guardrail, lane stripes smeared), one shape barely surviving (a wheel arc, the shifter) | Shift |
| **Crash / snap zoom** | shock-shove into a detail; discovery, alarm | Aggressively tight macro of the trigger detail (needle slamming red, last amber bulb), faint radial/zoom-blur ring at edges, subject oversized dead-center | Detail / Impact |
| **Speed ramp** | punctuation: ramp = the breakout, freeze = exclamation mark | Frozen partial blur at the peak — sidewall wrinkle caught mid-deformation, smoke just blooming, everything else tack-sharp; one arrested ten-thousandth of a second | Impact |
| **Freeze frame** | a held breath / a one-frame dossier on an object | Deliberately blur-free locked macro, hard edges, margin caption (knuckles whitening, *committed*); the symmetrical "exhale" amid kinetic panels | Detail / Pressure |
| **POV (cockpit / impossible mount)** | identification; the viewer *is* in the car | Hands + wheel rim in hard foreground, cluster mid-ground, Tree/rival in blurred deep ground; 24mm exaggerated proximity; or genuinely impossible mount (wheel arch, exhaust mouth) | POV / Pressure |
| **Joust** | closing-distance rate spikes the sense of speed | Near head-on, car offset to one side, a cone/marker huge and blurred on the opposite edge to mark the closing gap; reserve for the climax pass | Impact |
| **Low macro (aggressor cam)** | the lens is a predator, the track attacks the frame | Bumper/grille-level skimming the asphalt, fisheye curvature at the edges, road lunging into the lens; or extreme CU under hard cold side-light — a knuckle becomes a ridge, the lever a weapon | Impact / POV / Detail |
| **Restless / handheld cam** | the frame never settles; constant threat, physiological unease | Never a perfectly level, perfectly clean panel — bake in a 1–3° drift, edge smear, off-true horizon, a faint micro-shake artifact even in a "static" cockpit | Pressure |
| **Dutch angle** | imbalance, loss of grip | Cant the horizon hard at the one loss-of-traction beat only (tyre breaking away, car stepping sideways) — reserve it so it stays loud | Impact |

Ration aggression: one bumper-fisheye lunge, one crash-zoom, one dutch — at commitment beats, not as wallpaper. Per `camera-lighting-vocabulary.md` §2, the animatic prompt supplies one dominant move per clip; the keyframe is the locked first frame.

---

## 7. Light & color for speed without faces

Faces are banned, so light is the only actor left. It does not "set a mood" — it **rims a material** so a piece of metal, rubber or skin reports the emotion a face would. General light grammar (sources, direction, quality) is `camera-lighting-vocabulary.md` §4–7; the anti-sterile firewall is `animatic-keyframes.md` §7 + `universal-rules.md` U12. The race-specific governing law: *embrace the dark* (crush blacks, ~70% of the frame unlit), *one motivated practical per panel* (Tree lamp, headlight, sodium lamp, brake glow), *light is specular not ambient* (every panel needs ≥1 hard specular hit — no specular, no information).

### The cold combative palette

| Color | Emotional job | Where it lives in the keyframe |
|---|---|---|
| Hard white / dirty mercury white | clinical pressure, the white-hot edge of commitment | top/side key on knuckles, metal lip; blown highlight on chrome |
| Cyan / electric teal | cold adrenaline, machine-alive | backlight through burnout smoke; spill on wet asphalt; rim on rear-quarter |
| Steel blue | night base, isolation, the void | negative space, deep shadow body, the unlit 70% |
| Magenta / cold violet | aggression, neon menace | practical sign spill on roofline; reflection ribbon down wet lane |
| **Red (accent only)** | danger, redline, point of no return | brake disc glow, tail-lights, Tree bulbs in lacquer, tach needle in the red |
| Green (accent only) | release, GO | the Tree's green bulb, its single reflection in a headlight lens or paint |
| Toxic amber/sodium (rationed) | temporary, contaminated, alien — never cozy | sodium lamp as a passing smear; spilled fluid catching one lamp; the Tree's three ambers as countdown only |

**Warmth as toxin** is the only permitted heat: brake-disc/exhaust glow (the machine at its thermal limit), a header flame stab gone in a frame, the Tree's alien ambers, a sickly sodium smear. Any warm element must be **point-source and surrounded by cold**. If amber fills more than ~15% of the frame it has become a wash — kill it.

### Concrete lighting recipes (drop-in for the format-C Light column: source · direction · quality · what it rims)

- **Hard key on the working hand** [Detail/Pressure]: single hard source 45° camera-side onto knuckles on the shifter — finger shadows rake the skin, sweat reads as discrete specular dots, veins as ridges, background crushed. The whitening knuckle IS the fear.
- **Backlight / rim on metal edge** [Power]: hard white or cyan source behind/above at low angle drawing one bright line down the roof gutter, mirror housing or wing edge; body in shadow, only the contour glows, against black sky.
- **Backlit smoke** [Pressure/Establish]: hard cyan or mercury-white punching *through* tire smoke from behind; volumetric shafts, the car a dark mass dissolving into glowing haze, red tail-light bleed inside the smoke for the danger accent. Front-lit smoke is dead gray nothing — always rim it from behind.
- **Brake-disc glow** [Detail/Impact]: macro on the wheel, glowing orange-red rotor through the spokes as the *only* warm element (toxic heat), rim the caliper and spokes with that glow, everything else steel blue — the one ember in a cold frame.
- **Specular on wet asphalt — the mirror** [Establish/Shift]: low bumper-height, lane stretching away, practicals (Tree, sodium lamps, headlights) reflected as long vertical smears down the wet surface as the composition's spine; pull the real lamps half out of frame, keep the mirror. Wet asphalt at night = `dramaturgy.md` §9 guilt/threat, and the cheapest way to put more cold light in frame without lifting blacks.
- **Silhouette / contre-jour** [Power/Pressure]: helmet/shoulder as pure black shape against a blown headlight or the Tree's amber bank, one thin rim defining the form plus one glint on the visor edge, no features. The brain fills the dark with something worse than any face.
- **The Christmas Tree as the scene's lamp and clock** [Pressure→Impact]: put the Tree bank in frame as the dominant practical — its glow the only key. Stage 1: two blue bulbs as cold points in the lacquer. Stage 2: three ambers blazing, amber-as-toxin spill on wet asphalt, held. Stage 3: green pops, a single green reflection streaks the hood. Match-cut the round bulb → round headlight → round tach.

**Texture and atmosphere.** Name the grain, never "clean": fine-to-medium film grain (heaviest in shadow), halation/bloom on hard practicals (soft glow ring + hard hot core), one anamorphic flare off the dominant source, slight chromatic fringe on the hottest edges (anti-sterile test in `animatic-keyframes.md` §7). One atmospheric pressure per panel (`dramaturgy.md` §9, Kurosawa) — backlit tire smoke, frozen launch grit lit on its leading edge, heat-haze warping the rimmed edge, wet asphalt as the mirror. Don't stack smoke + haze + spray in one still or it turns to mud. Keep Tony Scott's restlessness and grain; discard his warm grade.

---

## 8. Sound & rhythm

You storyboard the **sound first**; the keyframes hang off it. The general law — **loudness in the audio = panel count** — and the descending duration staircase are the density ladder in `animatic-keyframes.md` §3, sitting on the `dramaturgy.md` §12 rhythm staircase. Do not re-derive them. The race-specific rhythm rules:

- **Engine as metronome.** Tie panel *duration* to RPM: idle = ~2s panels, redline = panels collapsing 2s → 1s → 0.5s → 8fr → 4fr toward the green. The board should read as an accelerating tachometer on mute. Annotate each panel with its on-screen life.
- **Amber collapse.** The Sportsman stagger (§5) is the audible drum-roll: idle drops out on the ambers, each amber a tighter panel, the green detonates.
- **The wrinkle is the one time-expansion.** Dedicate 2–3 sequential panels to the slick folding (clean → wrinkled → gripping), marked "RAMP — hold", sound dropped (the Goodyear move) — the only place time *expands* inside the loud section.
- **Pull-to-intimate at the peak.** At the contest's tensest point, cut from a wide loud pass to an ECU of glove-on-shifter / breath-fog, shallow focus, void around it — engines stripped to breath only. The *quiet* panel goes *tight*; the loud panel goes wide.
- **Machine talks (the governing anchor).** Strip music; the `Sound` cell reads "engine + tire only" (Audi Quattro 1984).
- **Sound leads picture by 2–3fr** (J-cuts). Annotate the offset at every hard mechanical event so the incoming panel opens mid-action (shifter already moving).

Every panel inherits a `Sound` cell even though it is a still (`dramaturgy.md` §11) — prompt the *physical consequence* of the sound (deformation, particulate, smear, heat-haze, isolation-in-void), never a named sound. Fill it.

---

## 9. 30-second structure (beat map)

Five phases: **ritual → staging → launch → contest → release.** Cut length escalates toward the green, the contest stays dense, one held aftermath. ~20–26 panels. Function tags from `role-modes.md` §4. This is the structural skeleton; for a fully worked, panel-by-panel deliverable board of this exact structure (format C, ~13 rows), use `animatic-keyframes.md` §8 — do not draw a second worked board here.

| Time | Phase | Function tags | # keyframes | Panel life | Framing | Sound | Render note |
|---|---|---|---|---|---|---|---|
| 0:00–0:06 | **Ritual** | Establish, Detail, Pressure | 3–4 | 1.5–2s | Macro / ECU, locked | Idle lope, metal ticks, near-silence, music off | Held low-motion inserts: slick into water box, harness latch, finger over ignition, condensation on glass. Belief is won here. |
| 0:06–0:11 | **Staging** | Pressure, Power | 3–4 | 1s → held | Symmetric MS, Tree centered, static | Idle drops to silence on ambers; Tree relay click | Pre-stage/stage bulbs; one long *held* symmetric Tree panel = the pause. Tach trembling = the only motion. |
| 0:11–0:19 | **Launch** | Impact | 6–9 | 8fr → 4fr (burst) | Low bumper-POV, side-rig, ECU tach | BANG: tire chirp + roar, J-cut 2–3fr ahead | Hip-hop burst cluster: bumper smear, side wheelspin, tach flare, clutch hand, lane-stripe strobe. Asphalt in frame. One speed-ramp on the wrinkle. |
| 0:19–0:27 | **Contest** | Power, Shift, Reaction | 6–8 | 0.5–1s | Mirror two-shot, joust, parallel pass | Layered roar; **one pull-to-intimate / in-the-head panel** | Mirrored compositions, joust, parallel pass, one medium-wide proving ground-speed. Alternate fragment-cluster ↔ one quiet detail panel. |
| 0:27–0:30 | **Release / Aftermath** | Impact, Aftermath, Exit | 2–3 | 0.5s, then 2s hold | Wide-to-detail, smoke in beam | Hard cut to silence / one tick | Finish marker + microscopic edge, OR skip the result → engine drop, smoke through headlight beam, car nosing into dark. End on consequence, not explanation. |

Allocation: plot the board as a descending duration staircase, broken only by the one pre-launch held panel (the single most-held still, most negative space) and the one post-finish hold. The launch is *never* one hero frame — fan it into the 6–9-panel micro-burst. No two bang-clusters touch; every burst is separated by a held quiet panel.

---

## 10. Anti-fake guard

The race-specific list of panels that kill credibility — do not draw. (The general per-panel earns-its-place checklist is `animatic-keyframes.md` §9; run that on every panel as well.)

- [ ] No high, clean, "beauty" god-angle for action beats — drop to bumper height; low/wide/close beats polish.
- [ ] No perfectly stable cabin — render visible vibration (trembling mirror, doubled needle, smeared rim); tilt 1–3°.
- [ ] No long-lens speed panel without road texture or a passing reference object.
- [ ] No panel that only works "when sped up" — build the speed into the static composition (squat, lifted nose, slick wrinkle).
- [ ] No air around the car on a speed beat — crowd the near edge with barrier/rival/wall.
- [ ] No sharp wheel rim on a moving car — smear the spokes into a disc.
- [ ] No shiny-bodywork beauty pass — shoot force transmission (tire load, chassis squat, exhaust flame).
- [ ] No ritual beat out of order or skipped (§5) — a knowing viewer reads the fake instantly.
- [ ] No warm cozy grade — cold palette, red as danger accent only, amber ≤15% and toxic (§7).
- [ ] No banned panel: static fetish insert (lever/badge/wheel with no verb, no state-change); anatomy at rest; a detail you cannot caption with a §4 label; all-proof-of-speed board with no commitment/mistake/recovery; decorative dashboard clutter (keyring, dice, coffee cup — "each object is a clue"); warm wash without narrative function.

Before sending the board, run `animatic-keyframes.md` §9 (per-panel master checklist), `dramaturgy.md` §15 and `universal-rules.md` §13 over it. The most-violated step is the three-detail check — do not skip it.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/race-and-speed.md -->


<!-- SOURCE_FILE_START: skills/video/references/role-modes.md -->
# SOURCE FILE: `skills/video/references/role-modes.md`

# Role modes

This skill fuses three mindsets. Switch role based on the task stage. The dramaturgy layer sits underneath all three roles. For the full dramaturgy method (scene formula, Murch Rule of Six, blocking as choreography of desire, staging and subtext, three-layer storyboard, shot card template, rhythm ladder), load `references/dramaturgy.md`. Director mode leans heaviest on that file.

## Contents

1. Director mode
2. Screenwriter mode
3. Editor mode
4. Shot function taxonomy

---

## 1. Director mode

### Trigger

User asks to "придумать сцену", "разработать концепцию", "визуализировать идею", "сделай как Финчер", "предложи трактовку", "какой вайб", or shares a raw idea without structure.

### Mindset

Every shot must answer at least one of these questions. If a shot answers none, delete it.

- What changes emotionally?
- What new information appears?
- What action moves the story?
- What pressure increases?
- What does the viewer need to notice?
- Why does the camera move?
- Why does the cut happen here?

### Output format. Director treatment

```text
Core idea. [one sentence, the point of the piece]
Emotional arc. [start -> middle -> end, three emotion states]
Visual motif. [one recurring visual element]
Rhythm. [pace logic. slow build, rapid montage, still + sudden burst]
Camera language. [dominant grammar. handheld intimacy, locked precision, gliding observer]
Lighting. [dominant source and direction]
Sound. [texture. ambient layers, music role, silence moments]
Ending image. [final frame in one sentence]
```

### Style references

Use one dominant director reference per scene. Translate into concrete camera, light, rhythm, blocking. Never stack three or more references.

- Fincher. Precise motivated camera. No handheld drift. Cold palette.
- Kurosawa. Weather as emotional pressure. Rain, wind, heat.
- Spielberg. Readable staging. Clear geography. Emotional wide shots.
- Edgar Wright. Sound-driven montage. Match cuts on sound events.
- Jonathan Glazer. Music-video visual idea translated to drama.
- Wong Kar-wai. Longing. Reflections. Slow emotional drift.
- Safdie. Anxiety. Handheld pressure. Overlapping sound.
- Wes Anderson. Symmetry. Controlled blocking. Color blocks.

---

## 2. Screenwriter mode

### Trigger

User asks to "напиши сценарий", "разбей на биты", "придумай диалог", "адаптируй историю в видео", "нужен story arc."

### Mindset

Translate every beat into physical action the camera can see. Tag each beat with a shot function (see section 4). Every beat must have subtext.

### Output format. Beat breakdown

```text
Beat 1. [function] - [physical action]. Subtext. [what it means].
Beat 2. [function] - [physical action]. Subtext. [what it means].
...
Final image. [what the viewer takes with them].
```

### Dialogue format (for Veo specifically)

Write spoken lines in ready-to-paste Veo syntax.

```text
He says, in a flat exhausted voice, "We are fine. We are fine."
```

Cut lines until they fit 8 seconds of natural speech.

### Internal monologue rule

Veo cannot render internal monologue. Translate into visible bodily signal.

Bad. "He is thinking about his father."
Good. "He stops mid-motion. His eyes drift off-axis. He swallows. He resumes."

---

## 3. Editor mode

### Trigger

User asks to "собери монтаж", "задай ритм", "сделай динамично", "разбей на склейки", "как смонтировать", "сколько кадров в 5 секундах."

### Mindset

Dynamic montage is built through structure, not speed. Random fast cuts create visual soup. Readable fast cuts create propulsion.

### Rules

- Clear shot function per cut.
- Escalating frame tightness (wide -> medium -> close).
- Different camera angles per cut.
- Motivated cuts (sound event, action beat, emotional shift).
- Contrast speed and pause.
- Sound-driven transitions.
- One silence or stillness moment before a major impact.

### Output format. Timecoded beat sheet

```text
00.0-00.8. [shot function] - [framing] - [camera] - [sound cue]
00.8-01.6. [shot function] - [framing] - [camera] - [sound cue]
...
```

### Density

- Emotional drama. 3-4 beats per 5s.
- Standard narrative. 4-7 beats per 5s.
- Fast montage. 6-9 beats per 5s.

More than 9 beats in 5s creates incoherent motion regardless of model.

---

## 4. Shot function taxonomy

Every beat should carry at least one function tag. This is the editor's grammar.

- **Establish.** Where we are. Wide or master shot. Sets geography.
- **Reveal.** What appears. New information enters frame.
- **Power.** Who controls the scene right now. Staging reveals the hierarchy before dialogue does.
- **Pressure.** Tension builds. Movement toward threat or decision. Environment can carry this (flickering light, rain, steam, a tight corridor).
- **Detail.** Important object, hand, eye, texture, gesture. Macro or close-up. The anchor object often lives here.
- **Reaction.** Emotional consequence. Face response to a beat.
- **Shift.** Inner change. Body language turning point. The moment before the decision becomes visible.
- **Impact.** Decisive visual event. The drop. The hit. The break.
- **Aftermath.** Emotional residue. Stillness after impact.
- **Exit.** Final state. The image the viewer leaves with.

A full scene usually moves. Establish -> Power -> Pressure -> Detail -> Reaction -> Shift -> Impact -> Aftermath -> Exit.

A montage sequence can compress or loop. Use function tags to keep the structure readable even at high speed.

Each tag is also a question the shot must answer. Establish. Where. Power. Who commands. Pressure. What pushes. Detail. What to notice. Reaction. What it cost. Shift. What changed inside. Impact. The moment. Aftermath. The residue. Exit. The image carried out.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/role-modes.md -->


<!-- SOURCE_FILE_START: skills/video/references/seedance-25.md -->
# SOURCE FILE: `skills/video/references/seedance-25.md`

# Seedance 2.5 — production reference (ByteDance, official guides of 2026-07-31)

Read `seedance.md` first for the family basics (Details Law, multi-shot syntax, 11-block skeleton). This file covers what 2.5 adds: the official prompt formulas, the 50-slot reference system, video editing, extension, ultra-long mode, and the blockout pipeline. Sources: the official Dreamina/Jimeng User Guide and Prompt Guide (both published 2026-07-31), verified against practitioner tests from the first launch week.

## Contents

1. What 2.5 changes
2. Specs and hard limits
3. Official prompt formula
4. Syntax markers for audio, dialogue and text
5. Reference discipline (the 50-slot system)
6. The 30-second structure: stages and end states
7. The anti-collapse skeleton (3 modules)
8. Realistic human formula (anti-AI-face)
9. Camera language
10. Transitions
11. Physics through consequences and triggers
12. Video editing (partial re-render)
13. Video extension
14. Ultra Long mode (30-180s)
15. Blockout and green screen
16. Storyboard grids and keyframes
17. Failure modes and fixes
18. Economics and model choice
19. Worked examples (official, verbatim)

---

## 1. What 2.5 changes

- **30-second native single-pass clip.** One generation, one continuous arc, no stitching. Extension pushes it to 60s; a separate Ultra Long mode goes to 180s (see sections 13-14).
- **50 multimodal references** (30 images + 10 videos + 10 audio) with per-asset role binding. The model understands which asset is responsible for character, scene, prop, camera move, or rhythm — if you tell it.
- **Realistic humans are a headline feature**, not a liability: real skin pores, restrained micro-acting, multilingual lip-sync in 11 languages. The 2.0-era face caution does not apply.
- **Negative commands became reliable.** "Pure video, no subtitles, no background music" now actually suppresses random subtitles and unwanted score — the classic 1.x/2.0 failure is fixed.
- **Second-level timestamp control.** `[0-4s] ...` beat windows are honored as timing, not just ordering.
- **Editing an existing video** (partial re-render, background swap, language re-dub) and **extending** it are first-class modes, not workarounds.
- **Blockout control**: white-model 3D previz video (or green-screen plates) locks camera path, staging and blocking; Blender/Maya plugins upload straight to Jimeng.

Entry points: Jimeng (jimeng.jianying.com — Omni Reference / Smart Edit / Long Video / First & Last Frames), Doubao (Pro subscription), Xiaoyunque (xyq.jianying.com — character library, 3D director stage, segment reshoot).

## 2. Specs and hard limits

| Parameter | 2.0 | 2.5 |
|---|---|---|
| Single-pass duration | up to 15s | up to **30s** (duration `-1` or 4-30) |
| Images per request | 9 | **30** (each ≤4K, ≤30 MB) |
| Video references | 3 clips, ≤15s total | **10 clips**, single 2-30s, **≤30s total** |
| Audio references | 3 clips, ≤15s total | **10 clips, ≤30s total**; audio-only input now allowed |
| Output resolution | up to 4K | **480p / 720p** on Jimeng web |
| Timestamps | ordering hints only | honored to the second |

Generation parameters (duration, aspect ratio, resolution) are set on the generation page or via API — **they do not belong in the prompt**. The 1.x/2.0 CLI tail (`--resolution ... --duration ...`) is not 2.5 syntax. Exception: in Ultra Long mode, restate duration and ratio at the top of the prompt.

Auto-locked parameters: video editing locks ratio and duration to the input (±0.3s); first/last frame locks ratio to the first image (a mismatched last frame gets stretched); extension locks ratio, duration settable.

## 3. Official prompt formula

Base formula for any 2.5 prompt:

```text
<Subject> performs <primary action or event> in <scene and environment>.
The visuals feature <visual style>.
Use <shot size, camera angle, camera movement, or cuts>.
Audio includes <dialogue, ambience, sound effects, or music>.
```

Any component may be omitted. For long or reference-heavy work, the macro-formula:

```text
Complete prompt = [reference declaration] + [one-line summary] + [plot by timeline] + [global tail]
```

- **Reference declaration.** Each asset by upload order + its role (character / voice / motion / scene). See section 5.
- **One-line summary.** Subject + place + event + genre/style + special camera treatment.
- **Plot by timeline.** Per beat: ➕ positive content (picture + camera + action + dialogue + SFX) and ➖ local bans ("no subtitles", "no BGM").
- **Global tail.** Re-state the must-hold globals (camera position, environment, sound, lighting) and repeat the global bans.

Re-@ the same asset multiple times through the prompt — the official guide says repeated mentions increase accuracy.

## 4. Syntax markers for audio, dialogue and text

2.5 has dedicated markers. Use them — do not describe audio in loose prose:

| Content | Marker | Example |
|---|---|---|
| Music | `( )` | `(Soft, rhythmic piano music plays in the background)` |
| Sound effect | `< >` | `<A bell rings in the distance>` |
| Dialogue | `{ }` | `{Hello, welcome back.}` |
| Subtitles / titles | `【 】` | `【Chapter One: Departure】` |

Dialogue language reinforcement — the formula is `Dialogue language + regional variety or accent + delivery style + speaker + {line}`:

```text
Dialogue language: authentic Los Angeles English. The young man says in natural
Los Angeles vernacular: {No way, you actually made it.}
The girl says softly in Japanese: {もう大丈夫です}
```

Lip shape, speech rhythm and face match the assigned language in one pass — this holds across all 11 supported languages, including mixed-language scenes.

## 5. Reference discipline (the 50-slot system)

The point of 50 slots is not dumping assets in. **Every material's role must be written in the prompt.** Do not rely on text labels inside images; do not make the model infer mappings.

Role template:

```text
@Image 1 defines <subject>'s <appearance, clothing, structure, or material>.
@Video 1 defines <motion, camera movement, or pacing>.
@Audio 1 defines <character or sound type>'s <voice, dialogue, ambience, or music>.
```

Rules:

- **Bind each subject individually.** `<Character A> corresponds to @Image 1. Use only the appearance, hairstyle, and clothing.` The officially forbidden pattern: "@Images 1 through 4 define four characters respectively" — it never states which is which.
- **Add exclusions** for anything that could bleed in: "Do not use the image background." / "Do not use the people in the image." / "Do not use the person's identity, clothing, or scene from the video."
- **Do not restate what a reference already defines.** If a reference video defines the motion, state only which attributes to inherit — re-describing every action conflicts with the reference.
- **Subject Profile** for a recurring character:

```text
[Subject Profile: Conservator]
Appearance and clothing: @Image 1.
Fixed prop: <Sample Case> from @Image 5.
Locations: <Conservation Lab> and <Gallery>.
Motion references: the case-opening motion from @Video 1.
Do not use: other characters' clothing. Do not give this character <Record Board>.
```

- **Select references per scene**, not all at once: `Scene 1 | Use: <list>. Event: ... End state: ...`
- The same character in two states (before / after a transformation) = **two separate image slots**, each bound to its time range. Expect this to be the flakiest binding — budget re-rolls.

Official stability sweet spots:

| Input | Best | Possible but unstable |
|---|---|---|
| Subjects in a reference video/audio | 1-5 | 6-10 |
| Reference clip length | 5-10s per subject | longer |
| Subjects across reference images | 1-8 | 9-12 |
| Multi-view sheets | ≤5 subjects: any | >5 subjects: single view only; separate images per view beat a collage |
| Video-edit source length | ≤20s | longer stalls |

## 6. The 30-second structure: stages and end states

Divide the clip into consecutive stages. **One primary state change per stage, and always state the visible end state** — the end state is what the model steers toward (this is the U11 final-image rule, per stage).

```text
[Generation Goal] Generate a <video type>. The central subject is <subject>,
and the primary event is <story summary>.
[Stage 1] Initial state: ... Primary event: <one primary action>. End state: <visible state>.
[Stage 2] Continue from the previous stage: <what must remain unchanged>.
          Primary event: ... End state: ...
[Stage 3] Primary event: <closing event>. End state: <final visible state>.
[Maintain Consistency] Keep <identity, count, clothing, prop ownership,
spatial direction, audio relationships> consistent.
```

Timestamp rules:

- A time range is an event's **time budget, not an edit point**. Ranges must be consecutive and non-overlapping.
- **Windows of 3 seconds or more.** Shorter windows execute unreliably.
- **One core action + one camera move per window.** Do not demand frequencies ("three actions in one second").
- Second-precision only where it matters: critical handoffs, entrances, transitions, beat hits. `At 5 seconds, the camera whip-pans left and completes the transition.` Relative triggers work too: `Three seconds after the character presses the button, the room lights turn off.`
- Too little content in a window = model freedom; too much = over-cutting and omissions. Match content volume to the budget.

## 7. The anti-collapse skeleton (3 modules)

The official structure for dramatic 30-second work. It maps onto our 11-block skeleton but is leaner:

```text
<One-line tone summary — the logline>

[Module 1 — Reference layer]
Strictly keep @Image 1's face and features consistent. Keep @Image 2's
composition / blockout / spatial relations. Strictly lock character blocking.

[Module 2 — Global settings ("worldview + anti-collapse")]
Base environment & texture (emphasize extreme, realistic physical texture).
Visual style (film look, depth of field, lighting).
Camera language.
Character styling (use the section 8 formula).
Performance core (the acting register for the whole piece).
Prohibitions: <sound bans> + <subtitle bans> + <behavior bans> + <known collapse points>.

[Module 3 — Timestamped storyboard]
[start-end s] [beat name] — physical directives (shot size, composition,
micro-actions) + emotional subtext.
```

Two techniques carry this skeleton:

- **The prohibition list is specific, not generic.** From the official farewell example: "No exaggerated crying, no fast cuts, no large body movements, no extra dialogue, no BGM, no runny nose, no premature dropping of tears." Ban the exact ways this scene can collapse.
- **Directive + subtext.** After the physical directive, explain to the model *why* the action happens: "Emotion analysis: she is not complaining — she is waiting for him to confirm an answer she already guessed." The model acts better when it knows the intent. This is the official guide's signature trick and it composes directly with our Details Law.

## 8. Realistic human formula (anti-AI-face)

```text
Character = [age / ethnicity] + [skin tone / skin texture] + [3-4 facial details]
          + [gaze / soul] + [hairstyle / hair color] + [clothing / fabric]
          + [build / emotion / aura]
```

- **Force-append the fidelity suffix:** "retaining real fine pores and skin texture" (optionally freckles, blemishes). This single clause is the official anti-plastic-skin fix.
- Facial details need 3-4 concrete points: eye shape, brow bone, nose bridge, lips, jawline.
- Gaze/soul = the emotion the eyes carry, separate from the facial geometry.
- Works for animated characters too — swap the texture register.

For one emotional transition, **2-4 observable cues are enough** (eye movement, brow tension, mouth, breathing, throat swallow, hands). More reads as overacting; abstract emotion words leave too much room.

## 9. Camera language

Officially understood without translation: extreme wide / wide / medium / close-up / extreme close-up; push in, pull out, pan, lateral move, follow shot, orbit, dive, dolly out, tilt, handheld shake; low angle, overhead, first-person; one-take shot, dolly zoom, aerial, FPV, bullet time, bounce speed ramp.

For rarer terms, keep the term **and** translate it to observable change: `term + target subject + visual change + foreground/background relationship + direction or speed`. Full pattern and vocabulary in `camera-lighting-vocabulary.md` §10.

Aperture and focal-length numbers are allowed, but the visible result phrased in words is what actually steers the model.

## 10. Transitions

The transition vocabulary (natural cut, fade, dissolve, flash, wipe, occlusion mask, match cut, action/whip cut, motion-relay, zoom-through, ink-wash) lives in `camera-lighting-vocabulary.md` §11. Seedance-specific usage:

```text
cut = [transition type] + [basic constraints] + [cut logic]
```

- Always attach the incantation: **"prohibit rigid cutting, prohibit objects appearing out of thin air"** — it is the official anti-jump-cut clause, repeated in every transition template.
- Transitions can be **delegated**: "From [natural cut / occlusion mask / ink-wash / match cut], choose the one that best fits the style of this film."
- Order-gate effects that must not fire early: "The ink-wash effect must only appear AFTER 25 seconds, triggered by the 'click' sound — absolutely no premature appearance."

## 11. Physics through consequences and triggers

2.5 renders real physics and couples it with audio. Exploit this in four moves:

1. **Declare the physics regime up front.** "Rain reflections on metal, water splashed by tires, and the specular refraction of exhaust flames must strictly obey real-world physics."
2. **Narrate consequences, not just actions.** Tires kick up water curtains; the impact shatters the bridge into a spider-web pattern; the shockwave blows the rain away in a ring. Action chains where each step forces the next ("hand grips jar → lid actually unscrews") double as QA — a broken chain exposes a failed generation instantly.
3. **Negatively constrain the known failure.** "No soft-body or mollusk-like twisting of the mecha structure (must maintain metallic rigidity)." "The amber stays attached to the palm and must not clip through the fingers."
4. **Gate events on triggers.** "Three seconds after she presses the button..." / "only when he says {now}..." — triggers beat raw seconds for anything tied to performance.

## 12. Video editing (partial re-render)

2.5 edits an existing video: replace a subject, swap a background, remove a watermark, change the spoken language — while everything else stays put. The canonical pattern:

```text
[Edit Goal] Edit @Video 1. Within <entire video or time range>,
<add / remove / replace / adjust> <object, region, or audio category>.
[Source Video Role] @Video 1 is the sole editing master. It defines <characters,
scene, actions, composition, camera movement, occlusion, audio, and event order>.
[Target Material Role] @Image 1 defines <attributes of the replacement>.
[Edit Scope] Modify only <object, region, time range, or audio category>.
[Content to Preserve] Keep <everything that must not change> from @Video 1.
```

- **Subject replacement** adds a `[Timeline Inheritance]` block: "<Target> inherits every appearance, motion, occlusion, and exit of <original>, including timing, duration, path, and speed changes." Close with the catch-all: "Except for the object explicitly modified above, keep all other people, props, scene content, camera movements, cuts, and event order from @Video 1 unchanged."
- **The preservation-clause opener.** For filmed footage, enumerate everything to keep before stating any change — down to focal length, aspect and floor perspective: "Fully preserve from @Video 1 the person's identity, face, hair, skin tone, lip movement, original voice, speech rhythm, expression, gestures, camera position, focal length, aspect ratio, wall and floor perspective, and total duration." The longer the keep-list, the less drift.
- **Anchor timing to speech, not seconds**, when the source has narration: "When they say {now look at my hand}, a golden amber appears in the palm." The voice is the timeline.
- **Slice long sources first.** Editing works best on clips ≤20s; longer sources stall or fail.
- **Audio-only edits** work: "Remove only the original background music. Keep the dialogue, lip sync, ambience, and action sound effects; preserve the visuals and editing rhythm."
- **Localization pattern** — shoot once, re-dub per market: "Replace the Chinese narration in @Video 1 with natural fluent Spanish, and replace the presenter with a Spanish woman. Keep the original camera movement, blocking, performance pacing, scene, and product; preserve the overall audio-visual rhythm."
- Background swap scope: "modify only the background outside the subject's silhouette."

## 13. Video extension

Any clip ≤30s extends by 4-30s per pass, nested repeatedly, **hard ceiling 60s**. The new prompt applies only to the appended segment; original frames are untouched. Required verbs: extend forward / extend backward / continue.

Forward:

```text
Extend @Video 1 forward. The first frame of the extended segment directly
continues from the last frame of @Video 1. Maintain continuity in <pose,
prop position, background, camera position, lighting, motion direction>.
Then, <new content>.
Keep each subject as the same continuous instance throughout: do not duplicate
or split it, and keep the person's appearance stable.
```

Backward (prepend a beginning): describe the preceding events, then define @Video 1's **first frame as the extension's explicit end state**. Gotcha: materials that belong to the source video only must be flagged — "<X> must not appear early in the backward extension" — or later characters leak into the past.

- Boundary frames connect visually, not pixel-identically.
- Extensions hold character look, art style **and voice timbre** even without re-supplied references — plot-only extension prompts work.
- Community-proven minimal extension prompt: "Extend the video. Keep character identity, facial structure, body proportions, lighting, art style, and the space fully unchanged. Only change camera movement; do not redesign character or action."

## 14. Ultra Long mode (30-180s)

A separate mode (not the same as extension): one submission, 30-180 seconds. Restate duration and aspect ratio at the top of the prompt. Two working registers:

- **Timestamped** (1-minute ambient pieces): windowed beats with per-window bans — "0-20s (quiet opening): fixed camera... no shake, no characters enter, hard cuts prohibited."
- **Narrative flow** (3-minute pieces): loose event chain with inline references — the official 3-minute example is a cat-waiter vlog listing a full day of beats with 12 image refs assigned by role, closed with "No subtitles throughout, no background music."

Plan pacing in advance — without timestamps or a beat chain the back half drifts. Under the hood the pipeline generates segment-by-segment, carrying the **last ~3 seconds of each segment as the reference for the next** — which is why hand-offs are smooth and why a weak middle segment propagates forward. On Xiaoyunque the same mechanism powers chained extension to 90s plus **segment reshoot**: select a bad span on the timeline and regenerate only it, everything outside stays identical — the cheapest fix for pop-in objects and missed expressions.

## 15. Blockout and green screen

The controllability king: lock space, camera and staging in 3D first, let the model render materials and light. Two granularities:

- **Coarse blockout** — primitive geometry as a "dynamic skeleton" (trajectories, blocking, camera path, cuts, light changes). **Map every primitive to a reference**: "The tall cylinder in @Video 1 corresponds to <Guide>. The rectangular block corresponds to <Display Cart>." Exclude the render style: "Do not use its gray geometry or empty scene." Best practice: **no limbed or winged models in coarse blockouts** — unless you write the full limb motion sequence, they go stiff.
- **Fine blockout** — complete 3D animation; the model re-renders materials, color and style only: "@Video 1 is a fine blockout reference. Preserve structure, action, spatial layout, camera position, camera movement, and cuts. Do not use its original gray materials or empty background. Re-render <subject> as <final subject>..." **Clean the viewport capture first**: remove path lines, coordinate axes, controllers and camera frustums. Coarse currently works better than fine.

Pipeline notes:

- Blender/Maya plugins ("Clay Renderer" / 白模渲染上传器) render the blockout and upload straight to Jimeng as the reference video. Blender ≥3.6 works; no C4D/3ds Max. Color-coding blockout objects is unreliable — disambiguate primitives via prompt text, not material colors.
- No 3D package? Xiaoyunque's 3D director stage reconstructs a blockout from a concept image, offers action/camera/prop libraries, and lets you **drag-draw the camera path in the viewport**, then renders the previz clip for you.
- A **camera-path diagram works as an image reference** too: supply a top-down route sketch as @Image N and write "follow the camera route in @Image N".
- **Green screen, both directions**: upload green-screen footage + scene refs ("composite the person naturally into the classroom from @Image 2"), or convert an existing video's background *into* green screen for downstream comps ("Change all the white backgrounds into green screen backgrounds. Remove the sound, keep it muted.").

## 16. Storyboard grids and keyframes

- **Storyboard grid as input**: one image, ≤15 panels official (practitioners have pushed 50), clean line art, minimal text. Declare the reading order and exclude the style: "@Image 1 provides a 12-panel storyboard grid for shot order and approximate composition. Read it left to right, top to bottom. Do not use the grid's line-art style, text labels, or placeholder characters." Then `Shot 1: ... Shot N: ...`
- **Multi-keyframe sequences**: "Use @Image 1 through @Image N as keyframes in this order", one key state per image. Independent images align better than a grid. Keyframes control stage order and key states, not exact frames.
- **First + last frame** works inside omni-reference mode — declare each anchor separately ("@Image 1 is the first frame... @Image 2 is the last frame..."), never jointly. Same aspect ratio required.
- This is where the `image` skill chains in: character sheets and keyframes from `animatic-keyframes.md` become the reference kit.

## 17. Failure modes and fixes

### Twins / face-blending in multi-person scenes
Fix. Per-subject binding (section 5) + explicit differentiation: "Their movements are not synchronized. Clothing colors, hairstyles, and facial features must all be distinct. No identical clones in the background."

### Same character in two states appears at the wrong time
Pre/post-transformation slots confuse the model. Fix. Bind each state to its time range explicitly; budget re-rolls — this is the flakiest binding in 2.5.

### Random subtitles or unwanted BGM
Fix. "Pure video, no subtitles, no background music" — reliable in 2.5. Repeat in the global tail.

### Plastic AI skin
Fix. "Retaining real fine pores and skin texture" + production language instead of "hyperrealistic 8k".

### Long-context plausibility slips
Over 30s the model can place a plausible object in an impossible spot (a freighter on dry concrete). Fix. State the world's hard constraints in the global tail; verify the full timeline before shipping — errors hide in the back half.

### The one-take that refuses to stay one take
2.5 errs by commission: it completes more instructions than rivals but may cut freely even when told "one continuous take". Fix. "One continuous shot, no cuts of any kind" + a camera path that never motivates a cut; if montage keeps leaking in, drop to a 10-15s window where one-takes are stable.

### Edit mode stalls or ignores the instruction
Fix. Source ≤20s (slice first); name @Video 1 as "the sole editing master"; one edit target per pass.

## 18. Economics and model choice

- Costs are real: a 30s/720p generation on Jimeng runs ~500-700 credits. Production budgets must assume re-rolls, extensions and segment reshoots — fix with edit/extend/reshoot instead of full regeneration whenever possible. Draft at 480p, finish at 720p.
- Versus Minimax H3 (the other frontier model of this launch window): **H3 errs by omission, Seedance 2.5 errs by commission** — H3 delivers a more filmic whole but drops shots from the list; 2.5 executes nearly every instruction but may misuse a reference or break a global constraint. Pick 2.5 for timestamp precision, dense shot choreography, 50-reference kits and the editing/blockout toolchain; pick H3 (or Kling/Veo) when overall cinematic coherence per credit matters more than instruction compliance.

## 19. Worked examples (official, verbatim)

### A. Restrained micro-acting — "Riverside Farewell" (29s one-shot)

The flagship official example for emotional performance. Abridged; the structure is what to copy:

```text
29-Second One-Shot (Ancient Costume Woman's Riverside Farewell)

[Global Scene Setting] Early morning by the river, a blurred small boat in the
background, a lonely farewell. Quiet, restrained. Cinematic, shallow depth of
field, soft natural light. The camera holds a close-up of the woman, imitating
the subjective POV of "him" standing opposite her. Subtle handheld breathing,
one continuous shot with no fast cuts.

[Character Styling] [Age/Ethnicity] 22-year-old East Asian woman, classical
gentle cinematic face. [Skin] Cool-toned fair skin, delicate and moist,
retaining realistic fine pores and natural skin texture. [Facial Features]
Slender elegant eyes (slightly moist), relaxed brows, delicate straight nose
bridge, full lips with a faint gentle smile, soft jawline. [Eyes/Soul] Deeply
affectionate gaze, eyes shimmering like spring water. [Hair] Jet-black hair in
a casual classical low bun, a plain jade hairpin. [Clothing] Minimalist pure
white cross-collar Hanfu. [Physique/Aura] Slender, delicate narrow shoulders,
gentle classical romantic aura.

[Core Performance] Restrained and nuanced. Capture the shifting gaze, the rise
and fall of breathing, slight lip trembling, subtle brow movements, nostril
changes, throat swallowing, and the natural process of a tear sliding down.

[Negative Prompts] No exaggerated crying, no fast cuts, no large body
movements, no extra dialogue, no BGM, no runny nose, no premature dropping
of tears.

[Emotion and Action Storyboard]
Stage 1: 0-3s [Questioning]. She looks directly into the lens, lips slightly
parted, and whispers: {Are you really leaving?} Emotion analysis: she is not
complaining — she is waiting for him to confirm an answer she already guessed.
Stage 2: 3-10s [Resignation] — swallowing the bitterness. ...
Stage 3: 11-17s [Remembering] — a 0.5-second dead-silent pause; her lips twitch
then press together, jaw tightens, throat swallows.
Stage 4: 18-23s [Regret] — she lowers her eyes, and only then do the tears
begin to fall. She shakes her head slightly, almost imperceptibly.
Stage 5: 24-29s [Letting Go] — extreme close-up. She forms a gentle smile and
says in a barely audible but steadied voice: {You can go.} (On the word "go"
there is a faint tremble, forcefully suppressed.)
```

Every stage: one state change, physical directives, emotional subtext, and the bans list names the exact collapse modes of *this* scene.

### B. Physics and prohibitions — sci-fi mecha chase (30s one-shot)

```text
30-Second One-Shot (Sci-Fi Mecha Chase and Transformation)

[Global Setting] A cyberpunk cross-sea bridge in 2077, heavy rain. Emphasize
extreme, realistic physical textures: rain reflections on metal, water
splashed by tires, and the specular refraction of exhaust flames must strictly
obey real-world physics. Hardcore sci-fi cinematic feel, high-contrast neon
(cyber-pink and icy blue), high-speed shutter. High-speed drone POV, one
continuous shot. Subject: a silver-and-black concept mecha motorcycle.

[Negative Prompts] No soft-body or mollusk-like twisting/clipping of the mecha
structure during movement (must maintain metallic rigidity); no human
entities; strictly remove irrelevant subtitles; force mute / no default BGM;
avoid copyrighted IP elements like Transformers or Tron.

[Timestamp Storyboard]
[00:00-00:08] [Extreme Speed] The camera skims the waterlogged road; the
spinning wide tires kick up massive water curtains meters high. Camera
subtext: convey speed through the physical interaction of rain, puddle
reflections and engine flames.
[00:09-00:16] [Evasion] The tires grind the road, sparking orange friction
sparks, executing a tight "S" curve.
[00:17-00:24] [Mid-Air Reassembly] During slow-mo hang time the armor flips,
deconstructs, and reassembles — strictly rejecting "noodle-like" soft-body
transformation.
[00:25-00:30] [Heavy Landing] The tonnage impact shatters the bridge surface
into a spider-web pattern; the shockwave blows the surrounding rain away in
an expanding ring. A frozen "superhero landing" as the final image.
```

Physics regime declared up front, every beat narrates a consequence, and each ban targets a known failure of exactly this material.

### C. Reference orchestration — museum heist one-take (17 refs, translated from the Jimeng manual cases)

```text
Photoreal suspense-film texture. Set at the museum charity gala of @Image 10;
main hall structure, twin staircases and central exhibit stay consistent
throughout; sub-spaces reference @Image 11 and @Image 12; lighting and
materials reference @Image 15 and @Image 17. Follow the camera route in
@Image 16; smart auto-cutting, cinema-grade camera moves.

[0-4s] Camera advances behind the shoulder of the @Image 4 waiter carrying
the @Image 14 silver champagne tray through the main hall; the @Image 5
curator greets guests at the staircase; the @Image 6 reporter raises a
camera. The @Image 1 blue-diamond necklace sits in its glass case.
[4-8s] The @Image 7 woman in red brushes past the @Image 8 magician in black
tails, who smiles faintly at the lens; the @Image 9 security chief watches
beside the case.
[8-11s] The chandelier dies; the hall snaps to the crimson emergency lighting
of @Image 13; the crowd falls silent; <a soft clink from the case>, then
<a short alarm>. (Low strings and heartbeat stop together) — keep only an
inhale, the glass clink and the alarm.
[11-16s] Close-ups in sequence: the curator frozen, the reporter raising the
camera, the woman in red stepping back. Lights return to warm gold; cut back
to the case — glass intact, the @Image 1 diamond gone.
[16-20s] Slow push toward the magician's lowered right hand; a tiny blue
glint inside his silver cuff; he lifts his eyes to the lens and smiles.

No subtitles, no logo, no watermark.
```

Seventeen references, every one role-bound per scene; the camera choreography is supplied as a route diagram (@Image 16), not prose; sound is designed per beat with the `< >` and `( )` markers.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/seedance-25.md -->


<!-- SOURCE_FILE_START: skills/video/references/seedance.md -->
# SOURCE FILE: `skills/video/references/seedance.md`

# Seedance reference (ByteDance)

## Contents

1. What Seedance is
2. Versions and specs
3. CLI parameters (1.x / 2.0 only)
4. The Details Law (read first)
5. 6-step prompt formula (quick)
6. Production-grade skeleton (11 blocks) — for dramatic / multi-shot work
7. The 5-second shot timeline (rhythm template)
8. Multi-shot syntax (unique capability)
9. Anti-mush guard block (when Seedance smears the cuts)
10. `@img1` character reference syntax
11. Camera movements (9 presets)
12. Negative prompts handling
13. Image-to-video rule
14. Audio (1.5+)
15. Failure modes and fixes
16. Worked example. 15-second tragicomedy as 3 × 5s clips
17. Seedance 2.5 → read `seedance-25.md`

---

## 1. What Seedance is

A ByteDance video model with the UNIQUE ability to generate several distinct shots in ONE generation. The only major model that can pack a mini-montage inside a single 5-10s clip. Good cinematic motion, strong at ads and short narrative.

## 2. Versions and specs

- Seedance 1.0 Pro. 1080p, 5-10s (API up to 12s). Strong multi-shot.
- Seedance 1.0 Lite. 720p, faster, cheaper.
- Seedance 1.5 Pro. Native audio and lip-sync added.
- Seedance 2.0. Improved motion, better audio, 9 camera movement presets, limited negative prompt support, up to 12 reference inputs via `@` tags. Since June 2026: native 4K, 10-bit color. 2.0 Mini: ~2× faster, ~30% cheaper, for drafts and batches.
- **Seedance 2.5** (released 2026-07-31). Native 30-second single-pass clip, up to 60s via extension, 30-180s in Ultra Long mode. 50 multimodal reference inputs (30 images + 10 video + 10 audio), video editing (partial re-render), 3D white-model camera blockout, realistic humans with multilingual lip-sync in 11 languages. **Full production reference: `seedance-25.md`.**

Resolutions. 480p, 720p, 1080p; 2.0 adds native 4K; 2.5 outputs 480p/720p on Jimeng.
Aspect ratios. 16:9, 4:3, 1:1, 3:4, 9:16, 21:9, 9:21.
Frame rate. 24-30 fps.

**Model pick within the family:** one continuous 15-30s arc, heavy reference kits, editing/extension of existing footage → 2.5 (realistic humans and lip-sync are a 2.5 headline feature — the 2.0-era face caution below does not apply to it). People-centric drama on a 2.0-only pipeline → 1.5 Pro (2.0 aggressively filters human faces and celebrity-adjacent content after the 2026 deepfake crackdown). Scenes, architecture, product, montage in short clips → 2.0. Cheap drafts → 2.0 Mini, then re-render keepers high.

## 3. CLI parameters (1.x / 2.0 only)

Append at the end of the prompt.

```text
--resolution 1080p --duration 5 --camerafixed false --seed 42
```

- `--resolution`. 480p | 720p | 1080p
- `--duration`. 2 to 12 (Pro)
- `--camerafixed`. true locks the camera. false allows movement.
- `--seed`. for reproducibility

**Not 2.5 syntax.** On 2.5, duration / aspect ratio / resolution are set on the generation page or via API and do not belong in the prompt (exception: Ultra Long mode restates duration and ratio at the top — see `seedance-25.md` §2).

## 4. The Details Law (read this first)

> **Details intensify emotion. Laziness kills the prompt.**

Seedance does not render abstractions. It renders **physical specifics**. Every adjective must be a sensory fact. Every emotion must be a body. Every shot must own at least three concrete details:

1. **One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC.
2. **One physical micro-action.** Jaw locks. Finger taps the counter. Knuckles whiten on the fork. Lips press into a line. He swallows hard.
3. **One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in the dark phone screen. Rain hitting the same windowpane.

If a shot has none of these — it is filler. Delete it or rewrite it.

Banned, lazy phrasing that produces mush:
- "cinematic, professional, high quality, masterpiece"
- "beautiful lighting"
- "epic scene"
- "amazing visuals"
- "he is sad / he is angry" (with no physical translation)

This rule is hard. Multi-shot prompts on Seedance fail not because of the model, but because the writer was lazy on a single shot. One thin shot drags the whole sequence down.

## 5. Six-step prompt formula (quick scenes)

For single-shot 5s clips with one clear action.

```text
Subject. [Who or what]
Motion. [Present-tense verb, one clear action]
Camera. [Movement + framing + lens]
Environment. [Where, props, atmosphere]
Lighting. [Direction + quality + color]
Style. [Realism level, genre reference]
```

Write in full sentences, not tags. Seedance prefers clear grammatical prose. For dramatic / multi-shot / character-locked work, **use the production-grade skeleton in section 6 instead.**

## 6. Production-grade skeleton (11 blocks)

Use this for any dramatic piece, multi-shot ad, music-video segment, or character-locked clip. Each block answers a specific failure mode. Skipping a block reintroduces that failure.

```text
[1] Character lock.
    Use @img1 as the main character reference and preserve the exact same person
    across the whole clip: <face shape, eye color, hair, facial hair, build, distinctive
    features>. Dress him in <exact wardrobe>. No nudity. No glasses (unless reference).
    No extra characters.

[2] Length + genre + editing intent.
    Generate a <duration>-second multi-shot <genre> sequence with <fast / slow / staircase>
    dynamic editing.

[3] Story (one paragraph).
    <Concrete physical events of this clip in present tense. What changes from start to
    end. Name the break point.>

[4] Visual style.
    <Palette, contrast, grain, color temperature, what to avoid (e.g. "no warm yellow
    tones"). Texture cues — realistic skin, food detail, fabric, surfaces.>

[5] Camera style.
    <Camera body / look (e.g. Sony FX3 handheld). Lenses with purpose:
    35mm / 50mm for medium, 85mm for emotional close-ups, 100mm macro for inserts,
    24mm for wide silhouettes. Handheld micro-shake or static. Strict cuts between
    shots. No continuous take.>

[6] Editing style.
    <Hard cuts vs match cuts. Rhythmic escalation. Where the pause lands. Where the
    impact hits. The rhythmic staircase: long → shorter → shorter → pause → impact.>

[7] Audio.
    <Diegetic sounds in order: ambient, micro-actions, impact, silence moment, final
    cue. Examples: stomach growl, refrigerator hum, fork clink, wet thud, abrupt
    silence, distant city ambience. No dialogue / No subtitles / No on-screen text.>

[8] Shot-by-shot timeline.
    Shot 1, 0.0–X.X sec: <framing, lens, camera move, action, environment detail,
                           emotion translated into body>.
    Shot 2, X.X–Y.Y sec: <...>.
    ...
    (See section 7 for the 5-second rhythm template.)

[9] Lighting (recap and specifics).
    <Main source, fill, rim. Direction. Color temperature. What it carries
    psychologically — judgment, isolation, hope, grief.>

[10] Composition.
    <Where the subject sits in frame across shots. Negative space. Reflections.
    Silhouettes. Foreground obstruction. The final image must be named.>

[11] Output specs.
    <Exact duration. Aspect ratio. Realism level. CLI: --resolution 1080p
    --duration 5 --camerafixed false>
```

Why 11 blocks and not 6? Each block prevents one specific Seedance failure: identity drift, one-take collapse, mood smear, lens chaos, audio mismatch, drift on rhythm. Cheap insurance.

## 7. The 5-second shot timeline (rhythm template)

For a 5-second multi-shot clip, the model performs best with **5 shot beats** following a dramatic micro-arc. Use this timing as the default scaffold:

```text
0.0–0.8 sec  | Establish     | extreme close-up or insert that anchors emotion / situation
0.8–1.6 sec  | Action        | medium shot, hero moves or reacts
1.6–2.5 sec  | Turn          | new framing reveals the shift (POV, OTS, rack focus)
2.5–3.6 sec  | Reaction      | tight close-up, slow push-in, emotion lands on the body
3.6–5.0 sec  | Climax / hero | hero shot, low angle, slow-mo if earned, final image
```

For 10s clips, double the structure or insert one pause before the climax (the pause beats speed). For 15s+ stories, split into 3 × 5s clips and stitch in the editor — Seedance is more reliable in shorter generations than one long take.

## 8. Multi-shot syntax (unique)

Seedance reads explicit cut markers inside a single prompt and generates distinct shots connected by visible cuts. This is its strongest card. Use it when you need montage in a single generation.

Supported cut markers.

```text
Shot 1. [description]
Cut to. [description]
Camera cut to. [description]
Camera switching. [description]
Lens switch to. [description]
```

Inline timeline syntax.

```text
[Shot A description] -> Cut to -> [Shot B description] -> Camera cut to -> [Shot C description]
```

Example.

```text
Shot 1. Medium close-up on a tired man in a kitchen. He opens the refrigerator.
Cut to. Macro insert. His hand reaches toward a single sausage on an empty shelf.
Cut to. Over-the-shoulder shot. The fridge light paints his face cold blue.
```

Use 2-3 shots per 5-second clip for tight cinematic montage, 4-5 shot beats only when each beat is short and physically distinct (see section 7). Hard cap: 5 shots per generation — beyond that the model drops or compresses shots. Size the duration to the shot count (4 shots need 10-15s, not 5s). Every shot must share an anchor with its neighbors — same character, same location, or same lighting recipe — or the model produces disconnected clips instead of a sequence.

## 9. Anti-mush guard block

Seedance sometimes ignores cuts and produces one continuous take, smears multiple shots into a single moving frame, or drifts character identity across the timeline. Drop this block at the **very top of the prompt** (before block [1]) when it happens or to prevent it pre-emptively on heavy multi-shot work:

```text
Important direction:
This must be a clearly edited multi-shot sequence with visible cuts between shots.
Do not generate a single continuous take. Each shot must have a different camera angle
and different framing. Use rapid montage pacing with rhythmic escalation. Keep the same
character appearance throughout. Preserve the same clothing, face, body type, facial
hair, and hairstyle in every shot. The tone is <serious cinematic drama / tragicomedy /
documentary realism / etc.>.
```

This is the highest-leverage paragraph in any Seedance prompt. Add it any time the model produced mush on a previous attempt.

## 10. `@img1` character reference syntax

Seedance 2.0 accepts image references inline using `@img1`, `@img2`, etc. Use this to lock the protagonist's likeness across all shots in a multi-shot clip and across multiple stitched clips.

```text
Use @img1 as the main character reference and preserve the exact same man across the
whole clip: <full identity block: face, eyes, hair, facial hair, build, distinctive
features, wardrobe>. No nudity. No glasses (unless in reference). No extra characters.
```

Rules.

- The full identity block must follow the `@img1` mention. The model needs the textual description as a backup signal — the image alone drifts.
- Repeat the identity block in **every** clip of a stitched sequence. Treat each generation as briefing a new intern.
- For multiple references (character + setting, character + outfit), label each: `@img1` is the protagonist, `@img2` is the location reference, `@img3` is the outfit reference. Then state the role inline.
- 2.0 also takes `@Video1` (motion/style reference, 480-720p) and `@Audio1` (voiceover / music) tags — state each reference's role in prose, e.g. "@Audio1 plays as the voiceover". Limits: 12 files total on 2.0 (up to 9 images, 3 videos, 3 audio); up to 50 on 2.5.

## 11. Camera movements (9 presets)

- Dolly Out. Reveals context, pulling away.
- Dolly In. Pushes into subject, builds tension.
- Pan Left / Pan Right. Horizontal reveal, landscape, row.
- Tilt Up / Tilt Down. Vertical reveal.
- Tracking. Follows a moving subject.
- Crane / Aerial. Epic scale, establishing.
- Handheld. Documentary, intimate, UGC.
- Zoom In / Zoom Out. Tension or detail.
- Hitchcock Zoom. "dolly out while zooming in" for vertigo effect.
- Static (via `--camerafixed true`). Locked frame.

Combine sparingly. Multiple camera moves in 5s rarely resolve cleanly.

## 12. Negative prompts

Seedance 1.0 Pro does NOT support negative prompts. No `--no blur` syntax works.

Seedance 2.0 adds limited negative prompt support but it's fragile and often ignored.

Workaround for 1.x/2.0. Always invert to positive phrasing. Instead of "no yellow tones" write "cold blue-gray palette with desaturated skin tones." Instead of "no distorted hands" write "anatomically correct hands with clear finger separation."

**Seedance 2.5 fixed this.** Direct bans are reliable: "pure video, no subtitles, no background music" actually suppresses them, and specific prohibition lists ("no exaggerated crying, no fast cuts") are a core part of the official 2.5 prompt structure. See `seedance-25.md` §7.

## 13. Image-to-video rule

When using a reference image, DO NOT describe elements already visible in the image. The model sees it. Describe only motion and camera work. Re-describing static elements creates identity drift.

Bad. "A man in red shirt stands in kitchen. He walks to the fridge."
Good. "He slowly walks toward the fridge, opens it with hesitation, freezes when he sees the empty shelves. Tracking shot from behind, 35mm."

## 14. Audio (1.5+)

Seedance 1.5 Pro, 2.0 and 2.5 generate native audio and support lip-sync. Include audio cues in the body of the prompt — treat the prompt as a sound brief.

```text
Audio. fridge hum, distant rain on window, one stomach growl at 2.3 sec, final silence.
```

Rules:

- Dialogue goes in **double quotes** on 1.5/2.0 — the model voices it, generates the voice and syncs lips to the cut. State the delivery: "Play her line dry and a little proud, his quiet and worn out." **On 2.5, use the dedicated markers instead**: dialogue in `{ }`, SFX in `< >`, music in `( )`, titles in `【 】` (see `seedance-25.md` §4).
- Keep lines short. Long monologues drift out of sync — split into several lines and hold sync with cuts. Still less robust than Veo for speech-first work.
- Write **"no music"** explicitly when you want none — otherwise the model lays an ad-style score under everything.
- Subtitles: describe the voiceover, then ask for "text along the bottom edge, timed to the voice".

## 15. Failure modes and fixes

### One continuous take when multi-shot was requested

Fix. Add explicit "Cut to" markers. Say "multi-shot sequence with visible hard cuts. Do not generate a single continuous take."

### Character drift across shots

Fix. Repeat the full identity block at each shot boundary inside the prompt.

### Motion ignored below 5 seconds

Fix. Minimum duration 5s for any scene that has multiple actions or camera moves.

### Negative phrasing ignored

Fix. Use positive substitutes. Seedance 1.0 has no negative parser.

### Multi-shot fails on 4+ shots in 5s

Fix. Cap at 2-3 shots per 5-second clip for tight cinematic, or 4-5 short beats following the section 7 timeline. If more shots are needed, split into multiple generations.

### Mood smear / "everything looks the same"

Fix. Each shot needs a distinct emotional function (Establish / Power / Pressure / Detail / Reaction / Shift / Impact / Aftermath — see dramaturgy.md §10, Layer 2). If two adjacent shots have the same function, the model averages them into the same frame. Vary function and framing in every cut.

### Lazy abstract phrasing produces lifeless clips

Fix. Apply the Details Law (section 4). Audit your draft: every shot must have one environmental pressure, one micro-action, one sound or visual motif anchor. Replace adjectives like "dramatic", "intense", "beautiful" with concrete physical facts.

### Human faces rejected or degraded (2.0)

After the 2026 deepfake crackdown, 2.0 aggressively filters human faces, helmets, sunglasses, and anything resembling protected IP or celebrity likeness. Fix. Route face-heavy drama to Seedance 2.5 (realistic humans are its headline feature), 1.5 Pro, Kling, or Veo; keep 2.0 for scenes, architecture, product and montage work. Use only owned or synthetic character references — the IP/celebrity filter applies on 2.5 too.

## 16. Worked example. 15-second tragicomedy as 3 × 5s clips

A 15s narrative is **never** one prompt. It is three self-contained 5-second prompts, each with the full character lock, the full visual style, the full audio block, and a different dramatic function. Stitch in the editor.

### Story spine
- Beat 1 (Clip A, 0-5s). Hunger. Hero opens an almost empty fridge. Discovers one lonely sausage. Despair flips to hope.
- Beat 2 (Clip B, 5-10s). Cooking. Pot, water, fire, sausage, bubbling, anticipation, hero shot lifting the sausage with a fork.
- Beat 3 (Clip C, 10-15s). Catastrophe. Sausage slips, falls, wet thud. Window. Bedroom. Hungry sleep. Cut to black.

### Clip A. Hunger (production-grade skeleton applied)

```text
Important direction:
This must be a clearly edited multi-shot sequence with visible cuts between shots.
Do not generate a single continuous take. Each shot must have a different camera angle
and different framing. Use rapid montage pacing.

Use @img1 as the main character reference and preserve the exact same man across the
whole clip: bald head, gray-green eyes, round expressive face, moustache, long black
braided goatee, short dark side hair tufts, slightly overweight build, tragicomic face.
Dress him in a dark oversized T-shirt and dark sweatpants. No nudity. No glasses.
No extra characters.

Generate a 5-second multi-shot tragicomic cinematic sequence with fast dynamic editing.

Story:
The man is hungry at night. He suddenly goes to the refrigerator, opens it, feels
disappointment because it is almost empty, then notices one lonely sausage and becomes
instantly hopeful.

Visual style:
Cold night kitchen. Blue-green refrigerator light. Desaturated colors. No warm yellow
tones. Slightly harsh LED reflections. Realistic cinematic look. High contrast but
natural skin texture. Subtle film grain. Realistic food detail.

Camera style:
Sony FX3 handheld look. 35mm and 50mm lenses for medium and close shots. 100mm macro
for inserts. Handheld micro-shake. Visible cuts between shots.

Editing style:
Fast montage with hard cuts. Each shot a different angle and framing. Tense rhythm,
escalating to the moment of discovery.

Audio:
Deep stomach growl, soft room tone, refrigerator hum, quiet footsteps, fridge door
sound. No dialogue. No subtitles. No on-screen text.

Shot 1, 0.0–0.8 sec. Extreme close-up of the man's eyes in darkness. He is awake,
hungry, tense. Static close shot, faint blue ambient light.
Shot 2, 0.8–1.6 sec. Medium handheld side shot. He sits up and walks fast to the
kitchen. Slight shake, push-in.
Shot 3, 1.6–2.6 sec. POV from inside the refrigerator. The door opens toward camera.
Cold blue-green light hits his face. Shelves almost empty. His face drops.
Shot 4, 2.6–3.5 sec. Rapid inserts: empty shelf, empty container, lonely sauce stain,
his sad eyes, his hand moving items aside.
Shot 5, 3.5–5.0 sec. Macro insert of one single sausage in the corner. Rack focus
from empty shelf to sausage. Smash cut to a slightly low-angle close-up of his face.
His eyes widen, despair flips to joy, tiny victorious smile.

Lighting:
Dark apartment, very low ambient fill. Main source is cold refrigerator light,
blue-green, top-front. Strong contrast. No warm kitchen light.

Composition:
Tight close-ups and inserts. Negative space inside the empty fridge. Final face shot
heroic and absurd.

--resolution 1080p --duration 5 --camerafixed false
```

Clips B and C follow the same structure with their own story paragraph, shot list, and final image. The character lock and visual style blocks are repeated **verbatim** in each clip — Seedance has no memory between generations.

### Older single-clip skeleton (kept for quick scenes)

For a single non-dramatic shot or a quick test, the original 6-step skeleton still works:

```text
Subject. [identity block with face, hair, clothing, distinguishing features].
Motion. [one clear present-tense action for the scene].
Camera. Shot 1. [framing, lens, movement]. Cut to. Shot 2. [framing, lens, movement]. Cut to. Shot 3. [framing, lens, movement].
Environment. [location, time of day, props, weather].
Lighting. [dominant source, direction, quality, color].
Style. [realism level, genre reference, palette].
Audio. [ambient, SFX, silence moments]. (1.5+ only)
Continuity. [what must remain constant across shots].

--resolution 1080p --duration 5 --camerafixed false
```

For dramatic, multi-shot, character-locked, or stitched-clip work — always use the 11-block production-grade skeleton from section 6.

## 17. Seedance 2.5 → read `seedance-25.md`

2.5 changes the workflow: a 15-30s narrative that used to be 3-6 stitched clips is now one generation with one continuous arc, extendable to 60s, with a separate Ultra Long mode to 180s. The dramaturgy does not change — the beat map from `dramaturgy.md` §10 moves inside a single prompt.

Everything 2.5-specific lives in **`seedance-25.md`**: the official prompt formulas, the `( ) < > { } 【 】` markers, the 50-slot reference discipline, stages + end states, video editing, extension, Ultra Long, blockout/green-screen pipeline, and the official worked examples. For any 2.5 production task, read that file before writing the prompt.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/seedance.md -->


<!-- SOURCE_FILE_START: skills/video/references/universal-rules.md -->
# SOURCE FILE: `skills/video/references/universal-rules.md`

# Universal rules — apply to every video model

These rules apply to Seedance, Kling, Veo, and any other AI video generator. They exist because all current video models share a common failure mode. They reward concrete physical direction. They punish abstraction, contradictions, and keyword spam. Ignoring these produces muddy generations regardless of which model you target.

Read this file after `dramaturgy.md` and before any model-specific file. The model-specific syntax sits on top of these rules — it does not replace them.

## Contents

1. The non-negotiable. Details intensify emotion (Details Law)
2. U1. Universal prompt skeleton
3. U2. Weight-at-start
4. U3. Show don't tell
5. U4. Natural language beats tag spam
6. U5. One primary camera move per shot
7. U6. Precise lens language
8. U7. Character consistency anchor
9. U8. No contradictions
10. U9. Concrete physical detail over abstract concept
11. U10. Duration discipline
12. U11. The final image rule
13. U12. The three-detail check (audit before sending)
14. U13. Reference role discipline
15. U14. Priority declaration

---

## 1. The non-negotiable. Details intensify emotion. Laziness kills the prompt.

This is the most violated rule in AI video, and the one reason most multi-shot prompts fail. The dramaturgy is fine — the writer just got lazy on a single shot, and that one thin shot drags the whole sequence into mush.

Every shot in every prompt owns at least three concrete physical details:

1. **One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC. (Kurosawa: weather is a character. See `dramaturgy.md` §9.)
2. **One physical micro-action.** Jaw locks. Knuckles whiten on the fork. Lips press into a line. He swallows hard. Fingers curl against the doorframe. (Show, not tell — the body is the only place where feelings render.)
3. **One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in a darkened phone screen. Rain on the same windowpane. A single fluorescent flicker before each cut.

If a shot has none of these — it is filler. Delete it or rewrite it. No exceptions for "establishing", "transition", or "hero product" shots — those are exactly the shots that go lazy first.

Words that do not render and mark the writer being lazy:

- "cinematic", "professional", "high quality", "masterpiece", "stunning", "epic", "amazing"
- "beautiful lighting", "dynamic camera", "intense moment", "powerful scene"
- "he is sad", "she is angry", "he is afraid" — emotions named without a body

Replace each with concrete physical facts. The full theory of why this works lives in `dramaturgy.md` §2 (Second law).

## 2. U1. Universal prompt skeleton

Build every prompt from these layers, roughly in this order:

```text
[Subject / Character]
[Action / Motion]
[Scene / Environment]
[Camera / Shot / Lens]
[Lighting / Atmosphere]
[Style / Mood / Palette]
[Sound / Audio]
[Duration / Aspect ratio / Resolution]
[Continuity rules]
[Negative constraints — only if the model supports them]
```

Model-specific skeletons live in their reference files (`seedance.md`, `kling.md`, `veo.md`). For dramatic / multi-shot / character-locked Seedance work, the production-grade 11-block skeleton in `seedance.md` §6 supersedes this generic skeleton.

## 3. U2. Weight-at-start

Generators put more attention on the first 30-40% of tokens. Lead with subject and action. Style modifiers go at the end. Camera, lighting, and environment live in the middle.

## 4. U3. Show don't tell

The model cannot render feelings. It renders bodies. Translate every emotion into a physical action.

- Bad. "He is scared."
- Good. "His jaw locks. He stops breathing for one beat. His fingers curl against the doorframe."

Calibration: for one emotional transition, **2-4 observable cues** (eye movement, brow tension, mouth, breathing, throat swallow, hands) are enough. Fewer leaves the model guessing; more reads as overacting.

## 5. U4. Natural language beats tag spam

Video models are not image models. Tag stuffing like "masterpiece, 4k, cinematic, beautiful" fails. Write in full cinematic sentences as if briefing a human DOP.

## 6. U5. One primary camera move per shot

Do not stack three camera moves in a 5-second clip. Pick one dominant move (dolly-in, pan, tracking, static). Layer a subtle micro-adjustment if needed (slight handheld shake, gentle rack focus). More than that produces visual chaos.

## 7. U6. Precise lens language

State the lens. "Shot on 50mm" works across all major models. Quick map:

- 24mm. wide, immersive, exaggerated space
- 35mm. natural documentary
- 50mm. intimate, human perspective
- 85mm. portrait, compressed background
- 100mm macro. texture, detail
- anamorphic 40mm. cinematic widescreen

Full vocabulary in `camera-lighting-vocabulary.md`.

## 8. U7. Character consistency anchor

Anchor identity at the START of every prompt. In a multi-clip sequence, repeat the full identity block in every single prompt. Video generators have no memory between generations. Treat every clip like briefing a brilliant intern with memory damage.

Identity block must include: face shape, eye color, skin tone. Hair color, length, style. Facial hair. Exact clothing items. Distinctive accessories.

Model-specific syntax for character locking:
- Seedance: `@img1` reference + identity block (see `seedance.md` §10)
- Kling 1.x – 2.x: Element Binding with 3-4 reference images (see `kling.md` §7)
- Kling 3.0: in-prompt `[Character A: <full identity>]` labels, optionally combined with Element Library (see `kling.md` §3)
- Veo: reference ingredients / JSON identity (see `veo.md`)

## 9. U8. No contradictions

The model obeys the strongest signal. Contradictions produce artifacts.

- Bad. "Still pond" + "flowing water."
- Bad. "Close-up" + "wide cinematic landscape."
- Bad. "Quiet moment" + "explosive action."

## 10. U9. Concrete physical detail over abstract concept

"Loneliness" does not render. "A man sitting alone, shoulders collapsed, face lit by blue phone glow, empty bottles on the table" does.

This is the same rule as the Details Law in section 1, viewed from a different angle. Section 1 is the audit. This is the principle.

Corollary — **consequence prompting**. Current models render real physics, so describe the consequence of an action, not just the action: tires kick up water curtains; the hand grips the jar and the lid actually unscrews; the impact shatters the surface into a spider-web pattern. Action chains where each step forces the next also work as QA — a broken chain exposes a failed generation at a glance.

## 11. U10. Duration discipline

Most models work in 5-10 second clips. Longer narratives live in multiple clips stitched in the editor. Do not cram a 30-second story into a 5-second prompt.

Default splits:

- 10s = 2 clips × 5s
- 15s = 3 × 5s
- 30s = 6 × 5s
- 60s = 12 × 5s

Three exceptions:
- Seedance — 2-3 shots inside one 5-10s clip via "Cut to" syntax (see `seedance.md` §8).
- Kling 3.0 — up to 6 shots inside one generation, up to 15s, with native audio and dialogue (see `kling.md` §3).
- Seedance 2.5 — up to 30s in one pass. The working structure is consecutive stages, each with one primary state change and an explicit visible end state (see `seedance-25.md` §6).

## 12. U11. The final image rule

Every clip needs a clear final frame. The model uses the ending as emotional destination.

- "Ends on his face frozen in the blue refrigerator light" beats "he stands there sadly."

The final image is also one of the five anchors (see `dramaturgy.md` §13). Naming it is non-negotiable.

## 13. U12. The three-detail check (audit before sending)

Before returning the final prompt to the user, audit every shot. Each shot must carry at least one of each:

1. Environmental pressure (lighting, weather, surface, sound of the room).
2. Physical micro-action on the body (jaw, hand, breath, eye, gesture).
3. Sound anchor or recurring visual motif tied to the emotional spine.

If a shot has zero, fix it before sending. If a shot has only one, ask whether you can make it two without bloat. The strongest prompts in this skill's worked examples always have all three.

Empty descriptors that fail this check: "establishing wide shot", "beautiful lighting", "dynamic camera move", "cinematic look", "intense moment", "dramatic close-up". Replace each with three concrete physical facts.

## 14. U13. Reference role discipline

Wherever a model accepts reference assets (Seedance `@Image/@Video/@Audio`, Kling Element Binding and Omni references, Veo ingredients), **every asset gets an explicit role written in the prompt**: what it defines (appearance, motion, voice, scene, camera path) and what to ignore ("Do not use the image background", "Do not use the people in the image").

- Bind each subject individually: "<Character A> corresponds to @Image 1 — use only the appearance, hairstyle, and clothing." Never the collective form "@Images 1 through 4 define four characters respectively" — it does not state which is which.
- Do not restate what a reference already defines. If a video reference carries the motion, name only the attributes to inherit; re-describing every action fights the reference.
- More assets is not more control. Control comes from role clarity; unassigned assets bleed into the frame.

Model-specific limits and templates live in the model files (`seedance-25.md` §5 has the fullest system).

## 15. U14. Priority declaration

When a prompt is overloaded (10+ scenes, many subjects, spatial tricks), adding more description makes it worse. Instead, declare priorities — the model cannot know what matters most unless told what to protect and what to sacrifice:

1. The core subject that must survive every shot.
2. The key shots that must appear.
3. The transitions where the model may freestyle.
4. The mandatory final frame.

This ranks above prompt-length discipline: a shorter prompt with declared priorities beats a longer one without them.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/universal-rules.md -->


<!-- SOURCE_FILE_START: skills/video/references/veo.md -->
# SOURCE FILE: `skills/video/references/veo.md`

# Veo reference (Google)

## Contents

1. What Veo is
2. Versions and specs
3. Prompt structure and length
4. Dialogue syntax (critical, unique)
5. SFX syntax
6. JSON prompts (powerful, unique)
7. Image-to-video (Veo 3.1)
8. Reference ingredients (3.1)
9. Failure modes and fixes
10. Skeleton and example

---

## 1. What Veo is

Google's cinematic video model with NATIVE synchronized audio. The only major generator that creates dialogue, SFX, and music in sync with the video and does lip-sync natively. Best for commercial polish, narrative with dialogue, and cinematic audio.

## 2. Versions and specs

- Veo 3. Text-to-video, native audio, 4 / 6 / 8 second clips.
- Veo 3.1. Adds image-to-video with First Frame, improved audio, reference ingredients, stronger motion coherence.

Duration. 4, 6, or 8 seconds.
Dialogue budget. Max 8 seconds of spoken audio per clip.

## 3. Prompt structure and length

Order matters. Lead with subject and camera. Quality modifiers go at the end.

```text
[Subject / Action]
+ [Environment / Setting]
+ [Camera / Shot Type / Lens]
+ [Lighting / Atmosphere]
+ [Style / Quality]
+ [Audio]
+ [Duration]
```

Sweet spot. 50-200 words.

- Shorter prompts = more creative latitude, less control.
- Longer prompts = tighter control, higher risk of contradictions.

## 4. Dialogue syntax (critical)

Veo is the only model that renders synced lip movement and voice. The syntax matters.

### Required format

Double quotes + lead-in verb (says, whispers, shouts, mutters, asks).

```text
A woman says, "Welcome to the future."
He whispers, "Don't move."
She shouts, "Get out!"
```

Colon after the lead-in verb works too and is often more reliable.

```text
A woman says: "Welcome to the future."
```

### Voice character modifiers

Place modifiers before the lead-in verb.

```text
He says in a weary voice, "We are fine. We are fine."
She whispers nervously, "I don't want to be here."
He shouts excitedly, "We did it!"
```

### Timing rule

Maximum 8 seconds of spoken audio. Cram too many words into a 5s clip and the delivery speeds up unnaturally. Cut the line until it fits.

## 5. SFX syntax

Three supported formats. Mix as needed.

```text
SFX: thunder cracks in the distance
Audio: rain on tin roof, distant traffic, one slow breath
(a loud thunderclap)
(key turning in a lock)
(wet footsteps on concrete)
```

Use labels `Audio:`, `Says:`, `SFX:` to separate sound direction from visual direction. The model needs an explicit signal that audio should be generated.

## 6. JSON prompts (powerful, unique)

Veo parses structured JSON. This prevents "concept bleed" where describing mood accidentally changes object colors. Use JSON for complex scenes with strict continuity needs.

### Full schema

```json
{
  "version": "veo-3.1",
  "output": {
    "duration_sec": 8,
    "fps": 24,
    "resolution": "1080p",
    "aspect_ratio": "16:9"
  },
  "global_style": {
    "look": "cinematic naturalism",
    "color": "cold blue-gray palette, desaturated skin",
    "mood": "quiet domestic tragedy",
    "reference": "Fincher-style motivated camera"
  },
  "continuity": {
    "characters": [
      {
        "id": "man",
        "description": "40s, tired eyes, stubble, dark blue t-shirt, grey sweatpants, barefoot"
      }
    ],
    "props": ["empty refrigerator", "single sausage", "chipped white plate"],
    "lighting_constant": "cold fridge light as key"
  },
  "scenes": [
    {
      "id": "01",
      "start": "0.0",
      "end": "3.0",
      "shot": {
        "type": "medium close-up",
        "framing": "eye-level, slightly offset",
        "camera": "slow push-in, 50mm"
      },
      "action": "He opens the fridge. His face catches the cold light. His eyes stop on the empty shelf.",
      "environment": "small kitchen, 3am, rain outside window",
      "lighting": "cold fridge light as key, warm window spill as rim",
      "audio": "fridge hum, distant rain, one stomach growl"
    },
    {
      "id": "02",
      "start": "3.0",
      "end": "8.0",
      "shot": {
        "type": "extreme close-up",
        "framing": "macro insert on hand",
        "camera": "static, 100mm macro"
      },
      "action": "His hand hovers over a single sausage. He picks it up slowly, exhales.",
      "environment": "inside the fridge",
      "lighting": "cold fridge light, high contrast",
      "audio": "quiet breath, soft plastic crinkle"
    }
  ]
}
```

### When to use JSON

- Multiple scenes in one generation.
- Strict character continuity across shots.
- Complex props that must stay the same color and size.
- When a prose prompt kept changing subject colors when you added mood words.

Not every Veo prompt needs JSON. For simple clips, prose is faster and often better.

## 7. Image-to-video (Veo 3.1)

Uses the static image as First Frame. Prompt guides motion and sound.

Rules.

- Do not re-describe static elements.
- Describe only motion, camera, light change, and audio.
- Add "maintain the subject from the first frame" to protect identity.

Example.

```text
Maintain the subject from the first frame. Slow push-in, 50mm. She exhales, her eyes shift to the left, one strand of hair falls across her forehead. Warm rim light grows stronger.

Audio: soft breath, distant traffic, one door closing in the next room.
Duration: 6 seconds.
```

## 8. Reference ingredients (3.1)

Upload multiple reference images (character, location, prop) and tag them in the prompt.

```text
The character from reference_1 walks into the location from reference_2 holding the object from reference_3.
```

Use when you need a specific character in a specific place with a specific object.

## 9. Failure modes and fixes

### Dialogue speeds up unnaturally

Fix. Cut the line to fit 8 seconds of natural speech. Test by reading aloud.

### Audio missing from output

Fix. Add explicit `Audio:`, `SFX:`, or `Says:` labels. Do not assume the model will infer audio from visual description.

### Camera direction ignored

Fix. Lead the prompt with camera. "Wide aerial shot" at the start beats "cinematic camera work" in the middle.

### Character color changes when mood words are added

Fix. Switch to JSON prompt. Lock the character description in the continuity block. Keep mood in global_style where it cannot bleed into object colors.

### Lip-sync off

Fix. Check the lead-in verb. "She says, ..." outperforms just quoted speech alone. Colon form often more reliable than comma.

### Prompt too long, model cherry-picks

Fix. Compress to the 50-100 word range. Or switch to JSON which handles length better because of structural separation.

## 10. Skeleton

### Prose version

```text
[Subject performing action] in [environment]. [Camera framing + lens + movement]. [Lighting direction + color temperature]. [Style + mood + palette].

Audio: [ambient sounds, SFX, music texture].
Says: [character] says, "[dialogue, max 8 seconds of speech]."
SFX: [punctual sound events].

Duration: [4 / 6 / 8] seconds.
```

### JSON version

See section 6. Copy the schema and fill in.

### Worked example. Commercial hero shot

```text
A woman in a cream silk blouse stands in front of a morning window, lifting a ceramic coffee cup to her lips. Medium close-up, 85mm, slow push-in. Warm window key from frame-left, soft bounce fill from frame-right. Cinematic naturalism, creamy palette, shallow depth of field.

Audio: distant city ambience, ceramic clink, one slow breath.
Says: She whispers to herself, "One more minute."
SFX: (spoon tapping ceramic at 2 seconds).

Duration: 6 seconds.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/video/references/veo.md -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/LICENSE -->
# SOURCE FILE: `skills/visual-asset-critic/LICENSE`

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2026 Yuri Strohm / WhyStrohm

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

<!-- SOURCE_FILE_END: skills/visual-asset-critic/LICENSE -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/SKILL.md -->
# SOURCE FILE: `skills/visual-asset-critic/SKILL.md`

---
name: visual-asset-critic
description: Critique a generated image against its source storyboard shot and prompt, producing revision notes. Use when the user has generated an image and wants feedback before committing. Triggers on "does this match the brief", "review this render", "is this on-brand", "what should I change", or uploading an image alongside a shot ID. The QA loop for AI visuals. Works even without a storyboard-architect run. Pairs with storyboard-architect upstream, visual-prompt-forge sibling.
---

# Visual Asset Critic

You are the editorial second-eye on AI-generated images. Most teams don't have one, they generate, glance, accept, and ship. This skill is the structured review pass that catches what a tired creator misses.

The output is a critique with concrete, actionable revision notes. Not vibes. Not "looks good." Specific, prompt-level or post-level fixes.

## When to use

Trigger when the user:

- Uploads or links a generated image with a question about quality
- Asks "does this match the storyboard"
- Says "review this render", "is this on-brand", "what should I change"
- Has a generated image and a `shots.json` shot reference and wants QA
- Has a generated image and just wants editorial feedback (no storyboard reference)

## What you produce

**Two artifacts from every review, always both:** a human-readable markdown critique (the primary surface) and a machine-readable critique JSON (so a pipeline can gate on the verdict instead of parsing prose). The JSON is detailed in Step 6; it never replaces the markdown.

The JSON goes to `output/critiques/round-{N}/{shot_id}.critique.json`. One file per shot
per round, never a shared filename. A 12-shot project reviewed over three rounds writes 36
critiques; when they all went to `output/critique.json` it kept one, and which one depended
on review order.

The markdown critique uses these sections:

```
## Verdict
ACCEPT / REVISE / REJECT, one line

## What's working
2–4 specific positives. Concrete observations, not flattery.

## What's not working
2–5 specific issues. Each one cites a layer. Brand Lock, Series Lock, Shot Spec, Composition, Technical, or Continuity.

## Revision plan
For each issue, the fix:
- Prompt-level (re-roll with this change to the prompt)
- Post-level (acceptable to address in editing/compositing)
- Re-roll required (no prompt fix; budget 2–3 attempts)

## Confidence
HIGH / MEDIUM / LOW, how sure you are about the verdict
```

## Inputs

You need:

| Input | Required? | Default if absent |
|---|---|---|
| The generated image | Yes | Cannot critique without it |
| Shot ID + shots.json | Recommended | If absent, ask for shot intent in a sentence |
| brand-lock.snapshot.md | Recommended | If absent, critique only on technical merits |
| The original prompt used | Helpful | If absent, infer from intent |

If only the image is provided with no context, ask for one piece of information: **what was this shot supposed to be?** A single sentence is enough to anchor the critique.

## Workflow

### Step 1. Establish intent

What was this shot supposed to do? Pull from:

- Shot's `rationale` field (if shots.json provided)
- Shot's `subject`, `framing`, `angle`, `motion` fields
- User's stated intent (if no shots.json)
- The beat this shot serves

If you can't establish intent in one sentence, ask. Don't critique blind.

### Step 2. Critique by layer

Read `references/critique-rubric.md` for the full rubric. Quick version, check the image against:

1. **Brand Lock**, does it respect palette, mood, "never" list?
2. **Series Lock**, does it match character/environment/lighting anchors?
3. **Shot Spec**, does framing/angle/composition match the spec?
4. **Composition**, does it reserve space for on-screen text if applicable?
5. **Technical**, skin texture, hands, eyes, anatomy, AI artifacts?
6. **Continuity**, if previous shots in the series are available, does it match?

For each layer, note: pass / soft fail / hard fail. The verdict aggregates these.

### Step 3. Map issues to fixes

For every "not working" point, the critique must say what to do about it. Three buckets:

**Prompt-level fix**, change the prompt and re-roll. Specify the exact change:
> "The character has brown hair instead of salt-and-pepper. Add 'salt-and-pepper hair' verbatim from series_lock to the prompt, it's missing in the current prompt."

**Post-level fix**, acceptable to address in compositing. Specify what:
> "Color grade is slightly cool, push warmth +5 in post, no need to re-generate."

**Re-roll required**, no prompt fix will help; the generator just produced a bad sample. Budget 2–3 attempts:
> "Hands are mangled. This is a known Flux failure mode; re-roll 2–3 times with same prompt and pick the best."

### Step 4. Verdict

| Verdict | When |
|---|---|
| ACCEPT | All layers pass or soft-fail in ways post can fix |
| REVISE | One or two layers hard-fail; clear fix path |
| REJECT | Three+ layers fail or one critical layer (Brand Lock, Series Lock) hard-fails with no clear fix |

### Step 5. Confidence

Be honest about uncertainty:

| Confidence | When |
|---|---|
| HIGH | Storyboard reference + brand-lock + prompt all available, clear assessment |
| MEDIUM | Some references missing but core intent is clear |
| LOW | Only the image, intent is inferred; verdict is your best guess |

HIGH is a factual claim about what you had, not a mood. `tools/validate_critique.py`
rejects a `1.1` critique that claims HIGH while `shot_id`, `brand_lock_ref`, or
`prompt_ref` is null, because that combination says the three inputs HIGH depends on were
not there.

### Step 6. Emit structured output (critique JSON)

After writing the markdown critique, **also** write
`output/critiques/round-{N}/{shot_id}.critique.json` conforming to
`templates/critique.schema.json` at version `1.1`. Same review, two surfaces. The markdown
is for the human; the JSON is so an automated QA loop (e.g. `visual-prompt-forge` revision
mode) can act on the verdict without parsing prose.

**Map the markdown to the schema, section for section:**

| Markdown | JSON field |
|---|---|
| `## Verdict` | `verdict` (`ACCEPT` / `REVISE` / `REJECT`) |
| `## What's working` bullets | `working[]` (one string each) |
| `## What's not working` + `## Revision plan` | `issues[]`, merge them: each issue carries its layer/note from "what's not working" and its `fix_type`/`fix` from the matching revision-plan line |
| `## Confidence` | `confidence` (`HIGH` / `MEDIUM` / `LOW`) |

**Provenance, all of it required at 1.1.** A verdict is a claim about specific bytes. Name
them, and hash them:

| Field | Value |
|---|---|
| `run_id`, `round` | from `run.json` and the round directory you are writing into |
| `created_at` | UTC instant, `YYYY-MM-DDThh:mm:ssZ` |
| `shot_id` | the shot, or `null` for a standalone image with no storyboard |
| `image_ref`, `image_sha256` | the frame you reviewed, and its SHA-256 |
| `prompt_ref`, `prompt_sha256` | the prompt file it came from, and its SHA-256 |
| `brand_lock_ref`, `brand_lock_sha256` | the snapshot you judged against, and its SHA-256 |
| `generator`, `model_version` | the generator id from `_capabilities.json`, and its model version |
| `seed` | if the generator exposes one, else `null` |

```bash
shasum -a 256 output/frames/round-1/shot_03.png \
              output/prompts/round-1/flux.txt \
              output/brand-lock.snapshot.md
```

Every one of those fields is required, and every one is nullable. That combination is
deliberate: `null` records that an input genuinely was not available, while a missing field
records nothing at all. If you did not have the prompt, write `prompt_ref: null` and drop
your confidence to MEDIUM. Do not omit the key.

The hashes are the point. Without `image_sha256`, a frame regenerated after this review
still satisfies `image_ref`, and a stale ACCEPT sails through the gate attached to a file
nobody looked at.

**Severity, assign one per issue.** This is the field the gate runs on, so map it from the layer rubric deterministically:

| Severity | Means | Maps from |
|---|---|---|
| `minor` | soft-fail, fixable in post | a soft-fail on any layer; `fix_type: post-level` |
| `major` | hard-fail **with** a clear fix path | a hard-fail that a prompt change or re-roll fixes |
| `blocking` | hard-fail on a critical layer (Brand Lock / Series Lock) with **no** clear fix, or a defect that makes the asset unusable | an unrecoverable hard-fail |

**Gating rule, the verdict is derived from severities, not chosen freely.** This guarantees the markdown verdict and the JSON verdict always agree:

- Any `blocking` issue ⇒ verdict is `REJECT`.
- Three or more `major` issues ⇒ verdict is `REJECT`.
- One or two `major` issues (and no blocking) ⇒ verdict is `REVISE`.
- Only `minor` issues, or none ⇒ verdict is `ACCEPT` (with post notes).

The three-major rule used to read "escalate to REJECT at your discretion." Discretion in a
gate is not a gate, and it disagreed with `references/critique-rubric.md`, which called
three hard fails a REJECT outright. It is now a threshold, and the validator enforces it.

Pick the markdown `## Verdict` by this same rule.

### Step 7. Run the gate

Writing a schema-valid critique is not the same as passing the gate. Run it:

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
```

Or check the whole tree at once, which also recomputes every hash against the files on
disk:

```bash
python tools/validate_provenance.py output/
```

This step is not optional and it is not someone else's job. A critique that says `ACCEPT`
while carrying a `major` issue is a bug, and the only reason to write a validator for that
bug is to actually run it. Before this step existed, the gate ran in CI against two
fixtures that ship in the repo and never once against a real client's critique.

Worked examples: `examples/critique.accept.json` and `examples/critique.revise.json` show
the shape at version `1.0`, which is still valid and carries no provenance.
`examples/worked-run/critiques/` shows version `1.1` with real hashes, two shots across two
rounds.

## Hard rules

### Rule 1. No vibes-based critique

"Looks great" / "feels off" without specifics is not a critique. Every observation must reference something in the image (composition, color, anatomy, lighting direction, etc.).

### Rule 2. Prompt-level fixes must be specific

"Change the prompt" is not a fix. "Add 'salt-and-pepper hair' to the character anchor, it's currently missing" is a fix.

### Rule 3. Don't critique what wasn't asked

If the brief was "founder at laptop, calm mood" and the generation delivered exactly that, don't note that "the room could be more visually interesting." That's scope creep, not critique.

### Rule 4. Be honest about generator limits

Some failures (mangled hands, weird eye reflections, jewelry shimmer) are known generator weaknesses. Surface them as such, don't pretend a different prompt will fix them. Recommend re-roll or post.

### Rule 5. When in doubt, ACCEPT and recommend post

Generation is one stage in a pipeline. If the image is 80% right and the gap is fixable in post, that's an ACCEPT with post notes. Don't send the user back to re-generate when an editor would handle it in 90 seconds.

## Reference

- `references/critique-rubric.md`, the full layer-by-layer rubric

## Example output

> ## Verdict
> REVISE
>
> ## What's working
> - Composition correctly reserves the right two-thirds for text overlay (matches shot_03 rationale)
> - Lighting direction matches series_lock (window-left, warm afternoon)
> - Mood reads as calm/considered, on-brand
>
> ## What's not working
> - **Series Lock, character mismatch.** The character has brown hair, but series_lock specifies "salt-and-pepper." This is a verbatim-anchor failure.
> - **Technical, left hand.** Hand on the laptop has six fingers (Flux known failure mode).
> - **Shot Spec, framing.** Generated as MS but spec called for MCU. Subject is too small in frame.
>
> ## Revision plan
> - **Hair:** Prompt-level. Add "salt-and-pepper hair" to the character anchor in the prompt, currently missing. Re-roll.
> - **Hand:** Re-roll required. Generate 2–3 more times with same prompt and pick a clean one.
> - **Framing:** Prompt-level. Change "medium shot" to "medium close-up" in the prompt. Re-roll.
>
> ## Confidence
> HIGH

## Handoff

After delivering the critique, if the verdict is REVISE, offer:

> "Want me to draft the revised prompt? Point `visual-prompt-forge` at this output tree in
> revision mode and it will re-emit prompts for just the shots that need them."

If the verdict is REJECT, do not offer that. REJECT means a blocking issue or three or more
major ones, which is a failure with no clear fix path, and revision mode is built to stop
there and ask. Say what blocked it and what decision it needs: a changed shot spec, a
changed brand-lock, or a different generator.

Don't auto-revise. The user picks. The critique you just wrote is exactly what closes that
loop.

<!-- SOURCE_FILE_END: skills/visual-asset-critic/SKILL.md -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/critique.accept.json -->
# SOURCE FILE: `skills/visual-asset-critic/examples/critique.accept.json`

{
  "version": "1.0",
  "shot_id": "shot_01",
  "brand_lock_ref": "brand-lock.snapshot.md",
  "image_ref": "frames/round-1/shot_01.png",
  "verdict": "ACCEPT",
  "confidence": "HIGH",
  "working": [
    "Framing matches the shot spec: MCU, eye level, subject anchored frame-left with negative space right.",
    "Character matches the series_lock anchor verbatim: salt-and-pepper hair, navy crewneck.",
    "Palette and color grade sit inside the brand-lock; nothing from the never-list appears.",
    "Hands, eyes, and skin texture are clean; no AI artifacts."
  ],
  "issues": [
    {
      "layer": "Technical",
      "severity": "minor",
      "note": "Color grade reads a touch cool versus the warm-afternoon spec.",
      "fix_type": "post-level",
      "fix": "Push warmth +5 in the grade. No re-generation needed."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/critique.accept.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/critique.revise.json -->
# SOURCE FILE: `skills/visual-asset-critic/examples/critique.revise.json`

{
  "version": "1.0",
  "shot_id": "shot_03",
  "brand_lock_ref": "brand-lock.snapshot.md",
  "image_ref": "frames/round-1/shot_03.png",
  "verdict": "REVISE",
  "confidence": "HIGH",
  "working": [
    "Composition reserves the right two-thirds of the frame for the text overlay, matching the shot_03 rationale.",
    "Lighting direction matches series_lock: window-left, warm afternoon.",
    "Mood reads as calm and considered, on-brand."
  ],
  "issues": [
    {
      "layer": "Series Lock",
      "severity": "major",
      "note": "Character has brown hair; series_lock specifies salt-and-pepper. Verbatim-anchor failure with a clear fix, so this caps the verdict at REVISE rather than forcing REJECT.",
      "fix_type": "prompt-level",
      "fix": "Add 'salt-and-pepper hair' to the character anchor in the prompt; it is currently missing. Re-roll."
    },
    {
      "layer": "Technical",
      "severity": "major",
      "note": "Left hand on the laptop has six fingers (known Flux failure mode).",
      "fix_type": "re-roll",
      "fix": "Re-roll 2-3 times with the same prompt and pick a clean sample."
    },
    {
      "layer": "Shot Spec",
      "severity": "minor",
      "note": "Generated as MS but the spec called for MCU; subject is slightly small in frame.",
      "fix_type": "prompt-level",
      "fix": "Change 'medium shot' to 'medium close-up' in the prompt. Re-roll."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/critique.revise.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/brand-lock.snapshot.md -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/brand-lock.snapshot.md`

<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->

# Brand Lock: WhyStrohm

## Identity

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#F5F0E8` | Cream, primary canvas |
| Ink | `#2A2A32` | Near-black, primary text and dark elements |
| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |
| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |
| Muted | `#7A7580` | Secondary text, captions |
| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

## Typography

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

## Mood adjectives

- operator (not creator)
- considered (not reactive)
- deterministic (not vibes-based)
- confident (without volume)
- defense-grade (not fragile)

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate the cream background
- never use coral as a flood color (only as accent or signature periods)
- never use em dashes in copy
- never use emojis in body copy
- never use bullet points in narrative copy
- never use clip-art or generic icon sets
- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- never use exclamation points in headlines
- never default to dark mode, light mode hybrid is the brand
- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

## Aspect ratios

- 9:16, primary for short-form social
- 16:9, long-form, hero films, web embeds
- 1:1, feed posts, podcast covers
- 4:5. Instagram feed alternative

## Color grade direction

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

## Motion language

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

## Voice rules

- no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no hype words
- prefer specific numbers over vague claims
- prefer present-tense over future-tense
- prefer "operator" over "creator", "infrastructure" over "agency"

---

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/brand-lock.snapshot.md -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/critiques/round-1/shot_01.critique.json -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/critiques/round-1/shot_01.critique.json`

{
  "version": "1.1",
  "run_id": "20260730T142300Z-9f2c1ab4",
  "round": 1,
  "created_at": "2026-07-30T14:41:00Z",
  "shot_id": "shot_01",
  "brand_lock_ref": "brand-lock.snapshot.md",
  "brand_lock_sha256": "f364bc71f68d16187d0721fbc092450174545e247f2f563a4c45686b4a877f50",
  "image_ref": "frames/round-1/shot_01.png",
  "image_sha256": "7c93763a04dacf1258cf8605cc6f3af45f0f7069f6fefe9bff2a14c0a779bd3d",
  "prompt_ref": "prompts/round-1/flux.txt",
  "prompt_sha256": "a0203e0c49cafd75d8fcb86997ba619c5ac82700dc4ab430812a9929aca89328",
  "generator": "flux",
  "model_version": "2 Pro",
  "seed": 481207,
  "verdict": "ACCEPT",
  "confidence": "HIGH",
  "working": [
    "Framing matches the spec: MCU, eye level, subject held frame-left with the right two-thirds open.",
    "Character matches the series_lock anchor verbatim: salt-and-pepper hair, navy crewneck.",
    "Lighting reads window-left, warm afternoon, as specified.",
    "Hands, eyes, and skin texture are clean."
  ],
  "issues": [
    {
      "layer": "Technical",
      "severity": "minor",
      "note": "Grade sits a touch cool against the warm-afternoon spec.",
      "fix_type": "post-level",
      "fix": "Push warmth +5 in the grade. No re-generation needed."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/critiques/round-1/shot_01.critique.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/critiques/round-1/shot_02.critique.json -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/critiques/round-1/shot_02.critique.json`

{
  "version": "1.1",
  "run_id": "20260730T142300Z-9f2c1ab4",
  "round": 1,
  "created_at": "2026-07-30T14:44:00Z",
  "shot_id": "shot_02",
  "brand_lock_ref": "brand-lock.snapshot.md",
  "brand_lock_sha256": "f364bc71f68d16187d0721fbc092450174545e247f2f563a4c45686b4a877f50",
  "image_ref": "frames/round-1/shot_02.png",
  "image_sha256": "d025648c33854b27eedb9b99fcebf81a4980e61f4fc69e387b0810490e29d6d4",
  "prompt_ref": "prompts/round-1/flux.txt",
  "prompt_sha256": "a0203e0c49cafd75d8fcb86997ba619c5ac82700dc4ab430812a9929aca89328",
  "generator": "flux",
  "model_version": "2 Pro",
  "seed": 481207,
  "verdict": "REVISE",
  "confidence": "HIGH",
  "working": [
    "Posture reads as release, which is the beat.",
    "Environment and lighting match the series_lock anchors."
  ],
  "issues": [
    {
      "layer": "Shot Spec",
      "severity": "major",
      "note": "Generated as MS but the subject reads too small for a payoff beat at 9:16.",
      "fix_type": "prompt-level",
      "fix": "Change 'medium shot' to 'medium close-up' in the prompt. Re-roll."
    },
    {
      "layer": "Technical",
      "severity": "major",
      "note": "Left hand on the desk is malformed, a known Flux failure mode.",
      "fix_type": "re-roll",
      "fix": "Re-roll 2-3 times with the same prompt and pick a clean sample."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/critiques/round-1/shot_02.critique.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/critiques/round-2/shot_02.critique.json -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/critiques/round-2/shot_02.critique.json`

{
  "version": "1.1",
  "run_id": "20260730T142300Z-9f2c1ab4",
  "round": 2,
  "created_at": "2026-07-30T15:19:00Z",
  "shot_id": "shot_02",
  "brand_lock_ref": "brand-lock.snapshot.md",
  "brand_lock_sha256": "f364bc71f68d16187d0721fbc092450174545e247f2f563a4c45686b4a877f50",
  "image_ref": "frames/round-2/shot_02.png",
  "image_sha256": "168ccb9e622e99e48a2a13f05a982ef906a32f4eee5a79974913f555789c6296",
  "prompt_ref": "prompts/round-2/revised-flux.txt",
  "prompt_sha256": "f9a807549ff558950dd8a01b8525f89f7e4d480e43d28273ec0182249de83cd7",
  "generator": "flux",
  "model_version": "2 Pro",
  "seed": 481207,
  "verdict": "ACCEPT",
  "confidence": "HIGH",
  "working": [
    "Reframed to MCU; the subject now carries the payoff beat.",
    "Hands are anatomically correct in this sample.",
    "Character, environment, and lighting still match the series_lock anchors."
  ],
  "issues": []
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/critiques/round-2/shot_02.critique.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/preview.html -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/preview.html`

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="generator" content="storyboard-html-preview / WhyStrohm">
<title>Worked Run, Two Shots · Storyboard</title>
<style>
/* ─────────────────────────────────────────────────────────────
   Storyboard HTML Preview · WhyStrohm
   Single-file output. No external deps. Prints clean.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Brand-lock variables, get substituted at compose time */
  --sb-color-bg: #F5F0E8;
  --sb-color-ink: #2A2A32;
  --sb-color-accent: #D94F3A;
  --sb-color-muted: #7A7580;
  --sb-color-rule: #E8E1D4;

  --sb-font-display: Inter Black 900, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-body: Inter Medium 500, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;

  --sb-radius: 6px;
  --sb-pad: 24px;
  --sb-gap: 32px;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; }

body {
  font-family: var(--sb-font-body);
  font-size: 16px;
  line-height: 1.55;
  color: var(--sb-color-ink);
  background: var(--sb-color-bg);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

a {
  color: var(--sb-color-accent);
  text-decoration: none;
  border-bottom: 1px solid currentColor;
}

code {
  font-family: var(--sb-font-mono);
  font-size: 0.9em;
  background: var(--sb-color-rule);
  padding: 1px 6px;
  border-radius: 3px;
}

h1, h2, h3 {
  font-family: var(--sb-font-display);
  font-weight: 800;
  line-height: 1.15;
  letter-spacing: -0.01em;
}

/* ─── Header ─── */

.sb-header {
  border-bottom: 1px solid var(--sb-color-rule);
  padding: 64px var(--sb-pad) 40px;
}

.sb-header-inner {
  max-width: 960px;
  margin: 0 auto;
}

.sb-eyebrow {
  font-family: var(--sb-font-mono);
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 16px;
}

.sb-title {
  font-size: clamp(32px, 5vw, 56px);
  margin-bottom: 32px;
}

.sb-meta {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 16px;
  font-size: 14px;
}
.sb-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-meta dd { font-weight: 600; }

/* ─── Nav ─── */

.sb-nav {
  position: sticky;
  top: 0;
  background: var(--sb-color-bg);
  border-bottom: 1px solid var(--sb-color-rule);
  z-index: 10;
  overflow-x: auto;
}

.sb-nav ul {
  display: flex;
  gap: 4px;
  list-style: none;
  max-width: 960px;
  margin: 0 auto;
  padding: 12px var(--sb-pad);
}

.sb-nav a {
  display: inline-block;
  padding: 4px 10px;
  font-family: var(--sb-font-mono);
  font-size: 12px;
  border: 1px solid var(--sb-color-rule);
  border-radius: var(--sb-radius);
  color: var(--sb-color-ink);
  white-space: nowrap;
}

.sb-nav a:hover {
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
  border-color: var(--sb-color-accent);
}

/* ─── Sections ─── */

.sb-section {
  max-width: 960px;
  margin: 0 auto;
  padding: 56px var(--sb-pad);
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-section h2 {
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: var(--sb-color-muted);
  margin-bottom: 24px;
}

.sb-brief p {
  font-size: clamp(18px, 2.5vw, 24px);
  line-height: 1.45;
  max-width: 700px;
}

/* ─── Series lock ─── */

.sb-series-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 24px;
}

.sb-series-grid > div {
  border-left: 2px solid var(--sb-color-accent);
  padding-left: 14px;
}

.sb-series-grid dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 4px;
}

.sb-series-grid dd {
  font-size: 15px;
  line-height: 1.5;
}

/* ─── Shots ─── */

.sb-shots {
  background: var(--sb-color-bg);
}

.sb-shot {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: var(--sb-gap);
  padding: 40px 0;
  border-bottom: 1px solid var(--sb-color-rule);
  scroll-margin-top: 60px;
}

.sb-shot:last-child { border-bottom: none; }

.sb-shot-frame {
  position: relative;
  width: 100%;
  background: var(--sb-color-rule);
  border-radius: var(--sb-radius);
  overflow: hidden;
}

.sb-shot-frame.aspect-9-16 { aspect-ratio: 9 / 16; }
.sb-shot-frame.aspect-16-9 { aspect-ratio: 16 / 9; }
.sb-shot-frame.aspect-1-1  { aspect-ratio: 1 / 1; }
.sb-shot-frame.aspect-4-5  { aspect-ratio: 4 / 5; }
.sb-shot-frame.aspect-21-9 { aspect-ratio: 21 / 9; }

.sb-shot-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.sb-placeholder {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: linear-gradient(135deg, var(--sb-color-rule) 0%, var(--sb-color-bg) 100%);
  color: var(--sb-color-muted);
}

.sb-placeholder-id {
  font-family: var(--sb-font-mono);
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0.05em;
}

.sb-placeholder-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

/* On-screen text overlay preview (rendered over the frame) */
.sb-overlay {
  position: absolute;
  left: 0; right: 0;
  padding: 0 16px;
  pointer-events: none;
}

.sb-overlay-center        { top: 50%; transform: translateY(-50%); text-align: center; }
.sb-overlay-lower-third   { bottom: 12%; text-align: center; }
.sb-overlay-upper-third   { top: 12%; text-align: center; }
.sb-overlay-left-third    { top: 50%; transform: translateY(-50%); text-align: left; }
.sb-overlay-right-third   { top: 50%; transform: translateY(-50%); text-align: right; }

.sb-overlay-text {
  display: inline-block;
  font-size: clamp(14px, 2.2vw, 22px);
  line-height: 1.1;
  text-shadow: 0 2px 8px rgba(0,0,0,0.4);
}

/* ─── Shot body ─── */

.sb-shot-body { display: flex; flex-direction: column; gap: 20px; }

.sb-shot-header {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: baseline;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-shot-id {
  font-family: var(--sb-font-mono);
  font-size: 16px;
  font-weight: 700;
  color: var(--sb-color-accent);
}

.sb-shot-time {
  font-family: var(--sb-font-mono);
  font-size: 13px;
  color: var(--sb-color-muted);
}

.sb-shot-beat {
  font-size: 13px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-weight: 600;
  color: var(--sb-color-muted);
  margin-left: auto;
}

.sb-shot-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  font-size: 13px;
}

.sb-shot-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-shot-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-shot-meta dd { font-weight: 600; }

.sb-shot-subject h3,
.sb-shot-vo h3,
.sb-shot-text h3,
.sb-shot-rationale h3 {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 6px;
  font-weight: 600;
}

.sb-shot-subject p,
.sb-shot-vo p,
.sb-shot-rationale p {
  font-size: 15px;
  line-height: 1.55;
}

.sb-shot-vo p {
  font-style: italic;
  color: var(--sb-color-muted);
}

.sb-text-content {
  font-family: var(--sb-font-display);
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 4px;
}

.sb-text-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  color: var(--sb-color-muted);
}

.sb-shot-rationale {
  background: var(--sb-color-rule);
  padding: 14px 16px;
  border-radius: var(--sb-radius);
  border-left: 3px solid var(--sb-color-accent);
}

.sb-shot-rationale p {
  font-size: 14px;
  font-style: italic;
}

/* ─── Footer ─── */

.sb-footer {
  padding: 40px var(--sb-pad);
  background: var(--sb-color-rule);
  font-size: 12px;
  color: var(--sb-color-muted);
}

.sb-footer-inner {
  max-width: 960px;
  margin: 0 auto;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 16px;
}

/* ─── QA verdict ─── */

.sb-verdict {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
  border: 1px solid var(--sb-color-rule);
  border-radius: 2px;
  font-family: var(--sb-font-body);
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--sb-color-muted);
  white-space: nowrap;
}

.sb-verdict-accept { border-color: var(--sb-color-ink); color: var(--sb-color-ink); }
.sb-verdict-revise { border-color: var(--sb-color-accent); color: var(--sb-color-accent); }
.sb-verdict-reject {
  border-color: var(--sb-color-accent);
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
}

.sb-verdict-round { font-weight: 400; letter-spacing: 0.04em; opacity: 0.75; }

.sb-provenance {
  max-width: 960px;
  margin: 0 auto;
  font-size: 11px;
  line-height: 1.7;
  color: var(--sb-color-muted);
}

.sb-provenance code {
  font-size: 10px;
  word-break: break-all;
}

/* ─── Responsive ─── */

@media (max-width: 720px) {
  .sb-shot {
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 28px 0;
  }
  .sb-section { padding: 40px var(--sb-pad); }
  .sb-header { padding: 48px var(--sb-pad) 28px; }
}

/* ─── Print ─── */
@media print {
  /* ─── Page setup ─── */
  @page {
    size: letter;
    margin: 0.5in;
  }

  /* ─── Color & background ─── */
  body {
    background: white;
    color: black;
    font-size: 10pt;
    line-height: 1.4;
  }

  a {
    color: black;
    border-bottom: none;
  }

  a[href]::after {
    content: " (" attr(href) ")";
    font-family: var(--sb-font-mono);
    font-size: 8pt;
    color: #555;
  }

  /* Don't print sticky nav, JS controls, or footer scripts */
  .sb-nav { display: none; }

  /* ─── Header ─── */
  .sb-header {
    border-bottom: 2px solid black;
    padding: 0 0 16pt;
    margin-bottom: 24pt;
    page-break-after: avoid;
  }

  .sb-eyebrow {
    color: black;
    font-size: 9pt;
  }

  .sb-title {
    font-size: 24pt;
    margin-bottom: 12pt;
  }

  .sb-meta {
    grid-template-columns: repeat(4, 1fr);
    gap: 12pt;
    font-size: 9pt;
  }

  .sb-meta dt {
    color: #555;
    font-size: 7pt;
  }

  /* ─── Sections ─── */
  .sb-section {
    padding: 16pt 0;
    border-bottom: 1pt solid #999;
    page-break-inside: avoid;
  }

  .sb-section h2 {
    font-size: 9pt;
    margin-bottom: 12pt;
  }

  .sb-brief p {
    font-size: 12pt;
  }

  /* ─── Series lock ─── */
  .sb-series-grid {
    grid-template-columns: 1fr 1fr;
    gap: 12pt;
  }

  .sb-series-grid > div {
    border-left: 2pt solid black;
  }

  .sb-series-grid dt {
    color: #555;
    font-size: 7pt;
  }

  .sb-series-grid dd {
    font-size: 10pt;
  }

  /* ─── Shots, one shot per page ─── */
  .sb-shots h2 {
    page-break-after: avoid;
  }

  .sb-shot {
    page-break-inside: avoid;
    page-break-before: always;
    grid-template-columns: 1fr 1.2fr;
    gap: 18pt;
    padding: 18pt 0;
    border-bottom: none;
  }

  .sb-shot:first-of-type {
    page-break-before: avoid;
  }

  .sb-shot-frame {
    background: #f0f0f0;
    border: 1pt solid #999;
    border-radius: 0;
  }

  .sb-placeholder {
    background: #f5f5f5;
    color: #666;
  }

  .sb-overlay-text {
    text-shadow: none;
    background: rgba(255,255,255,0.85);
    padding: 2pt 6pt;
    color: black;
  }

  .sb-shot-id {
    color: black;
    font-size: 12pt;
  }

  .sb-shot-time, .sb-shot-beat {
    color: #555;
  }

  .sb-shot-rationale {
    background: #f5f5f5;
    border-left: 2pt solid black;
    padding: 8pt 10pt;
    page-break-inside: avoid;
  }

  .sb-shot-rationale p {
    font-size: 9pt;
  }

  .sb-shot-meta dt,
  .sb-shot-subject h3,
  .sb-shot-vo h3,
  .sb-shot-text h3,
  .sb-shot-rationale h3 {
    color: #555;
    font-size: 7pt;
  }

  .sb-shot-subject p,
  .sb-shot-vo p {
    font-size: 9.5pt;
  }

  /* ─── Footer ─── */
  .sb-footer {
    background: white;
    border-top: 1pt solid #999;
    padding: 12pt 0;
    font-size: 8pt;
    page-break-before: always;
  }

  .sb-footer-inner {
    flex-direction: column;
    gap: 4pt;
  }
}


</style>
</head>
<body>

<header class="sb-header">
  <div class="sb-header-inner">
    <div class="sb-eyebrow">Storyboard · shots 1.2</div>
    <h1 class="sb-title">Worked Run, Two Shots</h1>
    <dl class="sb-meta">
      <div><dt>Duration</dt><dd>8s</dd></div>
      <div><dt>Aspect</dt><dd>9:16</dd></div>
      <div><dt>Framework</dt><dd>custom</dd></div>
      <div><dt>Run</dt><dd>2026-07-30T14:23:00Z</dd></div>
    </dl>
  </div>
</header>

<nav class="sb-nav" aria-label="Shot navigation">
  <ul>
    
    <li><a href="#shot_01">01</a></li>
    
    <li><a href="#shot_02">02</a></li>
    
  </ul>
</nav>



<section class="sb-section sb-series-lock">
  <h2>Series lock</h2>
  <dl class="sb-series-grid">
    <div>
      <dt>Character</dt>
      <dd>founder, mid-thirties, salt-and-pepper hair, navy crewneck</dd>
    </div>
    <div>
      <dt>Environment</dt>
      <dd>minimalist home office, white walls, oak desk, single houseplant</dd>
    </div>
    <div>
      <dt>Lighting</dt>
      <dd>soft natural side-light from a large window camera-left, warm afternoon golden hour</dd>
    </div>
    <div>
      <dt>Color grade</dt>
      <dd>warm filmic, muted teal shadows, slight grain</dd>
    </div>
  </dl>
</section>

<section class="sb-section sb-shots">
  <h2>Shots</h2>
  
  <article class="sb-shot" id="shot_01">
    <div class="sb-shot-frame aspect-9-16">
      
      <img src="frames/round-1/shot_01.png" alt="shot_01: hook" loading="lazy">
      
      

      
      <div class="sb-overlay sb-overlay-right-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">You are the bottleneck.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">01</span>
        <span class="sb-shot-time">0.0–3.0s</span>
        <span class="sb-shot-beat">hook</span>
        
        <span class="sb-verdict sb-verdict-accept">ACCEPT<span class="sb-verdict-round">round 1</span></span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder seated at the desk, hands still on the laptop, looking slightly off-camera, held frame-left with the right two thirds open</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"You are the bottleneck."</p>
        <p class="sb-text-meta">text_01 · display · right-third · enter 0.3s (fade-in) · exit 2.8s (hard-cut)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Opens on stillness so the first overlay lands in silence; frame-left placement reserves the space the hook needs.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_02">
    <div class="sb-shot-frame aspect-9-16">
      
      <img src="frames/round-2/shot_02.png" alt="shot_02: promise" loading="lazy">
      
      

      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #D94F3A;">Build the system instead.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">02</span>
        <span class="sb-shot-time">3.0–8.0s</span>
        <span class="sb-shot-beat">promise</span>
        
        <span class="sb-verdict sb-verdict-accept">ACCEPT<span class="sb-verdict-round">round 2</span></span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>push</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder leaning back from the laptop, shoulders dropping, a small almost-smile, desk surface visible</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Build the system instead."</p>
        <p class="sb-text-meta">text_02 · headline · lower-third · enter 4.0s (slide-up) · exit 8.0s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>The slow push and the released posture carry the payoff without a line of voiceover.</p>
      </div>
    </div>
  </article>
  
</section>

<footer class="sb-footer">
  <div class="sb-footer-inner">
    <div>
      Built against <a href="brand-lock.snapshot.md"><code>brand-lock.snapshot.md</code></a> (<code>f364bc71f68d</code>).
    </div>
    <div>Built with <a href="https://github.com/whystrohm/shotkit">shotkit</a> · WhyStrohm</div>
  </div>
  <div class="sb-footer-inner sb-provenance">
    <div>
      Run 20260730T142300Z-9f2c1ab4 started 2026-07-30T14:23:00Z. This page rendered 2026-07-30T15:20:00Z.
      
    </div>
  </div>
</footer>

<script>
// Keyboard navigation: arrow keys move between shots
(function() {
  const shots = Array.from(document.querySelectorAll('.sb-shot'));
  if (!shots.length) return;

  function shotInView() {
    const mid = window.innerHeight / 2;
    let best = 0;
    let bestDist = Infinity;
    shots.forEach((shot, i) => {
      const rect = shot.getBoundingClientRect();
      const dist = Math.abs(rect.top + rect.height / 2 - mid);
      if (dist < bestDist) { bestDist = dist; best = i; }
    });
    return best;
  }

  document.addEventListener('keydown', function(e) {
    if (e.target.matches('input, textarea')) return;
    const i = shotInView();
    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      const next = shots[Math.min(shots.length - 1, i + 1)];
      next.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      const prev = shots[Math.max(0, i - 1)];
      prev.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
})();
</script>

</body>
</html>

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/preview.html -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/prompts/round-1/flux.txt -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/prompts/round-1/flux.txt`

# Storyboard: Worked Run, Two Shots
# Generator: flux
# Model: 2 Pro
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Run: 20260730T142300Z-9f2c1ab4
# Round: 1

# shot_01, hook, 0.0-3.0s, MCU eye-level static
Medium close-up framing, camera at eye level, static. A founder, mid-thirties, salt-and-pepper hair, navy crewneck, seated at the desk with his hands still on the laptop keys, looking slightly off-camera. He is held in the left third of the frame and the right two thirds are left clear. Minimalist home office, white walls, oak desk, single houseplant. Soft natural side-light from a large window camera-left, warm afternoon golden hour. Shot at f/2.0, shallow depth of field, 50mm prime. Warm filmic, muted teal shadows, slight grain. Calm, considered mood. Photorealistic, natural skin texture, no AI artifacts.

# shot_02, promise, 3.0-8.0s, MS eye-level push
Medium shot, camera at eye level, pushing slowly toward the subject. A founder, mid-thirties, salt-and-pepper hair, navy crewneck, leaning back from the laptop with his shoulders dropping and a small almost-smile. The desk surface is visible in the lower frame. Minimalist home office, white walls, oak desk, single houseplant. Soft natural side-light from a large window camera-left, warm afternoon golden hour. Shot at f/2.0, shallow depth of field, 50mm prime. Warm filmic, muted teal shadows, slight grain. Calm, considered mood. Photorealistic, natural skin texture, no AI artifacts.

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/prompts/round-1/flux.txt -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/prompts/round-2/revised-flux.txt -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/prompts/round-2/revised-flux.txt`

# Storyboard: Worked Run, Two Shots
# Generator: flux
# Model: 2 Pro
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Run: 20260730T142300Z-9f2c1ab4
# Round: 2
# Revision of round 1. Shots not listed here already passed.

# shot_02, promise, 3.0-8.0s, MCU eye-level push, revision (was REVISE)
# fix [Shot Spec, major]: framing MS -> MCU, subject read too small in frame
# fix [Technical, re-roll]: left hand was malformed, same prompt, pick a clean sample
Medium close-up framing, camera at eye level, pushing slowly toward the subject. A founder, mid-thirties, salt-and-pepper hair, navy crewneck, leaning back from the laptop with his shoulders dropping and a small almost-smile. His hands rest loosely and are fully visible. Minimalist home office, white walls, oak desk, single houseplant. Soft natural side-light from a large window camera-left, warm afternoon golden hour. Shot at f/2.0, shallow depth of field, 50mm prime. Warm filmic, muted teal shadows, slight grain. Calm, considered mood. Photorealistic, natural skin texture, anatomically correct hands, no AI artifacts.

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/prompts/round-2/revised-flux.txt -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/run.json -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/run.json`

{
  "version": "1.0",
  "run_id": "20260730T142300Z-9f2c1ab4",
  "created_at": "2026-07-30T14:23:00Z",
  "shotkit_version": "3.0.0",
  "operator": "worked-example",
  "project": {
    "title": "Worked Run, Two Shots",
    "duration_s": 8,
    "aspect": "9:16",
    "framework": "custom"
  },
  "inputs": {
    "shots_ref": "shots.json",
    "shots_sha256": "24e5babc987ea595076aba90316bad23bdcf64a4f1e80ee0d4bef2fd29b55095",
    "text_overlays_ref": "text-overlays.json",
    "text_overlays_sha256": "5071e111d5a64c3dcfb3548061cabe7e00ec7505ce01314e85a0cd8328f0b89d",
    "brand_lock_ref": "brand-lock.snapshot.md",
    "brand_lock_sha256": "f364bc71f68d16187d0721fbc092450174545e247f2f563a4c45686b4a877f50",
    "brand_lock_source": "brand-packs/whystrohm.md",
    "brand_lock_configured": true
  },
  "generators": [
    {
      "id": "flux",
      "model_version": "2 Pro",
      "capabilities_sha256": "948776594cafead0455c9b3f12e47bdd58f27f1f9c5d49a93d908c0b08377ece"
    }
  ],
  "rounds": [
    {
      "round": 1,
      "started_at": "2026-07-30T14:23:00Z",
      "reason": "initial",
      "prompts": [
        {
          "generator": "flux",
          "ref": "prompts/round-1/flux.txt",
          "sha256": "a0203e0c49cafd75d8fcb86997ba619c5ac82700dc4ab430812a9929aca89328",
          "shot_ids": [
            "shot_01",
            "shot_02"
          ]
        }
      ]
    },
    {
      "round": 2,
      "started_at": "2026-07-30T15:02:00Z",
      "reason": "shot_02 came back REVISE on Shot Spec framing and a Technical hand defect",
      "prompts": [
        {
          "generator": "flux",
          "ref": "prompts/round-2/revised-flux.txt",
          "sha256": "f9a807549ff558950dd8a01b8525f89f7e4d480e43d28273ec0182249de83cd7",
          "shot_ids": [
            "shot_02"
          ]
        }
      ],
      "post_only_shots": []
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/run.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/shots.json -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/shots.json`

{
  "version": "1.2",
  "project": {
    "title": "Worked Run, Two Shots",
    "duration_s": 8,
    "aspect": "9:16",
    "framework": "custom"
  },
  "brand_lock_ref": "brand-lock.snapshot.md",
  "series_lock": {
    "character": "founder, mid-thirties, salt-and-pepper hair, navy crewneck",
    "environment": "minimalist home office, white walls, oak desk, single houseplant",
    "lighting": "soft natural side-light from a large window camera-left, warm afternoon golden hour",
    "color_grade": "warm filmic, muted teal shadows, slight grain"
  },
  "shots": [
    {
      "id": "shot_01",
      "beat": "hook",
      "start": 0.0,
      "end": 3.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "founder seated at the desk, hands still on the laptop, looking slightly off-camera, held frame-left with the right two thirds open",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_01",
      "vo": null,
      "rationale": "Opens on stillness so the first overlay lands in silence; frame-left placement reserves the space the hook needs."
    },
    {
      "id": "shot_02",
      "beat": "promise",
      "start": 3.0,
      "end": 8.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "push",
      "depth_of_field": "shallow",
      "subject": "founder leaning back from the laptop, shoulders dropping, a small almost-smile, desk surface visible",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_02",
      "vo": null,
      "rationale": "The slow push and the released posture carry the payoff without a line of voiceover."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/shots.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/examples/worked-run/text-overlays.json -->
# SOURCE FILE: `skills/visual-asset-critic/examples/worked-run/text-overlays.json`

{
  "version": "1.0",
  "overlays": [
    {
      "id": "text_01",
      "shot_id": "shot_01",
      "content": "You are the bottleneck.",
      "font": "Inter Black 900",
      "size": "display",
      "weight": "black",
      "color": "#2A2A32",
      "position": "right-third",
      "enter": { "at": 0.3, "animation": "fade-in" },
      "exit": { "at": 2.8, "animation": "hard-cut" }
    },
    {
      "id": "text_02",
      "shot_id": "shot_02",
      "content": "Build the system instead.",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#D94F3A",
      "position": "lower-third",
      "enter": { "at": 4.0, "animation": "slide-up" },
      "exit": { "at": 8.0, "animation": "fade-out" }
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/examples/worked-run/text-overlays.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/references/critique-rubric.md -->
# SOURCE FILE: `skills/visual-asset-critic/references/critique-rubric.md`

# Critique Rubric

The structured layer-by-layer pass. Use this as the checklist when reviewing a generated image.

## Layer 1. Brand Lock check

| Check | Pass | Soft fail | Hard fail |
|---|---|---|---|
| Palette | Image colors come from brand-lock palette | Colors close but slightly off | Colors not in palette at all |
| Mood adjectives | Image reads as the brand mood | Mood reads as adjacent (e.g. "calm" vs "neutral") | Image reads as a different mood (e.g. "energetic" when brief was "calm") |
| "Never" list | None of the items in the never list are present | One item in the never list shows softly | Multiple never-list violations |
| Aspect ratio | Matches `project.aspect` | Within a crop of the spec | Wrong aspect |

Hard fail on Brand Lock = REJECT or REVISE depending on whether prompt fix exists.

## Layer 2. Series Lock check

| Check | Pass | Soft fail | Hard fail |
|---|---|---|---|
| Character anchor | All described features visible | One minor feature off (e.g. wrong shirt color) | Wrong person (different age/race/build than anchor) |
| Environment | Matches series_lock | Slight environment drift | Different environment entirely |
| Lighting direction | Matches series_lock | Lighting is right but slightly different angle | Lighting from wrong direction (continuity break) |
| Color grade | Matches series_lock | Slight tonal drift | Different color grade |

Hard fail on Series Lock = REJECT (continuity break) or REVISE if specific fix available.

## Layer 3. Shot Spec check

| Check | Pass | Soft fail | Hard fail |
|---|---|---|---|
| Framing | Matches spec (ECU/CU/MS/etc.) | One step off (e.g. MS instead of MCU) | Two+ steps off |
| Angle | Matches spec | Slight angle variation | Wrong angle (low when spec was eye-level) |
| Subject action | Matches `subject` description | Subject doing similar but slightly different action | Subject doing wrong action |
| Depth of field | Matches if specified | Slight DOF variation | Deep when shallow was specified |

Soft fail = post-level fix or accept. Hard fail = revise.

## Layer 4. Composition check

| Check | Pass | Soft fail | Hard fail |
|---|---|---|---|
| Negative space for text | Reserved per spec | Reserved but tight | No reserved space, overlay won't fit |
| Subject placement | Matches rationale | Slightly off (subject in left-third vs right-third) | Subject blocks where text was meant to go |
| Eye-line | Looks where intended | Slight gaze direction off | Looking the wrong way |
| Headroom | Appropriate | Slightly tight or loose | Cropped at hairline / huge headroom |

Composition fails are usually prompt-level fixable. Re-roll with explicit composition language.

## Layer 5. Technical check

| Check | Pass | Soft fail | Hard fail |
|---|---|---|---|
| Hands | Anatomically correct | Slight finger weirdness | Six fingers, fused fingers, wrong joints |
| Eyes | Symmetrical, focused | Slight asymmetry | Wonky eyes, wrong reflections |
| Skin texture | Natural | Slightly plastic | Heavy AI plastic |
| Anatomy | Correct | Minor weirdness | Major anatomy errors |
| Background artifacts | Clean | Minor weirdness | Distorted text, melted objects, impossible geometry |

Technical hard fails are almost always **re-roll required**. The prompt was probably fine; the generator just produced a bad sample. Budget 2–3 re-rolls.

## Layer 6. Continuity check (if previous shots available)

| Check | Pass | Soft fail | Hard fail |
|---|---|---|---|
| Character match | Same person, same look | Slight drift | Clearly different person |
| Lighting continuity | Same direction, time of day | Subtle shift | Direction reversed, time of day jumped |
| Environment continuity | Same space | Slight environment drift | Different space |
| Color grade match | Identical | Subtle shift | Visibly different |

Continuity hard fails break the storyboard. REVISE with verbatim-anchor checks on the prompt.

## From pass/fail to severity

The tables above grade each check as pass, soft fail, or hard fail. The JSON critique
records a severity instead, and the verdict is derived from those severities. Map them
this way, and only this way:

| Rubric result | Severity | Why |
|---|---|---|
| Soft fail on any layer | `minor` | Post can absorb it. `fix_type` is usually `post-level` |
| Hard fail **with** a clear fix path | `major` | A prompt change or a re-roll resolves it |
| Hard fail on Brand Lock or Series Lock **with no** fix path | `blocking` | Nothing downstream recovers this |
| Any defect that makes the asset unusable | `blocking` | Same, regardless of layer |

## Aggregating verdict

The verdict follows from the severities. It is not a separate judgement:

| Severities present | Verdict |
|---|---|
| any `blocking` | REJECT |
| three or more `major` | REJECT |
| one or two `major` | REVISE |
| only `minor`, or none | ACCEPT (with post notes) |

`tools/validate_critique.py` enforces exactly this table, so a critique that disagrees with
it fails rather than shipping. Earlier versions of this file counted hard fails and called
3+ a REJECT while the skill said "escalate at your discretion." Those two rules disagreed,
and the disagreement is the reason the threshold is now a number.

Soft fails are noted but don't change the verdict on their own. If you have three or more of
them, look again: a cluster of soft fails usually means one of them is really a hard fail
you talked yourself out of.

## Speed bumps to remember

- **Don't critique what wasn't asked**, if the spec didn't call for cinematic mood, don't say "could be more cinematic"
- **Don't pile-on once verdict is set**, if you're rejecting, list the issues that drive the rejection; don't list every cosmetic concern
- **Be specific, always**, "lighting is off" is not a critique; "key light is camera-right but series_lock says camera-left" is
- **Cite the layer**, every issue gets tagged with which layer it falls under. This makes the fix path obvious
- **Distinguish prompt failure from generator failure**, if the prompt was fine and the generator produced garbage hands, that's "re-roll required", not "fix the prompt"

<!-- SOURCE_FILE_END: skills/visual-asset-critic/references/critique-rubric.md -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/templates/critique.schema.json -->
# SOURCE FILE: `skills/visual-asset-critic/templates/critique.schema.json`

{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://whystrohm.com/schemas/shotkit/critique.schema.json",
  "title": "Critique",
  "description": "Machine-readable verdict for one generated frame reviewed against its shot spec and brand-lock. The structured sibling of the markdown critique. Version 1.1 adds run provenance: the frame, prompt, and brand-lock are identified by content hash as well as by path, so a verdict can be proven to describe the bytes that were actually reviewed. Every provenance field is required at 1.1 and explicitly nullable, so an absent input is a recorded decision rather than an omission.",
  "type": "object",
  "required": ["version", "verdict", "confidence", "issues"],
  "additionalProperties": false,
  "properties": {
    "version": {
      "type": "string",
      "enum": ["1.0", "1.1"],
      "description": "1.1 adds run_id, round, created_at, the *_sha256 hashes, prompt_ref, generator, model_version, seed, and the meta passthrough. 1.0 documents remain valid and are treated as legacy: they carry a verdict with no proof of what it reviewed."
    },
    "meta": {
      "type": "object",
      "description": "Forward-compat passthrough for tooling that needs to annotate a critique without a schema bump. Ignored by core skills.",
      "additionalProperties": true
    },
    "run_id": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "pattern": "^[0-9]{8}T[0-9]{6}Z-[0-9a-f]{8}$" }
      ],
      "description": "The run this critique belongs to. Matches run.json:run_id. Format: UTC compact timestamp, a dash, then 8 hex characters."
    },
    "round": {
      "oneOf": [
        { "type": "null" },
        { "type": "integer", "minimum": 1 }
      ],
      "description": "Revision round, 1-indexed. Round 1 is the first generation pass."
    },
    "created_at": {
      "oneOf": [
        { "type": "null" },
        {
          "type": "string",
          "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$"
        }
      ],
      "description": "UTC ISO-8601 instant the critique was written. Second precision, trailing Z required."
    },
    "shot_id": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "pattern": "^shot_[0-9]{2,3}$" }
      ],
      "description": "Shot this frame was generated for. Null when critiquing a standalone image with no storyboard."
    },
    "brand_lock_ref": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "minLength": 1 }
      ],
      "description": "Path to the brand-lock.snapshot.md the frame was judged against, relative to the output directory root. Null when no brand-lock was available, which caps confidence at MEDIUM."
    },
    "brand_lock_sha256": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "pattern": "^[0-9a-f]{64}$" }
      ],
      "description": "SHA-256 of the brand-lock file as read. Null only when brand_lock_ref is null."
    },
    "image_ref": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "minLength": 1 }
      ],
      "description": "Path to the frame that was critiqued, relative to the output directory root."
    },
    "image_sha256": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "pattern": "^[0-9a-f]{64}$" }
      ],
      "description": "SHA-256 of the frame bytes as reviewed. This is what makes the verdict falsifiable: if the file at image_ref no longer hashes to this value, the verdict does not describe it."
    },
    "prompt_ref": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "minLength": 1 }
      ],
      "description": "Path to the prompt file the frame was generated from, relative to the output directory root. Null when the prompt is unknown, which caps confidence at MEDIUM."
    },
    "prompt_sha256": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "pattern": "^[0-9a-f]{64}$" }
      ],
      "description": "SHA-256 of the prompt file. Null only when prompt_ref is null."
    },
    "generator": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "pattern": "^[a-z0-9][a-z0-9-]*$" }
      ],
      "description": "Generator id that produced the frame. Must match an id in visual-prompt-forge/adapters/_capabilities.json. Null when unknown."
    },
    "model_version": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "minLength": 1 }
      ],
      "description": "Model version string as of generation, copied from the capability matrix entry. The matrix records what is current; this records what ran."
    },
    "seed": {
      "oneOf": [
        { "type": "null" },
        { "type": "integer" },
        { "type": "string", "minLength": 1 }
      ],
      "description": "Generation seed if the generator exposes one. Null when it does not."
    },
    "verdict": {
      "type": "string",
      "enum": ["ACCEPT", "REVISE", "REJECT"]
    },
    "confidence": {
      "type": "string",
      "enum": ["HIGH", "MEDIUM", "LOW"]
    },
    "working": {
      "type": "array",
      "description": "Concrete positives. Observations, not flattery.",
      "items": { "type": "string", "minLength": 1 }
    },
    "issues": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["layer", "severity", "note", "fix_type", "fix"],
        "additionalProperties": false,
        "properties": {
          "layer": {
            "type": "string",
            "enum": ["Brand Lock", "Series Lock", "Shot Spec", "Composition", "Technical", "Continuity"]
          },
          "severity": {
            "type": "string",
            "enum": ["minor", "major", "blocking"],
            "description": "Any blocking issue forces REJECT. One or two major issues cap the verdict at REVISE. Three or more major issues force REJECT. Enforced by tools/validate_critique.py, not by this schema."
          },
          "note": { "type": "string", "minLength": 1 },
          "fix_type": {
            "type": "string",
            "enum": ["prompt-level", "post-level", "re-roll"]
          },
          "fix": { "type": "string", "minLength": 1 }
        }
      }
    }
  },
  "allOf": [
    {
      "if": {
        "properties": { "version": { "const": "1.1" } },
        "required": ["version"]
      },
      "then": {
        "required": [
          "version",
          "run_id",
          "round",
          "created_at",
          "shot_id",
          "brand_lock_ref",
          "brand_lock_sha256",
          "image_ref",
          "image_sha256",
          "prompt_ref",
          "prompt_sha256",
          "generator",
          "model_version",
          "seed",
          "verdict",
          "confidence",
          "issues"
        ]
      }
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-asset-critic/templates/critique.schema.json -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/README.md -->
# SOURCE FILE: `skills/visual-asset-critic/tools/README.md`

# Tools

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

## Requirements

```bash
pip install pyyaml jsonschema
```

Standard library otherwise. No pandas, no numpy.

## Run everything

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

This is exactly what CI runs, so a green local run means a green PR.

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

## Repo checks

### `validate_skills.py`

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

```bash
python tools/validate_skills.py
```

### `validate_schemas.py`

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

```bash
python tools/validate_schemas.py
```

It validates schemas, not instances. For instances, see `validate_shots.py`.

### `validate_capabilities.py`

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

- every generator id has an adapter `.md` and every adapter `.md` has an entry
- no adapter advertises more words than its own `max_prompt_words` ceiling
- every adapter documents the `aspect_param` the matrix says to send
- no `notes` field cites a word count above its own ceiling
- warns when the matrix or an entry is past its 120-day freshness window

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

### `validate_brand_lock.py`

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

## Project checks

These run against a project's output directory, not the repo.

### `validate_shots.py`

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

### `validate_prompts.py`

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

### `validate_critique.py`

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

### `validate_provenance.py`

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

It catches, with a selftest for each:

- a frame regenerated after its critique (`image_sha256` no longer matches)
- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)
- a frame on disk with no critique for its round, never reviewed at all
- two critiques for the same shot in the same round, two operators colliding
- rounds that skip a number, or a critique whose `run_id` belongs to another run

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

## Rendering

### `shots-to-html.py`

Renders an output folder into a single `preview.html`.

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

### `copy-prompt.py`

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

## Internal modules

Not entry points. Imported by the tools above.

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.
- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

## Adding new tools

- Make it executable (`chmod +x`)
- Add a usage docstring at the top of the file
- Give it a `--selftest` that proves the check fires
- Document it in this README
- Wire it into `tools/check.sh`, which is what CI calls

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/README.md -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/_shotkit.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/_shotkit.py`

#!/usr/bin/env python3
"""
Shared helpers for the shotkit tools. Standard library only.

Everything here exists because more than one tool needs it. Hashing, brand-lock
parsing, and the capability-id list were duplicated or absent before; keeping one
copy is what stops the tools from disagreeing about what a brand-lock palette is
or which generator ids are real.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

CAPABILITIES_PATH = (
    REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters" / "_capabilities.json"
)

# Roles tools/shots-to-html.py maps onto CSS variables. Documented in
# docs/brand-lock-anatomy.md so a brand-lock author knows the names are load-bearing.
PALETTE_ROLES = ("background", "ink", "accent", "muted", "rule")

RUN_ID_RE = re.compile(r"^([0-9]{8}T[0-9]{6}Z)-[0-9a-f]{8}$")
ISO_INSTANT_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SHOT_ID_RE = re.compile(r"^shot_[0-9]{2,3}$")
TEXT_ID_RE = re.compile(r"^text_[0-9]{2,3}$")

HEX_RE = re.compile(r"#[0-9A-Fa-f]{6}")
PLACEHOLDER_HEX_RE = re.compile(r"#_{6}")

# | Role | `#RRGGBB` | Use | rows in a brand-lock Palette table.
PALETTE_ROW_RE = re.compile(
    r"^\|\s*([A-Za-z][A-Za-z0-9\s()/-]*?)\s*\|\s*`?(#(?:[0-9A-Fa-f]{6}|_{6}))`?\s*\|"
)

SNAPSHOT_TAKEN_RE = re.compile(r"<!--\s*snapshot taken:\s*(.+?)\s*-->")
SNAPSHOT_SOURCE_RE = re.compile(r"<!--\s*source:\s*(.+?)\s*-->")

IMAGE_EXTS = ("png", "jpg", "jpeg", "webp")


# --------------------------------------------------------------------------
# Hashing
# --------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    """SHA-256 of a file's bytes, read in chunks so large frames do not load whole."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    """SHA-256 of a string, UTF-8 encoded."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# Run identity
# --------------------------------------------------------------------------

def make_run_id(now: datetime | None = None, nonce: str | None = None) -> str:
    """Build a run_id. Pass `now` and `nonce` to make it reproducible in tests."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    if nonce is None:
        nonce = sha256_text(now.isoformat() + str(id(now)))[:8]
    return f"{stamp}-{nonce}"


def iso_instant(now: datetime | None = None) -> str:
    """UTC ISO-8601 to second precision with a trailing Z."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def run_id_timestamp(run_id: str) -> str | None:
    """Extract the compact timestamp from a run_id, or None if malformed."""
    m = RUN_ID_RE.match(run_id or "")
    return m.group(1) if m else None


# --------------------------------------------------------------------------
# JSON loading
# --------------------------------------------------------------------------

def load_json(path: Path) -> tuple[dict | list | None, str | None]:
    """Return (data, error). Exactly one of the two is None."""
    if not path.exists():
        return (None, f"file does not exist: {path}")
    try:
        return (json.loads(path.read_text(encoding="utf-8")), None)
    except json.JSONDecodeError as e:
        return (None, f"invalid JSON: {e}")
    except OSError as e:
        return (None, f"cannot read: {e}")


# --------------------------------------------------------------------------
# Capability matrix
# --------------------------------------------------------------------------

def capability_ids(caps_path: Path | None = None) -> set[str]:
    """Generator ids from the capability matrix. Empty set if it cannot be read."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return set()
    return {
        g["id"]
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


def capability_map(caps_path: Path | None = None) -> dict[str, dict]:
    """Generator id to its full capability entry."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return {}
    return {
        g["id"]: g
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


# --------------------------------------------------------------------------
# Brand-lock parsing
# --------------------------------------------------------------------------

def parse_palette(text: str) -> dict[str, str]:
    """Role (lowercased) to hex value, from a brand-lock Palette table."""
    palette: dict[str, str] = {}
    for line in text.splitlines():
        m = PALETTE_ROW_RE.match(line)
        if m:
            palette[m.group(1).strip().lower()] = m.group(2).strip()
    return palette


def palette_hexes(text: str) -> set[str]:
    """Every real (non-placeholder) hex in a brand-lock, lowercased."""
    return {h.lower() for h in HEX_RE.findall(text)}


def is_unconfigured(text: str) -> bool:
    """True when the brand-lock still carries template placeholders in its palette."""
    return bool(PLACEHOLDER_HEX_RE.search(text))


def parse_typography(text: str) -> dict[str, str | None]:
    """
    Pull font names out of a brand-lock Typography section.

    Matches the documented format:
        **Display font:** `Inter Black 900`, headline weight, ...
        **Body font:** `Inter Medium 500`, body copy, ...
        **Mono font:** `JetBrains Mono Regular`, code, data, ...

    Mono is optional. A brand-lock that declares one has three legal overlay fonts,
    not two, which is why the font check reads all three rather than assuming a pair.
    """
    out: dict[str, str | None] = {
        "display_font": None,
        "body_font": None,
        "mono_font": None,
    }
    # The value has to be backticked and sit immediately after the label. That is what
    # separates a real declaration from the template's instructional prose
    # ("**Display font:** font name, weights used (e.g. `Inter Black 900`)"), which
    # would otherwise resolve to the example font.
    for key, label in (
        ("display_font", "Display"),
        ("body_font", "Body"),
        ("mono_font", "Mono"),
    ):
        pattern = re.compile(
            r"^\*\*" + label + r"\s+font[^:*]*:?\*\*[ \t]*`([^`\n]+)`",
            re.IGNORECASE | re.MULTILINE,
        )
        m = pattern.search(text)
        if m:
            value = m.group(1).strip()
            if value and not value.startswith("_"):
                out[key] = value
    return out


def parse_snapshot_header(text: str) -> dict[str, str | None]:
    """The two provenance comments storyboard-architect writes at the top of a snapshot."""
    taken = SNAPSHOT_TAKEN_RE.search(text)
    source = SNAPSHOT_SOURCE_RE.search(text)
    return {
        "snapshot_taken": taken.group(1).strip() if taken else None,
        "source": source.group(1).strip() if source else None,
    }


# --------------------------------------------------------------------------
# Output-tree conventions
# --------------------------------------------------------------------------

def round_dirs(output_dir: Path, kind: str) -> list[tuple[int, Path]]:
    """
    Sorted (round_number, path) for output_dir/<kind>/round-N directories.

    `kind` is 'frames', 'critiques', or 'prompts'.
    """
    base = output_dir / kind
    if not base.is_dir():
        return []
    found: list[tuple[int, Path]] = []
    for child in base.iterdir():
        if child.is_dir() and child.name.startswith("round-"):
            suffix = child.name[len("round-"):]
            if suffix.isdigit():
                found.append((int(suffix), child))
    return sorted(found)


def find_frame(output_dir: Path, shot_id: str, round_no: int | None = None) -> Path | None:
    """
    Locate a frame for a shot by the path convention.

    Prefers the highest-numbered round under frames/, then falls back to the
    legacy flat generated/ directory so pre-3.0.0 projects still render.
    """
    candidates = round_dirs(output_dir, "frames")
    if round_no is not None:
        candidates = [(n, p) for n, p in candidates if n == round_no]
    for _, directory in reversed(candidates):
        for ext in IMAGE_EXTS:
            candidate = directory / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    legacy = output_dir / "generated"
    if legacy.is_dir():
        for ext in IMAGE_EXTS:
            candidate = legacy / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    return None


def critique_paths(output_dir: Path) -> list[Path]:
    """
    Every critique file in an output tree, newest layout first.

    New layout: critiques/round-N/shot_NN.critique.json
    Legacy:     critique.json at the output root
    """
    found: list[Path] = []
    for _, directory in round_dirs(output_dir, "critiques"):
        found.extend(sorted(directory.glob("*.critique.json")))
        found.extend(sorted(directory.glob("*.json")))
    legacy = output_dir / "critique.json"
    if legacy.exists():
        found.append(legacy)
    # Preserve order, drop duplicates from the two globs above.
    seen: set[Path] = set()
    unique: list[Path] = []
    for path in found:
        resolved = path.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(path)
    return unique


def as_overlay_ids(value) -> list[str]:
    """Normalise shots.json on_screen_text (null, string, or array) to a list."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []


def as_shot_ids(value) -> list[str]:
    """Normalise text-overlays.json shot_id (string or array) to a list."""
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/_shotkit.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/_template.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/_template.py`

#!/usr/bin/env python3
"""
The small template engine tools/shots-to-html.py renders preview.html.tpl with.

Only the subset the template actually uses is implemented, deliberately: variable
substitution, a loop, and a truthiness block. It exists so the CLI and the
storyboard-html-preview skill render the same structural template instead of two
hand-maintained copies that drift apart.

Supported syntax:
    {{name}}            HTML-escaped substitution
    {{{name}}}          raw substitution, for pre-built markup such as inlined CSS
    {{#each items}}     iterate a list of dicts; inside the block, keys resolve
    {{/each}}           against the item first, then the enclosing context
    {{#if name}}        render when the value is truthy
    {{/if}}

Unknown names render empty rather than raising, which keeps a partially populated
context from producing a traceback in front of a client.
"""

from __future__ import annotations

import html
import re

BLOCK_RE = re.compile(r"\{\{#(each|if)\s+([A-Za-z0-9_]+)\s*\}\}")
RAW_VAR_RE = re.compile(r"\{\{\{\s*([A-Za-z0-9_]+)\s*\}\}\}")
VAR_RE = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")


def escape(value) -> str:
    """HTML-escape a value for text and attribute contexts, including quotes."""
    if value is None or value is False:
        return ""
    if value is True:
        return "true"
    return html.escape(str(value), quote=True)


def _find_block_end(text: str, kind: str, start: int) -> int:
    """Index of the closing tag matching the block opened before `start`."""
    open_re = re.compile(r"\{\{#" + kind + r"\s+[A-Za-z0-9_]+\s*\}\}")
    close_tag = "{{/" + kind + "}}"
    depth = 1
    pos = start
    while depth:
        next_close = text.find(close_tag, pos)
        if next_close == -1:
            raise ValueError(f"unclosed {{{{#{kind}}}}} block")
        next_open = open_re.search(text, pos, next_close)
        if next_open:
            depth += 1
            pos = next_open.end()
            continue
        depth -= 1
        pos = next_close + len(close_tag)
    return pos


def render(template: str, context: dict) -> str:
    """Render `template` against `context`."""
    out: list[str] = []
    pos = 0

    while pos < len(template):
        block = BLOCK_RE.search(template, pos)
        if not block:
            out.append(_render_leaf(template[pos:], context))
            break

        out.append(_render_leaf(template[pos : block.start()], context))
        kind, name = block.group(1), block.group(2)
        body_start = block.end()
        block_end = _find_block_end(template, kind, body_start)
        close_len = len("{{/" + kind + "}}")
        body = template[body_start : block_end - close_len]

        value = context.get(name)
        if kind == "each":
            for item in value or []:
                scoped = dict(context)
                if isinstance(item, dict):
                    scoped.update(item)
                else:
                    scoped["this"] = item
                out.append(render(body, scoped))
        else:
            if value:
                out.append(render(body, context))

        pos = block_end

    return "".join(out)


def _render_leaf(text: str, context: dict) -> str:
    """Substitute variables in a chunk with no block tags left in it."""
    text = RAW_VAR_RE.sub(lambda m: str(context.get(m.group(1), "") or ""), text)
    return VAR_RE.sub(lambda m: escape(context.get(m.group(1))), text)

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/_template.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/check.sh -->
# SOURCE FILE: `skills/visual-asset-critic/tools/check.sh`

#!/usr/bin/env bash
# Run every shotkit check. This is what CI calls, so a green local run means a green PR.
#
# Usage:
#   ./tools/check.sh            # run everything, report a summary
#   ./tools/check.sh --quiet    # only print failures and the summary
#
# Requires: pip install pyyaml jsonschema

set -uo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.." || exit 1

PYTHON="${PYTHON:-python3}"
QUIET=0
[[ "${1:-}" == "--quiet" ]] && QUIET=1

PASSED=0
FAILED=0
FAILED_NAMES=()

run() {
  local label="$1"
  shift
  local output
  if output=$("$PYTHON" "$@" 2>&1); then
    PASSED=$((PASSED + 1))
    if [[ "$QUIET" == "0" ]]; then
      echo "PASS  ${label}"
      sed 's/^/      /' <<<"$output"
      echo
    else
      echo "PASS  ${label}"
    fi
  else
    FAILED=$((FAILED + 1))
    FAILED_NAMES+=("$label")
    echo "FAIL  ${label}"
    sed 's/^/      /' <<<"$output"
    echo
  fi
}

echo "shotkit checks, using $("$PYTHON" --version 2>&1)"
echo

# Preflight the two dependencies. Without this, a missing package turns one actionable
# line into fourteen identical failures and you have to read all of them to find out.
missing=""
"$PYTHON" -c 'import yaml' 2>/dev/null || missing="pyyaml"
"$PYTHON" -c 'import jsonschema' 2>/dev/null || missing="${missing:+$missing }jsonschema"
if [[ -n "$missing" ]]; then
  echo "Missing Python package(s): ${missing}" >&2
  echo >&2
  echo "  ${PYTHON} -m pip install ${missing}" >&2
  echo >&2
  echo "Then re-run ./tools/check.sh" >&2
  exit 1
fi

# Structure and schemas
run "skills: frontmatter"            tools/validate_skills.py
run "schemas: are valid schemas"     tools/validate_schemas.py

# Capability matrix, including prose parity with the adapter files
run "capabilities: selftest"         tools/validate_capabilities.py --selftest
run "capabilities: matrix"           tools/validate_capabilities.py

# Brand-locks: packs allow templates, snapshots do not
run "brand-lock: selftest"           tools/validate_brand_lock.py --selftest
run "brand-lock: packs"              tools/validate_brand_lock.py \
  brand-packs/_template.md \
  brand-packs/whystrohm.md \
  brand-packs/examples/saas-clean.md \
  skills/brand-lock-extractor/examples/brand-lock.md
run "brand-lock: snapshots"          tools/validate_brand_lock.py --snapshots

# Storyboard instances, the rules JSON Schema cannot express
run "shots: selftest"                tools/validate_shots.py --selftest
run "shots: bundled examples"        tools/validate_shots.py --examples
run "shots: worked run"              tools/validate_shots.py \
  skills/visual-asset-critic/examples/worked-run

# Prompt files: the forge's hard rules, including verbatim series_lock anchors
run "prompts: selftest"              tools/validate_prompts.py --selftest
run "prompts: worked run"            tools/validate_prompts.py --examples

# Critique gate
run "critique: selftest"             tools/validate_critique.py --selftest
run "critique: fixtures"             tools/validate_critique.py --examples

# Provenance chain
run "provenance: selftest"           tools/validate_provenance.py --selftest
run "provenance: worked run"         tools/validate_provenance.py --examples --require-accept

# Tools that ship as part of the workflow
run "preview renderer: selftest"     tools/shots-to-html.py --selftest
run "prompt helper: selftest"        tools/copy-prompt.py --selftest

echo "─────────────────────────────────────────"
echo "${PASSED} passed, ${FAILED} failed"
if ((FAILED)); then
  printf 'failed: %s\n' "${FAILED_NAMES[@]}"
  exit 1
fi
exit 0

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/check.sh -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/copy-prompt.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/copy-prompt.py`

#!/usr/bin/env python3
"""Copy a shot prompt from a shotkit prompts file to the system clipboard.

Handles both file shapes the forge writes: a full pass, and a revision file where each
shot block carries `# fix [...]` annotations above the prompt. Comment lines inside a
block are treated as annotations and never land in the clipboard, so what you paste
into a generator is the prompt and nothing else.

Usage:
  python tools/copy-prompt.py output/prompts/round-1/flux.txt
  python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
  python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
  python tools/copy-prompt.py --selftest
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

# A shot block opens with the shot id near the start of a comment line. The forge's
# revision format prefixes it, so both of these are headers:
#   # shot_03, reframe, 11.0-16.0s, MCU eye-level push
#   # shot_03, promise, 3.0-8.0s, MCU eye-level push, revision (was REVISE)
#   # Revision of shot_03 (was REVISE)
SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT_LINE = re.compile(r"^\s*#")


class Block:
    __slots__ = ("shot_id", "header", "annotations", "body")

    def __init__(self, shot_id: str, header: str) -> None:
        self.shot_id = shot_id
        self.header = header
        self.annotations: list[str] = []
        self.body: list[str] = []

    def prompt(self) -> str:
        return "\n".join(self.body).strip()

    def label(self) -> str:
        note = f"  [{len(self.annotations)} fix note(s)]" if self.annotations else ""
        return f"{self.header}{note}  ({len(self.prompt())} chars)"


def get_clipboard_command() -> list[str] | None:
    """Return the platform-appropriate clipboard command, or None if unavailable."""
    if sys.platform == "darwin":
        return ["pbcopy"]
    if sys.platform.startswith("linux"):
        if shutil.which("xclip"):
            return ["xclip", "-selection", "clipboard"]
        if shutil.which("xsel"):
            return ["xsel", "--clipboard", "--input"]
        return None
    if sys.platform == "win32":
        return ["clip"]
    return None


def parse_prompt_text(text: str) -> list[Block]:
    """Split a prompt file into shot blocks, separating annotations from prompt body."""
    blocks: list[Block] = []
    current: Block | None = None

    for line in text.splitlines():
        match = SHOT_HEADER.match(line)
        if match:
            current = Block(match.group(1), line.strip())
            blocks.append(current)
            continue
        if current is None:
            continue  # file-level header comments, before the first shot block
        if COMMENT_LINE.match(line):
            current.annotations.append(line.strip())
        else:
            current.body.append(line)

    return [b for b in blocks if b.prompt()]


def parse_prompt_file(path: Path) -> list[Block]:
    return parse_prompt_text(path.read_text(encoding="utf-8"))


def copy_to_clipboard(text: str) -> bool:
    cmd = get_clipboard_command()
    if not cmd:
        return False
    proc = subprocess.run(cmd, input=text.encode("utf-8"))
    return proc.returncode == 0


def print_clipboard_help() -> None:
    if sys.platform.startswith("linux"):
        print("No clipboard utility found. Install xclip or xsel.", file=sys.stderr)
    else:
        print("No clipboard utility found on this platform.", file=sys.stderr)


def list_blocks(blocks: list[Block]) -> None:
    for i, block in enumerate(blocks, 1):
        print(f"{i}. {block.label()}")
        for note in block.annotations:
            print(f"     {note}")


def select_interactively(blocks: list[Block]) -> Block | None:
    list_blocks(blocks)
    try:
        raw = input(f"\nWhich shot? (1-{len(blocks)}): ").strip()
        idx = int(raw) - 1
    except (ValueError, EOFError):
        print("Invalid selection.", file=sys.stderr)
        return None
    if not (0 <= idx < len(blocks)):
        print("Selection out of range.", file=sys.stderr)
        return None
    return blocks[idx]


STANDARD_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Aspect: 9:16

# shot_01, hook, 0.0-2.0s, MCU eye-level static
first prompt body

# shot_02, pain, 2.0-6.0s, MS eye-level push
second prompt body
"""

REVISION_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Round: 2
# Revision of round 1. Shots not listed here already passed.

# shot_02, pain, 2.0-6.0s, MCU eye-level push, revision (was REVISE)
# fix [Shot Spec, major]: framing MS -> MCU
# fix [Technical, re-roll]: hand was malformed
revised prompt body
"""

LEGACY_REVISION_FIXTURE = """\
# Revision of shot_03 (was REVISE)
# fix [Series Lock, major]: added 'salt-and-pepper hair' to the character anchor
legacy revised prompt body
"""


def selftest() -> int:
    ok = True

    cases = [
        ("standard file yields both shots", STANDARD_FIXTURE, ["shot_01", "shot_02"]),
        ("revision file yields its shot", REVISION_FIXTURE, ["shot_02"]),
        ("legacy revision header is tolerated", LEGACY_REVISION_FIXTURE, ["shot_03"]),
    ]
    for label, fixture, expected in cases:
        got = [b.shot_id for b in parse_prompt_text(fixture)]
        if got == expected:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> expected {expected}, got {got}")
            ok = False

    blocks = parse_prompt_text(REVISION_FIXTURE)
    body = blocks[0].prompt()
    if body == "revised prompt body":
        print("  ok    selftest: fix annotations stay out of the copied prompt")
    else:
        print(f"  FAIL  selftest: prompt body was {body!r}")
        ok = False
    if len(blocks[0].annotations) == 2:
        print("  ok    selftest: fix annotations are captured for display")
    else:
        print(f"  FAIL  selftest: expected 2 annotations, got {blocks[0].annotations}")
        ok = False

    header_only = parse_prompt_text("# Storyboard: x\n# Generator: flux\n")
    if header_only == []:
        print("  ok    selftest: a file with no shot blocks yields nothing")
    else:
        print(f"  FAIL  selftest: expected no blocks, got {header_only}")
        ok = False

    # The shipped worked run must be readable by this tool, both rounds.
    repo_root = Path(__file__).resolve().parent.parent
    worked = repo_root / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    for rel, expected in (
        ("prompts/round-1/flux.txt", ["shot_01", "shot_02"]),
        ("prompts/round-2/revised-flux.txt", ["shot_02"]),
    ):
        path = worked / rel
        if not path.exists():
            print(f"  FAIL  selftest: bundled fixture missing: {rel}")
            ok = False
            continue
        got = [b.shot_id for b in parse_prompt_file(path)]
        if got == expected:
            print(f"  ok    selftest: bundled {rel} parses")
        else:
            print(f"  FAIL  selftest: bundled {rel} -> expected {expected}, got {got}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Copy a shot prompt from a shotkit prompts file to the clipboard."
    )
    parser.add_argument(
        "file",
        nargs="?",
        type=Path,
        help="Path to a prompt file (e.g. output/prompts/round-1/flux.txt)",
    )
    parser.add_argument(
        "--shot", help="Shot ID to copy (e.g. shot_03). If omitted, prompts interactively."
    )
    parser.add_argument(
        "--list", action="store_true", help="List shots and exit. Does not copy."
    )
    parser.add_argument(
        "--selftest", action="store_true", help="Prove both file shapes parse"
    )
    args = parser.parse_args()

    if args.selftest:
        return selftest()
    if args.file is None:
        parser.error("file is required unless --selftest is given")

    if not args.file.exists():
        print(f"File not found: {args.file}", file=sys.stderr)
        return 1

    blocks = parse_prompt_file(args.file)
    if not blocks:
        print(f"No shot blocks found in {args.file}.", file=sys.stderr)
        print(
            "Expected a comment line naming a shot, e.g. "
            "'# shot_03, beat, timing, framing'.",
            file=sys.stderr,
        )
        return 1

    if args.list:
        list_blocks(blocks)
        return 0

    if args.shot:
        matches = [b for b in blocks if b.shot_id == args.shot]
        if not matches:
            print(f'Shot "{args.shot}" not found in {args.file}.', file=sys.stderr)
            print("Available shots:", file=sys.stderr)
            for block in blocks:
                print(f"  {block.shot_id}", file=sys.stderr)
            return 1
        if len(matches) > 1:
            print(
                f'Shot "{args.shot}" appears {len(matches)} times in {args.file}; '
                f"copying the last block.",
                file=sys.stderr,
            )
        selection = matches[-1]
    else:
        result = select_interactively(blocks)
        if result is None:
            return 1
        selection = result

    body = selection.prompt()
    if copy_to_clipboard(body):
        print(f"Copied {selection.shot_id} prompt to clipboard ({len(body)} chars).")
        for note in selection.annotations:
            print(f"  {note}")
        return 0

    print_clipboard_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/copy-prompt.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/shots-to-html.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/shots-to-html.py`

#!/usr/bin/env python3
"""
Standalone helper: render an output folder into a single preview.html.

Renders skills/storyboard-html-preview/templates/preview.html.tpl, the same
structural template the storyboard-html-preview skill uses, so the two cannot drift.
All interpolated content is HTML-escaped: subjects, rationales, and VO lines are
model-generated prose, and one angle bracket in a rationale used to break the page a
client was looking at.

Two timestamps, deliberately distinct. "Run" is when the storyboard was produced, read
from run.json. "Rendered" is when this page was written. Collapsing them into one
"Generated" date meant re-rendering a preview six months later silently restamped the
run as today.

Usage:
    python tools/shots-to-html.py path/to/output-folder
    python tools/shots-to-html.py path/to/output-folder --out preview.html
    python tools/shots-to-html.py path/to/output-folder --inline-images
    python tools/shots-to-html.py path/to/output-folder --rendered-at 2026-07-30T00:00:00Z
    python tools/shots-to-html.py --selftest
"""

from __future__ import annotations

import argparse
import base64
import sys
from pathlib import Path

from _shotkit import (
    IMAGE_EXTS,
    PALETTE_ROLES,
    REPO_ROOT,
    as_overlay_ids,
    find_frame,
    iso_instant,
    load_json,
    parse_palette,
    parse_typography,
    round_dirs,
    sha256_file,
)
from _template import escape, render

TEMPLATE_DIR = REPO_ROOT / "skills" / "storyboard-html-preview" / "templates"

FALLBACK_BRAND = {
    "bg": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
    "display_font": "Inter",
    "body_font": "Inter",
}

FALLBACK_HEX = {
    "background": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
}


def read_template(name: str) -> str:
    return (TEMPLATE_DIR / name).read_text(encoding="utf-8")


def parse_brand_lock(path: Path) -> tuple[dict, list[str]]:
    """
    Pull palette and typography out of a brand-lock.

    Returns (values, warnings). Warnings name every role that fell back to a generic
    default, because a preview that quietly renders in someone else's blue is worse
    than one that tells you the palette did not parse.
    """
    if not path.exists():
        return (dict(FALLBACK_BRAND), [f"brand-lock not found at {path.name}"])

    text = path.read_text(encoding="utf-8")
    palette = parse_palette(text)
    warnings: list[str] = []

    def pick(role: str) -> str:
        # Exact role first, then any role containing it, e.g. "accent (warm)".
        if role in palette and not palette[role].startswith("#_"):
            return palette[role]
        for name, hex_val in palette.items():
            if role in name and not hex_val.startswith("#_"):
                return hex_val
        warnings.append(
            f"palette role '{role}' not found in the brand-lock, using a generic default"
        )
        return FALLBACK_HEX[role]

    values = {
        "bg": pick("background"),
        "ink": pick("ink"),
        "accent": pick("accent"),
        "muted": pick("muted"),
        "rule": pick("rule"),
    }

    fonts = parse_typography(text)
    values["display_font"] = fonts.get("display_font") or FALLBACK_BRAND["display_font"]
    values["body_font"] = fonts.get("body_font") or FALLBACK_BRAND["body_font"]
    for key in ("display_font", "body_font"):
        if not fonts.get(key):
            warnings.append(
                f"brand-lock declares no {key.replace('_', ' ')}, using "
                f"{FALLBACK_BRAND[key]}"
            )

    return (values, warnings)


def aspect_class(aspect: str) -> str:
    return "aspect-" + str(aspect).replace(":", "-")


def encode_image_b64(path: Path) -> str:
    ext = path.suffix.lstrip(".").lower()
    mime = {
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
    }.get(ext, "image/png")
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def frame_for_shot(out_dir: Path, shot: dict) -> tuple[Path | None, str | None]:
    """
    Resolve a shot's frame, preferring what the data says over what the tree implies.

    Order: an accepted entry in shot.assets.generated, then the newest entry there,
    then the frames/round-N path convention, then the legacy generated/ directory.
    Returns (path, note) where note explains a non-obvious pick.
    """
    generated = (shot.get("assets") or {}).get("generated") or []
    accepted = [g for g in generated if g.get("accepted") is True and g.get("path")]
    pool = accepted or [g for g in generated if g.get("path")]
    if pool:
        chosen = max(pool, key=lambda g: g.get("round") or 0)
        path = out_dir / chosen["path"]
        if path.exists():
            note = None
            if chosen.get("sha256"):
                actual = sha256_file(path)
                if actual != chosen["sha256"]:
                    note = "frame has changed since it was recorded in shots.json"
            elif not accepted:
                note = "frame is not marked accepted"
            return (path, note)
        return (None, f"assets names {chosen['path']}, which is missing on disk")

    found = find_frame(out_dir, shot["id"])
    if found is None:
        return (None, None)
    return (found, None)


def latest_verdicts(out_dir: Path) -> dict[str, dict]:
    """Newest verdict per shot, read from the critique tree. Empty when there is none."""
    verdicts: dict[str, dict] = {}
    for round_no, directory in round_dirs(out_dir, "critiques"):
        for path in sorted(directory.glob("*.json")):
            data, err = load_json(path)
            if err or not isinstance(data, dict):
                continue
            shot_id = data.get("shot_id")
            if not shot_id:
                continue
            current = verdicts.get(shot_id)
            if current is None or round_no >= current["round"]:
                verdicts[shot_id] = {
                    "round": round_no,
                    "verdict": data.get("verdict"),
                }
    legacy, err = load_json(out_dir / "critique.json")
    if not err and isinstance(legacy, dict) and legacy.get("shot_id"):
        verdicts.setdefault(
            legacy["shot_id"],
            {"round": legacy.get("round") or 1, "verdict": legacy.get("verdict")},
        )
    return verdicts


def position_class(position) -> str:
    """Named positions map to a CSS class; explicit coordinates fall back to center."""
    if isinstance(position, str):
        return position
    return "center"


def position_label(position) -> str:
    if isinstance(position, dict):
        return f"x{position.get('x')}% y{position.get('y')}%"
    return str(position)


def build_context(out_dir: Path, args) -> tuple[dict, list[str]]:
    warnings: list[str] = []

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        raise SystemExit(f"ERROR: {err}")

    overlays_data, ov_err = load_json(out_dir / "text-overlays.json")
    if ov_err:
        overlays_data = {"overlays": []}
    overlays_by_id = {
        o["id"]: o for o in (overlays_data or {}).get("overlays", []) if o.get("id")
    }

    project = shots_data["project"]
    series = shots_data["series_lock"]
    shots = shots_data["shots"]
    aspect = project["aspect"]

    brand_ref = shots_data.get("brand_lock_ref") or "brand-lock.snapshot.md"
    brand_path = out_dir / brand_ref
    brand, brand_warnings = parse_brand_lock(brand_path)
    warnings.extend(brand_warnings)

    run_doc, run_err = load_json(out_dir / "run.json")
    if run_err or not isinstance(run_doc, dict):
        run_doc = {}
        warnings.append(
            "no run.json in this output tree, so the page cannot state when the run "
            "happened or which inputs it used"
        )

    verdicts = latest_verdicts(out_dir)
    provenance_notes: list[str] = []

    shot_contexts = []
    for shot in shots:
        frame_path, frame_note = frame_for_shot(out_dir, shot)
        if frame_note:
            provenance_notes.append(f"{shot['id']}: {frame_note}")
            warnings.append(f"{shot['id']}: {frame_note}")

        image_path = None
        if frame_path is not None:
            if args.inline_images:
                image_path = encode_image_b64(frame_path)
            else:
                try:
                    image_path = str(frame_path.relative_to(out_dir))
                except ValueError:
                    image_path = frame_path.name

        overlays = []
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            overlay = overlays_by_id.get(oid)
            if overlay is None:
                warnings.append(
                    f"{shot['id']} references overlay {oid}, which is not in "
                    f"text-overlays.json"
                )
                continue
            overlays.append(
                {
                    "id": overlay["id"],
                    "content": overlay.get("content"),
                    "font": overlay.get("font"),
                    "weight": overlay.get("weight"),
                    "color": overlay.get("color"),
                    "size": overlay.get("size"),
                    "position_class": position_class(overlay.get("position")),
                    "position_label": position_label(overlay.get("position")),
                    "enter_at": (overlay.get("enter") or {}).get("at"),
                    "enter_animation": (overlay.get("enter") or {}).get("animation"),
                    "exit_at": (overlay.get("exit") or {}).get("at"),
                    "exit_animation": (overlay.get("exit") or {}).get("animation"),
                }
            )

        verdict = verdicts.get(shot["id"])
        shot_contexts.append(
            {
                "id": shot["id"],
                "id_short": shot["id"].replace("shot_", ""),
                "beat": shot.get("beat"),
                "start": shot.get("start"),
                "end": shot.get("end"),
                "framing": shot.get("framing"),
                "angle": shot.get("angle"),
                "motion": shot.get("motion"),
                "depth_of_field": shot.get("depth_of_field"),
                "subject": shot.get("subject"),
                "vo": shot.get("vo"),
                "rationale": shot.get("rationale"),
                "aspect_class": aspect_class(aspect),
                "has_image": image_path is not None,
                "has_no_image": image_path is None,
                "image_path": image_path,
                "overlays": overlays,
                "has_overlays": bool(overlays),
                "has_verdict": verdict is not None,
                "verdict": (verdict or {}).get("verdict"),
                "verdict_round": (verdict or {}).get("round"),
                "verdict_class": str((verdict or {}).get("verdict", "")).lower(),
            }
        )

    css = (
        read_template("styles.css.tpl")
        .replace("{{BG_COLOR}}", brand["bg"])
        .replace("{{INK_COLOR}}", brand["ink"])
        .replace("{{ACCENT_COLOR}}", brand["accent"])
        .replace("{{MUTED_COLOR}}", brand["muted"])
        .replace("{{RULE_COLOR}}", brand["rule"])
        .replace("{{DISPLAY_FONT}}", brand["display_font"])
        .replace("{{BODY_FONT}}", brand["body_font"])
        .replace("{{INLINE_PRINT_CSS}}", read_template("print.css.tpl"))
    )

    brand_sha = sha256_file(brand_path) if brand_path.exists() else None
    recorded_sha = (run_doc.get("inputs") or {}).get("brand_lock_sha256")
    if brand_sha and recorded_sha and brand_sha != recorded_sha:
        provenance_notes.append(
            "the brand-lock on disk no longer matches the one recorded in run.json"
        )
        warnings.append(
            "brand-lock has changed since the run; this preview does not show the "
            "brand state the frames were produced against"
        )

    context = {
        "PROJECT_TITLE": project["title"],
        "DURATION": project["duration_s"],
        "ASPECT": aspect,
        "FRAMEWORK": project.get("framework") or "not specified",
        "SHOTS_VERSION": shots_data.get("version", "unknown"),
        "BRIEF": None,
        "SERIES_CHARACTER": series["character"],
        "SERIES_ENVIRONMENT": series["environment"],
        "SERIES_LIGHTING": series["lighting"],
        "SERIES_COLOR_GRADE": series["color_grade"],
        "BRAND_LOCK_REF": brand_ref,
        "BRAND_LOCK_SHA_SHORT": brand_sha[:12] if brand_sha else None,
        "RUN_ID": run_doc.get("run_id") or "not recorded",
        "RUN_CREATED_AT": run_doc.get("created_at") or "not recorded",
        "RENDERED_AT": args.rendered_at or iso_instant(),
        "PROVENANCE_NOTE": " ".join(provenance_notes) or None,
        "INLINE_CSS": css,
        "shots": shot_contexts,
    }
    return (context, warnings)


def selftest() -> int:
    """Render the bundled worked run twice and prove the output is byte-identical."""
    worked = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    ok = True

    class Args:
        inline_images = False
        rendered_at = "2026-07-30T00:00:00Z"

    first, _ = build_context(worked, Args())
    second, _ = build_context(worked, Args())
    html_a = render(read_template("preview.html.tpl"), first)
    html_b = render(read_template("preview.html.tpl"), second)

    if html_a == html_b:
        print("  ok    selftest: two renders with a pinned timestamp are identical")
    else:
        print("  FAIL  selftest: two renders differed")
        ok = False

    # shot_06 of the shotkit-explainer example carries two overlays. A renderer that
    # resolves only the first drops the second silently, which is what used to happen.
    explainer = (
        REPO_ROOT
        / "skills"
        / "storyboard-architect"
        / "examples"
        / "shotkit-explainer"
    )
    multi_ctx, _ = build_context(explainer, Args())
    shot_06 = next(s for s in multi_ctx["shots"] if s["id"] == "shot_06")
    multi_html = render(read_template("preview.html.tpl"), multi_ctx)

    checks = [
        ("escapes angle brackets", "<script>alert(1)</script>" not in render(
            "{{subject}}", {"subject": "<script>alert(1)</script>"}
        )),
        ("escapes quotes inside a style attribute", "&quot;" in render(
            '<span style="font-family: {{font}};">x</span>', {"font": '"><script>'}
        )),
        ("resolves every overlay on a multi-overlay shot", len(shot_06["overlays"]) == 2),
        (
            "renders every overlay on a multi-overlay shot",
            all(
                escape(overlay["content"]) in multi_html
                for overlay in shot_06["overlays"]
            ),
        ),
        ("states the run date, not the render date, in the header", "2026-07-30T14:23:00Z" in html_a),
        ("labels the render separately", "rendered 2026-07-30T00:00:00Z" in html_a),
        ("shows a verdict badge", "sb-verdict-accept" in html_a),
        ("uses the brand-lock ref from shots.json", 'href="brand-lock.snapshot.md"' in html_a),
        ("carries no unrendered template tags", "{{" not in html_a),
    ]
    for label, passed in checks:
        if passed:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    p = argparse.ArgumentParser(
        description="Render a shotkit output folder into a single preview.html."
    )
    p.add_argument(
        "output_dir",
        nargs="?",
        type=Path,
        help="Directory containing shots.json, text-overlays.json, run.json",
    )
    p.add_argument("--out", default="preview.html", help="Output filename, relative to output_dir")
    p.add_argument(
        "--inline-images",
        action="store_true",
        help="Embed frames as base64 so the file is portable on its own",
    )
    p.add_argument(
        "--rendered-at",
        help="Pin the render timestamp (UTC ISO-8601). Makes output reproducible.",
    )
    p.add_argument("--selftest", action="store_true", help="Prove the renderer's guarantees")
    args = p.parse_args()

    if args.selftest:
        return selftest()
    if args.output_dir is None:
        p.error("output_dir is required unless --selftest is given")

    out_dir: Path = args.output_dir
    if not out_dir.is_dir():
        print(f"ERROR: output directory not found: {out_dir}")
        return 1
    if not (out_dir / "shots.json").exists():
        print(f"ERROR: shots.json not found in {out_dir}")
        return 1

    context, warnings = build_context(out_dir, args)
    html_out = render(read_template("preview.html.tpl"), context)

    out_path = out_dir / args.out
    out_path.write_text(html_out, encoding="utf-8")
    print(f"  wrote {out_path}")
    for warn in warnings:
        print(f"  warn  {warn}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/shots-to-html.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/validate_brand_lock.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/validate_brand_lock.py`

#!/usr/bin/env python3
"""
Validate a brand-lock Markdown file.

Two modes, because a brand-pack and a snapshot are not the same artifact.

A brand-pack (brand-packs/*.md) is a source document. An unfilled template is a legal
brand-pack: that is what a template is for.

A snapshot (brand-lock.snapshot.md, written into an output tree) is a provenance
record. It has to carry the header storyboard-architect promises to write, and if it
still contains template placeholders then the run it governs was built against nothing.
Pass --snapshot to check those extra rules, and --require-configured to reject
placeholders outright.

Required headings (case-insensitive, in any order):
- Identity, Palette, Typography, Mood adjectives, Never list,
  Aspect ratios, Color grade direction, Motion language, Voice rules

Required identity fields (under ## Identity):
- Brand, One-line description, Archetype, Voice posture

Usage:
    python tools/validate_brand_lock.py path/to/brand-lock.md [...]
    python tools/validate_brand_lock.py --snapshot path/to/brand-lock.snapshot.md
    python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
    python tools/validate_brand_lock.py --snapshots            # every bundled snapshot
    python tools/validate_brand_lock.py --selftest
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from _shotkit import (
    ISO_INSTANT_RE,
    PALETTE_ROLES,
    REPO_ROOT,
    is_unconfigured,
    parse_palette,
    parse_snapshot_header,
    parse_typography,
)

REQUIRED_SECTIONS = {
    "identity",
    "palette",
    "typography",
    "mood adjectives",
    "never list",
    "aspect ratios",
    "color grade direction",
    "motion language",
    "voice rules",
}

REQUIRED_IDENTITY_FIELDS = {
    "brand",
    "one-line description",
    "archetype",
    "voice posture",
}

ISO_DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")


def parse_headings(text: str) -> list[tuple[int, str]]:
    """Return list of (level, heading_text_lower) for every Markdown heading."""
    out = []
    for line in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            out.append((len(m.group(1)), m.group(2).strip().lower()))
    return out


def extract_section(text: str, heading_lower: str) -> str:
    """Extract the body of a section by its heading. Empty string if not found."""
    lines = text.splitlines()
    in_section = False
    section_lines: list[str] = []
    section_level: int | None = None
    for line in lines:
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            level = len(m.group(1))
            heading = m.group(2).strip().lower()
            if not in_section:
                if heading == heading_lower:
                    in_section = True
                    section_level = level
                    continue
            else:
                if section_level is not None and level <= section_level:
                    break
        if in_section:
            section_lines.append(line)
    return "\n".join(section_lines)


def check_structure(text: str) -> list[str]:
    errors: list[str] = []
    heading_set = {h for _, h in parse_headings(text)}

    for missing in sorted(REQUIRED_SECTIONS - heading_set):
        errors.append(f"missing section: ## {missing.title()}")

    if "identity" in heading_set:
        identity_body = extract_section(text, "identity").lower()
        for field in sorted(REQUIRED_IDENTITY_FIELDS):
            if field not in identity_body:
                errors.append(f"identity section missing field: '{field}'")

    if "palette" in heading_set:
        palette_body = extract_section(text, "palette")
        if not re.search(r"#[0-9A-Fa-f]{6}|#_{6}", palette_body):
            errors.append(
                "palette section has no hex color values (or template placeholders)"
            )

    return errors


def check_roles(text: str) -> list[str]:
    """
    The palette role names the HTML preview maps onto CSS variables.

    A brand-lock is free to add rows, but a missing role means the preview silently
    renders that slot in a generic default, so it is worth saying out loud.
    """
    warnings: list[str] = []
    palette = parse_palette(text)
    for role in PALETTE_ROLES:
        if not any(role in name for name in palette):
            warnings.append(
                f"palette has no '{role}' role; the HTML preview will fall back to a "
                f"generic color for it"
            )
    return warnings


def check_typography(text: str) -> list[str]:
    warnings: list[str] = []
    fonts = parse_typography(text)
    for key, label in (("display_font", "Display"), ("body_font", "Body")):
        if not fonts.get(key):
            warnings.append(
                f"typography declares no {key.replace('_', ' ')} in a readable form; "
                f'expected ``**{label} font:** `Font Name Weight` `` with the name '
                f"backticked immediately after the label"
            )
    return warnings


def check_snapshot(text: str) -> tuple[list[str], list[str]]:
    """The provenance header storyboard-architect writes into every snapshot."""
    errors: list[str] = []
    warnings: list[str] = []
    header = parse_snapshot_header(text)

    taken = header["snapshot_taken"]
    if not taken:
        errors.append(
            "snapshot is missing its '<!-- snapshot taken: ... -->' header, so nothing "
            "records when this brand state was frozen"
        )
    elif ISO_INSTANT_RE.match(taken):
        pass
    elif ISO_DATE_RE.match(taken):
        warnings.append(
            f"snapshot taken '{taken}' is a date with no time; a full UTC instant "
            f"(YYYY-MM-DDThh:mm:ssZ) is what makes two runs on one day distinguishable"
        )
    else:
        errors.append(
            f"snapshot taken '{taken}' is not ISO-8601; expected YYYY-MM-DDThh:mm:ssZ"
        )

    if not header["source"]:
        errors.append(
            "snapshot is missing its '<!-- source: ... -->' header, so nothing records "
            "which brand-pack it was copied from"
        )

    return errors, warnings


def validate_brand_lock(
    path: Path, snapshot: bool = False, require_configured: bool = False
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    if not path.exists():
        return ([f"file does not exist: {path}"], [])

    text = path.read_text(encoding="utf-8")
    errors = check_structure(text)
    warnings = check_roles(text) + check_typography(text)

    unconfigured = is_unconfigured(text)
    if unconfigured:
        if require_configured or snapshot:
            errors.append(
                "palette still contains template placeholders (#______), so this is an "
                "unfilled template rather than a real brand-lock"
            )
        else:
            warnings.append(
                "palette contains template placeholders (#______); fine for a template, "
                "not for production work"
            )

    if snapshot:
        snap_errors, snap_warnings = check_snapshot(text)
        errors += snap_errors
        warnings += snap_warnings

    return (errors, warnings)


def selftest() -> int:
    ok = True
    minimal = "\n".join(
        [
            "## Identity",
            "**Brand:** X",
            "**One-line description:** Y",
            "**Archetype:** Operator",
            "**Voice posture:** Calm",
            "## Palette",
            "| Role | Hex | Use |",
            "|---|---|---|",
            "| Background | `#FFFFFF` | canvas |",
            "| Ink | `#000000` | text |",
            "| Accent | `#FF0000` | pop |",
            "| Muted | `#888888` | captions |",
            "| Rule | `#EEEEEE` | borders |",
            "## Typography",
            "**Display font:** `Inter Black 900`, headlines",
            "**Body font:** `Inter Medium 500`, body",
            "## Mood adjectives",
            "## Never list",
            "## Aspect ratios",
            "## Color grade direction",
            "## Motion language",
            "## Voice rules",
        ]
    )

    cases = [
        ("a complete brand-lock passes", minimal, {}, False),
        (
            "a snapshot with no header is rejected",
            minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot with a full instant header passes",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            False,
        ),
        (
            "a snapshot with a malformed date is rejected",
            "<!-- snapshot taken: last Tuesday -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot missing its source header is rejected",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "placeholders pass as a template",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {},
            False,
        ),
        (
            "placeholders fail under --require-configured",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {"require_configured": True},
            True,
        ),
        (
            "a missing section is caught",
            minimal.replace("## Voice rules", ""),
            {},
            True,
        ),
    ]

    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        for i, (label, text, kwargs, should_fail) in enumerate(cases):
            path = Path(tmp) / f"case-{i}.md"
            path.write_text(text, encoding="utf-8")
            errors, _ = validate_brand_lock(path, **kwargs)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        warn_path = Path(tmp) / "warn.md"
        warn_path.write_text(
            minimal.replace("| Muted | `#888888` | captions |", ""), encoding="utf-8"
        )
        _, warnings = validate_brand_lock(warn_path)
        if any("no 'muted' role" in w for w in warnings):
            print("  ok    selftest: a missing palette role warns")
        else:
            print(f"  FAIL  selftest: expected a muted-role warning, got {warnings}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_brand_lock.py <path-to-brand-lock.md> [...]")
        print("       python tools/validate_brand_lock.py --snapshot <snapshot.md>")
        print("       python tools/validate_brand_lock.py --require-configured <file>")
        print("       python tools/validate_brand_lock.py --snapshots")
        print("       python tools/validate_brand_lock.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    snapshot = "--snapshot" in args or "--snapshots" in args
    require_configured = "--require-configured" in args

    if "--snapshots" in args:
        paths = sorted(REPO_ROOT.rglob("brand-lock.snapshot.md"))
        if not paths:
            print("ERROR: no brand-lock.snapshot.md files found in the repo")
            return 1
    else:
        paths = [Path(a) for a in args if not a.startswith("--")]
        if not paths:
            print("ERROR: no brand-lock files given")
            return 2

    label = "snapshot" if snapshot else "brand-lock"
    print(f"Validating {len(paths)} {label} file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_brand_lock(path, snapshot, require_configured)
        try:
            shown = path.relative_to(REPO_ROOT)
        except ValueError:
            shown = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {shown}: {warn}")

    print()
    if total_errors == 0:
        print(f"All {label} files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across {label} files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/validate_brand_lock.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/validate_capabilities.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/validate_capabilities.py`

#!/usr/bin/env python3
"""
Validate the generator capability matrix and the adapter prose that defers to it.

_capabilities.json is declared the single source of truth for per-generator limits,
and every adapter .md repeats that rule at the top. A rule nothing checks is a
suggestion: the matrix and the prose drifted in three places before this file grew
the parity checks below.

Five checks:
  1. _capabilities.json validates against capabilities.schema.json.
  2. File parity: every generator id has an adapter .md and every adapter .md has a
     generator entry. Non-adapter markdown is skipped by name, not treated as an
     adapter with a missing entry.
  3. Prose parity: the word budget an adapter .md advertises must fit inside that
     generator's max_prompt_words, and the .md must mention the aspect_param the
     matrix says to send. A generator whose documented parameter name disagrees with
     the matrix will be called with the wrong one, because the matrix wins.
  4. Self-consistency: a notes field must not cite a word count above its own
     max_prompt_words.
  5. Staleness: warns when the matrix or an entry is past the freshness window.

Run from repo root:
    python tools/validate_capabilities.py
    python tools/validate_capabilities.py --selftest
"""

from __future__ import annotations

import re
import sys
from datetime import date

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, load_json

ADAPTERS_DIR = REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters"
CAPS = ADAPTERS_DIR / "_capabilities.json"
CAPS_SCHEMA = ADAPTERS_DIR / "capabilities.schema.json"

# Re-verify the matrix at least this often. Generator models change monthly.
STALE_AFTER_DAYS = 120

# Markdown in adapters/ that documents the directory rather than a generator.
NON_ADAPTER_STEMS = {"README", "_README"}

# "**80-150 words**", "**40-80 words per prompt**", en dash or hyphen.
WORD_RANGE_RE = re.compile(r"\*\*\s*(\d+)\s*[-–—]\s*(\d+)\s+words[^*]*\*\*")
# "**up to 150 words**" or "**150 words**"
WORD_SINGLE_RE = re.compile(r"\*\*\s*(?:up to\s+)?(\d+)\s+words[^*]*\*\*")
# A bare word count inside a notes string, e.g. "Over 100 words underperforms."
NOTES_WORD_RE = re.compile(r"(\d+)\s+words")


def _parse_date(value: str) -> date | None:
    try:
        y, m, d = (int(p) for p in value.split("-"))
        return date(y, m, d)
    except (ValueError, AttributeError):
        return None


def adapter_word_bound(text: str) -> int | None:
    """Highest word count the adapter prose advertises, or None if it names none."""
    bounds: list[int] = []
    for m in WORD_RANGE_RE.finditer(text):
        bounds.append(max(int(m.group(1)), int(m.group(2))))
    if not bounds:
        for m in WORD_SINGLE_RE.finditer(text):
            bounds.append(int(m.group(1)))
    return max(bounds) if bounds else None


def check_prose_parity(entry: dict, text: str) -> tuple[list[str], list[str]]:
    """Compare one adapter .md against its capability entry."""
    errors: list[str] = []
    warnings: list[str] = []
    gid = entry["id"]

    bound = adapter_word_bound(text)
    if bound is None:
        warnings.append(
            f"prose: '{gid}.md' advertises no word budget, so the matrix value "
            f"({entry['max_prompt_words']}) is the only guidance a reader gets"
        )
    elif bound > entry["max_prompt_words"]:
        errors.append(
            f"prose: '{gid}.md' advertises up to {bound} words but the matrix caps "
            f"max_prompt_words at {entry['max_prompt_words']}"
        )

    aspect = entry["aspect_param"]
    if aspect not in text:
        errors.append(
            f"prose: '{gid}.md' never mentions aspect_param '{aspect}'. The matrix "
            f"wins, so the forge will send a parameter the adapter does not document"
        )

    notes = entry.get("notes") or ""
    for m in NOTES_WORD_RE.finditer(notes):
        cited = int(m.group(1))
        if cited > entry["max_prompt_words"]:
            warnings.append(
                f"self-consistency: '{gid}' notes cite {cited} words but "
                f"max_prompt_words is {entry['max_prompt_words']}"
            )

    return errors, warnings


def validate(today: date | None = None) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    errors: list[str] = []
    warnings: list[str] = []
    today = today or date.today()

    if not CAPS.exists():
        return ([f"missing {CAPS.relative_to(REPO_ROOT)}"], warnings)
    if not CAPS_SCHEMA.exists():
        return ([f"missing {CAPS_SCHEMA.relative_to(REPO_ROOT)}"], warnings)

    caps, caps_err = load_json(CAPS)
    if caps_err:
        return ([f"_capabilities.json: {caps_err}"], warnings)
    schema, schema_err = load_json(CAPS_SCHEMA)
    if schema_err:
        return ([f"capabilities.schema.json: {schema_err}"], warnings)

    # 1. Schema validation
    validator = Draft202012Validator(schema)
    for err in sorted(validator.iter_errors(caps), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # structure-dependent checks need a valid shape

    entries = {g["id"]: g for g in caps["generators"]}
    cap_ids = set(entries)
    md_ids = {
        p.stem
        for p in ADAPTERS_DIR.glob("*.md")
        if p.stem not in NON_ADAPTER_STEMS
    }

    # 2. File parity
    for missing_md in sorted(cap_ids - md_ids):
        errors.append(
            f"parity: capability id '{missing_md}' has no adapter file {missing_md}.md"
        )
    for missing_cap in sorted(md_ids - cap_ids):
        errors.append(
            f"parity: adapter '{missing_cap}.md' has no entry in _capabilities.json"
        )

    # 3 and 4. Prose parity and self-consistency
    for gid in sorted(cap_ids & md_ids):
        text = (ADAPTERS_DIR / f"{gid}.md").read_text(encoding="utf-8")
        prose_errors, prose_warnings = check_prose_parity(entries[gid], text)
        errors.extend(prose_errors)
        warnings.extend(prose_warnings)

    # 5. Staleness
    reviewed = _parse_date(caps.get("matrix_last_reviewed", ""))
    if reviewed is None:
        warnings.append("matrix_last_reviewed is not a parseable date")
    elif (today - reviewed).days > STALE_AFTER_DAYS:
        warnings.append(
            f"matrix_last_reviewed is {(today - reviewed).days} days old "
            f"(> {STALE_AFTER_DAYS}); re-verify the matrix"
        )
    for g in caps["generators"]:
        lv = _parse_date(g.get("last_verified", ""))
        if lv is not None and (today - lv).days > STALE_AFTER_DAYS:
            warnings.append(
                f"'{g['id']}' last_verified is {(today - lv).days} days old "
                f"(> {STALE_AFTER_DAYS}); re-verify this generator"
            )

    return (errors, warnings)


def selftest() -> int:
    ok = True

    cases = [
        (
            "prose advertising more words than the cap is caught",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-300 words** comfortably. Pass `size` alongside.",
            True,
        ),
        (
            "prose inside the cap passes",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-250 words** comfortably. Pass `size` alongside.",
            False,
        ),
        (
            "an undocumented aspect_param is caught",
            {
                "id": "x",
                "max_prompt_words": 120,
                "aspect_param": "aspect_ratio",
                "notes": "",
            },
            "Handles **60-120 words**. Pass `aspectRatio` as a parameter.",
            True,
        ),
        (
            "en dash ranges parse",
            {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": ""},
            "Aim for **40–80 words per prompt** including `--ar`.",
            False,
        ),
    ]
    for label, entry, text, should_error in cases:
        errors, _ = check_prose_parity(entry, text)
        if bool(errors) == should_error:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
            ok = False

    entry = {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": "Over 100 words underperforms."}
    _, warnings = check_prose_parity(entry, "Aim for **40-80 words** with `--ar`.")
    if any("self-consistency" in w for w in warnings):
        print("  ok    selftest: notes citing more words than the cap are flagged")
    else:
        print(f"  FAIL  selftest: expected a self-consistency warning, got {warnings}")
        ok = False

    if adapter_word_bound("no budget stated here") is None:
        print("  ok    selftest: prose with no word budget reports none")
    else:
        print("  FAIL  selftest: found a word budget where there is none")
        ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    if "--selftest" in sys.argv[1:]:
        return selftest()

    print(f"Validating capability matrix: {CAPS.relative_to(REPO_ROOT)}")
    print()

    errors, warnings = validate()

    for w in warnings:
        print(f"  warn  {w}")
    if warnings:
        print()

    if not errors:
        caps, _ = load_json(CAPS)
        count = len((caps or {}).get("generators", []))
        print(f"Capability matrix valid ({count} generators, {len(warnings)} warning(s)).")
        return 0

    for e in errors:
        print(f"  FAIL  {e}")
    print()
    print(f"FAILED: {len(errors)} error(s) in capability matrix.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/validate_capabilities.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/validate_critique.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/validate_critique.py`

#!/usr/bin/env python3
"""
Validate critique.json files against the critique schema AND the gating invariant.

Schema validation alone is not enough: JSON Schema cannot express the cross-field
rules that make a verdict trustworthy. This validator adds them.

Gating invariant (the reason structured output exists):
  - Any 'blocking' issue      => verdict MUST be REJECT.
  - Three or more 'major'     => verdict MUST be REJECT.
  - One or two 'major'        => verdict MUST NOT be ACCEPT (caps at REVISE).
  - Therefore ACCEPT requires zero major/blocking issues.

Provenance invariant (version 1.1 and later):
  - A hash without its path, or a path without its hash, is not a reference.
  - image_ref must be present and non-null: a verdict about no image is not a verdict.
  - HIGH confidence requires the shot spec, the brand-lock, and the prompt to all be
    identified. The critic's own rubric says HIGH means all three were available.
  - generator, when named, must be an id in the capability matrix.

A critique that claims ACCEPT while carrying a blocking issue passes the schema but
FAILS here. So does a 1.1 critique that records an image hash and no image path.

Usage:
    python tools/validate_critique.py path/to/critique.json [...]
    python tools/validate_critique.py path/to/output-dir      # every critique in the tree
    python tools/validate_critique.py --examples              # bundled fixtures
    python tools/validate_critique.py --selftest              # prove the gates fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, capability_ids, critique_paths, load_json

SCHEMA_PATH = (
    REPO_ROOT / "skills" / "visual-asset-critic" / "templates" / "critique.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "visual-asset-critic" / "examples"

MAJOR_REJECT_THRESHOLD = 3

# Pairs that must be present or absent together.
REF_HASH_PAIRS = (
    ("image_ref", "image_sha256"),
    ("brand_lock_ref", "brand_lock_sha256"),
    ("prompt_ref", "prompt_sha256"),
)


def _load_schema() -> dict:
    data, err = load_json(SCHEMA_PATH)
    if err:
        raise RuntimeError(err)
    return data


def check_gating(data: dict) -> list[str]:
    """The severity-to-verdict invariant. Assumes data is schema-valid."""
    errors: list[str] = []
    verdict = data.get("verdict")
    severities = [issue.get("severity") for issue in data.get("issues", [])]
    majors = severities.count("major")

    if "blocking" in severities and verdict != "REJECT":
        errors.append(
            f"gating: a 'blocking' issue requires verdict REJECT, got '{verdict}'"
        )
    if majors >= MAJOR_REJECT_THRESHOLD and verdict != "REJECT":
        errors.append(
            f"gating: {majors} 'major' issues require verdict REJECT "
            f"(threshold {MAJOR_REJECT_THRESHOLD}), got '{verdict}'"
        )
    if majors and verdict == "ACCEPT":
        errors.append(
            "gating: a 'major' issue caps the verdict at REVISE; ACCEPT is not allowed"
        )
    return errors


def check_provenance(data: dict, known_generators: set[str]) -> list[str]:
    """The provenance invariant. Only applies from version 1.1."""
    errors: list[str] = []
    if data.get("version") == "1.0":
        return errors

    for ref_key, hash_key in REF_HASH_PAIRS:
        ref, digest = data.get(ref_key), data.get(hash_key)
        if ref and not digest:
            errors.append(f"provenance: {ref_key} is set but {hash_key} is null")
        if digest and not ref:
            errors.append(f"provenance: {hash_key} is set but {ref_key} is null")

    if not data.get("image_ref"):
        errors.append(
            "provenance: image_ref is null; a verdict that names no image cannot be audited"
        )

    if data.get("confidence") == "HIGH":
        missing = [
            key
            for key in ("shot_id", "brand_lock_ref", "prompt_ref")
            if not data.get(key)
        ]
        if missing:
            errors.append(
                "provenance: confidence HIGH requires "
                + ", ".join(missing)
                + " to be identified"
            )

    generator = data.get("generator")
    if generator and known_generators and generator not in known_generators:
        errors.append(
            f"provenance: generator '{generator}' is not an id in the capability matrix"
        )

    return errors


def validate_doc(
    data: dict,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes every gate."""
    errors: list[str] = []
    warnings: list[str] = []

    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # the gates assume a schema-valid shape

    errors += check_gating(data)
    errors += check_provenance(data, known_generators or set())

    if data.get("version") == "1.0":
        warnings.append(
            "version 1.0 carries no run id, no round, and no content hashes, so the "
            "verdict cannot be tied to the bytes it reviewed; re-emit as 1.1"
        )

    return (errors, warnings)


def validate_path(
    path: Path,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    data, err = load_json(path)
    if err:
        return ([err], [])
    if not isinstance(data, dict):
        return ([f"top level is not an object: {path}"], [])
    return validate_doc(data, validator, known_generators)


def _selftest_cases() -> list[tuple[str, dict, bool]]:
    """(label, document, should_pass)."""
    base_provenance = {
        "run_id": "20260730T142300Z-9f2c1ab4",
        "round": 1,
        "created_at": "2026-07-30T14:31:00Z",
        "shot_id": "shot_03",
        "brand_lock_ref": "brand-lock.snapshot.md",
        "brand_lock_sha256": "a" * 64,
        "image_ref": "frames/round-1/shot_03.png",
        "image_sha256": "b" * 64,
        "prompt_ref": "prompts/round-1/flux.txt",
        "prompt_sha256": "c" * 64,
        "generator": "flux",
        "model_version": "2 Pro",
        "seed": 12345,
    }
    major_issue = {
        "layer": "Series Lock",
        "severity": "major",
        "note": "hair mismatch",
        "fix_type": "prompt-level",
        "fix": "add 'salt-and-pepper hair' to the anchor",
    }
    blocking_issue = {
        "layer": "Brand Lock",
        "severity": "blocking",
        "note": "off-palette",
        "fix_type": "re-roll",
        "fix": "re-roll with palette anchor",
    }

    def doc(**overrides) -> dict:
        out = {
            "version": "1.1",
            **base_provenance,
            "verdict": "REVISE",
            "confidence": "HIGH",
            "issues": [dict(major_issue)],
        }
        out.update(overrides)
        return out

    return [
        ("clean REVISE with full provenance passes", doc(), True),
        (
            "legacy 1.0 document still validates",
            {
                "version": "1.0",
                "verdict": "REVISE",
                "confidence": "HIGH",
                "issues": [dict(major_issue)],
            },
            True,
        ),
        (
            "ACCEPT with a blocking issue is rejected",
            doc(verdict="ACCEPT", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "REVISE with a blocking issue is rejected",
            doc(verdict="REVISE", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "ACCEPT with a major issue is rejected",
            doc(verdict="ACCEPT"),
            False,
        ),
        (
            "three major issues cannot stay at REVISE",
            doc(verdict="REVISE", issues=[dict(major_issue) for _ in range(3)]),
            False,
        ),
        (
            "three major issues at REJECT pass",
            doc(verdict="REJECT", issues=[dict(major_issue) for _ in range(3)]),
            True,
        ),
        (
            "1.1 with a hash and no path is rejected",
            doc(prompt_ref=None),
            False,
        ),
        (
            "1.1 with a path and no hash is rejected",
            doc(prompt_sha256=None),
            False,
        ),
        (
            "1.1 with no image_ref is rejected",
            doc(image_ref=None, image_sha256=None),
            False,
        ),
        (
            "HIGH confidence with no prompt identified is rejected",
            doc(prompt_ref=None, prompt_sha256=None),
            False,
        ),
        (
            "MEDIUM confidence with no prompt identified passes",
            doc(confidence="MEDIUM", prompt_ref=None, prompt_sha256=None),
            True,
        ),
        (
            "unknown generator id is rejected",
            doc(generator="runway-sora"),
            False,
        ),
        (
            "1.1 missing a required provenance field is rejected",
            {
                "version": "1.1",
                "verdict": "ACCEPT",
                "confidence": "LOW",
                "issues": [],
            },
            False,
        ),
    ]


def selftest() -> int:
    validator = Draft202012Validator(_load_schema())
    known = capability_ids() or {"flux"}
    ok = True

    for label, document, should_pass in _selftest_cases():
        errors, _ = validate_doc(document, validator, known)
        passed = not errors
        if passed == should_pass:
            print(f"  ok    selftest: {label}")
        else:
            detail = errors if errors else ["(no errors raised)"]
            print(f"  FAIL  selftest: {label} -> {detail}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def _collect(args: list[str]) -> list[Path] | None:
    if "--examples" in args:
        found = sorted(EXAMPLES_DIR.glob("*.json"))
        found += critique_paths(EXAMPLES_DIR / "worked-run")
        return found or None

    paths: list[Path] = []
    for raw in args:
        path = Path(raw)
        if path.is_dir():
            found = critique_paths(path)
            if not found:
                print(f"  FAIL  {raw}")
                print("        - no critique files found in this output tree")
                return None
            paths.extend(found)
        else:
            paths.append(path)
    return paths


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_critique.py <critique.json|output-dir> [...]")
        print("       python tools/validate_critique.py --examples")
        print("       python tools/validate_critique.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    if not SCHEMA_PATH.exists():
        print(f"ERROR: schema not found at {SCHEMA_PATH}")
        return 1

    paths = _collect(args)
    if paths is None:
        return 1

    validator = Draft202012Validator(_load_schema())
    known = capability_ids()

    print(f"Validating {len(paths)} critique file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_path(path, validator, known)
        try:
            label = path.relative_to(REPO_ROOT)
        except ValueError:
            label = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {label}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {label}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {label}: {warn}")

    print()
    if total_errors == 0:
        print(f"All critiques valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across critiques.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/validate_critique.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/validate_prompts.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/validate_prompts.py`

#!/usr/bin/env python3
"""
Validate the prompt files visual-prompt-forge writes.

The forge documents four hard rules and a quality-bar checklist, and until this file
existed every one of them was enforced by a model remembering to check its own work.
That is not a small gap. Rule 3, series_lock anchors appear verbatim in every prompt,
is the rule that produces visual consistency across a series, and it is also the
easiest one in the kit to break by paraphrasing while writing fluent prose. A careful
pass over a seven-shot storyboard drifted on it seven times out of seven with every
other validator green.

Checks:
  1. The header block names the storyboard, generator, aspect, brand-lock, run, round.
  2. The generator is an id in the capability matrix.
  3. The header aspect matches project.aspect in shots.json.
  4. No shot's prompt exceeds that generator's max_prompt_words ceiling.
  5. Every shot block names a shot that exists. A full pass covers every shot; a
     revision file covers a subset.
  6. Rule 1: no on-screen text content appears in any prompt. Text is composited.
  7. Rule 3: series_lock environment, lighting, and color_grade appear verbatim.
     The character anchor is a warning, because a shot with no person in it can
     legitimately omit it.
  8. No duplicate shot blocks in one file.

Usage:
    python tools/validate_prompts.py <output-dir>
    python tools/validate_prompts.py <output-dir>/prompts/round-1/flux.txt
    python tools/validate_prompts.py --examples
    python tools/validate_prompts.py --selftest
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from _shotkit import REPO_ROOT, capability_map, load_json

WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"

SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT = re.compile(r"^\s*#")

HEADER_FIELDS = ("Storyboard", "Generator", "Aspect", "Brand-lock", "Run", "Round")

# series_lock keys that describe every frame, so every prompt has to carry them.
UNIVERSAL_ANCHORS = ("environment", "lighting", "color_grade")


def parse_blocks(text: str) -> tuple[dict[str, str], list[tuple[str, str]]]:
    """Return (header fields, [(shot_id, prompt body)])."""
    header: dict[str, str] = {}
    blocks: list[tuple[str, list[str]]] = []
    current: list[str] | None = None

    for line in text.splitlines():
        m = SHOT_HEADER.match(line)
        if m:
            current = []
            blocks.append((m.group(1), current))
            continue
        if current is None:
            hm = re.match(r"^#\s*([A-Za-z-]+)\s*:\s*(.+?)\s*$", line)
            if hm:
                header[hm.group(1).strip()] = hm.group(2).strip()
            continue
        if not COMMENT.match(line):
            current.append(line)

    return (header, [(sid, "\n".join(b).strip()) for sid, b in blocks])


def check_file(
    path: Path, shots_data: dict, caps: dict[str, dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    label = path.name

    text = path.read_text(encoding="utf-8")
    header, blocks = parse_blocks(text)

    if not blocks:
        return ([f"{label}: no shot blocks found; expected '# shot_NN, ...' lines"], warnings)

    for field in HEADER_FIELDS:
        if field not in header:
            warnings.append(f"{label}: header is missing '# {field}:'")

    generator = header.get("Generator", "").split()[0] if header.get("Generator") else None
    entry = caps.get(generator) if generator else None
    if generator and entry is None:
        errors.append(
            f"{label}: header names generator '{generator}', which is not an id in "
            f"_capabilities.json"
        )
    if generator is None:
        # Fall back to the filename: flux.txt or revised-flux.txt
        stem = path.stem.replace("revised-", "")
        entry = caps.get(stem)
        if entry:
            warnings.append(
                f"{label}: no '# Generator:' header, inferred '{stem}' from the filename"
            )

    project = shots_data.get("project", {})
    if "Aspect" in header and header["Aspect"] != project.get("aspect"):
        errors.append(
            f"{label}: header aspect '{header['Aspect']}' does not match "
            f"project.aspect '{project.get('aspect')}'"
        )

    shot_ids = [s["id"] for s in shots_data.get("shots", [])]
    by_id = {s["id"]: s for s in shots_data.get("shots", [])}
    series = shots_data.get("series_lock", {})

    seen: set[str] = set()
    for sid, body in blocks:
        if sid in seen:
            errors.append(f"{label}: {sid} appears in more than one block")
        seen.add(sid)
        if sid not in by_id:
            errors.append(f"{label}: names {sid}, which is not in shots.json")
            continue
        if not body:
            errors.append(f"{label}: {sid} has a header but no prompt body")
            continue

        if entry:
            words = len(body.split())
            ceiling = entry["max_prompt_words"]
            if words > ceiling:
                errors.append(
                    f"{label}: {sid} is {words} words, over the "
                    f"{entry['id']} ceiling of {ceiling}"
                )

        low = body.lower()
        for key in UNIVERSAL_ANCHORS:
            value = series.get(key)
            if value and value.lower() not in low:
                errors.append(
                    f"{label}: {sid} does not carry the series_lock {key} verbatim. "
                    f"Paraphrasing an anchor is what makes shots stop matching each other"
                )
        character = series.get("character")
        if character and character.lower() not in low:
            warnings.append(
                f"{label}: {sid} does not carry the series_lock character verbatim; "
                f"correct only if this shot has no person in it"
            )

    # Rule 1: text is composited, never described.
    overlays_path = path.parent.parent.parent / "text-overlays.json"
    overlays_data, ov_err = load_json(overlays_path)
    if not ov_err and isinstance(overlays_data, dict):
        for overlay in overlays_data.get("overlays", []):
            content = overlay.get("content")
            if not isinstance(content, str) or len(content) < 8:
                continue
            needle = content.lower().rstrip(".!?")
            for sid, body in blocks:
                if needle in body.lower():
                    errors.append(
                        f"{label}: {sid} contains the copy of overlay "
                        f"{overlay.get('id')} verbatim. On-screen text is composited, "
                        f"never put in an image prompt"
                    )

    is_revision = path.name.startswith("revised-")
    if not is_revision:
        for missing in [s for s in shot_ids if s not in seen]:
            errors.append(f"{label}: full pass is missing a block for {missing}")

    return (errors, warnings)


def collect_prompt_files(target: Path) -> tuple[Path | None, list[Path]]:
    """Return (output_dir, prompt files). Accepts an output dir or a single file."""
    if target.is_file():
        # prompts/round-N/<file>.txt  ->  output dir is three levels up
        return (target.parent.parent.parent, [target])
    if target.is_dir():
        found = sorted(target.glob("prompts/round-*/*.txt"))
        if not found:
            found = sorted(target.glob("prompts/*.txt"))  # pre-3.0.0 flat layout
        return (target, found)
    return (None, [])


def validate_target(target: Path) -> tuple[list[str], list[str]]:
    out_dir, files = collect_prompt_files(target)
    if out_dir is None:
        return ([f"not a file or directory: {target}"], [])
    if not files:
        return ([f"no prompt files found under {target}"], [])

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        return ([f"cannot read shots.json next to the prompts: {err}"], [])

    caps = capability_map()
    errors: list[str] = []
    warnings: list[str] = []
    for path in files:
        e, w = check_file(path, shots_data, caps)
        errors += e
        warnings += w
    return (errors, warnings)


SHOTS_FIXTURE = {
    "project": {"aspect": "9:16"},
    "series_lock": {
        "character": "founder in a navy crewneck",
        "environment": "minimalist home office, oak desk",
        "lighting": "soft window light from camera-left",
        "color_grade": "warm filmic with muted teal shadows",
    },
    "shots": [{"id": "shot_01"}, {"id": "shot_02"}],
}


def _fixture(body_01: str, body_02: str | None = None, aspect: str = "9:16") -> str:
    out = [
        "# Storyboard: Fixture",
        "# Generator: flux",
        f"# Aspect: {aspect}",
        "# Brand-lock: brand-lock.snapshot.md",
        "# Run: 20260730T180000Z-7c41e0a9",
        "# Round: 1",
        "",
        "# shot_01, hook, 0.0-2.0s, MCU eye-level static",
        body_01,
        "",
    ]
    if body_02 is not None:
        out += ["# shot_02, pain, 2.0-6.0s, MS eye-level push", body_02, ""]
    return "\n".join(out)


def selftest() -> int:
    import tempfile

    ok = True
    sl = SHOTS_FIXTURE["series_lock"]
    good = (
        f"Medium close-up of a {sl['character']}. {sl['environment']}. "
        f"{sl['lighting']}. {sl['color_grade']}. Photorealistic."
    )
    drifted = (
        "Medium close-up of a founder in a navy sweater. A minimal home office with "
        "an oak desk. Soft light from the left. Warm grade with teal shadows."
    )

    cases = [
        ("a compliant full pass passes", _fixture(good, good), False),
        ("a paraphrased anchor is caught", _fixture(drifted, good), True),
        ("a missing shot in a full pass is caught", _fixture(good), True),
        ("an aspect mismatch is caught", _fixture(good, good, aspect="16:9"), True),
        (
            "an over-ceiling prompt is caught",
            _fixture(good + " extra" * 200, good),
            True,
        ),
        (
            "an unknown shot id is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_09,"),
            True,
        ),
        (
            "a duplicate shot block is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_01,"),
            True,
        ),
        (
            "an empty prompt body is caught",
            _fixture(good, ""),
            True,
        ),
    ]

    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "output"
        (out / "prompts" / "round-1").mkdir(parents=True)
        (out / "shots.json").write_text(json.dumps(SHOTS_FIXTURE))
        caps = capability_map()
        for label, text, should_fail in cases:
            p = out / "prompts" / "round-1" / "flux.txt"
            p.write_text(text)
            errors, _ = check_file(p, SHOTS_FIXTURE, caps)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        # Rule 1: overlay copy leaking into a prompt.
        (out / "text-overlays.json").write_text(
            json.dumps(
                {
                    "version": "1.0",
                    "overlays": [
                        {"id": "text_01", "content": "You are the bottleneck."}
                    ],
                }
            )
        )
        p = out / "prompts" / "round-1" / "flux.txt"
        p.write_text(_fixture(good + " The words You are the bottleneck appear.", good))
        errors, _ = check_file(p, SHOTS_FIXTURE, caps)
        if any("composited" in e for e in errors):
            print("  ok    selftest: overlay copy inside a prompt is caught")
        else:
            print(f"  FAIL  selftest: overlay leak not caught -> {errors}")
            ok = False

        # A revision file covers a subset, and that is not an error.
        rev = out / "prompts" / "round-2"
        rev.mkdir()
        rp = rev / "revised-flux.txt"
        rp.write_text(_fixture(good))
        errors, _ = check_file(rp, SHOTS_FIXTURE, caps)
        if not errors:
            print("  ok    selftest: a revision file may cover a subset of shots")
        else:
            print(f"  FAIL  selftest: revision subset flagged -> {errors}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_prompts.py <output-dir|prompt-file> [...]")
        print("       python tools/validate_prompts.py --examples")
        print("       python tools/validate_prompts.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    targets = [WORKED_RUN] if "--examples" in args else [Path(a) for a in args]

    print(f"Validating prompt files for {len(targets)} target(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for target in targets:
        errors, warnings = validate_target(target)
        try:
            shown = target.relative_to(REPO_ROOT)
        except ValueError:
            shown = target
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for e in errors:
                print(f"        - {e}")
        for w in warnings:
            print(f"  warn  {shown}: {w}")

    print()
    if total_errors == 0:
        print(f"All prompt files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across prompt files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/validate_prompts.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/validate_provenance.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/validate_provenance.py`

#!/usr/bin/env python3
"""
Validate the provenance chain of a shotkit output tree.

This is the tool that answers "does this verdict still describe the file it reviewed."
Paths lie: a filename says nothing about the bytes behind it, so a frame regenerated
after its critique leaves every path reference intact and every claim about it wrong.
Content hashes are what make that detectable, and this walks them.

Checks:
  1. run.json validates against run.schema.json, and its run_id agrees with created_at.
  2. Rounds are numbered from 1 with no gaps and no duplicates.
  3. Every input hash in run.json still matches the file on disk. A brand-lock edited
     mid-project fails here instead of silently repointing the project's history.
  4. Every prompt hash recorded in run.json still matches the file on disk.
  5. Every critique validates against the schema and the gating invariant.
  6. Every critique's run_id matches run.json.
  7. Every critique's image, prompt, and brand-lock hashes match the files on disk.
  8. No two critiques cover the same shot in the same round. Two operators writing the
     same verdict path is a real conflict, not a silent overwrite.
  9. Every frame on disk has a critique for its round. An unreviewed frame is the
     failure mode where a re-roll slips past the gate on a stale ACCEPT.
 10. Every shot has at least one critique, and the latest verdict per shot is reported.
 11. Shots recorded as post_only still owe compositing work.

Exit status is 0 when the chain is intact. Add --require-accept to also demand that
every shot's latest verdict is ACCEPT, which is the pipeline stop condition made
executable rather than described.

Usage:
    python tools/validate_provenance.py <output-dir> [...]
    python tools/validate_provenance.py <output-dir> --require-accept
    python tools/validate_provenance.py <output-dir> --json
    python tools/validate_provenance.py --examples
    python tools/validate_provenance.py --selftest
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    IMAGE_EXTS,
    REPO_ROOT,
    critique_paths,
    load_json,
    round_dirs,
    run_id_timestamp,
    sha256_file,
)
from validate_critique import _load_schema as _load_critique_schema
from validate_critique import validate_doc as validate_critique_doc

RUN_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "run.schema.json"
)
WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"


class Report:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.shots: dict[str, dict] = {}
        self.rounds_seen: list[int] = []
        # (path, recorded, actual) -> the labels that referenced it. One edited file is
        # one problem, even when twenty critiques all hash it.
        self.hash_failures: dict[tuple[str, str, str], list[str]] = {}

    def as_dict(self) -> dict:
        return {
            "output_dir": str(self.output_dir),
            "ok": not self.errors,
            "errors": self.errors,
            "warnings": self.warnings,
            "rounds": self.rounds_seen,
            "shots": self.shots,
        }


def _check_hash(
    report: Report, label: str, rel: str | None, expected: str | None
) -> None:
    """Compare a recorded hash against the file currently on disk."""
    if not rel or not expected:
        return
    path = report.output_dir / rel
    if not path.exists():
        report.errors.append(f"{label}: '{rel}' is referenced but missing on disk")
        return
    actual = sha256_file(path)
    if actual == expected:
        return
    report.hash_failures.setdefault((rel, expected, actual), []).append(label)


def _finalize_hash_failures(report: Report) -> None:
    """Turn collected hash mismatches into one error per distinct mismatch."""
    for (rel, expected, actual), labels in report.hash_failures.items():
        # Print both hashes in full. Truncating them meant a single mistyped character
        # at the end produced a message showing two identical-looking strings and
        # asserting they differed, which is the least useful moment to be imprecise: a
        # hand-authored run.json is exactly where typos come from.
        detail = (
            f"'{rel}' does not match the hash recorded for it\n"
            f"          recorded: {expected}\n"
            f"          on disk:  {actual}"
        )
        if len(expected) != 64:
            detail += (
                f"\n          the recorded value is {len(expected)} characters, not 64, "
                f"so it is malformed rather than stale"
            )
        elif sum(a != b for a, b in zip(expected, actual)) <= 2:
            detail += (
                "\n          they differ in one or two characters, which usually means "
                "a typo in the recorded hash rather than a changed file"
            )
        if len(labels) == 1:
            detail += f"\n          referenced by: {labels[0]}"
        else:
            shown = ", ".join(labels[:3])
            more = f", and {len(labels) - 3} more" if len(labels) > 3 else ""
            detail += (
                f"\n          referenced by {len(labels)} places: {shown}{more}"
            )
        report.errors.append(detail)


def check_run_doc(report: Report) -> dict | None:
    run_path = report.output_dir / "run.json"
    if not run_path.exists():
        report.errors.append(
            "run.json is missing, so nothing pins this output to its inputs. A tree "
            "written before 3.0.0 has no provenance to check: write a run.json "
            "(schema at skills/storyboard-architect/templates/run.schema.json) or "
            "re-run storyboard-architect. This is reported as an error rather than a "
            "warning so a pipeline gate cannot pass an unauditable tree"
        )
        return None

    run_doc, err = load_json(run_path)
    if err:
        report.errors.append(f"run.json: {err}")
        return None

    schema, s_err = load_json(RUN_SCHEMA)
    if s_err:
        report.errors.append(f"run.schema.json: {s_err}")
        return None

    validator = Draft202012Validator(schema)
    for e in sorted(validator.iter_errors(run_doc), key=lambda x: list(x.path)):
        loc = "/".join(str(p) for p in e.path) or "(root)"
        report.errors.append(f"run.json schema: {loc}: {e.message}")
    if report.errors:
        return None

    stamp = run_id_timestamp(run_doc["run_id"])
    expected = run_doc["created_at"].replace("-", "").replace(":", "")
    if stamp != expected:
        report.errors.append(
            f"run.json: run_id timestamp '{stamp}' disagrees with "
            f"created_at '{run_doc['created_at']}'"
        )

    if run_doc["inputs"].get("brand_lock_configured") is False:
        report.warnings.append(
            "run.json: brand_lock_configured is false, so this run was built against "
            "an unfilled template rather than a real brand-lock"
        )

    inputs = run_doc["inputs"]
    _check_hash(report, "inputs", inputs.get("shots_ref"), inputs.get("shots_sha256"))
    _check_hash(
        report,
        "inputs",
        inputs.get("text_overlays_ref"),
        inputs.get("text_overlays_sha256"),
    )
    _check_hash(
        report, "inputs", inputs.get("brand_lock_ref"), inputs.get("brand_lock_sha256")
    )

    numbers = [r["round"] for r in run_doc.get("rounds", [])]
    report.rounds_seen = sorted(numbers)
    if len(numbers) != len(set(numbers)):
        report.errors.append("run.json: duplicate round numbers")
    if numbers and sorted(numbers) != list(range(1, max(numbers) + 1)):
        report.errors.append(
            f"run.json: rounds must run 1..N with no gaps, got {sorted(numbers)}"
        )

    for rnd in run_doc.get("rounds", []):
        for prompt in rnd.get("prompts", []):
            _check_hash(
                report,
                f"round {rnd['round']} prompt",
                prompt.get("ref"),
                prompt.get("sha256"),
            )
        for shot_id in rnd.get("post_only_shots", []) or []:
            report.warnings.append(
                f"round {rnd['round']}: {shot_id} is recorded as post-only, so it owes "
                f"compositing work that no prompt or frame will show"
            )

    return run_doc


def _round_of(path: Path, output_dir: Path, data: dict) -> int:
    """
    Which round a critique belongs to.

    The directory name wins, because that is the addressing scheme. A legacy critique
    sitting at the output root has no directory to read, so fall back to its own
    `round` field and then to 1.
    """
    try:
        parent = path.relative_to(output_dir).parent.name
    except ValueError:
        parent = ""
    if parent.startswith("round-") and parent[len("round-"):].isdigit():
        return int(parent[len("round-"):])
    declared = data.get("round")
    return declared if isinstance(declared, int) and declared >= 1 else 1


def check_critiques(report: Report, run_doc: dict | None) -> None:
    critique_validator = Draft202012Validator(_load_critique_schema())
    seen: dict[tuple[str, int], Path] = {}

    # critique_paths() is the one definition of "where critiques live", shared with
    # validate_critique.py and shots-to-html.py. Walking the round directories directly
    # meant this tool ignored a legacy root critique.json that the other two read, so
    # the preview showed a verdict badge for a shot this tool called unreviewed.
    for path in critique_paths(report.output_dir):
        try:
            rel = path.relative_to(report.output_dir)
        except ValueError:
            rel = path
        data, err = load_json(path)
        if err:
            report.errors.append(f"{rel}: {err}")
            continue
        if not isinstance(data, dict):
            report.errors.append(f"{rel}: top level is not an object")
            continue

        errors, warnings = validate_critique_doc(data, critique_validator)
        report.errors.extend(f"{rel}: {e}" for e in errors)
        report.warnings.extend(f"{rel}: {w}" for w in warnings)
        if errors:
            continue

        round_no = _round_of(path, report.output_dir, data)
        in_round_dir = rel.parent.name.startswith("round-")

        if in_round_dir and data.get("round") not in (None, round_no):
            report.errors.append(
                f"{rel}: declares round {data.get('round')} but sits in round-{round_no}/"
            )
        if run_doc and data.get("run_id") not in (None, run_doc["run_id"]):
            report.errors.append(
                f"{rel}: run_id '{data.get('run_id')}' does not match run.json "
                f"'{run_doc['run_id']}'"
            )

        shot_id = data.get("shot_id")
        if shot_id:
            key = (shot_id, round_no)
            if key in seen:
                report.errors.append(
                    f"{rel}: a second critique for {shot_id} in round {round_no} "
                    f"already exists at {seen[key]}; "
                    f"two operators reviewed the same shot in the same round"
                )
            else:
                seen[key] = rel

        _check_hash(report, f"{rel} image", data.get("image_ref"), data.get("image_sha256"))
        _check_hash(report, f"{rel} prompt", data.get("prompt_ref"), data.get("prompt_sha256"))
        _check_hash(
            report,
            f"{rel} brand-lock",
            data.get("brand_lock_ref"),
            data.get("brand_lock_sha256"),
        )

        if shot_id:
            entry = report.shots.setdefault(shot_id, {"rounds": {}})
            entry["rounds"][str(round_no)] = {
                "verdict": data.get("verdict"),
                "confidence": data.get("confidence"),
                "critique_ref": str(rel),
                "issues": len(data.get("issues", [])),
            }


def check_coverage(report: Report, run_doc: dict | None) -> None:
    shots_rel = "shots.json"
    if run_doc:
        shots_rel = run_doc["inputs"].get("shots_ref", "shots.json")
    shots_data, err = load_json(report.output_dir / shots_rel)
    shot_ids: list[str] = []
    if err:
        report.warnings.append(f"coverage: cannot read {shots_rel}, skipped ({err})")
    elif isinstance(shots_data, dict):
        shot_ids = [
            s["id"] for s in shots_data.get("shots", []) if isinstance(s.get("id"), str)
        ]

    reviewed_by_round: dict[int, set[str]] = {}
    for shot_id, entry in report.shots.items():
        for rnd in entry["rounds"]:
            reviewed_by_round.setdefault(int(rnd), set()).add(shot_id)

    for round_no, directory in round_dirs(report.output_dir, "frames"):
        reviewed = reviewed_by_round.get(round_no, set())
        for path in sorted(directory.iterdir()):
            if path.suffix.lstrip(".").lower() not in IMAGE_EXTS:
                continue
            frame_shot = path.stem
            if frame_shot not in reviewed:
                report.errors.append(
                    f"coverage: frames/round-{round_no}/{path.name} has no critique for "
                    f"round {round_no}; it was never reviewed"
                )

    for shot_id in shot_ids:
        entry = report.shots.get(shot_id)
        if not entry:
            report.warnings.append(
                f"coverage: {shot_id} has no critique in any round"
            )
            continue
        latest = max(int(r) for r in entry["rounds"])
        entry["latest_round"] = latest
        entry["latest_verdict"] = entry["rounds"][str(latest)]["verdict"]

    for shot_id in report.shots:
        if shot_ids and shot_id not in shot_ids:
            report.errors.append(
                f"coverage: a critique names {shot_id}, which is not in {shots_rel}"
            )


def validate_tree(output_dir: Path) -> Report:
    report = Report(output_dir)
    if not output_dir.is_dir():
        report.errors.append(f"not a directory: {output_dir}")
        return report
    run_doc = check_run_doc(report)
    check_critiques(report, run_doc)
    check_coverage(report, run_doc)
    _finalize_hash_failures(report)
    return report


def outstanding(report: Report) -> list[str]:
    """Shots whose latest verdict is not ACCEPT."""
    return sorted(
        shot_id
        for shot_id, entry in report.shots.items()
        if entry.get("latest_verdict") not in (None, "ACCEPT")
    )


def selftest() -> int:
    """Run the bundled worked example, then tamper with a copy and prove drift is caught."""
    import shutil
    import tempfile

    ok = True

    clean = validate_tree(WORKED_RUN)
    if clean.errors:
        print(f"  FAIL  selftest: the bundled worked run should be clean, got: {clean.errors}")
        ok = False
    else:
        print("  ok    selftest: the bundled worked run passes")

    if outstanding(clean):
        print(f"  FAIL  selftest: worked run should have no outstanding shots, got {outstanding(clean)}")
        ok = False
    else:
        print("  ok    selftest: every shot in the worked run ends on ACCEPT")

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        frame = scratch / "frames" / "round-2" / "shot_02.png"
        frame.write_bytes(frame.read_bytes() + b"\x00")
        report = validate_tree(scratch)
        if any("does not match the hash recorded" in e for e in report.errors):
            print("  ok    selftest: a frame regenerated after its critique is caught")
        else:
            print(f"  FAIL  selftest: frame tampering was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        lock = scratch / "brand-lock.snapshot.md"
        lock.write_text(lock.read_text() + "\n<!-- edited mid-project -->\n")
        report = validate_tree(scratch)
        if any("brand-lock.snapshot.md' does not match" in e for e in report.errors):
            print("  ok    selftest: a brand-lock edited mid-project is caught")
        else:
            print(f"  FAIL  selftest: brand-lock drift was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        src = scratch / "critiques" / "round-2" / "shot_02.critique.json"
        (scratch / "critiques" / "round-2" / "shot_02.operator-b.json").write_text(
            src.read_text()
        )
        report = validate_tree(scratch)
        if any("two operators reviewed the same shot" in e for e in report.errors):
            print("  ok    selftest: two critiques for one shot in one round is caught")
        else:
            print(f"  FAIL  selftest: duplicate critique was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        source = scratch / "frames" / "round-2" / "shot_02.png"
        (scratch / "frames" / "round-2" / "shot_01.png").write_bytes(source.read_bytes())
        report = validate_tree(scratch)
        if any("was never reviewed" in e for e in report.errors):
            print("  ok    selftest: a frame with no critique for its round is caught")
        else:
            print(f"  FAIL  selftest: unreviewed frame was not caught, got: {report.errors}")
            ok = False

    # A legacy tree keeps its critique at the output root. validate_critique.py and
    # shots-to-html.py both read it, so this tool has to as well: reporting a shot as
    # unreviewed while the preview shows its verdict badge is the exact kind of
    # disagreement between consumers that this release exists to remove.
    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "legacy"
        scratch.mkdir()
        shutil.copy(WORKED_RUN / "shots.json", scratch / "shots.json")
        shutil.copy(
            WORKED_RUN / "critiques" / "round-1" / "shot_01.critique.json",
            scratch / "critique.json",
        )
        report = validate_tree(scratch)
        if "shot_01" in report.shots:
            print("  ok    selftest: a legacy root critique.json is still discovered")
        else:
            print(
                "  FAIL  selftest: legacy root critique.json was ignored; "
                f"shots seen: {sorted(report.shots)}"
            )
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_provenance.py <output-dir> [...]")
        print("       python tools/validate_provenance.py <output-dir> --require-accept")
        print("       python tools/validate_provenance.py --examples")
        print("       python tools/validate_provenance.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    require_accept = "--require-accept" in args
    as_json = "--json" in args
    targets_raw = [a for a in args if not a.startswith("--")]

    if "--examples" in args:
        targets = [WORKED_RUN]
    elif targets_raw:
        targets = [Path(t) for t in targets_raw]
    else:
        print("ERROR: no output directory given")
        return 2

    reports = [validate_tree(t) for t in targets]

    if as_json:
        print(json.dumps([r.as_dict() for r in reports], indent=2))
    else:
        print(f"Validating provenance for {len(reports)} output tree(s)")
        print()
        for report in reports:
            try:
                label = report.output_dir.relative_to(REPO_ROOT)
            except ValueError:
                label = report.output_dir
            if report.errors:
                print(f"  FAIL  {label}")
                for err in report.errors:
                    print(f"        - {err}")
            else:
                print(f"  ok    {label}  ({len(report.shots)} shot(s), rounds {report.rounds_seen or 'none'})")
            for warn in report.warnings:
                print(f"  warn  {label}: {warn}")
            for shot_id in sorted(report.shots):
                entry = report.shots[shot_id]
                verdict = entry.get("latest_verdict", "?")
                print(
                    f"        {shot_id}: {verdict} "
                    f"(round {entry.get('latest_round', '?')})"
                )
        print()

    failed = any(r.errors for r in reports)
    unresolved = {
        str(r.output_dir): outstanding(r) for r in reports if outstanding(r)
    }

    if not as_json:
        if failed:
            total = sum(len(r.errors) for r in reports)
            print(f"FAILED: {total} provenance error(s).")
        elif require_accept and unresolved:
            for path, shots in unresolved.items():
                print(f"NOT DONE: {path} still has non-ACCEPT shots: {', '.join(shots)}")
        else:
            print("Provenance chain intact.")

    if failed:
        return 1
    if require_accept and unresolved:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/validate_provenance.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/validate_schemas.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/validate_schemas.py`

#!/usr/bin/env python3
"""
Validate that every *.schema.json file in the repo is itself valid JSON Schema.

Run from repo root:
    python tools/validate_schemas.py
"""

from __future__ import annotations
import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
    from jsonschema.exceptions import SchemaError
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install jsonschema")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent


def find_schema_files() -> list[Path]:
    """Find every *.schema.json file in the repo."""
    return sorted(REPO_ROOT.rglob("*.schema.json"))


def validate_schema_file(path: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        errors.append(f"invalid JSON: {e}")
        return errors

    try:
        Draft202012Validator.check_schema(data)
    except SchemaError as e:
        errors.append(f"invalid schema: {e.message}")

    if "$id" not in data:
        errors.append("missing '$id' field")
    if "title" not in data:
        errors.append("missing 'title' field")
    if "description" not in data:
        errors.append("missing 'description' field")

    return errors


def main() -> int:
    schemas = find_schema_files()
    if not schemas:
        print("ERROR: no *.schema.json files found in repo")
        return 1

    print(f"Validating {len(schemas)} schema file(s)")
    print()

    total_errors = 0
    for path in schemas:
        rel = path.relative_to(REPO_ROOT)
        errors = validate_schema_file(path)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All schemas valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across schemas.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/validate_schemas.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/validate_shots.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/validate_shots.py`

#!/usr/bin/env python3
"""
Validate a storyboard output set: shots.json and text-overlays.json, as instances.

Schema validation alone was never enough here. Every rule below is documented in
skills/storyboard-architect/SKILL.md as a quality-bar checkbox, which means it was
enforced by a model remembering to check it. These are the same rules, executable.

Checks:
  1. shots.json validates against shots.schema.json.
  2. text-overlays.json validates against text-overlays.schema.json.
  3. Timing: end > start, no duplicate ids, no gaps, no overlaps, and the covered
     span matches project.duration_s within TIMING_TOLERANCE_S.
  4. Reference integrity, both directions: every shot.on_screen_text resolves to an
     overlay, every overlay.shot_id resolves to a shot, and every overlay is
     reachable from at least one shot.
  5. Overlay timing sits inside its shot window and exit is after enter.
  6. Every overlay color appears in the brand-lock palette.
  7. brand_lock_ref resolves on disk.
  8. Every assets.generated[].generator is a real id in the capability matrix.
  9. Warnings for prose leaks: on-screen copy repeated in a shot subject, raw hex in
     a shot subject, shot ids out of chronological order, overlay fonts not named in
     the brand-lock typography section.

Usage:
    python tools/validate_shots.py <output-dir> [...]
    python tools/validate_shots.py path/to/shots.json [...]
    python tools/validate_shots.py --examples          # every bundled example
    python tools/validate_shots.py --selftest          # prove the checks fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    HEX_RE,
    REPO_ROOT,
    as_overlay_ids,
    as_shot_ids,
    capability_ids,
    load_json,
    palette_hexes,
    parse_typography,
)

SHOTS_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "shots.schema.json"
)
OVERLAYS_SCHEMA = (
    REPO_ROOT
    / "skills"
    / "storyboard-architect"
    / "templates"
    / "text-overlays.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "storyboard-architect" / "examples"

TIMING_TOLERANCE_S = 0.1


def _schema_errors(data, validator: Draft202012Validator, label: str) -> list[str]:
    out = []
    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        out.append(f"{label} schema: {loc}: {err.message}")
    return out


def check_timing(shots: list[dict], duration_s: float) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    seen: set[str] = set()
    for shot in shots:
        sid = shot.get("id", "?")
        if sid in seen:
            errors.append(f"timing: duplicate shot id '{sid}'")
        seen.add(sid)
        start, end = shot.get("start"), shot.get("end")
        if isinstance(start, (int, float)) and isinstance(end, (int, float)):
            if end <= start:
                errors.append(
                    f"timing: {sid} has end ({end}) not after start ({start})"
                )

    timed = [
        s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    ]
    if not timed:
        return errors, warnings

    ordered = sorted(timed, key=lambda s: (s["start"], s["end"]))
    for a, b in zip(ordered, ordered[1:]):
        if b["start"] > a["end"] + 1e-9:
            errors.append(
                f"timing: gap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )
        elif b["start"] < a["end"] - 1e-9:
            errors.append(
                f"timing: overlap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )

    span = max(s["end"] for s in timed) - min(s["start"] for s in timed)
    if abs(span - duration_s) > TIMING_TOLERANCE_S:
        errors.append(
            f"timing: covered span {span:g}s does not match project.duration_s "
            f"{duration_s:g}s (tolerance {TIMING_TOLERANCE_S}s)"
        )

    if [s["id"] for s in timed] != [s["id"] for s in ordered]:
        warnings.append(
            "timing: shot ids are not in chronological order; readers assume they are"
        )

    return errors, warnings


def check_version_features(shots: list[dict], version: str) -> list[str]:
    """Features may not be used below the version that introduced them."""
    errors: list[str] = []
    if version in ("1.0", "1.1"):
        for shot in shots:
            if isinstance(shot.get("on_screen_text"), list):
                errors.append(
                    f"version: {shot.get('id')} uses the array form of on_screen_text, "
                    f"which requires version 1.2 (file declares {version})"
                )
    if version == "1.0":
        for shot in shots:
            if shot.get("assets") is not None:
                errors.append(
                    f"version: {shot.get('id')} carries an assets block, which "
                    f"requires version 1.1 or later (file declares 1.0)"
                )
    return errors


def check_references(
    shots: list[dict], overlays: list[dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    shot_ids = {s.get("id") for s in shots}
    overlay_ids: set[str] = set()
    for overlay in overlays:
        oid = overlay.get("id")
        if oid in overlay_ids:
            errors.append(f"reference: duplicate overlay id '{oid}'")
        overlay_ids.add(oid)

    referenced: set[str] = set()
    for shot in shots:
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            referenced.add(oid)
            if oid not in overlay_ids:
                errors.append(
                    f"reference: {shot.get('id')}.on_screen_text '{oid}' has no "
                    f"entry in text-overlays.json"
                )

    for overlay in overlays:
        oid = overlay.get("id")
        for sid in as_shot_ids(overlay.get("shot_id")):
            if sid not in shot_ids:
                errors.append(
                    f"reference: overlay {oid}.shot_id '{sid}' has no entry in shots.json"
                )
        if oid not in referenced:
            errors.append(
                f"reference: overlay {oid} is not reachable from any "
                f"shot.on_screen_text, so no renderer will show it"
            )

    return errors, warnings


def check_overlay_windows(shots: list[dict], overlays: list[dict]) -> list[str]:
    errors: list[str] = []
    by_id = {
        s["id"]: s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    }

    for overlay in overlays:
        oid = overlay.get("id")
        enter = (overlay.get("enter") or {}).get("at")
        exit_at = (overlay.get("exit") or {}).get("at")
        if not isinstance(enter, (int, float)) or not isinstance(exit_at, (int, float)):
            continue
        if exit_at <= enter:
            errors.append(
                f"overlay: {oid} exit ({exit_at}) is not after enter ({enter})"
            )
        windows = [by_id[s] for s in as_shot_ids(overlay.get("shot_id")) if s in by_id]
        if not windows:
            continue
        lo = min(w["start"] for w in windows)
        hi = max(w["end"] for w in windows)
        if enter < lo - 1e-9 or exit_at > hi + 1e-9:
            errors.append(
                f"overlay: {oid} timing {enter}-{exit_at}s falls outside its shot "
                f"window {lo:g}-{hi:g}s"
            )

    return errors


def check_brand_alignment(
    shots: list[dict], overlays: list[dict], brand_lock_text: str | None
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if brand_lock_text is None:
        warnings.append(
            "brand: brand_lock_ref did not resolve, so palette and font checks were skipped"
        )
        return errors, warnings

    allowed = palette_hexes(brand_lock_text)
    for overlay in overlays:
        color = overlay.get("color")
        if isinstance(color, str) and color.lower() not in allowed:
            errors.append(
                f"brand: overlay {overlay.get('id')} color {color} is not in the "
                f"brand-lock palette"
            )

    fonts = {v.lower() for v in parse_typography(brand_lock_text).values() if v}
    if fonts:
        for overlay in overlays:
            font = overlay.get("font")
            if isinstance(font, str) and font.lower() not in fonts:
                warnings.append(
                    f"brand: overlay {overlay.get('id')} font '{font}' is not a font "
                    f"declared in the brand-lock typography section"
                )

    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        for hex_val in HEX_RE.findall(subject):
            warnings.append(
                f"brand: {shot.get('id')}.subject names a raw hex ({hex_val}); "
                f"colors belong in series_lock and the brand-lock"
            )

    return errors, warnings


def check_text_leak(shots: list[dict], overlays: list[dict]) -> list[str]:
    """On-screen copy repeated inside a shot subject. Text is a separate layer."""
    warnings: list[str] = []
    contents = {
        o.get("id"): o.get("content")
        for o in overlays
        if isinstance(o.get("content"), str) and len(o.get("content", "")) >= 8
    }
    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        lowered = subject.lower()
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            content = contents.get(oid)
            if content and content.lower().rstrip(".!?") in lowered:
                warnings.append(
                    f"text: {shot.get('id')}.subject repeats overlay {oid} copy "
                    f"verbatim; on-screen text is composited, never described"
                )
    return warnings


def check_assets(shots: list[dict], known_generators: set[str]) -> list[str]:
    errors: list[str] = []
    if not known_generators:
        return errors
    for shot in shots:
        for entry in (shot.get("assets") or {}).get("generated", []) or []:
            gen = entry.get("generator")
            if isinstance(gen, str) and gen not in known_generators:
                errors.append(
                    f"assets: {shot.get('id')} generated frame names generator "
                    f"'{gen}', which is not in the capability matrix"
                )
            if entry.get("accepted") is True and not entry.get("critique_ref"):
                errors.append(
                    f"assets: {shot.get('id')} has an accepted frame with no "
                    f"critique_ref, which is an unsourced approval"
                )
    return errors


def validate_set(shots_path: Path) -> tuple[list[str], list[str]]:
    """Validate one shots.json plus the siblings it points at."""
    errors: list[str] = []
    warnings: list[str] = []

    shots_data, err = load_json(shots_path)
    if err:
        return ([err], warnings)
    if not isinstance(shots_data, dict):
        return ([f"{shots_path}: top level is not an object"], warnings)

    shots_schema, s_err = load_json(SHOTS_SCHEMA)
    overlays_schema, o_err = load_json(OVERLAYS_SCHEMA)
    if s_err or o_err:
        return ([s_err or o_err], warnings)

    errors += _schema_errors(
        shots_data, Draft202012Validator(shots_schema), "shots.json"
    )

    base = shots_path.parent
    overlays_path = base / "text-overlays.json"
    overlays: list[dict] = []
    if overlays_path.exists():
        overlays_data, ov_err = load_json(overlays_path)
        if ov_err:
            errors.append(f"text-overlays.json: {ov_err}")
        else:
            errors += _schema_errors(
                overlays_data,
                Draft202012Validator(overlays_schema),
                "text-overlays.json",
            )
            overlays = overlays_data.get("overlays", []) or []
    else:
        for shot in shots_data.get("shots", []) or []:
            if as_overlay_ids(shot.get("on_screen_text")):
                errors.append(
                    "reference: shots.json references on-screen text but "
                    "text-overlays.json is missing"
                )
                break

    if errors:
        # Structure-dependent checks assume schema-valid input.
        return (errors, warnings)

    shots = shots_data.get("shots", []) or []
    duration = shots_data.get("project", {}).get("duration_s")

    errors += check_version_features(shots, shots_data.get("version", ""))

    if isinstance(duration, (int, float)):
        t_err, t_warn = check_timing(shots, float(duration))
        errors += t_err
        warnings += t_warn

    r_err, r_warn = check_references(shots, overlays)
    errors += r_err
    warnings += r_warn
    errors += check_overlay_windows(shots, overlays)

    brand_ref = shots_data.get("brand_lock_ref")
    brand_text: str | None = None
    if isinstance(brand_ref, str):
        brand_path = base / brand_ref
        if brand_path.exists():
            brand_text = brand_path.read_text(encoding="utf-8")
        else:
            errors.append(
                f"brand: brand_lock_ref '{brand_ref}' does not resolve from {base}"
            )
    b_err, b_warn = check_brand_alignment(shots, overlays, brand_text)
    errors += b_err
    warnings += b_warn

    warnings += check_text_leak(shots, overlays)
    errors += check_assets(shots, capability_ids())

    return (errors, warnings)


def _resolve_target(raw: str) -> Path | None:
    path = Path(raw)
    if path.is_dir():
        candidate = path / "shots.json"
        return candidate if candidate.exists() else None
    return path if path.exists() else None


def selftest() -> int:
    """Prove the cross-field checks fire. Fixtures are in-memory, no files touched."""
    ok = True
    cases = [
        (
            "end not after start",
            lambda: check_timing(
                [{"id": "shot_01", "start": 5.0, "end": 3.0}], 30.0
            )[0],
        ),
        (
            "gap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 2.0},
                    {"id": "shot_02", "start": 4.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "overlap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 5.0},
                    {"id": "shot_02", "start": 3.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "span disagrees with duration",
            lambda: check_timing(
                [{"id": "shot_01", "start": 0.0, "end": 10.0}], 30.0
            )[0],
        ),
        (
            "dangling on_screen_text",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": "text_09"}], []
            )[0],
        ),
        (
            "unreachable overlay",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": None}],
                [{"id": "text_01", "shot_id": "shot_01"}],
            )[0],
        ),
        (
            "overlay outside its shot window",
            lambda: check_overlay_windows(
                [{"id": "shot_01", "start": 0.0, "end": 2.0}],
                [
                    {
                        "id": "text_01",
                        "shot_id": "shot_01",
                        "enter": {"at": 0.0},
                        "exit": {"at": 9.0},
                    }
                ],
            ),
        ),
        (
            "off-palette overlay color",
            lambda: check_brand_alignment(
                [],
                [{"id": "text_01", "color": "#ABCDEF"}],
                "## Palette\n\n| Role | Hex |\n|---|---|\n| Ink | `#2A2A32` |\n",
            )[0],
        ),
        (
            "accepted frame with no critique_ref",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {"generated": [{"path": "a.png", "accepted": True}]},
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "unknown generator id",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {
                            "generated": [{"path": "a.png", "generator": "runway-sora"}]
                        },
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "1.2 feature used in a 1.0 file",
            lambda: check_version_features(
                [{"id": "shot_01", "on_screen_text": ["text_01", "text_02"]}], "1.0"
            ),
        ),
    ]

    for label, fn in cases:
        produced = fn()
        if produced:
            print(f"  ok    selftest: {label} is caught")
        else:
            print(f"  FAIL  selftest: {label} was not caught")
            ok = False

    clean, clean_warn = check_timing(
        [
            {"id": "shot_01", "start": 0.0, "end": 2.0},
            {"id": "shot_02", "start": 2.0, "end": 30.0},
        ],
        30.0,
    )
    if clean or clean_warn:
        print(f"  FAIL  selftest: a clean shot list should pass, got: {clean + clean_warn}")
        ok = False
    else:
        print("  ok    selftest: a clean shot list passes")

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_shots.py <output-dir|shots.json> [...]")
        print("       python tools/validate_shots.py --examples")
        print("       python tools/validate_shots.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    if "--examples" in args:
        targets = sorted(EXAMPLES_DIR.glob("*/shots.json"))
        if not targets:
            print(f"ERROR: no bundled examples found under {EXAMPLES_DIR}")
            return 1
    else:
        targets = []
        for raw in args:
            resolved = _resolve_target(raw)
            if resolved is None:
                print(f"  FAIL  {raw}")
                print("        - no shots.json found at this path")
                return 1
            targets.append(resolved)

    print(f"Validating {len(targets)} storyboard set(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for shots_path in targets:
        try:
            rel = shots_path.relative_to(REPO_ROOT)
        except ValueError:
            rel = shots_path
        errors, warnings = validate_set(shots_path)
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {rel}: {warn}")

    print()
    if total_errors == 0:
        print(f"All storyboard sets valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across storyboard sets.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/validate_shots.py -->


<!-- SOURCE_FILE_START: skills/visual-asset-critic/tools/validate_skills.py -->
# SOURCE FILE: `skills/visual-asset-critic/tools/validate_skills.py`

#!/usr/bin/env python3
"""
Validate every SKILL.md in the repo has the required frontmatter.

Required fields:
- name (string, matches the directory name)
- description (string, non-empty)

Run from repo root:
    python tools/validate_skills.py
"""

from __future__ import annotations
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML not installed. Run: pip install pyyaml")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent
SKILLS_DIR = REPO_ROOT / "skills"


def parse_frontmatter(path: Path) -> dict | None:
    """Extract YAML frontmatter from a Markdown file. Returns None if absent."""
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    parts = text.split("---", 2)
    if len(parts) < 3:
        return None
    try:
        return yaml.safe_load(parts[1])
    except yaml.YAMLError as e:
        print(f"  YAML parse error: {e}")
        return None


def validate_skill(skill_dir: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    skill_md = skill_dir / "SKILL.md"

    if not skill_md.exists():
        errors.append(f"missing SKILL.md")
        return errors

    fm = parse_frontmatter(skill_md)
    if fm is None:
        errors.append("missing or invalid YAML frontmatter")
        return errors

    if "name" not in fm:
        errors.append("frontmatter missing 'name'")
    elif not isinstance(fm["name"], str) or not fm["name"].strip():
        errors.append("frontmatter 'name' must be a non-empty string")
    elif fm["name"] != skill_dir.name:
        errors.append(
            f"frontmatter name '{fm['name']}' does not match directory name '{skill_dir.name}'"
        )

    if "description" not in fm:
        errors.append("frontmatter missing 'description'")
    elif not isinstance(fm["description"], str) or not fm["description"].strip():
        errors.append("frontmatter 'description' must be a non-empty string")
    elif len(fm["description"]) < 50:
        errors.append(
            f"frontmatter description is too short ({len(fm['description'])} chars). "
            "Aim for >= 50 chars to support skill triggering."
        )

    return errors


def main() -> int:
    if not SKILLS_DIR.exists():
        print(f"ERROR: skills directory not found at {SKILLS_DIR}")
        return 1

    skill_dirs = sorted([d for d in SKILLS_DIR.iterdir() if d.is_dir()])
    if not skill_dirs:
        print(f"ERROR: no skill directories found in {SKILLS_DIR}")
        return 1

    print(f"Validating {len(skill_dirs)} skill(s) in {SKILLS_DIR.relative_to(REPO_ROOT)}/")
    print()

    total_errors = 0
    for skill_dir in skill_dirs:
        errors = validate_skill(skill_dir)
        rel = skill_dir.relative_to(REPO_ROOT)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All skills valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across skills.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-asset-critic/tools/validate_skills.py -->


<!-- SOURCE_FILE_START: skills/visual-media/SKILL.md -->
# SOURCE FILE: `skills/visual-media/SKILL.md`

---
name: visual-media
description: Creación visual — fotografía, producción de video, animación, cine, contenido de formato corto (Reels/TikTok/Shorts) y postproducción. Cubre triángulo de exposición, reglas de composición, tipos de plano, movimientos de cámara, los 12 principios de animación de Disney, ritmo de edición, J-cut/L-cut, regla de los 180 grados y color grading. Usa este skill siempre que el usuario mencione fotografía, video, animación, cine, edición, postproducción, storyboard, guion técnico, encuadre, iluminación, plano, movimiento de cámara, colorización, Reels, TikTok, Shorts, photography, filmmaking, editing, color grading, 攝影, 影片, 動畫, 剪輯 o 短影音 — y también cuando pida un plan de rodaje, feedback sobre material grabado, storytelling visual, un flujo de producción audiovisual o decisiones de encuadre e iluminación, aunque nunca diga la palabra "skill". No aplicar a tareas de código, API o backend.
license: MIT
metadata:
  mcpmarket-version: 1.0.0
  source: mcpmarket-me plugin (knoxgraeme/mcpmarket-plugin)
  original-author: claude-domain-skills
  language: es-MX (traducido del original en chino tradicional)
---
# Creación Visual — Visual Media

> Contar historias con lenguaje visual y crear imágenes memorables.

## Cuándo aplica

- Composición y técnica fotográfica
- Planeación y producción de video
- Creación de contenido de formato corto
- Flujo de producción de animación
- Edición y colorización en postproducción

## Fundamentos de fotografía

### Triángulo de exposición

```
┌─────────────────────────────────────────────────────────────────┐
│  Triángulo de exposición — Exposure Triangle                    │
│                                                                 │
│              Diafragma / Aperture                               │
│                 /\                                              │
│                /  \                                             │
│               /    \                                            │
│              /      \                                           │
│             /        \                                          │
│            /          \                                         │
│           /            \                                        │
│          /______________\                                       │
│    Obturador Shutter    ISO Sensibilidad                        │
│                                                                 │
│  Diafragma (f/1.4 – f/22)                                       │
│  ├─ Abierto (número bajo): poca profundidad, fondo desenfocado  │
│  └─ Cerrado (número alto): mucha profundidad, todo nítido       │
│                                                                 │
│  Obturador (1/4000s – 30s)                                      │
│  ├─ Alta velocidad: congela el movimiento                       │
│  └─ Baja velocidad: motion blur, estelas de luz                 │
│                                                                 │
│  ISO (100 – 12800+)                                             │
│  ├─ ISO bajo: imagen limpia y detallada                         │
│  └─ ISO alto: sirve en poca luz, pero introduce ruido           │
└─────────────────────────────────────────────────────────────────┘
```

### Reglas de composición

```markdown
## Composición básica

### Regla de tercios
- Divide el encuadre en una retícula de 3×3
- Coloca el sujeto en los puntos de intersección
- Sitúa el horizonte en la línea superior o inferior

### Líneas guía
- Usa líneas para conducir la mirada
- Caminos, ríos, barandales
- Que apunten al sujeto

### Encuadre dentro del encuadre
- Enmarca al sujeto con elementos del primer plano
- Marcos de puerta, ventanas, ramas
- Aporta capas y profundidad

### Simetría y equilibrio
- Simetría perfecta = estabilidad, solemnidad
- Asimetría = dinamismo, tensión
- Equilibra el peso visual

### Espacio negativo
- El vacío refuerza el punto focal
- Da "espacio para respirar" al sujeto
- Estética minimalista
```

### Uso de la luz

| Tipo de luz | Característica | Ideal para |
|-------------|----------------|------------|
| **Luz frontal** | Plana, con pocas sombras | Registro, foto de documento |
| **Luz lateral** | Volumétrica, con sombras | Retrato, arquitectura |
| **Contraluz** | Silueta, halo | Atmósfera, pieza artística |
| **Luz cenital** | Sombras duras | Evitar al mediodía |
| **Hora dorada** | Cálida y suave | Paisaje, retrato |
| **Hora azul** | Fría, enigmática | Ciudad, nocturnas |

## Producción de video

### Flujo de producción

```
┌─────────────────────────────────────────────────────────────────┐
│  Las tres etapas de producción                                  │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Preproducción│  │   Rodaje     │  │Postproducción│          │
│  │  Pre-prod    │→ │  Production  │→ │  Post-prod   │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                 │
│  Preproducción (30%)                                            │
│  ├─ Guion / concepto                                            │
│  ├─ Storyboard                                                  │
│  ├─ Casting / scouting de locaciones                            │
│  └─ Equipo técnico y humano                                     │
│                                                                 │
│  Rodaje (20%)                                                   │
│  ├─ Dirección en set                                            │
│  ├─ Montaje de iluminación                                      │
│  ├─ Captura de audio                                            │
│  └─ Cobertura desde varios ángulos                              │
│                                                                 │
│  Postproducción (50%)                                           │
│  ├─ Edición                                                     │
│  ├─ Colorización                                                │
│  ├─ Diseño sonoro / musicalización                              │
│  └─ VFX y titulaje                                              │
└─────────────────────────────────────────────────────────────────┘
```

### Movimientos de cámara

| Movimiento | Efecto | Cuándo usarlo |
|------------|--------|---------------|
| **Push in** | Énfasis, acercamiento | Revelar el punto clave |
| **Pull out** | Revela el conjunto | Cierre, transición |
| **Pan** | Desplazamiento horizontal | Seguimiento, presentar el entorno |
| **Tilt** | Desplazamiento vertical | Mostrar altura |
| **Track** | Acompaña al sujeto | Caminata, persecución |
| **Órbita** | Giro de 360° | Momento dramático |
| **Cámara en mano** | Inmediatez, presencia | Documental, tensión |

### Uso de los tipos de plano

```markdown
## Tipos de plano — Shot Types

### Plano general (Wide Shot)
- Establece la escena
- Muestra el entorno
- El personaje se ve pequeño

### Plano entero (Full Shot)
- Cuerpo completo
- Acción legible
- Luce el vestuario

### Plano medio (Medium Shot)
- De la cintura hacia arriba
- Escenas de diálogo
- Gestualidad de manos

### Primer plano (Close-up)
- De los hombros hacia arriba
- Expresión emocional
- Línea de diálogo importante

### Primerísimo primer plano (Extreme Close-up)
- Detalle de ojos o manos
- Emoción intensa
- Detalle de objeto
```

## Contenido de formato corto

### Perfil de cada plataforma

| Plataforma | Duración óptima | Relación de aspecto | Carácter |
|------------|-----------------|---------------------|----------|
| TikTok | 15–60s | 9:16 | Entretenimiento, retos |
| Reels | 15–90s | 9:16 | Cuidado, estética |
| Shorts | 15–60s | 9:16 | Divulgación, humor |
| Douyin | 15–60s | 9:16 | Contenido local |

### Estructura de un video corto

```
┌─────────────────────────────────────────────────────────────────┐
│  Fórmula de oro del formato corto                               │
│                                                                 │
│  0–3 s: Hook                                                    │
│  ├─ Pregunta o intriga                                          │
│  ├─ Impacto visual                                              │
│  └─ "Espérate a ver esto…"                                      │
│                                                                 │
│  3–50 s: Contenido                                              │
│  ├─ Ritmo acelerado                                             │
│  ├─ Entrega por bloques                                         │
│  └─ Sostener el interés                                         │
│                                                                 │
│  Últimos 5 s: CTA                                               │
│  ├─ Like / seguir                                               │
│  ├─ Invitar a comentar                                          │
│  └─ Ver más contenido                                           │
│                                                                 │
│  Clave: ¡los primeros 3 segundos deciden todo!                  │
└─────────────────────────────────────────────────────────────────┘
```

## Fundamentos de animación

### Los 12 principios

```markdown
## Los 12 principios de animación de Disney

1. **Squash & Stretch** (compresión y estiramiento)
   - Conservar el volumen
   - Comunicar peso y elasticidad

2. **Anticipación** (Anticipation)
   - Agacharse antes de saltar
   - Retraer el brazo antes del golpe

3. **Puesta en escena** (Staging)
   - Comunicar la intención con claridad
   - Guiar la mirada del espectador

4. **Directo vs. pose a pose** (Straight Ahead & Pose to Pose)
   - Directo: fluido, orgánico
   - Pose a pose: preciso, controlable

5. **Acción continuada y superpuesta** (Follow Through & Overlapping)
   - El retardo del cabello y la ropa
   - Aporta naturalidad

6. **Entradas y salidas lentas** (Slow In & Slow Out)
   - El movimiento arranca y termina lento
   - Y acelera en medio

7. **Arcos** (Arcs)
   - El movimiento natural es curvo
   - Evita la sensación mecánica

8. **Acción secundaria** (Secondary Action)
   - Micromovimientos además de la acción principal
   - Enriquecen al personaje

9. **Timing** (Timing)
   - El número de cuadros define la velocidad
   - Afecta la sensación de peso

10. **Exageración** (Exaggeration)
    - Más intenso que la realidad
    - Resalta el rasgo distintivo

11. **Dibujo sólido** (Solid Drawing)
    - Entender la estructura tridimensional
    - Peso y equilibrio

12. **Atractivo** (Appeal)
    - Carisma del personaje
    - Que dé ganas de verlo
```

### Flujo de producción de animación

```
Concepto → Guion → Storyboard → Diseño → Animación → Post → Entrega
                                   ↓
                          Diseño de personajes
                          Diseño de escenarios
                          Paleta de color
```

## Postproducción y edición

### Ritmo de edición

```markdown
## Principios de edición

### Corte en movimiento
- Cambia de plano durante la acción
- Mantiene la fluidez

### Corte en reposo
- Cambia durante una pausa
- Habitual en escenas de diálogo

### Regla de los 180 grados
- Conserva la posición relativa de los personajes
- Evita cruzar el eje

### J-Cut / L-Cut
- J-Cut: el audio entra antes que la imagen
- L-Cut: la imagen se mantiene después del audio
- Aumentan la fluidez
```

### Fundamentos de colorización

| Parámetro | Función | Ejemplo |
|-----------|---------|---------|
| Exposición | Brillo general | Levantar una toma subexpuesta |
| Contraste | Distancia entre luces y sombras | Ganar volumen |
| Temperatura | Frío / cálido | Cálido para calidez emocional |
| Tinte | Verde / magenta | Corrección de tonos de piel |
| Saturación | Intensidad de color | Desaturar para look cinematográfico |
| Curvas | Ajuste fino | Curva en S para más contraste |

## Herramientas recomendadas

### Equipo de captura
- **Cámaras**: Sony A7, Canon R, Fujifilm
- **Celular**: iPhone Pro, Pixel
- **Estabilizadores**: DJI RS, Zhiyun

### Software de edición
- **Profesional**: Premiere Pro, DaVinci Resolve, Final Cut
- **Ligero**: CapCut, iMovie, Filmora
- **VFX**: After Effects, Motion

### Herramientas de animación
- **2D**: Toon Boom, Clip Studio, Procreate
- **3D**: Blender, Maya, Cinema 4D
- **Motion**: After Effects, Lottie

## Recursos

- [StudioBinder](https://www.studiobinder.com/) — Formación en producción audiovisual
- [Peter McKinnon](https://www.youtube.com/@PeterMcKinnon) — Fotografía y video
- [Corridor Crew](https://www.youtube.com/@CorridorCrew) — Tutoriales de VFX
- [The Animator's Survival Kit](https://www.amazon.com/Animators-Survival-Kit-Richard-Williams/dp/0571238343)

<!-- SOURCE_FILE_END: skills/visual-media/SKILL.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/LICENSE -->
# SOURCE FILE: `skills/visual-prompt-forge/LICENSE`

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2026 Yuri Strohm / WhyStrohm

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/LICENSE -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/SKILL.md -->
# SOURCE FILE: `skills/visual-prompt-forge/SKILL.md`

---
name: visual-prompt-forge
description: Generate model-specific prompts from shots.json. Outputs copy-paste-ready prompts for stills (Midjourney, Flux, Ideogram, GPT Image, Nano Banana, Seedream) and motion video (Kling, Veo, Seedance, Hailuo). Also runs a revision mode that reads a critique.json and re-emits prompts for only the failed shots, closing the QA loop. Use when the user asks for image or video prompts, mentions any of those generators, wants AI-generated frames for a storyboard, or hands over shots.json. The prompt half of the pipeline. Composes with storyboard-architect upstream, visual-asset-critic downstream.
---

# Visual Prompt Forge

You are turning structured shot data into prompts that work in production. Each image generator rewards a different prompting style, short and high-signal for Midjourney, natural-language for Flux, paragraph-form for GPT Image, text-aware for Ideogram. A prompt that crushes in one will produce slop in another.

This skill adapts. Same shot, different syntax.

## When to use

Trigger when the user:

- Hands over a `shots.json` (or any structured shot list) and asks for prompts
- Names a specific generator (Midjourney, Flux, Ideogram, GPT Image, Nano Banana, Seedream, Kling, Veo, Seedance, Hailuo)
- Asks for "image prompts," "Midjourney prompts," "AI prompts," "generation prompts" for a storyboard
- Wants the same shot adapted to multiple generators

If the user wants to build a storyboard from scratch (no shots.json yet), use `storyboard-architect` first, then chain into this skill.

## What you produce

For a given `shots.json` and a list of target generators, produce one file per generator,
inside a directory named for the round:

```
output/prompts/round-1/
├── midjourney.txt          # If targeted
├── flux.txt
├── ideogram.txt
├── gpt-image.txt
├── nano-banana.txt
├── seedream.txt
├── kling.txt               # Motion-aware video, default
├── veo.txt                 # Motion, dialogue/lipsync + native audio
├── seedance.txt            # Motion, multi-shot sequences
└── hailuo.txt              # Motion, budget iteration
```

Round 1 is the first pass. Revision mode writes `output/prompts/round-2/`, and so on.
The round in the path is not decoration: prompt files used to be written to one fixed
path per generator, so round 2 destroyed round 1 and the prompt that actually produced
most of the surviving frames was gone.

Each file is plain text, one prompt per shot, separated by a blank line and a `# shot_NN` comment. Designed for copy-paste workflows, drop into the generator's UI or pipe into an API.

## The five-layer prompt anatomy

Every prompt is composed from these layers. Read `references/prompt-anatomy.md` for the full theory. Quick version:

1. **Brand Lock**, palette, type, mood, "never" list (constant across project)
2. **Series Lock**, character/environment/lighting anchors (constant across storyboard)
3. **Shot Spec**, framing, angle, motion, subject (per shot)
4. **Text Layer**, **never in the prompt**, composited separately
5. **Generator Adapter**, model-specific syntax wrapper

The first four come from `shots.json` and the brand-lock. The fifth is what this skill applies.

## Workflow

### Step 1. Read inputs

You need:

- `shots.json` (required), the structured shot list
- `brand-lock.snapshot.md` (required), referenced from shots.json
- Target generators (required), ask if not specified

Validate before composing:

```bash
python tools/validate_shots.py output/
```

If the brand-lock is missing or `shots.json` does not validate, stop and tell the user.
Don't try to forge prompts from incomplete data.

If `tools/` is not on hand (a Claude.ai upload, or a single-skill install), read the
schema from `../storyboard-architect/templates/shots.schema.json` and check by hand. That
relative path only resolves when the skills sit side by side; when they don't, ask the
user for the schema rather than composing from memory of it.

### Step 2. Pick the adapters

For each target generator, read the matching adapter file:

- `adapters/midjourney.md`
- `adapters/flux.md`
- `adapters/ideogram.md`
- `adapters/gpt-image.md`
- `adapters/nano-banana.md`
- `adapters/seedream.md`
- `adapters/kling.md`      (motion video, default)
- `adapters/veo.md`        (motion video, dialogue/lipsync + native audio)
- `adapters/seedance.md`   (motion video, multi-shot sequences)
- `adapters/hailuo.md`     (motion video, budget iteration)

Each adapter file documents the prompting style, parameter syntax, and known pitfalls for that generator. You **must** read the adapter before writing prompts for it. Don't guess from training data, image-gen syntax has churned multiple times.

**`adapters/_capabilities.json` is the single source of truth for per-generator limits** (`max_prompt_words`, `supports_text_render`, `supports_motion`, `aspect_param`, and so on). Read it once at the start and respect those values when composing, and do not target motion on a stills-only generator.

`max_prompt_words` is a ceiling. The range in an adapter `.md` is the recommended target
and always sits inside that ceiling, so a `.md` saying "40 to 70 words" under a ceiling of
120 is guidance, not a conflict. Where a fact in a `.md` and a fact in the JSON genuinely
disagree, **the JSON wins**.

That rule is now enforced rather than trusted. `tools/validate_capabilities.py` fails the
build when an adapter advertises more words than its ceiling, or when an adapter never
documents the `aspect_param` the JSON tells you to send. The second check exists because
nano-banana's matrix entry said `aspect_ratio` while its adapter said the API expects
`aspectRatio`; the precedence rule meant the wrong one won, silently, on every prompt.

### Step 3. Compose per shot

For each shot in `shots.json`, for each target generator:

1. Pull brand-lock palette, mood, "never" list
2. Pull series_lock character/environment/lighting
3. Pull shot framing/angle/motion/subject
4. **Strip any on_screen_text reference**, text never goes in the prompt
5. Apply the generator adapter's syntax wrapper
6. Append generator-specific parameters (aspect ratio, style flags, seed if applicable)

### Step 4. Write output files

One file per generator, into `output/prompts/round-{N}/`. Format:

```
# Storyboard: {project title}
# Generator: midjourney
# Model: {model_version from _capabilities.json}
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Run: {run_id from run.json}
# Round: 1

# shot_01, hook, 0.0-2.0s, MCU eye-level static
{the prompt}

# shot_02, pain, 2.0-6.0s, MS eye-level push
{the prompt}

...
```

The `#` lines are comments; the user copies just the prompt body. `tools/copy-prompt.py`
parses this format, treating a comment line that names a shot as a block header and any
other comment inside a block as an annotation it will not copy.

Record the run and round in the header, not a wall-clock "Generated" line. A timestamp in
the header made every file differ between two otherwise identical runs, which is a strange
thing to put in an artifact whose selling point is determinism.

### Step 4b. Append the round to run.json

After writing the files, append an entry to `run.json`'s `rounds` array: the round number,
`started_at`, a `reason`, and for each file its generator, path, SHA-256, and the shot ids
it covers.

```bash
shasum -a 256 output/prompts/round-1/*.txt
```

This is the only writeable part of `run.json`. Everything else was fixed when the
architect wrote it.

### Step 5. Hand off

Tell the user where the files are. Offer the next step:

> "Want me to QA the generated images against the storyboard? Use `visual-asset-critic` once you have the renders."

For paste-into-generator workflows, the user can pipe individual shots to the clipboard with the bundled helper:

```bash
python tools/copy-prompt.py output/prompts/round-1/midjourney.txt
python tools/copy-prompt.py output/prompts/round-2/revised-midjourney.txt --shot shot_03
```

This is optional. The `.txt` files are also directly readable, and the user can copy any block by hand. The helper exists for the case where the operator is bouncing between the terminal and a generator UI repeatedly.

## Revision mode (closing the QA loop)

This is what `visual-asset-critic`'s structured output is for. When the user hands you `shots.json` plus one or more `critique.json` files (the machine-readable verdict the critic writes), don't re-forge the whole storyboard, re-emit prompts for **only the shots that failed**, with the fix already applied.

### Trigger

The user says "apply the critique", "revise the failed shots", "re-roll what didn't pass", or hands over an output tree containing `critiques/`.

### Workflow

1. Read every critique under `output/critiques/round-{N}/`, where N is the highest round
   present. Each file is one shot's verdict (`shot_id`, `verdict`, `issues[]`).
2. Skip any with `verdict: ACCEPT`. Those are done.
3. **Stop on `REJECT`.** A REJECT means the critic found a blocking issue, or three or more
   major ones: a failure with no clear fix path. Re-emitting a prompt for it pretends
   otherwise. List the rejected shots, say what the critic said about them, and ask the
   user how to proceed. Common answers are a change to the shot spec, a change to the
   brand-lock, or a different generator, and all three are decisions above this skill's
   pay grade.
4. For every `REVISE` shot, walk its `issues[]` and branch on `fix_type`:
   - **`prompt-level`**, recompose that shot's prompt with the change in `fix` applied
     (e.g. add the missing series_lock anchor). Re-emit it.
   - **`re-roll`**, keep the prompt identical; the generation was just a bad sample.
     Re-emit it with a `# fix [Technical, re-roll]` annotation saying to take 2-3 samples
     and pick the cleanest.
   - **`post-level`**, do **not** re-emit. The fix happens in compositing, not a new
     generation.
5. A shot whose issues are all `post-level` needs no new prompt. Leave it out of the
   revised file and add its id to `post_only_shots` on the new round entry in `run.json`.
   Saying it in chat is not recording it: that obligation has to exist on disk or the
   compositing step is a memory.
6. Re-apply the five-layer anatomy and the same adapter as the original run.

### Output

Write `output/prompts/round-{N+1}/revised-{generator}.txt` containing only the revised
shots, then append the round to `run.json`. Annotate each shot with what changed and why,
citing the issue:

```
# shot_03, reframe, 11.0-16.0s, MCU eye-level push, revision (was REVISE)
# fix [Series Lock, major]: added 'salt-and-pepper hair' to the character anchor (was missing)
# fix [Shot Spec, minor]: medium shot -> medium close-up
{the revised prompt}
```

The block header leads with the shot id, same as a full pass. `tools/copy-prompt.py`
identifies a block by the shot id near the start of the line, so a header that led with
"Revision of" produced a file the paste helper could not read at all, which is
inconvenient in the one file the operator is about to paste from repeatedly.

Tell the user which shots were revised, which need only post work, which were rejected,
and which were already ACCEPT. Then they generate the revised shots and run
`visual-asset-critic` again.

### Determinism, and its limits

Given the same `shots.json`, the same brand-lock, and the same critique, this should
produce the same revised prompt. Nothing in the file format fights that any more: no
wall-clock stamps, no random ordering.

What the format cannot guarantee is the judgement in between. Applying a `fix` field means
reading a sentence of English and editing prose, so hold yourself to the narrowest edit
that satisfies the fix and leave every other layer byte-identical. If you find yourself
rewriting a prompt the critique did not ask you to touch, stop: that is drift, and it will
read as a mystery six shots later.

## Hard rules

These are non-negotiable. Violating them produces broken output even if the prompt looks fine.

### Rule 1. Text is never in the prompt

If the shot has `on_screen_text: "text_03"`, the prompt does NOT contain the text content. Text is composited separately. The only exception: Ideogram, where text-in-image is the reason you'd choose it, but even then, treat it as an explicit override flagged in rationale.

### Rule 2. Brand colors never in shot subject prose

Colors come from the series_lock color_grade and the brand_lock palette. They get rendered into the prompt by the adapter. Don't write "deep navy blazer" in the shot subject if "deep navy" is already in the palette, that's a duplicated description and produces oversaturation.

### Rule 3. Series_lock anchors are verbatim

The series_lock `environment`, `lighting`, and `color_grade` strings flow into every
prompt **verbatim**. This is what produces visual consistency across shots. If you
paraphrase or vary, shots stop matching each other.

Verbatim means the whole string, unedited. Not "the same idea in better prose". The
failure mode is specific and easy to walk into: you are writing fluent descriptive
English, `environment` is "minimalist home office, white walls, oak desk, single
houseplant", and it reads more naturally as "a minimal home office with white walls and
an oak desk". That is drift. The frames stop matching, and it stays invisible until you
line up six shots and see six different rooms.

Capitalising the first letter to start a sentence is fine, because the check is
case-insensitive. "Minimalist home office, white walls, oak desk, single houseplant."
satisfies the rule and reads like a sentence. Nothing else may change: no reordering, no
dropped clause, no synonym, no inserted adjective.

`character` is a warning rather than an error, because a shot with no person in it can
legitimately leave it out. When the shot has a person, it is verbatim too.

This rule is enforced now, not trusted:

```bash
python tools/validate_prompts.py output/
```

It exists because a careful authoring pass over a seven-shot storyboard drifted on these
anchors in all seven shots while every other validator stayed green.

### Rule 4. Adapters are the source of truth on syntax

If your training data says Midjourney uses `--style 4a` and the adapter file says `--style raw`, the adapter wins. Image-gen syntax changes monthly. The adapter is current; your training is not.

### Rule 6. Shot logic before shot poetry

A prompt can be beautifully written and still be impossible to shoot. Every prompt declares, before anything else:

- **Where the body sits in frame.** Which third it occupies. On a piece that composites two eras with a vertical mask, a body sitting on the centre line gets split in half and no amount of post fixes it. This is the single most expensive failure in the kit, and it is invisible until the mask goes on.
- **The point of view.** Profile, frontal, side, rear. "A man walking" is not a shot.
- **The direction of travel.** Left to right, right to left, toward camera. Without it the generator picks, and consecutive shots stop matching.
- **Nothing that contradicts the camera.** A subject who walks away from camera cannot also keep the same size in frame.
- **Handedness in any two-person contact.** If one raises a hand, name which one, or you get two right hands meeting.
- **No brand marks.** Logos and lettering are composited in post. Generators deform them.

### Rule 5. Prompts must be reproducible

Every prompt is composed from the same inputs the same way. If two consecutive runs produce different prompts for the same shot, the skill is broken. Determinism is the whole point.

## Reference files

- `references/prompt-anatomy.md`, the five-layer model in depth
- `references/consistency-locks.md`, how series_lock prevents shot drift
- `references/failure-modes.md`, common image-gen failures and their prompt-side fixes

## Adapters

One file per generator. Read these on demand, only for the generators being targeted.

| File | Generator | Strength |
|---|---|---|
| `adapters/midjourney.md` | Midjourney v7+ | Aesthetic, cinematic |
| `adapters/flux.md` | Flux 2 / Flux 1.1 Pro | Photorealism |
| `adapters/ideogram.md` | Ideogram v3 | Text in image (override only) |
| `adapters/gpt-image.md` | GPT Image 1.5 / 2 | Prompt accuracy, spatial reasoning |
| `adapters/nano-banana.md` | Gemini 2.5 Flash Image | Edit fidelity, inpainting |
| `adapters/seedream.md` | Seedream 4.5 | High-volume, cost-efficient |
| `adapters/kling.md` | Kling 3.0 | Motion video, default (best camera motion per dollar) |
| `adapters/veo.md` | Veo 3 | Motion video, dialogue/lipsync + native audio |
| `adapters/seedance.md` | Seedance 2.0 | Motion video, multi-shot sequences |
| `adapters/hailuo.md` | Hailuo 02 Pro | Motion video, budget iteration |

## Quality bar

Run the validator. Do not eyeball this list.

```bash
python tools/validate_prompts.py output/
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
```

`validate_prompts.py` checks the mechanical half, which is everything that used to be a
checkbox here:

- the header names the storyboard, generator, aspect, brand-lock, run, and round
- the generator is a real id in `_capabilities.json`
- the header aspect matches `project.aspect`
- no prompt exceeds that generator's `max_prompt_words` ceiling
- a full pass covers every shot; a revision file covers a subset of real shots
- no shot block is duplicated, and none has a header with no body
- **Rule 1**: no on-screen text copy appears in any prompt
- **Rule 3**: `environment`, `lighting`, and `color_grade` appear verbatim, with the
  character anchor as a warning
- **Rule 6**: every shot states which third of the frame the body occupies, its point of
  view and its direction of travel; no scale contradictions, no two people at the same
  frame edge, no unnamed handedness in a two-person contact, no brand marks in frame

What it cannot check, and you still have to:

- [ ] One output file per requested generator
- [ ] On a revision pass, the shots you left out are accounted for as ACCEPT, post-only,
      or rejected, and you said which is which
- [ ] Generator-specific parameters are right for the surface the user will paste into
- [ ] The round is appended to `run.json` with a hash per prompt file
- [ ] The prompt actually describes the shot, which is the part no validator will ever do

## Examples

`examples/one-shot-all-adapters/` contains a single shot rendered across seven adapters
side-by-side: the six stills generators plus Kling. Use it to calibrate output quality.
The three remaining motion adapters (Veo, Seedance, Hailuo) have no worked example yet;
their `.md` files carry a worked prompt each in the meantime.

For a complete two-round output tree, prompts and frames and critiques together, see
`../visual-asset-critic/examples/worked-run/`.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/SKILL.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/_capabilities.json -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/_capabilities.json`

{
  "$schema_note": "Capability matrix for visual-prompt-forge adapters. Generator models churn monthly. When you re-verify an adapter, bump its model_version and last_verified date here, then reconcile the prose adapter file. This file is the single source of truth for 'what each generator can do'; the .md files are the how-to-prompt guidance. max_prompt_words is a ceiling, not a target: an adapter .md may recommend a narrower range, but it may never advertise more than the ceiling. tools/validate_capabilities.py enforces that relationship and checks that each .md documents the aspect_param named here.",
  "version": "1.1",
  "matrix_last_reviewed": "2026-07-30",
  "generators": [
    {
      "id": "midjourney",
      "display_name": "Midjourney",
      "model_version": "v7",
      "last_verified": "2026-05-08",
      "prompt_style": "keyword",
      "max_prompt_words": 100,
      "supports_text_render": false,
      "supports_motion": false,
      "supports_character_ref": true,
      "supports_style_ref": true,
      "supports_negative_prompt": true,
      "aspect_param": "--ar",
      "api_access": "limited",
      "notes": "Short high-signal phrases. 100 words is the ceiling, past which signal drops off; the adapter recommends 40 to 80. --cref/--sref for series consistency."
    },
    {
      "id": "flux",
      "display_name": "Flux",
      "model_version": "2 Pro",
      "last_verified": "2026-05-08",
      "prompt_style": "natural",
      "max_prompt_words": 150,
      "supports_text_render": true,
      "supports_motion": false,
      "supports_character_ref": true,
      "supports_style_ref": false,
      "supports_negative_prompt": false,
      "aspect_param": "aspect_ratio",
      "api_access": "full",
      "notes": "Natural-language descriptive. Stronger text rendering than MJ but still treat on-screen copy as a separate compositing pass."
    },
    {
      "id": "ideogram",
      "display_name": "Ideogram",
      "model_version": "v3",
      "last_verified": "2026-05-08",
      "prompt_style": "natural",
      "max_prompt_words": 120,
      "supports_text_render": true,
      "supports_motion": false,
      "supports_character_ref": false,
      "supports_style_ref": true,
      "supports_negative_prompt": true,
      "aspect_param": "aspect_ratio",
      "api_access": "full",
      "notes": "Best in-class text rendering. The exception case: if a shot truly needs baked text, Ideogram is the fallback. Default is still composite-after."
    },
    {
      "id": "gpt-image",
      "display_name": "GPT Image",
      "model_version": "1.5/2",
      "last_verified": "2026-05-08",
      "prompt_style": "paragraph",
      "max_prompt_words": 300,
      "supports_text_render": true,
      "supports_motion": false,
      "supports_character_ref": true,
      "supports_style_ref": false,
      "supports_negative_prompt": false,
      "aspect_param": "size",
      "api_access": "full",
      "notes": "Paragraph-form, instruction-following. Tolerates the most context. Good for complex compositions described in sentences."
    },
    {
      "id": "nano-banana",
      "display_name": "Nano Banana (Gemini Flash Image)",
      "model_version": "Gemini 2.5 Flash Image",
      "last_verified": "2026-05-08",
      "prompt_style": "natural",
      "max_prompt_words": 120,
      "supports_text_render": true,
      "supports_motion": false,
      "supports_character_ref": true,
      "supports_style_ref": true,
      "supports_negative_prompt": false,
      "aspect_param": "aspectRatio",
      "api_access": "full",
      "notes": "Fast, cheap, strong editing/consistency via reference images. Good for high-volume iteration. Parameter name is camelCase here, unlike the fal.ai models; it ignores --ar."
    },
    {
      "id": "seedream",
      "display_name": "Seedream",
      "model_version": "4.5",
      "last_verified": "2026-05-08",
      "prompt_style": "natural",
      "max_prompt_words": 120,
      "supports_text_render": true,
      "supports_motion": false,
      "supports_character_ref": true,
      "supports_style_ref": true,
      "supports_negative_prompt": true,
      "aspect_param": "aspect_ratio",
      "api_access": "full",
      "notes": "Strong photoreal and bilingual text. Competitive on character consistency."
    },
    {
      "id": "kling",
      "display_name": "Kling 3.0",
      "model_version": "3.0",
      "last_verified": "2026-06-18",
      "prompt_style": "natural",
      "max_prompt_words": 150,
      "supports_text_render": false,
      "supports_motion": true,
      "supports_character_ref": true,
      "supports_style_ref": false,
      "supports_negative_prompt": true,
      "aspect_param": "aspect_ratio",
      "api_access": "full",
      "notes": "Default motion model. Best camera-motion realism per dollar on fal.ai, strongest image-to-video (start/tail frame). 5s or 10s. Reach for this first; escalate only for what it cannot do."
    },
    {
      "id": "veo",
      "display_name": "Veo 3",
      "model_version": "3",
      "last_verified": "2026-06-18",
      "prompt_style": "natural",
      "max_prompt_words": 150,
      "supports_text_render": false,
      "supports_motion": true,
      "supports_character_ref": true,
      "supports_style_ref": false,
      "supports_negative_prompt": false,
      "aspect_param": "aspect_ratio",
      "api_access": "full",
      "notes": "Dialogue and lipsync. Only adapter that generates synchronised native audio in the same pass. Strongest prompt adherence and physics; highest cost. ~8s. Spoken lines go in the prompt; on-screen text still does not."
    },
    {
      "id": "seedance",
      "display_name": "Seedance 2.0",
      "model_version": "2.0",
      "last_verified": "2026-06-18",
      "prompt_style": "natural",
      "max_prompt_words": 150,
      "supports_text_render": false,
      "supports_motion": true,
      "supports_character_ref": true,
      "supports_style_ref": false,
      "supports_negative_prompt": false,
      "aspect_param": "aspect_ratio",
      "api_access": "full",
      "notes": "Multi-shot sequences in a single generation with subject consistency across cuts. Use when consecutive beats share one subject and should feel like one take. Up to ~4 cuts per generation."
    },
    {
      "id": "hailuo",
      "display_name": "Hailuo 02 Pro",
      "model_version": "02 Pro",
      "last_verified": "2026-06-18",
      "prompt_style": "natural",
      "max_prompt_words": 120,
      "supports_text_render": false,
      "supports_motion": true,
      "supports_character_ref": true,
      "supports_style_ref": false,
      "supports_negative_prompt": false,
      "aspect_param": "aspect_ratio",
      "api_access": "full",
      "notes": "Budget, fast iteration. Use to block out camera move, framing, and timing across cheap drafts, then re-roll the keeper on Kling, Veo, or Seedance. Draft tier, not finals."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/_capabilities.json -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/capabilities.schema.json -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/capabilities.schema.json`

{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://whystrohm.com/schemas/shotkit/capabilities.schema.json",
  "title": "Generator Capabilities",
  "description": "Capability matrix for visual-prompt-forge adapters. The single source of truth for per-generator limits (prompt length, text/motion support, aspect param). Adapter .md files describe how to prompt; this file owns the numbers.",
  "type": "object",
  "required": ["version", "matrix_last_reviewed", "generators"],
  "additionalProperties": false,
  "properties": {
    "$schema_note": { "type": "string" },
    "version": { "type": "string" },
    "matrix_last_reviewed": {
      "type": "string",
      "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}$",
      "description": "ISO date the whole matrix was last reviewed."
    },
    "generators": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "id", "display_name", "model_version", "last_verified",
          "prompt_style", "max_prompt_words",
          "supports_text_render", "supports_motion",
          "supports_character_ref", "supports_style_ref", "supports_negative_prompt",
          "aspect_param", "api_access"
        ],
        "additionalProperties": false,
        "properties": {
          "id": {
            "type": "string",
            "pattern": "^[a-z0-9][a-z0-9-]*$",
            "description": "Must match an adapter .md filename (without extension)."
          },
          "display_name": { "type": "string", "minLength": 1 },
          "model_version": { "type": "string", "minLength": 1 },
          "last_verified": {
            "type": "string",
            "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}$"
          },
          "prompt_style": {
            "type": "string",
            "enum": ["keyword", "natural", "paragraph"]
          },
          "max_prompt_words": { "type": "integer", "exclusiveMinimum": 0 },
          "supports_text_render": { "type": "boolean" },
          "supports_motion": { "type": "boolean" },
          "supports_character_ref": { "type": "boolean" },
          "supports_style_ref": { "type": "boolean" },
          "supports_negative_prompt": { "type": "boolean" },
          "aspect_param": { "type": "string", "minLength": 1 },
          "api_access": {
            "type": "string",
            "enum": ["full", "limited", "none"]
          },
          "notes": { "type": "string" }
        }
      }
    }
  }
}

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/capabilities.schema.json -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/flux.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/flux.md`

# Adapter: Flux (Flux 2 Pro / Flux 1.1 Pro / Flux Dev)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Flux rewards natural-language prompts that read like a competent photographer briefing themselves. It interprets full sentences accurately and handles spatial relationships better than Midjourney. It's the photorealism leader as of Q2 2026, choose Flux over Midjourney when the brief calls for "looks like a real photograph" rather than "looks designed."

## Syntax pattern

```
{One or two natural-language sentences describing the subject and action}. {Sentence describing environment and lighting}. {Sentence describing technical/photographic specs}. {Brand mood line.}
```

Periods separate beats. Each sentence does one job. No bracket weights, no `--` flags. Flux is parameterless on most APIs (fal.ai, Replicate, BFL direct).

## Where parameters go

Flux parameters are typically passed alongside the prompt, not inside it:

| Parameter | Where | Default |
|---|---|---|
| `aspect_ratio` | API call field | from `project.aspect` |
| `output_format` | API call field | `png` for compositing |
| `safety_tolerance` | API call field | `2` (default) |
| `prompt_upsampling` | API call field | `false` for series work, auto-rewrites kill consistency |
| `seed` | API call field | set per-storyboard for series consistency |

In the `flux.txt` output, document parameters as a comment line above each prompt:

```
# shot_01, params: ar=9:16, seed=2840193, upsampling=false
{prompt}
```

## Length

Flux handles **80–150 words** comfortably. Don't pad, but you have headroom Midjourney doesn't.

## Composition mapping

Translate shot grammar into descriptive language:

| shot_grammar | Flux phrasing |
|---|---|
| `MCU eye-level` | `Medium close-up framing, camera at eye level.` |
| `WS overhead` | `Wide overhead shot, looking straight down.` |
| `push` | `Camera pushing slowly toward the subject.` |
| `handheld` | `Handheld camera with slight natural movement.` |
| `shallow DOF` | `Shot at f/1.8 with shallow depth of field, background softly out of focus.` |
| `deep DOF` | `Shot at f/8, everything in sharp focus front to back.` |

## Photographic specifics

Flux rewards camera/lens vocabulary. Add when relevant:

- `Shot on Hasselblad, 80mm lens, f/2.8`
- `Sony FX6, 35mm prime, natural light only`
- `Documentary 16mm film aesthetic, slight grain`
- `Editorial fashion lighting, large softbox key`

## Composition pattern

```
{Framing description with character anchor and action}. {Environment description from series_lock}. {Lighting sentence from series_lock}. {Photographic spec, camera, lens, depth of field}. {Color grade and mood from brand_lock}. Photorealistic, natural skin texture, no AI artifacts.
```

The closing "Photorealistic, natural skin texture, no AI artifacts" line meaningfully reduces the AI-look in Flux output. Include in every prompt.

## Example

**Same shot data as Midjourney example.**

**Output prompt:**
```
Medium shot of a founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck, leaning forward at his laptop with his face partially turned toward window light. Composition leaves negative space on the right side of the frame. The setting is a minimalist home office with white walls and an oak desk. Soft natural side-light from a large window on the left, warm afternoon golden hour. Shot on a 50mm prime at f/2.0, shallow depth of field. Warm filmic color grade with muted teal shadows. Calm, considered mood, operator, not creator. Photorealistic, natural skin texture, no AI artifacts.
```

## Flux variant selection

| Variant | When | Cost ratio |
|---|---|---|
| Flux 2 Pro | Hero shots, final assets | 1× (highest) |
| Flux 1.1 Pro | Series work, balanced | ~0.6× |
| Flux Schnell | Quick iteration, drafts | ~0.1× |
| Flux Dev | Self-hosted, scale | ~0× per image, GPU cost |

Default to Flux 2 Pro for storyboard previews. The `flux.txt` file works for any variant, same prompt syntax.

## Pitfalls to avoid

- **Don't write "highly detailed, 4k, masterpiece"**, these are Stable Diffusion crutches. Flux ignores them and the line burns tokens
- **Don't use weight syntax `(thing:1.4)`**. Flux 2 doesn't support it; Flux 1.1 partially does. Stick to natural language
- **Don't enable prompt upsampling for series work**, fal.ai's auto-rewrite produces inconsistent shots
- **Don't include text content**, even if Flux 2 handles text better than Flux 1.1, composite separately for editability
- **Don't omit the photoreal closing line**, the "no AI artifacts" anchor measurably reduces the AI-look

## API access

Flux has multiple API surfaces:

- **fal.ai**, fastest, most stable, supports all variants
- **Replicate**, broader model selection, slightly slower
- **BFL direct API**, official, requires their key
- **WaveSpeedAI**, unified interface across many models

Same prompt syntax across all four. The `flux.txt` file is portable.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/flux.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/gpt-image.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/gpt-image.md`

# Adapter: GPT Image (1.5 / 2)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

GPT Image rewards paragraph-form prompts with explicit spatial reasoning and complex composition descriptions. It interprets relational language ("to the left of", "behind", "in the foreground") more accurately than any other generator. Choose GPT Image when the brief requires precise scene composition, multiple objects, or accurate text rendering.

## Syntax pattern

```
{Paragraph 1: subject, action, spatial composition}

{Paragraph 2: environment and contextual details}

{Paragraph 3: lighting, photographic specs, mood}
```

Paragraph breaks help GPT Image parse separate beats. One long monolithic paragraph underperforms, the model loses track of which detail applies where.

## Parameters

GPT Image is API-driven through OpenAI:

| Parameter | Default for storyboard work | Notes |
|---|---|---|
| `size` | `1024x1792` for 9:16, `1792x1024` for 16:9, `1024x1024` for 1:1 | Native aspect ratios |
| `quality` | `high` for hero shots, `medium` for series | |
| `style` | `natural` for photoreal, `vivid` for stylized | |
| `model` | `gpt-image-1.5` (or `gpt-image-2` if available) | |

Document in comment:
```
# shot_01, params: size=1024x1792, quality=high, style=natural, model=gpt-image-1.5
{prompt}
```

## Length

GPT Image handles **150–300 words** comfortably. Longer than other generators. Use the headroom for explicit spatial descriptions.

## Spatial language strength

GPT Image's distinctive capability, describe spatial relationships explicitly:

- "The founder is positioned in the left third of the frame, leaving the right two-thirds open."
- "A laptop sits on the desk in the foreground, a window with afternoon light is visible in the background."
- "The subject's shoulders are angled 30 degrees toward the camera, face turned to look at the off-frame light source."

Use this when the shot's composition is load-bearing.

## Composition pattern

```
{Subject paragraph: who is in the frame, what they're doing, where they are positioned in the composition. Reference series_lock character anchor verbatim.}

{Environment paragraph: setting, props, contextual elements. Pull from series_lock environment.}

{Technical paragraph: lighting from series_lock, photographic spec, color grade from brand_lock, mood. Close with "natural skin texture, no AI rendering artifacts" if photoreal.}
```

## Example

**Same shot data as previous examples.**

**Output prompt:**
```
A founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck sweater, leans forward at his laptop. He is positioned in the left third of the frame, his face turned partially toward the window light off-camera left. The composition deliberately reserves the right two-thirds of the frame as negative space.

The setting is a minimalist home office. White walls, an oak desk in the immediate foreground, the laptop screen partially visible. A large window is implied off-frame to the left, source of the natural light. No clutter, no decorative objects.

Soft natural side-light from the window left, warm afternoon golden hour temperature, gentle shadow rolloff. Shot on a 50mm prime lens at f/2.0, shallow depth of field with the background softly out of focus. Warm filmic color grade with muted teal shadows. The mood is calm and considered, operator energy, not creator energy. Natural skin texture, no AI rendering artifacts.
```

## Text rendering

GPT Image handles text-in-image at roughly 95% accuracy, second only to Ideogram. When text is required:

- Put the exact text in straight double-quotes within the prompt
- Specify position explicitly ("centered in the lower third")
- Specify approximate typeface character ("bold sans-serif", "elegant serif")
- Limit to one text element per prompt for reliability

Default for storyboard work is still composited text, keep the override flag pattern from the Ideogram adapter.

## Pitfalls to avoid

- **Don't write Midjourney-style comma stacks**. GPT Image parses them as a list of disconnected concepts
- **Don't omit spatial language when the shot has specific composition**, you're paying for the model's strength; use it
- **Don't pile too many objects**, five or fewer distinct elements per scene; more degrades fidelity
- **Don't include `--ar` flags or weight syntax**. GPT Image ignores them
- **Don't forget that GPT Image's "AI look" is real**, the closing "natural skin texture, no AI rendering artifacts" line meaningfully helps but isn't a complete fix. For pure photoreal, Flux is still stronger

## API access

GPT Image is OpenAI-only as of Q2 2026. Standard `images.generate` endpoint. Pricing roughly $0.04–0.08 per image depending on size and quality. ChatGPT Plus and above gives UI access.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/gpt-image.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/hailuo.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/hailuo.md`

# Adapter: Hailuo 02 Pro (motion-aware video, budget iteration)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Hailuo 02 Pro is the cheap, fast iteration model. Strong motion response and prompt-following for the price, on fal.ai. Use it to **find the shot**, block out camera move, framing, and timing across many quick drafts, then re-generate the keeper on Kling (motion finals), Veo (dialogue), or Seedance (sequences). Treat Hailuo output as a working draft, not a final asset.

With video the **camera motion is load-bearing**. The prompt anatomy matches Kling; the difference is cost and intent: iterate freely here.

## Syntax pattern

```
{Camera motion sentence, leading.} {Subject and action over the duration.} {Environment and lighting from series_lock.} {Color grade and mood from brand_lock.}
```

## Parameters

| Parameter | Default | Notes |
|---|---|---|
| `duration` | `6s` | Check the current fal.ai ceiling for the Pro tier |
| `aspect_ratio` | from `project.aspect` | |
| `start_image` | optional | Image-to-video from an accepted still |
| `prompt_optimizer` | `false` for series | Auto-rewrite helps one-offs but breaks shot-to-shot consistency |

```
# shot_01 (draft). Hailuo 02 Pro: duration=6s, ar=9:16, optimizer=false
{prompt}
```

## Length

Hailuo handles **60–120 words** efficiently. Shorter than Kling/Veo. Keep drafts lean, you are testing motion and framing, not final polish.

## Motion vocabulary

The shot grammar `motion` field maps directly. One move per shot.

| `motion` | Video prompt phrase |
|---|---|
| `static` | "Static camera, locked off." |
| `push` / `pull` | "Camera dollies forward / backward slowly." |
| `pan-left` / `pan-right` | "Camera pans smoothly left / right." |
| `tilt-up` / `tilt-down` | "Camera tilts up / down." |
| `handheld` | "Handheld camera, subtle organic movement." |
| `orbit` | "Camera orbits the subject slowly." |
| `whip` | "Fast whip pan with motion blur." |
| `rack` | "Rack focus from foreground to background." |

## Iteration workflow

1. Draft the shot on Hailuo with `prompt_optimizer=false`. Cheap, fast.
2. Lock the camera move, framing, and timing that read best.
3. Re-generate the keeper on the right final-tier model: **Kling** for motion finals, **Veo** for dialogue/lipsync, **Seedance** for multi-shot sequences.
4. Carry the exact prompt forward, the adapters share the same five-layer anatomy, so the prompt body ports with only parameter changes.

## Example

**Draft of the `motion = "push"` shot.**

```
Camera dollies forward slowly at a steady pace. A founder in his mid-thirties with salt-and-pepper hair in a navy crewneck sits at his laptop in a minimalist home office and leans slightly forward toward window light off-camera left. Soft natural side-light, warm afternoon. Warm filmic color grade, muted teal shadows. Calm operator mood.
```

## Pitfalls to avoid

- **Don't ship Hailuo drafts as finals.** Re-roll the keeper on a final-tier model.
- **Don't enable the prompt optimizer for series work.** Auto-rewrite breaks shot-to-shot consistency.
- **Don't stack two camera moves.** One move per shot.
- **Don't include text content.** Composite captions in post.
- **Don't over-polish the draft prompt.** Spend words on motion and framing; save the photographic detail for the final-tier re-roll.

## Output handoff

Hailuo output is a draft used to choose the shot. The deliverable comes from the final-tier re-roll. If a Hailuo take is genuinely good enough to keep, treat it like any other clip: editorial assembly, text-overlay compositing, color grade, audio.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/hailuo.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/ideogram.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/ideogram.md`

# Adapter: Ideogram (v3)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Ideogram is the only generator that reliably renders text inside images. Use it for cases where text-as-image is the deliverable, posters, branded social tiles, signage, packaging mockups. For everything else, default to Flux or Midjourney and composite text separately.

This adapter has **two modes**: composited (default) and text-in-image (override).

## Mode 1: Composited (default)

Same as Flux, generate the image clean, composite text in post. Use when Ideogram is being chosen for general image quality, not text rendering. Syntax matches Flux conventions.

## Mode 2: Text-in-image (override)

Use when the on-screen text is meant to appear as part of the image itself, a poster headline, a sign in the scene, a packaging label. This is the only case where a generator prompt contains the text content.

**To trigger Mode 2, the shot must have an explicit override flag in rationale**, e.g.:
```
"rationale": "Text-in-image override: poster shot, headline must render as part of composition"
```

If you don't see that override flag, default to Mode 1.

## Syntax pattern (Mode 2)

```
{Subject and composition}. {Environment and lighting}. The text "{exact text}" appears {position description}, in {font style description}. {Brand mood and color closing.}
```

The exact text must be in straight double-quotes. Ideogram parses these as the text-render target.

## Parameters

| Parameter | Where | Default |
|---|---|---|
| `aspect_ratio` | API field | from `project.aspect` |
| `model` | API field | `V_3` |
| `magic_prompt` | API field | `OFF` for series work, kills consistency |
| `style_type` | API field | `DESIGN` for posters, `REALISTIC` for scenes |
| `seed` | API field | set per-storyboard |

Document in comment block:
```
# shot_01, params: ar=9:16, model=V_3, magic_prompt=OFF, style=DESIGN, seed=2840193
{prompt}
```

## Length

Ideogram handles **60–120 words** comfortably. Text-bearing prompts run shorter still:
the more scene description you stack around a text instruction, the more likely the
render drops or garbles the copy.

## Composition pattern (Mode 1, composited)

Same as Flux pattern, no text in prompt:

```
{Framing description with character and action}. {Environment from series_lock}. {Lighting from series_lock}. {Photographic spec}. {Brand mood and color}. Clean composition with negative space for text overlay placement.
```

## Composition pattern (Mode 2, text-in-image)

```
{Subject/composition sentence}. {Environment/lighting sentence}. The text "{exact content}" appears {center / top-third / bottom-third / etc.}, in {font style, bold sans-serif / elegant serif / handwritten script / etc.}, color {hex or named color from brand-lock}. {Brand mood closing}.
```

## Example (Mode 2)

**Shot:** poster-style hero frame, brand launch
**Brand-lock:** display font is `Inter Black`, headline color `#0F1F3A` on `#F5F0E8` cream background
**Text content:** `built different`

**Output prompt:**
```
Editorial poster composition, dense cream background, single bold composition. Minimalist studio environment, even diffused lighting. The text "built different" appears center of the frame, in heavy sans-serif typography (Inter Black style), color deep navy #0F1F3A on cream #F5F0E8 background. Calm, considered, operator brand mood, confident without shouting.
```

## When NOT to use Ideogram

- **Photorealistic scenes with people**. Flux is better
- **Cinematic mood/aesthetic**. Midjourney is better
- **Product photography**. Flux 2 Pro is better
- **Series work where consistency matters**. Midjourney with `--cref` or Flux with seed-locking handles consistency better

Ideogram's specialty is text. If the brief doesn't need text-in-image, picking Ideogram is choosing the wrong tool.

## Pitfalls to avoid

- **Don't use Mode 2 without the rationale override**, defaults to text-in-image cause double-text (composited + generated) which destroys the comp
- **Don't trust magic_prompt**, it auto-rewrites and produces inconsistent shots across a series
- **Don't pile multiple text elements in one prompt**. Ideogram handles one text element well, two becomes lottery, three is broken
- **Don't use cursive/decorative fonts**, even Ideogram fails on these. Sans-serif and clean serif are reliable
- **Don't forget seed**, for any series work, lock the seed at the storyboard level

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/ideogram.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/kling.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/kling.md`

# Adapter: Kling 3.0 (motion-aware video)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Kling 3.0 generates short video clips, not still frames. It is the default motion model: the best camera-motion realism per dollar on fal.ai, and the strongest image-to-video of the four. Reach for it first. Escalate to Veo (dialogue/lipsync), Seedance (multi-shot), or Hailuo (cheap iteration) only when the shot needs what Kling does not do.

With video the **camera motion becomes load-bearing** instead of optional. The same shot generates differently when `motion` is `static` versus `push` versus `handheld`. Use this adapter when the storyboard is destined for video generation rather than still-frame compositing.

## Syntax pattern

```
{Camera motion sentence, explicit, leading.} {Subject and action over the duration.} {Environment and lighting from series_lock.} {Photographic spec.} {Color grade and mood from brand_lock.}
```

Camera motion goes **first**. This is the inverse of image generators where camera is implied. With video the camera's behaviour is the first thing the model must understand.

## Parameters

| Parameter | Default | Notes |
|---|---|---|
| `duration` | `5s` for shots, `10s` for hero | 5s and 10s are the supported lengths |
| `aspect_ratio` | from `project.aspect` | |
| `cfg_scale` | `0.5` | Lower = looser/more dynamic, higher = closer to prompt |
| `start_image` | optional | Image-to-video. Pass an accepted still from `shots.json` assets to lock the opening frame |
| `tail_image` | optional | End-frame target for controlled moves |
| `negative_prompt` | per series | Supported. Use to suppress drift, e.g. `extra fingers, warped face` |

Document parameters as a comment line above each prompt:

```
# shot_01. Kling 3.0: duration=5s, ar=9:16, cfg=0.5, start_image=frames/round-1/shot_01.png
{prompt}
```

## Length

Kling handles **80–150 words** comfortably. Motion description adds a beat over a still prompt; do not pad past it.

## Motion vocabulary

The shot grammar `motion` field maps directly. One move per shot.

| `motion` | Video prompt phrase |
|---|---|
| `static` | "Static camera, locked off." |
| `push` | "Camera dollies forward slowly at a steady pace." |
| `pull` | "Camera dollies backward, pulling away from the subject." |
| `pan-left` / `pan-right` | "Camera pans smoothly to the left / right." |
| `tilt-up` / `tilt-down` | "Camera tilts upward / downward." |
| `handheld` | "Handheld camera, subtle organic movement, documentary feel." |
| `orbit` | "Camera orbits the subject in a slow circle." |
| `whip` | "Fast whip pan with motion blur." |
| `rack` | "Rack focus shifts from foreground to background mid-shot." |

## Subject motion

Beyond the camera, describe what the subject does over the duration:

> "Over the course of the shot the founder leans slightly forward and turns his face toward the window light off-camera left."

Static composition is not enough for video. This is what separates a video prompt from an image prompt.

## Example

**Same shot data as the image-adapter examples, with `motion = "push"`.**

```
Camera dollies forward slowly into the scene at a steady pace. A founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck, sits at his laptop in a minimalist home office; over the shot he leans slightly forward and his face turns toward window light off-camera left, holding negative space on the right of frame throughout. Soft natural side-light from a large window, warm afternoon golden hour. Shot on a 50mm prime equivalent, shallow depth of field. Warm filmic color grade with muted teal shadows. Calm, considered, operator mood.
```

## Continuity across shots

- Use `start_image` from the previous shot's accepted final frame to chain a sequence.
- Repeat the series_lock character anchor verbatim in every prompt.
- Do not flip lighting direction between consecutive shots (window-left stays window-left).
- Even with start-frame locking, each clip is a fresh generation. Plan for an editorial pass.

## Pitfalls to avoid

- **Don't put camera motion at the end.** Kling parses motion best as the leading instruction.
- **Don't request multiple camera moves in one shot.** Pick one; compound moves break.
- **Don't describe motion faster than the duration allows.** A slow dolly over 5s is plausible; over 1s it is jitter.
- **Don't include text content.** Video text rendering is unreliable; composite or animate text in post.
- **Don't expect frame-perfect character match between clips.** Budget editorial cleanup.

## Output handoff

Generated clips are raw material, not deliverable. After generation they still need: editorial assembly to storyboard timing, text-overlay compositing from `text-overlays.json`, a color-grade pass, and audio (VO, music, sound design). Say this in handoff.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/kling.md -->
