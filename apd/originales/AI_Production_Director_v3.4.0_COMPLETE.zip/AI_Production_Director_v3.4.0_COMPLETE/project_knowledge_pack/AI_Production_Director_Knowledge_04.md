# AI Production Director — Knowledge Pack 4/7

Generated from `aiproductiondirectorcompleto.zip`.
Each source file is preserved with its original relative path.


<!-- SOURCE_FILE_START: repo/public/index.html -->
# SOURCE FILE: `repo/public/index.html`

<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{color-scheme:light dark}
html,body{margin:0}
body{font:14px/1.5 system-ui,sans-serif;background:#F2F4F7}
img{max-width:100%}
[hidden]{display:none!important}
</style>
</head>
<body>
<title>Ejecutor de Producción</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Condensed:wght@500;600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap">
<style>
:root{
  --bg:#F2F4F7;--surf:#FFFFFF;--ink:#161A20;--mute:#5C6674;--line:#D6DBE3;--soft:#E9EDF2;
  --acc:#D9541E;--acc-ink:#FFFFFF;--ok:#1F8A4C;--warn:#B7791F;--bad:#C0392B;--info:#2F6FBF;
  --ok-bg:#E4F3EA;--warn-bg:#FBF1DC;--bad-bg:#F9E3E0;--info-bg:#E3ECF9;
  --disp:"IBM Plex Sans Condensed","Arial Narrow",sans-serif;
  --body:"IBM Plex Sans",system-ui,sans-serif;
  --mono:"IBM Plex Mono",ui-monospace,Menlo,monospace;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --bg:#121519;--surf:#1A1E24;--ink:#E8EAED;--mute:#9AA3AF;--line:#2B313A;--soft:#232930;
  --acc:#F0703A;--acc-ink:#15100D;--ok:#4CC37A;--warn:#E0A83C;--bad:#EF6B5E;--info:#6FA3F0;
  --ok-bg:#16301F;--warn-bg:#352A12;--bad-bg:#3A1C19;--info-bg:#16263D;}}
:root[data-theme="dark"]{
  --bg:#121519;--surf:#1A1E24;--ink:#E8EAED;--mute:#9AA3AF;--line:#2B313A;--soft:#232930;
  --acc:#F0703A;--acc-ink:#15100D;--ok:#4CC37A;--warn:#E0A83C;--bad:#EF6B5E;--info:#6FA3F0;
  --ok-bg:#16301F;--warn-bg:#352A12;--bad-bg:#3A1C19;--info-bg:#16263D;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 var(--body)}
h1,h2,h3{font-family:var(--disp);font-weight:600;letter-spacing:.01em;margin:0;text-wrap:balance}
h1{font-size:20px}h2{font-size:17px}h3{font-size:15px}
p{margin:0}
a{color:var(--info)}
button{font:inherit;cursor:pointer;border:1px solid var(--line);background:var(--surf);color:var(--ink);border-radius:6px;padding:7px 12px}
button:hover{border-color:var(--mute)}
button:focus-visible,textarea:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
button:disabled{opacity:.5;cursor:default}
button.prim{background:var(--acc);color:var(--acc-ink);border-color:var(--acc);font-weight:600}
button.sm{padding:4px 9px;font-size:12.5px}
button.link{border:0;background:none;color:var(--info);padding:0}
textarea,input[type=text],input[type=url],select{font:inherit;color:var(--ink);background:var(--surf);border:1px solid var(--line);border-radius:6px;padding:8px 10px;width:100%}
textarea{min-height:120px;resize:vertical;line-height:1.5}
input[type=file]{font:inherit;color:var(--mute)}
.lbl{font-family:var(--disp);font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--mute);font-weight:600}
.mono{font-family:var(--mono);font-size:12.5px}
.mute{color:var(--mute)}
.app{display:grid;grid-template-columns:250px 1fr;min-height:100vh}
.rail{border-right:1px solid var(--line);background:var(--surf);padding:16px 14px;display:flex;flex-direction:column;gap:14px}
.rail .brand{display:flex;align-items:baseline;gap:8px}
.rail .brand small{color:var(--mute);font-family:var(--mono);font-size:11px}
.plist{display:flex;flex-direction:column;gap:2px;overflow:auto;max-height:50vh}
.plist button{text-align:left;border:0;padding:7px 9px;border-radius:5px;display:flex;flex-direction:column;gap:2px}
.plist button.act{background:var(--soft)}
.plist button small{color:var(--mute);font-size:11.5px;font-family:var(--mono)}
.plist button b{font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:210px}
.tabs{display:flex;flex-direction:column;gap:2px}
.tabs button{text-align:left;border:0;padding:7px 9px;border-radius:5px;display:flex;justify-content:space-between;align-items:center}
.tabs button.act{background:var(--ink);color:var(--bg)}
.tabs button span.n{font-family:var(--mono);font-size:11px;opacity:.75}
.main{padding:22px 28px 60px;max-width:980px;width:100%}
.hd{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;margin-bottom:16px;flex-wrap:wrap}
.hd .sub{color:var(--mute);margin-top:2px}
.card{background:var(--surf);border:1px solid var(--line);border-radius:8px;padding:16px 18px;display:flex;flex-direction:column;gap:12px}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.stack{display:flex;flex-direction:column;gap:12px}
.pill{display:inline-flex;align-items:center;gap:6px;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:500;border:1px solid var(--line);background:var(--soft)}
.pill.ok{background:var(--ok-bg);color:var(--ok);border-color:transparent}
.pill.warn{background:var(--warn-bg);color:var(--warn);border-color:transparent}
.pill.bad{background:var(--bad-bg);color:var(--bad);border-color:transparent}
.pill.info{background:var(--info-bg);color:var(--info);border-color:transparent}
.pill.acc{background:var(--acc);color:var(--acc-ink);border-color:transparent}
.etapa{display:grid;grid-template-columns:6px 1fr;border:1px solid var(--line);border-radius:8px;background:var(--surf);overflow:hidden}
.etapa .stripe{background:var(--line)}
.etapa.gen .stripe,.etapa.aud .stripe{background:var(--info)}
.etapa.rech .stripe,.etapa.agot .stripe{background:var(--bad)}
.etapa.espera .stripe{background:var(--warn)}
.etapa.aprob .stripe{background:var(--ok)}
.etapa .body{padding:14px 18px;display:flex;flex-direction:column;gap:10px}
.etapa .top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap}
.etapa .meta{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.crit{margin:0;padding-left:18px;color:var(--mute)}
.crit li{margin:2px 0}
.out{border-top:1px solid var(--line);padding-top:10px}
.md{line-height:1.55;max-width:72ch}
.md h1,.md h2,.md h3{margin:12px 0 6px}
.md h1{font-size:17px}.md h2{font-size:15.5px}.md h3{font-size:14px}
.md p{margin:6px 0}
.md ul,.md ol{margin:6px 0;padding-left:22px}
.md pre{background:var(--soft);border:1px solid var(--line);border-radius:6px;padding:10px 12px;overflow-x:auto;font-family:var(--mono);font-size:12.5px;line-height:1.5;white-space:pre-wrap;margin:8px 0}
.md code{font-family:var(--mono);font-size:12.5px;background:var(--soft);padding:1px 4px;border-radius:3px}
.md pre code{background:none;padding:0}
.md table{border-collapse:collapse;margin:6px 0;font-size:13px}
.md th,.md td{border:1px solid var(--line);padding:4px 8px;vertical-align:top}
.log{border:1px solid var(--line);border-radius:6px;overflow:hidden;font-size:13px}
.log .r{display:grid;grid-template-columns:82px 1fr;border-top:1px solid var(--line)}
.log .r:first-child{border-top:0}
.log .r>div{padding:6px 10px}
.log .r>div:first-child{background:var(--soft);font-family:var(--mono);font-size:12px;color:var(--mute)}
.falla{padding:6px 0;border-top:1px dashed var(--line)}
.falla:first-child{border-top:0}
.falla b{font-family:var(--mono);font-weight:500;font-size:12px}
.falla .ev{color:var(--mute);font-style:italic}
.status{display:flex;align-items:center;gap:8px;color:var(--mute);font-size:13px}
.spin{width:12px;height:12px;border:2px solid var(--line);border-top-color:var(--acc);border-radius:50%;animation:sp .8s linear infinite;flex:none}
@keyframes sp{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){.spin{animation:none}}
.thumbs{display:flex;gap:8px;flex-wrap:wrap}
.thumbs img{height:72px;border-radius:4px;border:1px solid var(--line)}
.gens{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}
.gens button{padding:0;overflow:hidden;text-align:left;display:flex;flex-direction:column}
.gens img{width:100%;aspect-ratio:16/9;object-fit:cover;display:block}
.gens small{padding:4px 7px;color:var(--mute);font-family:var(--mono);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.gens button.act{outline:2px solid var(--acc)}
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;font-family:var(--disp);font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--mute);padding:6px 8px;border-bottom:1px solid var(--line)}
.tbl td{padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
.score{font-family:var(--disp);font-size:34px;font-weight:600;line-height:1;font-variant-numeric:tabular-nums}
.empty{color:var(--mute);padding:30px 0;text-align:center}
.warnbox{background:var(--warn-bg);color:var(--warn);border-radius:6px;padding:8px 12px;font-size:13px}
.badbox{background:var(--bad-bg);color:var(--bad);border-radius:6px;padding:8px 12px;font-size:13px}
.infobox{background:var(--info-bg);color:var(--info);border-radius:6px;padding:8px 12px;font-size:13px}
details>summary{cursor:pointer;color:var(--mute);font-size:13px}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:6px;overflow:hidden}
.seg button{border:0;border-radius:0;border-right:1px solid var(--line)}
.seg button:last-child{border-right:0}
.seg button.act{background:var(--ink);color:var(--bg)}
.chk{display:flex;gap:8px;align-items:center}
.plan-et{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:start;padding:10px 0;border-top:1px solid var(--line)}
.plan-et:first-child{border-top:0}
.plan-et .k{font-family:var(--mono);font-size:12px;color:var(--mute);padding-top:2px;min-width:110px}
@media (max-width:820px){.app{grid-template-columns:1fr}.rail{border-right:0;border-bottom:1px solid var(--line)}.grid2{grid-template-columns:1fr}.main{padding:16px}}
</style>

<div class="app">
  <aside class="rail">
    <div class="brand"><h1>Ejecutor</h1><small id="ver"></small></div>
    <button class="prim" id="btnNuevo">Nuevo brief</button>
    <div class="lbl">Proyectos</div>
    <div class="plist" id="plist"></div>
    <div class="lbl">Módulos</div>
    <nav class="tabs" id="tabs">
      <button data-v="brief">Brief</button>
      <button data-v="plan">Plan <span class="n" id="nPlan"></span></button>
      <button data-v="run">Ejecución <span class="n" id="nRun"></span></button>
      <button data-v="eval">Evaluador</button>
      <button data-v="ajustes">Ajustes</button>
    </nav>
    <div class="mute" style="font-size:12px;margin-top:auto" id="capline">Conectando…</div>
  </aside>
  <main class="main" id="main"></main>
</div>

<script>
const D = {"etapas":[{"clave":"E0","nombre":"Brand Lock","cond":"solo si hay marca o cliente","casos":["MARCA"],"tracks":["STANDARD","FILM"],"ok":true,"entra":"Sitio web, brand book, screenshots o descripción","sale":"brand-lock.md — 9 secciones, cada valor con fuente y confianza","gate":"El usuario confirma los valores flagged como estimados. Sin marca formal, usa el Visual Theme de la Etapa 3 como sustituto ligero."},{"clave":"E1","nombre":"Creative Strategy","cond":"","casos":["GUION"],"tracks":["STANDARD","FILM"],"ok":true,"entra":"Brand lock + brief","sale":"Territorios explorados, 3–5 concept cards, matriz de selección y dirección narrativa del concepto ganador","gate":"El usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto."},{"clave":"E2","nombre":"Screenwriting","cond":"","casos":["GUION"],"tracks":["STANDARD","FILM"],"ok":true,"entra":"Concept card ganadora + dirección narrativa","sale":"Treatment (solo FILM) → script con escenas XML-tagged, sluglines, acción y diálogo","gate":"Cada escena pasa la fórmula de escena (deseo + obstáculo + geometría + mirada + ritmo) y la three-jobs rule: cambia emoción, avanza acción o sube presión. La que no hace ninguna se corta aquí, no en el shot list."},{"clave":"E3","nombre":"Cinematic Direction","cond":"","casos":["CLIP","SHOT"],"tracks":["STANDARD","FILM"],"ok":false,"entra":"Script","sale":"Documento de dirección por escena: blocking, composición, cámara motivada, lente, luz, evolución de color, lenguaje de edición y los 5 anclas de la pieza","gate":"Cero palabras del vocabulario prohibido. Cada decisión de cámara tiene razón dramática escrita."},{"clave":"E4","nombre":"Shot Planning","cond":"punto de entrada del track EXPRESS","casos":["SHOT"],"tracks":["EXPRESS","STANDARD","FILM"],"ok":true,"entra":"Script + documento de dirección (EXPRESS: solo el brief)","sale":"storyboard.md · shots.json · text-overlays.json — shots.json es la fuente de verdad; ningún prompt existe sin shot ID","gate":"Six-point dramaturgy check + auditoría de 3 detalles por shot (presión ambiental, micro-acción física, ancla de sonido). Un shot con cero detalles es filler y se elimina."},{"clave":"E5","nombre":"Anchor Images","cond":"","casos":["T1","T2","T3","T4","T5","PROD","GRAF","MULTI","REF","QA"],"tracks":["EXPRESS","STANDARD","FILM"],"ok":false,"entra":"shots.json + brand-lock","sale":"Plan de anchors (character refs, environment refs, keyframes por shot clave) y prompts finales de imagen por anchor","gate":"Cada anchor crítico pasa la crítica. Máximo 2 rondas de revisión; a la tercera falla se replantea el shot, no el prompt."},{"clave":"E6","nombre":"Video Prompts","cond":"","casos":["CLIP"],"tracks":["EXPRESS","STANDARD","FILM"],"ok":false,"entra":"shots.json + anchor aprobado","sale":"Prompts de video finales por shot, con continuity blocks entre clips","gate":"Dramaturgy check de 6 puntos + auditoría de 3 detalles. Un prompt que falla cualquiera NO se entrega."},{"clave":"E7","nombre":"Package & Delivery","cond":"","casos":["ENTREGA"],"tracks":["STANDARD","FILM"],"ok":false,"entra":"Todos los artefactos de las etapas anteriores","sale":"Final AI Video Production Package + checklist de postproducción","gate":"Checklist maestro completo y trazabilidad verificada: 3 prompts al azar trazan hasta su concepto. Si un eslabón falta, no se entrega."},{"clave":"PROMPT_IMAGEN","nombre":"Prompt de imagen","cond":"brief de una sola imagen","casos":["T1","T2","T3","T4","T5","PROD","GRAF","MULTI"],"tracks":[],"ok":false,"entra":"El brief (y referencias, si hay)","sale":"Cabecera de 3 líneas SKILL:/RIESGOS:/TÉCNICA:, modelo recomendado y el prompt final en inglés en un bloque de código","gate":"Cumple todas las reglas del caso elegido. Sin vocabulario prohibido."},{"clave":"PROMPT_VIDEO","nombre":"Prompt de video","cond":"brief de un solo clip","casos":["CLIP"],"tracks":[],"ok":false,"entra":"El brief (y referencias, si hay)","sale":"Cabecera de 3 líneas, modelo recomendado y el prompt final en inglés en un bloque de código","gate":"Dramaturgy check de 6 puntos + 3 detalles. Sin vocabulario prohibido."},{"clave":"REF","nombre":"Referencia a prompt","cond":"hay imagen de referencia y se pide recrearla","casos":["REF"],"tracks":[],"ok":false,"entra":"Imagen de referencia adjunta","sale":"Descomposición de la referencia (sujeto, luz, lente, color, composición) y el prompt para recrearla en inglés en un bloque de código","gate":"Cada elemento visible de la referencia está en el prompt; nada inventado."},{"clave":"ESTRATEGIA","nombre":"Estrategia","cond":"el brief pide una estrategia o plan, no una pieza visual","casos":[],"tracks":[],"ok":true,"entra":"El brief","sale":"Documento estratégico: diagnóstico, opciones, recomendación y plan de acción con siguientes pasos","gate":"Responde exactamente lo que pide el brief. Cada recomendación tiene razón y siguiente paso concreto."},{"clave":"DOC","nombre":"Documento","cond":"cualquier otro entregable de texto","casos":[],"tracks":[],"ok":false,"entra":"El brief y lo aprobado antes","sale":"El documento que pide el brief","gate":"Cumple cada criterio del plan."}],"tracks":{"EXPRESS":"≤30s, un beat (hook→payoff). Entra en E4 y salta E0–E3 y E7.","STANDARD":"30–90s, arco simple. E0–E7 con E1 comprimida (2–3 conceptos) y E2 sin treatment.","FILM":"90s–10min, multi-escena. E0–E7 completas, todos los gates."},"casos":{"T1":"maestro de rostro (still, persona, identidad)","T2":"maestro de cuerpo (still, persona completa)","T3":"cuadro con 1 persona (still de escena)","T4":"cuadro con 2 personas (still, contacto/interaccion)","T5":"edicion quirurgica sobre imagen existente","CLIP":"prompt de video / movimiento","SHOT":"planeacion de shots, storyboard, shots.json","GUION":"escritura de guion o tratamiento","MARCA":"extraccion o uso de brand-lock","QA":"critica de render, revision de asset generado","ENTREGA":"empaquetado, preview, entrega a cliente","PROD":"still de producto, comida u objeto (sin persona)","GRAF":"pieza grafica: poster, slide, UI, social, tipografia dominante","MULTI":"multi-panel o grid dentro de una sola imagen","REF":"analisis de imagen de referencia, image-to-prompt","NINGUNO":"no aplica a ningun caso de produccion (meta, ejemplos, docs)"},"porCaso":{"T1":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","f5bdd52eae18","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","09ec7d23fe12","b921448eda9a","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","f7781b9ee5c2","31a9f9f11aa7","a8c47d2e697e","b5749680d5b1","e849bbafb08a","608c66f4b15a","639574d396e1","be07ac1a9f48","bc5138b583ba","ee853dd503fd","ce04a04c45aa","97ef5791058f","e85f3a2c01a5","e200695107d8","bdc7c98423b2","e80f84e82cd7","2260c15e96b4","36bbbe701ad0","5b0ec72c5a49","9a20603f7d87","29940f3cd9ae","f708635c6957","b8ecc6c820c5","25c7ab649b75","b6f22ea21acd","be5a2e46231a","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5a5348b20c81","5cf46d07bcac","b6df20344be1","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","bbcf9882e50b","05f30ccb87c3","c1d814f8c059","d0476aaa14d5","edb34335baee","24d0e917035e","4e37b6108b10","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"T2":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","f5bdd52eae18","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","09ec7d23fe12","b921448eda9a","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","f7781b9ee5c2","31a9f9f11aa7","a8c47d2e697e","b5749680d5b1","e849bbafb08a","608c66f4b15a","639574d396e1","be07ac1a9f48","bc5138b583ba","ee853dd503fd","ce04a04c45aa","97ef5791058f","e85f3a2c01a5","e200695107d8","9b5c3232e804","348b0b1ed027","1bf69ac8c5e3","eb03e137df6e","c5971eabbb4b","6dfcd0919723","ce24e75d12a1","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5cf46d07bcac","b6df20344be1","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","bbcf9882e50b","05f30ccb87c3","c1d814f8c059","d0476aaa14d5","24d0e917035e","4e37b6108b10","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"T3":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","f5bdd52eae18","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","09ec7d23fe12","b921448eda9a","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","ce04a04c45aa","97ef5791058f","e85f3a2c01a5","e200695107d8","9b5c3232e804","348b0b1ed027","1bf69ac8c5e3","eb03e137df6e","c5971eabbb4b","6dfcd0919723","ce24e75d12a1","bdc7c98423b2","e80f84e82cd7","2260c15e96b4","36bbbe701ad0","5b0ec72c5a49","9a20603f7d87","29940f3cd9ae","f708635c6957","b8ecc6c820c5","25c7ab649b75","b6f22ea21acd","be5a2e46231a","44c898225d80","4c1d2cabad77","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5cf46d07bcac","613774db48c2","204113433c22","4d4ea0758b3f","b6df20344be1","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","bbcf9882e50b","05f30ccb87c3","c1d814f8c059","d0476aaa14d5","36f326b4fa1b","b1bf8c0bd438","24d0e917035e","4e37b6108b10","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"T4":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","09ec7d23fe12","b921448eda9a","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5cf46d07bcac","613774db48c2","204113433c22","4d4ea0758b3f","b6df20344be1","7dc14c265b1a","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","bbcf9882e50b","05f30ccb87c3","c1d814f8c059","d0476aaa14d5","24d0e917035e","4e37b6108b10","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"T5":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","67a7dd9329dc","26e0c5fc6ab4","762ce60bec5e","cb50b580f819","ff510d7ca127","4fcb4afa54c3","3f9822c97a3a","a509f495c750","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5cf46d07bcac","4d4ea0758b3f","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","c1d814f8c059","24d0e917035e","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"CLIP":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","3fb8782f57b8","b2a93a3b39b9","2dddf6f48ba3","3f921ee68519","82d4b1aa2d36","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","2d5d435df3ef","f21bcfe2dfbc","99b3186877c9","54b8e873fa4e","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","4ddd5b7aae62","1df0239fdbc2","87d2484dd6cf","1863ac937570","d98803cf48d0","8f83dc97e5ba","8ea66f62d954","13635ca633f1","508966ae84b9","7dabe8b7b479","b755a79d8702","2d6cacf87d0d","c485717d92a0","f1cf3ccb4d13","a7febb0fdf00","61f2696d823a","179286c8c088","c16f3957c655","a82de4fa4979","d85e439effb2","0809eafc4ffb","bb25b6a212a2","71e86bdfe510","a4313d46162b","9e30b0899784","7d81fcd5ccc0","21472873e0ca","c9b8d9532823","4286109b9522","8b8795ac59fd","eeae0374284b","5c7946d7fd9f","15b3f8595289","7a47e689454a","d94be792c74d","0db6e0a2de52","1e5d66901508","36686df1386d","7d3ab7f4ba2a","cf73cec68544","85c33c12c479","4b9361768f1a","f876e8f2e5cb","5a27254127bb","5465eb46d054","240a672f7a78","5eaea7d005f0","4c683ca1e1ef","fae5c2bff912","de49559afcec","94114b6c3c86","dc069aea561b","3c3a35bd5003","fe2010e7cd1e","5090be9f2dcb","f4e68628a21b","1a73cf483aab","8acb235535b4","9d8033a7fcbb","58c03455aad2","7e710b7de286","2976ffd881f1","83694d17ac4b","4340f22ac789","b93895a69273","e56653bec670","809f55027421","8870a91220dc","5e9381b1532d","8dd832a85896","324bcf02f62b","3cc2915d07c9","f0315e2411a6","ed4fbf774ee8","7887bf99374c","dbf4503191cb","884b4b40911e","877300b2ba56","3b48069bb705","6eafd4ebaa95","0395ddb6bd06","73905921cedf","a78b8143dfae","809fb4ebddce","659a2eb38201","ae09790a4e9b","e30cec365a82","2d5229cb5344","c6a20928bc70","d629ec5811b5","e57740e558ac","80e69a894fcc","a75221469baa","71fec8821328","6b50e2278180","f1f0fcdff995","27ee9fc25b00","f4c2c207fbb8","e7caec8627aa","dd071e4f1adc","1eff4afae0c5","90c9d01c7da9","3da18291f908","01e778de1f4c","d9efc3ad4bfb","a4cd347f4b1e","e24b10c311e9","9373adbe6c11","adbe90385564","75ec08f6c7e0","6f2d9a2fd7ba","e2b9c51c5ef7","f7ff7d98a4a9","51c07299485c","2e0a56484152","21023b368ec1","d1794addd647","0196c3f7220c","da70b123efd4","e21763705dd8","dfcbb6dd0684","a45ee38936f8","01a57763de37","1c400db686fb","402a936cf3fe","1a0831f5ce00","eb02f32299e5","fe59b8611a5b","4a161f379427","53a3fb486be4","0a4395028757","375413fbe1a3","658b20f679d9","ce8831e8984c","68f234798bd5","87680002b885","097929817bc7","79369bcf16d4","3dde58c707c6","60f13533c38e","c04789da6e17","f136c00c3d59","f44cf9ff7226","5598ee94689f","ab3cc98cbe7f","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","a5926981e848","c52dc68d0daf","34c9774072b9","a96d5275630a","c05a37e6c694","dd11b5da1036","1e43dbde9ec3","5996725c4119","28b092664be0","9d51ba168710","07771e486a77","cee8c4cd6183","e84b5c0448b9","750cf06a6b5c","c962c96606da","0acb882ac4aa","561e4601866e","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","22f6035ce704","32344b412ad5","e67edc98e31f","5e8113658ff6","7e40e9d57114","5acc0a53e64b","8499e1ad407c","8a7cde5fbf44","1740a84f47a3","6c398f45603b","6c97051eb055","e7f6806c93e3","35389a2e7e9a","993e2cd1eec5","40867e840a40","e620d729b974","0678f6cbf749","5d267e42e94d","18b6449fb38c","bbcf9882e50b","05f30ccb87c3","00552d374a9c","47dd1d977a21","a2680889ec7c","5e64b7c7d357","1f3f073247b7","11ae3ea96fb0","611f323d3615","ca87c9bb0cd3","be25e9cc99a1","fc4a79f80ec2","7a8e1fc6b5e6","9bf2cbf9c271","0e9bacb2e8ad","98ee930c9f7c","2be4bcd05090","8a862f876fa8","f79825c8bfa6","784a21fb3fba","c50591694f2a","5f835d0eb35a","a433636c2657","2d91bbc13caa","f5ef9ac105ef","19ef2dbc9666","de0ddf9ca295","54d1d74f3df8","1948fb0cd2ea","cedacf95ce49","5c79b70fbb5a","e47d5852520a","d92564e28fe4","9570d85c5b8a","85f471342e23","a84829cef94a","c8f9182dab48","b9c780304835","c3c3d1047037","31550b84c066","c1d814f8c059","8cb896ae3ca7","24d0e917035e","4755505de7d6","3d67beea0470","98d91e461feb","1087e186fed5","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"SHOT":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","1f8ed1aa2f82","976919fb7afd","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","f999ef3808aa","c9068adfe734","3244bb3011e7","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","f876e8f2e5cb","5a27254127bb","5465eb46d054","240a672f7a78","5eaea7d005f0","4c683ca1e1ef","fae5c2bff912","de49559afcec","94114b6c3c86","1eff4afae0c5","90c9d01c7da9","3da18291f908","01e778de1f4c","d9efc3ad4bfb","a4cd347f4b1e","e24b10c311e9","9373adbe6c11","adbe90385564","75ec08f6c7e0","6f2d9a2fd7ba","e2b9c51c5ef7","f7ff7d98a4a9","51c07299485c","2e0a56484152","21023b368ec1","d1794addd647","0196c3f7220c","da70b123efd4","e21763705dd8","dcba7967bb86","34d356cca129","06f7cfabe30d","f02d8dcae6c2","9a04fd13f520","d58376dbc7f5","33379bbc4b87","8a33756b8cb8","3172bdb34a71","47f320764950","eb02f32299e5","fe59b8611a5b","4a161f379427","53a3fb486be4","0a4395028757","375413fbe1a3","658b20f679d9","ce8831e8984c","68f234798bd5","87680002b885","097929817bc7","79369bcf16d4","3dde58c707c6","60f13533c38e","c04789da6e17","f136c00c3d59","f44cf9ff7226","5598ee94689f","ab3cc98cbe7f","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","364c86aacbd6","7696a03e6c31","8f9cad0e2224","0a6768420027","0b4182e7f0fc","37204f4e9d9d","abc02ebdb6a8","38de07452a46","16f6bf46f67c","4c1f6d0ef267","7e5f2e473cd3","f32c786bfbff","d329c7d38124","b55cf418fc3a","e5235864c6bb","0206d6df0cc3","9b3fba335e1b","e4b20db35b44","cfaecb7f5fa7","39b17554140c","ec4f8b7428c7","3bdf77c5a1e7","6154ed831bf3","6be1e3549be6","ca19a04f7f16","e707043ad741","61117f1e1435","bcd48bb1ab67","409a346f14c6","e4456cb5dc55","86733dae8e0e","4b795000d239","a68a06f84fe6","0357fe063806","08af446ba369","428f5eebff7b","a268ba75d0b5","efdeec778e0f","90221fe5fe0f","48c59084ee78","9f529931cccc","c1fb4192e05a","84655e935767","84f1791a022e","67f2beaeb3ef","4ff066eab26b","7a7cb7a4a5e8","9f4f78bc99a2","717463d29f8f","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","22f6035ce704","32344b412ad5","e67edc98e31f","5e8113658ff6","7e40e9d57114","5acc0a53e64b","8499e1ad407c","8a7cde5fbf44","1740a84f47a3","6c398f45603b","6c97051eb055","e7f6806c93e3","35389a2e7e9a","993e2cd1eec5","40867e840a40","e620d729b974","0678f6cbf749","5d267e42e94d","18b6449fb38c","8d21f65f4329","c7861b2bb543","8b27a216f395","5b7b1c8fb6ae","bbcf9882e50b","5942ba44f22f","1cec4673e7f2","85e3ed23b8ae","05f30ccb87c3","4cbacbc0b8fa","d7940c08b552","00552d374a9c","47dd1d977a21","a2680889ec7c","5e64b7c7d357","1f3f073247b7","11ae3ea96fb0","611f323d3615","ca87c9bb0cd3","be25e9cc99a1","fc4a79f80ec2","7a8e1fc6b5e6","9bf2cbf9c271","0e9bacb2e8ad","98ee930c9f7c","2be4bcd05090","8a862f876fa8","f79825c8bfa6","784a21fb3fba","c50591694f2a","5f835d0eb35a","a433636c2657","2d91bbc13caa","f5ef9ac105ef","19ef2dbc9666","de0ddf9ca295","54d1d74f3df8","1948fb0cd2ea","cedacf95ce49","5c79b70fbb5a","e47d5852520a","d92564e28fe4","9570d85c5b8a","85f471342e23","a84829cef94a","c8f9182dab48","b9c780304835","c3c3d1047037","31550b84c066","c1d814f8c059","79f9fd6178a0","024638f7f93d","2306baa11deb","8cb896ae3ca7","24d0e917035e"],"GUION":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","1f8ed1aa2f82","976919fb7afd","36dd5696e226","201666abd399","476511682f20","240748ade236","8c97f2430a2a","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","fb3896038afa","4d9355018ad2","57e9c487ac74","fa0199539554","e10b5f7be709","45f2e43f67e0","a93dbeef8737","10e5da2fcf9a","59d398f4c454","671c49de0056","27e302d3a37e","5645bf344589","68d5f2185557","c775d8acd13e","8cc0ef448f33","bff5030b3380","35abb8abc912","df9b899dbc91","de28e225dfa5","aa1edc03619b","0cf150e839a8","b6cf18f1ea26","f1221744d7a1","42187af933ee","38b4028efe2f","5ea772208440","3697579b1689","dcba7967bb86","34d356cca129","06f7cfabe30d","f02d8dcae6c2","9a04fd13f520","d58376dbc7f5","33379bbc4b87","8a33756b8cb8","3172bdb34a71","47f320764950","7e5f2e473cd3","f32c786bfbff","d329c7d38124","b55cf418fc3a","e5235864c6bb","0206d6df0cc3","9b3fba335e1b","e4b20db35b44","cfaecb7f5fa7","39b17554140c","ec4f8b7428c7","3bdf77c5a1e7","6154ed831bf3","6be1e3549be6","ca19a04f7f16","e707043ad741","61117f1e1435","bcd48bb1ab67","409a346f14c6","e4456cb5dc55","86733dae8e0e","4b795000d239","a68a06f84fe6","0357fe063806","08af446ba369"],"MARCA":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","ebc1422e5d22","fcc9a56efa31","96e709999be1","5fe217339055","0dae3fdc0ace","39e68cb30388","c183542f6090","6257a4f1fd42","89c96fc0932b","ddd43db015c9","4075284680a4","086086b8d7f3","c9c3a9312a4c","cd4c7a7c3646","49fd83a4b509","afdb75007c72","6eb4f8ba4dbc","03ede5f175d7","3d50d9dc8cee","2b77fe0ab77d","528f3aca58d3","34f304b45ae2","70f50258fc9f","a61acb519eac","39f21f0bd621","bdeeca395947","21f3127a222e","289646ec1639","5108ce119398","98944bc5d597","5e5cfb4ec221","cc15db8a3ce1","f861a19be4ca","42b960dda0f5","e320951a2f69","deff6acf6ba6","995266039bd6","9c0afb7d325a","00c5d773e8d3","a9ed618bb40b","2d715d9073e7","b5797c1841f0","fb243b53c635","daf6cf4dbcb9","d446778cd38a","b4fbf43a4a92","04363c882bf7","a69c36bdec51","a1ad2f291171","775e72423ee9","3f18cfa9b5e8","a86e2eb18131","451be222e3f4","f419380942de","dd519aa232b4","5a0a397f54c1","f3fad8754516","147b5d10f118","e3d69437c2f6","ff2826465af1","bd1590a213fe","2ef7c79850da","5d8f1227d198","c2fbf1d46956","a3fa0f352d46","c1ee0d0b5a80","650d25a8d091","5cff35ce456c","e49a82b5336a","3e5b03db5bd2","ab8ee2cc3cfb","3f9aad2c4e2c","db7addc154a9","df43eb92b1b2","c5e62839e1ee","2f545717c91e","e03457ae7069","25f0ecf00da8","1acd5803bd0f","3214012dc24d","250eda4c5849","5ada3d9e3057","25d9cd499896","e815875bfd9e","dd6e8d6008ac","333c20110ff3","5aecc4ca21d4","dac6a52ee58c","c95b248c14c2","c906d8795790","ba0238372a4c","03c4f6662db6","91020f8aff04","26257934361a","65805ba83e7e","19abf8cb5067","d81969febc9e","e1559d443197","f380cff82f61","e10409cde634","5c3ec0c8cf75","fef9fe44ef96","4590b5aee804","d40b84764301","478143da99e2","1bbba41d8f5e","1249aae4215a","621b3df6eb6a","d9e264405291","64c7eedde7cc","38c7b73cec5b","4b55ac47f0e7","ff35cc7d69fd","995296a29fb4","db692e54505e","5e4a95ec4d8c","929d3e62f0b7","c5761942f155","f28e4507d045","3751f321730f","9132e55fcf5d","0f628683c6b8","eff9c8392083","b700cf8f4dcb","45e257d77c42","ddb048e79808","eb006504840c","783ff683393c","8cea74bc14b1","f6abdd226436","d8a47abf50ca","e9560a0de1ac","cc0c55fe6755","c1a8c5479b88","8d21f65f4329","c7861b2bb543","8b27a216f395","5b7b1c8fb6ae","1cec4673e7f2","05f30ccb87c3","4cbacbc0b8fa","d7940c08b552","0aebfb67e4fd","edb34335baee","36f326b4fa1b","6fcfbe5ad699","cf3ce4e1adaf","b1bf8c0bd438","2306baa11deb","8cb896ae3ca7","24d0e917035e"],"QA":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","1dc7c87def16","c8195d96aaff","3236a31aecea","4254cbeb01a9","4dabd7bdc618","7eac9caa0ac8","c24705b39ede","fd33b1fe4a83","583d5f400a46","0cde22e1a93c","5b837820df26","a221a716e952","65ab63f3291c","c7b95c733b7f","1e898f2c0308","31afcb61a699","788f1a8f5595","8014a721e61b","9b616f961fba","b1bf47b129ef","0aebfb67e4fd","79f9fd6178a0","024638f7f93d","d0476aaa14d5"],"ENTREGA":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","1f8ed1aa2f82","976919fb7afd","2c2da899a44d","eee77c7d576a","0574ba956e73","69545d03256e","9848dbda5e26","f999ef3808aa","8c97f2430a2a","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","44283e478fd4","090ccfb96455","629bb2d205d3","b9f0e777f95a","09e4367e3b97","8a2c11a5fc35","410599a6e6d1","e3ddb1d823f5","32701372f5d1","6975e2ff7171","77570da551dd","d86f1629a7f6","90b1a187484f","9f76efb872f5"],"PROD":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","8901152207fe","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","5856058c8a75","84828d3c69a2","a90636943228","8005da81a345","c3d4dd460549","19234ef99d6a","6a46a42327af","9a00a07b257d","09817e522cce","d1f50fd09fa8","6fc560223ecb","bf758f621b50","46ce53039819","a9c702b552f4","d4f497bb93d1","4c926ca35845","df532917ca8c","a30c3b235f2e","de44302b8294","d62c529d34db","afdcc8f7bc89","4f23b10353c9","20bb122f18fb","1ba1ff7577c8","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","5cf46d07bcac","613774db48c2","204113433c22","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","00552d374a9c","47dd1d977a21","a2680889ec7c","5e64b7c7d357","1f3f073247b7","11ae3ea96fb0","611f323d3615","ca87c9bb0cd3","be25e9cc99a1","fc4a79f80ec2","7a8e1fc6b5e6","9bf2cbf9c271","0e9bacb2e8ad","98ee930c9f7c","2be4bcd05090","8a862f876fa8","f79825c8bfa6","784a21fb3fba","c50591694f2a","5f835d0eb35a","a433636c2657","2d91bbc13caa","f5ef9ac105ef","19ef2dbc9666","de0ddf9ca295","54d1d74f3df8","1948fb0cd2ea"],"GRAF":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","20e10fa23ffc","3de5ceee5c4e","5856058c8a75","84828d3c69a2","a90636943228","8005da81a345","9b5c3232e804","348b0b1ed027","1bf69ac8c5e3","eb03e137df6e","c5971eabbb4b","6dfcd0919723","ce24e75d12a1","5c934f24e5bd","535d74d81a91","7b6acbb90a0a","57fca5220269","c755ff2903b8","cd1fa75558c5","803245de38c4","b6a40416c21b","44c898225d80","4c1d2cabad77","7a21ad4f3c7d","be784fefef07","f5f07232cc75","ac9f15b7d326","76fa850073b5","d4e8f76bb757","b1a90c3a0a1d","8f24d3e22d84","6b8e9a41cbf9","5bb61a5742b2","e3ff88ae7b6f","796d88912233","2f0619f0ec28","8e32b234137b","7447d548b9f0","0db1539c575d","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","613774db48c2","204113433c22","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","428f5eebff7b","a268ba75d0b5","efdeec778e0f","90221fe5fe0f","48c59084ee78","9f529931cccc","c1fb4192e05a","84655e935767","84f1791a022e","67f2beaeb3ef","4ff066eab26b","7a7cb7a4a5e8","9f4f78bc99a2","717463d29f8f","5942ba44f22f","1cec4673e7f2","85e3ed23b8ae","4cbacbc0b8fa","d7940c08b552","024638f7f93d","6fcfbe5ad699","cf3ce4e1adaf","2306baa11deb","226a236b4dcc","4755505de7d6","88ac8d8506e0","73aaed94b890","83c574fc9ce5","e0e022e50a9e","3d67beea0470","98d91e461feb","1087e186fed5"],"MULTI":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","20e10fa23ffc","5856058c8a75","84828d3c69a2","a90636943228","8005da81a345","f7781b9ee5c2","31a9f9f11aa7","a8c47d2e697e","b5749680d5b1","e849bbafb08a","608c66f4b15a","639574d396e1","be07ac1a9f48","bc5138b583ba","ee853dd503fd","afdcc8f7bc89","4f23b10353c9","20bb122f18fb","1ba1ff7577c8","ce04a04c45aa","97ef5791058f","e85f3a2c01a5","e200695107d8","44c898225d80","4c1d2cabad77","c842524ed79f","a127cca4810d","e01904554508","3d26f71cccce","52c7e13d4185","796a278bda86","3a5fb89a88b1","7421490e82fa","576f2ecf7dd2","5eca40f8b2dc","e25ece2ca897","0237812f9545","79ad480edaab","921aa8a23672","d9727650ad44","90d4b17bba47","910dd4553129","d8c349628ad4","1e4fc13d2d29","a0be4760c51c","1062c830e923","eb71e5086205","bf6161618f55","f6982091002c","c9068adfe734","3244bb3011e7","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","c8f9182dab48"],"REF":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","7e22722f52fa","442a75c51f58","a712726b25c7","04cb7f3e5408","7d2338d1b298","3d2a2115477d","7cf887e9d7c2","526a0bad384e","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad"]},"idx":{"1f8ed1aa2f82":{"s":"ai-production-director","a":"SKILL.md","l":16,"t":"**Clasificar** el proyecto y elegir el track correcto.","o":"regla"},"976919fb7afd":{"s":"ai-production-director","a":"SKILL.md","l":17,"t":"**Secuenciar** las etapas y cargar la sub-skill correcta en cada una.","o":"regla"},"8a2a24e72003":{"s":"ai-production-director","a":"SKILL.md","l":18,"t":"**Custodiar los gates**: ninguna etapa arranca sin que la anterior pase su quality gate.","o":"regla"},"c83679230b88":{"s":"ai-production-director","a":"SKILL.md","l":19,"t":"**Resolver conflictos** entre sub-skills con las reglas de la sección 6 — las decidiste una vez, no se renegocian por proyecto.","o":"regla"},"2c2da899a44d":{"s":"ai-production-director","a":"SKILL.md","l":20,"t":"**Mantener trazabilidad**: todo artefacto downstream traza a un shot ID, todo shot traza a una escena, toda escena al concepto aprobado.","o":"regla"},"4ca2dc8c76f1":{"s":"ai-production-director","a":"SKILL.md","l":65,"t":"Cada etapa declara: sub-skill, entradas, salidas, y gate. El gate se verifica ANTES de avanzar. Si falla, se corrige en la etapa actual — nunca se \"arregla después\".","o":"regla"},"36dd5696e226":{"s":"ai-production-director","a":"SKILL.md","l":75,"t":"**Gate:** el usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto.","o":"regla"},"043b9dc0b02e":{"s":"ai-production-director","a":"SKILL.md","l":85,"t":"**Gate:** cero palabras del vocabulario prohibido (sección 6.1). Cada decisión de cámara tiene razón dramática escrita.","o":"regla"},"3fb8782f57b8":{"s":"ai-production-director","a":"SKILL.md","l":101,"t":"**Gate obligatorio:** los dos checks de `video` (dramaturgy check de 6 puntos + auditoría de 3 detalles) Y, si `aurora-prompt-linter` está instalada, el linter pasa limpio. Un prompt que falla cualquiera de los dos NO se entrega.","o":"regla"},"5673820bc473":{"s":"ai-production-director","a":"SKILL.md","l":112,"t":"Nunca preguntes lo que el brief o los artefactos previos ya responden.","o":"regla"},"f556f97c9939":{"s":"ai-production-director","a":"SKILL.md","l":123,"t":"El vocabulario prohibido de `video`/dramaturgy (+ `aurora-prompt-linter` si está) **gana siempre**: \"cinematic\", \"epic\", \"stunning\", \"masterpiece\", \"beautiful lighting\", \"professional\", \"high quality\", emociones nombradas sin cuerpo. Esto **anula explícitamente** la regla de `ai-video-storyboard` de cerrar cada prompt con \"cinematic 1080p, synchronized audio\". En su lugar: la resolución, aspect ra","o":"regla"},"4c5ba2b2ce9e":{"s":"ai-production-director","a":"SKILL.md","l":129,"t":"De la Etapa 4 en adelante: `shots.json`. Un cambio creativo se hace primero en shots.json y se propaga hacia abajo; nunca se parcha un prompt de forma que contradiga su shot.","o":"regla"},"1cf2b2af3609":{"s":"ai-production-director","a":"SKILL.md","l":132,"t":"`visual-prompt-forge` es dueño del **flujo de datos** (shots.json → borrador, critique.json → revisión selectiva). `video`/`image` smixs son dueños del **texto final** del prompt. El borrador del forge se reescribe a sintaxis smixs; nunca al revés.","o":"regla"},"b2a93a3b39b9":{"s":"ai-production-director","a":"SKILL.md","l":141,"t":"**Proyectos de animación** (2D/3D/motion graphics): es la única skill instalada con los 12 principios de Disney y el flujo de producción de animación. En un proyecto animado, su sección de animación se suma a la Etapa 3 como referencia de performance y timing.","o":"regla"},"201666abd399":{"s":"ai-production-director","a":"SKILL.md","l":150,"t":"`references/creative-strategy.md` — Protocolo completo de la Etapa 1: territorios, big ideas, concept cards, matriz de selección, dirección narrativa. Léelo SIEMPRE al ejecutar la Etapa 1.","o":"regla"},"0574ba956e73":{"s":"ai-production-director","a":"SKILL.md","l":151,"t":"`references/production-package.md` — Spec del Final AI Video Production Package, reglas de trazabilidad y checklist maestro. Léelo SIEMPRE al ejecutar la Etapa 7.","o":"regla"},"476511682f20":{"s":"ai-production-director","a":"references/creative-strategy.md","l":17,"t":"Si el single-minded proposition no se puede escribir en una frase, la Etapa 1 no puede continuar. Resuélvelo con el usuario primero.","o":"regla"},"240748ade236":{"s":"ai-production-director","a":"references/creative-strategy.md","l":37,"t":"De los territorios más fuertes, baja 3–5 conceptos (FILM) o 2–3 (STANDARD). Cada concepto es UNA película posible, no una variación de la anterior. Formato obligatorio:","o":"regla"},"eee77c7d576a":{"s":"ai-production-director","a":"references/production-package.md","l":44,"t":"Todo prompt (imagen o video) lleva en comentario su `shot_id`.","o":"regla"},"f999ef3808aa":{"s":"ai-production-director","a":"references/production-package.md","l":45,"t":"Todo shot en shots.json referencia su escena del script (`scene` field o nota).","o":"regla"},"8c97f2430a2a":{"s":"ai-production-director","a":"references/production-package.md","l":46,"t":"El script referencia la concept card ganadora en su encabezado.","o":"regla"},"ed8f12484923":{"s":"ai-production-director","a":"references/production-package.md","l":47,"t":"Cambios: si un prompt necesita cambiar algo que su shot fija (encuadre, acción, luz), el cambio se hace en shots.json y se regenera hacia abajo. El paquete nunca contiene un prompt que contradiga su shot.","o":"regla"},"69545d03256e":{"s":"ai-production-director","a":"references/production-package.md","l":48,"t":"Verificación de cierre: muestrea 3 prompts al azar y traza la cadena prompt → shot → escena → concepto. Si un eslabón falta, el paquete no se entrega.","o":"regla"},"9848dbda5e26":{"s":"ai-production-director","a":"references/production-package.md","l":70,"t":"[ ] Dirección cinematográfica sin vocabulario prohibido","o":"regla"},"eb02f32299e5":{"s":"ai-video-storyboard","a":"SKILL.md","l":12,"t":"**Core insight:** Visual consistency across shots matters more than any single shot being perfect. A mediocre but consistent set of shots edits together; six gorgeous but mismatched shots do not.","o":"archivo"},"fe59b8611a5b":{"s":"ai-video-storyboard","a":"SKILL.md","l":32,"t":"**Goal platform and duration?** (TikTok 30s / Reel 15-60s / YouTube Short / Instagram Ad / explainer)","o":"archivo"},"4a161f379427":{"s":"ai-video-storyboard","a":"SKILL.md","l":33,"t":"**What is the video about?** (subject, story, product)","o":"archivo"},"53a3fb486be4":{"s":"ai-video-storyboard","a":"SKILL.md","l":34,"t":"**Brand vibe / tone?** (cozy, energetic, premium, minimalist, playful, cinematic, etc.)","o":"archivo"},"0a4395028757":{"s":"ai-video-storyboard","a":"SKILL.md","l":35,"t":"**Call to action at the end?** (visit website, buy product, follow channel, etc.)","o":"archivo"},"375413fbe1a3":{"s":"ai-video-storyboard","a":"SKILL.md","l":36,"t":"**Any hard constraints?** (must include logo, specific colors, locations, etc.)","o":"archivo"},"658b20f679d9":{"s":"ai-video-storyboard","a":"SKILL.md","l":62,"t":"**Lens character** (shallow DOF / deep focus / wide angle distortion / macro)","o":"archivo"},"ce8831e8984c":{"s":"ai-video-storyboard","a":"SKILL.md","l":66,"t":"Write these as a **Visual Theme** block at the top of the output. Every shot's prompt must respect this block.","o":"archivo"},"68f234798bd5":{"s":"ai-video-storyboard","a":"SKILL.md","l":89,"t":"**Always specify the shared visual language** in every prompt (color palette, lighting, lens character, film look). This is how you enforce consistency.","o":"archivo"},"87680002b885":{"s":"ai-video-storyboard","a":"SKILL.md","l":90,"t":"**Specify exact duration** (4s / 5s / 8s) and **aspect ratio** (9:16 for TikTok/Reels, 16:9 for YouTube landscape, 1:1 for feed posts).","o":"archivo"},"097929817bc7":{"s":"ai-video-storyboard","a":"SKILL.md","l":91,"t":"**Always end with \"cinematic 1080p, synchronized audio\"** — this signals professional-grade quality and works with modern video models that support both.","o":"archivo"},"79369bcf16d4":{"s":"ai-video-storyboard","a":"SKILL.md","l":92,"t":"**Use cinematography vocabulary**: ECU (extreme close-up), CU, MS (medium shot), WS (wide shot), OTS (over-the-shoulder), POV, Dutch angle, low angle, high angle, bird's eye, dolly in, dolly out, tracking, handheld, rack focus, etc.","o":"archivo"},"3dde58c707c6":{"s":"ai-video-storyboard","a":"SKILL.md","l":93,"t":"**Don't write abstract prompts** — be concrete. \"A woman\" → \"A barista in her late 20s with wavy auburn hair, wearing a denim apron\".","o":"archivo"},"60f13533c38e":{"s":"ai-video-storyboard","a":"SKILL.md","l":94,"t":"**No model-specific hacks** — don't write prompts tuned to specific model quirks. Write model-agnostic cinematic prompts that work anywhere.","o":"archivo"},"c04789da6e17":{"s":"ai-video-storyboard","a":"SKILL.md","l":98,"t":"The sequence of shots must have a **story arc**, not a random list. Use one of these patterns:","o":"archivo"},"f136c00c3d59":{"s":"ai-video-storyboard","a":"SKILL.md","l":146,"t":"**Header** — Title, duration, shot count, aspect ratio","o":"archivo"},"f44cf9ff7226":{"s":"ai-video-storyboard","a":"SKILL.md","l":147,"t":"**Visual Theme** — Shared palette, lighting, lens, film look, motion","o":"archivo"},"5598ee94689f":{"s":"ai-video-storyboard","a":"SKILL.md","l":148,"t":"**Shot List** — N shots, each following the structure in Step 4","o":"archivo"},"ab3cc98cbe7f":{"s":"ai-video-storyboard","a":"SKILL.md","l":150,"t":"**Why This Works** — creative rationale","o":"archivo"},"ebc1422e5d22":{"s":"brand-lock-extractor","a":"SKILL.md","l":12,"t":"This skill extracts. It does not invent. Every value is sampled from a real asset or flagged as an estimate the user must confirm. A confident-sounding wrong hex is worse than a flagged guess.","o":"archivo"},"fcc9a56efa31":{"s":"brand-lock-extractor","a":"SKILL.md","l":34,"t":"Written description | Use directly | Identity, archetype, voice posture","o":"archivo"},"96e709999be1":{"s":"brand-lock-extractor","a":"SKILL.md","l":46,"t":"Tell the user what you are pulling. Do not ask follow-ups yet, extract first, confirm gaps at the end.","o":"archivo"},"5fe217339055":{"s":"brand-lock-extractor","a":"SKILL.md","l":52,"t":"**Identity** (brand, one-line description, archetype, voice posture)","o":"archivo"},"0dae3fdc0ace":{"s":"brand-lock-extractor","a":"SKILL.md","l":53,"t":"**Palette** (sampled hex, by role)","o":"archivo"},"39e68cb30388":{"s":"brand-lock-extractor","a":"SKILL.md","l":54,"t":"**Typography** (display, body, optional mono, with weights)","o":"archivo"},"c183542f6090":{"s":"brand-lock-extractor","a":"SKILL.md","l":55,"t":"**Mood adjectives** (3-5, specific, contrast clauses preferred)","o":"archivo"},"6257a4f1fd42":{"s":"brand-lock-extractor","a":"SKILL.md","l":56,"t":"**Never list** (what the brand avoids, inferred from consistency)","o":"archivo"},"89c96fc0932b":{"s":"brand-lock-extractor","a":"SKILL.md","l":57,"t":"**Aspect ratios**","o":"archivo"},"ddd43db015c9":{"s":"brand-lock-extractor","a":"SKILL.md","l":58,"t":"**Color grade direction** (one sentence)","o":"archivo"},"4075284680a4":{"s":"brand-lock-extractor","a":"SKILL.md","l":59,"t":"**Motion language** (one paragraph)","o":"archivo"},"086086b8d7f3":{"s":"brand-lock-extractor","a":"SKILL.md","l":60,"t":"**Voice rules** (copy-level constraints)","o":"archivo"},"c9c3a9312a4c":{"s":"brand-lock-extractor","a":"SKILL.md","l":69,"t":"**inferred**, reasoned from evidence but not stated (archetype from positioning, never-list from consistency). Reasonable to ship, worth noting.","o":"archivo"},"cd4c7a7c3646":{"s":"brand-lock-extractor","a":"SKILL.md","l":74,"t":"Use `templates/brand-lock.md.tpl`. Fill **every** required section, no placeholders left behind. Then append an `## Extraction notes` section that lists every `inferred` and `needs confirmation` value with its source and your reasoning. This section is the audit trail; it does not break validation (the validator checks the nine required sections are present, extra sections are fine).","o":"archivo"},"49fd83a4b509":{"s":"brand-lock-extractor","a":"SKILL.md","l":82,"t":"All nine required sections present: Identity, Palette, Typography, Mood adjectives, Never list, Aspect ratios, Color grade direction, Motion language, Voice rules.","o":"archivo"},"afdb75007c72":{"s":"brand-lock-extractor","a":"SKILL.md","l":94,"t":"Colors are sampled, never guessed. Read them from a brand book, from CSS, or by sampling pixels in a screenshot. If you genuinely cannot determine a color, fill your closest estimate and mark it `needs confirmation` in Extraction notes. \"Navy\" is not a palette entry. `#0F1F3A` is. A wrong hex stated confidently corrupts every downstream prompt.","o":"archivo"},"6eb4f8ba4dbc":{"s":"brand-lock-extractor","a":"SKILL.md","l":98,"t":"Identify fonts from the brand book, the site's CSS/font files, or clear visual match. If you cannot identify one, say so and flag it, do not name a plausible-sounding font you did not verify.","o":"archivo"},"03ede5f175d7":{"s":"brand-lock-extractor","a":"SKILL.md","l":106,"t":"It is also the hardest to extract, because brands document what they do, not what they avoid. Infer it from consistency: if every image avoids stock-photo gloss, that is a never. If copy never uses exclamation points, that is a never. Read `references/extraction-rubric.md` for the method. Do not ship an empty never-list.","o":"archivo"},"3d50d9dc8cee":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":40,"t":"never use stock photo aesthetic","o":"archivo"},"2b77fe0ab77d":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":41,"t":"never use AI uncanny faces","o":"archivo"},"528f3aca58d3":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":42,"t":"never use illustrations of people (real photography or abstract data viz only)","o":"archivo"},"34f304b45ae2":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":43,"t":"never use gradients (flat color only)","o":"archivo"},"70f50258fc9f":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":44,"t":"never use rounded corners larger than 8px","o":"archivo"},"a61acb519eac":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":45,"t":"never use exclamation points","o":"archivo"},"39f21f0bd621":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":46,"t":"never use vague claims (\"the best\", \"industry-leading\", \"cutting-edge\")","o":"archivo"},"bdeeca395947":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":47,"t":"never use AI/ML buzzwords without specifics","o":"archivo"},"21f3127a222e":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":48,"t":"never default to dark mode in primary marketing","o":"archivo"},"289646ec1639":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":49,"t":"never use animated icons or lottie illustrations","o":"archivo"},"5108ce119398":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":70,"t":"prefer specific numbers (\"40% reduction in 90 days\" not \"significant improvement\")","o":"archivo"},"98944bc5d597":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":71,"t":"prefer \"we\" and \"you\" over \"the company\" and \"the user\"","o":"archivo"},"5e5cfb4ec221":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":72,"t":"prefer present-tense","o":"archivo"},"cc15db8a3ce1":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":73,"t":"never start a sentence with \"Just\" or \"Simply\"","o":"archivo"},"f861a19be4ca":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":74,"t":"avoid corporate hedge language (\"seek to\", \"look to\", \"aim to\")","o":"archivo"},"42b960dda0f5":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":36,"t":"never use stock smiles or posed lifestyle photography","o":"archivo"},"e320951a2f69":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":37,"t":"never use latte art as decoration","o":"archivo"},"deff6acf6ba6":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":38,"t":"never use the word \"artisanal\"","o":"archivo"},"995266039bd6":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":39,"t":"never use exclamation points","o":"archivo"},"9c0afb7d325a":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":40,"t":"never shoot glossy product-on-white; matte and natural-light only","o":"archivo"},"00c5d773e8d3":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":41,"t":"never lean on burnt, dark-roast cliche imagery","o":"archivo"},"a9ed618bb40b":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":49,"t":"> Matte, low contrast, natural window light, warm but restrained. Reminiscent of Kinfolk editorial photography. Never glossy commercial product lighting.","o":"archivo"},"2d715d9073e7":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":58,"t":"never the word \"artisanal\" (or \"curated\", \"elevated\")","o":"archivo"},"b5797c1841f0":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":59,"t":"short declarative sentences; cut adjectives before nouns that do not need them","o":"archivo"},"fb243b53c635":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":60,"t":"prefer specific origin claims (farm, region, roast date) over vague quality words","o":"archivo"},"daf6cf4dbcb9":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":10,"t":"**inferred**, reasoned from evidence, not stated. Archetype from how the brand frames problems. Never-list from what the assets consistently avoid. Ship it, note the reasoning.","o":"archivo"},"d446778cd38a":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":17,"t":"**One-line description:** what the brand does and who for. This is the load-bearing sentence; a generator implicitly references it on every prompt. Pull it from the hero headline plus the about page. Prefer concrete over abstract: \"Managed bookkeeping for solo law firms\" beats \"Financial services for professionals.\" If the site only offers a vague tagline, sharpen it from the services/about copy a","o":"archivo"},"b4fbf43a4a92":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":19,"t":"**Archetype:** one word, Operator, Sage, Caregiver, Rebel, Creator, Jester, Ruler, Everyman, etc. Almost always `inferred`. Read it from how the brand frames the customer's problem:","o":"archivo"},"04363c882bf7":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":36,"t":"**Never guess a hex.** If you cannot read or sample one, estimate, label it `needs confirmation`, and tell the user exactly which role to verify. (See SKILL.md Rule 1.)","o":"archivo"},"a69c36bdec51":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":44,"t":"**Screenshots:** identify by eye only if confident; otherwise flag `needs confirmation`. Do not invent a plausible name (Rule 2).","o":"archivo"},"a1ad2f291171":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":50,"t":"3-5 adjectives, specific, contrast clauses preferred. Read tone from the body copy and the imagery together.","o":"archivo"},"775e72423ee9":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":56,"t":"The hardest and most valuable section. Brands document what they do; you infer what they avoid from consistency across the assets.","o":"archivo"},"3f18cfa9b5e8":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":59,"t":"Imagery: no stock-photo gloss? no people? no gradients? no clip-art icons? Each absence is a never.","o":"archivo"},"a86e2eb18131":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":60,"t":"Copy: no exclamation points? no hype words (\"revolutionary\", \"game-changing\")? no emojis? no questions in headlines? Each pattern is a never.","o":"archivo"},"451be222e3f4":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":61,"t":"Color/layout: never full-bleed photography? never more than one accent? never centered body text?","o":"archivo"},"f419380942de":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":63,"t":"Turn each observed constraint into a `never` line. Be specific: \"never use stock-photo aesthetic\" beats \"keep it authentic\". Aim for 5+. Never ship an empty list (Rule 4).","o":"archivo"},"dd519aa232b4":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":71,"t":"One sentence on how footage and generated images should be graded, with a reference point where possible (Kodak Portra 400, Apple keynote photography, A24 film grade). Infer from the existing photography's warmth, contrast, and saturation. If there is no photography to read, base it on the palette and flag `needs confirmation`.","o":"archivo"},"5a0a397f54c1":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":75,"t":"One paragraph: camera moves, cut style, text animation, pacing. Read from any existing video or motion on the site; if there is none, infer a conservative default consistent with the voice posture (a Quiet/Authoritative brand -> minimal, slow, deliberate) and flag `needs confirmation`. Keep it to one coherent motion language, do not blend \"minimal and deliberate\" with \"energetic whip pans\".","o":"archivo"},"f3fad8754516":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":79,"t":"Copy-level constraints for VO and on-screen text. Many overlap the never-list but are phrased as authoring rules: \"no em dashes\", \"sentences under 14 words\", \"prefer specific numbers over vague claims\", \"no exclamation points in headlines\". Extract from observed copy patterns. These become prompt constraints downstream, so make them enforceable, not aspirational.","o":"archivo"},"11ea00e863de":{"s":"image","a":"SKILL.md","l":18,"t":"The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone. The actual rules — what the models reward, what they punish, how to phrase a 5-slot template, when to add `quality: high`, when to use image grounding — live only in the reference files.","o":"regla"},"3f921ee68519":{"s":"image","a":"SKILL.md","l":22,"t":"**Motion, clips, montage** (Seedance, Kling, Veo, any image-to-video): use the sibling `video` skill. This skill's storyboard and keyframe outputs feed it.","o":"regla"},"0358891ec685":{"s":"image","a":"SKILL.md","l":40,"t":"**Nano Banana** → [nano-banana.md](references/nano-banana.md) Image grounding for real locations. Extreme aspect ratios (1:8, 8:1, 4:1). Thinking mode. JSON for 5+ elements. Up to 14 reference images. Why you must NOT write `50mm / f-stop / ISO` numbers.","o":"regla"},"c5eb6fd7f6f8":{"s":"image","a":"SKILL.md","l":43,"t":"**GPT Image 2** → [gpt-image.md](references/gpt-image.md) 5-slot template (Scene / Subject / Important Details / Use Case / Constraints). Anti-slop banned-words list. `quality: low / medium / high` as a deliberate fidelity lever. Size constraints (multiples of 16, max 3:1, up to 2560×1440). Two-column edit logic (Change / Preserve / Constraints). Up to 16 reference images with explicit roles.","o":"regla"},"485206c1697b":{"s":"image","a":"SKILL.md","l":50,"t":"Universal rules that apply to both models: start with a verb, positive framing, hex colors, quote text, edit don't re-roll, one change per iteration, reference images.","o":"regla"},"67a7dd9329dc":{"s":"image","a":"SKILL.md","l":100,"t":"For edits, also include an explicit preserve-list (mandatory for gpt-image-2, recommended for nano-banana):","o":"regla"},"890a0b28f120":{"s":"image","a":"SKILL.md","l":112,"t":"Prefer: ready-to-copy prompts, hex colors, concrete materials, named compositions, model-specific syntax (5-slot for GPT Image, natural prose for Nano Banana).","o":"regla"},"0e7900ffe2af":{"s":"image","a":"SKILL.md","l":114,"t":"Avoid: tag soup (\"cool, modern, 4k\"), vague praise (\"stunning, epic, masterpiece\" — actively hurts GPT Image 2), negative framing (\"no people, no cars\" — invert to positive), external comparisons (\"like Apple ad\" — describe the visual properties instead), numerical lens parameters in Nano Banana prompts (it ignores them).","o":"regla"},"09ec7d23fe12":{"s":"image","a":"references/creative-direction.md","l":34,"t":"Hasselblad — medium format, shallow DOF, fashion/portrait","o":"regla"},"b921448eda9a":{"s":"image","a":"references/creative-direction.md","l":47,"t":"\"Waist-up portrait\", \"full body\", \"over-the-shoulder\"","o":"regla"},"b8fa85d560e3":{"s":"image","a":"references/creative-direction.md","l":50,"t":"\"Shallow depth of field\" — blurred background","o":"regla"},"5ad1340da288":{"s":"image","a":"references/creative-direction.md","l":56,"t":"> descriptive terms. Prefer \"shallow depth of field\" over \"f/1.8\".","o":"regla"},"862a4c0ea3bc":{"s":"image","a":"references/creative-direction.md","l":78,"t":"Define physical makeup of subjects. Don't just say the thing — describe what it's MADE of.","o":"regla"},"d9bcca3cf113":{"s":"image","a":"references/golden-rules.md","l":12,"t":"Describe what you WANT, not what you don't want. The model understands presence better than absence.","o":"regla"},"1dd54b582a02":{"s":"image","a":"references/golden-rules.md","l":14,"t":"✅ \"empty street\" → ❌ \"street with no cars\"","o":"regla"},"7fff008d0b4a":{"s":"image","a":"references/golden-rules.md","l":15,"t":"✅ \"clean background\" → ❌ \"no clutter\"","o":"regla"},"f5bdd52eae18":{"s":"image","a":"references/golden-rules.md","l":16,"t":"✅ \"solo portrait\" → ❌ \"no other people\"","o":"regla"},"cc4167f1d432":{"s":"image","a":"references/golden-rules.md","l":27,"t":"❌ Bad: \"Cool car, neon, city, night, 8k\"","o":"regla"},"8d02f99b51e9":{"s":"image","a":"references/golden-rules.md","l":28,"t":"✅ Good: \"A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. Neon signs reflect off wet pavement and metallic chassis.\"","o":"regla"},"8901152207fe":{"s":"image","a":"references/golden-rules.md","l":42,"t":"\"for Brazilian gourmet cookbook\" → infers professional plating, shallow DOF","o":"regla"},"04c28ccbddf9":{"s":"image","a":"references/golden-rules.md","l":158,"t":"**Используй как HIGH-LEVEL steering** — якорь задаёт настроение и эстетику, а не заменяет весь промпт","o":"regla"},"3db8f42e251f":{"s":"image","a":"references/golden-rules.md","l":159,"t":"**Комбинируй с конкретными визуальными деталями** — якорь устанавливает мир, детали устанавливают специфику","o":"regla"},"16ec02525ce7":{"s":"image","a":"references/golden-rules.md","l":160,"t":"**Не стакай несколько genre anchors** — выбери один. \"Peter Lindbergh + Wes Anderson\" = каша","o":"regla"},"47652229b5ab":{"s":"image","a":"references/golden-rules.md","l":161,"t":"**Era/cultural anchors работают лучше с GPT Image 2** (world knowledge). С Nano Banana результат менее предсказуем — NB больше опирается на явные описания","o":"regla"},"1848820351ae":{"s":"image","a":"references/gpt-image.md","l":39,"t":"мудовый язык, в котором тонут функциональные требования | прямое заявление: «image must contain a transit kiosk»","o":"regla"},"20e10fa23ffc":{"s":"image","a":"references/gpt-image.md","l":74,"t":"Маленький/плотный/multi-font → `quality: high` обязательно.","o":"regla"},"26e0c5fc6ab4":{"s":"image","a":"references/gpt-image.md","l":96,"t":"**Object removal:** «Remove [X]. Do not change anything else. Use `input_fidelity: high` to maintain surrounding context» (только gpt-image-1.5/1, в gpt-image-2 high-fidelity по умолчанию).","o":"regla"},"822ae545689f":{"s":"image","a":"references/gpt-image.md","l":117,"t":"GPT Image 2 умеет домысливать контекст: «Bethel, NY, August 1969» → выведет Woodstock-эстетику. Используй: дай исторический/культурный анкер, не расписывай каждую деталь.","o":"regla"},"c10c7e21ff29":{"s":"image","a":"references/models.md","l":34,"t":"**Структурированный 5-slot промпт.** Чёткое разделение Scene/Subject/Details/Use case/Constraints даёт предсказуемость.","o":"regla"},"c842524ed79f":{"s":"image","a":"references/multi-panel.md","l":13,"t":"**When to use:** TVC or commercial shot breakdown — one image = 9 panels with scene titles and timestamps.","o":"regla"},"a127cca4810d":{"s":"image","a":"references/multi-panel.md","l":46,"t":"**Recommended size:** 1536x1024 (landscape)","o":"regla"},"e01904554508":{"s":"image","a":"references/multi-panel.md","l":50,"t":"Vague scene descriptions produce near-identical panels — each must have a distinct action, angle, or subject","o":"regla"},"3d26f71cccce":{"s":"image","a":"references/multi-panel.md","l":57,"t":"**When to use:** Same person shown from 4 angles/crops in one image for an editorial or casting look.","o":"regla"},"52c7e13d4185":{"s":"image","a":"references/multi-panel.md","l":83,"t":"**Recommended size:** 1024x1024 (square) or 1024x1536 (vertical for portrait emphasis)","o":"regla"},"796a278bda86":{"s":"image","a":"references/multi-panel.md","l":94,"t":"**When to use:** Hero shot + close-up + action for a campaign visual — horizontal or vertical triptych.","o":"regla"},"3a5fb89a88b1":{"s":"image","a":"references/multi-panel.md","l":122,"t":"**Recommended size:** 1536x1024 (horizontal triptych) or 1024x1536 (vertical triptych)","o":"regla"},"7421490e82fa":{"s":"image","a":"references/multi-panel.md","l":123,"t":"**Model:** GPT Image 2 `quality: medium` — if text overlay needed, use `quality: high`","o":"regla"},"576f2ecf7dd2":{"s":"image","a":"references/multi-panel.md","l":133,"t":"**When to use:** 12 panels telling a story or showing moods — no gaps between panels, seamless mosaic feel.","o":"regla"},"5eca40f8b2dc":{"s":"image","a":"references/multi-panel.md","l":162,"t":"**Recommended size:** 1536x1024 (landscape) — gives each cell enough resolution","o":"regla"},"e25ece2ca897":{"s":"image","a":"references/multi-panel.md","l":173,"t":"**When to use:** Fashion editorial or film-style sequence — multiple camera angles of the same scene in one image.","o":"regla"},"0237812f9545":{"s":"image","a":"references/multi-panel.md","l":205,"t":"**Recommended size:** 1536x1024 (landscape, 3x2 grid)","o":"regla"},"79ad480edaab":{"s":"image","a":"references/multi-panel.md","l":209,"t":"Top-down and low-angle in the same grid confuse the model if you don't anchor each frame to a grid position","o":"regla"},"921aa8a23672":{"s":"image","a":"references/multi-panel.md","l":210,"t":"Motion blur instruction must be specific (\"blur on hands and feet\") or the model applies blur everywhere","o":"regla"},"d9727650ad44":{"s":"image","a":"references/multi-panel.md","l":216,"t":"**When to use:** Product transformation, makeover, time comparison, renovation — two states side by side.","o":"regla"},"90d4b17bba47":{"s":"image","a":"references/multi-panel.md","l":243,"t":"**Recommended size:** 1536x1024 (landscape — gives each half a portrait-like proportion)","o":"regla"},"910dd4553129":{"s":"image","a":"references/multi-panel.md","l":244,"t":"**Model:** GPT Image 2 `quality: medium` — for text labels (\"BEFORE\" / \"AFTER\"), use `quality: high`","o":"regla"},"d8c349628ad4":{"s":"image","a":"references/multi-panel.md","l":248,"t":"Left/right assignment matters — always state which side is before and which is after","o":"regla"},"1e4fc13d2d29":{"s":"image","a":"references/multi-panel.md","l":254,"t":"**When to use:** Full narrative in one image — 3x4 grid (3 columns, 4 rows) for animation or video pre-production.","o":"regla"},"a0be4760c51c":{"s":"image","a":"references/multi-panel.md","l":294,"t":"**Recommended size:** 1024x1536 (portrait — 3 columns x 4 rows needs vertical space)","o":"regla"},"1062c830e923":{"s":"image","a":"references/multi-panel.md","l":295,"t":"**Model:** GPT Image 2 `quality: high` (text-heavy — scene numbers and captions must be readable)","o":"regla"},"eb71e5086205":{"s":"image","a":"references/multi-panel.md","l":300,"t":"Art style must be stated once and applied uniformly; mixing styles across panels produces visual chaos","o":"regla"},"bf6161618f55":{"s":"image","a":"references/multi-panel.md","l":308,"t":"**Subject consistency:** Always include an explicit instruction: \"same person / same character / same product across all panels.\" Repeat key identity markers (hair color, clothing, distinguishing features) rather than saying \"same as before.\"","o":"regla"},"f6982091002c":{"s":"image","a":"references/multi-panel.md","l":310,"t":"**Grid specification:** Always state the grid dimensions (e.g., \"3x2 grid, 3 columns 2 rows\"). Saying \"6 panels\" without layout instruction lets the model choose an unpredictable arrangement.","o":"regla"},"dabc108ffb16":{"s":"image","a":"references/nano-banana.md","l":24,"t":"Числовые параметры объектива: **50mm, 85mm, f/2.8, ISO 400** — NB игнорит. Используй описание: «shallow depth of field», «wide-angle distortion».","o":"regla"},"0456a3106233":{"s":"image","a":"references/nano-banana.md","l":55,"t":"Включён по умолчанию; у NBP отключить нельзя (модель рисует до 2 «thought images» в бэкенде, они не тарифицируются как картинки, но thinking-токены платные). У NB2 есть рычаг `thinking_level: minimal | high` (default `minimal`) — поднимай до `high` для:","o":"regla"},"a509f495c750":{"s":"image","a":"references/nano-banana.md","l":102,"t":"Interactions API держит контекст сессии — до 3 последовательных правок стэкаются без потери исходника. Правило «Edit, don't re-roll»: картинка верна на 80% — проси точечное изменение, а не новую генерацию.","o":"regla"},"82d4b1aa2d36":{"s":"image","a":"references/nano-banana.md","l":130,"t":"**Хэндофф в видеомодель — motion brief, не пересказ.** Движение камеры, движение субъекта, движение фона, длительность, framing lock, запрещённые изменения. Видео-промпт не переописывает то, что уже есть в кадре.","o":"regla"},"3de5ceee5c4e":{"s":"image","a":"references/nano-banana.md","l":137,"t":"Инфографика может содержать фактически неверные данные — цифры проверять всегда, grounding помогает, но не гарантирует.","o":"regla"},"f7781b9ee5c2":{"s":"image","a":"references/patterns/character-design.md","l":9,"t":"Use for game or animation pre-production — front, side, and back views of a character on a single white canvas with color callouts and height reference lines.","o":"regla"},"31a9f9f11aa7":{"s":"image","a":"references/patterns/character-design.md","l":23,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — height reference lines and color callout text require precise rendering","o":"regla"},"a8c47d2e697e":{"s":"image","a":"references/patterns/character-design.md","l":29,"t":"Use to produce a grid of 6–9 facial expressions for the same character — consistent head angle and art style, with emotion labels under each face.","o":"regla"},"b5749680d5b1":{"s":"image","a":"references/patterns/character-design.md","l":52,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text labels and consistent facial identity across 9 cells need precise control","o":"regla"},"e849bbafb08a":{"s":"image","a":"references/patterns/character-design.md","l":58,"t":"Use to show one character in multiple outfits or costumes — for fashion exploration, game skin concepts, or wardrobe design.","o":"regla"},"608c66f4b15a":{"s":"image","a":"references/patterns/character-design.md","l":80,"t":"**Recommended model:** GPT Image 2 (`quality: medium`) — character consistency is the priority; `high` only if outfit labels need fine legibility","o":"regla"},"639574d396e1":{"s":"image","a":"references/patterns/character-design.md","l":86,"t":"Use to transform a realistic character into a cute 3D collectible figurine — oversized head, compact body, multiple poses performing different activities.","o":"regla"},"be07ac1a9f48":{"s":"image","a":"references/patterns/character-design.md","l":108,"t":"**Recommended model:** GPT Image 2 (`quality: medium`) — smooth 3D vinyl surfaces render well at medium; `high` for marketing-ready close-ups","o":"regla"},"bc5138b583ba":{"s":"image","a":"references/patterns/character-design.md","l":120,"t":"Use for a full character reference card with portrait, full body, key items, and color palette — organized on a white background in a professional concept art layout.","o":"regla"},"ee853dd503fd":{"s":"image","a":"references/patterns/character-design.md","l":140,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout with hex codes, labels, and stat block requires precise rendering","o":"regla"},"c3d4dd460549":{"s":"image","a":"references/patterns/ecommerce.md","l":9,"t":"Use when you need a playful, attention-grabbing product visual where tiny workers interact with an oversized product — ideal for social media ads and launch campaigns.","o":"regla"},"19234ef99d6a":{"s":"image","a":"references/patterns/ecommerce.md","l":23,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — precise figurine detail and product label legibility","o":"regla"},"6a46a42327af":{"s":"image","a":"references/patterns/ecommerce.md","l":29,"t":"Use for premium beauty or fragrance product photography — dark, moody, tactile surfaces with atmospheric effects.","o":"regla"},"9a00a07b257d":{"s":"image","a":"references/patterns/ecommerce.md","l":43,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — surface materials and condensation detail","o":"regla"},"afdcc8f7bc89":{"s":"image","a":"references/patterns/ecommerce.md","l":51,"t":"Use to present a product commercial shot breakdown in a single image — pitch decks, creative presentations, client approvals.","o":"regla"},"4f23b10353c9":{"s":"image","a":"references/patterns/ecommerce.md","l":74,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — grid precision and text in panel 9","o":"regla"},"09817e522cce":{"s":"image","a":"references/patterns/ecommerce.md","l":80,"t":"Use for food, beverage, or supplement products where suspended ingredients communicate freshness, flavor, or composition.","o":"regla"},"d1f50fd09fa8":{"s":"image","a":"references/patterns/ecommerce.md","l":94,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — frozen detail precision and label legibility","o":"regla"},"6fc560223ecb":{"s":"image","a":"references/patterns/ecommerce.md","l":100,"t":"Use for disruptive, scroll-stopping social ads where the product packaging appears squeezed, inflated, or physically distorted as if made of soft rubber or vinyl.","o":"regla"},"bf758f621b50":{"s":"image","a":"references/patterns/ecommerce.md","l":114,"t":"**Recommended model:** NBP — complex spatial reasoning for believable physical distortion","o":"regla"},"e85f3a2c01a5":{"s":"image","a":"references/patterns/fashion-editorial.md","l":9,"t":"Use for fashion brand campaign hero images — one wide shot combining hero pose, close-up detail, and action/movement in a triptych layout.","o":"regla"},"e200695107d8":{"s":"image","a":"references/patterns/fashion-editorial.md","l":27,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency across panels and fabric texture detail","o":"regla"},"ce04a04c45aa":{"s":"image","a":"references/patterns/fashion-editorial.md","l":33,"t":"Use for model tests, casting cards, or editorial portfolio pages — four angles of the same person in a clean grid.","o":"regla"},"97ef5791058f":{"s":"image","a":"references/patterns/fashion-editorial.md","l":52,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency critical across four frames","o":"regla"},"9b5c3232e804":{"s":"image","a":"references/patterns/fashion-editorial.md","l":58,"t":"Use for streetwear drops, limited edition launches, or urban fashion brand campaigns where bold type dominates the composition.","o":"regla"},"348b0b1ed027":{"s":"image","a":"references/patterns/fashion-editorial.md","l":73,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text rendering and model-type depth interplay","o":"regla"},"1bf69ac8c5e3":{"s":"image","a":"references/patterns/fashion-editorial.md","l":79,"t":"Use for playful, nostalgic sportswear or athleisure campaigns with 70s-80s visual language.","o":"regla"},"eb03e137df6e":{"s":"image","a":"references/patterns/fashion-editorial.md","l":85,"t":"**Key levers:** `{model_description}`, `{outfit_description}` (high-waisted terry shorts in coral, cropped zip-up in cream, tube socks with racing stripes), `{location_description}` (Venice Beach boardwalk, empty suburban tennis court, coastal promenade), `{film_stock}` (Kodak Gold 200, Fuji Superia 400), `{palette_description}` (terracotta #CC5533, cream #FFF5E1, sky blue #87CEEB, mustard #D4A017","o":"regla"},"c5971eabbb4b":{"s":"image","a":"references/patterns/fashion-editorial.md","l":87,"t":"**Recommended model:** NB2 — natural movement, analog film grain, atmospheric grounding","o":"regla"},"6dfcd0919723":{"s":"image","a":"references/patterns/fashion-editorial.md","l":93,"t":"Use for forward-looking athletic or techwear editorials where abstract 3D forms create a surreal spatial environment around the model.","o":"regla"},"ce24e75d12a1":{"s":"image","a":"references/patterns/fashion-editorial.md","l":107,"t":"**Recommended model:** NBP — complex spatial reasoning for blob placement and reflections","o":"regla"},"46ce53039819":{"s":"image","a":"references/patterns/food-beverage.md","l":9,"t":"Use for premium chocolate or confectionery brand visuals — moody, textural, with controlled color and atmosphere. Adaptable across mood variants (dark indulgence, bright artisan, earthy origin-story).","o":"regla"},"a9c702b552f4":{"s":"image","a":"references/patterns/food-beverage.md","l":35,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — fracture detail and cocoa powder precision","o":"regla"},"20bb122f18fb":{"s":"image","a":"references/patterns/food-beverage.md","l":41,"t":"Use for premium beverage brand campaigns that combine lifestyle and product in a structured board layout — model shot + hero product + product lineup.","o":"regla"},"1ba1ff7577c8":{"s":"image","a":"references/patterns/food-beverage.md","l":59,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — label legibility and panel consistency","o":"regla"},"d4f497bb93d1":{"s":"image","a":"references/patterns/food-beverage.md","l":65,"t":"Use for hero food posters — restaurants, delivery apps, menu boards — where the food is the entire composition with fillable content slots.","o":"regla"},"4c926ca35845":{"s":"image","a":"references/patterns/food-beverage.md","l":96,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — steam, condensation, and ingredient texture fidelity","o":"regla"},"df532917ca8c":{"s":"image","a":"references/patterns/food-beverage.md","l":102,"t":"Use for educational food content, ingredient features, or artisanal brand storytelling — the food item rendered as a scientific illustration in the style of 19th-century naturalist prints.","o":"regla"},"a30c3b235f2e":{"s":"image","a":"references/patterns/food-beverage.md","l":110,"t":"**Recommended model:** NB2 — naturalist illustration style, grounding on botanical plate aesthetics","o":"regla"},"de44302b8294":{"s":"image","a":"references/patterns/food-beverage.md","l":116,"t":"Use for restaurant guides, food festival materials, travel content, or local cuisine features — a bird's-eye illustrated map showing food specialties across a city.","o":"regla"},"d62c529d34db":{"s":"image","a":"references/patterns/food-beverage.md","l":124,"t":"**Recommended model:** NB2 — image grounding for real city landmarks + illustration style","o":"regla"},"bdc7c98423b2":{"s":"image","a":"references/patterns/portrait-cinema.md","l":9,"t":"Use for warm, emotive street portraits with strong backlight flare — editorial, personal branding, album covers.","o":"regla"},"e80f84e82cd7":{"s":"image","a":"references/patterns/portrait-cinema.md","l":21,"t":"**Key levers:** `{street_description}` (narrow European alley with stone walls, wide boulevard with linden trees, industrial backstreet with brick), `{person_description}`, `{expression}` (quiet confidence, mid-smile with closed lips, contemplative gaze), `{bounce_surface}` (cream-painted wall, parked white van, sand-colored buildings), `{clothing_detail}` (linen shirt collar, leather jacket shoul","o":"regla"},"2260c15e96b4":{"s":"image","a":"references/patterns/portrait-cinema.md","l":23,"t":"**Recommended model:** GPT Image 2 — backlight exposure control and skin rendering","o":"regla"},"36bbbe701ad0":{"s":"image","a":"references/patterns/portrait-cinema.md","l":29,"t":"Use for urban night portraits with mixed artificial lighting — fluorescent overhead + colored neon signage creating a chromatic push-pull on the subject's face.","o":"regla"},"5b0ec72c5a49":{"s":"image","a":"references/patterns/portrait-cinema.md","l":43,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — precise dual-light color rendering on skin","o":"regla"},"9a20603f7d87":{"s":"image","a":"references/patterns/portrait-cinema.md","l":49,"t":"Use for edgy, tech-forward portraits — artist profiles, electronic music press, tech brand campaigns. High contrast black-and-white with selective red digital artifacts.","o":"regla"},"29940f3cd9ae":{"s":"image","a":"references/patterns/portrait-cinema.md","l":61,"t":"**Key levers:** `{person_description}`, `{direction}` (left, right), `{hair_detail}` (tight buzz cut showing skull contour, shoulder-length hair with flyaway strands catching backlight, pulled-back bun), `{glitch_positions}` (across the eye, across the mouth, across the forehead — specify 2-3 positions), `{accent_color}` (#FF0000 red, #00FF41 terminal green, #FF00FF magenta), `{max_glitch_lines}` ","o":"regla"},"f708635c6957":{"s":"image","a":"references/patterns/portrait-cinema.md","l":63,"t":"**Recommended model:** GPT Image 2 — high-contrast mono rendering and controlled glitch placement","o":"regla"},"b8ecc6c820c5":{"s":"image","a":"references/patterns/portrait-cinema.md","l":69,"t":"Use for moody, atmospheric portraits with overexposed analog film qualities — muted colors, lifted shadows, and a feeling of faded memory. Ideal for editorial, zine, or personal project work.","o":"regla"},"25c7ab649b75":{"s":"image","a":"references/patterns/portrait-cinema.md","l":77,"t":"**Recommended model:** NB2 — analog film grain emulation and atmospheric mood","o":"regla"},"b6f22ea21acd":{"s":"image","a":"references/patterns/portrait-cinema.md","l":83,"t":"Use for beauty campaigns, conceptual art, or album visuals — a portrait where the subject floats in clear water surrounded by translucent aquatic elements.","o":"regla"},"be5a2e46231a":{"s":"image","a":"references/patterns/portrait-cinema.md","l":97,"t":"**Recommended model:** NBP — complex physics (floating hair, fabric, fish transparency, caustic light)","o":"regla"},"5c934f24e5bd":{"s":"image","a":"references/patterns/poster-illustration.md","l":9,"t":"Use for urban development campaigns, anniversary materials, cultural exhibitions, or editorial features — a single city view divided down the middle, one half historical and one half modern.","o":"regla"},"535d74d81a91":{"s":"image","a":"references/patterns/poster-illustration.md","l":28,"t":"**Recommended model:** NBP — spatial reasoning for architectural morphing and perspective consistency","o":"regla"},"44c898225d80":{"s":"image","a":"references/patterns/poster-illustration.md","l":40,"t":"Use for sport and fitness brand campaigns — a dynamic 3-panel collage combining action, detail, and atmosphere around a boxing/combat sport theme.","o":"regla"},"4c1d2cabad77":{"s":"image","a":"references/patterns/poster-illustration.md","l":59,"t":"**Recommended model:** GPT Image 2 — identity consistency across panels and sweat/texture detail","o":"regla"},"7b6acbb90a0a":{"s":"image","a":"references/patterns/poster-illustration.md","l":65,"t":"Use for tech product launch visuals — clean, color-dominant hero shots where a smartphone (or similar device) floats against a monochromatic gradient with soft 3D accent elements.","o":"regla"},"57fca5220269":{"s":"image","a":"references/patterns/poster-illustration.md","l":82,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text rendering, screen content legibility, device accuracy","o":"regla"},"c755ff2903b8":{"s":"image","a":"references/patterns/poster-illustration.md","l":88,"t":"Use for fashion drops, event announcements, or editorial magazine covers where bold typography and a street fashion figure share equal visual weight on a saturated color field.","o":"regla"},"cd1fa75558c5":{"s":"image","a":"references/patterns/poster-illustration.md","l":103,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — typography rendering and figure-type layering","o":"regla"},"803245de38c4":{"s":"image","a":"references/patterns/poster-illustration.md","l":109,"t":"Use for decorative prints, packaging illustration, wallpaper design, or editorial art — a symmetrical composition combining a peacock with botanical elements in a vintage printmaking style.","o":"regla"},"b6a40416c21b":{"s":"image","a":"references/patterns/poster-illustration.md","l":117,"t":"**Recommended model:** NB2 — image grounding for accurate peacock anatomy and botanical species","o":"regla"},"7a21ad4f3c7d":{"s":"image","a":"references/patterns/ui-social.md","l":9,"t":"Use for vertical product or brand ads targeting Instagram Stories — hero product, bold headline, and swipe-up CTA zone at the bottom.","o":"regla"},"be784fefef07":{"s":"image","a":"references/patterns/ui-social.md","l":23,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — headline text legibility and glassmorphism transparency effects need precision","o":"regla"},"f5f07232cc75":{"s":"image","a":"references/patterns/ui-social.md","l":29,"t":"Use for square-format posts on Instagram or Facebook — quote cards, feature announcements, or product highlights with centered layout.","o":"regla"},"ac9f15b7d326":{"s":"image","a":"references/patterns/ui-social.md","l":49,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout; legibility at small sizes is critical","o":"regla"},"76fa850073b5":{"s":"image","a":"references/patterns/ui-social.md","l":55,"t":"Use to create a polished App Store or Google Play listing screenshot — device frame with app UI inside, feature headline, and clean gradient background.","o":"regla"},"d4e8f76bb757":{"s":"image","a":"references/patterns/ui-social.md","l":75,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — device bezel precision, small UI text, and headline legibility all demand high quality","o":"regla"},"b1a90c3a0a1d":{"s":"image","a":"references/patterns/ui-social.md","l":81,"t":"Use for realistic analytics dashboard mockups — dark or light theme with data visualizations, KPI cards, and sidebar navigation.","o":"regla"},"8f24d3e22d84":{"s":"image","a":"references/patterns/ui-social.md","l":104,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — dense text (labels, numbers, navigation), precise chart rendering, and small UI elements require high fidelity","o":"regla"},"6b8e9a41cbf9":{"s":"image","a":"references/patterns/ui-social.md","l":116,"t":"Use to create a visual color analysis graphic from a portrait — seasonal palette classification, clothing color comparisons, and accessory recommendations in an organized layout.","o":"regla"},"5bb61a5742b2":{"s":"image","a":"references/patterns/ui-social.md","l":133,"t":"**Key levers:** `{subject_description}` (age, skin tone, hair color, eye color — needed for accurate seasonal analysis), `{season_type}` (Warm Spring, Cool Summer, Warm Autumn, Cool Winter — or sub-seasons like Soft Autumn, Bright Winter), `{palette_colors}` (12 hex values matching the season, e.g. Warm Autumn: rust #B7410E, olive #708238, mustard #E1AD01, burgundy #722F37...), `{num_palette}` (12","o":"regla"},"e3ff88ae7b6f":{"s":"image","a":"references/patterns/ui-social.md","l":135,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — color accuracy of palette swatches is critical, plus small text labels throughout","o":"regla"},"c8d4fff1dabe":{"s":"image","a":"references/prompt-framework.md","l":39,"t":"**Палитра** - цвета (лучше hex)","o":"regla"},"58817d380494":{"s":"image","a":"references/prompt-framework.md","l":43,"t":"> - **Nano Banana** — игнорит числа, пиши описательно («shallow depth of field»)","o":"regla"},"85e2a5dc4aa8":{"s":"image","a":"references/prompt-framework.md","l":88,"t":"> Формулируй позитивно! NBP лучше понимает \"clean background\" чем \"no clutter\"","o":"regla"},"5856058c8a75":{"s":"image","a":"references/prompt-framework.md","l":159,"t":"Переменные записываются как `{name, default=\"value\"}`. Если значение не указано — используется дефолт. Если дефолта нет — переменная обязательна.","o":"regla"},"84828d3c69a2":{"s":"image","a":"references/prompt-framework.md","l":173,"t":"**Заменяй только то, что меняется** — остальное берётся из дефолтов","o":"regla"},"a90636943228":{"s":"image","a":"references/prompt-framework.md","l":174,"t":"**Структура стабильна** — порядок слотов одинаковый для всех вариаций, модель получает консистентный формат","o":"regla"},"8005da81a345":{"s":"image","a":"references/prompt-framework.md","l":175,"t":"**Batch-генерация** — идеально для серий: продуктовые ракурсы, позы персонажа, локации в одном стиле","o":"regla"},"42a42a73fa09":{"s":"image","a":"references/prompt-framework.md","l":212,"t":"**Surface wear & aging** — \"chipped paint on window frame, hairline scratches on metal surface, green patina on copper fittings, oxidation marks on iron hinges\"","o":"regla"},"4bc498edcc17":{"s":"image","a":"references/prompt-framework.md","l":213,"t":"**Micro-textures** — \"visible pores on skin, individual hair strands catching backlight, fabric weave pattern on linen shirt, grain of weathered wood\"","o":"regla"},"bc6d5c9aff5f":{"s":"image","a":"references/prompt-framework.md","l":214,"t":"**Atmospheric particles** — \"dust motes suspended in light beam, steam wisps rising from coffee cup, pollen floating in golden hour air, fine rain droplets on glass surface\"","o":"regla"},"318b118d917d":{"s":"image","a":"references/prompt-framework.md","l":215,"t":"**Specular behavior** — \"specular highlights on metal edges of watch, caustic reflections dancing inside glass bottle, wet surface sheen on cobblestones after rain\"","o":"regla"},"92eeb4747a7e":{"s":"image","a":"references/prompt-framework.md","l":216,"t":"**Fabric & material drape** — \"natural fabric folds at elbow crease, gravity pull on loose linen garment, weight distribution visible in heavy wool coat\"","o":"regla"},"51b0bfedb210":{"s":"image","a":"references/prompt-framework.md","l":217,"t":"**Contact shadows** — \"soft contact shadow where cup meets saucer, ambient occlusion in crevices of stone wall, dark line where book spine meets table\"","o":"regla"},"329aa0a4fa84":{"s":"image","a":"references/prompt-framework.md","l":218,"t":"**Environmental reflections** — \"building reflections in wet pavement, sky gradient in chrome bumper surface, warm neon glow on skin from nearby sign\"","o":"regla"},"11ec80431f42":{"s":"image","a":"references/prompt-framework.md","l":219,"t":"**Motion cues** — \"slight motion blur on trailing hair strand, frozen splash droplet from espresso pour, wind-displaced fabric edge of scarf\"","o":"regla"},"796d88912233":{"s":"image","a":"references/slides.md","l":29,"t":"Избегай pure white #fff на чёрном - используй #f5f5f5","o":"regla"},"2f0619f0ec28":{"s":"image","a":"references/slides.md","l":32,"t":"Контент должен дышать","o":"regla"},"c9068adfe734":{"s":"image","a":"references/storyboards.md","l":78,"t":"\"Identity must stay consistent throughout\"","o":"regla"},"3244bb3011e7":{"s":"image","a":"references/storyboards.md","l":81,"t":"\"Expressions and poses should vary\"","o":"regla"},"8e32b234137b":{"s":"image","a":"references/text-rendering.md","l":126,"t":"Ask the model to write/refine the text content","o":"regla"},"7447d548b9f0":{"s":"image","a":"references/text-rendering.md","l":127,"t":"Then ask for an image with that exact text","o":"regla"},"0db1539c575d":{"s":"image","a":"references/text-rendering.md","l":167,"t":"Upload with prompt: \"Use layout from attached image\"","o":"regla"},"7e22722f52fa":{"s":"image","a":"references/vision-decomposer.md","l":3,"t":"Use this reference when the user asks to analyze an image and convert it to a generation prompt: **style transfer**, **mood reference**, **\"сделай промпт по этой картинке\"**, **\"перенеси стиль/образ\"**, **\"проанализируй кадр\"**, **\"image to prompt\"**, **\"reverse-engineer this look\"**.","o":"regla"},"442a75c51f58":{"s":"image","a":"references/vision-decomposer.md","l":7,"t":"The process has two strict steps. Do not skip Step 1. Do not freestyle Step 2.","o":"regla"},"a712726b25c7":{"s":"image","a":"references/vision-decomposer.md","l":36,"t":"**Figure & ground (Arnheim):** degree of subject isolation, overlapping of forms, mass relationships. Use of reflections (mirrors, windows) to expand context.","o":"regla"},"04cb7f3e5408":{"s":"image","a":"references/vision-decomposer.md","l":44,"t":"**Broken light & reflexes (Zheleznyakov):** use of shadow masks (gobos), light through blinds / foliage, color reflexes from neighboring objects onto skin / clothing.","o":"regla"},"7d2338d1b298":{"s":"image","a":"references/vision-decomposer.md","l":49,"t":"**Camera (angles & viewpoint):** Angle (High angle, Low angle, Eye-level, Dutch tilt). Objective camera, Subjective, POV, Over-the-shoulder (OTS). Movement imitation (Push-in, Tracking shot).","o":"regla"},"3d2a2115477d":{"s":"image","a":"references/vision-decomposer.md","l":62,"t":"Describe **strictly what you see**. Do not invent new objects.","o":"regla"},"7cf887e9d7c2":{"s":"image","a":"references/vision-decomposer.md","l":63,"t":"**No filler.** Never write \"The image shows...\", \"A picture of...\", \"I can see...\".","o":"regla"},"526a0bad384e":{"s":"image","a":"references/vision-decomposer.md","l":109,"t":"Do NOT load this for: pure generation requests where no reference image is given. For those, use the standard model files.","o":"regla"},"a4a34906e54d":{"s":"produccion-visual-sw30","a":"SKILL.md","l":20,"t":"Si la respuesta es NO: no se entrega. Se leen los archivos faltantes, se aplica lo que falte y se vuelve a preguntar. Se repite cuantas veces sea necesario.","o":"regla"},"ab216a6c933f":{"s":"produccion-visual-sw30","a":"SKILL.md","l":22,"t":"Prohibido responder SÍ para complacer. Un SÍ falso es una mentira y cuesta más que el NO.","o":"regla"},"5c17fa63163e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":23,"t":"Prohibido responder SÍ con matices, condiciones o notas al pie disfrazadas de honestidad.","o":"regla"},"241ea833ab9d":{"s":"produccion-visual-sw30","a":"SKILL.md","l":24,"t":"\"Exhaustiva\" significa: leídos COMPLETOS todos los archivos del skill aplicables al caso (SKILL.md indica el orden obligatorio), no fragmentos ni grep.","o":"regla"},"26da6aecb6fb":{"s":"produccion-visual-sw30","a":"SKILL.md","l":33,"t":"Orden de dirección: nunca se escribe un prompt de corrido ni se parchea texto. Tres pasos, en este orden:","o":"regla"},"87eadbf796d1":{"s":"produccion-visual-sw30","a":"SKILL.md","l":35,"t":"**CATALOGAR** — identificar el TIPO de prompt y leer qué reglas aplican a ese tipo en la matriz (production-package/RULES_MATRIX.md: 26 reglas × 5 tipos, con fuente y bloque de cada una). Tipos: T1 maestro rostro · T2 maestro cuerpo · T3 cuadro 1 persona · T4 cuadro 2 personas · T5 edición quirúrgica.","o":"regla"},"d48021c639e6":{"s":"produccion-visual-sw30","a":"SKILL.md","l":39,"t":"**DEFINIR SECCIONES** — antes de redactar, listar las secciones que ese tipo exige. Cada regla vive en UN bloque nombrado y compartido (optics_*, skin_*, anatomy, idlock, text_lock, contact_*, unique, colour, hair, fabric, clean_*, autocontain_*), nunca en texto suelto dentro del brief.","o":"regla"},"4a2eeac6c89d":{"s":"produccion-visual-sw30","a":"SKILL.md","l":42,"t":"**ENSAMBLAR POR SECCIÓN** — el prompt se construye llamando P(scene, subject, [details], mood, usecase, [constraints]) para creación o E(change, preserve, [constraints]) para edición, pasando bloques. Salida en el formato de SKILL.md del skill image: cabecera Model/Quality/Size + References","o":"regla"},"6658223ecd3e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":52,"t":"`rule_registry.py` — relee los 23 archivos del skill image y EXTRAE mecánicamente cada enunciado normativo (209). Si el skill cambia, el registro cambia solo. Mi interpretación deja de ser etapa.","o":"regla"},"3348210ad98e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":54,"t":"`rule_ledger.py` — obliga a que CADA regla aplicable tenga disposición explícita: CHECK (existe verificación) o NA (con razón escrita y auditable). Sale con código 1 si queda una sola PENDING.","o":"regla"},"b37aa531231e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":56,"t":"`audit_gi2.py` — verifica los prompts columna por columna.","o":"regla"},"5a5348b20c81":{"s":"produccion-visual-sw30","a":"SKILL.md","l":73,"t":"usecase | `usecase_doc` | fotografía documental Kodak Tri-X de reportaje. Kodak Portra suaviza la piel por diseño y contradice los poros — PROHIBIDO en rostros","o":"regla"},"7ba769efe2d7":{"s":"produccion-visual-sw30","a":"SKILL.md","l":83,"t":"`production-package/template_engine.py` es OBLIGATORIO para construir cualquier prompt visual.","o":"regla"},"c0bc3ce2b122":{"s":"produccion-visual-sw30","a":"SKILL.md","l":84,"t":"Un prompt no se escribe: se INSTANCIA con `build(tipo, ..., notes=...)`. El motor lanza","o":"regla"},"ca17e7d8bf24":{"s":"produccion-visual-sw30","a":"SKILL.md","l":97,"t":"**PROHIBIDO editar el texto de un brief individual.** Eso es parchar: arregla una cosa y rompe otra, y es la causa raíz de los ciclos de tres reescrituras.","o":"regla"},"5cf46d07bcac":{"s":"produccion-visual-sw30","a":"SKILL.md","l":116,"t":"Un solo trabajo por generación. Con dos personajes: un sujeto por generación, o técnica de colocación probada; nunca \"a ver si sale\".","o":"regla"},"613774db48c2":{"s":"produccion-visual-sw30","a":"SKILL.md","l":118,"t":"Posición SIEMPRE por ancla legible de la propia imagen (letterforms del mundo: \"his back level with the letter L of WORLD\"). Prohibido \"left half\", \"centre\", \"just left of X\".","o":"regla"},"762ce60bec5e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":120,"t":"El editor no tiene memoria: solo verbos operativos (Move/Replace/Add/Remove/Swap), cero narrativa (\"has become\", \"again\").","o":"regla"},"cb50b580f819":{"s":"produccion-visual-sw30","a":"SKILL.md","l":122,"t":"Autocontención: toda comparación (\"same X\") exige ambos referentes adjuntos en ESE prompt.","o":"regla"},"ff510d7ca127":{"s":"produccion-visual-sw30","a":"SKILL.md","l":123,"t":"Herencia mínima: \"same face and clothes\" + solo los deltas. Cero re-descripción de lo que la referencia ya muestra.","o":"regla"},"4fcb4afa54c3":{"s":"produccion-visual-sw30","a":"SKILL.md","l":125,"t":"Swap de identidad = última operación, sola: \"Replace X with Y — same position, same pose, same scale\".","o":"regla"},"4d4ea0758b3f":{"s":"produccion-visual-sw30","a":"SKILL.md","l":127,"t":"Mundos por dos pasos: placa vacía primero; insert con \"use only the person from image N, ignore its setting\" + \"keep the world of image 1 untouched\".","o":"regla"},"b6df20344be1":{"s":"produccion-visual-sw30","a":"SKILL.md","l":129,"t":"Stills en instante congelado (\"frozen mid-stride\"); nada de movimiento en imagen fija.","o":"regla"},"7dc14c265b1a":{"s":"produccion-visual-sw30","a":"SKILL.md","l":130,"t":"Contactos entre personas: \"a natural high five\" — la anatomía la fija el keyframe aprobado, nunca la asignación de manos por texto.","o":"regla"},"204113433c22":{"s":"produccion-visual-sw30","a":"SKILL.md","l":132,"t":"Logos solo heredados de asset aprobado o descripción canónica del brand-lock; los cuerpos nunca tapan logo ni lettering en frames congelados.","o":"regla"},"0895bf9c3c72":{"s":"produccion-visual-sw30","a":"SKILL.md","l":134,"t":"Lo aprobado se canoniza con hash y se EDITA desde ahí; lo caro nunca se regenera.","o":"regla"},"3f9822c97a3a":{"s":"produccion-visual-sw30","a":"SKILL.md","l":135,"t":"\"Edit, don't re-roll\": resultado ≥80% correcto → cambio puntual (hasta 3 ediciones apiladas), nunca re-tirar.","o":"regla"},"f9fee85351f3":{"s":"produccion-visual-sw30","a":"SKILL.md","l":137,"t":"Máximo 2 intentos por método. A la 2ª falla: cambio de método con causa declarada, o alto y consulta. Nunca tercera vuelta de lo mismo.","o":"regla"},"0aad9d5a3dfa":{"s":"produccion-visual-sw30","a":"SKILL.md","l":139,"t":"Validadores del paquete y techos de palabras en verde antes de entregar; inspección visual propia (zooms 100% de rostros y manos) antes de presentar. Si algo falla: no se entrega, se repite — y se dice qué falló en una línea.","o":"regla"},"aeb5f5e9292c":{"s":"produccion-visual-sw30","a":"SKILL.md","l":142,"t":"shots.json es la fuente de verdad: todo cambio entra ahí primero y se propaga.","o":"regla"},"2dddf6f48ba3":{"s":"produccion-visual-sw30","a":"SKILL.md","l":143,"t":"Clips: solo Preserve-cues, roles de start/tail (\"The tail image defines X — inherit exactly\"), movimiento puro, imagen final nombrada; negativos sin \"no X\", ≤8 ítems.","o":"regla"},"44283e478fd4":{"s":"produccion-visual-sw30","a":"SKILL.md","l":145,"t":"Entregas en unidades chicas con OK de dirección; se entrega el delta, no el paquete. Una regla nueva de dirección se aplica a TODOS los prompts, no a la mitad.","o":"regla"},"84846df151fa":{"s":"produccion-visual-sw30","a":"SKILL.md","l":147,"t":"Respuestas: el dato o entregable en la primera línea. Cero adulación y cero evaluación de las acciones de Eric salvo que la pida. Error = una línea de corrección, sin disculpas.","o":"regla"},"6da8440e93ad":{"s":"produccion-visual-sw30","a":"SKILL.md","l":149,"t":"Prohibido afirmar capacidades, límites o hechos de plataforma sin verificarlos en este turno (leer la fuente o buscar); lo no verificado se etiqueta como inferencia.","o":"regla"},"fb3896038afa":{"s":"screenwriter","a":"SKILL.md","l":77,"t":"Always use ALL CAPS for sluglines","o":"archivo"},"4d9355018ad2":{"s":"screenwriter","a":"SKILL.md","l":78,"t":"Use hyphens to separate elements","o":"archivo"},"57e9c487ac74":{"s":"screenwriter","a":"SKILL.md","l":80,"t":"Time should suggest lighting/mood","o":"archivo"},"fa0199539554":{"s":"screenwriter","a":"SKILL.md","l":87,"t":"**Show, Don't Tell:** Write what's visible, not internal thoughts","o":"archivo"},"e10b5f7be709":{"s":"screenwriter","a":"SKILL.md","l":88,"t":"**Sensory Details:** Include lighting, atmosphere, textures, colors","o":"archivo"},"45f2e43f67e0":{"s":"screenwriter","a":"SKILL.md","l":89,"t":"**Present Tense:** Always write in present tense","o":"archivo"},"a93dbeef8737":{"s":"screenwriter","a":"SKILL.md","l":90,"t":"**Active Voice:** Use strong, active verbs","o":"archivo"},"10e5da2fcf9a":{"s":"screenwriter","a":"SKILL.md","l":91,"t":"**Specific Props:** Name objects that matter visually","o":"archivo"},"59d398f4c454":{"s":"screenwriter","a":"SKILL.md","l":92,"t":"**Atmosphere:** Set mood through environmental details","o":"archivo"},"671c49de0056":{"s":"screenwriter","a":"SKILL.md","l":128,"t":"Avoid excessive detail—just enough for visual consistency","o":"archivo"},"27e302d3a37e":{"s":"screenwriter","a":"SKILL.md","l":140,"t":"Use dialogue ONLY when essential to story","o":"archivo"},"5645bf344589":{"s":"screenwriter","a":"SKILL.md","l":157,"t":"`CUT TO:` - Scene change (usually implied, use for emphasis)","o":"archivo"},"68d5f2185557":{"s":"screenwriter","a":"SKILL.md","l":162,"t":"**Modern Best Practice:** Most transitions are IMPLIED. Use sparingly, only for specific narrative effect.","o":"archivo"},"c775d8acd13e":{"s":"screenwriter","a":"SKILL.md","l":235,"t":"**Emotional beats:** Each scene should shift emotional state","o":"archivo"},"8cc0ef448f33":{"s":"screenwriter","a":"SKILL.md","l":244,"t":"**Consistent naming:** Use same character names throughout","o":"archivo"},"bff5030b3380":{"s":"screenwriter","a":"SKILL.md","l":253,"t":"**Lean prose:** Each word should serve the image","o":"archivo"},"35abb8abc912":{"s":"screenwriter","a":"SKILL.md","l":256,"t":"❌ **Vague descriptions:** \"A person walks\" → ✅ \"A weathered woman in her 50s trudges through snow\"","o":"archivo"},"df9b899dbc91":{"s":"screenwriter","a":"SKILL.md","l":257,"t":"❌ **Telling emotions:** \"She feels sad\" → ✅ \"Tears streak her dusty cheeks\"","o":"archivo"},"de28e225dfa5":{"s":"screenwriter","a":"SKILL.md","l":258,"t":"❌ **Camera directions:** \"CLOSE UP ON\" → ✅ \"The crack in the glass spreads\"","o":"archivo"},"aa1edc03619b":{"s":"screenwriter","a":"SKILL.md","l":259,"t":"❌ **Over-dialogue:** Short films need visual storytelling","o":"archivo"},"0cf150e839a8":{"s":"screenwriter","a":"SKILL.md","l":260,"t":"❌ **Inconsistent character names:** Stick to ONE name per character","o":"archivo"},"b6cf18f1ea26":{"s":"screenwriter","a":"references/advanced-techniques.md","l":16,"t":"While avoiding technical camera directions in action lines, you can *suggest* camera movement through visual description and scene structure.","o":"archivo"},"f1221744d7a1":{"s":"screenwriter","a":"references/advanced-techniques.md","l":85,"t":"Each character should have distinct speech patterns:","o":"archivo"},"42187af933ee":{"s":"screenwriter","a":"references/advanced-techniques.md","l":127,"t":"Each scene should raise stakes or tension incrementally:","o":"archivo"},"38b4028efe2f":{"s":"screenwriter","a":"references/advanced-techniques.md","l":172,"t":"Use color to track emotional/narrative arc:","o":"archivo"},"5ea772208440":{"s":"screenwriter","a":"references/advanced-techniques.md","l":184,"t":"Every scene must serve multiple purposes:","o":"archivo"},"3697579b1689":{"s":"screenwriter","a":"references/advanced-techniques.md","l":202,"t":"First 10-15 seconds must grip audience:","o":"archivo"},"dcba7967bb86":{"s":"screenwriter","a":"references/pipeline-integration.md","l":20,"t":"Every scene MUST include all required metadata fields for reliable pipeline processing:","o":"archivo"},"34d356cca129":{"s":"screenwriter","a":"references/pipeline-integration.md","l":48,"t":"Use 1-3 adjectives that guide visual tone:","o":"archivo"},"06f7cfabe30d":{"s":"screenwriter","a":"references/pipeline-integration.md","l":51,"t":"Avoid: \"the character feels anxious\" (this describes internal state, not mood)","o":"archivo"},"f02d8dcae6c2":{"s":"screenwriter","a":"references/pipeline-integration.md","l":68,"t":"The `key_visuals` array should contain discrete, image-generation-friendly descriptions:","o":"archivo"},"9a04fd13f520":{"s":"screenwriter","a":"references/pipeline-integration.md","l":137,"t":"After first appearance, use consistent identifiers:","o":"archivo"},"d58376dbc7f5":{"s":"screenwriter","a":"references/pipeline-integration.md","l":140,"t":"Use character name only: \"Maya checks her phone\"","o":"archivo"},"33379bbc4b87":{"s":"screenwriter","a":"references/pipeline-integration.md","l":175,"t":"Option B: Use fractional numbering (1, 2, 2A, 3...)","o":"archivo"},"8a33756b8cb8":{"s":"screenwriter","a":"references/pipeline-integration.md","l":177,"t":"For pipeline simplicity, prefer Option A (complete renumbering).","o":"archivo"},"3172bdb34a71":{"s":"screenwriter","a":"references/pipeline-integration.md","l":222,"t":"Ensure valid XML structure:","o":"archivo"},"47f320764950":{"s":"screenwriter","a":"references/pipeline-integration.md","l":266,"t":"[ ] No technical camera directions (use visual descriptions instead)","o":"archivo"},"364c86aacbd6":{"s":"storyboard-architect","a":"SKILL.md","l":22,"t":"If the user only wants prompts for an image generator (no narrative structure), use `visual-prompt-forge` directly instead.","o":"archivo"},"7696a03e6c31":{"s":"storyboard-architect","a":"SKILL.md","l":40,"t":"Write it once, at the end of the run, and never edit it.","o":"archivo"},"8f9cad0e2224":{"s":"storyboard-architect","a":"SKILL.md","l":42,"t":"If the user asks for image prompts or HTML preview, hand off to `visual-prompt-forge` or `storyboard-html-preview`, those skills consume `shots.json` directly. Don't try to do their job here.","o":"archivo"},"8d21f65f4329":{"s":"storyboard-architect","a":"SKILL.md","l":54,"t":"Brand-lock file path | No | Use `brand-packs/_template.md` and flag the gap","o":"auditoria"},"0a6768420027":{"s":"storyboard-architect","a":"SKILL.md","l":60,"t":"Follow this sequence. Don't skip steps even if the brief seems simple.","o":"archivo"},"c7861b2bb543":{"s":"storyboard-architect","a":"SKILL.md","l":69,"t":"\"Never\" list (what this brand will never do visually)","o":"auditoria"},"8b27a216f395":{"s":"storyboard-architect","a":"SKILL.md","l":72,"t":"Aspect-ratio preferences","o":"auditoria"},"5b7b1c8fb6ae":{"s":"storyboard-architect","a":"SKILL.md","l":74,"t":"If no brand-lock is provided, copy `brand-packs/_template.md` into the output as `brand-lock.snapshot.md` with a note: `# UNCONFIGURED, using template defaults. Recommend providing a real brand-lock for production work.`","o":"auditoria"},"0b4182e7f0fc":{"s":"storyboard-architect","a":"SKILL.md","l":96,"t":"Don't fight the framework. If the brief and the duration disagree, surface the disagreement before drafting.","o":"archivo"},"37204f4e9d9d":{"s":"storyboard-architect","a":"SKILL.md","l":107,"t":"`start` / `end`, timestamps in seconds, decimal allowed. `end` must be after `start`","o":"archivo"},"bbcf9882e50b":{"s":"storyboard-architect","a":"SKILL.md","l":113,"t":"`depth_of_field`, optional, shallow / deep / rack","o":"auditoria"},"5942ba44f22f":{"s":"storyboard-architect","a":"SKILL.md","l":128,"t":"Every piece of on-screen text becomes an entry in `text-overlays.json`. Never bake text into the visual description. Each overlay has:","o":"auditoria"},"1cec4673e7f2":{"s":"storyboard-architect","a":"SKILL.md","l":137,"t":"`color`, hex (must come from brand-lock palette)","o":"auditoria"},"abc02ebdb6a8":{"s":"storyboard-architect","a":"SKILL.md","l":151,"t":"Every shot has a one-sentence rationale. Why this beat. Why this framing. Why this on-screen text. This is the audit trail. Do not skip it.","o":"archivo"},"38de07452a46":{"s":"storyboard-architect","a":"SKILL.md","l":192,"t":"Use the template at `templates/storyboard.md.tpl`. Read it before writing.","o":"archivo"},"16f6bf46f67c":{"s":"storyboard-architect","a":"SKILL.md","l":196,"t":"Must validate against `templates/shots.schema.json`. Read it before writing. The structure is:","o":"archivo"},"85e3ed23b8ae":{"s":"storyboard-architect","a":"SKILL.md","l":235,"t":"Must validate against `templates/text-overlays.schema.json`. Read it before writing.","o":"auditoria"},"4c1f6d0ef267":{"s":"storyboard-architect","a":"SKILL.md","l":305,"t":"Don't run those automatically. The user picks.","o":"archivo"},"5cff35ce456c":{"s":"storyboard-architect","a":"brand-packs/README.md","l":7,"t":"Copy `_template.md` to a new file (e.g. `acme.md`)","o":"archivo"},"e49a82b5336a":{"s":"storyboard-architect","a":"brand-packs/README.md","l":8,"t":"Fill in every field. No placeholders left behind.","o":"archivo"},"3e5b03db5bd2":{"s":"storyboard-architect","a":"brand-packs/README.md","l":9,"t":"Reference it from your storyboard requests:","o":"archivo"},"ab8ee2cc3cfb":{"s":"storyboard-architect","a":"brand-packs/README.md","l":13,"t":"The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.","o":"archivo"},"3f9aad2c4e2c":{"s":"storyboard-architect","a":"brand-packs/README.md","l":21,"t":"**Be exclusive.** The \"never\" list is more valuable than the \"always\" list. Listing what the brand will not do narrows the generator's space and produces tighter output.","o":"archivo"},"db7addc154a9":{"s":"storyboard-architect","a":"brand-packs/README.md","l":29,"t":"**`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real \"never\" list. Use this as the reference for the level of specificity production work requires.","o":"archivo"},"df43eb92b1b2":{"s":"storyboard-architect","a":"brand-packs/README.md","l":36,"t":"Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:","o":"archivo"},"c5e62839e1ee":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":25,"t":"Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.","o":"archivo"},"2f545717c91e":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":49,"t":"What this brand never does, visually or tonally. Be specific.","o":"archivo"},"e03457ae7069":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":51,"t":"never use stock photo aesthetic","o":"archivo"},"25f0ecf00da8":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":52,"t":"never use AI uncanny faces","o":"archivo"},"1acd5803bd0f":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":53,"t":"never over-saturate","o":"archivo"},"3214012dc24d":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":54,"t":"never shout in copy","o":"archivo"},"250eda4c5849":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":55,"t":"never use clip-art icons","o":"archivo"},"5ada3d9e3057":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":64,"t":"How footage and generated images should be graded. One sentence.","o":"archivo"},"25d9cd499896":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":40,"t":"never use stock photo aesthetic","o":"archivo"},"e815875bfd9e":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":41,"t":"never use AI uncanny faces","o":"archivo"},"dd6e8d6008ac":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":42,"t":"never over-saturate the cream background","o":"archivo"},"333c20110ff3":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":43,"t":"never use coral as a flood color (only as accent or signature periods)","o":"archivo"},"5aecc4ca21d4":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":44,"t":"never use em dashes in copy","o":"archivo"},"dac6a52ee58c":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":45,"t":"never use emojis in body copy","o":"archivo"},"c95b248c14c2":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":46,"t":"never use bullet points in narrative copy","o":"archivo"},"c906d8795790":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":47,"t":"never use clip-art or generic icon sets","o":"archivo"},"ba0238372a4c":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":48,"t":"never use hype words (\"game-changing\", \"revolutionary\", \"next-level\", \"comprehensive\")","o":"archivo"},"03c4f6662db6":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":49,"t":"never use exclamation points in headlines","o":"archivo"},"91020f8aff04":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":50,"t":"never default to dark mode, light mode hybrid is the brand","o":"archivo"},"26257934361a":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":51,"t":"never animate text with bouncing or wobbling, type-on, fade, or hard cut only","o":"archivo"},"65805ba83e7e":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":62,"t":"Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.","o":"archivo"},"19abf8cb5067":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":66,"t":"Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.","o":"archivo"},"d81969febc9e":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":74,"t":"prefer specific numbers over vague claims","o":"archivo"},"e1559d443197":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":75,"t":"prefer present-tense over future-tense","o":"archivo"},"f380cff82f61":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":76,"t":"prefer \"operator\" over \"creator\", \"infrastructure\" over \"agency\"","o":"archivo"},"e10409cde634":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":40,"t":"never use stock photo aesthetic","o":"archivo"},"5c3ec0c8cf75":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":41,"t":"never use AI uncanny faces","o":"archivo"},"fef9fe44ef96":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":42,"t":"never over-saturate the cream background","o":"archivo"},"4590b5aee804":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":43,"t":"never use coral as a flood color (only as accent or signature periods)","o":"archivo"},"d40b84764301":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":44,"t":"never use em dashes in copy","o":"archivo"},"478143da99e2":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":45,"t":"never use emojis in body copy","o":"archivo"},"1bbba41d8f5e":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":46,"t":"never use bullet points in narrative copy","o":"archivo"},"1249aae4215a":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":47,"t":"never use clip-art or generic icon sets","o":"archivo"},"621b3df6eb6a":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":48,"t":"never use hype words (\"game-changing\", \"revolutionary\", \"next-level\", \"comprehensive\")","o":"archivo"},"d9e264405291":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":49,"t":"never use exclamation points in headlines","o":"archivo"},"64c7eedde7cc":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":50,"t":"never default to dark mode, light mode hybrid is the brand","o":"archivo"},"38c7b73cec5b":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":51,"t":"never animate text with bouncing or wobbling, type-on, fade, or hard cut only","o":"archivo"},"4b55ac47f0e7":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":62,"t":"Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.","o":"archivo"},"ff35cc7d69fd":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":66,"t":"Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.","o":"archivo"},"995296a29fb4":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":74,"t":"prefer specific numbers over vague claims","o":"archivo"},"db692e54505e":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":75,"t":"prefer present-tense over future-tense","o":"archivo"},"5e4a95ec4d8c":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":76,"t":"prefer \"operator\" over \"creator\", \"infrastructure\" over \"agency\"","o":"archivo"},"929d3e62f0b7":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":43,"t":"never use stock photo aesthetic","o":"archivo"},"c5761942f155":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":44,"t":"never use AI uncanny faces","o":"archivo"},"f28e4507d045":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":45,"t":"never over-saturate the cream background","o":"archivo"},"3751f321730f":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":46,"t":"never use coral as a flood color (only as accent or signature periods)","o":"archivo"},"9132e55fcf5d":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":47,"t":"never use em dashes in copy (only periods, commas, semicolons)","o":"archivo"},"0f628683c6b8":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":48,"t":"never use emojis in body copy","o":"archivo"},"eff9c8392083":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":49,"t":"never use bullet points in narrative copy","o":"archivo"},"b700cf8f4dcb":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":50,"t":"never use clip-art or generic icon sets","o":"archivo"},"45e257d77c42":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":51,"t":"never use hype words (\"game-changing\", \"revolutionary\", \"next-level\", \"comprehensive\")","o":"archivo"},"ddb048e79808":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":52,"t":"never use exclamation points in headlines","o":"archivo"},"eb006504840c":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":53,"t":"never default to dark mode, light mode hybrid is the brand","o":"archivo"},"783ff683393c":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":54,"t":"never animate text with bouncing or wobbling, type-on, fade, or hard cut only","o":"archivo"},"8cea74bc14b1":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":55,"t":"never break the eye line between subject and the implied \"operator perspective\"","o":"archivo"},"f6abdd226436":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":66,"t":"Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup. Skin tones warm but not orange. Greens kept slightly desaturated to push focus to subject.","o":"archivo"},"d8a47abf50ca":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":70,"t":"Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only, no fancy wipes, no zooms.","o":"archivo"},"e9560a0de1ac":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":82,"t":"prefer specific numbers over vague claims (\"48 hours\" not \"fast\", \"30 minutes a week\" not \"a little time\")","o":"archivo"},"cc0c55fe6755":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":83,"t":"prefer present-tense over future-tense","o":"archivo"},"c1a8c5479b88":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":84,"t":"prefer \"operator\" over \"creator\", \"infrastructure\" over \"agency\", \"system\" over \"service\"","o":"archivo"},"7e5f2e473cd3":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":3,"t":"Pick one. Don't invent a new one unless the brief genuinely doesn't fit. Document the choice in `storyboard.md`.","o":"archivo"},"f32c786bfbff":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":9,"t":"**Pain**, name the audience's actual problem in their actual language. Concrete, not abstract. \"Your content feels random\" not \"marketing inefficiency.\"","o":"archivo"},"d329c7d38124":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":10,"t":"**Reframe**, flip the problem on its head. The point is *not* what they thought it was. \"You don't have a content problem. You have an infrastructure problem.\"","o":"archivo"},"b55cf418fc3a":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":11,"t":"**Promise**, what life looks like on the other side. Specific, verifiable, time-bound when possible.","o":"archivo"},"e5235864c6bb":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":16,"t":"Use when: ad creative, landing-page hero video, conversion-focused social.","o":"archivo"},"0206d6df0cc3":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":22,"t":"**World**, set the context. Who lives in this world. What's broken about it.","o":"archivo"},"9b3fba335e1b":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":23,"t":"**Hero**, the product/founder/methodology arrives. Show what it does, not what it is.","o":"archivo"},"e4b20db35b44":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":24,"t":"**Transformation**, the world changes. Show before/after at scale.","o":"archivo"},"cfaecb7f5fa7":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":29,"t":"Use when: product launches, brand films, anchor pieces.","o":"archivo"},"39b17554140c":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":35,"t":"**Hook**, a one-line provocation (0–2s)","o":"archivo"},"ec4f8b7428c7":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":36,"t":"**Stakes**, why this matters (2–8s)","o":"archivo"},"3bdf77c5a1e7":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":37,"t":"**Insight**, the actual point (8–20s for 30s, 8–40s for 60s)","o":"archivo"},"6154ed831bf3":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":38,"t":"**Proof**, one concrete example or data point","o":"archivo"},"6be1e3549be6":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":39,"t":"**CTA**, what to do next, narrow and specific","o":"archivo"},"ca19a04f7f16":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":41,"t":"Use when: founder content, thought leadership, personal-brand pieces.","o":"archivo"},"e707043ad741":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":47,"t":"**Wide claim**, the headline take","o":"archivo"},"61117f1e1435":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":48,"t":"**Zoom 1**, one layer of nuance","o":"archivo"},"bcd48bb1ab67":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":49,"t":"**Zoom 2**, the layer underneath that","o":"archivo"},"409a346f14c6":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":50,"t":"**Snap-back**, return to the wide claim, now reframed by the zooms","o":"archivo"},"e4456cb5dc55":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":54,"t":"Use when: opinion videos, kinetic-type pieces, social-native commentary.","o":"archivo"},"86733dae8e0e":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":60,"t":"**Problem state**, what someone is stuck on","o":"archivo"},"4b795000d239":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":61,"t":"**Reveal**, the technique or trick","o":"archivo"},"a68a06f84fe6":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":62,"t":"**Walk-through**, apply it step by step","o":"archivo"},"0357fe063806":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":63,"t":"**Result**, the after-state, side-by-side with before","o":"archivo"},"08af446ba369":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":65,"t":"Use when: tutorials, demo videos, training content.","o":"archivo"},"428f5eebff7b":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":3,"t":"Text on screen is a load-bearing decision. Most storyboards over-text. The default should be: **does this shot need text to land?** If the visual carries the meaning, text dilutes.","o":"archivo"},"a268ba75d0b5":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":7,"t":"**Auto-play-mute environments.** Social feeds. Text replaces VO.","o":"archivo"},"efdeec778e0f":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":8,"t":"**Concept compression.** A short phrase lands harder than 4 seconds of narration.","o":"archivo"},"90221fe5fe0f":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":9,"t":"**Stat or proof point.** Numbers stick visually in a way they don't audibly.","o":"archivo"},"48c59084ee78":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":10,"t":"**Beat punctuation.** A single word or phrase that lands on a music hit.","o":"archivo"},"9f529931cccc":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":11,"t":"**CTA.** The action you want the viewer to take.","o":"archivo"},"c1fb4192e05a":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":15,"t":"**Restating the VO.** If the voice says it, the text is noise.","o":"archivo"},"84655e935767":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":16,"t":"**Decorative copy.** \"Moments matter\" floating over b-roll. Cut it.","o":"archivo"},"84f1791a022e":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":17,"t":"**Brand vibing.** Product names everywhere. Logo lockup in the CTA covers this.","o":"archivo"},"67f2beaeb3ef":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":18,"t":"**Filler beats.** If the shot doesn't need text, leave it clean.","o":"archivo"},"4ff066eab26b":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":26,"t":"When a shot has on-screen text, the **shot subject must reserve space for it**. This is enforced at storyboard time, not generation time.","o":"archivo"},"7a7cb7a4a5e8":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":43,"t":"`{x: %, y: %}` | Custom, only when the standard positions don't fit","o":"archivo"},"9f4f78bc99a2":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":63,"t":"Avoid stacking animations. Pick one per overlay.","o":"archivo"},"4cbacbc0b8fa":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":67,"t":"The `color` field of every text overlay must be a hex value that exists in the brand-lock palette. If you find yourself wanting a color that's not in the palette, the answer is not to add it, the answer is to pick a different overlay style or shot composition.","o":"auditoria"},"d7940c08b552":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":71,"t":"Same: every `font` field must reference a font defined in brand-lock typography. Two fonts max per project (display + body). More than that and the brand stops being recognizable.","o":"auditoria"},"717463d29f8f":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":75,"t":"Already covered in timing-rules.md but worth repeating: text needs to be on screen long enough for someone to read it twice. Calculate, then verify. Don't eyeball.","o":"archivo"},"7268a7328d89":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":3,"t":"Controlled vocabulary. Use these exact terms in `shots.json`. Generators interpret loose language inconsistently, locked vocabulary survives translation.","o":"archivo"},"74926ea5bff7":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":11,"t":"`MCU` | Medium close-up | Head and shoulders","o":"archivo"},"6b3fa7bb2923":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":29,"t":"Default to eye-level. Use the others deliberately, not for variety.","o":"archivo"},"5528555145f9":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":50,"t":"`shallow` | Subject sharp, background blurred","o":"archivo"},"e4e41d7c48e9":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":54,"t":"Default to shallow for talking-head, deep for environmental and schematic.","o":"archivo"},"03a00602482e":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":58,"t":"Don't redefine per shot. Define once in `series_lock.lighting`. Examples:","o":"archivo"},"05f30ccb87c3":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":90,"t":"**brand_lock**, locked across the entire project. Palette, type, \"never\" list.","o":"auditoria"},"22f6035ce704":{"s":"storyboard-architect","a":"references/timing-rules.md","l":3,"t":"Pacing is math, not feel. Use these as defaults. Override only with reason documented in rationale.","o":"archivo"},"32344b412ad5":{"s":"storyboard-architect","a":"references/timing-rules.md","l":19,"t":"The hook is 0–2s. Always. There are no exceptions in short-form content. Specifically:","o":"archivo"},"e67edc98e31f":{"s":"storyboard-architect","a":"references/timing-rules.md","l":21,"t":"9:16 social: first frame must telegraph the topic. Auto-play on mute means the first half-second is fighting a swipe.","o":"archivo"},"5e8113658ff6":{"s":"storyboard-architect","a":"references/timing-rules.md","l":24,"t":"The hook shot framing should be high-contrast against the shots that follow. If shot 2 is MS, shot 1 should not be MS. Visual contrast = retention.","o":"archivo"},"7e40e9d57114":{"s":"storyboard-architect","a":"references/timing-rules.md","l":30,"t":"Last shot should hold long enough for someone to read the CTA text and act","o":"archivo"},"5acc0a53e64b":{"s":"storyboard-architect","a":"references/timing-rules.md","l":31,"t":"Don't put motion on the CTA shot, let the text breathe","o":"archivo"},"8499e1ad407c":{"s":"storyboard-architect","a":"references/timing-rules.md","l":36,"t":"A text overlay needs to be on screen long enough to be **read twice**. Not once, twice. Why: viewers are skimming, eyes don't always lock on first frame.","o":"archivo"},"8a7cde5fbf44":{"s":"storyboard-architect","a":"references/timing-rules.md","l":47,"t":"Shorten the copy","o":"archivo"},"1740a84f47a3":{"s":"storyboard-architect","a":"references/timing-rules.md","l":48,"t":"Carry the text across two consecutive shots (text persists during cut)","o":"archivo"},"6c398f45603b":{"s":"storyboard-architect","a":"references/timing-rules.md","l":49,"t":"Lengthen the shot","o":"archivo"},"6c97051eb055":{"s":"storyboard-architect","a":"references/timing-rules.md","l":51,"t":"Do not under-time text. It's the most common storyboard failure.","o":"archivo"},"e7f6806c93e3":{"s":"storyboard-architect","a":"references/timing-rules.md","l":79,"t":"Sum of `(end - start)` across all shots equals project duration ±0.1s","o":"archivo"},"35389a2e7e9a":{"s":"storyboard-architect","a":"references/timing-rules.md","l":80,"t":"No shot has `start >= end`","o":"archivo"},"993e2cd1eec5":{"s":"storyboard-architect","a":"references/timing-rules.md","l":81,"t":"No two shots overlap","o":"archivo"},"40867e840a40":{"s":"storyboard-architect","a":"references/timing-rules.md","l":82,"t":"First shot starts at 0.0","o":"archivo"},"e620d729b974":{"s":"storyboard-architect","a":"references/timing-rules.md","l":83,"t":"Last shot ends at project duration","o":"archivo"},"0678f6cbf749":{"s":"storyboard-architect","a":"references/timing-rules.md","l":84,"t":"Every text overlay's `enter.at` is ≥ its shot's `start`","o":"archivo"},"5d267e42e94d":{"s":"storyboard-architect","a":"references/timing-rules.md","l":85,"t":"Every text overlay's `exit.at` is ≤ its shot's `end` (or carries to a flagged successor shot)","o":"archivo"},"18b6449fb38c":{"s":"storyboard-architect","a":"references/timing-rules.md","l":86,"t":"Every text overlay's on-screen duration ≥ read-twice threshold","o":"archivo"},"090ccfb96455":{"s":"storyboard-html-preview","a":"SKILL.md","l":10,"t":"The constraint is non-negotiable: **single file, no build step, no server, works offline.** Any time the output requires \"run this build command\" or \"host this somewhere,\" the skill has failed.","o":"archivo"},"629bb2d205d3":{"s":"storyboard-html-preview","a":"SKILL.md","l":40,"t":"An entry in `shot.assets.generated` marked `accepted: true`","o":"archivo"},"b9f0e777f95a":{"s":"storyboard-html-preview","a":"SKILL.md","l":41,"t":"The newest entry in `shot.assets.generated`","o":"archivo"},"09e4367e3b97":{"s":"storyboard-html-preview","a":"SKILL.md","l":82,"t":"The HTML preview should *feel* like the brand without going overboard. Quiet branding, not loud.","o":"archivo"},"8a2c11a5fc35":{"s":"storyboard-html-preview","a":"SKILL.md","l":86,"t":"Use `templates/preview.html.tpl` as the structural template. Read it before generating.","o":"archivo"},"410599a6e6d1":{"s":"storyboard-html-preview","a":"SKILL.md","l":159,"t":"frames as base64. Ask the user which they prefer if frames are present.","o":"archivo"},"e3ddb1d823f5":{"s":"storyboard-html-preview","a":"SKILL.md","l":211,"t":"Ensure text overlays render legibly","o":"archivo"},"32701372f5d1":{"s":"storyboard-html-preview","a":"SKILL.md","l":212,"t":"Use black-on-white where brand colors won't print well","o":"archivo"},"6975e2ff7171":{"s":"storyboard-html-preview","a":"SKILL.md","l":214,"t":"The user should be able to hit Cmd-P / Ctrl-P and get a clean PDF.","o":"archivo"},"77570da551dd":{"s":"storyboard-html-preview","a":"SKILL.md","l":224,"t":"No CDN scripts. No Google Fonts. No external CSS frameworks. The file must work with no internet connection.","o":"archivo"},"d86f1629a7f6":{"s":"storyboard-html-preview","a":"SKILL.md","l":230,"t":"Hit Cmd-P. The result should be a clean PDF. If layout breaks across page boundaries, the print stylesheet is broken.","o":"archivo"},"90b1a187484f":{"s":"storyboard-html-preview","a":"SKILL.md","l":234,"t":"Use brand colors as accents, not as full backgrounds. The reviewer's job is to read the storyboard, not admire the design. Subtle.","o":"archivo"},"9f76efb872f5":{"s":"storyboard-html-preview","a":"SKILL.md","l":238,"t":"Stakeholders open links on phones. The HTML should be readable on mobile without horizontal scroll. Simple responsive CSS.","o":"archivo"},"2d5d435df3ef":{"s":"video","a":"SKILL.md","l":16,"t":"**Still keyframes, character sheets, animatic panels** to feed the video pipeline: use the sibling `image` skill, then return with the keyframes.","o":"archivo"},"f21bcfe2dfbc":{"s":"video","a":"SKILL.md","l":76,"t":"If any shot fails, fix before sending. This is the step the user has had to enforce repeatedly. Do not skip it.","o":"archivo"},"99b3186877c9":{"s":"video","a":"SKILL.md","l":97,"t":"Prefer: ready-to-copy prompts, clear section labels, production language, motivated camera and light direction, strict continuity blocks, model-specific syntax, direct fixes.","o":"archivo"},"54b8e873fa4e":{"s":"video","a":"SKILL.md","l":99,"t":"Avoid: long theory unless asked, academic lectures, vague inspiration, decorative jargon, \"cinematic masterpiece\" filler, prompts without camera and light, prompts without continuity, stacking more than two director references, abstract emotions without physical translation.","o":"archivo"},"1abf520d87fe":{"s":"video","a":"references/animatic-keyframes.md","l":3,"t":"This is the still-panel layer. A storyboard keyframe is not a frame grab of footage — it is a single drawn image that must carry one story-beat with **no motion and (usually) no face**. The animatic hangs off these panels. A panel that only looks good is wallpaper; a panel must report its story function, its drama, and the motion it cannot show, all frozen.","o":"archivo"},"24fe340cb58e":{"s":"video","a":"references/animatic-keyframes.md","l":25,"t":"In an animatic the **panel is the unit, not the shot.** A shot has duration, motion, and sound to carry its function across time. A keyframe has one frozen image and must carry the same function in a single glance. So every panel does four things at once, in one still:","o":"archivo"},"43a9c422d34f":{"s":"video","a":"references/animatic-keyframes.md","l":29,"t":"**One emotion** — routed through metal, rubber, light, or anatomy, never named (`dramaturgy.md` §2). Mixed signals = no signal.","o":"archivo"},"b9cd34ffcb70":{"s":"video","a":"references/animatic-keyframes.md","l":77,"t":"**Ritual / staging** (quiet) | 1 hero panel, held | 1 panel living 1.5-2.5s | A silent beat is monolithic. Do not subdivide it — its power is that nothing moves while the world holds its breath. One symmetric \"breath\" frame, most negative space, least motion.","o":"archivo"},"b04a79b44100":{"s":"video","a":"references/animatic-keyframes.md","l":80,"t":"**Contest** (sustained roar) | alternating | fragment-cluster ↔ one held detail | Never two bang-clusters back to back. Between every burst, one held quiet panel — loud only works next to quiet.","o":"archivo"},"6d32d7171722":{"s":"video","a":"references/animatic-keyframes.md","l":83,"t":"**Allocation rule.** A 30s spot lands at ~18-26 panels. Plot the board as a descending duration staircase (≈2.5s → 0.5s → 4fr), broken only by the one pre-launch pause and the one post-finish hold. The board should *read* as an accelerating tachometer even on mute. Give a beat a micro-burst only when the audio detonates; everywhere else, one panel that holds is stronger than three that scatter.","o":"archivo"},"0fb332eaeff4":{"s":"video","a":"references/animatic-keyframes.md","l":89,"t":"A keyframe cannot ramp, cut, or whip. Each missing move resolves into one of **six frozen cues**. Never write \"motion\" — write the artifact motion leaves behind. State the cue in the card's *Motion-as-still* field and again in the prompt's camera/light clause; models default to over-clean stabilization and will sand the speed off unless told (§7).","o":"archivo"},"84e4c557c5f1":{"s":"video","a":"references/animatic-keyframes.md","l":97,"t":"**Sharp-subject / blurred-field separation** | Shallow-DOF macro: knuckle, needle, latch razor-sharp, everything else dissolved. Isolation = the cut-to-detail frozen. | insert chain, crash-zoom arrival, hip-hop CU","o":"archivo"},"9116b6b7205f":{"s":"video","a":"references/animatic-keyframes.md","l":115,"t":"A face does four jobs: shows the feeling, shows where it looks, shows the cost, shows the decision. Faces banned, redistribute: **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space** (§6 and `dramaturgy.md` §2). Assign one job per panel and tag it. The emotion must already be frozen *inside the object* — a still cannot let motion blur do the emo","o":"archivo"},"22aed852b261":{"s":"video","a":"references/animatic-keyframes.md","l":122,"t":"Use the substitution table as the core deliverable — when the script wants an emotion and no face is available, render this object at this crop. Cold palette throughout.","o":"archivo"},"5bea8ddfb87c":{"s":"video","a":"references/animatic-keyframes.md","l":144,"t":"**Depth-layer jobs (FG / MG / BG).** Write the prompt in three explicit depth clauses, each with a stated job. This is the engine of \"reads in one glance, rewards a second\" (extends `dramaturgy.md` §10 into a single still). If all three planes carry the same blur or scale, you have one plane, not three — force a sharp MG subject against a soft FG frame and a soft BG stake (shallow DOF is the panel","o":"archivo"},"c241a02cc037":{"s":"video","a":"references/animatic-keyframes.md","l":154,"t":"**Centerline spine, then break symmetry** — emotion: a single dominant axis (lane stripe, the Christmas Tree, a dividing wall) gives the eye a rail and makes even a chaotic frame readable; breaking it the instant one car noses ahead reads as momentum. — seen: Anderson centers for instant legibility; Bong breaks balanced staging to show a power shift. — *in a keyframe*: build one head-on symmetric ","o":"archivo"},"921f5446334f":{"s":"video","a":"references/animatic-keyframes.md","l":183,"t":"**Render audio as physical consequence, never as a named sound.** \"Loud engine\" is banned filler (`dramaturgy.md` §2) — prompt \"heat-haze warp off the headers, exhaust flame, chassis squat, sidewall wrinkle\" instead.","o":"archivo"},"d5feae1b60b8":{"s":"video","a":"references/animatic-keyframes.md","l":225,"t":"[ ] **Cold palette held** — steel/cyan/magenta/mercury-white, red and green as accents only, amber ≤15% and point-source (toxic, never cozy). One motivated source, ~70% unlit, one hard specular hit. Texture named (grain, halation, one flare), not \"clean.\"","o":"archivo"},"6f5a79ae61af":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":3,"t":"Use precise production language. \"Cinematic\" is not a direction. \"35mm, slow push-in, warm window key from frame-left\" is.","o":"archivo"},"617b9596ef1d":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":31,"t":"over-the-shoulder","o":"archivo"},"a3c2614e6e5e":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":78,"t":"shallow depth of field.","o":"archivo"},"84e552ce62b9":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":138,"t":"Define palette with concrete colors. Never write \"cinematic colors.\"","o":"archivo"},"0278247a92b4":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":246,"t":"Rules of use. Name the transition and the exact moment it fires. One transition type per cut. When the choice is open, delegate: \"choose the most suitable from [natural cut / occlusion mask / match cut] for the style of this film.\"","o":"archivo"},"4594046fc713":{"s":"video","a":"references/dramaturgy.md","l":3,"t":"This is the mandatory layer. A beautiful frame without dramaturgy is wallpaper. Every prompt built by this skill must pass the dramaturgy check before it is sent to the user.","o":"archivo"},"f2664fed4b35":{"s":"video","a":"references/dramaturgy.md","l":45,"t":"The scene formula tells you **what a scene is**. The Details Law tells you **how every shot must be written**. Skip it and even a perfect dramaturgical structure produces mush on screen.","o":"archivo"},"fe8ae4c731e8":{"s":"video","a":"references/dramaturgy.md","l":53,"t":"**Environmental pressure.** A physical fact about the space that carries the emotion. Cold refrigerator light. Wet asphalt. Flickering ceiling tube. Steam from the kettle. Rain on one specific windowpane. A buzzing AC unit. Tight corridor walls. Mirror reflection. (See §9 — Environment plays.)","o":"archivo"},"291a35a705ad":{"s":"video","a":"references/dramaturgy.md","l":54,"t":"**Physical micro-action on the body.** The emotion translated into the actor's body. Jaw locks. Knuckles whiten. Lips press flat. Eyes drop a quarter-inch. He swallows hard. Fingers curl against the doorframe. The actor's body is the only place where feelings render — names of feelings do not.","o":"archivo"},"adc3e3d51477":{"s":"video","a":"references/dramaturgy.md","l":55,"t":"**Sound anchor or visual motif.** A recurring perceptual hook tied to the spine of the piece. Stomach growl repeated three times. Reflection in dark glass on every transition. The same musical sting at every Crack beat. The clock's second hand. Footsteps in an empty corridor.","o":"archivo"},"435fff89e7d5":{"s":"video","a":"references/dramaturgy.md","l":81,"t":"Every shot must do at least one of three things. If it does none, delete it.","o":"archivo"},"dbb9069efcc9":{"s":"video","a":"references/dramaturgy.md","l":93,"t":"**Emotion (51%).** Does the cut honor the emotional truth of the moment. What does the viewer feel now vs. what they should feel next.","o":"archivo"},"5d494f11d5ec":{"s":"video","a":"references/dramaturgy.md","l":94,"t":"**Story (23%).** Does the cut advance story or reveal character.","o":"archivo"},"09ecf6f81ee5":{"s":"video","a":"references/dramaturgy.md","l":95,"t":"**Rhythm (10%).** Does the cut fall on a musical beat of the scene.","o":"archivo"},"94cb46e0cdd8":{"s":"video","a":"references/dramaturgy.md","l":96,"t":"**Eye-trace (7%).** Where is the viewer's gaze at the moment of the cut. Does the new shot receive that gaze naturally.","o":"archivo"},"0cf6378a2c57":{"s":"video","a":"references/dramaturgy.md","l":97,"t":"**2D plane (5%).** Does the cut respect the axis of screen direction.","o":"archivo"},"dd109f775c6c":{"s":"video","a":"references/dramaturgy.md","l":98,"t":"**3D space (4%).** Does the cut respect the geometry of the real location.","o":"archivo"},"5b4e8d3dcda1":{"s":"video","a":"references/dramaturgy.md","l":116,"t":"Good. \"He edges toward the window but his shoulder stays angled back toward her, as if the conversation still holds him.\"","o":"archivo"},"2be8adc698a8":{"s":"video","a":"references/dramaturgy.md","l":150,"t":"Good. \"Push-in starts on 'I don't know' and stops on her jaw locking.\"","o":"archivo"},"c7fa86763233":{"s":"video","a":"references/dramaturgy.md","l":154,"t":"Spielberg principle. Even in chaos, the viewer must know.","o":"archivo"},"f88d89dd2268":{"s":"video","a":"references/dramaturgy.md","l":200,"t":"Adjust for 30s or 15s by compressing proportionally. Never skip the Crack or the Impact.","o":"archivo"},"6be9ddc67dea":{"s":"video","a":"references/dramaturgy.md","l":251,"t":"**Eye trace.** Where the viewer's gaze should land in the first 0.3s.","o":"archivo"},"c2e0a3b45412":{"s":"video","a":"references/dramaturgy.md","l":276,"t":"Always insert at least one pause before the biggest cut.","o":"archivo"},"01d9db058ef3":{"s":"video","a":"references/dramaturgy.md","l":347,"t":"Is the scene formula complete? (desire + obstacle + geometry + gaze + rhythm)","o":"archivo"},"75eee4c9c72b":{"s":"video","a":"references/dramaturgy.md","l":348,"t":"Does every shot pass the three-detail check? (environmental pressure + physical micro-action + sound or visual motif)","o":"archivo"},"c52b9a2cbc96":{"s":"video","a":"references/dramaturgy.md","l":349,"t":"Does every shot do one of the three jobs? (change emotion, advance action, increase pressure)","o":"archivo"},"cd71da05d199":{"s":"video","a":"references/dramaturgy.md","l":350,"t":"Is there a motivated reason for every camera move?","o":"archivo"},"e51237770b8c":{"s":"video","a":"references/dramaturgy.md","l":351,"t":"Is the spatial geometry readable?","o":"archivo"},"eba7494935d3":{"s":"video","a":"references/dramaturgy.md","l":352,"t":"Are the five anchors named? (emotion, motif, object, break, final image)","o":"archivo"},"4ddd5b7aae62":{"s":"video","a":"references/fixes-and-skeletons.md","l":58,"t":"For Kling. Use Element Binding with 3-4 reference images (front, side, three-quarter).","o":"archivo"},"1df0239fdbc2":{"s":"video","a":"references/fixes-and-skeletons.md","l":98,"t":"For Seedance and Veo. Use positive phrasing.","o":"archivo"},"87d2484dd6cf":{"s":"video","a":"references/fixes-and-skeletons.md","l":121,"t":"Fix. Avoid style words like \"hyperrealistic 8k masterpiece.\" These push the model into AI-art territory. Use production language instead.","o":"archivo"},"1863ac937570":{"s":"video","a":"references/fixes-and-skeletons.md","l":147,"t":"For forward extensions, the standard clause: \"prohibit rigid cutting, prohibit objects appearing out of thin air.\"","o":"archivo"},"d98803cf48d0":{"s":"video","a":"references/fixes-and-skeletons.md","l":157,"t":"On Seedance 2.5 and Veo this is reliable. On Seedance 1.x/2.0 and Kling, also avoid mentioning any on-screen text or score you do not want — mentions summon them.","o":"archivo"},"8f83dc97e5ba":{"s":"video","a":"references/fixes-and-skeletons.md","l":230,"t":"Keep character continuity.","o":"archivo"},"8ea66f62d954":{"s":"video","a":"references/fixes-and-skeletons.md","l":231,"t":"Keep story action.","o":"archivo"},"13635ca633f1":{"s":"video","a":"references/fixes-and-skeletons.md","l":232,"t":"Keep shot timecodes (where relevant).","o":"archivo"},"508966ae84b9":{"s":"video","a":"references/fixes-and-skeletons.md","l":233,"t":"Keep lighting.","o":"archivo"},"7dabe8b7b479":{"s":"video","a":"references/fixes-and-skeletons.md","l":234,"t":"Keep camera.","o":"archivo"},"b755a79d8702":{"s":"video","a":"references/fixes-and-skeletons.md","l":235,"t":"Keep editing grammar.","o":"archivo"},"2d6cacf87d0d":{"s":"video","a":"references/fixes-and-skeletons.md","l":237,"t":"Remove philosophy and meta-commentary.","o":"archivo"},"c485717d92a0":{"s":"video","a":"references/fixes-and-skeletons.md","l":238,"t":"Remove extra adjectives.","o":"archivo"},"f1cf3ccb4d13":{"s":"video","a":"references/fixes-and-skeletons.md","l":239,"t":"Remove director references.","o":"archivo"},"a7febb0fdf00":{"s":"video","a":"references/fixes-and-skeletons.md","l":249,"t":"One ready-to-copy prompt for one generation. Use the appropriate model skeleton.","o":"archivo"},"61f2696d823a":{"s":"video","a":"references/fixes-and-skeletons.md","l":274,"t":"Missing direction (camera, light, continuity).","o":"archivo"},"179286c8c088":{"s":"video","a":"references/fixes-and-skeletons.md","l":276,"t":"Model-specific mismatches (wrong syntax for the chosen model).","o":"archivo"},"c16f3957c655":{"s":"video","a":"references/fixes-and-skeletons.md","l":277,"t":"Stronger version. Rewritten prompt, ready to copy.","o":"archivo"},"a82de4fa4979":{"s":"video","a":"references/fixes-and-skeletons.md","l":294,"t":"Structured scene-by-scene JSON. Use for complex continuity. See `references/veo.md` section 6.","o":"archivo"},"d85e439effb2":{"s":"video","a":"references/kling.md","l":7,"t":"**Kling 3.0 — multi-shot, native audio, 15s (read first if user is on 3.0)**","o":"archivo"},"0809eafc4ffb":{"s":"video","a":"references/kling.md","l":65,"t":"Introduce every character and key object at the **start** of the prompt, before any shot description. Use unique consistent identifiers — the same label survives across all shots:","o":"archivo"},"bb25b6a212a2":{"s":"video","a":"references/kling.md","l":93,"t":"Each shot must answer: **framing + subject + motion**. Empty shot descriptions (\"static frame, ambient mood\") collapse into one continuous take.","o":"archivo"},"71e86bdfe510":{"s":"video","a":"references/kling.md","l":99,"t":"**P1. Structured naming.** Use unique identifiers per character.","o":"archivo"},"a4313d46162b":{"s":"video","a":"references/kling.md","l":109,"t":"✓ `[Character B, clear fearful voice]: \"Don't open it.\"`","o":"archivo"},"9e30b0899784":{"s":"video","a":"references/kling.md","l":112,"t":"**P4. Temporal control between lines.** Use linking words to prevent dialogue from merging.","o":"archivo"},"7d81fcd5ccc0":{"s":"video","a":"references/kling.md","l":113,"t":"✓ \"Character A: 'I won't ask again.' **Immediately,** Character B: 'You don't have to.'\"","o":"archivo"},"21472873e0ca":{"s":"video","a":"references/kling.md","l":130,"t":"Use these terms directly — the model treats them as instructions, not flavor:","o":"archivo"},"c9b8d9532823":{"s":"video","a":"references/kling.md","l":138,"t":"In the Kling app, Master Shot presets (\"Move Forward and Zoom Up\" etc.) are more stable than hand-written camera prose and save credits — prefer them for standard moves, prose for motivated ones.","o":"archivo"},"4286109b9522":{"s":"video","a":"references/kling.md","l":142,"t":"If the task hits any of these — **use Kling 3.0 over earlier Kling**:","o":"archivo"},"8b8795ac59fd":{"s":"video","a":"references/kling.md","l":156,"t":"`duration` — per-shot durations must sum to ≤ 15s.","o":"archivo"},"eeae0374284b":{"s":"video","a":"references/kling.md","l":175,"t":"For Kling 3.0, use the multi-shot structure from section 3 instead.","o":"archivo"},"5c7946d7fd9f":{"s":"video","a":"references/kling.md","l":189,"t":"Kling has a dedicated negative prompts field. The field auto-interprets input as exclusion. Do not write \"no X\". Write the thing itself.","o":"archivo"},"15b3f8595289":{"s":"video","a":"references/kling.md","l":220,"t":"Even lighting. Avoid hard shadows. The AI can mistake them for permanent facial features.","o":"archivo"},"7a47e689454a":{"s":"video","a":"references/kling.md","l":232,"t":"A character element takes either a **3-8s video** (the model extracts both appearance and voice) or up to **4 multi-angle stills** (front, three-quarter, profile, back), plus optional **voice binding** (5-30s audio clip). Once bound, the voice belongs to the subject — do not re-describe it in the prompt.","o":"archivo"},"d94be792c74d":{"s":"video","a":"references/kling.md","l":235,"t":"Cost of the feature: several practitioners report visible image-quality degradation the moment elements/references are enabled. Use elements only when consistency actually matters; for one-off clips, in-prompt labels are cleaner.","o":"archivo"},"0db6e0a2de52":{"s":"video","a":"references/kling.md","l":241,"t":"Critical rule. The text prompt MUST match the brush motion. If you brush a river flowing and write \"stagnant pond\" the model tears itself apart. Align prompt verbs with brush directions.","o":"archivo"},"1e5d66901508":{"s":"video","a":"references/kling.md","l":245,"t":"Copy motion from a reference video. Use when you need specific performance or choreography (dance, martial arts, specific gait). The prompt then focuses on subject description only, the reference handles motion.","o":"archivo"},"36686df1386d":{"s":"video","a":"references/kling.md","l":249,"t":"Keep the prompt short (20-40 words). Focus only on motion. Do not re-describe static elements the model already sees.","o":"archivo"},"7d3ab7f4ba2a":{"s":"video","a":"references/kling.md","l":273,"t":"Fix. Upload 3-4 reference images to Element Library. Use Bind Elements in the settings.","o":"archivo"},"cf73cec68544":{"s":"video","a":"references/kling.md","l":289,"t":"Fix. Make shot boundaries explicit: `Shot 1 (0-3s). ... Shot 2 (3-6s). ...`. Each shot description must include a different framing or camera angle. If two adjacent shots share both framing and angle, the model merges them.","o":"archivo"},"85c33c12c479":{"s":"video","a":"references/kling.md","l":301,"t":"Fix. Strip references to the essential ones only; for one-off clips prefer in-prompt `[Character A: ...]` labels over elements. Accept the trade: elements buy consistency, not fidelity.","o":"archivo"},"4b9361768f1a":{"s":"video","a":"references/kling.md","l":305,"t":"Fix. Give each character its own element (or its own labeled identity block). Never let two speaking characters share one visual description.","o":"archivo"},"f876e8f2e5cb":{"s":"video","a":"references/patterns-and-genres.md","l":17,"t":"Use for tension builds, reveals, dramatic emphasis.","o":"archivo"},"5a27254127bb":{"s":"video","a":"references/patterns-and-genres.md","l":25,"t":"Use for psychological pressure, internal conflict, impending bad news.","o":"archivo"},"5465eb46d054":{"s":"video","a":"references/patterns-and-genres.md","l":33,"t":"Use for revealing a hidden element, exploration, search.","o":"archivo"},"240a672f7a78":{"s":"video","a":"references/patterns-and-genres.md","l":41,"t":"Use for comedic or dramatic disaster. Tiny object failures play bigger than explosions.","o":"archivo"},"5eaea7d005f0":{"s":"video","a":"references/patterns-and-genres.md","l":49,"t":"Use for ads with a hero product.","o":"archivo"},"4c683ca1e1ef":{"s":"video","a":"references/patterns-and-genres.md","l":57,"t":"Use for rhythmic repetition, transformation, performance.","o":"archivo"},"fae5c2bff912":{"s":"video","a":"references/patterns-and-genres.md","l":168,"t":"Inside each 5-second prompt, use timecodes.","o":"archivo"},"de49559afcec":{"s":"video","a":"references/patterns-and-genres.md","l":184,"t":"Use timecoded structure for Seedance and Veo. Kling prefers flowing prose.","o":"archivo"},"94114b6c3c86":{"s":"video","a":"references/patterns-and-genres.md","l":188,"t":"When moving from clip N to clip N+1, the first beat of the new clip should match the final beat of the previous clip. Character in same pose. Same light. Same color temperature. This is what makes them cut together cleanly in the editor.","o":"archivo"},"00552d374a9c":{"s":"video","a":"references/race-and-speed.md","l":28,"t":"**Authentic speed, never CGI-clean or sped-up.** Build velocity into the static composition (§3); never lean on a ramp to rescue a dead frame. Over-crank, glass-smooth stabilization and post speed-ramps read subconsciously as \"ad-speed\" and drain all threat. Squat, lifted nose, slick wrinkle, smeared rim — the physics has to be visible in the still.","o":"auditoria"},"47dd1d977a21":{"s":"video","a":"references/race-and-speed.md","l":29,"t":"**Detail is the emotion.** Faces banned, feeling renders only on a knuckle, a needle, a pedal, smoke, or a sweat bead (`dramaturgy.md` §2; the full substitution method is `animatic-keyframes.md` §5). A hand mid-grip is the no-face equivalent of a close-up on the eyes. No abstract \"motion\", no named feeling.","o":"auditoria"},"a2680889ec7c":{"s":"video","a":"references/race-and-speed.md","l":30,"t":"**One governing visual promise per piece.** A 30s cut earns cohesion from a single conceit: everything through reflections in painted metal, or everything through circles (tach → headlight → bulb → wheel), or everything as machine-talks / no-music. Kon's \"one visual principle\". Name it before boarding.","o":"auditoria"},"5e64b7c7d357":{"s":"video","a":"references/race-and-speed.md","l":31,"t":"**Beat-locked cutting.** Loudness in the audio = shot count on the board (§8; the density ladder itself is `animatic-keyframes.md` §3). Silence = one held panel. Bang = a burst of 4–8-frame micro-panels. Cut length is engine RPM made visual: idle = long panels, redline = collapsing panels toward the green.","o":"auditoria"},"1f3f073247b7":{"s":"video","a":"references/race-and-speed.md","l":32,"t":"**Cold combative palette** (§7). Steel blue, cyan, magenta, dirty mercury-white; **red as danger accent only** (brake glow, redline, tail-lights, the Tree's bulbs). No warm cozy amber wash — warmth appears only as toxin. Steal Tony Scott's grain, contrast and overexposure; **discard his warm grade.**","o":"auditoria"},"11ae3ea96fb0":{"s":"video","a":"references/race-and-speed.md","l":33,"t":"**Every insert is load-bearing.** Each detail panel must be captionable with one race label — *setup / commitment / mistake / recovery / proof-of-speed / result* (§4). If you cannot label it, it is a *fantik* (`dramaturgy.md` §3) — drop it. A board that is all proof-of-speed with no commitment/mistake/recovery is a reel, not a story.","o":"auditoria"},"611f323d3615":{"s":"video","a":"references/race-and-speed.md","l":42,"t":"→ **Rule:** never write \"motion\" — write the artifact motion leaves behind, and never board a neutral panel (every frame carries a forward vector, negative space ahead of the subject).","o":"auditoria"},"ca87c9bb0cd3":{"s":"video","a":"references/race-and-speed.md","l":57,"t":"A still has no engine note and zero motion. It sells velocity through the **speed-budget rule** — a frame reads fast only when **≥3 of five cues coexist** (camera at/below bumper height · asphalt streaking the lower frame · a near foreground reference passing the edge · sharp hero against motion-blurred background · a mechanical-vibration cue). The full rule, with the anti-fake firewall, lives in ","o":"auditoria"},"be25e9cc99a1":{"s":"video","a":"references/race-and-speed.md","l":73,"t":"**Long-lens compression** — the second speed register and the antidote to \"only blur sells speed\". Frankenheimer's 1000mm stacked distant cars onto the hero so closing distance reads as collapse. Pair compression panels with low-wide panels in the cut; never board the whole spot on one lens. In `seedance.md`/`veo.md` syntax name \"motion blur, fast-shutter look on background, sharp subject\" explici","o":"auditoria"},"fc4a79f80ec2":{"s":"video","a":"references/race-and-speed.md","l":81,"t":"A face does four jobs: internal state, where it looks, the cost, the decision. Banned, those jobs redistribute — **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space.** The mechanism, the EMOTION→OBJECT substitution table and the state-change cheat-sheet are owned by `animatic-keyframes.md` §5; do not duplicate them. Two filters before you draw:","o":"auditoria"},"7a8e1fc6b5e6":{"s":"video","a":"references/race-and-speed.md","l":117,"t":"**Amber logic (decision point).** Choose the **Sportsman / full tree** for an ad: three ambers fire *sequentially 0.5s apart* — three drawable keyframes, a stretched drum-roll of dread with cut length collapsing toward the green. The Pro tree fires all three at once — one panel, brutal but no build. Draw the Sportsman stagger. Always leave on the **last amber, not the green** (holeshot): the launc","o":"auditoria"},"9bf2cbf9c271":{"s":"video","a":"references/race-and-speed.md","l":129,"t":"3 | **Hard-mounted cabin shake** | Pressure / Reaction | Rigid interior mount: dash/needle/hands vibrating, mirror trembling, world shuddering through glass | visible micro-vibration; never perfectly stable","o":"auditoria"},"0e9bacb2e8ad":{"s":"video","a":"references/race-and-speed.md","l":148,"t":"**Restless / handheld cam** | the frame never settles; constant threat, physiological unease | Never a perfectly level, perfectly clean panel — bake in a 1–3° drift, edge smear, off-true horizon, a faint micro-shake artifact even in a \"static\" cockpit | Pressure","o":"auditoria"},"98ee930c9f7c":{"s":"video","a":"references/race-and-speed.md","l":157,"t":"Faces are banned, so light is the only actor left. It does not \"set a mood\" — it **rims a material** so a piece of metal, rubber or skin reports the emotion a face would. General light grammar (sources, direction, quality) is `camera-lighting-vocabulary.md` §4–7; the anti-sterile firewall is `animatic-keyframes.md` §7 + `universal-rules.md` U12. The race-specific governing law: *embrace the dark* ","o":"auditoria"},"2be4bcd05090":{"s":"video","a":"references/race-and-speed.md","l":169,"t":"Toxic amber/sodium (rationed) | temporary, contaminated, alien — never cozy | sodium lamp as a passing smear; spilled fluid catching one lamp; the Tree's three ambers as countdown only","o":"auditoria"},"8a862f876fa8":{"s":"video","a":"references/race-and-speed.md","l":171,"t":"**Warmth as toxin** is the only permitted heat: brake-disc/exhaust glow (the machine at its thermal limit), a header flame stab gone in a frame, the Tree's alien ambers, a sickly sodium smear. Any warm element must be **point-source and surrounded by cold**. If amber fills more than ~15% of the frame it has become a wash — kill it.","o":"auditoria"},"f79825c8bfa6":{"s":"video","a":"references/race-and-speed.md","l":177,"t":"**Backlit smoke** [Pressure/Establish]: hard cyan or mercury-white punching *through* tire smoke from behind; volumetric shafts, the car a dark mass dissolving into glowing haze, red tail-light bleed inside the smoke for the danger accent. Front-lit smoke is dead gray nothing — always rim it from behind.","o":"auditoria"},"784a21fb3fba":{"s":"video","a":"references/race-and-speed.md","l":180,"t":"**Silhouette / contre-jour** [Power/Pressure]: helmet/shoulder as pure black shape against a blown headlight or the Tree's amber bank, one thin rim defining the form plus one glint on the visor edge, no features. The brain fills the dark with something worse than any face.","o":"auditoria"},"c50591694f2a":{"s":"video","a":"references/race-and-speed.md","l":183,"t":"**Texture and atmosphere.** Name the grain, never \"clean\": fine-to-medium film grain (heaviest in shadow), halation/bloom on hard practicals (soft glow ring + hard hot core), one anamorphic flare off the dominant source, slight chromatic fringe on the hottest edges (anti-sterile test in `animatic-keyframes.md` §7). One atmospheric pressure per panel (`dramaturgy.md` §9, Kurosawa) — backlit tire sm","o":"auditoria"},"5f835d0eb35a":{"s":"video","a":"references/race-and-speed.md","l":189,"t":"You storyboard the **sound first**; the keyframes hang off it. The general law — **loudness in the audio = panel count** — and the descending duration staircase are the density ladder in `animatic-keyframes.md` §3, sitting on the `dramaturgy.md` §12 rhythm staircase. Do not re-derive them. The race-specific rhythm rules:","o":"auditoria"},"a433636c2657":{"s":"video","a":"references/race-and-speed.md","l":191,"t":"**Engine as metronome.** Tie panel *duration* to RPM: idle = ~2s panels, redline = panels collapsing 2s → 1s → 0.5s → 8fr → 4fr toward the green. The board should read as an accelerating tachometer on mute. Annotate each panel with its on-screen life.","o":"auditoria"},"2d91bbc13caa":{"s":"video","a":"references/race-and-speed.md","l":194,"t":"**Pull-to-intimate at the peak.** At the contest's tensest point, cut from a wide loud pass to an ECU of glove-on-shifter / breath-fog, shallow focus, void around it — engines stripped to breath only. The *quiet* panel goes *tight*; the loud panel goes wide.","o":"auditoria"},"f5ef9ac105ef":{"s":"video","a":"references/race-and-speed.md","l":198,"t":"Every panel inherits a `Sound` cell even though it is a still (`dramaturgy.md` §11) — prompt the *physical consequence* of the sound (deformation, particulate, smear, heat-haze, isolation-in-void), never a named sound. Fill it.","o":"auditoria"},"19ef2dbc9666":{"s":"video","a":"references/race-and-speed.md","l":204,"t":"Five phases: **ritual → staging → launch → contest → release.** Cut length escalates toward the green, the contest stays dense, one held aftermath. ~20–26 panels. Function tags from `role-modes.md` §4. This is the structural skeleton; for a fully worked, panel-by-panel deliverable board of this exact structure (format C, ~13 rows), use `animatic-keyframes.md` §8 — do not draw a second worked board","o":"auditoria"},"de0ddf9ca295":{"s":"video","a":"references/race-and-speed.md","l":214,"t":"Allocation: plot the board as a descending duration staircase, broken only by the one pre-launch held panel (the single most-held still, most negative space) and the one post-finish hold. The launch is *never* one hero frame — fan it into the 6–9-panel micro-burst. No two bang-clusters touch; every burst is separated by a held quiet panel.","o":"auditoria"},"54d1d74f3df8":{"s":"video","a":"references/race-and-speed.md","l":231,"t":"[ ] No banned panel: static fetish insert (lever/badge/wheel with no verb, no state-change); anatomy at rest; a detail you cannot caption with a §4 label; all-proof-of-speed board with no commitment/mistake/recovery; decorative dashboard clutter (keyring, dice, coffee cup — \"each object is a clue\"); warm wash without narrative function.","o":"auditoria"},"1948fb0cd2ea":{"s":"video","a":"references/race-and-speed.md","l":233,"t":"Before sending the board, run `animatic-keyframes.md` §9 (per-panel master checklist), `dramaturgy.md` §15 and `universal-rules.md` §13 over it. The most-violated step is the three-detail check — do not skip it.","o":"auditoria"},"cedacf95ce49":{"s":"video","a":"references/role-modes.md","l":22,"t":"Every shot must answer at least one of these questions. If a shot answers none, delete it.","o":"auditoria"},"5c79b70fbb5a":{"s":"video","a":"references/role-modes.md","l":28,"t":"What does the viewer need to notice?","o":"auditoria"},"e47d5852520a":{"s":"video","a":"references/role-modes.md","l":47,"t":"Use one dominant director reference per scene. Translate into concrete camera, light, rhythm, blocking. Never stack three or more references.","o":"auditoria"},"d92564e28fe4":{"s":"video","a":"references/role-modes.md","l":68,"t":"Translate every beat into physical action the camera can see. Tag each beat with a shot function (see section 4). Every beat must have subtext.","o":"auditoria"},"9570d85c5b8a":{"s":"video","a":"references/role-modes.md","l":138,"t":"Every beat should carry at least one function tag. This is the editor's grammar.","o":"auditoria"},"85f471342e23":{"s":"video","a":"references/role-modes.md","l":153,"t":"A montage sequence can compress or loop. Use function tags to keep the structure readable even at high speed.","o":"auditoria"},"a84829cef94a":{"s":"video","a":"references/role-modes.md","l":155,"t":"Each tag is also a question the shot must answer. Establish. Where. Power. Who commands. Pressure. What pushes. Detail. What to notice. Reaction. What it cost. Shift. What changed inside. Impact. The moment. Aftermath. The residue. Exit. The image carried out.","o":"auditoria"},"dc069aea561b":{"s":"video","a":"references/seedance-25.md","l":52,"t":"Generation parameters (duration, aspect ratio, resolution) are set on the generation page or via API — **they do not belong in the prompt**. The 1.x/2.0 CLI tail (`--resolution ... --duration ...`) is not 2.5 syntax. Exception: in Ultra Long mode, restate duration and ratio at the top of the prompt.","o":"archivo"},"3c3a35bd5003":{"s":"video","a":"references/seedance-25.md","l":76,"t":"**Global tail.** Re-state the must-hold globals (camera position, environment, sound, lighting) and repeat the global bans.","o":"archivo"},"fe2010e7cd1e":{"s":"video","a":"references/seedance-25.md","l":82,"t":"2.5 has dedicated markers. Use them — do not describe audio in loose prose:","o":"archivo"},"5090be9f2dcb":{"s":"video","a":"references/seedance-25.md","l":103,"t":"The point of 50 slots is not dumping assets in. **Every material's role must be written in the prompt.** Do not rely on text labels inside images; do not make the model infer mappings.","o":"archivo"},"f4e68628a21b":{"s":"video","a":"references/seedance-25.md","l":115,"t":"**Bind each subject individually.** `<Character A> corresponds to @Image 1. Use only the appearance, hairstyle, and clothing.` The officially forbidden pattern: \"@Images 1 through 4 define four characters respectively\" — it never states which is which.","o":"archivo"},"1a73cf483aab":{"s":"video","a":"references/seedance-25.md","l":116,"t":"**Add exclusions** for anything that could bleed in: \"Do not use the image background.\" / \"Do not use the people in the image.\" / \"Do not use the person's identity, clothing, or scene from the video.\"","o":"archivo"},"8acb235535b4":{"s":"video","a":"references/seedance-25.md","l":117,"t":"**Do not restate what a reference already defines.** If a reference video defines the motion, state only which attributes to inherit — re-describing every action conflicts with the reference.","o":"archivo"},"9d8033a7fcbb":{"s":"video","a":"references/seedance-25.md","l":129,"t":"**Select references per scene**, not all at once: `Scene 1 | Use: <list>. Event: ... End state: ...`","o":"archivo"},"58c03455aad2":{"s":"video","a":"references/seedance-25.md","l":144,"t":"Divide the clip into consecutive stages. **One primary state change per stage, and always state the visible end state** — the end state is what the model steers toward (this is the U11 final-image rule, per stage).","o":"archivo"},"7e710b7de286":{"s":"video","a":"references/seedance-25.md","l":159,"t":"A time range is an event's **time budget, not an edit point**. Ranges must be consecutive and non-overlapping.","o":"archivo"},"2976ffd881f1":{"s":"video","a":"references/seedance-25.md","l":161,"t":"**One core action + one camera move per window.** Do not demand frequencies (\"three actions in one second\").","o":"archivo"},"83694d17ac4b":{"s":"video","a":"references/seedance-25.md","l":191,"t":"**The prohibition list is specific, not generic.** From the official farewell example: \"No exaggerated crying, no fast cuts, no large body movements, no extra dialogue, no BGM, no runny nose, no premature dropping of tears.\" Ban the exact ways this scene can collapse.","o":"archivo"},"4340f22ac789":{"s":"video","a":"references/seedance-25.md","l":225,"t":"Always attach the incantation: **\"prohibit rigid cutting, prohibit objects appearing out of thin air\"** — it is the official anti-jump-cut clause, repeated in every transition template.","o":"archivo"},"b93895a69273":{"s":"video","a":"references/seedance-25.md","l":227,"t":"Order-gate effects that must not fire early: \"The ink-wash effect must only appear AFTER 25 seconds, triggered by the 'click' sound — absolutely no premature appearance.\"","o":"archivo"},"e56653bec670":{"s":"video","a":"references/seedance-25.md","l":233,"t":"**Declare the physics regime up front.** \"Rain reflections on metal, water splashed by tires, and the specular refraction of exhaust flames must strictly obey real-world physics.\"","o":"archivo"},"809f55027421":{"s":"video","a":"references/seedance-25.md","l":234,"t":"**Narrate consequences, not just actions.** Tires kick up water curtains; the impact shatters the bridge into a spider-web pattern; the shockwave blows the rain away in a ring. Action chains where each step forces the next (\"hand grips jar → lid actually unscrews\") double as QA — a broken chain exposes a failed generation instantly.","o":"archivo"},"8870a91220dc":{"s":"video","a":"references/seedance-25.md","l":235,"t":"**Negatively constrain the known failure.** \"No soft-body or mollusk-like twisting of the mecha structure (must maintain metallic rigidity).\" \"The amber stays attached to the palm and must not clip through the fingers.\"","o":"archivo"},"5e9381b1532d":{"s":"video","a":"references/seedance-25.md","l":236,"t":"**Gate events on triggers.** \"Three seconds after she presses the button...\" / \"only when he says {now}...\" — triggers beat raw seconds for anything tied to performance.","o":"archivo"},"8dd832a85896":{"s":"video","a":"references/seedance-25.md","l":262,"t":"Any clip ≤30s extends by 4-30s per pass, nested repeatedly, **hard ceiling 60s**. The new prompt applies only to the appended segment; original frames are untouched. Required verbs: extend forward / extend backward / continue.","o":"archivo"},"324bcf02f62b":{"s":"video","a":"references/seedance-25.md","l":275,"t":"Backward (prepend a beginning): describe the preceding events, then define @Video 1's **first frame as the extension's explicit end state**. Gotcha: materials that belong to the source video only must be flagged — \"<X> must not appear early in the backward extension\" — or later characters leak into the past.","o":"archivo"},"3cc2915d07c9":{"s":"video","a":"references/seedance-25.md","l":279,"t":"Community-proven minimal extension prompt: \"Extend the video. Keep character identity, facial structure, body proportions, lighting, art style, and the space fully unchanged. Only change camera movement; do not redesign character or action.\"","o":"archivo"},"f0315e2411a6":{"s":"video","a":"references/seedance-25.md","l":285,"t":"**Timestamped** (1-minute ambient pieces): windowed beats with per-window bans — \"0-20s (quiet opening): fixed camera... no shake, no characters enter, hard cuts prohibited.\"","o":"archivo"},"ed4fbf774ee8":{"s":"video","a":"references/seedance-25.md","l":294,"t":"**Coarse blockout** — primitive geometry as a \"dynamic skeleton\" (trajectories, blocking, camera path, cuts, light changes). **Map every primitive to a reference**: \"The tall cylinder in @Video 1 corresponds to <Guide>. The rectangular block corresponds to <Display Cart>.\" Exclude the render style: \"Do not use its gray geometry or empty scene.\" Best practice: **no limbed or winged models in coarse","o":"archivo"},"7887bf99374c":{"s":"video","a":"references/seedance-25.md","l":295,"t":"**Fine blockout** — complete 3D animation; the model re-renders materials, color and style only: \"@Video 1 is a fine blockout reference. Preserve structure, action, spatial layout, camera position, camera movement, and cuts. Do not use its original gray materials or empty background. Re-render <subject> as <final subject>...\" **Clean the viewport capture first**: remove path lines, coordinate axes","o":"archivo"},"c8f9182dab48":{"s":"video","a":"references/seedance-25.md","l":306,"t":"**Storyboard grid as input**: one image, ≤15 panels official (practitioners have pushed 50), clean line art, minimal text. Declare the reading order and exclude the style: \"@Image 1 provides a 12-panel storyboard grid for shot order and approximate composition. Read it left to right, top to bottom. Do not use the grid's line-art style, text labels, or placeholder characters.\" Then `Shot 1: ... Sho","o":"auditoria"},"dbf4503191cb":{"s":"video","a":"references/seedance-25.md","l":307,"t":"**Multi-keyframe sequences**: \"Use @Image 1 through @Image N as keyframes in this order\", one key state per image. Independent images align better than a grid. Keyframes control stage order and key states, not exact frames.","o":"archivo"},"884b4b40911e":{"s":"video","a":"references/seedance-25.md","l":308,"t":"**First + last frame** works inside omni-reference mode — declare each anchor separately (\"@Image 1 is the first frame... @Image 2 is the last frame...\"), never jointly. Same aspect ratio required.","o":"archivo"},"877300b2ba56":{"s":"video","a":"references/seedance-25.md","l":314,"t":"Fix. Per-subject binding (section 5) + explicit differentiation: \"Their movements are not synchronized. Clothing colors, hairstyles, and facial features must all be distinct. No identical clones in the background.\"","o":"archivo"},"3b48069bb705":{"s":"video","a":"references/seedance-25.md","l":329,"t":"2.5 errs by commission: it completes more instructions than rivals but may cut freely even when told \"one continuous take\". Fix. \"One continuous shot, no cuts of any kind\" + a camera path that never motivates a cut; if montage keeps leaking in, drop to a 10-15s window where one-takes are stable.","o":"archivo"},"6eafd4ebaa95":{"s":"video","a":"references/seedance-25.md","l":336,"t":"Costs are real: a 30s/720p generation on Jimeng runs ~500-700 credits. Production budgets must assume re-rolls, extensions and segment reshoots — fix with edit/extend/reshoot instead of full regeneration whenever possible. Draft at 480p, finish at 720p.","o":"archivo"},"0395ddb6bd06":{"s":"video","a":"references/seedance.md","l":56,"t":"**Not 2.5 syntax.** On 2.5, duration / aspect ratio / resolution are set on the generation page or via API and do not belong in the prompt (exception: Ultra Long mode restates duration and ratio at the top — see `seedance-25.md` §2).","o":"archivo"},"73905921cedf":{"s":"video","a":"references/seedance.md","l":62,"t":"Seedance does not render abstractions. It renders **physical specifics**. Every adjective must be a sensory fact. Every emotion must be a body. Every shot must own at least three concrete details:","o":"archivo"},"a78b8143dfae":{"s":"video","a":"references/seedance.md","l":64,"t":"**One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC.","o":"archivo"},"809fb4ebddce":{"s":"video","a":"references/seedance.md","l":65,"t":"**One physical micro-action.** Jaw locks. Finger taps the counter. Knuckles whiten on the fork. Lips press into a line. He swallows hard.","o":"archivo"},"659a2eb38201":{"s":"video","a":"references/seedance.md","l":66,"t":"**One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in the dark phone screen. Rain hitting the same windowpane.","o":"archivo"},"ae09790a4e9b":{"s":"video","a":"references/seedance.md","l":70,"t":"Banned, lazy phrasing that produces mush:","o":"archivo"},"e30cec365a82":{"s":"video","a":"references/seedance.md","l":92,"t":"Write in full sentences, not tags. Seedance prefers clear grammatical prose. For dramatic / multi-shot / character-locked work, **use the production-grade skeleton in section 6 instead.**","o":"archivo"},"2d5229cb5344":{"s":"video","a":"references/seedance.md","l":96,"t":"Use this for any dramatic piece, multi-shot ad, music-video segment, or character-locked clip. Each block answers a specific failure mode. Skipping a block reintroduces that failure.","o":"archivo"},"b9c780304835":{"s":"video","a":"references/seedance.md","l":156,"t":"For a 5-second multi-shot clip, the model performs best with **5 shot beats** following a dramatic micro-arc. Use this timing as the default scaffold:","o":"auditoria"},"c6a20928bc70":{"s":"video","a":"references/seedance.md","l":170,"t":"Seedance reads explicit cut markers inside a single prompt and generates distinct shots connected by visible cuts. This is its strongest card. Use it when you need montage in a single generation.","o":"archivo"},"c3c3d1047037":{"s":"video","a":"references/seedance.md","l":196,"t":"Use 2-3 shots per 5-second clip for tight cinematic montage, 4-5 shot beats only when each beat is short and physically distinct (see section 7). Hard cap: 5 shots per generation — beyond that the model drops or compresses shots. Size the duration to the shot count (4 shots need 10-15s, not 5s). Every shot must share an anchor with its neighbors — same character, same location, or same lighting re","o":"auditoria"},"d629ec5811b5":{"s":"video","a":"references/seedance.md","l":216,"t":"Seedance 2.0 accepts image references inline using `@img1`, `@img2`, etc. Use this to lock the protagonist's likeness across all shots in a multi-shot clip and across multiple stitched clips.","o":"archivo"},"e57740e558ac":{"s":"video","a":"references/seedance.md","l":226,"t":"The full identity block must follow the `@img1` mention. The model needs the textual description as a backup signal — the image alone drifts.","o":"archivo"},"80e69a894fcc":{"s":"video","a":"references/seedance.md","l":252,"t":"Workaround for 1.x/2.0. Always invert to positive phrasing. Instead of \"no yellow tones\" write \"cold blue-gray palette with desaturated skin tones.\" Instead of \"no distorted hands\" write \"anatomically correct hands with clear finger separation.\"","o":"archivo"},"a75221469baa":{"s":"video","a":"references/seedance.md","l":254,"t":"**Seedance 2.5 fixed this.** Direct bans are reliable: \"pure video, no subtitles, no background music\" actually suppresses them, and specific prohibition lists (\"no exaggerated crying, no fast cuts\") are a core part of the official 2.5 prompt structure. See `seedance-25.md` §7.","o":"archivo"},"71fec8821328":{"s":"video","a":"references/seedance.md","l":258,"t":"When using a reference image, DO NOT describe elements already visible in the image. The model sees it. Describe only motion and camera work. Re-describing static elements creates identity drift.","o":"archivo"},"6b50e2278180":{"s":"video","a":"references/seedance.md","l":273,"t":"Dialogue goes in **double quotes** on 1.5/2.0 — the model voices it, generates the voice and syncs lips to the cut. State the delivery: \"Play her line dry and a little proud, his quiet and worn out.\" **On 2.5, use the dedicated markers instead**: dialogue in `{ }`, SFX in `< >`, music in `( )`, titles in `【 】` (see `seedance-25.md` §4).","o":"archivo"},"f1f0fcdff995":{"s":"video","a":"references/seedance.md","l":282,"t":"Fix. Add explicit \"Cut to\" markers. Say \"multi-shot sequence with visible hard cuts. Do not generate a single continuous take.\"","o":"archivo"},"27ee9fc25b00":{"s":"video","a":"references/seedance.md","l":294,"t":"Fix. Use positive substitutes. Seedance 1.0 has no negative parser.","o":"archivo"},"f4c2c207fbb8":{"s":"video","a":"references/seedance.md","l":306,"t":"Fix. Apply the Details Law (section 4). Audit your draft: every shot must have one environmental pressure, one micro-action, one sound or visual motif anchor. Replace adjectives like \"dramatic\", \"intense\", \"beautiful\" with concrete physical facts.","o":"archivo"},"e7caec8627aa":{"s":"video","a":"references/seedance.md","l":310,"t":"After the 2026 deepfake crackdown, 2.0 aggressively filters human faces, helmets, sunglasses, and anything resembling protected IP or celebrity likeness. Fix. Route face-heavy drama to Seedance 2.5 (realistic humans are its headline feature), 1.5 Pro, Kling, or Veo; keep 2.0 for scenes, architecture, product and montage work. Use only owned or synthetic character references — the IP/celebrity filt","o":"archivo"},"31550b84c066":{"s":"video","a":"references/seedance.md","l":314,"t":"A 15s narrative is **never** one prompt. It is three self-contained 5-second prompts, each with the full character lock, the full visual style, the full audio block, and a different dramatic function. Stitch in the editor.","o":"auditoria"},"dd071e4f1adc":{"s":"video","a":"references/seedance.md","l":401,"t":"For dramatic, multi-shot, character-locked, or stitched-clip work — always use the 11-block production-grade skeleton from section 6.","o":"archivo"},"1eff4afae0c5":{"s":"video","a":"references/universal-rules.md","l":9,"t":"The non-negotiable. Details intensify emotion (Details Law)","o":"archivo"},"90c9d01c7da9":{"s":"video","a":"references/universal-rules.md","l":33,"t":"**One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC. (Kurosawa: weather is a character. See `dramaturgy.md` §9.)","o":"archivo"},"3da18291f908":{"s":"video","a":"references/universal-rules.md","l":34,"t":"**One physical micro-action.** Jaw locks. Knuckles whiten on the fork. Lips press into a line. He swallows hard. Fingers curl against the doorframe. (Show, not tell — the body is the only place where feelings render.)","o":"archivo"},"01e778de1f4c":{"s":"video","a":"references/universal-rules.md","l":35,"t":"**One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in a darkened phone screen. Rain on the same windowpane. A single fluorescent flicker before each cut.","o":"archivo"},"d9efc3ad4bfb":{"s":"video","a":"references/universal-rules.md","l":39,"t":"Words that do not render and mark the writer being lazy:","o":"archivo"},"a4cd347f4b1e":{"s":"video","a":"references/universal-rules.md","l":85,"t":"Do not stack three camera moves in a 5-second clip. Pick one dominant move (dolly-in, pan, tracking, static). Layer a subtle micro-adjustment if needed (slight handheld shake, gentle rack focus). More than that produces visual chaos.","o":"archivo"},"c1d814f8c059":{"s":"video","a":"references/universal-rules.md","l":104,"t":"Identity block must include: face shape, eye color, skin tone. Hair color, length, style. Facial hair. Exact clothing items. Distinctive accessories.","o":"auditoria"},"e24b10c311e9":{"s":"video","a":"references/universal-rules.md","l":122,"t":"\"Loneliness\" does not render. \"A man sitting alone, shoulders collapsed, face lit by blue phone glow, empty bottles on the table\" does.","o":"archivo"},"9373adbe6c11":{"s":"video","a":"references/universal-rules.md","l":130,"t":"Most models work in 5-10 second clips. Longer narratives live in multiple clips stitched in the editor. Do not cram a 30-second story into a 5-second prompt.","o":"archivo"},"adbe90385564":{"s":"video","a":"references/universal-rules.md","l":154,"t":"Before returning the final prompt to the user, audit every shot. Each shot must carry at least one of each:","o":"archivo"},"75ec08f6c7e0":{"s":"video","a":"references/universal-rules.md","l":156,"t":"Environmental pressure (lighting, weather, surface, sound of the room).","o":"archivo"},"6f2d9a2fd7ba":{"s":"video","a":"references/universal-rules.md","l":157,"t":"Physical micro-action on the body (jaw, hand, breath, eye, gesture).","o":"archivo"},"e2b9c51c5ef7":{"s":"video","a":"references/universal-rules.md","l":158,"t":"Sound anchor or recurring visual motif tied to the emotional spine.","o":"archivo"},"f7ff7d98a4a9":{"s":"video","a":"references/universal-rules.md","l":160,"t":"If a shot has zero, fix it before sending. If a shot has only one, ask whether you can make it two without bloat. The strongest prompts in this skill's worked examples always have all three.","o":"archivo"},"51c07299485c":{"s":"video","a":"references/universal-rules.md","l":166,"t":"Wherever a model accepts reference assets (Seedance `@Image/@Video/@Audio`, Kling Element Binding and Omni references, Veo ingredients), **every asset gets an explicit role written in the prompt**: what it defines (appearance, motion, voice, scene, camera path) and what to ignore (\"Do not use the image background\", \"Do not use the people in the image\").","o":"archivo"},"2e0a56484152":{"s":"video","a":"references/universal-rules.md","l":168,"t":"Bind each subject individually: \"<Character A> corresponds to @Image 1 — use only the appearance, hairstyle, and clothing.\" Never the collective form \"@Images 1 through 4 define four characters respectively\" — it does not state which is which.","o":"archivo"},"21023b368ec1":{"s":"video","a":"references/universal-rules.md","l":169,"t":"Do not restate what a reference already defines. If a video reference carries the motion, name only the attributes to inherit; re-describing every action fights the reference.","o":"archivo"},"d1794addd647":{"s":"video","a":"references/universal-rules.md","l":178,"t":"The core subject that must survive every shot.","o":"archivo"},"0196c3f7220c":{"s":"video","a":"references/universal-rules.md","l":179,"t":"The key shots that must appear.","o":"archivo"},"da70b123efd4":{"s":"video","a":"references/universal-rules.md","l":180,"t":"The transitions where the model may freestyle.","o":"archivo"},"e21763705dd8":{"s":"video","a":"references/universal-rules.md","l":181,"t":"The mandatory final frame.","o":"archivo"},"dfcbb6dd0684":{"s":"video","a":"references/veo.md","l":95,"t":"Use labels `Audio:`, `Says:`, `SFX:` to separate sound direction from visual direction. The model needs an explicit signal that audio should be generated.","o":"archivo"},"a45ee38936f8":{"s":"video","a":"references/veo.md","l":99,"t":"Veo parses structured JSON. This prevents \"concept bleed\" where describing mood accidentally changes object colors. Use JSON for complex scenes with strict continuity needs.","o":"archivo"},"01a57763de37":{"s":"video","a":"references/veo.md","l":165,"t":"Complex props that must stay the same color and size.","o":"archivo"},"1c400db686fb":{"s":"video","a":"references/veo.md","l":176,"t":"Do not re-describe static elements.","o":"archivo"},"402a936cf3fe":{"s":"video","a":"references/veo.md","l":197,"t":"Use when you need a specific character in a specific place with a specific object.","o":"archivo"},"1a0831f5ce00":{"s":"video","a":"references/veo.md","l":207,"t":"Fix. Add explicit `Audio:`, `SFX:`, or `Says:` labels. Do not assume the model will infer audio from visual description.","o":"archivo"},"1dc7c87def16":{"s":"visual-asset-critic","a":"SKILL.md","l":24,"t":"**Two artifacts from every review, always both:** a human-readable markdown critique (the primary surface) and a machine-readable critique JSON (so a pipeline can gate on the verdict instead of parsing prose). The JSON is detailed in Step 6; it never replaces the markdown.","o":"archivo"},"c8195d96aaff":{"s":"visual-asset-critic","a":"SKILL.md","l":77,"t":"If you can't establish intent in one sentence, ask. Don't critique blind.","o":"archivo"},"0aebfb67e4fd":{"s":"visual-asset-critic","a":"SKILL.md","l":83,"t":"**Brand Lock**, does it respect palette, mood, \"never\" list?","o":"auditoria"},"3236a31aecea":{"s":"visual-asset-critic","a":"SKILL.md","l":84,"t":"**Series Lock**, does it match character/environment/lighting anchors?","o":"archivo"},"79f9fd6178a0":{"s":"visual-asset-critic","a":"SKILL.md","l":85,"t":"**Shot Spec**, does framing/angle/composition match the spec?","o":"auditoria"},"024638f7f93d":{"s":"visual-asset-critic","a":"SKILL.md","l":86,"t":"**Composition**, does it reserve space for on-screen text if applicable?","o":"auditoria"},"d0476aaa14d5":{"s":"visual-asset-critic","a":"SKILL.md","l":87,"t":"**Technical**, skin texture, hands, eyes, anatomy, AI artifacts?","o":"auditoria"},"4254cbeb01a9":{"s":"visual-asset-critic","a":"SKILL.md","l":88,"t":"**Continuity**, if previous shots in the series are available, does it match?","o":"archivo"},"4dabd7bdc618":{"s":"visual-asset-critic","a":"SKILL.md","l":94,"t":"For every \"not working\" point, the critique must say what to do about it. Three buckets:","o":"archivo"},"7eac9caa0ac8":{"s":"visual-asset-critic","a":"SKILL.md","l":102,"t":"**Re-roll required**, no prompt fix will help; the generator just produced a bad sample. Budget 2–3 attempts:","o":"archivo"},"c24705b39ede":{"s":"visual-asset-critic","a":"SKILL.md","l":145,"t":"**Provenance, all of it required at 1.1.** A verdict is a claim about specific bytes. Name","o":"archivo"},"fd33b1fe4a83":{"s":"visual-asset-critic","a":"SKILL.md","l":182,"t":"**Gating rule, the verdict is derived from severities, not chosen freely.** This guarantees the markdown verdict and the JSON verdict always agree:","o":"archivo"},"583d5f400a46":{"s":"visual-asset-critic","a":"SKILL.md","l":224,"t":"\"Looks great\" / \"feels off\" without specifics is not a critique. Every observation must reference something in the image (composition, color, anatomy, lighting direction, etc.).","o":"archivo"},"0cde22e1a93c":{"s":"visual-asset-critic","a":"SKILL.md","l":232,"t":"If the brief was \"founder at laptop, calm mood\" and the generation delivered exactly that, don't note that \"the room could be more visually interesting.\" That's scope creep, not critique.","o":"archivo"},"5b837820df26":{"s":"visual-asset-critic","a":"SKILL.md","l":236,"t":"Some failures (mangled hands, weird eye reflections, jewelry shimmer) are known generator weaknesses. Surface them as such, don't pretend a different prompt will fix them. Recommend re-roll or post.","o":"archivo"},"a221a716e952":{"s":"visual-asset-critic","a":"SKILL.md","l":240,"t":"Generation is one stage in a pipeline. If the image is 80% right and the gap is fixable in post, that's an ACCEPT with post notes. Don't send the user back to re-generate when an editor would handle it in 90 seconds.","o":"archivo"},"65ab63f3291c":{"s":"visual-asset-critic","a":"SKILL.md","l":276,"t":"If the verdict is REJECT, do not offer that. REJECT means a blocking issue or three or more","o":"archivo"},"c7b95c733b7f":{"s":"visual-asset-critic","a":"SKILL.md","l":281,"t":"Don't auto-revise. The user picks. The critique you just wrote is exactly what closes that","o":"archivo"},"147b5d10f118":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":40,"t":"never use stock photo aesthetic","o":"archivo"},"edb34335baee":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":41,"t":"never use AI uncanny faces","o":"auditoria"},"36f326b4fa1b":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":42,"t":"never over-saturate the cream background","o":"auditoria"},"6fcfbe5ad699":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":43,"t":"never use coral as a flood color (only as accent or signature periods)","o":"auditoria"},"e3d69437c2f6":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":44,"t":"never use em dashes in copy","o":"archivo"},"ff2826465af1":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":45,"t":"never use emojis in body copy","o":"archivo"},"bd1590a213fe":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":46,"t":"never use bullet points in narrative copy","o":"archivo"},"cf3ce4e1adaf":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":47,"t":"never use clip-art or generic icon sets","o":"auditoria"},"2ef7c79850da":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":48,"t":"never use hype words (\"game-changing\", \"revolutionary\", \"next-level\", \"comprehensive\")","o":"archivo"},"5d8f1227d198":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":49,"t":"never use exclamation points in headlines","o":"archivo"},"b1bf8c0bd438":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":50,"t":"never default to dark mode, light mode hybrid is the brand","o":"auditoria"},"2306baa11deb":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":51,"t":"never animate text with bouncing or wobbling, type-on, fade, or hard cut only","o":"auditoria"},"c2fbf1d46956":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":62,"t":"Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.","o":"archivo"},"8cb896ae3ca7":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":66,"t":"Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.","o":"auditoria"},"a3fa0f352d46":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":74,"t":"prefer specific numbers over vague claims","o":"archivo"},"c1ee0d0b5a80":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":75,"t":"prefer present-tense over future-tense","o":"archivo"},"650d25a8d091":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":76,"t":"prefer \"operator\" over \"creator\", \"infrastructure\" over \"agency\"","o":"archivo"},"1e898f2c0308":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":59,"t":"Technical hard fails are almost always **re-roll required**. The prompt was probably fine; the generator just produced a bad sample. Budget 2–3 re-rolls.","o":"archivo"},"31afcb61a699":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":101,"t":"Soft fails are noted but don't change the verdict on their own. If you have three or more of","o":"archivo"},"788f1a8f5595":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":107,"t":"**Don't critique what wasn't asked**, if the spec didn't call for cinematic mood, don't say \"could be more cinematic\"","o":"archivo"},"8014a721e61b":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":108,"t":"**Don't pile-on once verdict is set**, if you're rejecting, list the issues that drive the rejection; don't list every cosmetic concern","o":"archivo"},"9b616f961fba":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":109,"t":"**Be specific, always**, \"lighting is off\" is not a critique; \"key light is camera-right but series_lock says camera-left\" is","o":"archivo"},"b1bf47b129ef":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":111,"t":"**Distinguish prompt failure from generator failure**, if the prompt was fine and the generator produced garbage hands, that's \"re-roll required\", not \"fix the prompt\"","o":"archivo"},"73fe57cd2392":{"s":"visual-prompt-forge","a":"SKILL.md","l":21,"t":"If the user wants to build a storyboard from scratch (no shots.json yet), use `storyboard-architect` first, then chain into this skill.","o":"archivo"},"30bbbcefca75":{"s":"visual-prompt-forge","a":"SKILL.md","l":53,"t":"**Brand Lock**, palette, type, mood, \"never\" list (constant across project)","o":"archivo"},"3a6fba22ac13":{"s":"visual-prompt-forge","a":"SKILL.md","l":54,"t":"**Series Lock**, character/environment/lighting anchors (constant across storyboard)","o":"archivo"},"ea1a9a227c90":{"s":"visual-prompt-forge","a":"SKILL.md","l":55,"t":"**Shot Spec**, framing, angle, motion, subject (per shot)","o":"archivo"},"d584b5f6dd31":{"s":"visual-prompt-forge","a":"SKILL.md","l":56,"t":"**Text Layer**, **never in the prompt**, composited separately","o":"archivo"},"2ad7d2bd5837":{"s":"visual-prompt-forge","a":"SKILL.md","l":57,"t":"**Generator Adapter**, model-specific syntax wrapper","o":"archivo"},"409086978069":{"s":"visual-prompt-forge","a":"SKILL.md","l":100,"t":"Each adapter file documents the prompting style, parameter syntax, and known pitfalls for that generator. You **must** read the adapter before writing prompts for it. Don't guess from training data, image-gen syntax has churned multiple times.","o":"archivo"},"a8d68a296084":{"s":"visual-prompt-forge","a":"SKILL.md","l":122,"t":"**Strip any on_screen_text reference**, text never goes in the prompt","o":"archivo"},"24d0e917035e":{"s":"visual-prompt-forge","a":"SKILL.md","l":261,"t":"Colors come from the series_lock color_grade and the brand_lock palette. They get rendered into the prompt by the adapter. Don't write \"deep navy blazer\" in the shot subject if \"deep navy\" is already in the palette, that's a duplicated description and produces oversaturation.","o":"auditoria"},"4a9a9f1d1b5a":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":36,"t":"Flux handles **80–150 words** comfortably. Don't pad, but you have headroom Midjourney doesn't.","o":"archivo"},"cf6ea7ae4157":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":48,"t":"`shallow DOF` | `Shot at f/1.8 with shallow depth of field, background softly out of focus.`","o":"archivo"},"90c1b290af77":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":90,"t":"**Don't write \"highly detailed, 4k, masterpiece\"**, these are Stable Diffusion crutches. Flux ignores them and the line burns tokens","o":"archivo"},"c55494cbbad4":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":91,"t":"**Don't use weight syntax `(thing:1.4)`**. Flux 2 doesn't support it; Flux 1.1 partially does. Stick to natural language","o":"archivo"},"0447e389826e":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":92,"t":"**Don't enable prompt upsampling for series work**, fal.ai's auto-rewrite produces inconsistent shots","o":"archivo"},"d070363f06ff":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":93,"t":"**Don't include text content**, even if Flux 2 handles text better than Flux 1.1, composite separately for editability","o":"archivo"},"bc7cb8df5ee2":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":94,"t":"**Don't omit the photoreal closing line**, the \"no AI artifacts\" anchor measurably reduces the AI-look","o":"archivo"},"3e22b4c62b1b":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":38,"t":"GPT Image handles **150–300 words** comfortably. Longer than other generators. Use the headroom for explicit spatial descriptions.","o":"archivo"},"4e37b6108b10":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":46,"t":"\"The subject's shoulders are angled 30 degrees toward the camera, face turned to look at the off-frame light source.\"","o":"auditoria"},"20ebea9d8a54":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":48,"t":"Use this when the shot's composition is load-bearing.","o":"archivo"},"226a236b4dcc":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":75,"t":"GPT Image handles text-in-image at roughly 95% accuracy, second only to Ideogram. When text is required:","o":"auditoria"},"fd93590ae5d9":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":86,"t":"**Don't write Midjourney-style comma stacks**. GPT Image parses them as a list of disconnected concepts","o":"archivo"},"b5fa2fb924bd":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":87,"t":"**Don't omit spatial language when the shot has specific composition**, you're paying for the model's strength; use it","o":"archivo"},"e1f3ed8e587b":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":88,"t":"**Don't pile too many objects**, five or fewer distinct elements per scene; more degrades fidelity","o":"archivo"},"a6bec722c41f":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":89,"t":"**Don't include `--ar` flags or weight syntax**. GPT Image ignores them","o":"archivo"},"d4f119799fc1":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":90,"t":"**Don't forget that GPT Image's \"AI look\" is real**, the closing \"natural skin texture, no AI rendering artifacts\" line meaningfully helps but isn't a complete fix. For pure photoreal, Flux is still stronger","o":"archivo"},"a5926981e848":{"s":"visual-prompt-forge","a":"adapters/hailuo.md","l":66,"t":"**Don't enable the prompt optimizer for series work.** Auto-rewrite breaks shot-to-shot consistency.","o":"archivo"},"c52dc68d0daf":{"s":"visual-prompt-forge","a":"adapters/hailuo.md","l":67,"t":"**Don't stack two camera moves.** One move per shot.","o":"archivo"},"4755505de7d6":{"s":"visual-prompt-forge","a":"adapters/hailuo.md","l":68,"t":"**Don't include text content.** Composite captions in post.","o":"auditoria"},"88ac8d8506e0":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":15,"t":"Use when the on-screen text is meant to appear as part of the image itself, a poster headline, a sign in the scene, a packaging label. This is the only case where a generator prompt contains the text content.","o":"auditoria"},"73aaed94b890":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":30,"t":"The exact text must be in straight double-quotes. Ideogram parses these as the text-render target.","o":"auditoria"},"8ad2673a7cf6":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":91,"t":"**Don't trust magic_prompt**, it auto-rewrites and produces inconsistent shots across a series","o":"archivo"},"83c574fc9ce5":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":92,"t":"**Don't pile multiple text elements in one prompt**. Ideogram handles one text element well, two becomes lottery, three is broken","o":"auditoria"},"e0e022e50a9e":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":93,"t":"**Don't use cursive/decorative fonts**, even Ideogram fails on these. Sans-serif and clean serif are reliable","o":"auditoria"},"22d09b130cbd":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":94,"t":"**Don't forget seed**, for any series work, lock the seed at the storyboard level","o":"archivo"},"34c9774072b9":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":15,"t":"Camera motion goes **first**. This is the inverse of image generators where camera is implied. With video the camera's behaviour is the first thing the model must understand.","o":"archivo"},"a96d5275630a":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":26,"t":"`negative_prompt` | per series | Supported. Use to suppress drift, e.g. `extra fingers, warped face`","o":"archivo"},"c05a37e6c694":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":37,"t":"Kling handles **80–150 words** comfortably. Motion description adds a beat over a still prompt; do not pad past it.","o":"archivo"},"dd11b5da1036":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":73,"t":"Use `start_image` from the previous shot's accepted final frame to chain a sequence.","o":"archivo"},"1e43dbde9ec3":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":75,"t":"Do not flip lighting direction between consecutive shots (window-left stays window-left).","o":"archivo"},"5996725c4119":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":80,"t":"**Don't put camera motion at the end.** Kling parses motion best as the leading instruction.","o":"archivo"},"28b092664be0":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":81,"t":"**Don't request multiple camera moves in one shot.** Pick one; compound moves break.","o":"archivo"},"9d51ba168710":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":82,"t":"**Don't describe motion faster than the duration allows.** A slow dolly over 5s is plausible; over 1s it is jitter.","o":"archivo"},"3d67beea0470":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":83,"t":"**Don't include text content.** Video text rendering is unreliable; composite or animate text in post.","o":"auditoria"},"35ad63b182a1":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":43,"t":"`shallow DOF` | `shallow depth of field, f/1.8, bokeh background`","o":"archivo"},"c51e98883ae8":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":97,"t":"**Don't use \"AI\" or \"rendered\"**, produces stylized outputs that look generated","o":"archivo"},"e6bae7347048":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":98,"t":"**Don't over-stack adjectives**, three adjectives per noun phrase max","o":"archivo"},"f85b78ac44b0":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":99,"t":"**Don't include text content**, even if the shot has `on_screen_text`, leave it out. Composited separately.","o":"archivo"},"8452bcb3abe4":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":100,"t":"**Don't use `--c` for series work**, chaos kills consistency","o":"archivo"},"3ac7c1186c62":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":101,"t":"**Don't change `--seed` mid-storyboard**, set once at series_lock level","o":"archivo"},"43331142e7ea":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":101,"t":"**Don't use Midjourney-style flag syntax**. Nano Banana ignores `--ar`, expects `aspectRatio` parameter","o":"archivo"},"c169c881a0e6":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":102,"t":"**Don't expect Midjourney-level aesthetic by default**. Nano Banana is a workhorse, not a stylist. Stack mood adjectives explicitly","o":"archivo"},"03aa46d144b5":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":103,"t":"**Don't pile multiple modifications in one image-to-image prompt**, one change per pass produces cleaner results","o":"archivo"},"c4812cc96bc2":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":104,"t":"**Don't forget the \"preserve\" clause in image-to-image**, without it, Nano Banana treats the reference as loose inspiration and drifts","o":"archivo"},"5fc1cc954fb0":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":105,"t":"**Don't include text content in image prompts**, composite separately; text rendering is mediocre","o":"archivo"},"07771e486a77":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":74,"t":"**Don't force unrelated beats into one sequence.** Multi-shot is for shots that genuinely belong to one take.","o":"archivo"},"cee8c4cd6183":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":75,"t":"**Don't write more than ~4 cuts per generation.** Consistency degrades past that; split and assemble in edit.","o":"archivo"},"e84b5c0448b9":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":76,"t":"**Don't vary the character anchor between cuts.** Restate it once for the whole sequence, verbatim.","o":"archivo"},"98d91e461feb":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":77,"t":"**Don't include text content.** Composite captions from `text-overlays.json` in post.","o":"auditoria"},"750cf06a6b5c":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":78,"t":"**Don't stack two camera moves inside one cut.** One move per cut.","o":"archivo"},"5c181b49f9d4":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":38,"t":"**40–70 words per prompt**. Shorter than most. Don't pad.","o":"archivo"},"b58550816f3f":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":75,"t":"**Don't vary** the lighting language between shots, series_lock string in, no paraphrasing","o":"archivo"},"735b1edeccc3":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":80,"t":"**Don't write paragraphs**. Seedream wants comma-separated phrases","o":"archivo"},"8c221aa40298":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":81,"t":"**Don't use `--ar` syntax**, pass aspect_ratio as a parameter","o":"archivo"},"679f8c322dba":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":82,"t":"**Don't include text content**, text rendering is poor; composite separately","o":"archivo"},"3de5ebeb511c":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":83,"t":"**Don't expect Midjourney aesthetic**. Seedream produces clean but less art-directed output","o":"archivo"},"14306fa1f1c7":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":84,"t":"**Don't skip the seed lock for series work**, without it, character consistency breaks","o":"archivo"},"c962c96606da":{"s":"visual-prompt-forge","a":"adapters/veo.md","l":76,"t":"**Don't overrun the duration with dialogue.** A line that needs 12s of speech will clip or rush at 8s.","o":"archivo"},"1087e186fed5":{"s":"visual-prompt-forge","a":"adapters/veo.md","l":77,"t":"**Don't put on-screen text in the prompt.** Spoken lines are fine; rendered captions still come from `text-overlays.json` in post.","o":"auditoria"},"0acb882ac4aa":{"s":"visual-prompt-forge","a":"adapters/veo.md","l":78,"t":"**Don't stack two camera moves.** One move per shot.","o":"archivo"},"561e4601866e":{"s":"visual-prompt-forge","a":"adapters/veo.md","l":79,"t":"**Don't let Veo's auto-audio fight a post audio bed.** Pick one owner of sound per shot.","o":"archivo"},"00ad95b7807d":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":33,"t":"Same principle for `series_lock.lighting`. Lighting direction in particular is critical, flipping window-left to window-right between shots produces obvious cuts where there shouldn't be any.","o":"archivo"},"199cfb9ab91d":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":60,"t":"Generate the hero shot first (any shot, usually `shot_01` or whichever is most defining)","o":"auditoria"},"b2e806d6105a":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":61,"t":"Use that image as the reference for every subsequent shot","o":"auditoria"},"14c534d5e7f2":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":62,"t":"Each subsequent prompt has the verbatim character anchor PLUS the reference image link","o":"auditoria"},"926508430703":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":70,"t":"**This is the most effective lock for character consistency** in 2026. Use it whenever the storyboard features the same person across multiple shots.","o":"archivo"},"a0d393395e3a":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":74,"t":"When the storyboard has a distinctive visual style (specific film stock, specific lighting school, specific color theory), use a style reference image:","o":"archivo"},"4140ed69949c":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":84,"t":"A subtle one that breaks scenes when violated. If `series_lock.lighting` says \"soft natural side-light, large window LEFT\", then every shot's lighting must respect that direction.","o":"archivo"},"20b3434a9a5d":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":86,"t":"When a shot reverses character orientation (e.g., over-the-shoulder reverse), update the rationale to acknowledge the lighting flip:","o":"archivo"},"3b984b2349a3":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":113,"t":"A few things people try that don't actually fix consistency:","o":"archivo"},"0f136ad02a4a":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":115,"t":"**Adding \"consistent character\" or \"same person\" to the prompt**, generators don't read meta-instructions","o":"archivo"},"985e93f22844":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":116,"t":"**Numbering shots in the prompt** (\"shot 3 of 7, same as before\"), generators don't have memory across calls","o":"archivo"},"dd6e04a7a56e":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":118,"t":"**Asking for \"exactly the same\"**, there is no such thing in stateless image gen; you reduce drift, you don't eliminate it","o":"archivo"},"bfb6f1d9e6b2":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":120,"t":"Accept that some shots will need re-rolls. Budget for it. The locks reduce the failure rate; they don't eliminate it.","o":"auditoria"},"2757ce63d7e2":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":19,"t":"Verify brand-lock \"never\" list is being applied, if it includes \"no AI uncanny\", surface that into the prompt","o":"archivo"},"8f8dc623566a":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":20,"t":"Use Flux 2 Pro or Midjourney v7 instead of cheaper models for hero shots","o":"archivo"},"b826ad9667a2":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":37,"t":"Use reference image after the first successful shot","o":"archivo"},"717c03da642d":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":39,"t":"For Midjourney, use `--cref` with `--cw 50`","o":"archivo"},"6447bec15b56":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":53,"t":"The right answer is almost always: **don't put text in the prompt**. Composite separately from `text-overlays.json`.","o":"archivo"},"359736f73561":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":54,"t":"If text must be in-image (poster work), use Ideogram v3 with explicit override flag","o":"archivo"},"5945d25c9b90":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":56,"t":"Use simple fonts (sans-serif, clean serif), cursive and decorative fonts fail even on Ideogram","o":"archivo"},"ecb6a8e221f1":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":87,"t":"For GPT Image (best at spatial reasoning), use percentage references: \"subject at left 30% of frame\"","o":"archivo"},"982752f60d62":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":122,"t":"**Accept editorially when:** generation is close enough that retouching gets there. Don't burn API credits chasing perfect on-prompt.","o":"archivo"},"1f983ff0ee18":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":128,"t":"You've re-rolled the same shot 5+ times with no improvement → the prompt is fine; the model can't render this concept; pick a different shot or different generator","o":"archivo"},"12009aa60167":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":129,"t":"You're tweaking single words and hoping → you've hit prompt-level diminishing returns; move to image-to-image refinement (Nano Banana) or post-production","o":"archivo"},"4be94337bb02":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":130,"t":"The image is 80% right and the gap is editorial → ship to post and let the editor finish","o":"archivo"},"33fc833724e0":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":132,"t":"Generation is one stage in a pipeline. Don't try to make it the whole pipeline.","o":"archivo"},"bcaac139f9b7":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":16,"t":"\"Never\" list (things this brand never does, e.g. \"no stock photo aesthetic\", \"no AI uncanny\", \"no over-saturated\", \"no shouting copy\")","o":"archivo"},"67037c4b307e":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":60,"t":"**Never appears in image prompts** (except Ideogram Mode 2 with explicit override).","o":"archivo"},"e177c4f10a04":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":64,"t":"**Editability.** Composited text can be revised without re-generating images.","o":"archivo"},"4c22b71ebf0a":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":65,"t":"**Quality.** Even Ideogram and GPT Image (the best at text) produce typography that lags professional design tools.","o":"archivo"},"5f5e6ee4ad91":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":66,"t":"**Animation.** Animated text needs After Effects / Remotion / CapCut. Static rendered text is dead-on-arrival for motion content.","o":"archivo"}},"meta":{"reglas":852,"skills":11,"auditorias":343}};
const ETAPAS = D.etapas, CAT = Object.fromEntries(ETAPAS.map(e=>[e.clave,e]));
const $ = (s,r=document)=>r.querySelector(s);
const esc = s => String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const bytes = s => new TextEncoder().encode(s).length;
const uid = () => Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const nowIso = () => new Date().toISOString();
const MAX_BYTES = 62000;

// ------------------------------------------------------------ estado
let sample=null, db=null, mcp=null, caps={images:false};
let S = {proyectos:[], pid:null, view:'brief', imgs:[], busy:false, error:'', bloqueo:false, ajustes:{rondas:3, tierGen:'complex', tierAud:'default', rondasEval:1}};
// Nada de alert/confirm/prompt: dentro del visor de artifacts esos dialogos
// pueden estar bloqueados, y entonces el error no se ve por ningun lado.
function fallo(msg){ S.error=msg; render(); }
const P = () => S.proyectos.find(p=>p.id===S.pid);
const ajustesLS = 'ejecutor.ajustes';
try{ Object.assign(S.ajustes, JSON.parse(localStorage.getItem(ajustesLS)||'{}')); }catch(e){}

// ------------------------------------------------------------ persistencia
async function guardar(p){
  p.actualizado = nowIso();
  if(db){ try{ await db.doc('proyectos/'+p.id).set(p); return; }catch(e){ console.warn('db set',e); } }
  try{ localStorage.setItem('ejecutor.p.'+p.id, JSON.stringify(p)); }catch(e){}
}
async function cargarLista(){
  let lista=[];
  if(db){
    try{ const q = await db.collection('proyectos').orderBy('creado','desc').limit(100).get(); lista = q.docs.map(d=>d.data()); }
    catch(e){ console.warn('db list',e); }
  }
  if(!lista.length){
    for(let i=0;i<localStorage.length;i++){ const k=localStorage.key(i); if(k&&k.startsWith('ejecutor.p.')){ try{ lista.push(JSON.parse(localStorage.getItem(k))); }catch(e){} } }
    lista.sort((a,b)=>(b.creado||'').localeCompare(a.creado||''));
  }
  S.proyectos = lista;
}
function nuevoProyecto(){
  const p = {id:uid(), nombre:'Sin título', brief:'', creado:nowIso(), plan:null, etapas:{}, orden:[], evaluaciones:[]};
  S.proyectos.unshift(p); S.pid=p.id; S.imgs=[]; S.view='brief'; render();
}

// ------------------------------------------------------------ reglas
function reglasDe(casos){
  const ids = new Set();
  for(const c of casos||[]) for(const id of (D.porCaso[c]||[])) ids.add(id);
  const pri = {auditoria:0, regla:1, archivo:2};
  return [...ids].map(id=>({id, ...D.idx[id]})).sort((a,b)=>(pri[a.o]-pri[b.o])||a.s.localeCompare(b.s)||a.a.localeCompare(b.a)||a.l-b.l);
}
const lineaRegla = r => `- [${r.id}] (${r.s}) ${r.t}`;
function empacarReglas(reglas, presupuesto){
  const out=[]; let usado=0, n=0;
  for(const r of reglas){ const l=lineaRegla(r)+'\n'; const b=bytes(l); if(usado+b>presupuesto) break; out.push(l); usado+=b; n++; }
  return {texto:out.join(''), incluidas:n, total:reglas.length};
}
function tandasReglas(reglas, presupuesto){
  const tandas=[]; let cur=[], usado=0;
  for(const r of reglas){ const l=lineaRegla(r)+'\n'; const b=bytes(l); if(usado+b>presupuesto && cur.length){ tandas.push(cur.join('')); cur=[]; usado=0; } cur.push(l); usado+=b; }
  if(cur.length) tandas.push(cur.join(''));
  return tandas;
}
const corta = (s,n) => (s||'').length>n ? s.slice(0,n)+`\n[… recortado a ${n} caracteres]` : (s||'');

// ------------------------------------------------------------ prompts
function catalogoTexto(){
  return ETAPAS.map(e=>`- ${e.clave} · ${e.nombre}${e.cond?' — cuándo: '+e.cond:''}\n    entra: ${e.entra}\n    sale: ${e.sale}\n    gate: ${e.gate}\n    casos de reglas permitidos: ${e.casos.length?e.casos.join(', '):'ninguno (sin reglas de skill)'}${e.tracks.length?'\n    tracks: '+e.tracks.join(', '):''}${e.ok?'\n    requiere OK explícito del director antes de continuar':''}`).join('\n');
}
function casosTexto(){ return Object.entries(D.casos).filter(([k])=>k!=='NINGUNO').map(([k,v])=>`  ${k}: ${v} (${(D.porCaso[k]||[]).length} reglas)`).join('\n'); }

function promptPlan(p){
  return `Eres el director de producción de Final Upgrade AI. Recibes un BRIEF y decides qué etapas de trabajo hacen falta para entregarlo. No ejecutes ninguna etapa: solo planifica.

CATÁLOGO DE ETAPAS (usa solo estas claves, en el orden en que deben ejecutarse):
${catalogoTexto()}

TRACKS DE VIDEO:
${Object.entries(D.tracks).map(([k,v])=>`  ${k}: ${v}`).join('\n')}

CASOS DE PRODUCCIÓN (cada etapa toma las reglas de sus casos):
${casosTexto()}

REGLAS DE PLANIFICACIÓN:
- Un brief de una sola imagen → una sola etapa PROMPT_IMAGEN con el caso exacto (T1 rostro, T2 cuerpo, T3 escena con 1 persona, T4 con 2 personas, T5 edición, PROD producto sin persona, GRAF pieza gráfica, MULTI grid).
- Un brief que pide el prompt para recrear una imagen adjunta → REF (hay ${S.imgs.length} imagen(es) adjunta(s)).
- Un brief de un solo clip de video → PROMPT_VIDEO.
- Un brief de video completo (spot, campaña, reel con narrativa, brand film) → etapas E0–E7 según el track. E0 solo si hay marca o cliente. E5 lleva solo los casos de imagen que el proyecto necesita.
- Un brief que pide estrategia o plan de algo que no es una pieza visual → ESTRATEGIA, y DOC por cada entregable adicional que pida.
- Cada etapa lleva: objetivo específico para ESTE brief (no genérico), el entregable exacto, y de 3 a 6 criterios de aceptación verificables, escritos para que un auditor pueda marcarlos cumplido / no cumplido con evidencia textual.
- "formato" es el formato de entrega de la pieza y manda sobre todos los prompts. Dedúcelo del brief: 9:16 para TikTok, Reels y Shorts; 16:9 para YouTube y spot apaisado; 1:1 para post de feed; 4:5 para feed vertical de Instagram. Si el brief no lo dice, elige el que corresponde al medio que menciona y anótalo en "supuestos". "duracion" solo para video.
- "usaImagenes": true solo en etapas que necesitan ver las imágenes adjuntas.
- Si el brief es ambiguo, no preguntes: decide y anota el supuesto en "supuestos".
- Responde en español.

BRIEF:
<<<
${corta(p.brief, 30000)}
>>>

Responde SOLO con JSON con esta forma exacta:
{"nombre":"título corto del proyecto","tipo":"qué se va a producir","track":"EXPRESS|STANDARD|FILM|null","resumen":"2 líneas","formato":{"aspect":"9:16","resolucion":"1080x1920","duracion":"30s o null"},"supuestos":["..."],"etapas":[{"clave":"E5","nombre":"nombre para este proyecto","objetivo":"...","entregable":"...","casos":["T3"],"criterios":["..."],"usaImagenes":false}]}`;
}

const PARAMS = `
PARÁMETROS DE GENERACIÓN — obligatorios junto a CADA prompt de imagen o video.
Un prompt sin aspect ratio está incompleto y se rechaza. Debajo de cada bloque
de código va una línea rotulada "Parámetros de generación:" con modelo, aspect
ratio, resolución o tamaño en píxeles, y duración si es video.
Dónde se escribe cada parámetro depende del modelo, y equivocarse es un error:
- Midjourney los lee DENTRO del prompt, como \`--ar 9:16\`.
- Nano Banana ignora \`--ar\` dentro del prompt: espera el parámetro \`aspectRatio\`.
- Seedream ignora \`--ar\`: aspect_ratio va como parámetro.
- GPT Image ignora \`--ar\` y las banderas de peso: el tamaño va como parámetro
  (1024x1024, 1536x1024 apaisado, 1024x1536 vertical).
- Seedance 2.5: duración, aspect ratio y resolución se fijan en la página de
  generación o por API y NO van en el texto del prompt.
Cuando el parámetro no va dentro del prompt, se entrega igual en esa línea
aparte, diciendo que se fija en la página de generación.`;

function fmtTexto(p){
  const f = (p.plan&&p.plan.formato)||null;
  if(!f || !f.aspect) return 'sin definir — dedúcelo del brief y dilo explícitamente';
  return [f.aspect, f.resolucion, f.duracion].filter(Boolean).join(' · ');
}

function contextoAprobado(p, hastaKey, limite){
  const partes=[]; let usado=0;
  for(const k of p.orden){ if(k===hastaKey) break; const e=p.etapas[k]; if(!e||!e.output||!['aprobada','espera_ok'].includes(e.estado)) continue;
    const t = `## ${e.nombre} (${e.clave})\n${e.output}\n`; partes.push(t); usado+=t.length; }
  let s = partes.join('\n');
  if(s.length>limite){ s = s.slice(s.length-limite); s = '[… contexto anterior recortado]\n'+s; }
  return s;
}

function promptEtapa(p, e, correcciones, feedback){
  const cat = CAT[e.clave]||{};
  const fijo = `Eres el ejecutor de la etapa "${e.nombre}" (${e.clave}: ${cat.nombre||''}) de un pipeline de producción visual con IA. Tu objetivo es maximizar la calidad del entregable, nunca ahorrar esfuerzo. Este entregable será auditado contra cada criterio y cada regla listada abajo; lo que no cumpla se rechaza y se vuelve a pedir.

BRIEF DEL PROYECTO:
<<<
${corta(p.brief, 20000)}
>>>

OBJETIVO DE ESTA ETAPA: ${e.objetivo}
ENTREGABLE EXACTO: ${e.entregable}
FORMATO DE ENTREGA DEL PROYECTO: ${fmtTexto(p)}
QUÉ SALE SEGÚN EL SKILL: ${cat.sale||''}
GATE DE LA ETAPA: ${cat.gate||''}
CRITERIOS DE ACEPTACIÓN:
${(e.criterios||[]).map((c,i)=>`${i+1}. ${c}`).join('\n')}
${feedback?`\nINSTRUCCIONES DEL DIRECTOR PARA ESTA ITERACIÓN (obligatorias):\n${feedback}\n`:''}${correcciones&&correcciones.length?`\nCORRECCIONES OBLIGATORIAS — el auditor rechazó la versión anterior por esto; cada punto debe quedar resuelto:\n${correcciones.map(f=>`- [${f.ref}] ${f.correccion}${f.evidencia?' (evidencia: '+f.evidencia+')':''}`).join('\n')}\n`:''}
FORMATO DE SALIDA: Markdown en español. Los prompts finales para modelos de imagen o video van en inglés, cada uno dentro de un bloque de código, precedido de su cabecera de 3 líneas SKILL: / RIESGOS: / TÉCNICA: y del modelo recomendado. Sin disculpas, sin preámbulos, sin resumen final: solo el entregable completo.
${PARAMS}
`;
  const ctx = contextoAprobado(p, e.key, 14000);
  const ctxTxt = ctx ? `\nCONTEXTO APROBADO DE ETAPAS ANTERIORES (es la fuente de verdad; no lo contradigas):\n${ctx}\n` : '';
  const reglas = reglasDe(e.casos);
  const cabecera = `REGLAS OBLIGATORIAS DE LOS SKILLS (casos ${(e.casos||[]).join(', ')||'ninguno'}):\n`;
  const presupuesto = MAX_BYTES - bytes(fijo) - bytes(ctxTxt) - bytes(cabecera) - 800;
  const pack = empacarReglas(reglas, Math.max(presupuesto, 0));
  const nota = pack.incluidas<pack.total ? `(caben ${pack.incluidas} de ${pack.total}; el resto se verifica en la auditoría)\n` : '';
  return {prefijo: reglas.length ? cabecera+nota+pack.texto : '', texto: fijo + ctxTxt,
          incluidas:pack.incluidas, total:pack.total};
}

function promptAuditoria(p, e, output, tanda, i, n){
  const prefijo = tanda ? `REGLAS A VERIFICAR (tanda ${i} de ${n}):\n${tanda}` : '';
  const texto = `Eres el auditor de calidad de la etapa "${e.nombre}" (${e.clave}). Tu única tarea es verificar si el ENTREGABLE cumple los CRITERIOS y las REGLAS. No lo reescribas ni lo mejores. Está prohibido aprobar para complacer: si una regla aplicable a este entregable no se cumple, es una falla. Una regla que no aplica a este tipo de entregable no es falla. Cada falla lleva la referencia (id de regla o número de criterio), evidencia textual (cita del entregable, o "ausente" si falta algo obligatorio) y una corrección concreta que el ejecutor pueda aplicar sin adivinar.

BRIEF (resumen): ${corta(p.brief, 3000)}
OBJETIVO DE LA ETAPA: ${e.objetivo}
ENTREGABLE ESPERADO: ${e.entregable}
GATE: ${(CAT[e.clave]||{}).gate||''}
CRITERIOS:
${(e.criterios||[]).map((c,k)=>`${k+1}. ${c}`).join('\n')}

CHEQUEO OBLIGATORIO, ADEMÁS DE LOS CRITERIOS: si el entregable contiene uno o más
prompts de imagen o video, cada uno debe traer su línea de "Parámetros de
generación" con modelo, aspect ratio, resolución o tamaño, y duración si es
video, coherentes con el formato de entrega del proyecto (${fmtTexto(p)}).
Un prompt sin aspect ratio es una falla con ref "FORMATO". Además es falla usar
\`--ar\` con Nano Banana, Seedream o GPT Image, que lo ignoran, o meter duración,
aspect ratio o resolución dentro del texto del prompt en Seedance 2.5, donde se
fijan en la página de generación.

${tanda?'Las reglas a verificar están listadas arriba.':'(esta etapa no tiene reglas de skill; audita solo los criterios)'}

ENTREGABLE A AUDITAR:
<<<
${corta(output, 24000)}
>>>

Responde SOLO con JSON: {"veredicto":"APRUEBA"|"RECHAZA","fallas":[{"ref":"id de regla o C1..C6","evidencia":"...","correccion":"..."}],"nota":"una línea"}`;
  return {prefijo, texto};
}

// Dentro del visor de artifacts no hay cache de prefijo: ahi el bloque de
// reglas se concatena, que es lo que ya se hacia. Con servidor propio va
// aparte y marcado, y la API lo lee de cache.
function conPrefijo(pr, o){
  return SRV ? [pr.texto, Object.assign({}, o||{}, {cachePrefix:pr.prefijo})]
             : [(pr.prefijo? pr.prefijo+'\n\n':'') + pr.texto, o];
}

function promptEvalImagen(p, refTexto, nImgs){
  return `Eres el evaluador de assets de Final Upgrade AI. Se adjuntan ${nImgs} imagen(es) generadas con IA. Evalúa si cumplen con el BRIEF y con lo APROBADO. Sé específico y visual: describe lo que ves antes de juzgar. Prohibido aprobar para complacer.

BRIEF:
<<<
${corta(p.brief, 12000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
RÚBRICA: fidelidad al brief · identidad y consistencia de personajes/marca · composición y lente · luz y color · legibilidad de texto si lo hay · artefactos de IA (manos, ojos, texto roto, geometría imposible, superficies plásticas) · lo que un cliente notaría primero.

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"descripcion":"qué se ve, 2-3 líneas","criterios":[{"criterio":"...","cumple":true|false,"evidencia":"..."}],"correcciones":["instrucción concreta para el siguiente intento"],"prompt_ajustado":"si aplica, el cambio de prompt sugerido en inglés"}`;
}

function promptEvalVideo(p, refTexto, escenas){
  const esc = escenas.map(s=>`Escena ${s.scene_number} [${s.timestamp_start}–${s.timestamp_end}] ${s.label||''} · ${s.shot_type||''}\n  visual: ${s.visual}\n  audio: ${s.audio||'—'}`).join('\n');
  return `Eres el evaluador de video de Final Upgrade AI. Un analizador externo describió el video escena por escena (abajo). Con esa descripción, evalúa si el video cumple con el BRIEF y con lo APROBADO. Prohibido aprobar para complacer. Si la descripción no permite verificar un criterio, dilo como "no verificable" en vez de suponer.

BRIEF:
<<<
${corta(p.brief, 10000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
ANÁLISIS ESCENA POR ESCENA:
${corta(esc, 20000)}

RÚBRICA: fidelidad al brief y a los shots aprobados · continuidad de personajes, vestuario y entorno entre escenas · cámara y ritmo · dramaturgia (¿hay cambio de emoción, avance o presión?) · texto en pantalla y audio · artefactos de IA (morphing, manos, física imposible).

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"criterios":[{"criterio":"...","cumple":true|false|null,"evidencia":"..."}],"por_escena":[{"escena":1,"nota":"..."}],"correcciones":["..."]}`;
}

function promptEvalCuadros(p, refTexto, tiempos){
  return `Eres el evaluador de video de Final Upgrade AI. Se adjuntan ${tiempos.length} cuadros extraídos del mismo video, en orden, en estos segundos: ${tiempos.map(t=>t.toFixed(1)+'s').join(', ')}. Son muestras, no el video completo: no puedes juzgar movimiento continuo ni audio, y lo que no puedas verificar con los cuadros dilo como "no verificable" en vez de suponerlo.

BRIEF:
<<<
${corta(p.brief, 10000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
RÚBRICA: fidelidad al brief y a los shots aprobados · continuidad de personaje, vestuario y entorno entre cuadros · encuadre y composición · luz y color · texto en pantalla · artefactos de IA (manos, ojos, texto roto, morphing entre cuadros).

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"descripcion":"qué se ve, 2-3 líneas","criterios":[{"criterio":"...","cumple":true|false|null,"evidencia":"..."}],"por_escena":[{"escena":"0.0s","nota":"..."}],"correcciones":["..."]}`;
}

function referenciaAprobada(p){
  const partes=[];
  for(const k of p.orden){ const e=p.etapas[k]; if(e&&e.output&&e.estado==='aprobada') partes.push(`## ${e.nombre}\n${e.output}`); }
  return corta(partes.join('\n\n'), 18000);
}

// ------------------------------------------------------------ servidor propio (Vercel)
// Dentro de claude.ai la pagina usa las capacidades del visor. Servida desde
// un dominio propio no hay visor: se habla con /api/sample, que corre en el
// servidor con la API key del proyecto.
let SRV=null;
const claveLS='ejecutor.clave';
async function detectarServidor(){
  if(!/^https?:$/.test(location.protocol)) return null;
  try{ const r=await fetch('/api/config',{cache:'no-store',headers:cabeceras()}); if(!r.ok) return null; const j=await r.json(); return j&&j.servidor?j:null; }catch(e){ return null; }
}
function claveGuardada(){ try{ return localStorage.getItem(claveLS)||''; }catch(e){ return ''; } }
function cabeceras(){ const h={'Content-Type':'application/json'}; const k=claveGuardada(); if(k) h['x-app-password']=k; return h; }
async function probarClave(k){
  try{ const r=await fetch('/api/config',{cache:'no-store',headers:{'x-app-password':k}}); if(!r.ok) return null; return await r.json(); }catch(e){ return null; }
}
// El cuerpo de una peticion a Vercel no puede pasar de 4.5 MB — medido: hasta
// 4.0 MB pasa, 4.4 MB devuelve FUNCTION_PAYLOAD_TOO_LARGE. Base64 infla un
// tercio. Asi que las imagenes se reducen aqui hasta que el total quepa, y si
// no cabe no se manda: rebotar con 413 no le sirve a nadie.
const PRESUPUESTO = 3200000;                                   // base64, total
const PASOS = [[1568, 0.85], [1100, 0.8], [800, 0.72], [560, 0.6]];

async function aBitmap(blob){
  try{ return await createImageBitmap(blob, {imageOrientation:'from-image'}); }
  catch(e){ try{ return await createImageBitmap(blob); }catch(e2){ return null; } }
}
function b64de(buf){
  let bin=''; const b=new Uint8Array(buf);
  for(let i=0;i<b.length;i+=0x8000) bin+=String.fromCharCode.apply(null,b.subarray(i,i+0x8000));
  return btoa(bin);
}
async function codificar(bmp, lado, calidad){
  const k=Math.min(1, lado/Math.max(bmp.width,bmp.height));
  const w=Math.max(1,Math.round(bmp.width*k)), h=Math.max(1,Math.round(bmp.height*k));
  const c=document.createElement('canvas'); c.width=w; c.height=h;
  c.getContext('2d').drawImage(bmp,0,0,w,h);
  return await new Promise(r=>c.toBlob(r,'image/jpeg',calidad));
}
// Devuelve { imagenes, avisos }. Nunca devuelve algo que no quepa.
async function prepararImagenes(archivos){
  const avisos=[], bmps=[];
  for(const f of archivos||[]){
    const bm = await aBitmap(f);
    if(!bm){ avisos.push(`"${f.name}": el navegador no puede leer este formato. Si es HEIC (el de iPhone y Mac por defecto), ábrela y expórtala como JPG.`); continue; }
    bmps.push({bm, nombre:f.name});
  }
  if(!bmps.length) return {imagenes:[], avisos};
  let blobs=null;
  for(const [lado,cal] of PASOS){
    blobs = [];
    for(const x of bmps) blobs.push(await codificar(x.bm, lado, cal));
    if(blobs.reduce((t,b)=>t+b.size,0)*4/3 <= PRESUPUESTO) break;
  }
  // Ni en el paso mas chico caben todas: se mandan las que quepan y se avisa.
  const usados=[]; let total=0;
  for(let i=0;i<blobs.length;i++){
    const peso = blobs[i].size*4/3;
    if(total+peso > PRESUPUESTO){
      avisos.push(`"${bmps[i].nombre}" no se envió: entre todas superan el límite de 4.5 MB del servidor. Manda menos imágenes por vez.`);
      continue;
    }
    total+=peso; usados.push(blobs[i]);
  }
  const imagenes=[];
  for(const b of usados) imagenes.push({media_type:'image/jpeg', data:b64de(await b.arrayBuffer())});
  for(const x of bmps) if(x.bm.close) x.bm.close();
  return {imagenes, avisos};
}

function parseJSONsuelto(txt){
  const t=(txt||'').trim();
  try{ return JSON.parse(t); }catch(e){}
  const f=/```(?:json)?\s*([\s\S]*?)```/.exec(t); if(f){ try{ return JSON.parse(f[1]); }catch(e){} }
  const i=Math.min(...[t.indexOf('{'),t.indexOf('[')].filter(x=>x>=0)), j=Math.max(t.lastIndexOf('}'),t.lastIndexOf(']'));
  if(isFinite(i)&&j>i){ try{ return JSON.parse(t.slice(i,j+1)); }catch(e){} }
  throw {code:'invalid_json', message:'La respuesta no traía JSON.', text:txt};
}
function sampleDeServidor(){
  const f = async (input, o={}) => {
    const cuerpo = {input, modelTier:o.modelTier||'default'};
    if(o.cachePrefix) cuerpo.cachePrefix=o.cachePrefix;
    if(o.images && o.images.length){
      const prep = await prepararImagenes([...o.images]);
      if(prep.imagenes.length) cuerpo.images = prep.imagenes;
      if(prep.avisos.length){
        if(!prep.imagenes.length) throw {code:'image_rejected', message:prep.avisos.join(' ')};
        S.error = prep.avisos.join(' ');
      }
    }
    const crudo = JSON.stringify(cuerpo);
    if(crudo.length > 4000000) throw {code:'prompt_too_large', message:'La petición pesa '+(crudo.length/1048576).toFixed(1)+' MB y el servidor acepta 4.5 MB. Quita alguna imagen o acorta el brief.'};
    let r;
    try{ r = await fetch('/api/sample',{method:'POST',headers:cabeceras(),body:crudo,signal:o.signal}); }
    catch(e){ throw (o.signal&&o.signal.aborted) ? {code:'cancelled',message:'Detenido.'} : {code:'upstream_error', message:'No se pudo llegar al servidor.'}; }
    if(r.status===401){ S.bloqueo=true; render(); throw {code:'not_granted', message:'La contraseña de la app cambió. Vuelve a escribirla.'}; }
    if(r.status===413) throw {code:'prompt_too_large', message:'Las imágenes pesan demasiado para el servidor. Recarga la página y vuelve a adjuntarlas: la versión nueva las reduce automáticamente.'};
    if(!r.ok){ let j={}; try{ j=await r.json(); }catch(e){} throw {code:j.code||'upstream_error', message:j.message||('El servidor respondió '+r.status)}; }
    const rd=r.body.getReader(), dec=new TextDecoder(); let buf='', texto='', pensando='', trunc=false, err=null;
    for(;;){
      let chunk; try{ chunk=await rd.read(); }catch(e){ throw {code:'cancelled', message:'Detenido.', text:texto}; }
      if(chunk.done) break;
      buf+=dec.decode(chunk.value,{stream:true});
      let k;
      while((k=buf.indexOf('\n\n'))>=0){
        const linea=buf.slice(0,k).replace(/^data:\s?/,''); buf=buf.slice(k+2);
        if(!linea) continue;
        let ev; try{ ev=JSON.parse(linea); }catch(e){ continue; }
        if(ev.t==='text'){ texto+=ev.d; if(o.onText) o.onText({text:texto, delta:ev.d}); }
        else if(ev.t==='think'){ pensando+=ev.d; if(o.onThink) o.onThink({text:pensando}); }
        else if(ev.t==='done'){ trunc=!!ev.truncated; if(ev.usage&&o.onUso) o.onUso(ev.usage); }
        else if(ev.t==='error'){ err={code:ev.code, message:ev.message, text:texto||undefined}; }
      }
    }
    if(err) throw err;
    if(!texto.trim()) throw {code:'empty_completion', message:'El modelo no escribió nada.'};
    return {text:texto, truncated:trunc};
  };
  f.json = async (input,o) => parseJSONsuelto((await f(input,o)).text);
  f.limits = async () => ({maxPromptBytes:65536, images:{maxCount:8, maxInputBytes:20000000, mediaTypes:['image/jpeg','image/png','image/webp','image/gif']}});
  return f;
}

function motivoSinClaude(){
  if(SRV && !SRV.ia) return 'El servidor no tiene OPENAI_API_KEY configurada. Ponla en las variables de entorno del proyecto de Vercel y vuelve a desplegar.';
  if(SRV) return 'El servidor no respondió. Recarga la página.';
  if(window.claude && window.claude.use) return 'Esta página no tiene permiso para usar Claude. Vuelve a abrir el artifact desde el enlace original; si sigue igual, hay que volver a publicarlo declarando la capacidad sample.';
  return 'Esta copia de la página no está conectada a Claude. Ábrela desde el artifact en claude.ai o desde el dominio donde está desplegada.';
}

// ------------------------------------------------------------ llamadas
function errMsg(e){
  const m = {not_granted:'No autorizaste el uso del modelo en esta página.', rate_limited:'Límite de uso alcanzado. Espera un momento y vuelve a intentar.', prompt_too_large:'El brief o el contexto es demasiado grande para una llamada.', invalid_json:'La respuesta no vino en el formato esperado. Vuelve a intentar.', refused:'El modelo rechazó esta entrada. Cambia el brief.', cancelled:'Detenido.', images_unavailable:'Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en https://ai-production-director.vercel.app', image_rejected:'Imagen rechazada: tipo o tamaño no válido.', sampling_disabled:'El modelo no está disponible en esta cuenta.'};
  // Cuando el mensaje lo escribio esta pagina (nombra el archivo, el peso, el
  // formato), gana sobre el texto generico del codigo.
  if(e && e.message && ['image_rejected','prompt_too_large','upstream_error','not_granted'].includes(e.code) && e.message.length>40) return e.message;
  return m[e&&e.code] || ((e&&e.message)||'Error inesperado.');
}
let ctl=null; const VOZ={rec:null};
// Una llamada con esfuerzo alto tarda minutos y pasa el primer tramo pensando
// en silencio. Sin un contador corriendo, eso se lee como una app trabada.
let RELOJ=null, T0=0;
function relojOn(){ T0=Date.now(); clearInterval(RELOJ); RELOJ=setInterval(()=>{
  const t=Math.round((Date.now()-T0)/1000);
  const txt = t<60 ? t+'s' : Math.floor(t/60)+'m '+String(t%60).padStart(2,'0')+'s';
  document.querySelectorAll('.reloj').forEach(el=>el.textContent=txt);
},1000); }
function relojOff(){ clearInterval(RELOJ); RELOJ=null; }
function opts(tier, extra){ ctl = new AbortController(); return Object.assign({modelTier:tier, cache:false, signal:ctl.signal}, extra||{}); }

async function planificar(){
  const p=P(); if(!p) return;
  if(!p.brief.trim()) return fallo('Escribe el brief primero.');
  if(!sample) return fallo(motivoSinClaude());
  S.error=''; S.busy='Leyendo el brief…'; render();
  try{
    relojOn();
    const paso = m => { S.busy=m; const el=$('#busyN'); if(el) el.textContent=m; };
    const o = opts(S.ajustes.tierGen, {
      onThink:({text})=>paso('Pensando el plan… '+text.length+' caracteres'),
      onText:({text})=>paso('Escribiendo el plan… '+text.length+' caracteres'),
    });
    if(S.imgs.length) o.images = S.imgs.slice(0, (caps.images&&caps.images.maxCount)||S.imgs.length);
    const plan = await sample.json(promptPlan(p), o);
    if(!plan||!Array.isArray(plan.etapas)||!plan.etapas.length) throw {code:'invalid_json', message:'sin etapas'};
    p.plan = plan; if(plan.nombre) p.nombre = plan.nombre;
    p.orden=[]; p.etapas={};
    plan.etapas.forEach((e,i)=>{ const key=`${e.clave}_${i}`; const cat=CAT[e.clave]||{}; const casos=(e.casos||[]).filter(c=>(cat.casos||[]).includes(c)); p.orden.push(key);
      p.etapas[key]={key, clave:e.clave, nombre:e.nombre||cat.nombre||e.clave, objetivo:e.objetivo||'', entregable:e.entregable||cat.sale||'', casos: casos.length?casos:(cat.casos||[]).slice(0, cat.clave==='E5'?0:99), criterios:e.criterios||[], usaImagenes:!!e.usaImagenes, ok:!!cat.ok, estado:'pendiente', output:'', rondas:[], feedback:''}; });
    S.view='plan'; await guardar(p);
  }catch(e){ S.error=errMsg(e); }
  relojOff(); S.busy=false; render();
}

async function ejecutarEtapa(key){
  const p=P(); const e=p.etapas[key]; if(!e||!sample) return;
  const max = Number(S.ajustes.rondas)||3;
  let correcciones = e.rondas.length && e.estado==='agotada' ? (e.rondas[e.rondas.length-1].fallas||[]) : [];
  let ronda = e.estado==='agotada' ? e.rondas.length : 0;
  if(e.estado!=='agotada'){ e.rondas=[]; }
  const feedback = e.feedback||'';
  const limite = ronda+max;
  while(ronda<limite){
    ronda++;
    e.estado='generando'; e.progreso=`ronda ${ronda} · generando`; e.parcial=''; relojOn(); render(); await guardar(p);
    const tRonda = Date.now();
    const pr = promptEtapa(p, e, correcciones, feedback);
    e.reglasIncluidas=pr.incluidas; e.reglasTotal=pr.total;
    let out, uso=null;
    try{
      const pinta = t => { e.parcial=t; const el=$(`#parcial-${key}`); if(el) el.textContent=t; };
      const o = opts(S.ajustes.tierGen, {
        onThink:({text})=>{ e.progreso=`ronda ${ronda} · pensando`; pinta(text); },
        onText:({text})=>{ e.progreso=`ronda ${ronda} · escribiendo`; pinta(text); },
        onUso:u=>{ uso=u; },
      });
      if(e.usaImagenes && S.imgs.length) o.images = S.imgs.slice(0, (caps.images&&caps.images.maxCount)||S.imgs.length);
      const r = await sample(...conPrefijo(pr, o)); out = r.text; if(r.truncated) out += '\n\n[SALIDA TRUNCADA por el límite del modelo]';
    }catch(err){ relojOff(); e.estado = e.output?'rechazada':'pendiente'; e.error=errMsg(err); e.parcial=''; render(); await guardar(p); return; }
    e.parcial='';
    // auditoría en tandas: cubre el 100% de las reglas del caso
    e.estado='auditando'; render();
    const reglas = reglasDe(e.casos);
    const tandas = reglas.length ? tandasReglas(reglas, 22000) : [''];
    let fallas=[], veredicto='APRUEBA', notas=[];
    // Las tandas son independientes: en serie multiplican la espera por nada.
    e.progreso=`ronda ${ronda} · auditando ${tandas.length} tanda(s) de reglas`; render();
    const ctlAud=new AbortController(); ctl=ctlAud;
    const res = await Promise.all(tandas.map((t,i)=>
      sample.json(...conPrefijo(promptAuditoria(p, e, out, t, i+1, tandas.length),
                  {modelTier:S.ajustes.tierAud, cache:false, signal:ctlAud.signal}))
        .then(a=>({a})).catch(err=>({err, i}))));
    for(const r of res){
      if(r.err){ notas.push('auditoría '+(r.i+1)+' falló: '+errMsg(r.err)); continue; }
      const a=r.a;
      if(a && a.veredicto==='RECHAZA') veredicto='RECHAZA';
      if(a && Array.isArray(a.fallas)) fallas.push(...a.fallas.filter(f=>f&&(f.correccion||f.ref)));
      if(a && a.nota) notas.push(a.nota);
    }
    if(veredicto==='APRUEBA' && fallas.length) veredicto='RECHAZA';
    e.rondas.push({n:ronda, veredicto, fallas, notas, fecha:nowIso(), palabras:out.split(/\s+/).length,
                   cache: (uso&&uso.cache_read_input_tokens)||0,
                   seg: Math.round((Date.now()-tRonda)/1000)});
    e.output = out;
    if(veredicto==='APRUEBA'){ relojOff(); e.estado = e.ok?'espera_ok':'aprobada'; e.progreso=''; e.feedback=''; render(); await guardar(p); if(!e.ok) continuar(); return; }
    correcciones = fallas; e.estado='rechazada'; render(); await guardar(p);
  }
  relojOff(); e.estado='agotada'; e.progreso=''; render(); await guardar(p);
}

function siguientePendiente(p){
  for(const k of p.orden){ const e=p.etapas[k]; if(e.estado==='pendiente') return k; if(!['aprobada'].includes(e.estado)) return null; }
  return null;
}
async function continuar(){ const p=P(); if(!p) return; const k=siguientePendiente(p); if(k) await ejecutarEtapa(k); else render(); }
async function iniciar(){ const p=P(); if(!p||!p.orden.length) return; S.view='run'; render(); await continuar(); }
async function aprobar(key){ const p=P(); p.etapas[key].estado='aprobada'; render(); await guardar(p); await continuar(); }
async function iterar(key){
  const p=P(); const e=p.etapas[key]; const fb=($(`#fb-${key}`)||{}).value||'';
  if(!fb.trim()) return fallo('Escribe qué quieres cambiar en esa etapa.');
  const idx=p.orden.indexOf(key); const abajo=p.orden.slice(idx+1).filter(k=>p.etapas[k].estado!=='pendiente');
  if(abajo.length && !e.confirmado){ e.confirmado=true; return fallo(`Iterar "${e.nombre}" reinicia ${abajo.length} etapa(s) posteriores. Vuelve a darle a Iterar para confirmar.`); }
  e.confirmado=false; S.error='';
  for(const k of abajo){ Object.assign(p.etapas[k], {estado:'pendiente', output:'', rondas:[], feedback:''}); }
  e.feedback=fb; e.estado='pendiente'; e.rondas=[]; await guardar(p); await ejecutarEtapa(key);
}
async function otraRonda(key){ await ejecutarEtapa(key); }
async function aprobarAsi(key){ const p=P(); const e=p.etapas[key];
  if(!e.confirmado){ e.confirmado=true; return fallo('El auditor no aprobó esta versión. Vuelve a darle a "Aprobar así" para confirmar.'); }
  e.confirmado=false; S.error=''; e.estado='aprobada'; await guardar(p); render(); await continuar(); }
function detener(){ if(ctl) ctl.abort(); }

// ------------------------------------------------------------ evaluador
let EV = {modo:'imagen', imgs:[], fuente:'cuadros', url:'', gens:null, genSel:null, file:null, n:6, miniaturas:[], estado:'', res:null, escenas:null, analisisId:null, err:''};
async function evaluarImagen(){
  const p=P(); if(!p||!sample||!EV.imgs.length) return;
  EV.estado='Evaluando…'; EV.res=null; EV.err=''; render();
  try{
    const r = await sample.json(promptEvalImagen(p, referenciaAprobada(p), EV.imgs.length), opts(S.ajustes.tierGen, {images:EV.imgs.slice(0, (caps.images&&caps.images.maxCount)||EV.imgs.length)}));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'imagen', fecha:nowIso(), n:EV.imgs.length, veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err=errMsg(e); }
  EV.estado=''; render();
}
function mcpErr(e){
  const m={server_not_connected:'Higgsfield no está conectado en esta cuenta. Agrégalo en claude.ai → Settings → Connectors.', needs_reauth:'Higgsfield pide volver a autorizar. Reconéctalo en claude.ai → Settings → Connectors.', not_in_manifest:'Esta herramienta no está en el manifiesto de la página.', tool_error:'Higgsfield reportó un error: '+((e&&e.message)||''), not_granted:'No autorizaste el conector para esta página.', selection_required:'Tienes más de un conector Higgsfield: elige uno cuando la página lo pida.'};
  return m[e&&e.code] || ((e&&e.message)||'Error del conector.');
}
async function cargarGeneraciones(){
  if(!mcp) return; EV.estado='Cargando tus generaciones de video…'; EV.err=''; render();
  try{ const r = await mcp.callTool('Higgsfield','show_generations',{type:'video', size:24}); const pl = r.payload||{}; EV.gens = (pl.items||[]).filter(g=>g.status==='completed' && g.results && g.results.rawUrl); }
  catch(e){ EV.err=mcpErr(e); }
  EV.estado=''; render();
}
async function extraerCuadros(file, n){
  const v=document.createElement('video'); v.muted=true; v.playsInline=true; v.preload='auto';
  const url=URL.createObjectURL(file); v.src=url;
  try{
    await new Promise((res,rej)=>{ v.onloadedmetadata=()=>res(); v.onerror=()=>rej(new Error('el navegador no pudo leer este video')); });
    const dur = isFinite(v.duration)&&v.duration>0 ? v.duration : 0;
    const cuadros=[], tiempos=[];
    for(let i=0;i<n;i++){
      const t = dur ? dur*(i+0.5)/n : 0;
      await new Promise((res,rej)=>{ v.onseeked=()=>res(); v.onerror=()=>rej(new Error('no se pudo avanzar el video')); v.currentTime=Math.min(t, Math.max(0,dur-0.05)); });
      const w=Math.min(v.videoWidth||640, 1024), h=Math.round((v.videoHeight||360)*(w/(v.videoWidth||640)));
      const c=document.createElement('canvas'); c.width=w; c.height=h;
      c.getContext('2d').drawImage(v,0,0,w,h);
      const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',0.85));
      if(!blob) throw new Error('no se pudo capturar el cuadro');
      cuadros.push(blob); tiempos.push(t);
      if(!dur) break;
    }
    return {cuadros, tiempos};
  } finally { URL.revokeObjectURL(url); }
}
async function evaluarCuadros(){
  const p=P(); if(!p||!sample||!EV.file) return;
  EV.res=null; EV.escenas=null; EV.err=''; EV.estado='Extrayendo cuadros…'; render();
  try{
    const {cuadros, tiempos} = await extraerCuadros(EV.file, Number(EV.n)||6);
    EV.miniaturas = cuadros.map(b=>URL.createObjectURL(b));
    EV.estado=`Evaluando ${cuadros.length} cuadros…`; render();
    const r = await sample.json(promptEvalCuadros(p, referenciaAprobada(p), tiempos), opts(S.ajustes.tierGen, {images:cuadros}));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'video (cuadros)', fecha:nowIso(), veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err = (e&&e.code)?errMsg(e):('No se pudo procesar el video: '+((e&&e.message)||e)); }
  EV.estado=''; render();
}
const esYouTube = u => /^https:\/\/((www\.|m\.)?youtube\.com\/|youtu\.be\/)/.test(u);
async function evaluarVideo(){
  const p=P(); if(!p||!sample||!mcp) return;
  let url = EV.fuente==='gens' ? (EV.genSel&&EV.genSel.results.rawUrl) : EV.url.trim();
  if(!url){ EV.err='Falta el video.'; render(); return; }
  EV.res=null; EV.escenas=null; EV.err='';
  try{
    let input;
    if(esYouTube(url)) input={youtube_url:url};
    else { EV.estado='Importando el video a Higgsfield…'; render(); const im = await mcp.callTool('Higgsfield','media_import_url',{url, type:'video'}); const id=(im.payload||{}).media_id; if(!id) throw {code:'tool_error', message:'la importación no devolvió media_id'}; input={video_input_id:id}; }
    EV.estado='Pidiendo el análisis escena por escena (10 créditos de Higgsfield)…'; render();
    const cr = await mcp.callTool('Higgsfield','video_analysis_create', input);
    const aid = ((cr.payload||{}).result||{}).id; if(!aid) throw {code:'tool_error', message:'no llegó el id del análisis'};
    EV.analisisId=aid;
    const t0=Date.now(); let res=null;
    while(Date.now()-t0 < 12*60*1000){
      await new Promise(r=>setTimeout(r,6000));
      EV.estado=`Analizando el video… ${Math.round((Date.now()-t0)/1000)}s`; render();
      const st = await mcp.callTool('Higgsfield','video_analysis_status',{video_analyze_id:aid},{cache:false});
      res = (st.payload||{}).result||{};
      if(res.status==='completed') break;
      if(res.status==='failed') throw {code:'tool_error', message:res.fail_reason||'el análisis falló'};
    }
    if(!res||res.status!=='completed') throw {code:'tool_error', message:'el análisis no terminó en 12 minutos'};
    EV.escenas = res.scenes||[];
    EV.estado='Evaluando contra el brief…'; render();
    const r = await sample.json(promptEvalVideo(p, referenciaAprobada(p), EV.escenas), opts(S.ajustes.tierGen));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'video', fecha:nowIso(), url, veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err = e&&e.code&&['not_granted','rate_limited','invalid_json','refused','cancelled','prompt_too_large'].includes(e.code) ? errMsg(e) : mcpErr(e); }
  EV.estado=''; render();
}

// ------------------------------------------------------------ markdown mínimo
function md(src){
  const lines=(src||'').split('\n'); let out=[], i=0, inCode=false, buf=[], list=null;
  const flush=()=>{ if(list){ out.push(`</${list}>`); list=null; } };
  const inline = s => esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>').replace(/(^|\W)\*([^*\n]+)\*(?=\W|$)/g,'$1<i>$2</i>');
  for(;i<lines.length;i++){ const l=lines[i];
    if(/^```/.test(l)){ if(inCode){ out.push('<pre><code>'+esc(buf.join('\n'))+'</code></pre>'); buf=[]; inCode=false; } else { flush(); inCode=true; } continue; }
    if(inCode){ buf.push(l); continue; }
    let m;
    if((m=/^(#{1,3})\s+(.*)/.exec(l))){ flush(); out.push(`<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`); continue; }
    if((m=/^\s*[-*•]\s+(.*)/.exec(l))){ if(list!=='ul'){ flush(); out.push('<ul>'); list='ul'; } out.push('<li>'+inline(m[1])+'</li>'); continue; }
    if((m=/^\s*\d+[.)]\s+(.*)/.exec(l))){ if(list!=='ol'){ flush(); out.push('<ol>'); list='ol'; } out.push('<li>'+inline(m[1])+'</li>'); continue; }
    if(/^\s*\|.*\|\s*$/.test(l)){ flush(); const rows=[]; while(i<lines.length && /^\s*\|.*\|\s*$/.test(lines[i])){ rows.push(lines[i]); i++; } i--; const cells=r=>r.trim().slice(1,-1).split('|').map(c=>inline(c.trim())); const body=rows.filter(r=>!/^\s*\|[\s:|-]+\|\s*$/.test(r)); out.push('<table>'+body.map((r,k)=>'<tr>'+cells(r).map(c=>k===0?`<th>${c}</th>`:`<td>${c}</td>`).join('')+'</tr>').join('')+'</table>'); continue; }
    if(!l.trim()){ flush(); continue; }
    flush(); out.push('<p>'+inline(l)+'</p>');
  }
  if(inCode) out.push('<pre><code>'+esc(buf.join('\n'))+'</code></pre>');
  flush(); return out.join('');
}

// ------------------------------------------------------------ render
const ESTADO = {pendiente:['','Pendiente'], generando:['gen','Generando'], auditando:['aud','Auditando'], rechazada:['rech','Rechazada por el auditor'], agotada:['agot','No pasó la auditoría'], espera_ok:['espera','Espera tu OK'], aprobada:['aprob','Aprobada']};
const pillEstado = e => { const [cls,txt]=ESTADO[e.estado]||['',e.estado]; const c = {gen:'info',aud:'info',rech:'bad',agot:'bad',espera:'warn',aprob:'ok'}[cls]||''; return `<span class="pill ${c}">${txt}</span>`; };

function render(){
  const p=P();
  $('#ver').textContent = `${D.meta.reglas} reglas · ${D.meta.auditorias} auditorías`;
  $('#plist').innerHTML = S.proyectos.map(x=>`<button class="${x.id===S.pid?'act':''}" data-p="${x.id}"><b>${esc(x.nombre)}</b><small>${(x.creado||'').slice(0,10)} · ${x.orden?x.orden.length:0} etapas</small></button>`).join('') || '<div class="mute" style="padding:6px 9px">Ningún proyecto todavía.</div>';
  $('#plist').querySelectorAll('button').forEach(b=>b.onclick=()=>{ S.pid=b.dataset.p; S.imgs=[]; EV.res=null; EV.escenas=null; S.view = P().orden.length?'run':'brief'; render(); });
  $('#tabs').querySelectorAll('button').forEach(b=>{ b.classList.toggle('act', b.dataset.v===S.view); b.onclick=()=>{ S.view=b.dataset.v; render(); }; });
  $('#nPlan').textContent = p&&p.orden.length ? p.orden.length : '';
  $('#nRun').textContent = p&&p.orden.length ? `${p.orden.filter(k=>p.etapas[k].estado==='aprobada').length}/${p.orden.length}` : '';
  $('#btnNuevo').onclick = nuevoProyecto;
  const m=$('#main');
  if(S.bloqueo){ vBloqueo(m); return; }
  if(!p){ m.innerHTML = `<div class="hd"><div><h2>Brief</h2></div></div><div class="empty">Sin proyectos. Usa <b>Nuevo brief</b>.</div>`; return; }
  ({brief:vBrief, plan:vPlan, run:vRun, eval:vEval, ajustes:vAjustes})[S.view](m,p);
  banner(m);
}

function banner(m){
  if(!S.error) return;
  const d=document.createElement('div');
  d.className='badbox'; d.style.marginBottom='12px'; d.style.cursor='pointer';
  d.title='Clic para cerrar';
  d.textContent=S.error;
  d.onclick=()=>{ S.error=''; render(); };
  m.insertBefore(d, m.firstChild);
}

function vBloqueo(m){
  m.innerHTML = `<div class="hd"><div><h2>Contraseña</h2><p class="sub">Esta app usa la cuenta de OpenAI del servidor. La contraseña evita que la gaste alguien más.</p></div></div>
  <div class="card" style="max-width:440px">
    <div><div class="lbl">Contraseña</div><input type="password" id="pw" autocomplete="current-password"></div>
    <div class="row"><button class="prim" id="btnPw">Entrar</button><span class="mute" id="pwMsg"></span></div>
  </div>`;
  const inp=$('#pw'), msg=$('#pwMsg'), btn=$('#btnPw');
  const entrar=async()=>{
    const k=inp.value.trim();
    if(!k){ msg.textContent='Escribe la contraseña.'; return; }
    btn.disabled=true; msg.textContent='Verificando…';
    const j=await probarClave(k);
    btn.disabled=false;
    if(!j){ msg.textContent='No se pudo hablar con el servidor.'; return; }
    if(!j.claveOk){ msg.textContent='Contraseña incorrecta.'; inp.select(); return; }
    try{ localStorage.setItem(claveLS,k); }catch(e){}
    SRV=j; S.bloqueo=false; S.error=''; render();
  };
  btn.onclick=entrar;
  inp.onkeydown=e=>{ if(e.key==='Enter') entrar(); };
  inp.focus();
}

function vBrief(m,p){
  m.innerHTML = `<div class="hd"><div><h2>Brief</h2></div></div>
  <div class="card">
    <div><div class="lbl">Nombre del proyecto</div><input type="text" id="nombre" value="${esc(p.nombre)}"></div>
    <div><div class="row" style="justify-content:space-between"><div class="lbl">Brief</div><div class="row"><button class="sm" id="btnVoz">Dictar</button><span class="mute" style="font-size:12px" id="vozN"></span></div></div><textarea id="brief" style="min-height:260px">${esc(p.brief)}</textarea><div class="mute" style="font-size:12px;margin-top:4px" id="briefN"></div></div>
    <div class="grid2">
      <div><div class="lbl">Documentos</div><div class="row"><input type="file" id="docs" hidden accept=".txt,.md,.pdf,.docx,text/plain,text/markdown,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" multiple><button id="btnDocs">Subir txt, md, pdf o docx</button><span class="mute" style="font-size:12px" id="docsN">El texto se agrega al brief.</span></div></div>
      <div><div class="lbl">Imágenes de referencia</div><div class="row"><input type="file" id="imgs" hidden accept="image/*" multiple><button id="btnImgs" ${caps.images?'':'disabled'}>Subir imágenes</button><span class="mute" style="font-size:12px" id="imgsN">${caps.images?(S.imgs.length?`${S.imgs.length} adjunta(s). Se pierden al recargar.`:''):'No disponible aquí.'}</span></div><div class="thumbs" id="thumbs"></div>${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}</div>
    </div>
    ${sample?'':`<div class="badbox">${esc(motivoSinClaude())}</div>`}
    <div class="row"><button class="prim" id="btnPlan" ${S.busy?'disabled':''}>Analizar brief y proponer etapas</button>${p.orden.length?`<span class="mute">Ya hay un plan de ${p.orden.length} etapas. Volver a analizar lo reemplaza.</span>`:''}${S.busy?`<span class="status"><span class="spin"></span><span id="busyN">${esc(S.busy)}</span> · <span class="reloj">0s</span></span>`:''}</div>
  </div>`;
  const ta=$('#brief'), nm=$('#nombre'), cnt=$('#briefN');
  const upd=()=>{ cnt.textContent = `${ta.value.length.toLocaleString('es-MX')} caracteres`; };
  upd();
  ta.oninput=()=>{ p.brief=ta.value; upd(); }; ta.onchange=()=>guardar(p);
  nm.onchange=()=>{ p.nombre=nm.value||'Sin título'; guardar(p); render(); };
  const th=$('#thumbs'); const pintar=()=>{ th.innerHTML=''; S.imgs.forEach(f=>{ const im=document.createElement('img'); im.src=URL.createObjectURL(f); im.alt=f.name; th.appendChild(im); }); };
  pintar();
  $('#btnImgs').onclick=()=>$('#imgs').click(); $('#btnDocs').onclick=()=>$('#docs').click();
  const bv=$('#btnVoz'), vn=$('#vozN'); const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){ bv.disabled=true; vn.textContent='Este navegador no tiene reconocimiento de voz.'; }
  else bv.onclick=()=>{ if(VOZ.rec){ VOZ.rec.stop(); return; } const r=new SR(); VOZ.rec=r; r.lang='es-MX'; r.continuous=true; r.interimResults=true; let base=ta.value, fin='';
    r.onstart=()=>{ bv.textContent='Detener'; bv.classList.add('prim'); vn.textContent='Escuchando…'; };
    r.onresult=ev=>{ let inter=''; for(let i=ev.resultIndex;i<ev.results.length;i++){ const t=ev.results[i][0].transcript; if(ev.results[i].isFinal) fin+=t+' '; else inter+=t; } ta.value=(base.trim()?base.replace(/\s+$/,'')+' ':'')+fin+inter; p.brief=ta.value; upd(); };
    r.onerror=ev=>{ vn.textContent = ev.error==='not-allowed'||ev.error==='service-not-allowed' ? 'Micrófono bloqueado: permite el micrófono en el navegador o dicta con el teclado del sistema.' : 'Error de voz: '+ev.error; };
    r.onend=()=>{ VOZ.rec=null; bv.textContent='Dictar'; bv.classList.remove('prim'); if(vn.textContent==='Escuchando…') vn.textContent=''; guardar(p); };
    try{ r.start(); }catch(e){ vn.textContent='No se pudo iniciar el dictado.'; VOZ.rec=null; } };
  $('#imgs').onchange=ev=>{ S.imgs=[...S.imgs, ...ev.target.files]; ev.target.value=''; pintar(); $('#imgsN').textContent=`${S.imgs.length} adjunta(s). Se pierden al recargar.`; };
  $('#docs').onchange=async ev=>{ const files=[...ev.target.files]; const dn=$('#docsN'); for(const f of files){ dn.textContent=`Leyendo ${f.name}…`; try{ const t=(await textoDe(f)).trim(); if(!t) throw new Error('sin texto legible'); ta.value = (ta.value.trim()? ta.value.replace(/\s+$/,'')+'\n\n':'') + `--- ${f.name} ---\n${t}`; p.brief=ta.value; upd(); dn.textContent=`${f.name}: ${t.length.toLocaleString('es-MX')} caracteres agregados.`; }catch(e){ dn.textContent=`${f.name}: no se pudo leer (${e.message||e}).`; } } ev.target.value=''; await guardar(p); };
  $('#btnPlan').onclick=()=>{ p.brief=ta.value; planificar(); };
}

// ------------------------------------------------------------ documentos
const PDFJS='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', PDFW='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', MAMMOTH='https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.8.0/mammoth.browser.min.js';
function loadScript(src){ return new Promise((res,rej)=>{ if(document.querySelector(`script[src="${src}"]`)) return res(); const s=document.createElement('script'); s.src=src; s.onload=res; s.onerror=()=>rej(new Error('no se pudo cargar la librería')); document.head.appendChild(s); }); }
async function textoDe(f){
  const n=f.name.toLowerCase();
  if(n.endsWith('.pdf')){ await loadScript(PDFJS); pdfjsLib.GlobalWorkerOptions.workerSrc=PDFW; const doc=await pdfjsLib.getDocument({data:new Uint8Array(await f.arrayBuffer())}).promise; const out=[]; for(let i=1;i<=doc.numPages;i++){ const tc=await (await doc.getPage(i)).getTextContent(); out.push(tc.items.map(it=>it.str+(it.hasEOL?'\n':' ')).join('').replace(/[ \t]+\n/g,'\n')); } return out.join('\n\n'); }
  if(n.endsWith('.docx')){ await loadScript(MAMMOTH); return (await mammoth.extractRawText({arrayBuffer:await f.arrayBuffer()})).value; }
  return await f.text();
}

function vPlan(m,p){
  if(!p.plan){ m.innerHTML=`<div class="hd"><div><h2>Plan</h2></div></div><div class="empty">Todavía no hay plan. Analiza el brief primero.</div>`; return; }
  const pl=p.plan; const corriendo = p.orden.some(k=>['generando','auditando'].includes(p.etapas[k].estado));
  m.innerHTML = `<div class="hd"><div><h2>${esc(p.nombre)}</h2><p class="sub">${esc(pl.tipo||'')}${pl.track?` · track ${esc(pl.track)}`:''}</p></div>
    <div class="row"><button class="prim" id="btnRun" ${corriendo?'disabled':''}>${p.orden.some(k=>p.etapas[k].estado!=='pendiente')?'Ir a la ejecución':'Aprobar plan y ejecutar'}</button></div></div>
  <div class="stack">
    <div class="card"><p>${esc(pl.resumen||'')}</p>
      <div class="row"><div><div class="lbl">Aspect ratio</div><input type="text" id="fAspect" style="width:110px" value="${esc((pl.formato||{}).aspect||'')}"></div>
        <div><div class="lbl">Resolución</div><input type="text" id="fRes" style="width:150px" value="${esc((pl.formato||{}).resolucion||'')}"></div>
        <div><div class="lbl">Duración</div><input type="text" id="fDur" style="width:110px" value="${esc((pl.formato||{}).duracion||'')}"></div>
        <span class="mute" style="font-size:12.5px;align-self:flex-end">Manda sobre todos los prompts. Corrígelo aquí antes de ejecutar.</span></div>
      ${(pl.supuestos||[]).length?`<div><div class="lbl">Supuestos que tomó el planificador</div><ul class="crit">${pl.supuestos.map(s=>`<li>${esc(s)}</li>`).join('')}</ul></div>`:''}</div>
    <div class="card"><h3>Etapas (${p.orden.length})</h3>
    <div>${p.orden.map((k,i)=>{ const e=p.etapas[k]; const n=reglasDe(e.casos).length; return `<div class="plan-et"><div class="k">${i+1} · ${esc(e.clave)}</div><div><b>${esc(e.nombre)}</b>${e.ok?' <span class="pill warn">pide tu OK</span>':''}<div class="mute" style="margin:2px 0 4px">${esc(e.objetivo)}</div><div style="font-size:13px"><span class="lbl">Entrega</span> ${esc(e.entregable)}</div><ol class="crit" style="margin-top:4px">${(e.criterios||[]).map(c=>`<li>${esc(c)}</li>`).join('')}</ol><div class="meta" style="margin-top:6px"><span class="pill">${n} reglas</span>${(e.casos||[]).map(c=>`<span class="pill">${c}</span>`).join('')}${e.usaImagenes?'<span class="pill info">ve las imágenes</span>':''}</div></div><div><button class="sm" data-quitar="${k}" ${corriendo?'disabled':''}>Quitar</button></div></div>`; }).join('')}</div>
    <div class="row"><select id="addEt" style="width:auto"><option value="">Agregar etapa…</option>${ETAPAS.map(e=>`<option value="${e.clave}">${e.clave} · ${esc(e.nombre)}</option>`).join('')}</select></div></div>
  </div>`;
  $('#btnRun').onclick=iniciar;
  const guardaFmt=()=>{ pl.formato={aspect:$('#fAspect').value.trim(), resolucion:$('#fRes').value.trim(), duracion:$('#fDur').value.trim()}; guardar(p); };
  ['#fAspect','#fRes','#fDur'].forEach(sel=>$(sel).onchange=guardaFmt);
  m.querySelectorAll('[data-quitar]').forEach(b=>b.onclick=async()=>{ const k=b.dataset.quitar; p.orden=p.orden.filter(x=>x!==k); delete p.etapas[k]; await guardar(p); render(); });
  $('#addEt').onchange=async ev=>{ const c=ev.target.value; if(!c) return; const cat=CAT[c]; const key=`${c}_${uid()}`; p.orden.push(key); p.etapas[key]={key, clave:c, nombre:cat.nombre, objetivo:cat.sale, entregable:cat.sale, casos:cat.casos.slice(0, c==='E5'||c==='PROMPT_IMAGEN'?1:99), criterios:[cat.gate], usaImagenes:c==='REF', ok:cat.ok, estado:'pendiente', output:'', rondas:[], feedback:''}; await guardar(p); render(); };
}

function vRun(m,p){
  if(!p.orden.length){ m.innerHTML=`<div class="hd"><div><h2>Ejecución</h2></div></div><div class="empty">Sin plan. Analiza el brief y aprueba el plan.</div>`; return; }
  const corriendo = p.orden.some(k=>['generando','auditando'].includes(p.etapas[k].estado));
  const listas = p.orden.filter(k=>p.etapas[k].estado==='aprobada').length;
  m.innerHTML = `<div class="hd"><div><h2>${esc(p.nombre)}</h2><p class="sub">${listas} de ${p.orden.length} etapas aprobadas${p.plan&&p.plan.track?` · track ${esc(p.plan.track)}`:''}</p></div>
    <div class="row">${corriendo?`<button id="btnStop">Detener</button>`:`<button class="prim" id="btnCont" ${siguientePendiente(p)?'':'disabled'}>Continuar</button>`}</div></div>
  <div class="stack">${p.orden.map((k,i)=>etapaHTML(p.etapas[k],i)).join('')}</div>`;
  if($('#btnStop')) $('#btnStop').onclick=detener;
  if($('#btnCont')) $('#btnCont').onclick=continuar;
  m.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>({aprobar, iterar, otraRonda, aprobarAsi, ejecutar:ejecutarEtapa, copiar:k=>{ navigator.clipboard.writeText(p.etapas[k].output||''); b.textContent='Copiado'; }})[b.dataset.act](b.dataset.k));
}

function etapaHTML(e,i){
  const cls=(ESTADO[e.estado]||[''])[0]; const activa=['generando','auditando'].includes(e.estado);
  const ult = e.rondas[e.rondas.length-1];
  return `<section class="etapa ${cls}"><div class="stripe"></div><div class="body">
    <div class="top"><div><div class="lbl">${i+1} · ${esc(e.clave)}</div><h3>${esc(e.nombre)}</h3></div><div class="meta">${pillEstado(e)}${e.rondas.length?`<span class="pill">${e.rondas.length} ronda${e.rondas.length>1?'s':''}</span>`:''}${e.reglasTotal?`<span class="pill" title="reglas que cupieron en la instrucción / reglas auditadas">${e.reglasIncluidas}/${e.reglasTotal} reglas</span>`:''}</div></div>
    <p class="mute">${esc(e.objetivo)}</p>
    ${activa?`<div class="status"><span class="spin"></span>${esc(e.progreso||'')} · <span class="reloj">0s</span></div>${activa?`<pre class="mono" id="parcial-${e.key}" style="white-space:pre-wrap;max-height:220px;overflow:auto;margin:0;color:var(--mute)">${esc(e.parcial||'')}</pre>`:''}`:''}
    ${e.error?`<div class="badbox">${esc(e.error)}</div>`:''}
    ${e.rondas.length?`<details ${['rechazada','agotada'].includes(e.estado)?'open':''}><summary>Auditoría · ${e.rondas.map(r=>`R${r.n} ${r.veredicto==='APRUEBA'?'✓':'✗'+r.fallas.length}`).join(' · ')}</summary><div class="log" style="margin-top:8px">${e.rondas.map(r=>`<div class="r"><div>ronda ${r.n}<br>${r.veredicto==='APRUEBA'?'aprueba':'rechaza'}${r.seg?`<br>${r.seg<60?r.seg+'s':Math.floor(r.seg/60)+'m '+String(r.seg%60).padStart(2,'0')+'s'}`:''}<br>${r.palabras} pal.${r.cache?`<br>${Math.round(r.cache/1000)}K de caché`:''}</div><div>${r.fallas.length?r.fallas.map(f=>`<div class="falla"><b>${esc(f.ref)}</b> ${esc(f.correccion)}${f.evidencia?`<div class="ev">${esc(f.evidencia)}</div>`:''}</div>`).join(''):'<span class="mute">Sin fallas.</span>'}${r.notas&&r.notas.length?`<div class="mute" style="margin-top:4px;font-size:12px">${r.notas.map(esc).join(' · ')}</div>`:''}</div></div>`).join('')}</div></details>`:''}
    ${e.output&&!activa?`<div class="out"><div class="row" style="justify-content:space-between"><span class="lbl">Entregable${e.estado==='agotada'?' (última versión, no aprobada)':''}</span><button class="sm" data-act="copiar" data-k="${e.key}">Copiar</button></div><div class="md">${md(e.output)}</div></div>`:''}
    ${!activa?`<div class="row" style="border-top:1px solid var(--line);padding-top:10px">
      ${e.estado==='espera_ok'?`<button class="prim" data-act="aprobar" data-k="${e.key}">Aprobar y continuar</button>`:''}
      ${e.estado==='agotada'?`<button class="prim" data-act="otraRonda" data-k="${e.key}">Otras ${S.ajustes.rondas} rondas</button><button data-act="aprobarAsi" data-k="${e.key}">Aprobar así</button>`:''}
      ${e.estado==='rechazada'?`<button class="prim" data-act="otraRonda" data-k="${e.key}">Reintentar</button>`:''}
      ${e.estado==='pendiente'&&!e.output?`<button class="sm" data-act="ejecutar" data-k="${e.key}">Ejecutar solo esta</button>`:''}
      ${e.output||e.estado==='rechazada'?`<div style="flex:1;min-width:260px"><textarea id="fb-${e.key}" style="min-height:56px" placeholder="Qué cambiar en esta etapa (iteración)">${esc(e.feedback||'')}</textarea></div><button data-act="iterar" data-k="${e.key}">Iterar</button>`:''}
    </div>`:''}
  </div></section>`;
}

function vEval(m,p){
  const ref = p.orden.filter(k=>p.etapas[k].estado==='aprobada').length;
  m.innerHTML = `<div class="hd"><div><h2>Evaluador</h2><p class="sub">Referencia: brief${ref?` + ${ref} etapas aprobadas`:''} de <b>${esc(p.nombre)}</b></p></div>
    <div class="seg"><button data-m="imagen" class="${EV.modo==='imagen'?'act':''}">Imagen</button><button data-m="video" class="${EV.modo==='video'?'act':''}">Video</button></div></div>
  <div class="stack">
  ${EV.modo==='imagen'?`<div class="card">
      <div><div class="lbl">Imágenes generadas</div><div class="row"><input type="file" id="evImgs" hidden accept="image/*" multiple><button id="btnEvPick" ${caps.images?'':'disabled'}>Subir imágenes</button><span class="mute" style="font-size:12px">${caps.images?(EV.imgs.length?`${EV.imgs.length} adjunta(s)`:''):'No disponible aquí.'}</span></div><div class="thumbs" id="evThumbs"></div>${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}</div>
      <div class="row"><button class="prim" id="btnEvImg" ${!sample||!EV.imgs.length||EV.estado?'disabled':''}>Evaluar</button>${EV.estado?`<span class="status"><span class="spin"></span>${esc(EV.estado)}</span>`:''}</div>
    </div>`
  :`<div class="card">
      ${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}
      <div class="seg"><button data-f="cuadros" class="${EV.fuente==='cuadros'?'act':''}">Archivo de video</button>${mcp?`<button data-f="url" class="${EV.fuente==='url'?'act':''}">URL</button><button data-f="gens" class="${EV.fuente==='gens'?'act':''}">Higgsfield</button>`:''}</div>
      ${EV.fuente==='cuadros'?`<div class="row"><input type="file" id="evVid" hidden accept="video/*"><button id="btnVidPick">Elegir video</button><span class="mute" style="font-size:12.5px">${EV.file?esc(EV.file.name):'mp4, mov o webm del disco'}</span><select id="evN" style="width:auto">${[4,6,8,12].map(n=>`<option ${EV.n==n?'selected':''}>${n}</option>`).join('')}</select><span class="mute" style="font-size:12.5px">cuadros</span></div>${EV.miniaturas.length?`<div class="thumbs">${EV.miniaturas.map(u=>`<img src="${u}" alt="">`).join('')}</div>`:''}<div class="row"><button class="prim" id="btnEvCuadros" ${!sample||!caps.images||!EV.file||EV.estado?'disabled':''}>Evaluar</button><span class="mute" style="font-size:12.5px">Sin audio ni movimiento continuo: se evalúan cuadros.</span></div>`
      :EV.fuente==='url'?`<input type="url" id="evUrl" placeholder="https://youtu.be/… o https://….cloudfront.net/….mp4" value="${esc(EV.url)}">`
      :`<div class="row"><button class="sm" id="btnGens" ${!mcp||EV.estado?'disabled':''}>${EV.gens?'Recargar':'Cargar mis videos'}</button><span class="mute" style="font-size:12.5px">${EV.gens?`${EV.gens.length} videos completados`:''}</span></div>${EV.gens?`<div class="gens">${EV.gens.map(g=>`<button data-g="${g.id}" class="${EV.genSel&&EV.genSel.id===g.id?'act':''}"><img src="${esc(g.results.thumbnailUrl||'')}" alt=""><small>${esc((g.params&&g.params.prompt||g.model||g.id).slice(0,60))}</small></button>`).join('')}</div>`:''}`}
      ${EV.fuente!=='cuadros'?`<div class="row"><button class="prim" id="btnEvVid" ${!sample||!mcp||EV.estado?'disabled':''}>Analizar y evaluar</button><span class="mute" style="font-size:12.5px">10 créditos de Higgsfield por análisis.</span></div>`:''}
      ${EV.estado?`<div class="status"><span class="spin"></span>${esc(EV.estado)}</div>`:''}
    </div>`}
  ${EV.err?`<div class="badbox">${esc(EV.err)}</div>`:''}
  ${EV.res?resultadoHTML(EV.res):''}
  ${EV.escenas?`<div class="card"><h3>Escenas detectadas (${EV.escenas.length})</h3><table class="tbl"><tr><th>#</th><th>Tiempo</th><th>Plano</th><th>Visual</th><th>Audio</th></tr>${EV.escenas.map(s=>`<tr><td>${s.scene_number}</td><td class="mono">${esc(s.timestamp_start)}–${esc(s.timestamp_end)}</td><td>${esc(s.shot_type||'')}</td><td>${esc(s.visual||'')}</td><td class="mute">${esc(s.audio||'')}</td></tr>`).join('')}</table></div>`:''}
  ${(p.evaluaciones||[]).length?`<details><summary>Historial · ${p.evaluaciones.length} evaluaciones</summary><table class="tbl" style="margin-top:8px"><tr><th>Fecha</th><th>Tipo</th><th>Veredicto</th><th>Puntaje</th></tr>${p.evaluaciones.slice().reverse().map(x=>`<tr><td class="mono">${esc(x.fecha.slice(0,16).replace('T',' '))}</td><td>${esc(x.tipo)}</td><td>${esc(x.veredicto||'')}</td><td class="mono">${x.puntaje??''}</td></tr>`).join('')}</table></details>`:''}
  </div>`;
  m.querySelectorAll('[data-m]').forEach(b=>b.onclick=()=>{ EV.modo=b.dataset.m; EV.res=null; EV.escenas=null; EV.err=''; render(); });
  m.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{ EV.fuente=b.dataset.f; render(); });
  m.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{ EV.genSel=EV.gens.find(g=>g.id===b.dataset.g); render(); });
  if($('#evImgs')){ const th=$('#evThumbs'); const pintar=()=>{ th.innerHTML=''; EV.imgs.forEach(f=>{ const im=document.createElement('img'); im.src=URL.createObjectURL(f); im.alt=f.name; th.appendChild(im); }); }; pintar(); $('#btnEvPick').onclick=()=>$('#evImgs').click(); $('#evImgs').onchange=ev=>{ EV.imgs=[...ev.target.files]; render(); }; $('#btnEvImg').onclick=evaluarImagen; }
  if($('#btnVidPick')){ $('#btnVidPick').onclick=()=>$('#evVid').click(); $('#evVid').onchange=ev=>{ EV.file=ev.target.files[0]||null; EV.miniaturas=[]; EV.res=null; render(); }; $('#evN').onchange=ev=>{ EV.n=Number(ev.target.value); }; $('#btnEvCuadros').onclick=evaluarCuadros; }
  if($('#evUrl')) $('#evUrl').oninput=ev=>{ EV.url=ev.target.value; };
  if($('#btnGens')) $('#btnGens').onclick=cargarGeneraciones;
  if($('#btnEvVid')) $('#btnEvVid').onclick=evaluarVideo;
}

function resultadoHTML(r){
  const v=r.veredicto||''; const c = v==='CUMPLE'?'ok':v==='PARCIAL'?'warn':'bad';
  return `<div class="card"><div class="row" style="justify-content:space-between"><div class="row"><span class="score">${r.puntaje??'–'}</span><span class="pill ${c}">${esc(v)}</span></div></div>
    ${r.descripcion?`<p>${esc(r.descripcion)}</p>`:''}
    ${Array.isArray(r.criterios)?`<table class="tbl"><tr><th>Criterio</th><th>Cumple</th><th>Evidencia</th></tr>${r.criterios.map(x=>`<tr><td>${esc(x.criterio)}</td><td>${x.cumple===true?'<span class="pill ok">sí</span>':x.cumple===false?'<span class="pill bad">no</span>':'<span class="pill">n/v</span>'}</td><td class="mute">${esc(x.evidencia||'')}</td></tr>`).join('')}</table>`:''}
    ${Array.isArray(r.por_escena)&&r.por_escena.length?`<div><div class="lbl">Por escena</div><ul class="crit">${r.por_escena.map(x=>`<li><b>${esc(x.escena)}</b> ${esc(x.nota)}</li>`).join('')}</ul></div>`:''}
    ${Array.isArray(r.correcciones)&&r.correcciones.length?`<div><div class="lbl">Correcciones para el siguiente intento</div><ol class="crit" style="color:var(--ink)">${r.correcciones.map(x=>`<li>${esc(x)}</li>`).join('')}</ol></div>`:''}
    ${r.prompt_ajustado?`<div><div class="lbl">Ajuste de prompt sugerido</div><div class="md"><pre><code>${esc(r.prompt_ajustado)}</code></pre></div></div>`:''}
  </div>`;
}

const ESF=[['complex','alto'],['default','medio'],['quick','bajo']];
function vAjustes(m,p){
  const a=S.ajustes;
  m.innerHTML=`<div class="hd"><div><h2>Ajustes</h2></div></div>
  <div class="card"><div class="grid2">
    <div><div class="lbl">Rondas máximas de auditoría por etapa</div><select id="aR">${[1,2,3,4,5].map(n=>`<option ${a.rondas==n?'selected':''}>${n}</option>`).join('')}</select></div>
    <div></div>
    <div><div class="lbl">Esfuerzo al generar</div><select id="aG">${ESF.map(([v,n])=>`<option value="${v}" ${a.tierGen===v?'selected':''}>${n}</option>`).join('')}</select></div>
    <div><div class="lbl">Esfuerzo al auditar</div><select id="aA">${ESF.map(([v,n])=>`<option value="${v}" ${a.tierAud===v?'selected':''}>${n}</option>`).join('')}</select></div>
  </div>
    <div><div class="lbl">Base de reglas</div><div class="mute" style="font-size:13px">${D.meta.reglas} reglas de ${D.meta.skills} skills · ${D.meta.auditorias} correcciones de auditoría externa · casos: ${Object.keys(D.porCaso).map(c=>`${c} ${D.porCaso[c].length}`).join(' · ')}</div></div>
  </div>`;
  const save=()=>{ a.rondas=Number($('#aR').value); a.tierGen=$('#aG').value; a.tierAud=$('#aA').value; try{ localStorage.setItem(ajustesLS, JSON.stringify(a)); }catch(e){} };
  ['#aR','#aG','#aA'].forEach(s=>$(s).onchange=save);
}

// ------------------------------------------------------------ arranque
(async()=>{
  render();
  const cl=$('#capline');
  const use = n => (window.claude&&window.claude.use) ? window.claude.use(n).catch(()=>null) : Promise.resolve(null);
  [sample, db, mcp] = await Promise.all([use('sample'), use('db'), use('mcp')]);
  if(!sample){
    SRV = await detectarServidor();
    if(SRV && SRV.ia){ sample = sampleDeServidor(); if(SRV.clave && !SRV.claveOk) S.bloqueo=true; }
  }
  if(sample){ try{ const l=await sample.limits(); caps.images=l.images||false; }catch(e){} }
  await cargarLista();
  if(S.proyectos.length && !S.pid){ S.pid=S.proyectos[0].id; S.view = P().orden.length?'run':'brief'; }
  if(!S.proyectos.length){ const p={id:uid(), nombre:'Sin título', brief:'', creado:nowIso(), plan:null, etapas:{}, orden:[], evaluaciones:[]}; S.proyectos.push(p); S.pid=p.id; S.view='brief'; }
  const parts=[ sample?(SRV?('ChatGPT '+(SRV.modelo||'')+' vía servidor propio'):'Claude listo'):(SRV&&!SRV.ia?'Falta OPENAI_API_KEY en el servidor':'Modelo no disponible'), db?'guardado en la nube':'guardado local', mcp?'Higgsfield listo':'video por cuadros' ];
  cl.textContent = parts.join(' · ');
  render();
})();
</script>

</body>
</html>

<!-- SOURCE_FILE_END: repo/public/index.html -->


<!-- SOURCE_FILE_START: repo/vercel.json -->
# SOURCE FILE: `repo/vercel.json`

{
  "$schema": "https://openapi.vercel.sh/vercel.json",
  "functions": {
    "api/sample.js": { "maxDuration": 300 }
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [{ "key": "Cache-Control", "value": "no-store" }]
    }
  ]
}

<!-- SOURCE_FILE_END: repo/vercel.json -->


<!-- SOURCE_FILE_START: skills/ai-production-director/SKILL.md -->
# SOURCE FILE: `skills/ai-production-director/SKILL.md`

---
name: ai-production-director
description: >-
  Skill maestra que orquesta el pipeline completo de producción audiovisual con AI — de creative brief a Final AI Video Production Package. Dirige y secuencia las sub-skills instaladas (screenwriter, video, image, ai-video-storyboard, storyboard-architect, visual-prompt-forge, visual-asset-critic, brand-lock-extractor, storyboard-html-preview, visual-media) según el track del proyecto, resuelve conflictos entre ellas y aplica quality gates por etapa. USA ESTE SKILL SIEMPRE que el usuario pida producir un video completo — spot, campaña, reel con narrativa, brand film, explainer o cortometraje — o diga "pipeline completo", "producción completa", "de brief a video", "production package", "arranca la producción", o entregue un creative brief esperando el paquete final. APLICAR TAMBIÉN si pide una parte del flujo pero el contexto revela un proyecto multi-etapa. NO aplicar a piezas sueltas — un solo prompt (usar image/video), un storyboard aislado (usar storyboard-architect), o teoría de cine (usar visual-media).
license: Apache-2.0 (orquestador original de Final Upgrade AI; sub-skills conservan sus licencias — smixs video/image son CC BY 4.0 con atribución obligatoria a Serge Shima)
metadata:
  version: 1.0.0
  author: Final Upgrade AI
  pipeline: brief → strategy → script → direction → shots → anchors → prompts → package
---

# AI Production Director

Eres el director de producción del pipeline. Tu trabajo NO es escribir guiones, prompts ni storyboards tú mismo desde cero — para eso existen las sub-skills, cada una con oficio profundo que tú no debes duplicar ni contradecir. Tu trabajo es:

1. **Clasificar** el proyecto y elegir el track correcto.
2. **Secuenciar** las etapas y cargar la sub-skill correcta en cada una.
3. **Custodiar los gates**: ninguna etapa arranca sin que la anterior pase su quality gate.
4. **Resolver conflictos** entre sub-skills con las reglas de la sección 6 — las decidiste una vez, no se renegocian por proyecto.
5. **Mantener trazabilidad**: todo artefacto downstream traza a un shot ID, todo shot traza a una escena, toda escena al concepto aprobado.

El anti-patrón que este skill existe para matar: "escríbeme un guion y dame prompts" en un solo paso. Eso produce prompts sin dramaturgia, sin consistencia visual y sin trazabilidad. El pipeline produce un paquete de producción.

## 1. Mapa de sub-skills

| Sub-skill | Capa | Qué aporta | Autoridad sobre |
|---|---|---|---|
| `brand-lock-extractor` | 0 · Marca | brand-lock.md de 9 secciones desde assets reales | Parámetros de marca |
| *(este skill)* + `references/creative-strategy.md` | 1 · Estrategia | Territorios, big ideas, 3–5 concept cards, dirección narrativa | Estrategia creativa |
| `screenwriter` | 2 · Guion | Concept → treatment → script con escenas XML-tagged | Estructura narrativa y diálogo |
| `video` (smixs) — capa dramaturgia | 3 · Dirección | Fórmula de escena, Ley de 3 Detalles, Regla de Seis de Murch, blocking, ritmo | Dramaturgia y lenguaje de cámara |
| `storyboard-architect` (shotkit) | 4 · Shot planning | storyboard.md + shots.json + text-overlays.json + run.json, validados por schema | **Fuente de verdad estructural** desde aquí |
| `ai-video-storyboard` | 4 · Shot planning (EXPRESS) | Shot list ligero por cadencia de plataforma | Solo track EXPRESS |
| `image` (smixs) | 5 · Anchors | Sintaxis por modelo de imagen (Nano Banana, GPT Image 2), character sheets, keyframes | Sintaxis final de prompts de imagen |
| `visual-prompt-forge` (shotkit) | 5–6 · Prompts | shots.json → borradores de prompt por adaptador; modo revisión desde critique.json | Estructura shots→prompt y loop de revisión |
| `visual-asset-critic` (shotkit) | 5 · QA | Crítica de render vs. shot origen, critique.json accionable | Aceptar/rechazar renders |
| `video` (smixs) — archivos de modelo | 6 · Video prompts | Sintaxis exacta Seedance/Kling/Veo, protocolos de diálogo, failure modes | Sintaxis final de prompts de video |
| `storyboard-html-preview` (shotkit) | 7 · Entrega | Preview HTML single-file para cliente | Formato de entrega visual |
| `visual-media` | Transversal limitada | Ver sección 7 — SOLO animación y material didáctico ES | Proyectos de animación |
| `aurora-prompt-linter` (si está instalada) | Gate final | Validación determinista de todo prompt visual antes de entregar | Veto final sobre prompts |

Cuando ejecutes una etapa, LEE el SKILL.md de la sub-skill correspondiente y sigue su protocolo completo — no trabajes de memoria sobre lo que "recuerdas" que dice.

## 2. Selección de track

Clasifica el proyecto en el primer mensaje. Si el brief no da los datos, pregunta UNA sola vez, todo junto: plataforma y duración, marca/cliente, objetivo, deadline, y si existen assets de marca.

| Criterio | EXPRESS | STANDARD | FILM |
|---|---|---|---|
| Duración | ≤30s | 30–90s | 90s–10min |
| Cliente/marca formal | No | Sí | Sí o pieza de autor |
| Narrativa | Un beat (hook→payoff) | Arco simple | Multi-escena, personajes |
| Revisiones esperadas | 0–1 | 1–2 rondas | Rondas formales |
| Etapas | 4 → 5/6 comprimidas | 0–7 con estrategia ligera | 0–7 completas |
| Ejemplo | Reel orgánico interno | Spot de campaña, brand film corto | Cortometraje, explainer largo, film de marca |

- **EXPRESS**: salta estrategia formal y guion; usa `ai-video-storyboard` para el shot list, luego directo a `image`/`video` para prompts. Sin shots.json ni loop de crítica salvo que el usuario lo pida.
- **STANDARD**: pipeline completo pero Etapa 1 comprimida (2–3 conceptos en vez de 5, sin documento de territorios) y Etapa 2 comprimida (script directo, sin treatment separado).
- **FILM**: todas las etapas, todos los artefactos, todos los gates.

Anuncia el track elegido y el plan de etapas en una línea antes de arrancar. Si el usuario ya trae artefactos de etapas previas (un script, un shots.json), entra al pipeline en la etapa correspondiente — no repitas trabajo hecho.

## 3. Las etapas

Cada etapa declara: sub-skill, entradas, salidas, y gate. El gate se verifica ANTES de avanzar. Si falla, se corrige en la etapa actual — nunca se "arregla después".

### Etapa 0 — Brand Lock *(solo si hay marca/cliente)*
- **Skill:** `brand-lock-extractor`. Entrada: sitio web, brand book, screenshots o descripción.
- **Salida:** `brand-lock.md` (9 secciones, cada valor con fuente y confianza).
- **Gate:** el usuario confirma los valores flagged como estimados. Sin marca formal, usa el Visual Theme de la Etapa 3 como sustituto ligero.

### Etapa 1 — Creative Strategy
- **Módulo:** `references/creative-strategy.md` de ESTE skill (no hay sub-skill instalada para esto — el módulo es la autoridad).
- **Salida:** documento con territorios explorados, 3–5 concept cards, matriz de selección, y dirección narrativa del concepto ganador.
- **Gate:** el usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto.

### Etapa 2 — Screenwriting
- **Skill:** `screenwriter`. Entrada: concept card ganadora + dirección narrativa.
- **Salida:** treatment (solo FILM) → script con escenas XML-tagged, sluglines, acción y diálogo.
- **Gate:** cada escena pasa la fórmula de escena de `video`/dramaturgy (deseo + obstáculo + geometría + mirada + ritmo) y la three-jobs rule: cada escena cambia emoción, avanza acción o sube presión. Escena que no hace ninguna de las tres se corta aquí, no en el shot list.

### Etapa 3 — Cinematic Direction
- **Skill:** `video` (smixs), archivos `dramaturgy.md` y `universal-rules.md` + vocabulario de cámara/luz.
- **Salida:** documento de dirección por escena: blocking, composición, cámara motivada (cada movimiento responde "¿qué cambió?"), lente, luz, evolución de color, lenguaje de edición, y los 5 anclas de la pieza (una emoción, un motivo, un objeto, un quiebre, una imagen final).
- **Gate:** cero palabras del vocabulario prohibido (sección 6.1). Cada decisión de cámara tiene razón dramática escrita.

### Etapa 4 — Shot Planning
- **Skill:** `storyboard-architect` (STANDARD/FILM) o `ai-video-storyboard` (EXPRESS).
- **Entrada:** script + documento de dirección. **Salida:** `storyboard.md`, `shots.json`, `text-overlays.json`, `run.json`, `brand-lock.snapshot.md`.
- **Gate:** `tools/validate_shots.py` limpio + six-point dramaturgy check + auditoría de 3 detalles por shot (presión ambiental, micro-acción física, ancla de sonido/motivo). Un shot con cero detalles es filler y se elimina.
- Desde aquí, **shots.json es la fuente de verdad**. Ningún prompt, imagen o revisión existe sin shot ID.

### Etapa 5 — Anchor Images
- **Skills:** `visual-prompt-forge` genera los borradores desde shots.json (adaptador correcto por modelo) → `image` (smixs) es la autoridad de sintaxis final por modelo → el usuario genera → `visual-asset-critic` evalúa cada render contra su shot.
- **Salida:** plan de anchors (character refs, environment refs, keyframes por shot clave), prompts finales, y critiques por ronda.
- **Gate:** cada anchor crítico tiene critique ACCEPT, con máximo 2 rondas de revisión vía forge en modo revisión (solo shots reprobados). A la tercera falla, se replantea el shot, no el prompt.

### Etapa 6 — Video Prompts
- **Skills:** `visual-prompt-forge` estructura el prompt de movimiento desde shots.json + anchor aprobado → `video` (smixs) archivo del modelo destino es la autoridad de sintaxis final: motion brief (no re-describir la escena que el anchor ya fija), cámara, blocking, performance, evolución de luz, física, protocolo de diálogo/audio.
- **Salida:** prompts de video finales por shot, con continuity blocks entre clips.
- **Gate obligatorio:** los dos checks de `video` (dramaturgy check de 6 puntos + auditoría de 3 detalles) Y, si `aurora-prompt-linter` está instalada, el linter pasa limpio. Un prompt que falla cualquiera de los dos NO se entrega.

### Etapa 7 — Package & Delivery
- **Skill:** `storyboard-html-preview` para el preview de cliente + `references/production-package.md` de este skill para el ensamblado.
- **Salida:** Final AI Video Production Package (spec completa en la referencia) + checklist de postproducción.
- **Gate:** checklist maestro de la referencia completo; trazabilidad verificada (muestreo: 3 prompts al azar trazan hasta su concepto).

## 4. Interacción con el usuario entre etapas

- Al cerrar cada gate, entrega el artefacto de la etapa y anuncia la siguiente en una línea. En STANDARD/FILM, los gates 1 (selección de concepto), 2 (script) y 4 (storyboard) requieren OK explícito del usuario; los demás avanzan solos salvo instrucción contraria.
- En EXPRESS, solo el shot list requiere OK antes de escribir prompts.
- Nunca preguntes lo que el brief o los artefactos previos ya responden.

## 5. Ejecución por etapa — regla de carga

En claude.ai las sub-skills están instaladas por separado. Al entrar a una etapa: (1) nombra la sub-skill que vas a usar, (2) lee su SKILL.md y los references que su protocolo exija para el caso, (3) ejecuta SU protocolo, no un resumen. La calidad del pipeline es la calidad de la sub-skill peor ejecutada.

## 6. Reglas de resolución de conflictos

Estas reglas son decisiones tomadas. Aplícalas sin reabrir el debate en medio de un proyecto.

### 6.1 Vocabulario
El vocabulario prohibido de `video`/dramaturgy (+ `aurora-prompt-linter` si está) **gana siempre**: "cinematic", "epic", "stunning", "masterpiece", "beautiful lighting", "professional", "high quality", emociones nombradas sin cuerpo. Esto **anula explícitamente** la regla de `ai-video-storyboard` de cerrar cada prompt con "cinematic 1080p, synchronized audio". En su lugar: la resolución, aspect ratio, duración y si el modelo genera audio se especifican como parámetros técnicos concretos según el archivo del modelo destino.

### 6.2 Sintaxis de modelo
`ai-video-storyboard` pide prompts model-agnostic; `video`/`image` (smixs) existen para sintaxis por modelo. Resolución: model-agnostic SOLO en artefactos intermedios (storyboard, shot cards). Todo prompt FINAL se escribe en la sintaxis del modelo destino según el archivo smixs correspondiente. Si el modelo no tiene archivo smixs (p.ej. Flux, Midjourney, Ideogram), la autoridad es el adaptador de `visual-prompt-forge`.

### 6.3 Fuente de verdad estructural
De la Etapa 4 en adelante: `shots.json`. Un cambio creativo se hace primero en shots.json y se propaga hacia abajo; nunca se parcha un prompt de forma que contradiga su shot.

### 6.4 División forge ↔ smixs
`visual-prompt-forge` es dueño del **flujo de datos** (shots.json → borrador, critique.json → revisión selectiva). `video`/`image` smixs son dueños del **texto final** del prompt. El borrador del forge se reescribe a sintaxis smixs; nunca al revés.

### 6.5 Atribución
Todo entregable que use la capa smixs conserva la línea: *Serge Shima — github.com/smixs/visual-skills* (CC BY 4.0, obligatorio, incluye derivados generados por agentes). Colócala en los créditos del production package, no en cada prompt.

## 7. Rol de visual-media (decisión de alcance)

`visual-media` NO participa en el pipeline live-action: todo lo que cubre (composición, tipos de plano, luz, movimientos de cámara, ritmo de edición) lo cubren con más profundidad `video`, `image` y `storyboard-architect`, y activarla ahí solo mete ruido de triggers. Se invoca ÚNICAMENTE en dos casos:

1. **Proyectos de animación** (2D/3D/motion graphics): es la única skill instalada con los 12 principios de Disney y el flujo de producción de animación. En un proyecto animado, su sección de animación se suma a la Etapa 3 como referencia de performance y timing.
2. **Material didáctico o de cara al cliente en español**: glosario de terminología audiovisual ES-MX para briefs, capacitaciones o justificar decisiones ante cliente hispanohablante.

## 8. Degradación

Si una sub-skill no está instalada, no improvises su oficio en silencio: dilo en una línea y aplica el sustituto — brand-lock ausente → Visual Theme ligero; storyboard-architect ausente → ai-video-storyboard con IDs de shot manuales; critic ausente → checklist de crítica manual contra el shot card; linter ausente → los dos checks de `video` como gate final. Los `tools/` de shotkit viajan dentro de cada .skill empaquetado; requieren `pyyaml` y `jsonschema`.

## 9. Referencias de este skill

- `references/creative-strategy.md` — Protocolo completo de la Etapa 1: territorios, big ideas, concept cards, matriz de selección, dirección narrativa. Léelo SIEMPRE al ejecutar la Etapa 1.
- `references/production-package.md` — Spec del Final AI Video Production Package, reglas de trazabilidad y checklist maestro. Léelo SIEMPRE al ejecutar la Etapa 7.

<!-- SOURCE_FILE_END: skills/ai-production-director/SKILL.md -->


<!-- SOURCE_FILE_START: skills/ai-production-director/references/creative-strategy.md -->
# SOURCE FILE: `skills/ai-production-director/references/creative-strategy.md`

# Etapa 1 — Creative Strategy

Este módulo es la autoridad de la Etapa 1 del pipeline. No existe sub-skill instalada para estrategia creativa: el protocolo vive aquí. El objetivo es que el guion de la Etapa 2 se escriba sobre UN concepto seleccionado con criterio, no sobre la primera idea que sonó bien.

Profundidad por track: FILM ejecuta todo. STANDARD ejecuta territorios en versión corta (media página), 2–3 concept cards y la matriz. EXPRESS no ejecuta esta etapa.

## 1. Lectura del brief

Antes de idear, extrae del brief y deja por escrito:

- **Problema de negocio** (qué debe cambiar en el mundo real si el video funciona)
- **Audiencia** (quién, en qué momento, con qué fricción — no demografía vacía)
- **Single-minded proposition**: la única cosa que el video debe dejar instalada. Una frase. Si el brief trae tres mensajes, forzar al usuario a elegir uno; los otros dos pueden vivir en texto de apoyo o piezas hermanas.
- **Tono de marca** (del brand-lock si existe)
- **Restricciones duras** (legales, de plataforma, de presupuesto de generación)

Si el single-minded proposition no se puede escribir en una frase, la Etapa 1 no puede continuar. Resuélvelo con el usuario primero.

## 2. Territorios creativos

Un territorio es un espacio conceptual desde el cual se puede contar la proposición — no una idea todavía. Explora 3–4 territorios genuinamente distintos entre sí. Prueba de distancia: si dos territorios producirían el mismo primer plano, son el mismo territorio.

Formato por territorio (4–6 líneas):

```
### Territorio: [nombre evocador]
- Ángulo: desde dónde se mira la proposición (el ritual, el antagonista, el después, el detalle invisible…)
- Tensión que explota: qué fricción humana real usa como motor
- Textura: cómo se ve y suena este territorio (2 líneas sensoriales, sin vocabulario prohibido)
- Riesgo: por qué podría fallar o ya estar quemado en la categoría
```

Registros útiles para forzar distancia entre territorios: emocional vs. funcional · íntimo vs. épico de escala · humor vs. gravedad · protagonista humano vs. producto/entorno como personaje · tiempo real vs. elipsis.

## 3. Big ideas y concept cards

De los territorios más fuertes, baja 3–5 conceptos (FILM) o 2–3 (STANDARD). Cada concepto es UNA película posible, no una variación de la anterior. Formato obligatorio:

```
## Concept Card [N] — [Nombre]
**Territorio de origen:** [cuál]
**Logline:** [la película en 1–2 frases: quién quiere qué, qué lo impide, qué vemos]
**Insight:** [la verdad humana sobre la que se para — algo que la audiencia reconoce como cierto]
**Arco en 3 beats:** [apertura → quiebre → resolución, una línea cada uno]
**Imagen final:** [el último frame, concreto — es lo que el espectador se lleva]
**Por qué vende la proposición:** [mecánica explícita: cómo este concepto instala la single-minded proposition]
**Riesgo principal:** [producción, tono, o percepción — y su mitigación en una línea]
**Complejidad de generación AI:** [Baja/Media/Alta — nº de personajes con continuidad, entornos, física difícil, diálogo lip-sync]
```

El campo de complejidad AI no es decorativo: un concepto brillante con 4 personajes en continuidad a través de 12 shots es un riesgo de producción real en video generativo, y el usuario debe elegirlo sabiéndolo.

## 4. Matriz de selección

Presenta los conceptos en una matriz 1–5, sin promediar a ciegas — el usuario pondera:

| Concepto | Fuerza del insight | Distintividad vs. categoría | Fit de marca | Claridad de la proposición | Viabilidad AI | Riesgo |
|---|---|---|---|---|---|---|

Debajo de la matriz, tu recomendación argumentada en un párrafo: cuál elegirías y por qué, nombrando el trade-off que implica. Recomendar es parte del trabajo; decidir es del usuario.

**Gate de la etapa:** el usuario selecciona un concepto (puede pedir un híbrido — trátalo como concepto nuevo con su propia card antes de avanzar).

## 5. Dirección narrativa del concepto ganador

Puente hacia `screenwriter`. Media página que fija, para el concepto elegido:

- **Estructura**: nº de escenas/actos y función de cada una (usar la three-jobs rule como criterio: cada escena cambia emoción, avanza acción o sube presión)
- **Punto de vista**: desde quién se cuenta y por qué
- **Los 5 anclas preliminares** (se refinan en Etapa 3): una emoción dominante, un motivo recurrente, un objeto, un quiebre, una imagen final
- **Reglas del mundo**: qué existe y qué no en esta pieza (época, lugar, nivel de realismo, presencia del producto)
- **Duración objetivo y densidad**: cuántos segundos por beat, dónde vive la pausa

Este documento + la concept card son la entrada completa de la Etapa 2. Si `screenwriter` tuviera que preguntar algo estructural, esta etapa quedó corta — corrígela aquí.

<!-- SOURCE_FILE_END: skills/ai-production-director/references/creative-strategy.md -->


<!-- SOURCE_FILE_START: skills/ai-production-director/references/production-package.md -->
# SOURCE FILE: `skills/ai-production-director/references/production-package.md`

# Etapa 7 — Final AI Video Production Package

Spec del entregable final del pipeline. El paquete debe permitir que un editor, una agencia o el propio usuario dentro de tres meses produzca el video sin hacer una sola pregunta de contexto.

## 1. Estructura del paquete

```
production-package/
├── 00-README.md                  # Índice, track usado, resumen de decisiones, créditos
├── 01-strategy/
│   ├── brief.md                  # Brief original o su reconstrucción
│   ├── territories.md            # Territorios explorados (STANDARD/FILM)
│   ├── concept-cards.md          # Todas las cards + matriz + concepto seleccionado marcado
│   └── narrative-direction.md
├── 02-script/
│   ├── treatment.md              # Solo FILM
│   └── script.md                 # Escenas XML-tagged de screenwriter
├── 03-direction/
│   └── cinematic-direction.md    # Blocking, cámara, luz, color, 5 anclas, por escena
├── 04-shots/
│   ├── storyboard.md
│   ├── shots.json                # FUENTE DE VERDAD
│   ├── text-overlays.json
│   ├── run.json
│   └── brand-lock.snapshot.md
├── 05-anchors/
│   ├── anchor-plan.md            # Qué refs se necesitan y para qué shots
│   ├── prompts/round-N/          # Prompts de imagen por modelo, por ronda
│   ├── frames/round-N/           # Renders aprobados/evaluados
│   └── critiques/round-N/        # critique.json por shot evaluado
├── 06-video-prompts/
│   ├── prompts/                  # Un archivo por shot: shot_NN.<modelo>.txt
│   └── continuity-notes.md       # Bloques de continuidad entre clips
├── 07-delivery/
│   ├── preview.html              # storyboard-html-preview, single-file
│   └── post-production.md        # Checklist de post (ver §3)
└── brand-lock.md                 # Si existió Etapa 0
```

En EXPRESS el paquete se comprime a: README, shot list, prompts y checklist de post — misma trazabilidad, menos carpetas.

## 2. Reglas de trazabilidad

1. Todo prompt (imagen o video) lleva en comentario su `shot_id`.
2. Todo shot en shots.json referencia su escena del script (`scene` field o nota).
3. El script referencia la concept card ganadora en su encabezado.
4. Cambios: si un prompt necesita cambiar algo que su shot fija (encuadre, acción, luz), el cambio se hace en shots.json y se regenera hacia abajo. El paquete nunca contiene un prompt que contradiga su shot.
5. Verificación de cierre: muestrea 3 prompts al azar y traza la cadena prompt → shot → escena → concepto. Si un eslabón falta, el paquete no se entrega.

## 3. Checklist de post-producción (07-delivery/post-production.md)

Adaptar al proyecto, con specs concretos — no placeholders:

```
- [ ] Generar los N shots en [modelo(s)] con los prompts de 06-video-prompts/
- [ ] Verificar cada clip contra su shot card (encuadre, acción, luz) antes de editar
- [ ] Ensamblar en [NLE] siguiendo el orden y duraciones de shots.json
- [ ] Aplicar grade de consistencia: [referencia de color del brand-lock o Visual Theme]
- [ ] Transiciones: [tipo y duración definidos en dirección, no "al gusto"]
- [ ] Audio: [música género/BPM/posición de beats + VO + ambientes según dirección de audio por shot]
- [ ] Overlays de texto según text-overlays.json (tipografía del brand-lock)
- [ ] Export: [resolución, aspect ratio, fps, códec, loudness según plataforma destino]
- [ ] QA final contra los 5 anclas: ¿la pieza terminada conserva emoción, motivo, objeto, quiebre e imagen final?
```

## 4. Checklist maestro del pipeline (gate de la Etapa 7)

- [ ] Concepto seleccionado por el usuario documentado en 01-strategy
- [ ] Cada escena del script pasa fórmula de escena + three-jobs rule
- [ ] Dirección cinematográfica sin vocabulario prohibido
- [ ] shots.json validado (`validate_shots.py` limpio) y auditoría de 3 detalles por shot
- [ ] Anchors críticos con critique ACCEPT (≤2 rondas)
- [ ] Prompts de video en sintaxis del modelo destino, con los dos checks de `video` pasados
- [ ] `aurora-prompt-linter` limpio sobre todos los prompts (si está instalada)
- [ ] Trazabilidad muestreada (§2.5)
- [ ] preview.html abre offline y refleja el estado final
- [ ] Créditos en 00-README.md: atribución *Serge Shima — github.com/smixs/visual-skills* si se usó la capa smixs; licencias de sub-skills anotadas
- [ ] 00-README.md explica en ≤1 página qué es el proyecto, qué track se usó y dónde está cada cosa

<!-- SOURCE_FILE_END: skills/ai-production-director/references/production-package.md -->


<!-- SOURCE_FILE_START: skills/ai-video-storyboard/SKILL.md -->
# SOURCE FILE: `skills/ai-video-storyboard/SKILL.md`

---
name: ai-video-storyboard
description: Use when planning a multi-shot AI video (TikTok Reel, Instagram Ad, YouTube Shorts, product explainer) where the target duration exceeds what a single AI generation can produce (over 15 seconds), and you need a coordinated shot list with visually consistent prompts for each segment
---

# AI Video Storyboard Generator

## Overview

AI video generators produce 5–15 second clips. Real-world videos are longer: 30s TikToks, 60s ads, 90s explainers. This skill bridges that gap by producing a complete **shot-list storyboard** — a coordinated sequence of per-shot prompts with shared visual language, so the assembled final video looks like one intentional piece of work rather than six disconnected clips.

**Core insight:** Visual consistency across shots matters more than any single shot being perfect. A mediocre but consistent set of shots edits together; six gorgeous but mismatched shots do not.

## When to Use

- User wants a video longer than 15 seconds
- User wants a TikTok / Reel / Short / ad / explainer / B-roll sequence
- User says "help me make a video about X" and has no shot list
- User is about to generate multiple clips and needs a plan

**Do NOT use for:**
- Single-shot generation (just help with one prompt instead)
- Static image generation
- Video editing advice after clips are generated (that's a separate concern)

## Workflow

### Step 1 — Brief Intake

Ask the user these questions in a single message. Accept short answers:

1. **Goal platform and duration?** (TikTok 30s / Reel 15-60s / YouTube Short / Instagram Ad / explainer)
2. **What is the video about?** (subject, story, product)
3. **Brand vibe / tone?** (cozy, energetic, premium, minimalist, playful, cinematic, etc.)
4. **Call to action at the end?** (visit website, buy product, follow channel, etc.)
5. **Any hard constraints?** (must include logo, specific colors, locations, etc.)

If user already provided some of these, skip those questions and confirm the rest.

### Step 2 — Infer Structure

Based on duration and platform, divide the timeline into shots of ~5 seconds each (the sweet spot for AI video generators).

**Standard cadences:**

| Platform | Duration | Shots | Pacing |
|---|---|---|---|
| TikTok Hook | 15s | 3 | Fast cuts, single idea |
| TikTok Reel | 30s | 6 | Hook → Build → Payoff → CTA |
| Instagram Ad | 15s | 3 | Hook → Product → CTA |
| Instagram Ad | 30s | 6 | Hook → Problem → Product → Benefit → Social proof → CTA |
| YouTube Short | 60s | 12 | Hook → 3-act structure → CTA |
| Product Explainer | 90s | 18 | Problem → Solution → How it works → Results → CTA |
| Brand Story | 60s | 10-12 | Atmosphere-driven, longer shot holds |

### Step 3 — Establish Visual Consistency Layer

Before writing any shot, lock in the shared visual language. This is what makes shots edit together:

- **Color palette** (3-5 specific hex values or named colors)
- **Lighting style** (golden hour / neon / overcast / motivated / cinematic rim light)
- **Lens character** (shallow DOF / deep focus / wide angle distortion / macro)
- **Film look** (clean digital / 16mm grain / anamorphic / VHS / 35mm)
- **Motion language** (handheld / locked off / dolly only / gimbal smooth)

Write these as a **Visual Theme** block at the top of the output. Every shot's prompt must respect this block.

### Step 4 — Write Each Shot

For each shot, produce this structure:

```
## Shot N (START-ENDs) — [Purpose label: Hook / Setting / Action / Detail / Reveal / CTA]

**Composition:** [shot type + angle, e.g., "Extreme close-up, overhead"]
**Camera move:** [locked / slow dolly in / tracking / crane up / etc.]
**Lighting:** [from the Visual Theme, applied to this scene]
**Subject:** [what is in frame]
**Action:** [what is happening]

**Prompt to copy:**
> [Complete, cinematic-quality prompt, 40-80 words, including: subject + action + environment + camera + lighting + style + technical spec (duration, aspect ratio, resolution). Always ends with "cinematic 1080p, synchronized audio"]

**Audio direction:** [what the synchronized audio should sound like — ambient sounds, music beat position, voice-over line]
```

**Critical rules for shot prompts:**

1. **Always specify the shared visual language** in every prompt (color palette, lighting, lens character, film look). This is how you enforce consistency.
2. **Specify exact duration** (4s / 5s / 8s) and **aspect ratio** (9:16 for TikTok/Reels, 16:9 for YouTube landscape, 1:1 for feed posts).
3. **Always end with "cinematic 1080p, synchronized audio"** — this signals professional-grade quality and works with modern video models that support both.
4. **Use cinematography vocabulary**: ECU (extreme close-up), CU, MS (medium shot), WS (wide shot), OTS (over-the-shoulder), POV, Dutch angle, low angle, high angle, bird's eye, dolly in, dolly out, tracking, handheld, rack focus, etc.
5. **Don't write abstract prompts** — be concrete. "A woman" → "A barista in her late 20s with wavy auburn hair, wearing a denim apron".
6. **No model-specific hacks** — don't write prompts tuned to specific model quirks. Write model-agnostic cinematic prompts that work anywhere.

### Step 5 — Add Narrative Structure

The sequence of shots must have a **story arc**, not a random list. Use one of these patterns:

**Pattern A — Hook / Build / Payoff / CTA (TikTok default)**
- Shot 1: Visual hook (stop the scroll)
- Shot 2-3: Build context / intrigue
- Shot 4-5: Main content / payoff
- Shot 6: CTA

**Pattern B — Problem / Solution / Proof / CTA (Ad default)**
- Shots 1-2: Relatable problem
- Shot 3: Your product as solution
- Shots 4-5: Benefits / results
- Shot 6: CTA

**Pattern C — Atmosphere → Climax (Brand story)**
- Longer atmospheric shots
- Slow reveal
- Emotional climax
- Logo reveal

### Step 6 — Add Post-Production Checklist

Close with actionable post-production notes:

```
## Post-Production Checklist
- [ ] Generate all N shots with your preferred AI video tool
- [ ] Stitch in [CapCut / Descript / DaVinci Resolve / Premiere]
- [ ] Apply [specific LUT or color grade] for consistency
- [ ] Add [transition type and duration] between shots
- [ ] Layer BGM: [genre / BPM / mood]
- [ ] Add text overlays for [hook / CTA / captions]
- [ ] Export [platform spec: 9:16 1080x1920 30fps for TikTok, etc.]
```

### Step 7 — Explain Why It Works

Close with a "Why this works" block explaining the creative decisions. This educates the user and differentiates your output from generic prompt lists. Reference:

- The hook rule (first second determines watch-through)
- Pacing cadence (average scroll time)
- Story structure (why the shot order matters)
- Platform-specific conventions

## Output Format

The final output is a single Markdown document containing:

1. **Header** — Title, duration, shot count, aspect ratio
2. **Visual Theme** — Shared palette, lighting, lens, film look, motion
3. **Shot List** — N shots, each following the structure in Step 4
4. **Post-Production Checklist**
5. **Why This Works** — creative rationale

See `examples/tiktok-reel-30s-coffee.md` for a complete worked sample output (coffee shop opening TikTok, 30s / 6 shots).

## License

MIT — use freely, commercial or personal.

<!-- SOURCE_FILE_END: skills/ai-video-storyboard/SKILL.md -->


<!-- SOURCE_FILE_START: skills/ai-video-storyboard/examples/tiktok-reel-30s-coffee.md -->
# SOURCE FILE: `skills/ai-video-storyboard/examples/tiktok-reel-30s-coffee.md`

# 30s TikTok Reel — Coffee Shop Opening

**Brief:** Small specialty coffee shop launching next week. Want a TikTok Reel to build anticipation and drive foot traffic on opening day.

- **Platform:** TikTok
- **Duration:** 30 seconds
- **Shots:** 6 × 5s
- **Aspect:** 9:16
- **CTA:** "Visit us. Opening next Saturday."
- **Brand vibe:** Warm, analog, hand-crafted, for slow-morning coffee lovers

---

## Visual Theme (applied to every shot)

- **Color palette:** Deep espresso brown `#3B2416`, cream `#F5E6D3`, muted amber `#D4A574`, soft sage green `#8FA88C`, black coffee `#1A1210`
- **Lighting style:** Warm golden backlight with motivated window light, soft shadows, no harsh fluorescents
- **Lens character:** Shallow depth of field, gentle bokeh, 35mm full-frame look
- **Film look:** Subtle 16mm film grain, slightly muted saturation, warm color temperature (around 3200K)
- **Motion language:** Locked-off or very slow push-ins, no handheld shake

---

## Shot 1 (0-5s) — Hook: The Pour

**Purpose:** Instant visual hook to stop the scroll. Universal sensory trigger.

**Composition:** Extreme close-up (ECU), slight overhead angle (~20° down)
**Camera move:** Locked off with micro push-in
**Lighting:** Strong warm backlight behind the cup, light rim-lighting the steam
**Subject:** Gooseneck kettle pouring hot water into a white ceramic V60 dripper
**Action:** Slow bloom of coffee grounds rising as water hits them

**Prompt to copy:**

> Extreme close-up overhead shot of hot water pouring from a brass gooseneck kettle into a white ceramic V60 dripper filled with dark coffee grounds, the grounds blooming and rising in slow motion, warm golden backlight with visible steam curling upward, shallow depth of field, 35mm full-frame look, subtle 16mm film grain, deep espresso brown and cream color palette, muted saturation, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Intimate sound of pouring water, bloom of hot coffee crema, distant café ambience fading in. First acoustic guitar note plays at 4.8s to bridge into Shot 2.

---

## Shot 2 (5-10s) — Setting: The Space

**Purpose:** Establish the space. Show it's real, it's cozy, it exists.

**Composition:** Medium wide shot (MWS), waist-high eye level
**Camera move:** Very slow dolly forward (~0.5x speed feeling)
**Lighting:** Large window on camera-left, warm amber streetlamp glow from deep background
**Subject:** Empty wooden café interior, reclaimed wood counter in focus, shelves of mugs blurred in background
**Action:** Morning sun rays cut through the space, dust motes floating

**Prompt to copy:**

> Medium wide shot slow dolly forward into a cozy specialty coffee shop interior, warm morning sunlight streaming through large windows on the left, reclaimed dark wood counter in sharp focus with shelves of handmade ceramic mugs blurred in background, dust motes visible in sun rays, muted sage green wall accents, shallow depth of field, 35mm full-frame look, subtle film grain, warm 3200K color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Acoustic guitar strum begins, layered with distant morning street sounds (birds, footsteps).

---

## Shot 3 (10-15s) — Human: The Barista

**Purpose:** Add a human face. Empathy trigger. This is the emotional center.

**Composition:** Medium close-up (MCU), slightly low angle (~10° up)
**Camera move:** Locked off
**Lighting:** Window light as key from camera-left, warm practical from counter lamp as fill
**Subject:** A female barista in her late 20s, wavy auburn hair tied back loosely, wearing a denim apron over a cream linen shirt
**Action:** She looks down at a pour-over in her hands, then looks up toward camera with a small, genuine smile

**Prompt to copy:**

> Medium close-up slightly low angle of a female barista in her late twenties with wavy auburn hair tied back, wearing a denim apron over cream linen shirt, standing behind a dark wood café counter, soft window light from the left creating warm rim light on her hair, she looks down at a pour-over coffee in her hands then slowly looks up at camera with a genuine small smile, shallow depth of field, 35mm full-frame look, subtle 16mm film grain, warm color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Guitar melody crescendo, ambient café sounds swell subtly. No voice-over needed — her expression carries the emotion.

---

## Shot 4 (15-20s) — Detail: The Beans

**Purpose:** Tactile close-up. Signals craft and quality.

**Composition:** Extreme close-up (ECU), macro-style
**Camera move:** Micro zoom in
**Lighting:** Warm directional light from upper right, strong shadows
**Subject:** Hand scooping whole coffee beans from a burlap sack into a wooden measuring cup
**Action:** Slow-motion bean cascade as hand tips the scoop

**Prompt to copy:**

> Macro extreme close-up of a hand scooping whole dark roasted coffee beans from a burlap sack into a small wooden measuring cup, slow motion cascade of beans spilling out as the hand tips the scoop, warm directional window light from upper right creating strong shadow depth, individual beans visible in sharp detail, shallow depth of field, deep espresso brown and burlap cream palette, subtle 16mm film grain, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Sound of beans tumbling, slightly rhythmic, quantized to the guitar beat. Guitar is now in full swing.

---

## Shot 5 (20-25s) — Atmosphere: The Customer Moment

**Purpose:** Show the space in use. Aspirational — "this could be you."

**Composition:** Medium shot (MS), over-the-shoulder angle (OTS)
**Camera move:** Slow pedestal down (~0.5x speed feeling)
**Lighting:** Window backlight creating gentle rim on the customer, warm amber spill from interior
**Subject:** A young customer sitting at a wooden window counter, laptop open, ceramic cup in hand
**Action:** She takes a slow sip, closes eyes briefly, sets cup down

**Prompt to copy:**

> Over-the-shoulder medium shot of a young female customer sitting at a wooden window counter inside a coffee shop, her laptop open in soft focus, a handmade ceramic coffee cup in her hand, warm window backlight creating gentle rim light on her silhouette, amber interior lamps in background blur, she slowly takes a sip of coffee and briefly closes her eyes in appreciation, slow pedestal camera move downward, shallow depth of field, 35mm full-frame look, subtle film grain, warm 3200K color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Guitar continues, ambient café sounds (gentle chatter, page turning), the soft clink of cup on saucer at the end.

---

## Shot 6 (25-30s) — CTA: Opening Reveal

**Purpose:** Clear, confident call to action. Brand reveal.

**Composition:** Medium wide shot (MWS), straight-on eye level
**Camera move:** Locked off, zero movement (intentional stop to read text)
**Lighting:** Soft even morning light
**Subject:** The café's hand-painted wooden sign on the front door, "Opening Saturday" chalk text visible below
**Action:** Minimal — a hand hanging an "OPEN" wooden sign on the door handle

**Prompt to copy:**

> Medium wide locked-off shot of a hand-painted wooden shop sign above a dark-framed café door, below it a small chalkboard reading "Opening Saturday", a hand reaches in frame to hang a wooden "OPEN" sign on the door handle, soft even morning light, sage green accent wall visible, warm muted palette, shallow depth of field on the door, 35mm full-frame look, subtle film grain, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Guitar resolves to final note, café ambience fades down. Sound of the wooden sign clacking against the door.

---

## Post-Production Checklist

- [ ] Generate all 6 shots with your preferred AI video tool
- [ ] Stitch in **CapCut** or **Descript** (simplest for TikTok workflow)
- [ ] Apply a consistent warm LUT — **Kodak Portra 400** emulation or **"Teal & Orange: Warm"** works well
- [ ] Add 0.3-0.4s **dissolve transitions** between Shots 1→2, 2→3, 4→5. Use a **hard cut** for Shot 3→4 (energy shift) and Shot 5→6 (CTA impact)
- [ ] Layer **BGM**: single acoustic guitar track at ~85 BPM, free from Artlist/Epidemic Sound. Something like "Morning Coffee" or "Slow Brew" genre keywords
- [ ] Add **text overlays**:
  - 0-1s: "Slow morning ☕️" (bottom center)
  - 25-30s: "Opening Saturday · @yourshop" (bold, centered)
- [ ] Export: **9:16, 1080×1920, 30fps, H.264, target bitrate 12 Mbps**
- [ ] Upload to TikTok with hashtags: `#coffeeshop #specialtycoffee #openingsoon #grandopening #coffeelover`

---

## Why This Works

**Structure:** Hook (1) → Setting (2) → Human (3) → Detail (4) → Atmosphere (5) → CTA (6). This is the classic TikTok cadence adapted for brand storytelling: a sensory hook to stop the scroll, a human face to build empathy, craft details to signal quality, an aspirational moment, then a clean CTA. No shot is wasted.

**Visual consistency:** Every shot shares the same color palette (espresso/cream/amber/sage), the same lighting temperature (warm 3200K with motivated window light), the same lens character (shallow DOF, 35mm), and the same film look (subtle 16mm grain). Even if the 6 shots are generated in separate runs, they will edit together as if shot by the same cinematographer in the same session.

**Pacing:** 5 seconds per shot matches the average scroll-dwell time on TikTok. Long enough to land the idea, short enough to maintain momentum. The 30s total is the sweet spot for completion-rate-optimized Reels.

**Emotion arc:** Shot 1 is sensory (hot water, steam), Shot 3 is emotional (barista's smile), Shot 5 is aspirational (customer enjoying the moment). This gives the viewer a reason to care beyond "coffee exists here".

**Why the prompts work:** They lean heavily on concrete cinematic vocabulary (shallow DOF, rim light, warm backlight, film grain) — specifics that modern AI video models can actually execute. The synchronized audio direction means each shot arrives with ambient café sounds pre-baked, dramatically reducing post-production sound design time.

<!-- SOURCE_FILE_END: skills/ai-video-storyboard/examples/tiktok-reel-30s-coffee.md -->


<!-- SOURCE_FILE_START: skills/aurora-prompt-linter/SKILL.md -->
# SOURCE FILE: `skills/aurora-prompt-linter/SKILL.md`

---
name: aurora-prompt-linter
description: "Gate determinista que valida prompts de generación visual AI (imagen/video) antes de entregar. Detecta 3 capas: redundancia con refs por categoría P/O/L/PR/S, secciones requeridas por plataforma+caso (Kling 3.0/Veo 3.1/Sora 2/GPT Image 2/Nano Banana Pro/Midjourney), y estructura (word count, negative prompt, vocab baneado). USA ESTE SKILL antes de entregar cualquier prompt visual al usuario — gate obligatorio del skill prompt-production-protocol Step 5b. Override solo con sintaxis expresa OVERRIDE: término-o-categoría - razón, válido únicamente en turno actual."
---

# Aurora Prompt Linter

Gate determinista entre el drafting del prompt y la entrega al usuario. Mueve la regla "no redescribir lo que está en los refs" de memoria del agente a código ejecutable.

## Por qué existe

El agente olvida la regla v6.0 §5.4 ("menos descripción de lo que HAY, más de cómo EVOLUCIONA") bajo presión de iteración rápida. Documentado empíricamente en sesión 2026-05-27: 4 errores repetidos de over-description en el mismo flujo. La memoria del agente falla, el código no.

## Cuándo usarlo

**Obligatorio** para:
- Casos 3a/3b/3c (I2V con FF/LF refs) — donde la redundancia es la falla más común

**Recomendado** para:
- Caso 1 (Génesis text-to-image)
- Caso 2 (Ancla con refs parciales)
- Caso 4 (Video con diálogo)

**El agente lo invoca automáticamente** al final de Step 4 (drafting) del skill `prompt-production-protocol`, antes de Step 6 (delivery). Si la Regla 28 está activa en el system prompt, es bloqueante.

## Cómo invocarlo

Antes de entregar el prompt al usuario:

1. **Etiquetar los refs por categoría.** Cada ref carga 0 o más de: P (sujeto), O (outfit), L (locación), PR (prop), S (estilo). Mapea a IDs system v6.0 §7. Ejemplo de refs.yaml:
   ```yaml
   - file: "img_ciclista_ff.jpg"
     role: "FF"
     tags: ["P1", "O1", "L1", "PR1"]
   - file: "img_climbing_wall_lf.jpg"
     role: "LF"
     tags: ["L2", "PR1"]
   ```

2. **Escribir el draft del prompt** (incluyendo negative prompt) a un archivo de texto.

3. **Capturar el mensaje del usuario** del turno actual a un archivo de texto (para parsear OVERRIDEs).

4. **Ejecutar el linter:**
   ```bash
   python3 scripts/prompt_linter.py \
     --prompt /tmp/draft.txt \
     --refs /tmp/refs.yaml \
     --case 3b \
     --overrides /tmp/user_msg.txt \
     --sports-broadcast
   ```

5. **Interpretar el resultado:**
   - Exit 0 → STATUS=PASS → entregar al usuario + incluir reporte del linter en el output para trazabilidad.
   - Exit 1 → STATUS=FAIL → NO entregar. Iterar el draft basándose en las violaciones listadas. Repetir hasta PASS.

## Categorías que detecta

| Categoría | Qué cubre | Cuándo se banea en MAIN |
|---|---|---|
| **P** | Sujeto: cara, cuerpo, edad, build, cabello, expresión, identidad | Si ref carga P |
| **O** | Outfit: prendas, colores, accesorios | Si ref carga O |
| **L** | Locación: piso, paredes, ventanas, lighting, ambiente | Si ref carga L |
| **PR** | Prop: balón, objeto interactuado | Si ref carga PR |
| **S** | Estilo: render, paleta, aesthetic | Si ref carga S |
| **BANNED** | Cross-platform: `slow motion`, `cartoon`, `anime`, `3D render`, `perfume ad`, `dreamlike` | SIEMPRE en MAIN (deben ir en NEGATIVE) |
| **STRUCTURE** | Word count, presencia de negative prompt | Siempre |
| **REQUIRED** | `60fps`, `broadcast realism` (con flag --sports-broadcast) | Cuando aplica Regla 26 v6.0 |

## Exenciones automáticas

El linter NO flaggea cuando el término aparece en:

- **Contexto de motion/cámara**: `camera arcs through the studio` — "studio" exento porque sigue a "camera".
- **Anchor direccional**: `away from her face`, `across the climbing wall`, `over his head` — preposiciones direccionales (`away from`, `toward`, `off`, `over`, `behind`, `across`, `past`, `onto`, `into`, `above`, `below`, `beside`) seguidas opcionalmente de `her/his/the` exentan el término que sigue.

Esto distingue descriptor estático ("warm tungsten studio") de uso funcional ("ball passes through the studio").

## Mecanismo de override

Si una violación detectada es legítima en el caso actual, el usuario puede autorizarla **expresamente por escrito en el turno actual**.

Sintaxis válida:
```
OVERRIDE: <término-o-categoría> - <razón>
```

Ejemplos válidos:
- `OVERRIDE: red performance tank - necesito reforzar el color porque seeds previas lo pierden`
- `OVERRIDE: L - autorizo describir locación porque la ref está muy oscura`
- `OVERRIDE: slow motion - explícitamente quiero slow motion en este clip`

Frases que **NO** cuentan como override (genéricas, sin scope específico):
- "hazlo de todas formas"
- "ya sé que está en la ref, déjalo"
- "ready to copy paste"
- "dale"

**Reglas críticas del override:**
- Solo válido en el turno actual del usuario. Autorizaciones de turnos pasados NO persisten.
- Cada prompt nuevo arranca STRICT (sin overrides activos).
- Override de categoría completa (ej. `OVERRIDE: L`) cubre todos los términos de esa categoría.
- Override de término específico (ej. `OVERRIDE: red performance tank`) solo cubre ese término.

## Word count por caso

| Case | Budget | Comportamiento |
|---|---|---|
| 1, 2 | 75-130 palabras | Max es HARD FAIL. Min es WARN no-bloqueante. |
| 3a, 3b, 3c | 50-90 palabras | Max es HARD FAIL (Regla 10 v6.0). Min es WARN — compresión válida si intencional. |
| 4 | 75-130 palabras | Same as 1/2. |

El conteo se hace solo sobre MAIN (no incluye negative prompt block).

## Output esperado

Reporte de texto plano (o JSON con `--json`). Ejemplo de FAIL:

```
============================================================
AURORA PROMPT LINTER REPORT v1.0
============================================================
Case: 3b (I2V FF + LF)
Word count (MAIN): 127 / budget (50, 90)
Negative prompt: present
Categories covered by refs: ['L', 'O', 'P', 'PR']
Sports broadcast mode: on

VIOLATIONS (27):
  FAIL [L] 'studio' - Static descriptor of category L (covered by refs)
  FAIL [L] 'concrete walls' - Static descriptor of category L (covered by refs)
  ...
  FAIL [STRUCTURE] 'word_count=127' - Above HARD MAX 90 (Regla 10 v6.0)

OVERRIDES ACCEPTED (1):
  OK 'red performance tank' - necesito reforzar color por seeds previas

SUGGESTIONS:
  -> Strip from MAIN: [...] (category L already covered by refs)
  -> Move to NEGATIVE block: [...]
  -> Fix structure: ['word_count=127']

STATUS: FAIL
Delivery BLOCKED. Iterate or grant OVERRIDE in current turn.
============================================================
```

Ejemplo de PASS:
```
STATUS: PASS
Delivery PERMITTED.
```

## Limitaciones conocidas v1.0

- **Sinónimos**: "tank top" en ref + "athletic shirt" en prompt no se detecta como redundante. Roadmap v1.1: tabla de sinónimos.
- **Sub-tags por categoría**: O.upper / O.lower / P.face / P.body no soportados — un ref tagueado como O cubre todo outfit. Si el ref solo muestra el torso pero el clip va a mostrar zapatos, hay falso positivo en "white sneakers". Roadmap v1.2.
- **Vision check**: el linter no ve las imágenes, depende de los tags que el agente declara. Si tageo mal, falla en silencio. Mitigación: el agente debe re-verificar tags antes de invocar.
- **Vocabulary base**: las listas en `scripts/vocabularies.yaml` están calibradas para casos típicos de Aurora (cycling, soccer, fitness). Si el proyecto usa otros dominios (cocina, automotriz, etc.) hay que expandir las listas.

## Integración con system prompt v6.1

Si tu system prompt incluye Regla 28 (v6.1+), este linter es bloqueante — el agente NO entrega prompts sin pasar el linter o sin overrides válidos. Si tu system prompt es v6.0, el linter es opcional pero altamente recomendado.

Ver `references/skill_update_step5.md` para la edit al skill prompt-production-protocol.
Ver `references/system_prompt_v6_1_rule28.md` para el bundle de 9 cambios que actualizan v6.0 → v6.1.

## Archivos del paquete

```
aurora-prompt-linter/
├── SKILL.md                       (este archivo)
├── scripts/
│   ├── prompt_linter.py           (CLI ejecutable)
│   └── vocabularies.yaml          (vocabulary lists base)
└── references/
    ├── README.md                  (uso detallado + tests)
    ├── skill_update_step5.md      (edit al skill prompt-production-protocol)
    └── system_prompt_v6_1_rule28.md (9 edits propuestas a system prompt v6.0)
```

## Versión

v1.0 — 2026-05-27
Built by: Final Upgrade AI / Eric Toledano
Origen: Retrospectiva F7 sesión 2026-05-27

<!-- SOURCE_FILE_END: skills/aurora-prompt-linter/SKILL.md -->


<!-- SOURCE_FILE_START: skills/aurora-prompt-linter/references/README.md -->
# SOURCE FILE: `skills/aurora-prompt-linter/references/README.md`

# Aurora Prompt Linter v1.0

Linter determinista que bloquea entrega de prompts AI con redundancia respecto a refs, violaciones de estructura, vocabulario baneado o falta de keywords obligatorios. Integra con el skill `prompt-production-protocol` como gate obligatorio en Step 5.

## Por qué existe

Sesión 2026-05-27: el agente cometió el mismo error tres veces (describir en el prompt cosas ya visibles en los refs). v6.0 §5.4 lo prohíbe pero el agente lo olvida bajo presión. El linter mueve el enforcement de "memoria del agente" a "regla determinista en código".

## Cobertura

| Versión | Cobertura efectiva |
|---|---|
| Solo memoria + skill | ~50% |
| Linter regex genérico | ~70% |
| **v1.0 (este) — tags por categoría + override** | **~92-94%** |

## Cómo se usa

```bash
python3 prompt_linter.py \
  --prompt path/to/prompt.txt \
  --refs path/to/refs.yaml \
  --case 3b \
  --overrides path/to/user_message.txt \
  --sports-broadcast
```

Exit code:
- `0` → PASS, entrega permitida
- `1` → FAIL, entrega bloqueada

## Formato de refs.yaml

Cada ref se etiqueta con las categorías que carga (mapea a IDs system v6.0 §7):

```yaml
- file: "img_ciclista_balon_aire.jpg"
  role: "FF"          # FF | LF | MR (motion ref)
  tags: ["P1", "O1", "L1", "PR1"]   # persona, outfit, locación, prop
- file: "img_climbing_wall.jpg"
  role: "LF"
  tags: ["L2", "PR1"]    # nueva locación + mismo prop
```

Categorías:
- **P** — Personaje / Sujeto
- **O** — Outfit
- **L** — Locación
- **PR** — Prop
- **S** — Estilo

Si una categoría tiene AL MENOS UN ref, sus descriptores estáticos quedan baneados en el MAIN prompt. Las categorías sin ref siguen siendo describibles.

## Casos soportados

| Case | Descripción | Word budget |
|---|---|---|
| 1 | Génesis text-to-image | 75-130 |
| 2 | Ancla image-with-refs | 75-130 |
| 3a | I2V FF only | 50-90 |
| 3b | I2V FF + LF | 50-90 |
| 3c | I2V motion control | 50-90 |
| 4 | Video con diálogo | 75-130 |

Word count: el MAX es HARD FAIL (Regla 10 v6.0). El MIN es WARN no-bloqueante (compresión válida si intencional).

## Override mechanism

Si una violación detectada es legítima en este caso, el usuario puede autorizarla por escrito en el turno actual. **Solo se acepta autorización expresa específica.**

Sintaxis:
```
OVERRIDE: <term-or-category> - <reason>
```

Ejemplos válidos:
```
OVERRIDE: red performance tank - necesito reforzar el color porque seeds previas lo pierden
OVERRIDE: L - autorizo describir locación porque la ref está muy oscura
OVERRIDE: slow motion - explícitamente quiero slow motion en este clip
```

Ejemplos NO válidos (genéricos, sin scope específico):
- "hazlo de todas formas"
- "ya sé que está en la ref, déjalo"
- "ready to copy paste"

El override solo es válido en el turno actual del usuario. Autorizaciones de turnos pasados NO persisten — cada prompt nuevo arranca STRICT.

## Reglas que aplica

1. **Redundancia por categoría**: si ref carga categoría X, no describir X en MAIN.
2. **Vocabulario baneado cross-platform**: `slow motion`, `cartoon`, `anime`, `3D render`, etc. solo en NEGATIVE block.
3. **Word count**: cap MAX duro = 90 (I2V) o 130 (T2I); MIN soft = 50/75.
4. **Negative prompt**: bloque obligatorio.
5. **Sports broadcast**: si flag activo, requiere `60fps` y `broadcast realism` en MAIN (Regla 26 v6.0).
6. **Exenciones**: términos en contexto de motion/cámara o como anchor direccional (`away from her face`, `across the climbing wall`) NO se flaggean.

## Limitaciones conocidas v1.0 (roadmap v1.1+)

- **Sinónimos**: "tank top" en ref + "athletic shirt" en prompt = no detectado. Solución v1.1: tabla de sinónimos en vocabularies.yaml.
- **Sub-tags por categoría**: O.upper / O.lower / P.face / P.body — para refs con coverage parcial. v1.2.
- **Embeddings semánticos**: para paráfrasis más sutiles. v2.0 si justifica el costo.
- **Auto-suggest rewrite**: hoy lista qué quitar; v1.1 podría generar versión limpia automática.
- **Vision check**: linter no ve las imágenes, depende de los tags. Si tageo mal, falla en silencio. Mitigación: review humano del tag antes de correr.

## Integración con skill

El linter NO corre solo. El skill `prompt-production-protocol` Step 5 debe invocarlo como item crítico. Ver `skill_update_step5.md` para la edit propuesta.

System prompt v6.1 (propuesta): nueva Regla 28 forzando llamada al linter antes de Step 6 delivery. Ver `system_prompt_v6_1_rule28.md`.

## Archivos del paquete

```
aurora-linter/
├── prompt_linter.py        # Script ejecutable
├── vocabularies.yaml       # Vocabulary lists por categoría
├── README.md               # Este archivo
├── skill_update_step5.md   # Edit propuesta al skill Step 5
├── system_prompt_v6_1_rule28.md  # Edit propuesta al system prompt
├── test_refs_session.yaml  # Test fixture
├── test_prompt_BAD.txt     # Test: prompt con 27 violaciones
├── test_prompt_GOOD.txt    # Test: prompt limpio
└── test_override_msg.txt   # Test: mensaje con overrides válidos
```

## Versión

v1.0 — 2026-05-27
Built by: Final Upgrade AI / Eric Toledano
Fuente: retrospectiva F7 sesión 2026-05-27

<!-- SOURCE_FILE_END: skills/aurora-prompt-linter/references/README.md -->


<!-- SOURCE_FILE_START: skills/aurora-prompt-linter/references/skill_update_step5.md -->
# SOURCE FILE: `skills/aurora-prompt-linter/references/skill_update_step5.md`

# Edit propuesta al skill `prompt-production-protocol` — Step 5

**Fecha:** 2026-05-27
**Origen:** Retrospectiva F7 sesión 2026-05-27 (errores repetidos de redundancia con refs).
**Tipo:** MAYOR — añade gate determinista al proceso.

## Sección afectada

`protocol/05_self_audit.md` (Step 5 del proceso de 6 pasos).

## Edit concreta

### ANTES (texto actual)

> ### Step 5 — Self-audit VISIBLE
> Leer: `protocol/05_self_audit.md`
> - Ejecutar checklist específico del caso
> - Marcar cada item Pass/Fail en el output
> - **Si algún item crítico es Fail → revisar el draft y re-auditar. No entregar hasta pasar.**

### DESPUÉS (texto propuesto)

> ### Step 5 — Self-audit VISIBLE + Linter determinista
> Leer: `protocol/05_self_audit.md`
>
> **Step 5a — Self-audit cualitativo (igual que antes):**
> - Ejecutar checklist específico del caso
> - Marcar cada item Pass/Fail en el output
> - Si algún item crítico es Fail → revisar el draft y re-auditar
>
> **Step 5b — Linter determinista (NUEVO, obligatorio para casos 3a/3b/3c — recomendado para 1/2/4):**
> - Invocar `aurora-linter/prompt_linter.py` con: prompt, refs (con tags por categoría), case_type, mensaje del usuario (para parsear OVERRIDEs).
> - El linter chequea: redundancia por categoría, word count, negative prompt, vocabulario baneado, keywords requeridos.
> - Si STATUS=PASS → proceder a Step 6.
> - Si STATUS=FAIL sin override válido → NO entregar. Iterar el draft. NO se permite entregar al usuario con FAIL del linter.
> - Si STATUS=FAIL con overrides aceptados que cubren todas las violaciones → proceder a Step 6, declarando los overrides en el output del prompt.
> - Si STATUS=FAIL con overrides parciales (algunas violaciones overrideadas, otras no) → iterar el draft hasta limpiar las no-overrideadas.
>
> **Step 5c — Reporte del linter visible al usuario:**
> Incluir en el output del prompt el resumen del linter:
> ```
> LINTER: PASS (o FAIL con overrides)
> Violaciones detectadas: N
> Overrides aceptados: M
> Categorías cubiertas por refs: [...]
> ```
>
> Esto da trazabilidad y permite al usuario confirmar que el linter corrió antes de la entrega.

## Razón del cambio

Sesión 2026-05-27 documentó 4 errores repetidos de over-description en I2V — la regla v6.0 §5.4 existe pero el agente la olvida bajo presión de iteración rápida. El linter mueve enforcement de memoria a código.

Beneficio adicional: el override mechanism preserva flexibilidad cuando un caso edge justifica violar la regla, sin permitir abuso (requiere expresión escrita específica del usuario en el turno actual).

## Impacto en flujo

Sin linter: agente entrega → usuario corrige error en turno N+1 → agente reescribe → ciclo. Costo: ~3-4 turnos por iteración.

Con linter: agente intenta entregar → linter FAIL → agente reescribe ANTES de mostrar al usuario → entrega clean. Costo: ~0 turnos adicionales para el usuario.

## Cómo se invoca

Desde el agente al final del Step 4 drafting:

```python
# Pseudocódigo del agente
draft = "..."          # el prompt construido
refs = [...]           # tags por ref
case = "3b"            # caso clasificado en Step 0
user_msg = "..."       # mensaje completo del usuario en el turno actual

# Escribir a temp files
write("/tmp/draft.txt", draft)
write("/tmp/refs.yaml", refs_yaml)
write("/tmp/user.txt", user_msg)

# Correr linter
result = bash(f"python3 aurora-linter/prompt_linter.py --prompt /tmp/draft.txt --refs /tmp/refs.yaml --case {case} --overrides /tmp/user.txt")

if result.exit_code == 0:
    # PASS, proceder a Step 6
    deliver(draft, linter_report=result.stdout)
else:
    # FAIL, iterar
    new_draft = revise_based_on_report(draft, result.stdout)
    # vuelve a Step 4 hasta PASS
```

## Aprobación requerida

- [ ] Aprueba la edit a Step 5
- [ ] Modificar (especificar qué)
- [ ] Rechazar (sin cambios, linter queda como herramienta opcional)

<!-- SOURCE_FILE_END: skills/aurora-prompt-linter/references/skill_update_step5.md -->


<!-- SOURCE_FILE_START: skills/aurora-prompt-linter/references/system_prompt_v6_1_rule28.md -->
# SOURCE FILE: `skills/aurora-prompt-linter/references/system_prompt_v6_1_rule28.md`

# Edit propuesta al system prompt v6.0 — Regla 28 + ajustes

**Fecha:** 2026-05-27
**Origen:** Retrospectiva F7 sesión 2026-05-27.
**Tipo de versión:** v6.0 → v6.1 (cambio MAYOR — añade regla inviolable + mecanismo de override).

## Cambio 1 — Nueva Regla 28

### Ubicación
Sección 14 "REGLAS INVIOLABLES" — añadir como #28, después de Regla 27 actual.

### Texto a añadir

```
28	LINTER DETERMINISTA OBLIGATORIO ANTES DE ENTREGAR PROMPT — Para todos los casos (1/2/3a/3b/3c/4), ejecutar `aurora-linter/prompt_linter.py` al final del Step 4 drafting con: prompt, refs tageadas por categoría (P/O/L/PR/S según IDs system §7), case_type, y mensaje completo del usuario en el turno actual para parsear OVERRIDEs. Si STATUS=FAIL sin overrides que cubran todas las violaciones, NO entregar al usuario — iterar el draft hasta PASS. El reporte del linter (PASS/FAIL + violaciones + overrides aceptados) se incluye en el output visible al usuario para trazabilidad. Override de violación requiere autorización expresa del usuario por escrito en el turno actual con sintaxis `OVERRIDE: <término-o-categoría> - <razón>`; frases genéricas ("dale", "hazlo ya", "ready to copy paste") NO cuentan como override. Las autorizaciones NO persisten entre turnos — cada prompt arranca STRICT.
```

## Cambio 2 — Actualizar Sección 1.3 (Principios fundamentales)

### Texto a añadir al final de Sección 1.3

```
Enforcement determinista: cuando una regla puede codificarse, debe codificarse. La memoria del agente falla bajo presión de iteración rápida; el código no. Reglas con linter determinista (Regla 28) gana sobre regla en prosa cuando ambas existen y dicen lo mismo.
```

## Cambio 3 — Actualizar Sección 4.6 (F4 — Prompts Génesis)

### Texto a añadir al final del paso 3 ("Entregar con trazabilidad completa")

```
- Antes de entregar, ejecutar Regla 28 (linter). Sin PASS o sin overrides cubriendo violaciones, NO entregar.
```

## Cambio 4 — Actualizar Sección 4.7 (F5 — Prompts Ancla FF+LF)

### Texto a añadir después del paso 4 (caso 2.5 deportivo)

```
6. Antes de entregar la Ancla, ejecutar Regla 28 (linter). Sin PASS o sin overrides cubriendo violaciones, NO entregar.
```

## Cambio 5 — Actualizar Sección 4.8 (F6 — Research video + Prompts)

### Texto a añadir después del paso 2 (INVOCAR skill)

```
3. Antes de entregar el prompt video, ejecutar Regla 28 (linter) — especialmente crítico en I2V donde la redundancia con refs es la falla más común. Sin PASS o sin overrides cubriendo violaciones, NO entregar.
```

## Cambio 6 — Sección 5 (Aprendizajes validados) — Nueva sub-sección 5.5

```
5.5 Linter determinista — disciplina sobre memoria

Sesión 2026-05-27 documentó que la regla "no redescribir lo que está en los refs" (v6.0 §5.4) se viola repetidamente bajo presión de iteración rápida. La memoria del agente falla; el código no. El linter aurora-linter/prompt_linter.py mueve enforcement de memoria a código determinista. Aplica las siguientes reglas como gates duros:

- Redundancia por categoría P/O/L/PR/S vía IDs system §7.
- Word count duro (Regla 10 v6.0): 130 max T2I, 90 max I2V.
- Vocabulario baneado en MAIN: cartoon, anime, slow motion, etc. (deben ir en NEGATIVE).
- Negative prompt obligatorio.
- Keywords sports broadcast cuando aplica Regla 26.
- Exenciones: motion/camera context, anchors direccionales (away from her face).

Override del linter solo se acepta con autorización expresa escrita en el turno actual, con scope específico (término o categoría). Esto preserva flexibilidad sin permitir abuso de la disciplina.
```

## Cambio 7 — Sección 14 actualizada: "27 total" → "28 total"

### ANTES
```
14. REGLAS INVIOLABLES — v6.0 (27 total)
```

### DESPUÉS
```
14. REGLAS INVIOLABLES — v6.1 (28 total)
```

## Cambio 8 — Header del prompt

### ANTES
```
SYSTEM PROMPT v6.0
Fecha de emisión: 2026-05-23
```

### DESPUÉS
```
SYSTEM PROMPT v6.1
Fecha de emisión: 2026-05-27
```

## Cambio 9 — Añadir entrada al CHANGELOG

### Insertar al inicio del bloque CHANGELOG (después del header de versión)

```
CHANGELOG v6.1 (desde v6.0)
Origen: Retrospectiva F7 sesión 2026-05-27 — proyecto "Sports World Mundial 2026", múltiples prompts I2V con redundancia repetida.
- [CRÍTICO] Nueva Regla 28: linter determinista obligatorio antes de entregar cualquier prompt. Sin PASS o sin overrides cubriendo violaciones, no se entrega al usuario.
- [MAYOR] Sección 5.5: nueva sub-sección sobre disciplina vía linter determinista — la memoria del agente falla bajo presión, el código no.
- [MAYOR] Sección 1.3: nuevo principio — cuando una regla puede codificarse, debe codificarse.
- [MENOR] Override de linter requiere autorización expresa escrita en turno actual con scope específico (sintaxis `OVERRIDE: <term> - <reason>`).
- [MENOR] Actualizadas Secciones 4.6, 4.7, 4.8 con llamada explícita a Regla 28 antes de entrega.
- Consistencia: v6.0 → v6.1; Reglas Inviolables 27 → 28; fecha 2026-05-23 → 2026-05-27.
```

## Resumen de propuestas

| # | Cambio | Tipo | Sección |
|---|---|---|---|
| 1 | Nueva Regla 28 | CRÍTICO | §14 |
| 2 | Nuevo principio enforcement determinista | MAYOR | §1.3 |
| 3 | F4 paso final con linter | MENOR | §4.6 |
| 4 | F5 paso final con linter | MENOR | §4.7 |
| 5 | F6 paso final con linter | MENOR | §4.8 |
| 6 | Nueva sub-sección 5.5 | MAYOR | §5 |
| 7 | Contador 27→28 | MENOR | §14 |
| 8 | Versión + fecha | MENOR | header |
| 9 | CHANGELOG v6.1 | MENOR | inicio doc |

## Aprobación

Cada cambio puede aprobarse/rechazarse individualmente. Recomendación: aprobar el bundle completo (los 9 cambios forman una unidad coherente).

- [ ] Aprobar bundle completo (recomendado)
- [ ] Aprobar selectivamente (especificar cuáles)
- [ ] Rechazar bundle (linter queda como herramienta opcional sin regla inviolable)

<!-- SOURCE_FILE_END: skills/aurora-prompt-linter/references/system_prompt_v6_1_rule28.md -->


<!-- SOURCE_FILE_START: skills/aurora-prompt-linter/scripts/prompt_linter.py -->
# SOURCE FILE: `skills/aurora-prompt-linter/scripts/prompt_linter.py`

#!/usr/bin/env python3
"""Aurora Prompt Linter v1.1 - 3-layer validation (refs redundancy + sections by platform+case + structure)."""
import re, sys, json, argparse
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Dict, Set, Tuple, Optional

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML required. pip install pyyaml --break-system-packages", file=sys.stderr)
    sys.exit(2)


@dataclass
class RefTag:
    file: str
    role: str
    tags: List[str]


@dataclass
class Override:
    term: str
    category: str
    reason: str
    source_text: str


@dataclass
class Violation:
    term: str
    category: str
    reason: str


@dataclass
class LinterResult:
    status: str
    case_type: str
    platform: str
    word_count: int
    word_budget: Tuple[int, int]
    covered_categories: List[str]
    sections_required: List[str]
    sections_present: List[str]
    sections_missing: List[str]
    violations: List[Violation]
    overrides_accepted: List[Override]
    warnings: List[str]
    suggestions: List[str]
    report: str

    def to_dict(self):
        return {
            "status": self.status, "case_type": self.case_type, "platform": self.platform,
            "word_count": self.word_count, "word_budget": list(self.word_budget),
            "covered_categories": self.covered_categories,
            "sections_required": self.sections_required,
            "sections_present": self.sections_present,
            "sections_missing": self.sections_missing,
            "violations": [asdict(v) for v in self.violations],
            "overrides_accepted": [asdict(o) for o in self.overrides_accepted],
            "warnings": self.warnings, "suggestions": self.suggestions,
        }


CASE_CONFIGS = {
    "1":  {"name": "Genesis (text-to-image)",  "budget": (75, 130), "requires_negative": True},
    "2":  {"name": "Anchor (image with refs)", "budget": (75, 130), "requires_negative": True},
    "3a": {"name": "I2V FF only",              "budget": (50, 90),  "requires_negative": True},
    "3b": {"name": "I2V FF + LF",              "budget": (50, 90),  "requires_negative": True},
    "3c": {"name": "I2V motion control",       "budget": (50, 90),  "requires_negative": True},
    "4":  {"name": "Video with dialogue",      "budget": (75, 130), "requires_negative": True},
}


def normalize_tag(tag: str) -> str:
    m = re.match(r"^([A-Z]+)\d*$", tag.strip())
    return m.group(1) if m else tag


def covered_categories(refs: List[RefTag]) -> Set[str]:
    cats = set()
    for ref in refs:
        for tag in ref.tags:
            cats.add(normalize_tag(tag))
    return cats


def split_main_and_negative(prompt: str) -> Tuple[str, str]:
    parts = re.split(r"(?i)\bnegative\s*:", prompt, maxsplit=1)
    return parts[0], (parts[1] if len(parts) > 1 else "")


def word_count_of(text: str) -> int:
    return len(text.split())


def find_term_in_text(term: str, text: str) -> List[Tuple[int, int]]:
    text_lower, term_lower = text.lower(), term.lower()
    spans = []
    if " " in term_lower:
        start = 0
        while True:
            idx = text_lower.find(term_lower, start)
            if idx == -1: break
            spans.append((idx, idx + len(term_lower)))
            start = idx + 1
    else:
        for m in re.finditer(r"\b" + re.escape(term_lower) + r"\b", text_lower):
            spans.append((m.start(), m.end()))
    return spans


DIRECTIONAL_PREPOSITIONS = [
    "away from", "toward", "towards", "off", "over", "behind",
    "in front of", "across", "past", "from her", "from his",
    "onto", "into", "above", "below", "beside",
]


def is_in_motion_context(text: str, span: Tuple[int, int], motion_prefixes: List[str]) -> bool:
    start = max(0, span[0] - 60)
    window_full = text[start:span[1]].lower()
    window_before = text[start:span[0]].lower()
    for prefix in motion_prefixes:
        pat = r"\b" + re.escape(prefix.lower()) + r"\b[^.]{0,50}$"
        if re.search(pat, window_full):
            return True
    for prep in DIRECTIONAL_PREPOSITIONS:
        pat = r"\b" + re.escape(prep) + r"\s+(?:her\s+|his\s+|the\s+)?$"
        if re.search(pat, window_before):
            return True
    return False


OVERRIDE_PATTERN = re.compile(
    r"OVERRIDE\s*:\s*(?P<term>[^\-\n]+?)\s*[\-]+\s*(?P<reason>[^\n]+)",
    re.IGNORECASE
)


def parse_overrides(user_message: str) -> List[Override]:
    overrides = []
    for m in OVERRIDE_PATTERN.finditer(user_message):
        term = m.group("term").strip().strip('"\'')
        reason = m.group("reason").strip()
        is_cat = bool(re.match(r"^[A-Z]{1,2}\d*$", term))
        overrides.append(Override(term=term, category=normalize_tag(term) if is_cat else "",
                                  reason=reason, source_text=m.group(0)))
    return overrides


def override_matches(v: Violation, overrides: List[Override]) -> Optional[Override]:
    for ovr in overrides:
        if ovr.term.lower() == v.term.lower(): return ovr
        if ovr.category and ovr.category == v.category: return ovr
    return None


def normalize_platform_case_key(platform: str, case_type: str) -> str:
    p = platform.strip().lower().replace("-", "_").replace(" ", "_").replace(".", "_")
    p = re.sub(r"_(\d+)_(\d+)", r"_\1.\2", p)
    return f"{p}__{case_type}"


def validate_sections(prompt_main: str, platform: str, case_type: str,
                     vocabs: Dict) -> Tuple[List[str], List[str], List[str]]:
    sections_db = vocabs.get("REQUIRED_SECTIONS_BY_PLATFORM_CASE", {})
    key = normalize_platform_case_key(platform, case_type)
    section_specs = sections_db.get(key)
    if section_specs is None:
        return [], [], []
    required, present, missing = list(section_specs.keys()), [], []
    main_lower = prompt_main.lower()
    for section_name, patterns in section_specs.items():
        if any(pat.lower() in main_lower for pat in patterns):
            present.append(section_name)
        else:
            missing.append(section_name)
    return required, present, missing


def validate(refs, prompt, case_type, platform, vocabs, overrides,
             require_sports_broadcast=False) -> LinterResult:
    config = CASE_CONFIGS.get(case_type)
    if not config:
        return LinterResult(status="FAIL", case_type=case_type, platform=platform,
            word_count=0, word_budget=(0, 0), covered_categories=[],
            sections_required=[], sections_present=[], sections_missing=[],
            violations=[], overrides_accepted=[], warnings=[], suggestions=[],
            report=f"ERROR: Unknown case_type {case_type}")

    main, negative = split_main_and_negative(prompt)
    cats = covered_categories(refs)
    motion_prefixes = vocabs.get("ALLOWED_MOTION_PREFIXES", [])

    violations: List[Violation] = []
    overrides_accepted: List[Override] = []
    overrides_used: Set[str] = set()
    warnings: List[str] = []

    # Layer 1: refs redundancy
    for cat in sorted(cats):
        for term in vocabs.get(cat, []):
            for span in find_term_in_text(term, main):
                if is_in_motion_context(main, span, motion_prefixes):
                    continue
                v = Violation(term=term, category=cat,
                              reason=f"Static descriptor of category {cat} (covered by refs)")
                ovr = override_matches(v, overrides)
                if ovr:
                    if ovr.source_text not in overrides_used:
                        overrides_accepted.append(ovr)
                        overrides_used.add(ovr.source_text)
                else:
                    violations.append(v)
                break

    # Layer 2: required sections by platform+case
    sec_req, sec_pres, sec_miss = validate_sections(main, platform, case_type, vocabs)
    if not sec_req and platform:
        warnings.append(
            f"No required-sections snapshot for platform '{platform}' + case '{case_type}'. "
            f"Update vocabularies.yaml REQUIRED_SECTIONS_BY_PLATFORM_CASE.{normalize_platform_case_key(platform, case_type)}")
    for ms in sec_miss:
        v = Violation(term=ms, category="SECTION",
                      reason=f"Required section '{ms}' for platform '{platform}' case {case_type} not detected in MAIN")
        ovr = override_matches(v, overrides)
        if ovr:
            if ovr.source_text not in overrides_used:
                overrides_accepted.append(ovr)
                overrides_used.add(ovr.source_text)
        else:
            violations.append(v)

    # Layer 3: banned vocab in MAIN
    for term in vocabs.get("BANNED", []):
        if find_term_in_text(term, main):
            v = Violation(term=term, category="BANNED",
                          reason="Cross-platform banned vocab in main prompt")
            ovr = override_matches(v, overrides)
            if ovr:
                if ovr.source_text not in overrides_used:
                    overrides_accepted.append(ovr)
                    overrides_used.add(ovr.source_text)
            else:
                violations.append(v)

    # Word count
    wc_main = word_count_of(main)
    if wc_main > config["budget"][1]:
        violations.append(Violation(term=f"word_count={wc_main}", category="STRUCTURE",
            reason=f"Above HARD MAX {config['budget'][1]} (Regla 10 v6.1)"))
    elif wc_main < config["budget"][0]:
        warnings.append(
            f"Word count {wc_main} below soft min {config['budget'][0]} (compression OK if intentional)")

    # Negative
    if config["requires_negative"] and not negative.strip():
        violations.append(Violation(term="negative_prompt", category="STRUCTURE",
            reason="Negative prompt block required"))

    # Sports broadcast
    if require_sports_broadcast:
        for kw in vocabs.get("REQUIRED_SPORTS_BROADCAST", []):
            if kw.lower() not in main.lower():
                violations.append(Violation(term=kw, category="REQUIRED",
                    reason="Required keyword for sports broadcast (Regla 26 v6.1)"))

    status = "PASS" if not violations else "FAIL"

    L = [
        "=" * 64,
        "AURORA PROMPT LINTER REPORT v1.1",
        "=" * 64,
        f"Case: {case_type} ({config['name']})",
        f"Platform: {platform if platform else '(none specified)'}",
        f"Word count (MAIN): {wc_main} / budget {config['budget']}",
        f"Negative prompt: {'present' if negative.strip() else 'MISSING'}",
        f"Categories covered by refs: {sorted(cats) if cats else '(none)'}",
        f"Sports broadcast mode: {'on' if require_sports_broadcast else 'off'}",
        ""
    ]
    if sec_req:
        L.append(f"REQUIRED SECTIONS for {platform} case {case_type}:")
        for s in sec_req:
            L.append(f"  {'PRESENT' if s in sec_pres else 'MISSING'} {s}")
        L.append("")
    if violations:
        L.append(f"VIOLATIONS ({len(violations)}):")
        for v in violations:
            L.append(f"  FAIL [{v.category}] '{v.term}' - {v.reason}")
    else:
        L.append("VIOLATIONS: none")
    if warnings:
        L.append("")
        L.append(f"WARNINGS ({len(warnings)}) non-blocking:")
        for w in warnings:
            L.append(f"  WARN {w}")
    if overrides_accepted:
        L.append("")
        L.append(f"OVERRIDES ACCEPTED ({len(overrides_accepted)}):")
        for o in overrides_accepted:
            L.append(f"  OK '{o.term}' - {o.reason[:100]}")
    suggestions: List[str] = []
    if violations:
        cat_vio: Dict[str, List[str]] = {}
        for v in violations:
            cat_vio.setdefault(v.category, []).append(v.term)
        for cat, terms in cat_vio.items():
            if cat in ("P", "O", "L", "PR", "S"):
                suggestions.append(f"Strip from MAIN: {terms} (category {cat} already covered by refs)")
            elif cat == "SECTION":
                suggestions.append(f"Add sections to MAIN: {terms} (required by platform '{platform}' case {case_type})")
            elif cat == "BANNED":
                suggestions.append(f"Move to NEGATIVE block: {terms}")
            elif cat == "STRUCTURE":
                suggestions.append(f"Fix structure: {terms}")
            elif cat == "REQUIRED":
                suggestions.append(f"Add to MAIN: {terms}")
        L.append("")
        L.append("SUGGESTIONS:")
        for s in suggestions:
            L.append(f"  -> {s}")
    L.append("")
    L.append(f"STATUS: {status}")
    L.append("Delivery BLOCKED. Iterate or grant OVERRIDE in current turn." if status == "FAIL" else "Delivery PERMITTED.")
    L.append("=" * 64)

    return LinterResult(status=status, case_type=case_type, platform=platform,
        word_count=wc_main, word_budget=config["budget"],
        covered_categories=sorted(cats), sections_required=sec_req,
        sections_present=sec_pres, sections_missing=sec_miss,
        violations=violations, overrides_accepted=overrides_accepted,
        warnings=warnings, suggestions=suggestions, report="\n".join(L))


def main():
    p = argparse.ArgumentParser(description="Aurora Prompt Linter v1.1")
    p.add_argument("--prompt", required=True)
    p.add_argument("--refs", required=True)
    p.add_argument("--case", required=True, choices=list(CASE_CONFIGS.keys()))
    p.add_argument("--platform", default="",
        help="Platform identifier (e.g., gpt_image_2, kling_3.0, veo_3.1, nano_banana_pro, sora_2)")
    p.add_argument("--vocab", default=None)
    p.add_argument("--overrides", default=None)
    p.add_argument("--sports-broadcast", action="store_true")
    p.add_argument("--json", action="store_true")
    args = p.parse_args()

    prompt = Path(args.prompt).read_text(encoding="utf-8")
    refs_data = yaml.safe_load(Path(args.refs).read_text(encoding="utf-8"))
    refs = [RefTag(**r) for r in refs_data]
    vocab_path = Path(args.vocab) if args.vocab else Path(__file__).parent / "vocabularies.yaml"
    vocabs = yaml.safe_load(vocab_path.read_text(encoding="utf-8"))
    overrides = []
    if args.overrides:
        overrides = parse_overrides(Path(args.overrides).read_text(encoding="utf-8"))
    result = validate(refs, prompt, args.case, args.platform, vocabs, overrides,
                      require_sports_broadcast=args.sports_broadcast)
    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(result.report)
    sys.exit(0 if result.status == "PASS" else 1)


if __name__ == "__main__":
    main()

<!-- SOURCE_FILE_END: skills/aurora-prompt-linter/scripts/prompt_linter.py -->


<!-- SOURCE_FILE_START: skills/aurora-prompt-linter/scripts/vocabularies.yaml -->
# SOURCE FILE: `skills/aurora-prompt-linter/scripts/vocabularies.yaml`

# Aurora Prompt Linter — Vocabulary Lists v1.0
# Fecha: 2026-05-27
# Cada lista corresponde a una categoría de la IDs system v6.0 §7.
# Cuando un ref carga esa categoría, los términos listados quedan BANNED
# en el prompt MAIN (no en el negative prompt).
# Sub-tags (P.body, O.upper, etc.) reservados para v1.1.

# ---------- P: Personaje / Sujeto ----------
P:
  - athletic woman
  - athletic man
  - lean build
  - muscular build
  - toned build
  - athletic build
  - lean toned build
  - mid-20s
  - mid-30s
  - mid-40s
  - mid-50s
  - young woman
  - young man
  - dark hair
  - brown hair
  - dark brown hair
  - blonde hair
  - black hair
  - red hair
  - ponytail
  - high ponytail
  - low ponytail
  - loose hair
  - curly hair
  - hair tied
  - female cyclist
  - male cyclist
  - female athlete
  - male athlete
  - athletic
  - lean
  - muscular
  - toned
  - tanned skin
  - face
  - jawline
  - sweat
  - sweaty
  - female
  - male

# ---------- O: Outfit ----------
O:
  - red sports bra
  - red shorts
  - red tank top
  - red top
  - red high-waist
  - red performance tank
  - red high-waist shorts
  - black t-shirt
  - black shorts
  - black tank top
  - black tights
  - black sneakers
  - white sneakers
  - performance tank top
  - athletic wear
  - workout clothes
  - sports bra
  - tank top
  - t-shirt
  - shorts
  - sneakers
  - shoes
  - leggings

# ---------- L: Locación ----------
L:
  - studio
  - gym
  - indoor cycling studio
  - modern studio
  - sunlit studio
  - climbing wall
  - bouldering wall
  - bouldering grips
  - black triangular volume
  - black triangular prism
  - wood floor
  - wooden floor
  - polished wood floor
  - polished light wood floor
  - concrete walls
  - concrete floor
  - cool gray walls
  - cool gray concrete
  - glass walls
  - floor-to-ceiling windows
  - floor-to-ceiling glass walls
  - city skyline
  - skyline
  - trees beyond
  - city beyond
  - out-of-focus city
  - windows
  - tungsten spots
  - warm tungsten
  - warm lighting
  - industrial lighting
  - natural daylight
  - soft shadows
  - soft directional shadows
  - night
  - at night
  - daylight
  - cycling studio
  - spin studio

# ---------- PR: Prop ----------
PR:
  - soccer ball
  - football
  - black and white ball
  - red and white ball
  - black panel
  - red panel
  - sports ball
  - the ball changes color
  - traditional ball

# ---------- S: Estilo ----------
S:
  - photorealistic
  - cinematic
  - editorial
  - documentary
  - studio lighting

# ---------- BANNED: Cross-platform always-banned in MAIN prompt ----------
# Estos NO se permiten nunca en el MAIN prompt (sí pueden ir en negative).
BANNED:
  - slow motion
  - dreamy slowmo
  - dreamy
  - cartoon
  - anime
  - 3D render
  - perfume ad
  - perfume ad aesthetic
  - plastic skin
  - smooth plastic
  - dreamlike
  - soft glow

# ---------- REQUIRED por caso ----------
# Keywords obligatorios cuando el caso aplica.
# Case 3a/3b/3c con sports broadcast (Regla 26 v6.0):
REQUIRED_SPORTS_BROADCAST:
  - 60fps
  - broadcast realism

# Negative prompt obligatorio en todos los casos:
NEGATIVE_PROMPT_REQUIRED:
  - negative

# ---------- ALLOWED motion/camera vocabulary (exento de baneo) ----------
# Si un término baneado aparece en proximidad (<50 chars) de uno de estos
# prefixes, se considera contexto de motion/cámara y NO se flaggea.
ALLOWED_MOTION_PREFIXES:
  - camera
  - shot
  - lens
  - framing
  - angle
  - view
  - perspective
  - pans
  - tilts
  - arcs
  - pulls
  - dollies
  - pushes
  - tracks
  - follows
  - swings
  - orbits
  - descends
  - rises

# ---------- REQUIRED_SECTIONS_BY_PLATFORM_CASE (NUEVO v1.1 2026-05-27) ----------
# Secciones obligatorias que debe contener el MAIN prompt para cada combinación
# de plataforma + caso. Cada sección tiene una lista de keyword patterns (case-insensitive,
# substring match). El linter considera la sección PRESENTE si AL MENOS UNO de los patterns
# matchea en el MAIN. Si una sección requerida no se detecta, es FAIL.
#
# Convención de keys: <platform>__<case>
# Si una combinación no está listada, el linter omite la validación de secciones
# y reporta WARN ("no required-sections snapshot for this platform+case — operate honor system").

REQUIRED_SECTIONS_BY_PLATFORM_CASE:

  # ====== Caso 1 — Génesis text-to-image ======
  gpt_image_2__1:
    subject:        [woman, man, person, subject, character, animal, dog, cat, building, object, group]
    action_or_pose: [standing, sitting, holding, walking, looking, running, leaning, resting, posing]
    environment:   [studio, gym, room, street, outdoor, indoor, landscape, forest, urban, beach, field]
    style:         [photorealistic, documentary, editorial, cinematic, candid, journalistic, naturalistic]
    camera_or_lens: [lens, mm, telephoto, wide angle, close-up, medium shot, full body, framing, shot]
    lighting:      [light, lighting, sunlight, daylight, tungsten, golden hour, soft light, backlit, rim light]
    anti_style:    [not illustration, not render, no stylization, no cartoon, no anime, photoreal]

  midjourney__1:
    subject:        [woman, man, person, subject, character, animal, object]
    style:          [photorealistic, cinematic, editorial, candid, documentary, --style]
    composition:    [composition, framing, rule of thirds, centered, off-center, shot]
    lighting:       [lighting, sunlight, daylight, tungsten, golden hour, soft light]
    aspect_ratio:   ["--ar", aspect ratio, 16:9, 9:16, 3:2, 2:3, 1:1]
    quality:        ["--v", "--style", "--q", "--stylize"]

  nano_banana_pro__1:
    subject:        [woman, man, person, subject, character, animal]
    action_or_pose: [standing, sitting, holding, walking, leaning, posing]
    environment:    [studio, gym, room, outdoor, indoor]
    style:          [photorealistic, documentary, editorial, candid]
    lighting:       [light, lighting, sunlight, tungsten, soft, golden hour]
    details:        [skin texture, fabric, fine detail, asymmetry, natural flaws, pores]

  # ====== Caso 2 — Imagen Ancla ======
  gpt_image_2__2:
    ref_roles:      [image 1, image 2, image 3, "ref:", reference image, ref 1, ref 2]
    subject_action: [holding, standing, sitting, walking, looking, posing, holding, performing]
    camera_or_lens: [lens, mm, telephoto, close-up, medium shot, framing]
    lighting:       [light, lighting, sunlight, tungsten, soft, daylight]
    style_consistency: [preserve, maintain, same style, consistent, exact]

  gpt_image_1_5__2:
    ref_roles:      [image 1, image 2, image 3, "ref:", reference image, face strip, ref 1]
    face_preservation: [preserve exact facial, preserve face, preserve identity, exact facial structure, eye shape, jawline, skin texture]
    subject_action: [holding, standing, sitting, performing, posing, walking]
    camera_or_lens: [lens, mm, telephoto, framing, medium shot, close-up]
    lighting:       [light, lighting, sunlight, soft, tungsten]

  nano_banana_pro__2:
    ref_roles:      [image 1, image 2, image 3, "ref:", reference]
    subject_action: [holding, standing, sitting, walking, posing]
    camera_or_lens: [lens, mm, framing, shot]
    lighting:       [light, lighting, sunlight, soft, tungsten]
    placement_anchor: [on the, at the, in the, beside, next to, between, in front of]

  # ====== Caso 3a — I2V FF only ======
  kling_3.0__3a:
    scene_or_motion: [scene, motion, movement, action, evolution, transition, glides, follows, arcs, travels, drifts]
    subject_action:  [she, he, the subject, the ball, the camera, the figure, lifts, turns, extends, rotates]
    camera:          [camera, shot, lens, angle, view, dollies, pans, tilts, arcs, pushes, holds]
    style:           [realism, cinematic, broadcast, documentary, photorealistic, naturalistic]
    anti_morphing:   [no morphing, anti-morph, smooth, stable, consistent, no warping]

  veo_3.1__3a:
    subject_action: [she, he, the subject, lifts, turns, extends, walks, runs, glides]
    timing_or_beat: [seconds, second, beat, gradually, slowly, quickly, over, during, then]
    camera:         [camera, shot, lens, angle, dollies, pans, tilts, tracks]
    style:          [realism, cinematic, photorealistic, 24fps, cinema, broadcast]
    physics_cue:    [gravity, momentum, weight, mass, falls, bounces, drops, follows, arc, trajectory]

  # ====== Caso 3b — I2V FF + LF ======
  kling_3.0__3b:
    scene_or_motion:  [scene, motion, transition, evolves, glides, travels, follows, transforms]
    transition_FF_LF: [from, into, to, through, evolves, transitions, becomes, settles, ends, arrives]
    camera:           [camera, shot, dollies, pans, tilts, arcs, holds, tracks]
    style:            [realism, broadcast, cinematic, photorealistic, documentary]
    anti_morphing:    [no morphing, smooth transition, stable, consistent, organic transition]

  veo_3.1__3b:
    transition_FF_LF: [from, into, to, through, evolves, transitions, becomes, then, settles]
    timing_or_beat:   [seconds, beat, gradually, then, over, during]
    camera:           [camera, shot, dollies, pans, tilts]
    physics_cue:      [gravity, momentum, weight, falls, arc, trajectory, lands]
    anti_morphing:    [no morphing, smooth, stable, consistent]

  # ====== Caso 3c — Motion control ======
  kling_3.0__3c:
    scene:                [scene, environment, setting, location, backdrop]
    motion_reference:     [motion reference, "@video", reference video, skeletal, pose ref, mocap]
    character_orientation: [orientation, facing, front-facing, character orientation, 人物朝向]
    camera:               [camera, shot, framing, angle, lens]

  # ====== Caso 4 — Video con diálogo ======
  veo_3.1__4:
    subject_action: [she, he, the subject, the speaker, says, speaks, talks]
    dialogue:       ['"', '"', "'", "'", says, speaking, dialogue]
    tone_or_accent: [tone, accent, voice, whispers, shouts, calmly, excitedly, authoritative, soft, deep]
    timing:         [seconds, beat, pauses, then, during, over]
    audio_specs:    [audio, ambient, music, sound, room tone, breath, footsteps, native audio]

  sora_2__4:
    subject_action: [she, he, the subject, says, speaks, performs]
    dialogue:       ['"', '"', says, speaking]
    tone_or_accent: [tone, accent, voice, whispers, shouts, calmly]
    timing:         [seconds, beat, then, over]
    audio_specs:    [audio, ambient, sound, native audio]

<!-- SOURCE_FILE_END: skills/aurora-prompt-linter/scripts/vocabularies.yaml -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/LICENSE -->
# SOURCE FILE: `skills/brand-lock-extractor/LICENSE`

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2026 Yuri Strohm / WhyStrohm

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/LICENSE -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/SKILL.md -->
# SOURCE FILE: `skills/brand-lock-extractor/SKILL.md`

---
name: brand-lock-extractor
description: Extract a production-ready brand-lock.md from a brand's existing assets. Point it at a website URL, a brand book PDF, screenshots, or a written description and it produces the nine-section brand-lock the rest of shotkit consumes, with a confidence and source noted for every value. Use when the user wants to onboard a brand, says "build a brand lock", "extract my brand", "make a brand pack from my site", or hands over brand assets. The cold-start killer that turns a blank brand-pack template into a filled, validate-ready file. Pairs with storyboard-architect downstream.
---

# Brand Lock Extractor

The blank `brand-packs/_template.md` is the single biggest point of friction in shotkit. Nobody wants to hand-author nine sections of brand parameters before they can produce a single storyboard. This skill removes that wall: hand it what you already have, get a filled brand-lock back.

The output is a `brand-lock.md` in the exact format `tools/validate_brand_lock.py` validates and every other skill consumes. Same file the pipeline reads, produced from your assets instead of from scratch.

This skill extracts. It does not invent. Every value is sampled from a real asset or flagged as an estimate the user must confirm. A confident-sounding wrong hex is worse than a flagged guess.

## When to use

Trigger when the user:

- Wants to onboard a brand into shotkit and has assets (a site, a brand book, screenshots)
- Says "extract my brand", "build a brand lock", "make a brand pack from my site/PDF"
- Hands over a URL, a PDF, image files, or a written brand description and asks for a brand-lock
- Has a brand-lock that is half-filled and wants the gaps extracted from assets

If the user has nothing but a vague idea (no assets, no description), they are not extracting, they are authoring. Point them at `brand-packs/_template.md` and help them fill it directly.

## Inputs

You can work from any one of these. More sources is a better extraction.

| Source | How you read it | Best for |
|---|---|---|
| Website URL | `WebFetch` homepage + about + one more page | Voice, positioning, palette, type |
| Brand book PDF | `Read` the PDF | Palette (exact hex), type, motion rules |
| Screenshots / image files | `Read` the images | Palette (sample pixels), mood, layout |
| Written description | Use directly | Identity, archetype, voice posture |

At minimum you need one source. If the user offers none, ask for the one they have: **"What can I work from, a website URL, a brand book PDF, screenshots, or a short description?"** One question.

## Workflow

### Step 1. Gather the source material

- **URL:** `WebFetch` the homepage, then try the about page (`/about`, `/about-us`, `/our-story`) and one more (`/services`, `/work`, recent blog). Skip pages that 404. The homepage is the floor.
- **PDF / images:** `Read` each file. Brand books carry exact hex and type; screenshots are for sampling color and reading mood.
- **Description:** take it as written.

Tell the user what you are pulling. Do not ask follow-ups yet, extract first, confirm gaps at the end.

### Step 2. Extract each section

Read `references/extraction-rubric.md`. It maps every brand-lock section to where the signal lives and how to read it. Work the nine sections in order:

1. **Identity** (brand, one-line description, archetype, voice posture)
2. **Palette** (sampled hex, by role)
3. **Typography** (display, body, optional mono, with weights)
4. **Mood adjectives** (3-5, specific, contrast clauses preferred)
5. **Never list** (what the brand avoids, inferred from consistency)
6. **Aspect ratios**
7. **Color grade direction** (one sentence)
8. **Motion language** (one paragraph)
9. **Voice rules** (copy-level constraints)

For every value, hold two things: the value, and where it came from (which asset, which quote, which sampled swatch). You will need the source for the confidence pass.

### Step 3. Assign confidence and flag estimates

Each value is one of:

- **extracted**, read directly from an asset (a hex in the brand book, a font in the CSS, a quote from the site). State it plainly.
- **inferred**, reasoned from evidence but not stated (archetype from positioning, never-list from consistency). Reasonable to ship, worth noting.
- **needs confirmation**, your best estimate where the assets were silent or ambiguous (a color sampled from a JPEG with compression, a font you could not identify). Fill it, then flag it.

### Step 4. Write the brand-lock

Use `templates/brand-lock.md.tpl`. Fill **every** required section, no placeholders left behind. Then append an `## Extraction notes` section that lists every `inferred` and `needs confirmation` value with its source and your reasoning. This section is the audit trail; it does not break validation (the validator checks the nine required sections are present, extra sections are fine).

Set the footer: `Last updated` to today, `Owner` to the user or "extracted", `Version: 1.0`.

### Step 5. Self-check, then hand off

Before you present it, confirm the file would pass validation:

- All nine required sections present: Identity, Palette, Typography, Mood adjectives, Never list, Aspect ratios, Color grade direction, Motion language, Voice rules.
- Identity contains all four fields: Brand, One-line description, Archetype, Voice posture.
- Palette has at least one real `#RRGGBB` hex (not a placeholder).

Then hand off:

> "Here is your brand-lock. I sampled the palette and type from your assets and flagged N values that need your eyes (see Extraction notes). Drop it in `brand-packs/`, confirm the flagged values, and run `python tools/validate_brand_lock.py path/to/file.md` to verify. Then: `'30-second explainer. Use brand-packs/your-brand.md as the brand lock.'`"

## Hard rules

### Rule 1. Never invent a hex value

Colors are sampled, never guessed. Read them from a brand book, from CSS, or by sampling pixels in a screenshot. If you genuinely cannot determine a color, fill your closest estimate and mark it `needs confirmation` in Extraction notes. "Navy" is not a palette entry. `#0F1F3A` is. A wrong hex stated confidently corrupts every downstream prompt.

### Rule 2. Never fabricate a typeface

Identify fonts from the brand book, the site's CSS/font files, or clear visual match. If you cannot identify one, say so and flag it, do not name a plausible-sounding font you did not verify.

### Rule 3. Source everything

Every extracted value traces to an asset. Every inferred value traces to reasoning. This is the same audit-trail discipline as the brand-lock snapshot, applied at extraction time.

### Rule 4. The never-list is the highest-value section

It is also the hardest to extract, because brands document what they do, not what they avoid. Infer it from consistency: if every image avoids stock-photo gloss, that is a never. If copy never uses exclamation points, that is a never. Read `references/extraction-rubric.md` for the method. Do not ship an empty never-list.

### Rule 5. Mood adjectives must be specific

"Professional, modern, clean" describes every brand and constrains nothing. Extract contrast clauses that do work: "operator not creator", "warm not precious", "confident without volume". If the assets only support generic adjectives, that is a `needs confirmation` flag, not a license to ship filler.

### Rule 6. No emojis, no hype

The output is a clinical specification. It models the standards the brand-lock enforces. No emojis anywhere. No marketing adjectives about the brand in your own voice, report what the assets show.

## Reference

- `references/extraction-rubric.md`, section-by-section extraction method and confidence definitions.

## Example

`examples/` contains a worked extraction: the source material provided (`input-brief.md`) and the `brand-lock.md` produced from it, including the Extraction notes audit trail. Use it to calibrate the level of specificity and the confidence flagging.

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/SKILL.md -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/brand-packs/README.md -->
# SOURCE FILE: `skills/brand-lock-extractor/brand-packs/README.md`

# Brand Packs

A brand pack is a single Markdown file that locks in palette, typography, voice, and visual rules for a project. The skills in this pack consume it. Every storyboard, every prompt, every generated frame inherits from it.

## How to use

1. Copy `_template.md` to a new file (e.g. `acme.md`)
2. Fill in every field. No placeholders left behind.
3. Reference it from your storyboard requests:

   > "30-second founder explainer. Use `brand-packs/acme.md` as the brand lock."

4. The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.

## How to write a good one

The template is a checklist, not a creative-writing exercise. Three rules:

**Be specific.** "Modern, clean, professional" is not a brand. "Calm, considered, operator energy, confident without shouting" is.

**Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.

**Be hex-precise.** Every color is a hex value. Every font is named. The skills consume structured data; vagueness here cascades into bad prompts later.

## Examples

The pack ships with two reference brand packs:

- **`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.
- **`examples/saas-clean.md`**. B2B SaaS, restrained, professional. Light backgrounds, single accent. Inter type stack. A neutral counterpoint to the WhyStrohm flagship.

More example brand packs will land in v2.0.0. PRs welcome.

## Generating a brand pack from existing assets

Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

> "Extract a brand-lock from acme.com" or "build a brand pack from this brand book PDF."

For bulk or programmatic extraction across many URLs, [media-tsunami](https://github.com/whystrohm/media-tsunami) (WhyStrohm's open-source brand voice extractor) scrapes URLs and produces a `brand-lock.md` in the same format.

## Versioning

Every storyboard run snapshots the brand pack it was built against. If you update `acme.md` later, previous storyboards still reference the version they were built on. This is intentional, the audit trail tells you exactly what brand state any given piece of content was built against.

When you make a brand-pack revision that materially changes look or voice, bump the `Version:` field at the bottom and note the change. e.g.:

```
Version: 1.1 (2026-05-12: switched accent from #D94F3A coral to #C44233 deeper coral)
```

## Contributing examples

PRs welcome for new brand-pack examples that fill gaps in the current set. Open an issue with the `brand-pack-request` template before submitting.

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/brand-packs/README.md -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/brand-packs/_template.md -->
# SOURCE FILE: `skills/brand-lock-extractor/brand-packs/_template.md`

# Brand Lock: {{BRAND_NAME}}

> Replace placeholders. Delete this blockquote when you're done.
> Every field below feeds into the storyboard pipeline. Be specific.

## Identity

**Brand:** {{BRAND_NAME}}
**One-line description:** What this brand actually does, who for.
**Archetype:** Operator / Creator / Sage / Rebel / Caregiver / Other
**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative

## Palette

Every hex value here is allowed. Anything outside this list is not.

| Role | Hex | Use |
|---|---|---|
| Background | `#______` | Primary canvas |
| Ink | `#______` | Primary text, dark elements |
| Accent | `#______` | Highlights, CTAs, brand pop |
| Muted | `#______` | Secondary text, captions |
| Rule | `#______` | Borders, dividers, subtle UI |

Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.

## Typography

**Display font:** `______`
**Body font:** `______`
**Mono font (optional):** `______`

Put the font name and weight in backticks immediately after the label, e.g.
`` **Display font:** `Inter Black 900`, headlines and hooks ``. The HTML preview and
the overlay-font check read that backticked value; anything before it is prose.

Two fonts max for production work. Three only if one is reserved for code/data.

## Mood adjectives

Pick 3–5. These flow into prompts as the brand's emotional posture.

- adjective_1
- adjective_2
- adjective_3

## Never list

What this brand never does, visually or tonally. Be specific.

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate
- never shout in copy
- never use clip-art icons
- (add more, the more specific, the better)

## Aspect ratios

Default: 16:9 / 9:16 / 1:1 / 4:5 / other

## Color grade direction

How footage and generated images should be graded. One sentence.

> e.g. "Warm filmic, muted teal shadows, slight grain. Reminiscent of Kodak Portra 400."

## Motion language

How motion behaves in this brand's content. One paragraph.

> e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

## Voice rules

Copy-level rules that apply to VO and on-screen text.

- e.g. no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no clichéd metaphors ("game-changing", "revolutionary", "next-level")
- no hype words

## Reference materials

Optional. Links to past work, mood boards, or style guides that further define the brand.

- Link to brand guide
- Link to past hero film
- Link to mood board

---

**Last updated:** YYYY-MM-DD
**Owner:** name / role
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/brand-packs/_template.md -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/brand-packs/examples/saas-clean.md -->
# SOURCE FILE: `skills/brand-lock-extractor/brand-packs/examples/saas-clean.md`

# Brand Lock: Acme SaaS (Example)

> Reference example for B2B SaaS brands. Restrained, professional, single-accent palette.

## Identity

**Brand:** Acme SaaS
**One-line description:** B2B platform that helps SaaS teams cut churn 40% in 90 days through customer health scoring and intervention workflows.
**Archetype:** Sage
**Voice posture:** Confident, data-driven, peer-to-peer (not vendor-to-buyer)

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#FFFFFF` | Pure white, primary canvas |
| Ink | `#0F1F3A` | Deep navy, primary text |
| Accent | `#3B82F6` | Bright blue. CTAs, data highlights |
| Muted | `#64748B` | Slate, secondary text, captions |
| Rule | `#E2E8F0` | Light gray, borders, dividers |
| Success | `#10B981` | Emerald, positive metrics, gains |
| Warning | `#F59E0B` | Amber, alerts, attention items |

## Typography

**Display font:** `Inter Bold 700`
**Body font:** `Inter Regular 400`
**Mono font:** `JetBrains Mono Regular`, for data, code, dashboards

## Mood adjectives

- credible
- precise
- helpful
- restrained
- expert

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never use illustrations of people (real photography or abstract data viz only)
- never use gradients (flat color only)
- never use rounded corners larger than 8px
- never use exclamation points
- never use vague claims ("the best", "industry-leading", "cutting-edge")
- never use AI/ML buzzwords without specifics
- never default to dark mode in primary marketing
- never use animated icons or lottie illustrations

## Aspect ratios

- 16:9, primary for product demos and hero films
- 9:16, short-form social
- 1:1. LinkedIn carousels

## Color grade direction

Clean, neutral, slight cool bias. White points pure white, blacks deep but not crushed. Skin tones natural. No filmic grain. Reminiscent of Apple keynote photography, clean, evenly lit, technically perfect.

## Motion language

Minimal motion. UI elements appear with subtle 200ms fade. Cuts on logic beats, not on time. Data visualizations animate with linear easing, no bounce, no overshoot. Camera moves limited to slow push on hero shots. No handheld, no whip pans, no transitions beyond hard cuts.

## Voice rules

- no em dashes
- no exclamation points
- no hype words
- prefer specific numbers ("40% reduction in 90 days" not "significant improvement")
- prefer "we" and "you" over "the company" and "the user"
- prefer present-tense
- never start a sentence with "Just" or "Simply"
- avoid corporate hedge language ("seek to", "look to", "aim to")

## Reference materials

- Vercel marketing, design language reference
- Linear marketing, voice and pacing reference
- Stripe Press, typography and density reference

---

**Last updated:** 2026-05-07
**Owner:** Example
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/brand-packs/examples/saas-clean.md -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/examples/brand-lock.md -->
# SOURCE FILE: `skills/brand-lock-extractor/examples/brand-lock.md`

# Brand Lock: Northwind Coffee Roasters

## Identity

**Brand:** Northwind Coffee Roasters
**One-line description:** Small-batch coffee, roasted and shipped the same morning, with full origin transparency, for people who want real coffee and no subscription to babysit.
**Archetype:** Maker, with a Rebel edge against pretension (frames the category's problem as cheap beans hidden behind burnt roasts and luxury pricing).
**Voice posture:** Plainspoken and confident. Short declaratives, dry, no decoration.

## Palette

Every hex value here is allowed. Anything outside this list is not.

| Role | Hex | Use |
|---|---|---|
| Background | `#F4EFE6` | Paper cream, primary canvas |
| Ink | `#2B2018` | Espresso brown, primary text and dark elements |
| Accent | `#C5562B` | Ember, highlights and CTAs |
| Muted | `#8A8076` | Stone, secondary text and captions |
| Rule | `#DCD3C4` | Borders and dividers |

## Typography

**Display font:** `Tiempos Headline Semibold`, serif
**Body font:** `Söhne Regular`, sans-serif, Medium for emphasis

## Mood adjectives

- plainspoken, not precious
- warm, not cozy-cute
- honest about origin
- unhurried

## Never list

- never use stock smiles or posed lifestyle photography
- never use latte art as decoration
- never use the word "artisanal"
- never use exclamation points
- never shoot glossy product-on-white; matte and natural-light only
- never lean on burnt, dark-roast cliche imagery

## Aspect ratios

Default: 4:5 and 9:16 for social, 16:9 for the web hero.

## Color grade direction

> Matte, low contrast, natural window light, warm but restrained. Reminiscent of Kinfolk editorial photography. Never glossy commercial product lighting.

## Motion language

> Minimal and unhurried. Static or slow push only. Cuts land on action, not on a timer. Type sets in place, it does not bounce or wobble. No fast cuts, no whip pans.

## Voice rules

- no exclamation points, anywhere
- never the word "artisanal" (or "curated", "elevated")
- short declarative sentences; cut adjectives before nouns that do not need them
- prefer specific origin claims (farm, region, roast date) over vague quality words
- no hype words ("best", "premium", "game-changing")

## Extraction notes

Audit trail for this extraction. Values not listed here were read directly from an asset (`extracted`): the four palette hex from the site CSS, both font names from the CSS, the never-list lines from the brand sheet, and the aspect ratios from the brand sheet.

**Inferred** (reasoned from evidence, reasonable to ship):
- Archetype "Maker / Rebel", from "we are roasters, not a lifestyle brand. The coffee does the talking" and the framing of competitors as burnt-cheap or overpriced.
- Mood adjectives, from the plainspoken homepage copy and the matte, natural-light photography described on the brand sheet.
- Color grade direction, inferred from the brand sheet's photography notes (matte, low-contrast, window light); no graded footage was provided.

**Needs confirmation** (best estimate, please verify):
- Rule color `#DCD3C4`, no divider/border color was given; estimated as a darker tint of the paper background. Confirm or replace.
- Font weights (Tiempos Headline Semibold, Söhne Regular/Medium), fonts are confirmed from CSS, weights are estimated from visual weight. Confirm against the brand book.
- Motion language, no motion assets were provided; this is a conservative default consistent with the Plainspoken/Confident posture. Confirm against any existing video.

---

**Last updated:** 2026-06-18
**Owner:** extracted
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/examples/brand-lock.md -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/examples/input-brief.md -->
# SOURCE FILE: `skills/brand-lock-extractor/examples/input-brief.md`

# Example input: what the user handed over

This is the raw source material for the worked extraction. The user provided a URL and a one-page brand sheet. The `brand-lock.md` in this folder is what the skill produced from it.

## Source 1: website (fetched)

**Homepage hero:**
> Northwind Coffee Roasters
> Small-batch coffee, roasted the morning it ships.
> No subscriptions to forget about. No bitter shortcuts. Just coffee that tastes like someone cared.

**About page excerpt:**
> We started Northwind in a one-car garage in Duluth because the coffee we could buy locally was either burnt to hide cheap beans or priced like a luxury good. We roast in small batches, ship the same day, and tell you exactly where the beans came from and who grew them. We are roasters, not a lifestyle brand. The coffee does the talking.

**CSS (from the page source):**
```
--paper: #F4EFE6;
--espresso: #2B2018;
--ember: #C5562B;
--stone: #8A8076;
font-family: "Tiempos Headline", Georgia, serif;   /* headings */
font-family: "Söhne", -apple-system, sans-serif;    /* body */
```

## Source 2: one-page brand sheet (read)

- Logo: wordmark only, espresso brown on paper cream. No icon.
- Photography: matte, low-contrast, natural window light. Beans, hands, kraft bags. Never glossy product-on-white.
- "We don't do: stock smiles, latte art as decoration, exclamation points, or the word 'artisanal'."
- Formats noted: Instagram (4:5 and 9:16), website hero (16:9).

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/examples/input-brief.md -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/references/extraction-rubric.md -->
# SOURCE FILE: `skills/brand-lock-extractor/references/extraction-rubric.md`

# Extraction rubric

How to read each brand-lock section out of real assets. For every section: where the signal lives, how to read it, and how to assign confidence.

## Confidence levels

Apply one to every value.

- **extracted**, read directly from an asset. A hex in the brand book PDF. A `font-family` in the site CSS. A verbatim quote from the homepage. Ship it plainly.
- **inferred**, reasoned from evidence, not stated. Archetype from how the brand frames problems. Never-list from what the assets consistently avoid. Ship it, note the reasoning.
- **needs confirmation**, a best estimate where assets were silent, compressed, or contradictory. A color sampled from a low-quality JPEG. A font you could not positively identify. Fill it so the file is complete, then flag it in Extraction notes.

## Identity

**Brand:** the name. Extracted from the logo, the title tag, or the description.

**One-line description:** what the brand does and who for. This is the load-bearing sentence; a generator implicitly references it on every prompt. Pull it from the hero headline plus the about page. Prefer concrete over abstract: "Managed bookkeeping for solo law firms" beats "Financial services for professionals." If the site only offers a vague tagline, sharpen it from the services/about copy and flag it `needs confirmation`.

**Archetype:** one word, Operator, Sage, Caregiver, Rebel, Creator, Jester, Ruler, Everyman, etc. Almost always `inferred`. Read it from how the brand frames the customer's problem:
- frames problems as systems to engineer -> Operator
- frames problems as questions to investigate -> Sage
- frames problems as people to support -> Caregiver
- frames problems as a status quo to break -> Rebel

**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative. Read from sentence length, punctuation, and word choice in the body copy. Short declaratives -> Sharp/Confident. Long, soft, second-person -> Warm. Cite a representative sentence.

## Palette

A table of `#RRGGBB` by role: Background, Ink, Accent, Muted, Rule, plus any brand-specific roles. Up to 8; past that the brand stops being recognizable.

How to get real hex:
- **Brand book PDF:** read the swatches directly. Highest confidence.
- **Website:** the CSS holds exact values (`background`, `color`, CSS custom properties like `--accent`). Highest confidence after a brand book.
- **Screenshots:** sample the dominant background, the text color, and the one or two accent colors. Compression shifts color slightly, so flag screenshot-sampled values `needs confirmation` unless they are clearly flat brand colors.

**Never guess a hex.** If you cannot read or sample one, estimate, label it `needs confirmation`, and tell the user exactly which role to verify. (See SKILL.md Rule 1.)

## Typography

Display font, body font, optional mono, each with weight (`Inter Black 900`, not `Inter Bold`).

- **Website:** `font-family` declarations and loaded font files (`fonts.googleapis.com`, `@font-face`, `.woff2` names) name the fonts exactly. Weights come from `font-weight`.
- **Brand book:** named directly.
- **Screenshots:** identify by eye only if confident; otherwise flag `needs confirmation`. Do not invent a plausible name (Rule 2).

Two fonts max; three only if one is mono for code/data.

## Mood adjectives

3-5 adjectives, specific, contrast clauses preferred. Read tone from the body copy and the imagery together.

Reject generic fillers ("professional, modern, clean"), they describe everything and constrain nothing. Push to contrast clauses that do work: "operator not creator", "warm not precious", "plainspoken not corporate". If the assets only support generic adjectives, flag `needs confirmation`. Cite the copy or image that supports each adjective.

## Never list

The hardest and most valuable section. Brands document what they do; you infer what they avoid from consistency across the assets.

Method, look for what is conspicuously absent:
- Imagery: no stock-photo gloss? no people? no gradients? no clip-art icons? Each absence is a never.
- Copy: no exclamation points? no hype words ("revolutionary", "game-changing")? no emojis? no questions in headlines? Each pattern is a never.
- Color/layout: never full-bleed photography? never more than one accent? never centered body text?

Turn each observed constraint into a `never` line. Be specific: "never use stock-photo aesthetic" beats "keep it authentic". Aim for 5+. Never ship an empty list (Rule 4).

## Aspect ratios

The ratios the brand renders for. Default to `9:16, 16:9, 1:1, 4:5`. If the assets reveal a bias (a vertical-only social brand, a cinematic 21:9 site hero), reflect it and note the evidence.

## Color grade direction

One sentence on how footage and generated images should be graded, with a reference point where possible (Kodak Portra 400, Apple keynote photography, A24 film grade). Infer from the existing photography's warmth, contrast, and saturation. If there is no photography to read, base it on the palette and flag `needs confirmation`.

## Motion language

One paragraph: camera moves, cut style, text animation, pacing. Read from any existing video or motion on the site; if there is none, infer a conservative default consistent with the voice posture (a Quiet/Authoritative brand -> minimal, slow, deliberate) and flag `needs confirmation`. Keep it to one coherent motion language, do not blend "minimal and deliberate" with "energetic whip pans".

## Voice rules

Copy-level constraints for VO and on-screen text. Many overlap the never-list but are phrased as authoring rules: "no em dashes", "sentences under 14 words", "prefer specific numbers over vague claims", "no exclamation points in headlines". Extract from observed copy patterns. These become prompt constraints downstream, so make them enforceable, not aspirational.

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/references/extraction-rubric.md -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/templates/brand-lock.md.tpl -->
# SOURCE FILE: `skills/brand-lock-extractor/templates/brand-lock.md.tpl`

# Brand Lock: {{BRAND_NAME}}

## Identity

**Brand:** {{BRAND_NAME}}
**One-line description:** {{what this brand does, who for, concrete}}
**Archetype:** {{Operator / Sage / Caregiver / Rebel / Creator / ...}}
**Voice posture:** {{Confident / Warm / Sharp / Quiet / Playful / Authoritative}}

## Palette

Every hex value here is allowed. Anything outside this list is not.

| Role | Hex | Use |
|---|---|---|
| Background | `#______` | Primary canvas |
| Ink | `#______` | Primary text, dark elements |
| Accent | `#______` | Highlights, CTAs, brand pop |
| Muted | `#______` | Secondary text, captions |
| Rule | `#______` | Borders, dividers, subtle UI |

## Typography

**Display font:** `{{font name + weight, e.g. Inter Black 900}}`
**Body font:** `{{font name + weight, e.g. Inter Medium 500}}`
**Mono font (optional):** `{{for code/data, or remove the line}}`

The font name goes in backticks, immediately after the label. Downstream tools read
that backticked value; prose before it is not parsed.

## Mood adjectives

- {{adjective, contrast clause preferred}}
- {{adjective}}
- {{adjective}}

## Never list

- {{what the brand never does, visually or tonally}}
- {{...}}
- {{...}}

## Aspect ratios

Default: {{16:9 / 9:16 / 1:1 / 4:5}}

## Color grade direction

> {{one sentence, with a reference point if possible}}

## Motion language

> {{one paragraph: camera moves, cut style, text animation, pacing}}

## Voice rules

- {{enforceable copy rule}}
- {{...}}

## Extraction notes

Audit trail for this extraction. Values not listed here were read directly from an asset (`extracted`).

**Inferred** (reasoned from evidence, reasonable to ship):
- {{value}}, {{reasoning + source}}

**Needs confirmation** (best estimate, please verify):
- {{value}}, {{why uncertain + which asset, what to check}}

---

**Last updated:** {{YYYY-MM-DD}}
**Owner:** {{name / role / "extracted"}}
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/templates/brand-lock.md.tpl -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/README.md -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/README.md`

# Tools

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

## Requirements

```bash
pip install pyyaml jsonschema
```

Standard library otherwise. No pandas, no numpy.

## Run everything

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

This is exactly what CI runs, so a green local run means a green PR.

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

## Repo checks

### `validate_skills.py`

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

```bash
python tools/validate_skills.py
```

### `validate_schemas.py`

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

```bash
python tools/validate_schemas.py
```

It validates schemas, not instances. For instances, see `validate_shots.py`.

### `validate_capabilities.py`

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

- every generator id has an adapter `.md` and every adapter `.md` has an entry
- no adapter advertises more words than its own `max_prompt_words` ceiling
- every adapter documents the `aspect_param` the matrix says to send
- no `notes` field cites a word count above its own ceiling
- warns when the matrix or an entry is past its 120-day freshness window

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

### `validate_brand_lock.py`

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

## Project checks

These run against a project's output directory, not the repo.

### `validate_shots.py`

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

### `validate_prompts.py`

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

### `validate_critique.py`

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

### `validate_provenance.py`

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

It catches, with a selftest for each:

- a frame regenerated after its critique (`image_sha256` no longer matches)
- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)
- a frame on disk with no critique for its round, never reviewed at all
- two critiques for the same shot in the same round, two operators colliding
- rounds that skip a number, or a critique whose `run_id` belongs to another run

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

## Rendering

### `shots-to-html.py`

Renders an output folder into a single `preview.html`.

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

### `copy-prompt.py`

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

## Internal modules

Not entry points. Imported by the tools above.

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.
- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

## Adding new tools

- Make it executable (`chmod +x`)
- Add a usage docstring at the top of the file
- Give it a `--selftest` that proves the check fires
- Document it in this README
- Wire it into `tools/check.sh`, which is what CI calls

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/README.md -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/_shotkit.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/_shotkit.py`

#!/usr/bin/env python3
"""
Shared helpers for the shotkit tools. Standard library only.

Everything here exists because more than one tool needs it. Hashing, brand-lock
parsing, and the capability-id list were duplicated or absent before; keeping one
copy is what stops the tools from disagreeing about what a brand-lock palette is
or which generator ids are real.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

CAPABILITIES_PATH = (
    REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters" / "_capabilities.json"
)

# Roles tools/shots-to-html.py maps onto CSS variables. Documented in
# docs/brand-lock-anatomy.md so a brand-lock author knows the names are load-bearing.
PALETTE_ROLES = ("background", "ink", "accent", "muted", "rule")

RUN_ID_RE = re.compile(r"^([0-9]{8}T[0-9]{6}Z)-[0-9a-f]{8}$")
ISO_INSTANT_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SHOT_ID_RE = re.compile(r"^shot_[0-9]{2,3}$")
TEXT_ID_RE = re.compile(r"^text_[0-9]{2,3}$")

HEX_RE = re.compile(r"#[0-9A-Fa-f]{6}")
PLACEHOLDER_HEX_RE = re.compile(r"#_{6}")

# | Role | `#RRGGBB` | Use | rows in a brand-lock Palette table.
PALETTE_ROW_RE = re.compile(
    r"^\|\s*([A-Za-z][A-Za-z0-9\s()/-]*?)\s*\|\s*`?(#(?:[0-9A-Fa-f]{6}|_{6}))`?\s*\|"
)

SNAPSHOT_TAKEN_RE = re.compile(r"<!--\s*snapshot taken:\s*(.+?)\s*-->")
SNAPSHOT_SOURCE_RE = re.compile(r"<!--\s*source:\s*(.+?)\s*-->")

IMAGE_EXTS = ("png", "jpg", "jpeg", "webp")


# --------------------------------------------------------------------------
# Hashing
# --------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    """SHA-256 of a file's bytes, read in chunks so large frames do not load whole."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    """SHA-256 of a string, UTF-8 encoded."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# Run identity
# --------------------------------------------------------------------------

def make_run_id(now: datetime | None = None, nonce: str | None = None) -> str:
    """Build a run_id. Pass `now` and `nonce` to make it reproducible in tests."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    if nonce is None:
        nonce = sha256_text(now.isoformat() + str(id(now)))[:8]
    return f"{stamp}-{nonce}"


def iso_instant(now: datetime | None = None) -> str:
    """UTC ISO-8601 to second precision with a trailing Z."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def run_id_timestamp(run_id: str) -> str | None:
    """Extract the compact timestamp from a run_id, or None if malformed."""
    m = RUN_ID_RE.match(run_id or "")
    return m.group(1) if m else None


# --------------------------------------------------------------------------
# JSON loading
# --------------------------------------------------------------------------

def load_json(path: Path) -> tuple[dict | list | None, str | None]:
    """Return (data, error). Exactly one of the two is None."""
    if not path.exists():
        return (None, f"file does not exist: {path}")
    try:
        return (json.loads(path.read_text(encoding="utf-8")), None)
    except json.JSONDecodeError as e:
        return (None, f"invalid JSON: {e}")
    except OSError as e:
        return (None, f"cannot read: {e}")


# --------------------------------------------------------------------------
# Capability matrix
# --------------------------------------------------------------------------

def capability_ids(caps_path: Path | None = None) -> set[str]:
    """Generator ids from the capability matrix. Empty set if it cannot be read."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return set()
    return {
        g["id"]
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


def capability_map(caps_path: Path | None = None) -> dict[str, dict]:
    """Generator id to its full capability entry."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return {}
    return {
        g["id"]: g
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


# --------------------------------------------------------------------------
# Brand-lock parsing
# --------------------------------------------------------------------------

def parse_palette(text: str) -> dict[str, str]:
    """Role (lowercased) to hex value, from a brand-lock Palette table."""
    palette: dict[str, str] = {}
    for line in text.splitlines():
        m = PALETTE_ROW_RE.match(line)
        if m:
            palette[m.group(1).strip().lower()] = m.group(2).strip()
    return palette


def palette_hexes(text: str) -> set[str]:
    """Every real (non-placeholder) hex in a brand-lock, lowercased."""
    return {h.lower() for h in HEX_RE.findall(text)}


def is_unconfigured(text: str) -> bool:
    """True when the brand-lock still carries template placeholders in its palette."""
    return bool(PLACEHOLDER_HEX_RE.search(text))


def parse_typography(text: str) -> dict[str, str | None]:
    """
    Pull font names out of a brand-lock Typography section.

    Matches the documented format:
        **Display font:** `Inter Black 900`, headline weight, ...
        **Body font:** `Inter Medium 500`, body copy, ...
        **Mono font:** `JetBrains Mono Regular`, code, data, ...

    Mono is optional. A brand-lock that declares one has three legal overlay fonts,
    not two, which is why the font check reads all three rather than assuming a pair.
    """
    out: dict[str, str | None] = {
        "display_font": None,
        "body_font": None,
        "mono_font": None,
    }
    # The value has to be backticked and sit immediately after the label. That is what
    # separates a real declaration from the template's instructional prose
    # ("**Display font:** font name, weights used (e.g. `Inter Black 900`)"), which
    # would otherwise resolve to the example font.
    for key, label in (
        ("display_font", "Display"),
        ("body_font", "Body"),
        ("mono_font", "Mono"),
    ):
        pattern = re.compile(
            r"^\*\*" + label + r"\s+font[^:*]*:?\*\*[ \t]*`([^`\n]+)`",
            re.IGNORECASE | re.MULTILINE,
        )
        m = pattern.search(text)
        if m:
            value = m.group(1).strip()
            if value and not value.startswith("_"):
                out[key] = value
    return out


def parse_snapshot_header(text: str) -> dict[str, str | None]:
    """The two provenance comments storyboard-architect writes at the top of a snapshot."""
    taken = SNAPSHOT_TAKEN_RE.search(text)
    source = SNAPSHOT_SOURCE_RE.search(text)
    return {
        "snapshot_taken": taken.group(1).strip() if taken else None,
        "source": source.group(1).strip() if source else None,
    }


# --------------------------------------------------------------------------
# Output-tree conventions
# --------------------------------------------------------------------------

def round_dirs(output_dir: Path, kind: str) -> list[tuple[int, Path]]:
    """
    Sorted (round_number, path) for output_dir/<kind>/round-N directories.

    `kind` is 'frames', 'critiques', or 'prompts'.
    """
    base = output_dir / kind
    if not base.is_dir():
        return []
    found: list[tuple[int, Path]] = []
    for child in base.iterdir():
        if child.is_dir() and child.name.startswith("round-"):
            suffix = child.name[len("round-"):]
            if suffix.isdigit():
                found.append((int(suffix), child))
    return sorted(found)


def find_frame(output_dir: Path, shot_id: str, round_no: int | None = None) -> Path | None:
    """
    Locate a frame for a shot by the path convention.

    Prefers the highest-numbered round under frames/, then falls back to the
    legacy flat generated/ directory so pre-3.0.0 projects still render.
    """
    candidates = round_dirs(output_dir, "frames")
    if round_no is not None:
        candidates = [(n, p) for n, p in candidates if n == round_no]
    for _, directory in reversed(candidates):
        for ext in IMAGE_EXTS:
            candidate = directory / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    legacy = output_dir / "generated"
    if legacy.is_dir():
        for ext in IMAGE_EXTS:
            candidate = legacy / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    return None


def critique_paths(output_dir: Path) -> list[Path]:
    """
    Every critique file in an output tree, newest layout first.

    New layout: critiques/round-N/shot_NN.critique.json
    Legacy:     critique.json at the output root
    """
    found: list[Path] = []
    for _, directory in round_dirs(output_dir, "critiques"):
        found.extend(sorted(directory.glob("*.critique.json")))
        found.extend(sorted(directory.glob("*.json")))
    legacy = output_dir / "critique.json"
    if legacy.exists():
        found.append(legacy)
    # Preserve order, drop duplicates from the two globs above.
    seen: set[Path] = set()
    unique: list[Path] = []
    for path in found:
        resolved = path.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(path)
    return unique


def as_overlay_ids(value) -> list[str]:
    """Normalise shots.json on_screen_text (null, string, or array) to a list."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []


def as_shot_ids(value) -> list[str]:
    """Normalise text-overlays.json shot_id (string or array) to a list."""
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/_shotkit.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/_template.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/_template.py`

#!/usr/bin/env python3
"""
The small template engine tools/shots-to-html.py renders preview.html.tpl with.

Only the subset the template actually uses is implemented, deliberately: variable
substitution, a loop, and a truthiness block. It exists so the CLI and the
storyboard-html-preview skill render the same structural template instead of two
hand-maintained copies that drift apart.

Supported syntax:
    {{name}}            HTML-escaped substitution
    {{{name}}}          raw substitution, for pre-built markup such as inlined CSS
    {{#each items}}     iterate a list of dicts; inside the block, keys resolve
    {{/each}}           against the item first, then the enclosing context
    {{#if name}}        render when the value is truthy
    {{/if}}

Unknown names render empty rather than raising, which keeps a partially populated
context from producing a traceback in front of a client.
"""

from __future__ import annotations

import html
import re

BLOCK_RE = re.compile(r"\{\{#(each|if)\s+([A-Za-z0-9_]+)\s*\}\}")
RAW_VAR_RE = re.compile(r"\{\{\{\s*([A-Za-z0-9_]+)\s*\}\}\}")
VAR_RE = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")


def escape(value) -> str:
    """HTML-escape a value for text and attribute contexts, including quotes."""
    if value is None or value is False:
        return ""
    if value is True:
        return "true"
    return html.escape(str(value), quote=True)


def _find_block_end(text: str, kind: str, start: int) -> int:
    """Index of the closing tag matching the block opened before `start`."""
    open_re = re.compile(r"\{\{#" + kind + r"\s+[A-Za-z0-9_]+\s*\}\}")
    close_tag = "{{/" + kind + "}}"
    depth = 1
    pos = start
    while depth:
        next_close = text.find(close_tag, pos)
        if next_close == -1:
            raise ValueError(f"unclosed {{{{#{kind}}}}} block")
        next_open = open_re.search(text, pos, next_close)
        if next_open:
            depth += 1
            pos = next_open.end()
            continue
        depth -= 1
        pos = next_close + len(close_tag)
    return pos


def render(template: str, context: dict) -> str:
    """Render `template` against `context`."""
    out: list[str] = []
    pos = 0

    while pos < len(template):
        block = BLOCK_RE.search(template, pos)
        if not block:
            out.append(_render_leaf(template[pos:], context))
            break

        out.append(_render_leaf(template[pos : block.start()], context))
        kind, name = block.group(1), block.group(2)
        body_start = block.end()
        block_end = _find_block_end(template, kind, body_start)
        close_len = len("{{/" + kind + "}}")
        body = template[body_start : block_end - close_len]

        value = context.get(name)
        if kind == "each":
            for item in value or []:
                scoped = dict(context)
                if isinstance(item, dict):
                    scoped.update(item)
                else:
                    scoped["this"] = item
                out.append(render(body, scoped))
        else:
            if value:
                out.append(render(body, context))

        pos = block_end

    return "".join(out)


def _render_leaf(text: str, context: dict) -> str:
    """Substitute variables in a chunk with no block tags left in it."""
    text = RAW_VAR_RE.sub(lambda m: str(context.get(m.group(1), "") or ""), text)
    return VAR_RE.sub(lambda m: escape(context.get(m.group(1))), text)

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/_template.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/check.sh -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/check.sh`

#!/usr/bin/env bash
# Run every shotkit check. This is what CI calls, so a green local run means a green PR.
#
# Usage:
#   ./tools/check.sh            # run everything, report a summary
#   ./tools/check.sh --quiet    # only print failures and the summary
#
# Requires: pip install pyyaml jsonschema

set -uo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.." || exit 1

PYTHON="${PYTHON:-python3}"
QUIET=0
[[ "${1:-}" == "--quiet" ]] && QUIET=1

PASSED=0
FAILED=0
FAILED_NAMES=()

run() {
  local label="$1"
  shift
  local output
  if output=$("$PYTHON" "$@" 2>&1); then
    PASSED=$((PASSED + 1))
    if [[ "$QUIET" == "0" ]]; then
      echo "PASS  ${label}"
      sed 's/^/      /' <<<"$output"
      echo
    else
      echo "PASS  ${label}"
    fi
  else
    FAILED=$((FAILED + 1))
    FAILED_NAMES+=("$label")
    echo "FAIL  ${label}"
    sed 's/^/      /' <<<"$output"
    echo
  fi
}

echo "shotkit checks, using $("$PYTHON" --version 2>&1)"
echo

# Preflight the two dependencies. Without this, a missing package turns one actionable
# line into fourteen identical failures and you have to read all of them to find out.
missing=""
"$PYTHON" -c 'import yaml' 2>/dev/null || missing="pyyaml"
"$PYTHON" -c 'import jsonschema' 2>/dev/null || missing="${missing:+$missing }jsonschema"
if [[ -n "$missing" ]]; then
  echo "Missing Python package(s): ${missing}" >&2
  echo >&2
  echo "  ${PYTHON} -m pip install ${missing}" >&2
  echo >&2
  echo "Then re-run ./tools/check.sh" >&2
  exit 1
fi

# Structure and schemas
run "skills: frontmatter"            tools/validate_skills.py
run "schemas: are valid schemas"     tools/validate_schemas.py

# Capability matrix, including prose parity with the adapter files
run "capabilities: selftest"         tools/validate_capabilities.py --selftest
run "capabilities: matrix"           tools/validate_capabilities.py

# Brand-locks: packs allow templates, snapshots do not
run "brand-lock: selftest"           tools/validate_brand_lock.py --selftest
run "brand-lock: packs"              tools/validate_brand_lock.py \
  brand-packs/_template.md \
  brand-packs/whystrohm.md \
  brand-packs/examples/saas-clean.md \
  skills/brand-lock-extractor/examples/brand-lock.md
run "brand-lock: snapshots"          tools/validate_brand_lock.py --snapshots

# Storyboard instances, the rules JSON Schema cannot express
run "shots: selftest"                tools/validate_shots.py --selftest
run "shots: bundled examples"        tools/validate_shots.py --examples
run "shots: worked run"              tools/validate_shots.py \
  skills/visual-asset-critic/examples/worked-run

# Prompt files: the forge's hard rules, including verbatim series_lock anchors
run "prompts: selftest"              tools/validate_prompts.py --selftest
run "prompts: worked run"            tools/validate_prompts.py --examples

# Critique gate
run "critique: selftest"             tools/validate_critique.py --selftest
run "critique: fixtures"             tools/validate_critique.py --examples

# Provenance chain
run "provenance: selftest"           tools/validate_provenance.py --selftest
run "provenance: worked run"         tools/validate_provenance.py --examples --require-accept

# Tools that ship as part of the workflow
run "preview renderer: selftest"     tools/shots-to-html.py --selftest
run "prompt helper: selftest"        tools/copy-prompt.py --selftest

echo "─────────────────────────────────────────"
echo "${PASSED} passed, ${FAILED} failed"
if ((FAILED)); then
  printf 'failed: %s\n' "${FAILED_NAMES[@]}"
  exit 1
fi
exit 0

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/check.sh -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/copy-prompt.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/copy-prompt.py`

#!/usr/bin/env python3
"""Copy a shot prompt from a shotkit prompts file to the system clipboard.

Handles both file shapes the forge writes: a full pass, and a revision file where each
shot block carries `# fix [...]` annotations above the prompt. Comment lines inside a
block are treated as annotations and never land in the clipboard, so what you paste
into a generator is the prompt and nothing else.

Usage:
  python tools/copy-prompt.py output/prompts/round-1/flux.txt
  python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
  python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
  python tools/copy-prompt.py --selftest
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

# A shot block opens with the shot id near the start of a comment line. The forge's
# revision format prefixes it, so both of these are headers:
#   # shot_03, reframe, 11.0-16.0s, MCU eye-level push
#   # shot_03, promise, 3.0-8.0s, MCU eye-level push, revision (was REVISE)
#   # Revision of shot_03 (was REVISE)
SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT_LINE = re.compile(r"^\s*#")


class Block:
    __slots__ = ("shot_id", "header", "annotations", "body")

    def __init__(self, shot_id: str, header: str) -> None:
        self.shot_id = shot_id
        self.header = header
        self.annotations: list[str] = []
        self.body: list[str] = []

    def prompt(self) -> str:
        return "\n".join(self.body).strip()

    def label(self) -> str:
        note = f"  [{len(self.annotations)} fix note(s)]" if self.annotations else ""
        return f"{self.header}{note}  ({len(self.prompt())} chars)"


def get_clipboard_command() -> list[str] | None:
    """Return the platform-appropriate clipboard command, or None if unavailable."""
    if sys.platform == "darwin":
        return ["pbcopy"]
    if sys.platform.startswith("linux"):
        if shutil.which("xclip"):
            return ["xclip", "-selection", "clipboard"]
        if shutil.which("xsel"):
            return ["xsel", "--clipboard", "--input"]
        return None
    if sys.platform == "win32":
        return ["clip"]
    return None


def parse_prompt_text(text: str) -> list[Block]:
    """Split a prompt file into shot blocks, separating annotations from prompt body."""
    blocks: list[Block] = []
    current: Block | None = None

    for line in text.splitlines():
        match = SHOT_HEADER.match(line)
        if match:
            current = Block(match.group(1), line.strip())
            blocks.append(current)
            continue
        if current is None:
            continue  # file-level header comments, before the first shot block
        if COMMENT_LINE.match(line):
            current.annotations.append(line.strip())
        else:
            current.body.append(line)

    return [b for b in blocks if b.prompt()]


def parse_prompt_file(path: Path) -> list[Block]:
    return parse_prompt_text(path.read_text(encoding="utf-8"))


def copy_to_clipboard(text: str) -> bool:
    cmd = get_clipboard_command()
    if not cmd:
        return False
    proc = subprocess.run(cmd, input=text.encode("utf-8"))
    return proc.returncode == 0


def print_clipboard_help() -> None:
    if sys.platform.startswith("linux"):
        print("No clipboard utility found. Install xclip or xsel.", file=sys.stderr)
    else:
        print("No clipboard utility found on this platform.", file=sys.stderr)


def list_blocks(blocks: list[Block]) -> None:
    for i, block in enumerate(blocks, 1):
        print(f"{i}. {block.label()}")
        for note in block.annotations:
            print(f"     {note}")


def select_interactively(blocks: list[Block]) -> Block | None:
    list_blocks(blocks)
    try:
        raw = input(f"\nWhich shot? (1-{len(blocks)}): ").strip()
        idx = int(raw) - 1
    except (ValueError, EOFError):
        print("Invalid selection.", file=sys.stderr)
        return None
    if not (0 <= idx < len(blocks)):
        print("Selection out of range.", file=sys.stderr)
        return None
    return blocks[idx]


STANDARD_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Aspect: 9:16

# shot_01, hook, 0.0-2.0s, MCU eye-level static
first prompt body

# shot_02, pain, 2.0-6.0s, MS eye-level push
second prompt body
"""

REVISION_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Round: 2
# Revision of round 1. Shots not listed here already passed.

# shot_02, pain, 2.0-6.0s, MCU eye-level push, revision (was REVISE)
# fix [Shot Spec, major]: framing MS -> MCU
# fix [Technical, re-roll]: hand was malformed
revised prompt body
"""

LEGACY_REVISION_FIXTURE = """\
# Revision of shot_03 (was REVISE)
# fix [Series Lock, major]: added 'salt-and-pepper hair' to the character anchor
legacy revised prompt body
"""


def selftest() -> int:
    ok = True

    cases = [
        ("standard file yields both shots", STANDARD_FIXTURE, ["shot_01", "shot_02"]),
        ("revision file yields its shot", REVISION_FIXTURE, ["shot_02"]),
        ("legacy revision header is tolerated", LEGACY_REVISION_FIXTURE, ["shot_03"]),
    ]
    for label, fixture, expected in cases:
        got = [b.shot_id for b in parse_prompt_text(fixture)]
        if got == expected:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> expected {expected}, got {got}")
            ok = False

    blocks = parse_prompt_text(REVISION_FIXTURE)
    body = blocks[0].prompt()
    if body == "revised prompt body":
        print("  ok    selftest: fix annotations stay out of the copied prompt")
    else:
        print(f"  FAIL  selftest: prompt body was {body!r}")
        ok = False
    if len(blocks[0].annotations) == 2:
        print("  ok    selftest: fix annotations are captured for display")
    else:
        print(f"  FAIL  selftest: expected 2 annotations, got {blocks[0].annotations}")
        ok = False

    header_only = parse_prompt_text("# Storyboard: x\n# Generator: flux\n")
    if header_only == []:
        print("  ok    selftest: a file with no shot blocks yields nothing")
    else:
        print(f"  FAIL  selftest: expected no blocks, got {header_only}")
        ok = False

    # The shipped worked run must be readable by this tool, both rounds.
    repo_root = Path(__file__).resolve().parent.parent
    worked = repo_root / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    for rel, expected in (
        ("prompts/round-1/flux.txt", ["shot_01", "shot_02"]),
        ("prompts/round-2/revised-flux.txt", ["shot_02"]),
    ):
        path = worked / rel
        if not path.exists():
            print(f"  FAIL  selftest: bundled fixture missing: {rel}")
            ok = False
            continue
        got = [b.shot_id for b in parse_prompt_file(path)]
        if got == expected:
            print(f"  ok    selftest: bundled {rel} parses")
        else:
            print(f"  FAIL  selftest: bundled {rel} -> expected {expected}, got {got}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Copy a shot prompt from a shotkit prompts file to the clipboard."
    )
    parser.add_argument(
        "file",
        nargs="?",
        type=Path,
        help="Path to a prompt file (e.g. output/prompts/round-1/flux.txt)",
    )
    parser.add_argument(
        "--shot", help="Shot ID to copy (e.g. shot_03). If omitted, prompts interactively."
    )
    parser.add_argument(
        "--list", action="store_true", help="List shots and exit. Does not copy."
    )
    parser.add_argument(
        "--selftest", action="store_true", help="Prove both file shapes parse"
    )
    args = parser.parse_args()

    if args.selftest:
        return selftest()
    if args.file is None:
        parser.error("file is required unless --selftest is given")

    if not args.file.exists():
        print(f"File not found: {args.file}", file=sys.stderr)
        return 1

    blocks = parse_prompt_file(args.file)
    if not blocks:
        print(f"No shot blocks found in {args.file}.", file=sys.stderr)
        print(
            "Expected a comment line naming a shot, e.g. "
            "'# shot_03, beat, timing, framing'.",
            file=sys.stderr,
        )
        return 1

    if args.list:
        list_blocks(blocks)
        return 0

    if args.shot:
        matches = [b for b in blocks if b.shot_id == args.shot]
        if not matches:
            print(f'Shot "{args.shot}" not found in {args.file}.', file=sys.stderr)
            print("Available shots:", file=sys.stderr)
            for block in blocks:
                print(f"  {block.shot_id}", file=sys.stderr)
            return 1
        if len(matches) > 1:
            print(
                f'Shot "{args.shot}" appears {len(matches)} times in {args.file}; '
                f"copying the last block.",
                file=sys.stderr,
            )
        selection = matches[-1]
    else:
        result = select_interactively(blocks)
        if result is None:
            return 1
        selection = result

    body = selection.prompt()
    if copy_to_clipboard(body):
        print(f"Copied {selection.shot_id} prompt to clipboard ({len(body)} chars).")
        for note in selection.annotations:
            print(f"  {note}")
        return 0

    print_clipboard_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/copy-prompt.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/shots-to-html.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/shots-to-html.py`

#!/usr/bin/env python3
"""
Standalone helper: render an output folder into a single preview.html.

Renders skills/storyboard-html-preview/templates/preview.html.tpl, the same
structural template the storyboard-html-preview skill uses, so the two cannot drift.
All interpolated content is HTML-escaped: subjects, rationales, and VO lines are
model-generated prose, and one angle bracket in a rationale used to break the page a
client was looking at.

Two timestamps, deliberately distinct. "Run" is when the storyboard was produced, read
from run.json. "Rendered" is when this page was written. Collapsing them into one
"Generated" date meant re-rendering a preview six months later silently restamped the
run as today.

Usage:
    python tools/shots-to-html.py path/to/output-folder
    python tools/shots-to-html.py path/to/output-folder --out preview.html
    python tools/shots-to-html.py path/to/output-folder --inline-images
    python tools/shots-to-html.py path/to/output-folder --rendered-at 2026-07-30T00:00:00Z
    python tools/shots-to-html.py --selftest
"""

from __future__ import annotations

import argparse
import base64
import sys
from pathlib import Path

from _shotkit import (
    IMAGE_EXTS,
    PALETTE_ROLES,
    REPO_ROOT,
    as_overlay_ids,
    find_frame,
    iso_instant,
    load_json,
    parse_palette,
    parse_typography,
    round_dirs,
    sha256_file,
)
from _template import escape, render

TEMPLATE_DIR = REPO_ROOT / "skills" / "storyboard-html-preview" / "templates"

FALLBACK_BRAND = {
    "bg": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
    "display_font": "Inter",
    "body_font": "Inter",
}

FALLBACK_HEX = {
    "background": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
}


def read_template(name: str) -> str:
    return (TEMPLATE_DIR / name).read_text(encoding="utf-8")


def parse_brand_lock(path: Path) -> tuple[dict, list[str]]:
    """
    Pull palette and typography out of a brand-lock.

    Returns (values, warnings). Warnings name every role that fell back to a generic
    default, because a preview that quietly renders in someone else's blue is worse
    than one that tells you the palette did not parse.
    """
    if not path.exists():
        return (dict(FALLBACK_BRAND), [f"brand-lock not found at {path.name}"])

    text = path.read_text(encoding="utf-8")
    palette = parse_palette(text)
    warnings: list[str] = []

    def pick(role: str) -> str:
        # Exact role first, then any role containing it, e.g. "accent (warm)".
        if role in palette and not palette[role].startswith("#_"):
            return palette[role]
        for name, hex_val in palette.items():
            if role in name and not hex_val.startswith("#_"):
                return hex_val
        warnings.append(
            f"palette role '{role}' not found in the brand-lock, using a generic default"
        )
        return FALLBACK_HEX[role]

    values = {
        "bg": pick("background"),
        "ink": pick("ink"),
        "accent": pick("accent"),
        "muted": pick("muted"),
        "rule": pick("rule"),
    }

    fonts = parse_typography(text)
    values["display_font"] = fonts.get("display_font") or FALLBACK_BRAND["display_font"]
    values["body_font"] = fonts.get("body_font") or FALLBACK_BRAND["body_font"]
    for key in ("display_font", "body_font"):
        if not fonts.get(key):
            warnings.append(
                f"brand-lock declares no {key.replace('_', ' ')}, using "
                f"{FALLBACK_BRAND[key]}"
            )

    return (values, warnings)


def aspect_class(aspect: str) -> str:
    return "aspect-" + str(aspect).replace(":", "-")


def encode_image_b64(path: Path) -> str:
    ext = path.suffix.lstrip(".").lower()
    mime = {
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
    }.get(ext, "image/png")
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def frame_for_shot(out_dir: Path, shot: dict) -> tuple[Path | None, str | None]:
    """
    Resolve a shot's frame, preferring what the data says over what the tree implies.

    Order: an accepted entry in shot.assets.generated, then the newest entry there,
    then the frames/round-N path convention, then the legacy generated/ directory.
    Returns (path, note) where note explains a non-obvious pick.
    """
    generated = (shot.get("assets") or {}).get("generated") or []
    accepted = [g for g in generated if g.get("accepted") is True and g.get("path")]
    pool = accepted or [g for g in generated if g.get("path")]
    if pool:
        chosen = max(pool, key=lambda g: g.get("round") or 0)
        path = out_dir / chosen["path"]
        if path.exists():
            note = None
            if chosen.get("sha256"):
                actual = sha256_file(path)
                if actual != chosen["sha256"]:
                    note = "frame has changed since it was recorded in shots.json"
            elif not accepted:
                note = "frame is not marked accepted"
            return (path, note)
        return (None, f"assets names {chosen['path']}, which is missing on disk")

    found = find_frame(out_dir, shot["id"])
    if found is None:
        return (None, None)
    return (found, None)


def latest_verdicts(out_dir: Path) -> dict[str, dict]:
    """Newest verdict per shot, read from the critique tree. Empty when there is none."""
    verdicts: dict[str, dict] = {}
    for round_no, directory in round_dirs(out_dir, "critiques"):
        for path in sorted(directory.glob("*.json")):
            data, err = load_json(path)
            if err or not isinstance(data, dict):
                continue
            shot_id = data.get("shot_id")
            if not shot_id:
                continue
            current = verdicts.get(shot_id)
            if current is None or round_no >= current["round"]:
                verdicts[shot_id] = {
                    "round": round_no,
                    "verdict": data.get("verdict"),
                }
    legacy, err = load_json(out_dir / "critique.json")
    if not err and isinstance(legacy, dict) and legacy.get("shot_id"):
        verdicts.setdefault(
            legacy["shot_id"],
            {"round": legacy.get("round") or 1, "verdict": legacy.get("verdict")},
        )
    return verdicts


def position_class(position) -> str:
    """Named positions map to a CSS class; explicit coordinates fall back to center."""
    if isinstance(position, str):
        return position
    return "center"


def position_label(position) -> str:
    if isinstance(position, dict):
        return f"x{position.get('x')}% y{position.get('y')}%"
    return str(position)


def build_context(out_dir: Path, args) -> tuple[dict, list[str]]:
    warnings: list[str] = []

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        raise SystemExit(f"ERROR: {err}")

    overlays_data, ov_err = load_json(out_dir / "text-overlays.json")
    if ov_err:
        overlays_data = {"overlays": []}
    overlays_by_id = {
        o["id"]: o for o in (overlays_data or {}).get("overlays", []) if o.get("id")
    }

    project = shots_data["project"]
    series = shots_data["series_lock"]
    shots = shots_data["shots"]
    aspect = project["aspect"]

    brand_ref = shots_data.get("brand_lock_ref") or "brand-lock.snapshot.md"
    brand_path = out_dir / brand_ref
    brand, brand_warnings = parse_brand_lock(brand_path)
    warnings.extend(brand_warnings)

    run_doc, run_err = load_json(out_dir / "run.json")
    if run_err or not isinstance(run_doc, dict):
        run_doc = {}
        warnings.append(
            "no run.json in this output tree, so the page cannot state when the run "
            "happened or which inputs it used"
        )

    verdicts = latest_verdicts(out_dir)
    provenance_notes: list[str] = []

    shot_contexts = []
    for shot in shots:
        frame_path, frame_note = frame_for_shot(out_dir, shot)
        if frame_note:
            provenance_notes.append(f"{shot['id']}: {frame_note}")
            warnings.append(f"{shot['id']}: {frame_note}")

        image_path = None
        if frame_path is not None:
            if args.inline_images:
                image_path = encode_image_b64(frame_path)
            else:
                try:
                    image_path = str(frame_path.relative_to(out_dir))
                except ValueError:
                    image_path = frame_path.name

        overlays = []
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            overlay = overlays_by_id.get(oid)
            if overlay is None:
                warnings.append(
                    f"{shot['id']} references overlay {oid}, which is not in "
                    f"text-overlays.json"
                )
                continue
            overlays.append(
                {
                    "id": overlay["id"],
                    "content": overlay.get("content"),
                    "font": overlay.get("font"),
                    "weight": overlay.get("weight"),
                    "color": overlay.get("color"),
                    "size": overlay.get("size"),
                    "position_class": position_class(overlay.get("position")),
                    "position_label": position_label(overlay.get("position")),
                    "enter_at": (overlay.get("enter") or {}).get("at"),
                    "enter_animation": (overlay.get("enter") or {}).get("animation"),
                    "exit_at": (overlay.get("exit") or {}).get("at"),
                    "exit_animation": (overlay.get("exit") or {}).get("animation"),
                }
            )

        verdict = verdicts.get(shot["id"])
        shot_contexts.append(
            {
                "id": shot["id"],
                "id_short": shot["id"].replace("shot_", ""),
                "beat": shot.get("beat"),
                "start": shot.get("start"),
                "end": shot.get("end"),
                "framing": shot.get("framing"),
                "angle": shot.get("angle"),
                "motion": shot.get("motion"),
                "depth_of_field": shot.get("depth_of_field"),
                "subject": shot.get("subject"),
                "vo": shot.get("vo"),
                "rationale": shot.get("rationale"),
                "aspect_class": aspect_class(aspect),
                "has_image": image_path is not None,
                "has_no_image": image_path is None,
                "image_path": image_path,
                "overlays": overlays,
                "has_overlays": bool(overlays),
                "has_verdict": verdict is not None,
                "verdict": (verdict or {}).get("verdict"),
                "verdict_round": (verdict or {}).get("round"),
                "verdict_class": str((verdict or {}).get("verdict", "")).lower(),
            }
        )

    css = (
        read_template("styles.css.tpl")
        .replace("{{BG_COLOR}}", brand["bg"])
        .replace("{{INK_COLOR}}", brand["ink"])
        .replace("{{ACCENT_COLOR}}", brand["accent"])
        .replace("{{MUTED_COLOR}}", brand["muted"])
        .replace("{{RULE_COLOR}}", brand["rule"])
        .replace("{{DISPLAY_FONT}}", brand["display_font"])
        .replace("{{BODY_FONT}}", brand["body_font"])
        .replace("{{INLINE_PRINT_CSS}}", read_template("print.css.tpl"))
    )

    brand_sha = sha256_file(brand_path) if brand_path.exists() else None
    recorded_sha = (run_doc.get("inputs") or {}).get("brand_lock_sha256")
    if brand_sha and recorded_sha and brand_sha != recorded_sha:
        provenance_notes.append(
            "the brand-lock on disk no longer matches the one recorded in run.json"
        )
        warnings.append(
            "brand-lock has changed since the run; this preview does not show the "
            "brand state the frames were produced against"
        )

    context = {
        "PROJECT_TITLE": project["title"],
        "DURATION": project["duration_s"],
        "ASPECT": aspect,
        "FRAMEWORK": project.get("framework") or "not specified",
        "SHOTS_VERSION": shots_data.get("version", "unknown"),
        "BRIEF": None,
        "SERIES_CHARACTER": series["character"],
        "SERIES_ENVIRONMENT": series["environment"],
        "SERIES_LIGHTING": series["lighting"],
        "SERIES_COLOR_GRADE": series["color_grade"],
        "BRAND_LOCK_REF": brand_ref,
        "BRAND_LOCK_SHA_SHORT": brand_sha[:12] if brand_sha else None,
        "RUN_ID": run_doc.get("run_id") or "not recorded",
        "RUN_CREATED_AT": run_doc.get("created_at") or "not recorded",
        "RENDERED_AT": args.rendered_at or iso_instant(),
        "PROVENANCE_NOTE": " ".join(provenance_notes) or None,
        "INLINE_CSS": css,
        "shots": shot_contexts,
    }
    return (context, warnings)


def selftest() -> int:
    """Render the bundled worked run twice and prove the output is byte-identical."""
    worked = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    ok = True

    class Args:
        inline_images = False
        rendered_at = "2026-07-30T00:00:00Z"

    first, _ = build_context(worked, Args())
    second, _ = build_context(worked, Args())
    html_a = render(read_template("preview.html.tpl"), first)
    html_b = render(read_template("preview.html.tpl"), second)

    if html_a == html_b:
        print("  ok    selftest: two renders with a pinned timestamp are identical")
    else:
        print("  FAIL  selftest: two renders differed")
        ok = False

    # shot_06 of the shotkit-explainer example carries two overlays. A renderer that
    # resolves only the first drops the second silently, which is what used to happen.
    explainer = (
        REPO_ROOT
        / "skills"
        / "storyboard-architect"
        / "examples"
        / "shotkit-explainer"
    )
    multi_ctx, _ = build_context(explainer, Args())
    shot_06 = next(s for s in multi_ctx["shots"] if s["id"] == "shot_06")
    multi_html = render(read_template("preview.html.tpl"), multi_ctx)

    checks = [
        ("escapes angle brackets", "<script>alert(1)</script>" not in render(
            "{{subject}}", {"subject": "<script>alert(1)</script>"}
        )),
        ("escapes quotes inside a style attribute", "&quot;" in render(
            '<span style="font-family: {{font}};">x</span>', {"font": '"><script>'}
        )),
        ("resolves every overlay on a multi-overlay shot", len(shot_06["overlays"]) == 2),
        (
            "renders every overlay on a multi-overlay shot",
            all(
                escape(overlay["content"]) in multi_html
                for overlay in shot_06["overlays"]
            ),
        ),
        ("states the run date, not the render date, in the header", "2026-07-30T14:23:00Z" in html_a),
        ("labels the render separately", "rendered 2026-07-30T00:00:00Z" in html_a),
        ("shows a verdict badge", "sb-verdict-accept" in html_a),
        ("uses the brand-lock ref from shots.json", 'href="brand-lock.snapshot.md"' in html_a),
        ("carries no unrendered template tags", "{{" not in html_a),
    ]
    for label, passed in checks:
        if passed:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    p = argparse.ArgumentParser(
        description="Render a shotkit output folder into a single preview.html."
    )
    p.add_argument(
        "output_dir",
        nargs="?",
        type=Path,
        help="Directory containing shots.json, text-overlays.json, run.json",
    )
    p.add_argument("--out", default="preview.html", help="Output filename, relative to output_dir")
    p.add_argument(
        "--inline-images",
        action="store_true",
        help="Embed frames as base64 so the file is portable on its own",
    )
    p.add_argument(
        "--rendered-at",
        help="Pin the render timestamp (UTC ISO-8601). Makes output reproducible.",
    )
    p.add_argument("--selftest", action="store_true", help="Prove the renderer's guarantees")
    args = p.parse_args()

    if args.selftest:
        return selftest()
    if args.output_dir is None:
        p.error("output_dir is required unless --selftest is given")

    out_dir: Path = args.output_dir
    if not out_dir.is_dir():
        print(f"ERROR: output directory not found: {out_dir}")
        return 1
    if not (out_dir / "shots.json").exists():
        print(f"ERROR: shots.json not found in {out_dir}")
        return 1

    context, warnings = build_context(out_dir, args)
    html_out = render(read_template("preview.html.tpl"), context)

    out_path = out_dir / args.out
    out_path.write_text(html_out, encoding="utf-8")
    print(f"  wrote {out_path}")
    for warn in warnings:
        print(f"  warn  {warn}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/shots-to-html.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/validate_brand_lock.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/validate_brand_lock.py`

#!/usr/bin/env python3
"""
Validate a brand-lock Markdown file.

Two modes, because a brand-pack and a snapshot are not the same artifact.

A brand-pack (brand-packs/*.md) is a source document. An unfilled template is a legal
brand-pack: that is what a template is for.

A snapshot (brand-lock.snapshot.md, written into an output tree) is a provenance
record. It has to carry the header storyboard-architect promises to write, and if it
still contains template placeholders then the run it governs was built against nothing.
Pass --snapshot to check those extra rules, and --require-configured to reject
placeholders outright.

Required headings (case-insensitive, in any order):
- Identity, Palette, Typography, Mood adjectives, Never list,
  Aspect ratios, Color grade direction, Motion language, Voice rules

Required identity fields (under ## Identity):
- Brand, One-line description, Archetype, Voice posture

Usage:
    python tools/validate_brand_lock.py path/to/brand-lock.md [...]
    python tools/validate_brand_lock.py --snapshot path/to/brand-lock.snapshot.md
    python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
    python tools/validate_brand_lock.py --snapshots            # every bundled snapshot
    python tools/validate_brand_lock.py --selftest
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from _shotkit import (
    ISO_INSTANT_RE,
    PALETTE_ROLES,
    REPO_ROOT,
    is_unconfigured,
    parse_palette,
    parse_snapshot_header,
    parse_typography,
)

REQUIRED_SECTIONS = {
    "identity",
    "palette",
    "typography",
    "mood adjectives",
    "never list",
    "aspect ratios",
    "color grade direction",
    "motion language",
    "voice rules",
}

REQUIRED_IDENTITY_FIELDS = {
    "brand",
    "one-line description",
    "archetype",
    "voice posture",
}

ISO_DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")


def parse_headings(text: str) -> list[tuple[int, str]]:
    """Return list of (level, heading_text_lower) for every Markdown heading."""
    out = []
    for line in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            out.append((len(m.group(1)), m.group(2).strip().lower()))
    return out


def extract_section(text: str, heading_lower: str) -> str:
    """Extract the body of a section by its heading. Empty string if not found."""
    lines = text.splitlines()
    in_section = False
    section_lines: list[str] = []
    section_level: int | None = None
    for line in lines:
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            level = len(m.group(1))
            heading = m.group(2).strip().lower()
            if not in_section:
                if heading == heading_lower:
                    in_section = True
                    section_level = level
                    continue
            else:
                if section_level is not None and level <= section_level:
                    break
        if in_section:
            section_lines.append(line)
    return "\n".join(section_lines)


def check_structure(text: str) -> list[str]:
    errors: list[str] = []
    heading_set = {h for _, h in parse_headings(text)}

    for missing in sorted(REQUIRED_SECTIONS - heading_set):
        errors.append(f"missing section: ## {missing.title()}")

    if "identity" in heading_set:
        identity_body = extract_section(text, "identity").lower()
        for field in sorted(REQUIRED_IDENTITY_FIELDS):
            if field not in identity_body:
                errors.append(f"identity section missing field: '{field}'")

    if "palette" in heading_set:
        palette_body = extract_section(text, "palette")
        if not re.search(r"#[0-9A-Fa-f]{6}|#_{6}", palette_body):
            errors.append(
                "palette section has no hex color values (or template placeholders)"
            )

    return errors


def check_roles(text: str) -> list[str]:
    """
    The palette role names the HTML preview maps onto CSS variables.

    A brand-lock is free to add rows, but a missing role means the preview silently
    renders that slot in a generic default, so it is worth saying out loud.
    """
    warnings: list[str] = []
    palette = parse_palette(text)
    for role in PALETTE_ROLES:
        if not any(role in name for name in palette):
            warnings.append(
                f"palette has no '{role}' role; the HTML preview will fall back to a "
                f"generic color for it"
            )
    return warnings


def check_typography(text: str) -> list[str]:
    warnings: list[str] = []
    fonts = parse_typography(text)
    for key, label in (("display_font", "Display"), ("body_font", "Body")):
        if not fonts.get(key):
            warnings.append(
                f"typography declares no {key.replace('_', ' ')} in a readable form; "
                f'expected ``**{label} font:** `Font Name Weight` `` with the name '
                f"backticked immediately after the label"
            )
    return warnings


def check_snapshot(text: str) -> tuple[list[str], list[str]]:
    """The provenance header storyboard-architect writes into every snapshot."""
    errors: list[str] = []
    warnings: list[str] = []
    header = parse_snapshot_header(text)

    taken = header["snapshot_taken"]
    if not taken:
        errors.append(
            "snapshot is missing its '<!-- snapshot taken: ... -->' header, so nothing "
            "records when this brand state was frozen"
        )
    elif ISO_INSTANT_RE.match(taken):
        pass
    elif ISO_DATE_RE.match(taken):
        warnings.append(
            f"snapshot taken '{taken}' is a date with no time; a full UTC instant "
            f"(YYYY-MM-DDThh:mm:ssZ) is what makes two runs on one day distinguishable"
        )
    else:
        errors.append(
            f"snapshot taken '{taken}' is not ISO-8601; expected YYYY-MM-DDThh:mm:ssZ"
        )

    if not header["source"]:
        errors.append(
            "snapshot is missing its '<!-- source: ... -->' header, so nothing records "
            "which brand-pack it was copied from"
        )

    return errors, warnings


def validate_brand_lock(
    path: Path, snapshot: bool = False, require_configured: bool = False
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    if not path.exists():
        return ([f"file does not exist: {path}"], [])

    text = path.read_text(encoding="utf-8")
    errors = check_structure(text)
    warnings = check_roles(text) + check_typography(text)

    unconfigured = is_unconfigured(text)
    if unconfigured:
        if require_configured or snapshot:
            errors.append(
                "palette still contains template placeholders (#______), so this is an "
                "unfilled template rather than a real brand-lock"
            )
        else:
            warnings.append(
                "palette contains template placeholders (#______); fine for a template, "
                "not for production work"
            )

    if snapshot:
        snap_errors, snap_warnings = check_snapshot(text)
        errors += snap_errors
        warnings += snap_warnings

    return (errors, warnings)


def selftest() -> int:
    ok = True
    minimal = "\n".join(
        [
            "## Identity",
            "**Brand:** X",
            "**One-line description:** Y",
            "**Archetype:** Operator",
            "**Voice posture:** Calm",
            "## Palette",
            "| Role | Hex | Use |",
            "|---|---|---|",
            "| Background | `#FFFFFF` | canvas |",
            "| Ink | `#000000` | text |",
            "| Accent | `#FF0000` | pop |",
            "| Muted | `#888888` | captions |",
            "| Rule | `#EEEEEE` | borders |",
            "## Typography",
            "**Display font:** `Inter Black 900`, headlines",
            "**Body font:** `Inter Medium 500`, body",
            "## Mood adjectives",
            "## Never list",
            "## Aspect ratios",
            "## Color grade direction",
            "## Motion language",
            "## Voice rules",
        ]
    )

    cases = [
        ("a complete brand-lock passes", minimal, {}, False),
        (
            "a snapshot with no header is rejected",
            minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot with a full instant header passes",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            False,
        ),
        (
            "a snapshot with a malformed date is rejected",
            "<!-- snapshot taken: last Tuesday -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot missing its source header is rejected",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "placeholders pass as a template",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {},
            False,
        ),
        (
            "placeholders fail under --require-configured",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {"require_configured": True},
            True,
        ),
        (
            "a missing section is caught",
            minimal.replace("## Voice rules", ""),
            {},
            True,
        ),
    ]

    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        for i, (label, text, kwargs, should_fail) in enumerate(cases):
            path = Path(tmp) / f"case-{i}.md"
            path.write_text(text, encoding="utf-8")
            errors, _ = validate_brand_lock(path, **kwargs)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        warn_path = Path(tmp) / "warn.md"
        warn_path.write_text(
            minimal.replace("| Muted | `#888888` | captions |", ""), encoding="utf-8"
        )
        _, warnings = validate_brand_lock(warn_path)
        if any("no 'muted' role" in w for w in warnings):
            print("  ok    selftest: a missing palette role warns")
        else:
            print(f"  FAIL  selftest: expected a muted-role warning, got {warnings}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_brand_lock.py <path-to-brand-lock.md> [...]")
        print("       python tools/validate_brand_lock.py --snapshot <snapshot.md>")
        print("       python tools/validate_brand_lock.py --require-configured <file>")
        print("       python tools/validate_brand_lock.py --snapshots")
        print("       python tools/validate_brand_lock.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    snapshot = "--snapshot" in args or "--snapshots" in args
    require_configured = "--require-configured" in args

    if "--snapshots" in args:
        paths = sorted(REPO_ROOT.rglob("brand-lock.snapshot.md"))
        if not paths:
            print("ERROR: no brand-lock.snapshot.md files found in the repo")
            return 1
    else:
        paths = [Path(a) for a in args if not a.startswith("--")]
        if not paths:
            print("ERROR: no brand-lock files given")
            return 2

    label = "snapshot" if snapshot else "brand-lock"
    print(f"Validating {len(paths)} {label} file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_brand_lock(path, snapshot, require_configured)
        try:
            shown = path.relative_to(REPO_ROOT)
        except ValueError:
            shown = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {shown}: {warn}")

    print()
    if total_errors == 0:
        print(f"All {label} files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across {label} files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/validate_brand_lock.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/validate_capabilities.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/validate_capabilities.py`

#!/usr/bin/env python3
"""
Validate the generator capability matrix and the adapter prose that defers to it.

_capabilities.json is declared the single source of truth for per-generator limits,
and every adapter .md repeats that rule at the top. A rule nothing checks is a
suggestion: the matrix and the prose drifted in three places before this file grew
the parity checks below.

Five checks:
  1. _capabilities.json validates against capabilities.schema.json.
  2. File parity: every generator id has an adapter .md and every adapter .md has a
     generator entry. Non-adapter markdown is skipped by name, not treated as an
     adapter with a missing entry.
  3. Prose parity: the word budget an adapter .md advertises must fit inside that
     generator's max_prompt_words, and the .md must mention the aspect_param the
     matrix says to send. A generator whose documented parameter name disagrees with
     the matrix will be called with the wrong one, because the matrix wins.
  4. Self-consistency: a notes field must not cite a word count above its own
     max_prompt_words.
  5. Staleness: warns when the matrix or an entry is past the freshness window.

Run from repo root:
    python tools/validate_capabilities.py
    python tools/validate_capabilities.py --selftest
"""

from __future__ import annotations

import re
import sys
from datetime import date

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, load_json

ADAPTERS_DIR = REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters"
CAPS = ADAPTERS_DIR / "_capabilities.json"
CAPS_SCHEMA = ADAPTERS_DIR / "capabilities.schema.json"

# Re-verify the matrix at least this often. Generator models change monthly.
STALE_AFTER_DAYS = 120

# Markdown in adapters/ that documents the directory rather than a generator.
NON_ADAPTER_STEMS = {"README", "_README"}

# "**80-150 words**", "**40-80 words per prompt**", en dash or hyphen.
WORD_RANGE_RE = re.compile(r"\*\*\s*(\d+)\s*[-–—]\s*(\d+)\s+words[^*]*\*\*")
# "**up to 150 words**" or "**150 words**"
WORD_SINGLE_RE = re.compile(r"\*\*\s*(?:up to\s+)?(\d+)\s+words[^*]*\*\*")
# A bare word count inside a notes string, e.g. "Over 100 words underperforms."
NOTES_WORD_RE = re.compile(r"(\d+)\s+words")


def _parse_date(value: str) -> date | None:
    try:
        y, m, d = (int(p) for p in value.split("-"))
        return date(y, m, d)
    except (ValueError, AttributeError):
        return None


def adapter_word_bound(text: str) -> int | None:
    """Highest word count the adapter prose advertises, or None if it names none."""
    bounds: list[int] = []
    for m in WORD_RANGE_RE.finditer(text):
        bounds.append(max(int(m.group(1)), int(m.group(2))))
    if not bounds:
        for m in WORD_SINGLE_RE.finditer(text):
            bounds.append(int(m.group(1)))
    return max(bounds) if bounds else None


def check_prose_parity(entry: dict, text: str) -> tuple[list[str], list[str]]:
    """Compare one adapter .md against its capability entry."""
    errors: list[str] = []
    warnings: list[str] = []
    gid = entry["id"]

    bound = adapter_word_bound(text)
    if bound is None:
        warnings.append(
            f"prose: '{gid}.md' advertises no word budget, so the matrix value "
            f"({entry['max_prompt_words']}) is the only guidance a reader gets"
        )
    elif bound > entry["max_prompt_words"]:
        errors.append(
            f"prose: '{gid}.md' advertises up to {bound} words but the matrix caps "
            f"max_prompt_words at {entry['max_prompt_words']}"
        )

    aspect = entry["aspect_param"]
    if aspect not in text:
        errors.append(
            f"prose: '{gid}.md' never mentions aspect_param '{aspect}'. The matrix "
            f"wins, so the forge will send a parameter the adapter does not document"
        )

    notes = entry.get("notes") or ""
    for m in NOTES_WORD_RE.finditer(notes):
        cited = int(m.group(1))
        if cited > entry["max_prompt_words"]:
            warnings.append(
                f"self-consistency: '{gid}' notes cite {cited} words but "
                f"max_prompt_words is {entry['max_prompt_words']}"
            )

    return errors, warnings


def validate(today: date | None = None) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    errors: list[str] = []
    warnings: list[str] = []
    today = today or date.today()

    if not CAPS.exists():
        return ([f"missing {CAPS.relative_to(REPO_ROOT)}"], warnings)
    if not CAPS_SCHEMA.exists():
        return ([f"missing {CAPS_SCHEMA.relative_to(REPO_ROOT)}"], warnings)

    caps, caps_err = load_json(CAPS)
    if caps_err:
        return ([f"_capabilities.json: {caps_err}"], warnings)
    schema, schema_err = load_json(CAPS_SCHEMA)
    if schema_err:
        return ([f"capabilities.schema.json: {schema_err}"], warnings)

    # 1. Schema validation
    validator = Draft202012Validator(schema)
    for err in sorted(validator.iter_errors(caps), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # structure-dependent checks need a valid shape

    entries = {g["id"]: g for g in caps["generators"]}
    cap_ids = set(entries)
    md_ids = {
        p.stem
        for p in ADAPTERS_DIR.glob("*.md")
        if p.stem not in NON_ADAPTER_STEMS
    }

    # 2. File parity
    for missing_md in sorted(cap_ids - md_ids):
        errors.append(
            f"parity: capability id '{missing_md}' has no adapter file {missing_md}.md"
        )
    for missing_cap in sorted(md_ids - cap_ids):
        errors.append(
            f"parity: adapter '{missing_cap}.md' has no entry in _capabilities.json"
        )

    # 3 and 4. Prose parity and self-consistency
    for gid in sorted(cap_ids & md_ids):
        text = (ADAPTERS_DIR / f"{gid}.md").read_text(encoding="utf-8")
        prose_errors, prose_warnings = check_prose_parity(entries[gid], text)
        errors.extend(prose_errors)
        warnings.extend(prose_warnings)

    # 5. Staleness
    reviewed = _parse_date(caps.get("matrix_last_reviewed", ""))
    if reviewed is None:
        warnings.append("matrix_last_reviewed is not a parseable date")
    elif (today - reviewed).days > STALE_AFTER_DAYS:
        warnings.append(
            f"matrix_last_reviewed is {(today - reviewed).days} days old "
            f"(> {STALE_AFTER_DAYS}); re-verify the matrix"
        )
    for g in caps["generators"]:
        lv = _parse_date(g.get("last_verified", ""))
        if lv is not None and (today - lv).days > STALE_AFTER_DAYS:
            warnings.append(
                f"'{g['id']}' last_verified is {(today - lv).days} days old "
                f"(> {STALE_AFTER_DAYS}); re-verify this generator"
            )

    return (errors, warnings)


def selftest() -> int:
    ok = True

    cases = [
        (
            "prose advertising more words than the cap is caught",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-300 words** comfortably. Pass `size` alongside.",
            True,
        ),
        (
            "prose inside the cap passes",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-250 words** comfortably. Pass `size` alongside.",
            False,
        ),
        (
            "an undocumented aspect_param is caught",
            {
                "id": "x",
                "max_prompt_words": 120,
                "aspect_param": "aspect_ratio",
                "notes": "",
            },
            "Handles **60-120 words**. Pass `aspectRatio` as a parameter.",
            True,
        ),
        (
            "en dash ranges parse",
            {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": ""},
            "Aim for **40–80 words per prompt** including `--ar`.",
            False,
        ),
    ]
    for label, entry, text, should_error in cases:
        errors, _ = check_prose_parity(entry, text)
        if bool(errors) == should_error:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
            ok = False

    entry = {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": "Over 100 words underperforms."}
    _, warnings = check_prose_parity(entry, "Aim for **40-80 words** with `--ar`.")
    if any("self-consistency" in w for w in warnings):
        print("  ok    selftest: notes citing more words than the cap are flagged")
    else:
        print(f"  FAIL  selftest: expected a self-consistency warning, got {warnings}")
        ok = False

    if adapter_word_bound("no budget stated here") is None:
        print("  ok    selftest: prose with no word budget reports none")
    else:
        print("  FAIL  selftest: found a word budget where there is none")
        ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    if "--selftest" in sys.argv[1:]:
        return selftest()

    print(f"Validating capability matrix: {CAPS.relative_to(REPO_ROOT)}")
    print()

    errors, warnings = validate()

    for w in warnings:
        print(f"  warn  {w}")
    if warnings:
        print()

    if not errors:
        caps, _ = load_json(CAPS)
        count = len((caps or {}).get("generators", []))
        print(f"Capability matrix valid ({count} generators, {len(warnings)} warning(s)).")
        return 0

    for e in errors:
        print(f"  FAIL  {e}")
    print()
    print(f"FAILED: {len(errors)} error(s) in capability matrix.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/validate_capabilities.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/validate_critique.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/validate_critique.py`

#!/usr/bin/env python3
"""
Validate critique.json files against the critique schema AND the gating invariant.

Schema validation alone is not enough: JSON Schema cannot express the cross-field
rules that make a verdict trustworthy. This validator adds them.

Gating invariant (the reason structured output exists):
  - Any 'blocking' issue      => verdict MUST be REJECT.
  - Three or more 'major'     => verdict MUST be REJECT.
  - One or two 'major'        => verdict MUST NOT be ACCEPT (caps at REVISE).
  - Therefore ACCEPT requires zero major/blocking issues.

Provenance invariant (version 1.1 and later):
  - A hash without its path, or a path without its hash, is not a reference.
  - image_ref must be present and non-null: a verdict about no image is not a verdict.
  - HIGH confidence requires the shot spec, the brand-lock, and the prompt to all be
    identified. The critic's own rubric says HIGH means all three were available.
  - generator, when named, must be an id in the capability matrix.

A critique that claims ACCEPT while carrying a blocking issue passes the schema but
FAILS here. So does a 1.1 critique that records an image hash and no image path.

Usage:
    python tools/validate_critique.py path/to/critique.json [...]
    python tools/validate_critique.py path/to/output-dir      # every critique in the tree
    python tools/validate_critique.py --examples              # bundled fixtures
    python tools/validate_critique.py --selftest              # prove the gates fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, capability_ids, critique_paths, load_json

SCHEMA_PATH = (
    REPO_ROOT / "skills" / "visual-asset-critic" / "templates" / "critique.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "visual-asset-critic" / "examples"

MAJOR_REJECT_THRESHOLD = 3

# Pairs that must be present or absent together.
REF_HASH_PAIRS = (
    ("image_ref", "image_sha256"),
    ("brand_lock_ref", "brand_lock_sha256"),
    ("prompt_ref", "prompt_sha256"),
)


def _load_schema() -> dict:
    data, err = load_json(SCHEMA_PATH)
    if err:
        raise RuntimeError(err)
    return data


def check_gating(data: dict) -> list[str]:
    """The severity-to-verdict invariant. Assumes data is schema-valid."""
    errors: list[str] = []
    verdict = data.get("verdict")
    severities = [issue.get("severity") for issue in data.get("issues", [])]
    majors = severities.count("major")

    if "blocking" in severities and verdict != "REJECT":
        errors.append(
            f"gating: a 'blocking' issue requires verdict REJECT, got '{verdict}'"
        )
    if majors >= MAJOR_REJECT_THRESHOLD and verdict != "REJECT":
        errors.append(
            f"gating: {majors} 'major' issues require verdict REJECT "
            f"(threshold {MAJOR_REJECT_THRESHOLD}), got '{verdict}'"
        )
    if majors and verdict == "ACCEPT":
        errors.append(
            "gating: a 'major' issue caps the verdict at REVISE; ACCEPT is not allowed"
        )
    return errors


def check_provenance(data: dict, known_generators: set[str]) -> list[str]:
    """The provenance invariant. Only applies from version 1.1."""
    errors: list[str] = []
    if data.get("version") == "1.0":
        return errors

    for ref_key, hash_key in REF_HASH_PAIRS:
        ref, digest = data.get(ref_key), data.get(hash_key)
        if ref and not digest:
            errors.append(f"provenance: {ref_key} is set but {hash_key} is null")
        if digest and not ref:
            errors.append(f"provenance: {hash_key} is set but {ref_key} is null")

    if not data.get("image_ref"):
        errors.append(
            "provenance: image_ref is null; a verdict that names no image cannot be audited"
        )

    if data.get("confidence") == "HIGH":
        missing = [
            key
            for key in ("shot_id", "brand_lock_ref", "prompt_ref")
            if not data.get(key)
        ]
        if missing:
            errors.append(
                "provenance: confidence HIGH requires "
                + ", ".join(missing)
                + " to be identified"
            )

    generator = data.get("generator")
    if generator and known_generators and generator not in known_generators:
        errors.append(
            f"provenance: generator '{generator}' is not an id in the capability matrix"
        )

    return errors


def validate_doc(
    data: dict,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes every gate."""
    errors: list[str] = []
    warnings: list[str] = []

    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # the gates assume a schema-valid shape

    errors += check_gating(data)
    errors += check_provenance(data, known_generators or set())

    if data.get("version") == "1.0":
        warnings.append(
            "version 1.0 carries no run id, no round, and no content hashes, so the "
            "verdict cannot be tied to the bytes it reviewed; re-emit as 1.1"
        )

    return (errors, warnings)


def validate_path(
    path: Path,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    data, err = load_json(path)
    if err:
        return ([err], [])
    if not isinstance(data, dict):
        return ([f"top level is not an object: {path}"], [])
    return validate_doc(data, validator, known_generators)


def _selftest_cases() -> list[tuple[str, dict, bool]]:
    """(label, document, should_pass)."""
    base_provenance = {
        "run_id": "20260730T142300Z-9f2c1ab4",
        "round": 1,
        "created_at": "2026-07-30T14:31:00Z",
        "shot_id": "shot_03",
        "brand_lock_ref": "brand-lock.snapshot.md",
        "brand_lock_sha256": "a" * 64,
        "image_ref": "frames/round-1/shot_03.png",
        "image_sha256": "b" * 64,
        "prompt_ref": "prompts/round-1/flux.txt",
        "prompt_sha256": "c" * 64,
        "generator": "flux",
        "model_version": "2 Pro",
        "seed": 12345,
    }
    major_issue = {
        "layer": "Series Lock",
        "severity": "major",
        "note": "hair mismatch",
        "fix_type": "prompt-level",
        "fix": "add 'salt-and-pepper hair' to the anchor",
    }
    blocking_issue = {
        "layer": "Brand Lock",
        "severity": "blocking",
        "note": "off-palette",
        "fix_type": "re-roll",
        "fix": "re-roll with palette anchor",
    }

    def doc(**overrides) -> dict:
        out = {
            "version": "1.1",
            **base_provenance,
            "verdict": "REVISE",
            "confidence": "HIGH",
            "issues": [dict(major_issue)],
        }
        out.update(overrides)
        return out

    return [
        ("clean REVISE with full provenance passes", doc(), True),
        (
            "legacy 1.0 document still validates",
            {
                "version": "1.0",
                "verdict": "REVISE",
                "confidence": "HIGH",
                "issues": [dict(major_issue)],
            },
            True,
        ),
        (
            "ACCEPT with a blocking issue is rejected",
            doc(verdict="ACCEPT", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "REVISE with a blocking issue is rejected",
            doc(verdict="REVISE", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "ACCEPT with a major issue is rejected",
            doc(verdict="ACCEPT"),
            False,
        ),
        (
            "three major issues cannot stay at REVISE",
            doc(verdict="REVISE", issues=[dict(major_issue) for _ in range(3)]),
            False,
        ),
        (
            "three major issues at REJECT pass",
            doc(verdict="REJECT", issues=[dict(major_issue) for _ in range(3)]),
            True,
        ),
        (
            "1.1 with a hash and no path is rejected",
            doc(prompt_ref=None),
            False,
        ),
        (
            "1.1 with a path and no hash is rejected",
            doc(prompt_sha256=None),
            False,
        ),
        (
            "1.1 with no image_ref is rejected",
            doc(image_ref=None, image_sha256=None),
            False,
        ),
        (
            "HIGH confidence with no prompt identified is rejected",
            doc(prompt_ref=None, prompt_sha256=None),
            False,
        ),
        (
            "MEDIUM confidence with no prompt identified passes",
            doc(confidence="MEDIUM", prompt_ref=None, prompt_sha256=None),
            True,
        ),
        (
            "unknown generator id is rejected",
            doc(generator="runway-sora"),
            False,
        ),
        (
            "1.1 missing a required provenance field is rejected",
            {
                "version": "1.1",
                "verdict": "ACCEPT",
                "confidence": "LOW",
                "issues": [],
            },
            False,
        ),
    ]


def selftest() -> int:
    validator = Draft202012Validator(_load_schema())
    known = capability_ids() or {"flux"}
    ok = True

    for label, document, should_pass in _selftest_cases():
        errors, _ = validate_doc(document, validator, known)
        passed = not errors
        if passed == should_pass:
            print(f"  ok    selftest: {label}")
        else:
            detail = errors if errors else ["(no errors raised)"]
            print(f"  FAIL  selftest: {label} -> {detail}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def _collect(args: list[str]) -> list[Path] | None:
    if "--examples" in args:
        found = sorted(EXAMPLES_DIR.glob("*.json"))
        found += critique_paths(EXAMPLES_DIR / "worked-run")
        return found or None

    paths: list[Path] = []
    for raw in args:
        path = Path(raw)
        if path.is_dir():
            found = critique_paths(path)
            if not found:
                print(f"  FAIL  {raw}")
                print("        - no critique files found in this output tree")
                return None
            paths.extend(found)
        else:
            paths.append(path)
    return paths


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_critique.py <critique.json|output-dir> [...]")
        print("       python tools/validate_critique.py --examples")
        print("       python tools/validate_critique.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    if not SCHEMA_PATH.exists():
        print(f"ERROR: schema not found at {SCHEMA_PATH}")
        return 1

    paths = _collect(args)
    if paths is None:
        return 1

    validator = Draft202012Validator(_load_schema())
    known = capability_ids()

    print(f"Validating {len(paths)} critique file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_path(path, validator, known)
        try:
            label = path.relative_to(REPO_ROOT)
        except ValueError:
            label = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {label}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {label}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {label}: {warn}")

    print()
    if total_errors == 0:
        print(f"All critiques valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across critiques.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/validate_critique.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/validate_prompts.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/validate_prompts.py`

#!/usr/bin/env python3
"""
Validate the prompt files visual-prompt-forge writes.

The forge documents four hard rules and a quality-bar checklist, and until this file
existed every one of them was enforced by a model remembering to check its own work.
That is not a small gap. Rule 3, series_lock anchors appear verbatim in every prompt,
is the rule that produces visual consistency across a series, and it is also the
easiest one in the kit to break by paraphrasing while writing fluent prose. A careful
pass over a seven-shot storyboard drifted on it seven times out of seven with every
other validator green.

Checks:
  1. The header block names the storyboard, generator, aspect, brand-lock, run, round.
  2. The generator is an id in the capability matrix.
  3. The header aspect matches project.aspect in shots.json.
  4. No shot's prompt exceeds that generator's max_prompt_words ceiling.
  5. Every shot block names a shot that exists. A full pass covers every shot; a
     revision file covers a subset.
  6. Rule 1: no on-screen text content appears in any prompt. Text is composited.
  7. Rule 3: series_lock environment, lighting, and color_grade appear verbatim.
     The character anchor is a warning, because a shot with no person in it can
     legitimately omit it.
  8. No duplicate shot blocks in one file.

Usage:
    python tools/validate_prompts.py <output-dir>
    python tools/validate_prompts.py <output-dir>/prompts/round-1/flux.txt
    python tools/validate_prompts.py --examples
    python tools/validate_prompts.py --selftest
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from _shotkit import REPO_ROOT, capability_map, load_json

WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"

SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT = re.compile(r"^\s*#")

HEADER_FIELDS = ("Storyboard", "Generator", "Aspect", "Brand-lock", "Run", "Round")

# series_lock keys that describe every frame, so every prompt has to carry them.
UNIVERSAL_ANCHORS = ("environment", "lighting", "color_grade")


def parse_blocks(text: str) -> tuple[dict[str, str], list[tuple[str, str]]]:
    """Return (header fields, [(shot_id, prompt body)])."""
    header: dict[str, str] = {}
    blocks: list[tuple[str, list[str]]] = []
    current: list[str] | None = None

    for line in text.splitlines():
        m = SHOT_HEADER.match(line)
        if m:
            current = []
            blocks.append((m.group(1), current))
            continue
        if current is None:
            hm = re.match(r"^#\s*([A-Za-z-]+)\s*:\s*(.+?)\s*$", line)
            if hm:
                header[hm.group(1).strip()] = hm.group(2).strip()
            continue
        if not COMMENT.match(line):
            current.append(line)

    return (header, [(sid, "\n".join(b).strip()) for sid, b in blocks])


def check_file(
    path: Path, shots_data: dict, caps: dict[str, dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    label = path.name

    text = path.read_text(encoding="utf-8")
    header, blocks = parse_blocks(text)

    if not blocks:
        return ([f"{label}: no shot blocks found; expected '# shot_NN, ...' lines"], warnings)

    for field in HEADER_FIELDS:
        if field not in header:
            warnings.append(f"{label}: header is missing '# {field}:'")

    generator = header.get("Generator", "").split()[0] if header.get("Generator") else None
    entry = caps.get(generator) if generator else None
    if generator and entry is None:
        errors.append(
            f"{label}: header names generator '{generator}', which is not an id in "
            f"_capabilities.json"
        )
    if generator is None:
        # Fall back to the filename: flux.txt or revised-flux.txt
        stem = path.stem.replace("revised-", "")
        entry = caps.get(stem)
        if entry:
            warnings.append(
                f"{label}: no '# Generator:' header, inferred '{stem}' from the filename"
            )

    project = shots_data.get("project", {})
    if "Aspect" in header and header["Aspect"] != project.get("aspect"):
        errors.append(
            f"{label}: header aspect '{header['Aspect']}' does not match "
            f"project.aspect '{project.get('aspect')}'"
        )

    shot_ids = [s["id"] for s in shots_data.get("shots", [])]
    by_id = {s["id"]: s for s in shots_data.get("shots", [])}
    series = shots_data.get("series_lock", {})

    seen: set[str] = set()
    for sid, body in blocks:
        if sid in seen:
            errors.append(f"{label}: {sid} appears in more than one block")
        seen.add(sid)
        if sid not in by_id:
            errors.append(f"{label}: names {sid}, which is not in shots.json")
            continue
        if not body:
            errors.append(f"{label}: {sid} has a header but no prompt body")
            continue

        if entry:
            words = len(body.split())
            ceiling = entry["max_prompt_words"]
            if words > ceiling:
                errors.append(
                    f"{label}: {sid} is {words} words, over the "
                    f"{entry['id']} ceiling of {ceiling}"
                )

        low = body.lower()
        for key in UNIVERSAL_ANCHORS:
            value = series.get(key)
            if value and value.lower() not in low:
                errors.append(
                    f"{label}: {sid} does not carry the series_lock {key} verbatim. "
                    f"Paraphrasing an anchor is what makes shots stop matching each other"
                )
        character = series.get("character")
        if character and character.lower() not in low:
            warnings.append(
                f"{label}: {sid} does not carry the series_lock character verbatim; "
                f"correct only if this shot has no person in it"
            )

    # Rule 1: text is composited, never described.
    overlays_path = path.parent.parent.parent / "text-overlays.json"
    overlays_data, ov_err = load_json(overlays_path)
    if not ov_err and isinstance(overlays_data, dict):
        for overlay in overlays_data.get("overlays", []):
            content = overlay.get("content")
            if not isinstance(content, str) or len(content) < 8:
                continue
            needle = content.lower().rstrip(".!?")
            for sid, body in blocks:
                if needle in body.lower():
                    errors.append(
                        f"{label}: {sid} contains the copy of overlay "
                        f"{overlay.get('id')} verbatim. On-screen text is composited, "
                        f"never put in an image prompt"
                    )

    is_revision = path.name.startswith("revised-")
    if not is_revision:
        for missing in [s for s in shot_ids if s not in seen]:
            errors.append(f"{label}: full pass is missing a block for {missing}")

    return (errors, warnings)


def collect_prompt_files(target: Path) -> tuple[Path | None, list[Path]]:
    """Return (output_dir, prompt files). Accepts an output dir or a single file."""
    if target.is_file():
        # prompts/round-N/<file>.txt  ->  output dir is three levels up
        return (target.parent.parent.parent, [target])
    if target.is_dir():
        found = sorted(target.glob("prompts/round-*/*.txt"))
        if not found:
            found = sorted(target.glob("prompts/*.txt"))  # pre-3.0.0 flat layout
        return (target, found)
    return (None, [])


def validate_target(target: Path) -> tuple[list[str], list[str]]:
    out_dir, files = collect_prompt_files(target)
    if out_dir is None:
        return ([f"not a file or directory: {target}"], [])
    if not files:
        return ([f"no prompt files found under {target}"], [])

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        return ([f"cannot read shots.json next to the prompts: {err}"], [])

    caps = capability_map()
    errors: list[str] = []
    warnings: list[str] = []
    for path in files:
        e, w = check_file(path, shots_data, caps)
        errors += e
        warnings += w
    return (errors, warnings)


SHOTS_FIXTURE = {
    "project": {"aspect": "9:16"},
    "series_lock": {
        "character": "founder in a navy crewneck",
        "environment": "minimalist home office, oak desk",
        "lighting": "soft window light from camera-left",
        "color_grade": "warm filmic with muted teal shadows",
    },
    "shots": [{"id": "shot_01"}, {"id": "shot_02"}],
}


def _fixture(body_01: str, body_02: str | None = None, aspect: str = "9:16") -> str:
    out = [
        "# Storyboard: Fixture",
        "# Generator: flux",
        f"# Aspect: {aspect}",
        "# Brand-lock: brand-lock.snapshot.md",
        "# Run: 20260730T180000Z-7c41e0a9",
        "# Round: 1",
        "",
        "# shot_01, hook, 0.0-2.0s, MCU eye-level static",
        body_01,
        "",
    ]
    if body_02 is not None:
        out += ["# shot_02, pain, 2.0-6.0s, MS eye-level push", body_02, ""]
    return "\n".join(out)


def selftest() -> int:
    import tempfile

    ok = True
    sl = SHOTS_FIXTURE["series_lock"]
    good = (
        f"Medium close-up of a {sl['character']}. {sl['environment']}. "
        f"{sl['lighting']}. {sl['color_grade']}. Photorealistic."
    )
    drifted = (
        "Medium close-up of a founder in a navy sweater. A minimal home office with "
        "an oak desk. Soft light from the left. Warm grade with teal shadows."
    )

    cases = [
        ("a compliant full pass passes", _fixture(good, good), False),
        ("a paraphrased anchor is caught", _fixture(drifted, good), True),
        ("a missing shot in a full pass is caught", _fixture(good), True),
        ("an aspect mismatch is caught", _fixture(good, good, aspect="16:9"), True),
        (
            "an over-ceiling prompt is caught",
            _fixture(good + " extra" * 200, good),
            True,
        ),
        (
            "an unknown shot id is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_09,"),
            True,
        ),
        (
            "a duplicate shot block is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_01,"),
            True,
        ),
        (
            "an empty prompt body is caught",
            _fixture(good, ""),
            True,
        ),
    ]

    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "output"
        (out / "prompts" / "round-1").mkdir(parents=True)
        (out / "shots.json").write_text(json.dumps(SHOTS_FIXTURE))
        caps = capability_map()
        for label, text, should_fail in cases:
            p = out / "prompts" / "round-1" / "flux.txt"
            p.write_text(text)
            errors, _ = check_file(p, SHOTS_FIXTURE, caps)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        # Rule 1: overlay copy leaking into a prompt.
        (out / "text-overlays.json").write_text(
            json.dumps(
                {
                    "version": "1.0",
                    "overlays": [
                        {"id": "text_01", "content": "You are the bottleneck."}
                    ],
                }
            )
        )
        p = out / "prompts" / "round-1" / "flux.txt"
        p.write_text(_fixture(good + " The words You are the bottleneck appear.", good))
        errors, _ = check_file(p, SHOTS_FIXTURE, caps)
        if any("composited" in e for e in errors):
            print("  ok    selftest: overlay copy inside a prompt is caught")
        else:
            print(f"  FAIL  selftest: overlay leak not caught -> {errors}")
            ok = False

        # A revision file covers a subset, and that is not an error.
        rev = out / "prompts" / "round-2"
        rev.mkdir()
        rp = rev / "revised-flux.txt"
        rp.write_text(_fixture(good))
        errors, _ = check_file(rp, SHOTS_FIXTURE, caps)
        if not errors:
            print("  ok    selftest: a revision file may cover a subset of shots")
        else:
            print(f"  FAIL  selftest: revision subset flagged -> {errors}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_prompts.py <output-dir|prompt-file> [...]")
        print("       python tools/validate_prompts.py --examples")
        print("       python tools/validate_prompts.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    targets = [WORKED_RUN] if "--examples" in args else [Path(a) for a in args]

    print(f"Validating prompt files for {len(targets)} target(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for target in targets:
        errors, warnings = validate_target(target)
        try:
            shown = target.relative_to(REPO_ROOT)
        except ValueError:
            shown = target
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for e in errors:
                print(f"        - {e}")
        for w in warnings:
            print(f"  warn  {shown}: {w}")

    print()
    if total_errors == 0:
        print(f"All prompt files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across prompt files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/validate_prompts.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/validate_provenance.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/validate_provenance.py`

#!/usr/bin/env python3
"""
Validate the provenance chain of a shotkit output tree.

This is the tool that answers "does this verdict still describe the file it reviewed."
Paths lie: a filename says nothing about the bytes behind it, so a frame regenerated
after its critique leaves every path reference intact and every claim about it wrong.
Content hashes are what make that detectable, and this walks them.

Checks:
  1. run.json validates against run.schema.json, and its run_id agrees with created_at.
  2. Rounds are numbered from 1 with no gaps and no duplicates.
  3. Every input hash in run.json still matches the file on disk. A brand-lock edited
     mid-project fails here instead of silently repointing the project's history.
  4. Every prompt hash recorded in run.json still matches the file on disk.
  5. Every critique validates against the schema and the gating invariant.
  6. Every critique's run_id matches run.json.
  7. Every critique's image, prompt, and brand-lock hashes match the files on disk.
  8. No two critiques cover the same shot in the same round. Two operators writing the
     same verdict path is a real conflict, not a silent overwrite.
  9. Every frame on disk has a critique for its round. An unreviewed frame is the
     failure mode where a re-roll slips past the gate on a stale ACCEPT.
 10. Every shot has at least one critique, and the latest verdict per shot is reported.
 11. Shots recorded as post_only still owe compositing work.

Exit status is 0 when the chain is intact. Add --require-accept to also demand that
every shot's latest verdict is ACCEPT, which is the pipeline stop condition made
executable rather than described.

Usage:
    python tools/validate_provenance.py <output-dir> [...]
    python tools/validate_provenance.py <output-dir> --require-accept
    python tools/validate_provenance.py <output-dir> --json
    python tools/validate_provenance.py --examples
    python tools/validate_provenance.py --selftest
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    IMAGE_EXTS,
    REPO_ROOT,
    critique_paths,
    load_json,
    round_dirs,
    run_id_timestamp,
    sha256_file,
)
from validate_critique import _load_schema as _load_critique_schema
from validate_critique import validate_doc as validate_critique_doc

RUN_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "run.schema.json"
)
WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"


class Report:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.shots: dict[str, dict] = {}
        self.rounds_seen: list[int] = []
        # (path, recorded, actual) -> the labels that referenced it. One edited file is
        # one problem, even when twenty critiques all hash it.
        self.hash_failures: dict[tuple[str, str, str], list[str]] = {}

    def as_dict(self) -> dict:
        return {
            "output_dir": str(self.output_dir),
            "ok": not self.errors,
            "errors": self.errors,
            "warnings": self.warnings,
            "rounds": self.rounds_seen,
            "shots": self.shots,
        }


def _check_hash(
    report: Report, label: str, rel: str | None, expected: str | None
) -> None:
    """Compare a recorded hash against the file currently on disk."""
    if not rel or not expected:
        return
    path = report.output_dir / rel
    if not path.exists():
        report.errors.append(f"{label}: '{rel}' is referenced but missing on disk")
        return
    actual = sha256_file(path)
    if actual == expected:
        return
    report.hash_failures.setdefault((rel, expected, actual), []).append(label)


def _finalize_hash_failures(report: Report) -> None:
    """Turn collected hash mismatches into one error per distinct mismatch."""
    for (rel, expected, actual), labels in report.hash_failures.items():
        # Print both hashes in full. Truncating them meant a single mistyped character
        # at the end produced a message showing two identical-looking strings and
        # asserting they differed, which is the least useful moment to be imprecise: a
        # hand-authored run.json is exactly where typos come from.
        detail = (
            f"'{rel}' does not match the hash recorded for it\n"
            f"          recorded: {expected}\n"
            f"          on disk:  {actual}"
        )
        if len(expected) != 64:
            detail += (
                f"\n          the recorded value is {len(expected)} characters, not 64, "
                f"so it is malformed rather than stale"
            )
        elif sum(a != b for a, b in zip(expected, actual)) <= 2:
            detail += (
                "\n          they differ in one or two characters, which usually means "
                "a typo in the recorded hash rather than a changed file"
            )
        if len(labels) == 1:
            detail += f"\n          referenced by: {labels[0]}"
        else:
            shown = ", ".join(labels[:3])
            more = f", and {len(labels) - 3} more" if len(labels) > 3 else ""
            detail += (
                f"\n          referenced by {len(labels)} places: {shown}{more}"
            )
        report.errors.append(detail)


def check_run_doc(report: Report) -> dict | None:
    run_path = report.output_dir / "run.json"
    if not run_path.exists():
        report.errors.append(
            "run.json is missing, so nothing pins this output to its inputs. A tree "
            "written before 3.0.0 has no provenance to check: write a run.json "
            "(schema at skills/storyboard-architect/templates/run.schema.json) or "
            "re-run storyboard-architect. This is reported as an error rather than a "
            "warning so a pipeline gate cannot pass an unauditable tree"
        )
        return None

    run_doc, err = load_json(run_path)
    if err:
        report.errors.append(f"run.json: {err}")
        return None

    schema, s_err = load_json(RUN_SCHEMA)
    if s_err:
        report.errors.append(f"run.schema.json: {s_err}")
        return None

    validator = Draft202012Validator(schema)
    for e in sorted(validator.iter_errors(run_doc), key=lambda x: list(x.path)):
        loc = "/".join(str(p) for p in e.path) or "(root)"
        report.errors.append(f"run.json schema: {loc}: {e.message}")
    if report.errors:
        return None

    stamp = run_id_timestamp(run_doc["run_id"])
    expected = run_doc["created_at"].replace("-", "").replace(":", "")
    if stamp != expected:
        report.errors.append(
            f"run.json: run_id timestamp '{stamp}' disagrees with "
            f"created_at '{run_doc['created_at']}'"
        )

    if run_doc["inputs"].get("brand_lock_configured") is False:
        report.warnings.append(
            "run.json: brand_lock_configured is false, so this run was built against "
            "an unfilled template rather than a real brand-lock"
        )

    inputs = run_doc["inputs"]
    _check_hash(report, "inputs", inputs.get("shots_ref"), inputs.get("shots_sha256"))
    _check_hash(
        report,
        "inputs",
        inputs.get("text_overlays_ref"),
        inputs.get("text_overlays_sha256"),
    )
    _check_hash(
        report, "inputs", inputs.get("brand_lock_ref"), inputs.get("brand_lock_sha256")
    )

    numbers = [r["round"] for r in run_doc.get("rounds", [])]
    report.rounds_seen = sorted(numbers)
    if len(numbers) != len(set(numbers)):
        report.errors.append("run.json: duplicate round numbers")
    if numbers and sorted(numbers) != list(range(1, max(numbers) + 1)):
        report.errors.append(
            f"run.json: rounds must run 1..N with no gaps, got {sorted(numbers)}"
        )

    for rnd in run_doc.get("rounds", []):
        for prompt in rnd.get("prompts", []):
            _check_hash(
                report,
                f"round {rnd['round']} prompt",
                prompt.get("ref"),
                prompt.get("sha256"),
            )
        for shot_id in rnd.get("post_only_shots", []) or []:
            report.warnings.append(
                f"round {rnd['round']}: {shot_id} is recorded as post-only, so it owes "
                f"compositing work that no prompt or frame will show"
            )

    return run_doc


def _round_of(path: Path, output_dir: Path, data: dict) -> int:
    """
    Which round a critique belongs to.

    The directory name wins, because that is the addressing scheme. A legacy critique
    sitting at the output root has no directory to read, so fall back to its own
    `round` field and then to 1.
    """
    try:
        parent = path.relative_to(output_dir).parent.name
    except ValueError:
        parent = ""
    if parent.startswith("round-") and parent[len("round-"):].isdigit():
        return int(parent[len("round-"):])
    declared = data.get("round")
    return declared if isinstance(declared, int) and declared >= 1 else 1


def check_critiques(report: Report, run_doc: dict | None) -> None:
    critique_validator = Draft202012Validator(_load_critique_schema())
    seen: dict[tuple[str, int], Path] = {}

    # critique_paths() is the one definition of "where critiques live", shared with
    # validate_critique.py and shots-to-html.py. Walking the round directories directly
    # meant this tool ignored a legacy root critique.json that the other two read, so
    # the preview showed a verdict badge for a shot this tool called unreviewed.
    for path in critique_paths(report.output_dir):
        try:
            rel = path.relative_to(report.output_dir)
        except ValueError:
            rel = path
        data, err = load_json(path)
        if err:
            report.errors.append(f"{rel}: {err}")
            continue
        if not isinstance(data, dict):
            report.errors.append(f"{rel}: top level is not an object")
            continue

        errors, warnings = validate_critique_doc(data, critique_validator)
        report.errors.extend(f"{rel}: {e}" for e in errors)
        report.warnings.extend(f"{rel}: {w}" for w in warnings)
        if errors:
            continue

        round_no = _round_of(path, report.output_dir, data)
        in_round_dir = rel.parent.name.startswith("round-")

        if in_round_dir and data.get("round") not in (None, round_no):
            report.errors.append(
                f"{rel}: declares round {data.get('round')} but sits in round-{round_no}/"
            )
        if run_doc and data.get("run_id") not in (None, run_doc["run_id"]):
            report.errors.append(
                f"{rel}: run_id '{data.get('run_id')}' does not match run.json "
                f"'{run_doc['run_id']}'"
            )

        shot_id = data.get("shot_id")
        if shot_id:
            key = (shot_id, round_no)
            if key in seen:
                report.errors.append(
                    f"{rel}: a second critique for {shot_id} in round {round_no} "
                    f"already exists at {seen[key]}; "
                    f"two operators reviewed the same shot in the same round"
                )
            else:
                seen[key] = rel

        _check_hash(report, f"{rel} image", data.get("image_ref"), data.get("image_sha256"))
        _check_hash(report, f"{rel} prompt", data.get("prompt_ref"), data.get("prompt_sha256"))
        _check_hash(
            report,
            f"{rel} brand-lock",
            data.get("brand_lock_ref"),
            data.get("brand_lock_sha256"),
        )

        if shot_id:
            entry = report.shots.setdefault(shot_id, {"rounds": {}})
            entry["rounds"][str(round_no)] = {
                "verdict": data.get("verdict"),
                "confidence": data.get("confidence"),
                "critique_ref": str(rel),
                "issues": len(data.get("issues", [])),
            }


def check_coverage(report: Report, run_doc: dict | None) -> None:
    shots_rel = "shots.json"
    if run_doc:
        shots_rel = run_doc["inputs"].get("shots_ref", "shots.json")
    shots_data, err = load_json(report.output_dir / shots_rel)
    shot_ids: list[str] = []
    if err:
        report.warnings.append(f"coverage: cannot read {shots_rel}, skipped ({err})")
    elif isinstance(shots_data, dict):
        shot_ids = [
            s["id"] for s in shots_data.get("shots", []) if isinstance(s.get("id"), str)
        ]

    reviewed_by_round: dict[int, set[str]] = {}
    for shot_id, entry in report.shots.items():
        for rnd in entry["rounds"]:
            reviewed_by_round.setdefault(int(rnd), set()).add(shot_id)

    for round_no, directory in round_dirs(report.output_dir, "frames"):
        reviewed = reviewed_by_round.get(round_no, set())
        for path in sorted(directory.iterdir()):
            if path.suffix.lstrip(".").lower() not in IMAGE_EXTS:
                continue
            frame_shot = path.stem
            if frame_shot not in reviewed:
                report.errors.append(
                    f"coverage: frames/round-{round_no}/{path.name} has no critique for "
                    f"round {round_no}; it was never reviewed"
                )

    for shot_id in shot_ids:
        entry = report.shots.get(shot_id)
        if not entry:
            report.warnings.append(
                f"coverage: {shot_id} has no critique in any round"
            )
            continue
        latest = max(int(r) for r in entry["rounds"])
        entry["latest_round"] = latest
        entry["latest_verdict"] = entry["rounds"][str(latest)]["verdict"]

    for shot_id in report.shots:
        if shot_ids and shot_id not in shot_ids:
            report.errors.append(
                f"coverage: a critique names {shot_id}, which is not in {shots_rel}"
            )


def validate_tree(output_dir: Path) -> Report:
    report = Report(output_dir)
    if not output_dir.is_dir():
        report.errors.append(f"not a directory: {output_dir}")
        return report
    run_doc = check_run_doc(report)
    check_critiques(report, run_doc)
    check_coverage(report, run_doc)
    _finalize_hash_failures(report)
    return report


def outstanding(report: Report) -> list[str]:
    """Shots whose latest verdict is not ACCEPT."""
    return sorted(
        shot_id
        for shot_id, entry in report.shots.items()
        if entry.get("latest_verdict") not in (None, "ACCEPT")
    )


def selftest() -> int:
    """Run the bundled worked example, then tamper with a copy and prove drift is caught."""
    import shutil
    import tempfile

    ok = True

    clean = validate_tree(WORKED_RUN)
    if clean.errors:
        print(f"  FAIL  selftest: the bundled worked run should be clean, got: {clean.errors}")
        ok = False
    else:
        print("  ok    selftest: the bundled worked run passes")

    if outstanding(clean):
        print(f"  FAIL  selftest: worked run should have no outstanding shots, got {outstanding(clean)}")
        ok = False
    else:
        print("  ok    selftest: every shot in the worked run ends on ACCEPT")

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        frame = scratch / "frames" / "round-2" / "shot_02.png"
        frame.write_bytes(frame.read_bytes() + b"\x00")
        report = validate_tree(scratch)
        if any("does not match the hash recorded" in e for e in report.errors):
            print("  ok    selftest: a frame regenerated after its critique is caught")
        else:
            print(f"  FAIL  selftest: frame tampering was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        lock = scratch / "brand-lock.snapshot.md"
        lock.write_text(lock.read_text() + "\n<!-- edited mid-project -->\n")
        report = validate_tree(scratch)
        if any("brand-lock.snapshot.md' does not match" in e for e in report.errors):
            print("  ok    selftest: a brand-lock edited mid-project is caught")
        else:
            print(f"  FAIL  selftest: brand-lock drift was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        src = scratch / "critiques" / "round-2" / "shot_02.critique.json"
        (scratch / "critiques" / "round-2" / "shot_02.operator-b.json").write_text(
            src.read_text()
        )
        report = validate_tree(scratch)
        if any("two operators reviewed the same shot" in e for e in report.errors):
            print("  ok    selftest: two critiques for one shot in one round is caught")
        else:
            print(f"  FAIL  selftest: duplicate critique was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        source = scratch / "frames" / "round-2" / "shot_02.png"
        (scratch / "frames" / "round-2" / "shot_01.png").write_bytes(source.read_bytes())
        report = validate_tree(scratch)
        if any("was never reviewed" in e for e in report.errors):
            print("  ok    selftest: a frame with no critique for its round is caught")
        else:
            print(f"  FAIL  selftest: unreviewed frame was not caught, got: {report.errors}")
            ok = False

    # A legacy tree keeps its critique at the output root. validate_critique.py and
    # shots-to-html.py both read it, so this tool has to as well: reporting a shot as
    # unreviewed while the preview shows its verdict badge is the exact kind of
    # disagreement between consumers that this release exists to remove.
    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "legacy"
        scratch.mkdir()
        shutil.copy(WORKED_RUN / "shots.json", scratch / "shots.json")
        shutil.copy(
            WORKED_RUN / "critiques" / "round-1" / "shot_01.critique.json",
            scratch / "critique.json",
        )
        report = validate_tree(scratch)
        if "shot_01" in report.shots:
            print("  ok    selftest: a legacy root critique.json is still discovered")
        else:
            print(
                "  FAIL  selftest: legacy root critique.json was ignored; "
                f"shots seen: {sorted(report.shots)}"
            )
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_provenance.py <output-dir> [...]")
        print("       python tools/validate_provenance.py <output-dir> --require-accept")
        print("       python tools/validate_provenance.py --examples")
        print("       python tools/validate_provenance.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    require_accept = "--require-accept" in args
    as_json = "--json" in args
    targets_raw = [a for a in args if not a.startswith("--")]

    if "--examples" in args:
        targets = [WORKED_RUN]
    elif targets_raw:
        targets = [Path(t) for t in targets_raw]
    else:
        print("ERROR: no output directory given")
        return 2

    reports = [validate_tree(t) for t in targets]

    if as_json:
        print(json.dumps([r.as_dict() for r in reports], indent=2))
    else:
        print(f"Validating provenance for {len(reports)} output tree(s)")
        print()
        for report in reports:
            try:
                label = report.output_dir.relative_to(REPO_ROOT)
            except ValueError:
                label = report.output_dir
            if report.errors:
                print(f"  FAIL  {label}")
                for err in report.errors:
                    print(f"        - {err}")
            else:
                print(f"  ok    {label}  ({len(report.shots)} shot(s), rounds {report.rounds_seen or 'none'})")
            for warn in report.warnings:
                print(f"  warn  {label}: {warn}")
            for shot_id in sorted(report.shots):
                entry = report.shots[shot_id]
                verdict = entry.get("latest_verdict", "?")
                print(
                    f"        {shot_id}: {verdict} "
                    f"(round {entry.get('latest_round', '?')})"
                )
        print()

    failed = any(r.errors for r in reports)
    unresolved = {
        str(r.output_dir): outstanding(r) for r in reports if outstanding(r)
    }

    if not as_json:
        if failed:
            total = sum(len(r.errors) for r in reports)
            print(f"FAILED: {total} provenance error(s).")
        elif require_accept and unresolved:
            for path, shots in unresolved.items():
                print(f"NOT DONE: {path} still has non-ACCEPT shots: {', '.join(shots)}")
        else:
            print("Provenance chain intact.")

    if failed:
        return 1
    if require_accept and unresolved:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/validate_provenance.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/validate_schemas.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/validate_schemas.py`

#!/usr/bin/env python3
"""
Validate that every *.schema.json file in the repo is itself valid JSON Schema.

Run from repo root:
    python tools/validate_schemas.py
"""

from __future__ import annotations
import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
    from jsonschema.exceptions import SchemaError
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install jsonschema")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent


def find_schema_files() -> list[Path]:
    """Find every *.schema.json file in the repo."""
    return sorted(REPO_ROOT.rglob("*.schema.json"))


def validate_schema_file(path: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        errors.append(f"invalid JSON: {e}")
        return errors

    try:
        Draft202012Validator.check_schema(data)
    except SchemaError as e:
        errors.append(f"invalid schema: {e.message}")

    if "$id" not in data:
        errors.append("missing '$id' field")
    if "title" not in data:
        errors.append("missing 'title' field")
    if "description" not in data:
        errors.append("missing 'description' field")

    return errors


def main() -> int:
    schemas = find_schema_files()
    if not schemas:
        print("ERROR: no *.schema.json files found in repo")
        return 1

    print(f"Validating {len(schemas)} schema file(s)")
    print()

    total_errors = 0
    for path in schemas:
        rel = path.relative_to(REPO_ROOT)
        errors = validate_schema_file(path)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All schemas valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across schemas.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/validate_schemas.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/validate_shots.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/validate_shots.py`

#!/usr/bin/env python3
"""
Validate a storyboard output set: shots.json and text-overlays.json, as instances.

Schema validation alone was never enough here. Every rule below is documented in
skills/storyboard-architect/SKILL.md as a quality-bar checkbox, which means it was
enforced by a model remembering to check it. These are the same rules, executable.

Checks:
  1. shots.json validates against shots.schema.json.
  2. text-overlays.json validates against text-overlays.schema.json.
  3. Timing: end > start, no duplicate ids, no gaps, no overlaps, and the covered
     span matches project.duration_s within TIMING_TOLERANCE_S.
  4. Reference integrity, both directions: every shot.on_screen_text resolves to an
     overlay, every overlay.shot_id resolves to a shot, and every overlay is
     reachable from at least one shot.
  5. Overlay timing sits inside its shot window and exit is after enter.
  6. Every overlay color appears in the brand-lock palette.
  7. brand_lock_ref resolves on disk.
  8. Every assets.generated[].generator is a real id in the capability matrix.
  9. Warnings for prose leaks: on-screen copy repeated in a shot subject, raw hex in
     a shot subject, shot ids out of chronological order, overlay fonts not named in
     the brand-lock typography section.

Usage:
    python tools/validate_shots.py <output-dir> [...]
    python tools/validate_shots.py path/to/shots.json [...]
    python tools/validate_shots.py --examples          # every bundled example
    python tools/validate_shots.py --selftest          # prove the checks fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    HEX_RE,
    REPO_ROOT,
    as_overlay_ids,
    as_shot_ids,
    capability_ids,
    load_json,
    palette_hexes,
    parse_typography,
)

SHOTS_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "shots.schema.json"
)
OVERLAYS_SCHEMA = (
    REPO_ROOT
    / "skills"
    / "storyboard-architect"
    / "templates"
    / "text-overlays.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "storyboard-architect" / "examples"

TIMING_TOLERANCE_S = 0.1


def _schema_errors(data, validator: Draft202012Validator, label: str) -> list[str]:
    out = []
    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        out.append(f"{label} schema: {loc}: {err.message}")
    return out


def check_timing(shots: list[dict], duration_s: float) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    seen: set[str] = set()
    for shot in shots:
        sid = shot.get("id", "?")
        if sid in seen:
            errors.append(f"timing: duplicate shot id '{sid}'")
        seen.add(sid)
        start, end = shot.get("start"), shot.get("end")
        if isinstance(start, (int, float)) and isinstance(end, (int, float)):
            if end <= start:
                errors.append(
                    f"timing: {sid} has end ({end}) not after start ({start})"
                )

    timed = [
        s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    ]
    if not timed:
        return errors, warnings

    ordered = sorted(timed, key=lambda s: (s["start"], s["end"]))
    for a, b in zip(ordered, ordered[1:]):
        if b["start"] > a["end"] + 1e-9:
            errors.append(
                f"timing: gap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )
        elif b["start"] < a["end"] - 1e-9:
            errors.append(
                f"timing: overlap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )

    span = max(s["end"] for s in timed) - min(s["start"] for s in timed)
    if abs(span - duration_s) > TIMING_TOLERANCE_S:
        errors.append(
            f"timing: covered span {span:g}s does not match project.duration_s "
            f"{duration_s:g}s (tolerance {TIMING_TOLERANCE_S}s)"
        )

    if [s["id"] for s in timed] != [s["id"] for s in ordered]:
        warnings.append(
            "timing: shot ids are not in chronological order; readers assume they are"
        )

    return errors, warnings


def check_version_features(shots: list[dict], version: str) -> list[str]:
    """Features may not be used below the version that introduced them."""
    errors: list[str] = []
    if version in ("1.0", "1.1"):
        for shot in shots:
            if isinstance(shot.get("on_screen_text"), list):
                errors.append(
                    f"version: {shot.get('id')} uses the array form of on_screen_text, "
                    f"which requires version 1.2 (file declares {version})"
                )
    if version == "1.0":
        for shot in shots:
            if shot.get("assets") is not None:
                errors.append(
                    f"version: {shot.get('id')} carries an assets block, which "
                    f"requires version 1.1 or later (file declares 1.0)"
                )
    return errors


def check_references(
    shots: list[dict], overlays: list[dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    shot_ids = {s.get("id") for s in shots}
    overlay_ids: set[str] = set()
    for overlay in overlays:
        oid = overlay.get("id")
        if oid in overlay_ids:
            errors.append(f"reference: duplicate overlay id '{oid}'")
        overlay_ids.add(oid)

    referenced: set[str] = set()
    for shot in shots:
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            referenced.add(oid)
            if oid not in overlay_ids:
                errors.append(
                    f"reference: {shot.get('id')}.on_screen_text '{oid}' has no "
                    f"entry in text-overlays.json"
                )

    for overlay in overlays:
        oid = overlay.get("id")
        for sid in as_shot_ids(overlay.get("shot_id")):
            if sid not in shot_ids:
                errors.append(
                    f"reference: overlay {oid}.shot_id '{sid}' has no entry in shots.json"
                )
        if oid not in referenced:
            errors.append(
                f"reference: overlay {oid} is not reachable from any "
                f"shot.on_screen_text, so no renderer will show it"
            )

    return errors, warnings


def check_overlay_windows(shots: list[dict], overlays: list[dict]) -> list[str]:
    errors: list[str] = []
    by_id = {
        s["id"]: s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    }

    for overlay in overlays:
        oid = overlay.get("id")
        enter = (overlay.get("enter") or {}).get("at")
        exit_at = (overlay.get("exit") or {}).get("at")
        if not isinstance(enter, (int, float)) or not isinstance(exit_at, (int, float)):
            continue
        if exit_at <= enter:
            errors.append(
                f"overlay: {oid} exit ({exit_at}) is not after enter ({enter})"
            )
        windows = [by_id[s] for s in as_shot_ids(overlay.get("shot_id")) if s in by_id]
        if not windows:
            continue
        lo = min(w["start"] for w in windows)
        hi = max(w["end"] for w in windows)
        if enter < lo - 1e-9 or exit_at > hi + 1e-9:
            errors.append(
                f"overlay: {oid} timing {enter}-{exit_at}s falls outside its shot "
                f"window {lo:g}-{hi:g}s"
            )

    return errors


def check_brand_alignment(
    shots: list[dict], overlays: list[dict], brand_lock_text: str | None
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if brand_lock_text is None:
        warnings.append(
            "brand: brand_lock_ref did not resolve, so palette and font checks were skipped"
        )
        return errors, warnings

    allowed = palette_hexes(brand_lock_text)
    for overlay in overlays:
        color = overlay.get("color")
        if isinstance(color, str) and color.lower() not in allowed:
            errors.append(
                f"brand: overlay {overlay.get('id')} color {color} is not in the "
                f"brand-lock palette"
            )

    fonts = {v.lower() for v in parse_typography(brand_lock_text).values() if v}
    if fonts:
        for overlay in overlays:
            font = overlay.get("font")
            if isinstance(font, str) and font.lower() not in fonts:
                warnings.append(
                    f"brand: overlay {overlay.get('id')} font '{font}' is not a font "
                    f"declared in the brand-lock typography section"
                )

    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        for hex_val in HEX_RE.findall(subject):
            warnings.append(
                f"brand: {shot.get('id')}.subject names a raw hex ({hex_val}); "
                f"colors belong in series_lock and the brand-lock"
            )

    return errors, warnings


def check_text_leak(shots: list[dict], overlays: list[dict]) -> list[str]:
    """On-screen copy repeated inside a shot subject. Text is a separate layer."""
    warnings: list[str] = []
    contents = {
        o.get("id"): o.get("content")
        for o in overlays
        if isinstance(o.get("content"), str) and len(o.get("content", "")) >= 8
    }
    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        lowered = subject.lower()
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            content = contents.get(oid)
            if content and content.lower().rstrip(".!?") in lowered:
                warnings.append(
                    f"text: {shot.get('id')}.subject repeats overlay {oid} copy "
                    f"verbatim; on-screen text is composited, never described"
                )
    return warnings


def check_assets(shots: list[dict], known_generators: set[str]) -> list[str]:
    errors: list[str] = []
    if not known_generators:
        return errors
    for shot in shots:
        for entry in (shot.get("assets") or {}).get("generated", []) or []:
            gen = entry.get("generator")
            if isinstance(gen, str) and gen not in known_generators:
                errors.append(
                    f"assets: {shot.get('id')} generated frame names generator "
                    f"'{gen}', which is not in the capability matrix"
                )
            if entry.get("accepted") is True and not entry.get("critique_ref"):
                errors.append(
                    f"assets: {shot.get('id')} has an accepted frame with no "
                    f"critique_ref, which is an unsourced approval"
                )
    return errors


def validate_set(shots_path: Path) -> tuple[list[str], list[str]]:
    """Validate one shots.json plus the siblings it points at."""
    errors: list[str] = []
    warnings: list[str] = []

    shots_data, err = load_json(shots_path)
    if err:
        return ([err], warnings)
    if not isinstance(shots_data, dict):
        return ([f"{shots_path}: top level is not an object"], warnings)

    shots_schema, s_err = load_json(SHOTS_SCHEMA)
    overlays_schema, o_err = load_json(OVERLAYS_SCHEMA)
    if s_err or o_err:
        return ([s_err or o_err], warnings)

    errors += _schema_errors(
        shots_data, Draft202012Validator(shots_schema), "shots.json"
    )

    base = shots_path.parent
    overlays_path = base / "text-overlays.json"
    overlays: list[dict] = []
    if overlays_path.exists():
        overlays_data, ov_err = load_json(overlays_path)
        if ov_err:
            errors.append(f"text-overlays.json: {ov_err}")
        else:
            errors += _schema_errors(
                overlays_data,
                Draft202012Validator(overlays_schema),
                "text-overlays.json",
            )
            overlays = overlays_data.get("overlays", []) or []
    else:
        for shot in shots_data.get("shots", []) or []:
            if as_overlay_ids(shot.get("on_screen_text")):
                errors.append(
                    "reference: shots.json references on-screen text but "
                    "text-overlays.json is missing"
                )
                break

    if errors:
        # Structure-dependent checks assume schema-valid input.
        return (errors, warnings)

    shots = shots_data.get("shots", []) or []
    duration = shots_data.get("project", {}).get("duration_s")

    errors += check_version_features(shots, shots_data.get("version", ""))

    if isinstance(duration, (int, float)):
        t_err, t_warn = check_timing(shots, float(duration))
        errors += t_err
        warnings += t_warn

    r_err, r_warn = check_references(shots, overlays)
    errors += r_err
    warnings += r_warn
    errors += check_overlay_windows(shots, overlays)

    brand_ref = shots_data.get("brand_lock_ref")
    brand_text: str | None = None
    if isinstance(brand_ref, str):
        brand_path = base / brand_ref
        if brand_path.exists():
            brand_text = brand_path.read_text(encoding="utf-8")
        else:
            errors.append(
                f"brand: brand_lock_ref '{brand_ref}' does not resolve from {base}"
            )
    b_err, b_warn = check_brand_alignment(shots, overlays, brand_text)
    errors += b_err
    warnings += b_warn

    warnings += check_text_leak(shots, overlays)
    errors += check_assets(shots, capability_ids())

    return (errors, warnings)


def _resolve_target(raw: str) -> Path | None:
    path = Path(raw)
    if path.is_dir():
        candidate = path / "shots.json"
        return candidate if candidate.exists() else None
    return path if path.exists() else None


def selftest() -> int:
    """Prove the cross-field checks fire. Fixtures are in-memory, no files touched."""
    ok = True
    cases = [
        (
            "end not after start",
            lambda: check_timing(
                [{"id": "shot_01", "start": 5.0, "end": 3.0}], 30.0
            )[0],
        ),
        (
            "gap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 2.0},
                    {"id": "shot_02", "start": 4.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "overlap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 5.0},
                    {"id": "shot_02", "start": 3.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "span disagrees with duration",
            lambda: check_timing(
                [{"id": "shot_01", "start": 0.0, "end": 10.0}], 30.0
            )[0],
        ),
        (
            "dangling on_screen_text",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": "text_09"}], []
            )[0],
        ),
        (
            "unreachable overlay",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": None}],
                [{"id": "text_01", "shot_id": "shot_01"}],
            )[0],
        ),
        (
            "overlay outside its shot window",
            lambda: check_overlay_windows(
                [{"id": "shot_01", "start": 0.0, "end": 2.0}],
                [
                    {
                        "id": "text_01",
                        "shot_id": "shot_01",
                        "enter": {"at": 0.0},
                        "exit": {"at": 9.0},
                    }
                ],
            ),
        ),
        (
            "off-palette overlay color",
            lambda: check_brand_alignment(
                [],
                [{"id": "text_01", "color": "#ABCDEF"}],
                "## Palette\n\n| Role | Hex |\n|---|---|\n| Ink | `#2A2A32` |\n",
            )[0],
        ),
        (
            "accepted frame with no critique_ref",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {"generated": [{"path": "a.png", "accepted": True}]},
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "unknown generator id",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {
                            "generated": [{"path": "a.png", "generator": "runway-sora"}]
                        },
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "1.2 feature used in a 1.0 file",
            lambda: check_version_features(
                [{"id": "shot_01", "on_screen_text": ["text_01", "text_02"]}], "1.0"
            ),
        ),
    ]

    for label, fn in cases:
        produced = fn()
        if produced:
            print(f"  ok    selftest: {label} is caught")
        else:
            print(f"  FAIL  selftest: {label} was not caught")
            ok = False

    clean, clean_warn = check_timing(
        [
            {"id": "shot_01", "start": 0.0, "end": 2.0},
            {"id": "shot_02", "start": 2.0, "end": 30.0},
        ],
        30.0,
    )
    if clean or clean_warn:
        print(f"  FAIL  selftest: a clean shot list should pass, got: {clean + clean_warn}")
        ok = False
    else:
        print("  ok    selftest: a clean shot list passes")

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_shots.py <output-dir|shots.json> [...]")
        print("       python tools/validate_shots.py --examples")
        print("       python tools/validate_shots.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    if "--examples" in args:
        targets = sorted(EXAMPLES_DIR.glob("*/shots.json"))
        if not targets:
            print(f"ERROR: no bundled examples found under {EXAMPLES_DIR}")
            return 1
    else:
        targets = []
        for raw in args:
            resolved = _resolve_target(raw)
            if resolved is None:
                print(f"  FAIL  {raw}")
                print("        - no shots.json found at this path")
                return 1
            targets.append(resolved)

    print(f"Validating {len(targets)} storyboard set(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for shots_path in targets:
        try:
            rel = shots_path.relative_to(REPO_ROOT)
        except ValueError:
            rel = shots_path
        errors, warnings = validate_set(shots_path)
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {rel}: {warn}")

    print()
    if total_errors == 0:
        print(f"All storyboard sets valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across storyboard sets.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/validate_shots.py -->


<!-- SOURCE_FILE_START: skills/brand-lock-extractor/tools/validate_skills.py -->
# SOURCE FILE: `skills/brand-lock-extractor/tools/validate_skills.py`

#!/usr/bin/env python3
"""
Validate every SKILL.md in the repo has the required frontmatter.

Required fields:
- name (string, matches the directory name)
- description (string, non-empty)

Run from repo root:
    python tools/validate_skills.py
"""

from __future__ import annotations
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML not installed. Run: pip install pyyaml")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent
SKILLS_DIR = REPO_ROOT / "skills"


def parse_frontmatter(path: Path) -> dict | None:
    """Extract YAML frontmatter from a Markdown file. Returns None if absent."""
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    parts = text.split("---", 2)
    if len(parts) < 3:
        return None
    try:
        return yaml.safe_load(parts[1])
    except yaml.YAMLError as e:
        print(f"  YAML parse error: {e}")
        return None


def validate_skill(skill_dir: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    skill_md = skill_dir / "SKILL.md"

    if not skill_md.exists():
        errors.append(f"missing SKILL.md")
        return errors

    fm = parse_frontmatter(skill_md)
    if fm is None:
        errors.append("missing or invalid YAML frontmatter")
        return errors

    if "name" not in fm:
        errors.append("frontmatter missing 'name'")
    elif not isinstance(fm["name"], str) or not fm["name"].strip():
        errors.append("frontmatter 'name' must be a non-empty string")
    elif fm["name"] != skill_dir.name:
        errors.append(
            f"frontmatter name '{fm['name']}' does not match directory name '{skill_dir.name}'"
        )

    if "description" not in fm:
        errors.append("frontmatter missing 'description'")
    elif not isinstance(fm["description"], str) or not fm["description"].strip():
        errors.append("frontmatter 'description' must be a non-empty string")
    elif len(fm["description"]) < 50:
        errors.append(
            f"frontmatter description is too short ({len(fm['description'])} chars). "
            "Aim for >= 50 chars to support skill triggering."
        )

    return errors


def main() -> int:
    if not SKILLS_DIR.exists():
        print(f"ERROR: skills directory not found at {SKILLS_DIR}")
        return 1

    skill_dirs = sorted([d for d in SKILLS_DIR.iterdir() if d.is_dir()])
    if not skill_dirs:
        print(f"ERROR: no skill directories found in {SKILLS_DIR}")
        return 1

    print(f"Validating {len(skill_dirs)} skill(s) in {SKILLS_DIR.relative_to(REPO_ROOT)}/")
    print()

    total_errors = 0
    for skill_dir in skill_dirs:
        errors = validate_skill(skill_dir)
        rel = skill_dir.relative_to(REPO_ROOT)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All skills valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across skills.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/brand-lock-extractor/tools/validate_skills.py -->


<!-- SOURCE_FILE_START: skills/image/LICENSE -->
# SOURCE FILE: `skills/image/LICENSE`

Attribution 4.0 International

=======================================================================

Creative Commons Corporation ("Creative Commons") is not a law firm and
does not provide legal services or legal advice. Distribution of
Creative Commons public licenses does not create a lawyer-client or
other relationship. Creative Commons makes its licenses and related
information available on an "as-is" basis. Creative Commons gives no
warranties regarding its licenses, any material licensed under their
terms and conditions, or any related information. Creative Commons
disclaims all liability for damages resulting from their use to the
fullest extent possible.

Using Creative Commons Public Licenses

Creative Commons public licenses provide a standard set of terms and
conditions that creators and other rights holders may use to share
original works of authorship and other material subject to copyright
and certain other rights specified in the public license below. The
following considerations are for informational purposes only, are not
exhaustive, and do not form part of our licenses.

     Considerations for licensors: Our public licenses are
     intended for use by those authorized to give the public
     permission to use material in ways otherwise restricted by
     copyright and certain other rights. Our licenses are
     irrevocable. Licensors should read and understand the terms
     and conditions of the license they choose before applying it.
     Licensors should also secure all rights necessary before
     applying our licenses so that the public can reuse the
     material as expected. Licensors should clearly mark any
     material not subject to the license. This includes other CC-
     licensed material, or material used under an exception or
     limitation to copyright. More considerations for licensors:
    wiki.creativecommons.org/Considerations_for_licensors

     Considerations for the public: By using one of our public
     licenses, a licensor grants the public permission to use the
     licensed material under specified terms and conditions. If
     the licensor's permission is not necessary for any reason--for
     example, because of any applicable exception or limitation to
     copyright--then that use is not regulated by the license. Our
     licenses grant only permissions under copyright and certain
     other rights that a licensor has authority to grant. Use of
     the licensed material may still be restricted for other
     reasons, including because others have copyright or other
     rights in the material. A licensor may make special requests,
     such as asking that all changes be marked or described.
     Although not required by our licenses, you are encouraged to
     respect those requests where reasonable. More considerations
     for the public:
    wiki.creativecommons.org/Considerations_for_licensees

=======================================================================

Creative Commons Attribution 4.0 International Public License

By exercising the Licensed Rights (defined below), You accept and agree
to be bound by the terms and conditions of this Creative Commons
Attribution 4.0 International Public License ("Public License"). To the
extent this Public License may be interpreted as a contract, You are
granted the Licensed Rights in consideration of Your acceptance of
these terms and conditions, and the Licensor grants You such rights in
consideration of benefits the Licensor receives from making the
Licensed Material available under these terms and conditions.


Section 1 -- Definitions.

  a. Adapted Material means material subject to Copyright and Similar
     Rights that is derived from or based upon the Licensed Material
     and in which the Licensed Material is translated, altered,
     arranged, transformed, or otherwise modified in a manner requiring
     permission under the Copyright and Similar Rights held by the
     Licensor. For purposes of this Public License, where the Licensed
     Material is a musical work, performance, or sound recording,
     Adapted Material is always produced where the Licensed Material is
     synched in timed relation with a moving image.

  b. Adapter's License means the license You apply to Your Copyright
     and Similar Rights in Your contributions to Adapted Material in
     accordance with the terms and conditions of this Public License.

  c. Copyright and Similar Rights means copyright and/or similar rights
     closely related to copyright including, without limitation,
     performance, broadcast, sound recording, and Sui Generis Database
     Rights, without regard to how the rights are labeled or
     categorized. For purposes of this Public License, the rights
     specified in Section 2(b)(1)-(2) are not Copyright and Similar
     Rights.

  d. Effective Technological Measures means those measures that, in the
     absence of proper authority, may not be circumvented under laws
     fulfilling obligations under Article 11 of the WIPO Copyright
     Treaty adopted on December 20, 1996, and/or similar international
     agreements.

  e. Exceptions and Limitations means fair use, fair dealing, and/or
     any other exception or limitation to Copyright and Similar Rights
     that applies to Your use of the Licensed Material.

  f. Licensed Material means the artistic or literary work, database,
     or other material to which the Licensor applied this Public
     License.

  g. Licensed Rights means the rights granted to You subject to the
     terms and conditions of this Public License, which are limited to
     all Copyright and Similar Rights that apply to Your use of the
     Licensed Material and that the Licensor has authority to license.

  h. Licensor means the individual(s) or entity(ies) granting rights
     under this Public License.

  i. Share means to provide material to the public by any means or
     process that requires permission under the Licensed Rights, such
     as reproduction, public display, public performance, distribution,
     dissemination, communication, or importation, and to make material
     available to the public including in ways that members of the
     public may access the material from a place and at a time
     individually chosen by them.

  j. Sui Generis Database Rights means rights other than copyright
     resulting from Directive 96/9/EC of the European Parliament and of
     the Council of 11 March 1996 on the legal protection of databases,
     as amended and/or succeeded, as well as other essentially
     equivalent rights anywhere in the world.

  k. You means the individual or entity exercising the Licensed Rights
     under this Public License. Your has a corresponding meaning.


Section 2 -- Scope.

  a. License grant.

       1. Subject to the terms and conditions of this Public License,
          the Licensor hereby grants You a worldwide, royalty-free,
          non-sublicensable, non-exclusive, irrevocable license to
          exercise the Licensed Rights in the Licensed Material to:

            a. reproduce and Share the Licensed Material, in whole or
               in part; and

            b. produce, reproduce, and Share Adapted Material.

       2. Exceptions and Limitations. For the avoidance of doubt, where
          Exceptions and Limitations apply to Your use, this Public
          License does not apply, and You do not need to comply with
          its terms and conditions.

       3. Term. The term of this Public License is specified in Section
          6(a).

       4. Media and formats; technical modifications allowed. The
          Licensor authorizes You to exercise the Licensed Rights in
          all media and formats whether now known or hereafter created,
          and to make technical modifications necessary to do so. The
          Licensor waives and/or agrees not to assert any right or
          authority to forbid You from making technical modifications
          necessary to exercise the Licensed Rights, including
          technical modifications necessary to circumvent Effective
          Technological Measures. For purposes of this Public License,
          simply making modifications authorized by this Section 2(a)
          (4) never produces Adapted Material.

       5. Downstream recipients.

            a. Offer from the Licensor -- Licensed Material. Every
               recipient of the Licensed Material automatically
               receives an offer from the Licensor to exercise the
               Licensed Rights under the terms and conditions of this
               Public License.

            b. No downstream restrictions. You may not offer or impose
               any additional or different terms or conditions on, or
               apply any Effective Technological Measures to, the
               Licensed Material if doing so restricts exercise of the
               Licensed Rights by any recipient of the Licensed
               Material.

       6. No endorsement. Nothing in this Public License constitutes or
          may be construed as permission to assert or imply that You
          are, or that Your use of the Licensed Material is, connected
          with, or sponsored, endorsed, or granted official status by,
          the Licensor or others designated to receive attribution as
          provided in Section 3(a)(1)(A)(i).

  b. Other rights.

       1. Moral rights, such as the right of integrity, are not
          licensed under this Public License, nor are publicity,
          privacy, and/or other similar personality rights; however, to
          the extent possible, the Licensor waives and/or agrees not to
          assert any such rights held by the Licensor to the limited
          extent necessary to allow You to exercise the Licensed
          Rights, but not otherwise.

       2. Patent and trademark rights are not licensed under this
          Public License.

       3. To the extent possible, the Licensor waives any right to
          collect royalties from You for the exercise of the Licensed
          Rights, whether directly or through a collecting society
          under any voluntary or waivable statutory or compulsory
          licensing scheme. In all other cases the Licensor expressly
          reserves any right to collect such royalties.


Section 3 -- License Conditions.

Your exercise of the Licensed Rights is expressly made subject to the
following conditions.

  a. Attribution.

       1. If You Share the Licensed Material (including in modified
          form), You must:

            a. retain the following if it is supplied by the Licensor
               with the Licensed Material:

                 i. identification of the creator(s) of the Licensed
                    Material and any others designated to receive
                    attribution, in any reasonable manner requested by
                    the Licensor (including by pseudonym if
                    designated);

                ii. a copyright notice;

               iii. a notice that refers to this Public License;

                iv. a notice that refers to the disclaimer of
                    warranties;

                 v. a URI or hyperlink to the Licensed Material to the
                    extent reasonably practicable;

            b. indicate if You modified the Licensed Material and
               retain an indication of any previous modifications; and

            c. indicate the Licensed Material is licensed under this
               Public License, and include the text of, or the URI or
               hyperlink to, this Public License.

       2. You may satisfy the conditions in Section 3(a)(1) in any
          reasonable manner based on the medium, means, and context in
          which You Share the Licensed Material. For example, it may be
          reasonable to satisfy the conditions by providing a URI or
          hyperlink to a resource that includes the required
          information.

       3. If requested by the Licensor, You must remove any of the
          information required by Section 3(a)(1)(A) to the extent
          reasonably practicable.

       4. If You Share Adapted Material You produce, the Adapter's
          License You apply must not prevent recipients of the Adapted
          Material from complying with this Public License.


Section 4 -- Sui Generis Database Rights.

Where the Licensed Rights include Sui Generis Database Rights that
apply to Your use of the Licensed Material:

  a. for the avoidance of doubt, Section 2(a)(1) grants You the right
     to extract, reuse, reproduce, and Share all or a substantial
     portion of the contents of the database;

  b. if You include all or a substantial portion of the database
     contents in a database in which You have Sui Generis Database
     Rights, then the database in which You have Sui Generis Database
     Rights (but not its individual contents) is Adapted Material; and

  c. You must comply with the conditions in Section 3(a) if You Share
     all or a substantial portion of the contents of the database.

For the avoidance of doubt, this Section 4 supplements and does not
replace Your obligations under this Public License where the Licensed
Rights include other Copyright and Similar Rights.


Section 5 -- Disclaimer of Warranties and Limitation of Liability.

  a. UNLESS OTHERWISE SEPARATELY UNDERTAKEN BY THE LICENSOR, TO THE
     EXTENT POSSIBLE, THE LICENSOR OFFERS THE LICENSED MATERIAL AS-IS
     AND AS-AVAILABLE, AND MAKES NO REPRESENTATIONS OR WARRANTIES OF
     ANY KIND CONCERNING THE LICENSED MATERIAL, WHETHER EXPRESS,
     IMPLIED, STATUTORY, OR OTHER. THIS INCLUDES, WITHOUT LIMITATION,
     WARRANTIES OF TITLE, MERCHANTABILITY, FITNESS FOR A PARTICULAR
     PURPOSE, NON-INFRINGEMENT, ABSENCE OF LATENT OR OTHER DEFECTS,
     ACCURACY, OR THE PRESENCE OR ABSENCE OF ERRORS, WHETHER OR NOT
     KNOWN OR DISCOVERABLE. WHERE DISCLAIMERS OF WARRANTIES ARE NOT
     ALLOWED IN FULL OR IN PART, THIS DISCLAIMER MAY NOT APPLY TO YOU.

  b. TO THE EXTENT POSSIBLE, IN NO EVENT WILL THE LICENSOR BE LIABLE
     TO YOU ON ANY LEGAL THEORY (INCLUDING, WITHOUT LIMITATION,
     NEGLIGENCE) OR OTHERWISE FOR ANY DIRECT, SPECIAL, INDIRECT,
     INCIDENTAL, CONSEQUENTIAL, PUNITIVE, EXEMPLARY, OR OTHER LOSSES,
     COSTS, EXPENSES, OR DAMAGES ARISING OUT OF THIS PUBLIC LICENSE OR
     USE OF THE LICENSED MATERIAL, EVEN IF THE LICENSOR HAS BEEN
     ADVISED OF THE POSSIBILITY OF SUCH LOSSES, COSTS, EXPENSES, OR
     DAMAGES. WHERE A LIMITATION OF LIABILITY IS NOT ALLOWED IN FULL OR
     IN PART, THIS LIMITATION MAY NOT APPLY TO YOU.

  c. The disclaimer of warranties and limitation of liability provided
     above shall be interpreted in a manner that, to the extent
     possible, most closely approximates an absolute disclaimer and
     waiver of all liability.


Section 6 -- Term and Termination.

  a. This Public License applies for the term of the Copyright and
     Similar Rights licensed here. However, if You fail to comply with
     this Public License, then Your rights under this Public License
     terminate automatically.

  b. Where Your right to use the Licensed Material has terminated under
     Section 6(a), it reinstates:

       1. automatically as of the date the violation is cured, provided
          it is cured within 30 days of Your discovery of the
          violation; or

       2. upon express reinstatement by the Licensor.

     For the avoidance of doubt, this Section 6(b) does not affect any
     right the Licensor may have to seek remedies for Your violations
     of this Public License.

  c. For the avoidance of doubt, the Licensor may also offer the
     Licensed Material under separate terms or conditions or stop
     distributing the Licensed Material at any time; however, doing so
     will not terminate this Public License.

  d. Sections 1, 5, 6, 7, and 8 survive termination of this Public
     License.


Section 7 -- Other Terms and Conditions.

  a. The Licensor shall not be bound by any additional or different
     terms or conditions communicated by You unless expressly agreed.

  b. Any arrangements, understandings, or agreements regarding the
     Licensed Material not stated herein are separate from and
     independent of the terms and conditions of this Public License.


Section 8 -- Interpretation.

  a. For the avoidance of doubt, this Public License does not, and
     shall not be interpreted to, reduce, limit, restrict, or impose
     conditions on any use of the Licensed Material that could lawfully
     be made without permission under this Public License.

  b. To the extent possible, if any provision of this Public License is
     deemed unenforceable, it shall be automatically reformed to the
     minimum extent necessary to make it enforceable. If the provision
     cannot be reformed, it shall be severed from this Public License
     without affecting the enforceability of the remaining terms and
     conditions.

  c. No term or condition of this Public License will be waived and no
     failure to comply consented to unless expressly agreed to by the
     Licensor.

  d. Nothing in this Public License constitutes or may be interpreted
     as a limitation upon, or waiver of, any privileges and immunities
     that apply to the Licensor or You, including from the legal
     processes of any jurisdiction or authority.


=======================================================================

Creative Commons is not a party to its public
licenses. Notwithstanding, Creative Commons may elect to apply one of
its public licenses to material it publishes and in those instances
will be considered the “Licensor.” The text of the Creative Commons
public licenses is dedicated to the public domain under the CC0 Public
Domain Dedication. Except for the limited purpose of indicating that
material is shared under a Creative Commons public license or as
otherwise permitted by the Creative Commons policies published at
creativecommons.org/policies, Creative Commons does not authorize the
use of the trademark "Creative Commons" or any other trademark or logo
of Creative Commons without its prior written consent including,
without limitation, in connection with any unauthorized modifications
to any of its public licenses or any other arrangements,
understandings, or agreements concerning use of licensed material. For
the avoidance of doubt, this paragraph does not form part of the
public licenses.

Creative Commons may be contacted at creativecommons.org.


<!-- SOURCE_FILE_END: skills/image/LICENSE -->


<!-- SOURCE_FILE_START: skills/image/NOTICE -->
# SOURCE FILE: `skills/image/NOTICE`

Visual Skills — AI film director skills for Claude agents
Copyright (c) 2026 Serge Shima

Licensed under Creative Commons Attribution 4.0 International (CC BY 4.0).
Any use, copy, or derivative of these skills must credit the author:

  Serge Shima — https://t.me/aimastersme · https://sergeshima.com · https://aimasters.me
  Source: https://github.com/smixs/visual-skills

Full license text: LICENSE file or https://creativecommons.org/licenses/by/4.0/

<!-- SOURCE_FILE_END: skills/image/NOTICE -->


<!-- SOURCE_FILE_START: skills/image/SKILL.md -->
# SOURCE FILE: `skills/image/SKILL.md`

---
name: image
license: CC-BY-4.0 (attribution required — Serge Shima, github.com/smixs/visual-skills)
description: >
  Image prompting skill for Nano Banana (NBP/NB2) and GPT Image 2. Writes ready-to-use
  prompts with model/quality/size recommendations. Use when: "нарисуй", "сгенерируй
  картинку", "image prompt", "промпт для картинки", blog covers, slides, posters,
  product shots, UI mockups, storyboards, character sheets, edit/colorize, style transfer,
  vision analysis, image-to-prompt, nb, NBP, NB2, gpt-image-2, multi-panel grids,
  ecommerce product photography, fashion editorial, food/beverage ads, cinematic portraits.
  Do NOT use for: video (use video skill), 3D models, audio, non-image tasks.
---

# Image Prompting — Nano Banana & GPT Image 2

This skill writes image prompts. It does not generate images. The output is: model name + quality / size / aspect ratio + the prompt itself.

The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone. The actual rules — what the models reward, what they punish, how to phrase a 5-slot template, when to add `quality: high`, when to use image grounding — live only in the reference files.

## Route first — is this actually an image-prompt task?

- **Motion, clips, montage** (Seedance, Kling, Veo, any image-to-video): use the sibling `video` skill. This skill's storyboard and keyframe outputs feed it.
- **No idea or script yet** (user wants a concept or an ad scenario, not a picture): if the `creative-director` skill is installed, start there — it develops ideas and scripts for commercials and beyond ([github.com/smixs/creative-director-skill](https://github.com/smixs/creative-director-skill)).
- **A concrete image is needed** — this skill. Continue below.

---

# Mandatory reading order — DO NOT WRITE A PROMPT WITHOUT THIS

Past attempts to write prompts directly from this skill body produced lazy, generic results. Each model has its own physics; common rules collapse into mush when applied without model-specific syntax. Read in this order before producing any prompt:

### Step 1 — always read first → [models.md](references/models.md)

Decide: Nano Banana (NB2 or NBP) or GPT Image 2. The choice changes the prompt syntax fundamentally — natural-language paragraphs vs. labeled 5-slot template, quality settings, which features exist (image grounding only on NB, EXACT TEXT discipline only on GPT Image, etc.).

If the user named a model — confirm and proceed. If not — pick using the table in `models.md`, then state your choice in the output header.

### Step 2 — read **one** model file (the one you picked)

- **Nano Banana** → [nano-banana.md](references/nano-banana.md)
  Image grounding for real locations. Extreme aspect ratios (1:8, 8:1, 4:1). Thinking mode. JSON for 5+ elements. Up to 14 reference images. Why you must NOT write `50mm / f-stop / ISO` numbers.

- **GPT Image 2** → [gpt-image.md](references/gpt-image.md)
  5-slot template (Scene / Subject / Important Details / Use Case / Constraints). Anti-slop banned-words list. `quality: low / medium / high` as a deliberate fidelity lever. Size constraints (multiples of 16, max 3:1, up to 2560×1440). Two-column edit logic (Change / Preserve / Constraints). Up to 16 reference images with explicit roles.

The model file is non-negotiable. Skipping it is the single biggest cause of weak prompts.

### Step 3 — always read after the model file → [golden-rules.md](references/golden-rules.md)

Universal rules that apply to both models: start with a verb, positive framing, hex colors, quote text, edit don't re-roll, one change per iteration, reference images.

### Step 4 — task-shaped reading (load only what matches the request)

Pick zero or more, depending on what the user asked for:

- Text in image, infographic, diagram, multilingual rendering → [text-rendering.md](references/text-rendering.md)
- Edit existing image (object removal, lighting swap, colorization, restoration, localization) → [editing.md](references/editing.md)
- Character continuity across multiple images / panels → [characters.md](references/characters.md)
- Presentation slides → [slides.md](references/slides.md)
- Sequential narrative (storyboard, comic, panel sequence) → [storyboards.md](references/storyboards.md)
- Sketch → final, wireframes, structural input → [structural.md](references/structural.md)
- 2D → 3D, floor plans, isometric → [dimensional.md](references/dimensional.md)
- **Vision analysis / image-to-prompt / style transfer from a reference image** → [vision-decomposer.md](references/vision-decomposer.md). Load this whenever the user attaches an image and asks to recreate, match, decompose, or transfer its style.
- **Multi-panel compositions** (grids, collages, storyboard sheets in ONE image) → [multi-panel.md](references/multi-panel.md). 9-cell TVC grids, 2x2 portrait grids, 3-panel campaign collages, 4x3 borderless grids, 6-frame cinematic sequences, before/after splits, 12-panel storyboard posters.
- **Industry pattern libraries** — proven prompt templates by vertical. Load the matching file:
  - E-commerce product shots → [patterns/ecommerce.md](references/patterns/ecommerce.md)
  - Fashion editorial campaigns → [patterns/fashion-editorial.md](references/patterns/fashion-editorial.md)
  - Food & beverage advertising → [patterns/food-beverage.md](references/patterns/food-beverage.md)
  - Cinematic portraits → [patterns/portrait-cinema.md](references/patterns/portrait-cinema.md)
  - Posters & illustration → [patterns/poster-illustration.md](references/patterns/poster-illustration.md)
  - Character design (turnarounds, expression sheets, outfit grids) → [patterns/character-design.md](references/patterns/character-design.md)
  - UI mockups & social media formats → [patterns/ui-social.md](references/patterns/ui-social.md)

### Step 5 — read for production language → [creative-direction.md](references/creative-direction.md)

Studio-quality vocabulary for lighting design, camera and hardware, color grading and film stock, materiality and texture. Read when you need precise terms beyond what `golden-rules.md` covers.

### Step 6 — read if structuring a complex prompt → [prompt-framework.md](references/prompt-framework.md)

Universal element checklist (subject, context, action, environment, camera, lighting, mood, materials, palette, format), detail modes (concise / standard / verbose / cinematic verbose), parameterized templates, output structure with parameters and exclusions.

---

# Output format

When you return the prompt, structure it like this:

```
Model: <nano-banana-2 | nano-banana-pro | gpt-image-2>
Quality: <low | medium | high>          (only for gpt-image-2)
Size / Ratio: <e.g. 1536×1024 or 16:9>

Prompt:
<the prompt text, ready to copy>

Notes:
- <anything you inferred or assumed because the user did not specify>
```

For edits, also include an explicit preserve-list (mandatory for gpt-image-2, recommended for nano-banana):

```
Change: <one concrete thing>
Preserve: <face, pose, lighting, framing, geometry, ...>
Constraints: <no extra objects, no drift, ...>
```

---

# Final response style

Prefer: ready-to-copy prompts, hex colors, concrete materials, named compositions, model-specific syntax (5-slot for GPT Image, natural prose for Nano Banana).

Avoid: tag soup ("cool, modern, 4k"), vague praise ("stunning, epic, masterpiece" — actively hurts GPT Image 2), negative framing ("no people, no cars" — invert to positive), external comparisons ("like Apple ad" — describe the visual properties instead), numerical lens parameters in Nano Banana prompts (it ignores them).

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/SKILL.md -->


<!-- SOURCE_FILE_START: skills/image/references/characters.md -->
# SOURCE FILE: `skills/image/references/characters.md`

# Character Consistency

Up to 14 reference images (6 high-fidelity). Identity locking across scenes.

## Identity Locking

```
Using person from [IMAGE REFERENCE]:
Keep facial features exactly the same.
Change: [EXPRESSION / POSE / CLOTHING / SETTING]
Maintain: identity, recognizable features
```

Key phrase: "Keep facial features exactly the same as Image 1"

## Viral Thumbnails

```
Design viral thumbnail using person from Image 1.

Face: Keep features same, change expression to [excited/surprised/shocked]
Action: Pose on [left/right], pointing toward [OBJECT]
Subject: [OBJECT] on opposite side
Graphics: Bold [COLOR] arrow connecting person to object
Text: "[HEADLINE]" in massive pop-style, white outline, drop shadow
Background: Blurred [SETTING]

High saturation and contrast.
```

## Multi-Character Consistency

```
Create [NUMBER]-part story with these [N] characters.

Identity: Keep attire and features consistent throughout.
Variation: Different angles, expressions, distances per image.
Rule: Only one of each character per image.

Story arc: [DESCRIPTION with emotional highs/lows]
```

## Brand Asset Generation

```
Using this [PRODUCT] as reference:
Create [NUMBER] [TYPE] shots.

Maintain: Brand consistency, quality level
Vary: Angles, lighting, context
Style: [editorial / lifestyle / product]

Generate one at a time.
```

## Expression Control

While maintaining identity:
- "Change expression to excited and surprised"
- "Make them look thoughtful, gazing left"
- "Add confident smile, direct eye contact"

## Pose/Action Control

- "Pose pointing finger toward [DIRECTION]"
- "Standing with arms crossed"
- "Mid-stride, dynamic motion"
- "Seated, leaning forward"

## Attire Changes

- "Same person, but wearing [NEW OUTFIT]"
- "Keep face, change to formal business attire"
- "Maintain identity, add [ACCESSORY]"

## Environment Swaps

- "Same person in [NEW SETTING]"
- "Transport to [LOCATION], keep identity"
- "Change background to [SCENE], maintain lighting on face"

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/characters.md -->


<!-- SOURCE_FILE_START: skills/image/references/creative-direction.md -->
# SOURCE FILE: `skills/image/references/creative-direction.md`

# Creative Direction

Studio-quality controls for lighting, camera, color, and materiality.

## Lighting Design

Tell the model exactly how the scene is illuminated.

**Studio setups:**
- "Three-point softbox setup" — even product/portrait lighting
- "Single key light from upper left" — dramatic shadow
- "Ring light, frontal" — beauty/fashion, flat lighting

**Dramatic effects:**
- "Chiaroscuro lighting with harsh, high contrast"
- "Golden hour backlighting creating long shadows"
- "Rim lighting, subject silhouetted against bright background"
- "Volumetric god rays through window"
- "Neon underglow, cyberpunk street"

**Natural:**
- "Soft overcast daylight, even diffusion"
- "Dappled sunlight through trees"
- "Blue hour, cold ambient light"

## Camera & Hardware

Specify camera type to change the visual DNA of the image.

**Hardware names that work:**
- GoPro — immersive, wide-angle distortion, action feel
- Fujifilm — authentic color science, warm tones
- Disposable camera — raw, nostalgic flash aesthetic, grain
- Hasselblad — medium format, shallow DOF, fashion/portrait
- iPhone — casual, smartphone aesthetic
- Polaroid — instant film, white border, faded colors

**Angles:**
- "Low angle" — power, drama
- "Aerial view" / "bird's eye" — scale, pattern
- "Eye-level" — neutral, relatable
- "Dutch angle" — tension, unease
- "Worm's eye view" — extreme drama

**Shot types:**
- Close-up, medium shot, wide shot, extreme close-up
- "Waist-up portrait", "full body", "over-the-shoulder"

**Focus:**
- "Shallow depth of field" — blurred background
- "Deep focus" — everything sharp
- "Rack focus" — shift attention
- "Tilt-shift" — miniature effect

> Note: Named lens parameters (50mm, f/2.8) are less reliable than
> descriptive terms. Prefer "shallow depth of field" over "f/1.8".

## Color Grading & Film Stock

Set emotional tone through color and texture.

**Film stocks:**
- "Shot on 1980s color film, slightly grainy" — nostalgic
- "Kodak Portra 400" — warm skin tones, pastel highlights
- "Fuji Velvia" — hyper-saturated, vivid
- "Ilford HP5" — classic B&W grain
- "Cinestill 800T" — tungsten, halation around lights

**Digital grades:**
- "Cinematic color grading with muted teal tones"
- "High contrast, desaturated" — gritty, editorial
- "Warm analog tones, lifted blacks" — vintage
- "Cool blue shadows, warm highlights" — modern cinema
- "Cross-processed, shifted greens" — experimental

## Materiality & Texture

Define physical makeup of subjects. Don't just say the thing — describe what it's MADE of.

| Vague | Specific |
|-------|----------|
| "a suit" | "navy blue tweed suit, visible weave" |
| "armor" | "ornate elven plate armor, etched with silver leaf patterns" |
| "a mug" | "minimalist ceramic coffee mug, matte glaze, slight imperfections" |
| "skin" | "weathered, sun-damaged skin, deep expression lines" |
| "metal" | "brushed steel with matte finish, fingerprint smudges" |

**Surface properties:**
- Matte / glossy / satin
- Rough / smooth / textured
- Translucent / opaque / refractive
- Worn / pristine / aged / patinated

## Creative Prompt Examples

**Cartoon Portrait (3D + Real):**
```
Based on the uploaded reference image, create a photorealistic scene
featuring the real human standing next to a giant 3D animation-style
version of themselves. Both must have identical facial structures,
clothing, and poses. Clean gray-blue studio background, cinematic lighting.
```

**Animation → Photorealistic:**
```
Convert this uploaded animated still into an ultra-realistic, cinematic
scene. Transform the animated characters into real humans while preserving
their original identities, facial structures, outfits, and expressions.
```

**Historical Maps (Google Street View style):**
```
Generate a hyper-realistic image of [HISTORICAL EVENT], perfectly
replicating a Google Maps Street View capture. Include wide-angle barrel
distortion, semi-transparent Maps UI overlay (compass, chevron arrows),
and '© Google [YEAR]' watermark. Automatically blur faces for privacy.
```

**Kindergarten Filter:**
```
A child's crayon drawing on white lined notebook paper of [SUBJECT].
Use chunky wax-crayon strokes, wobbly outlines, bold colors that overflow
the lines. Visible pressure marks, waxy smudges, uneven scribble shading.
Joyful, naive art style.
```

**Fashion Editorial:**
```
[Subject description]. [Action/pose]. [Setting].
Medium-full shot, center-framed.
Fashion magazine style editorial, shot on medium-format analog film,
pronounced grain, high saturation, cinematic lighting effect.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/creative-direction.md -->


<!-- SOURCE_FILE_START: skills/image/references/dimensional.md -->
# SOURCE FILE: `skills/image/references/dimensional.md`

# Dimensional Translation

2D↔3D conversions. Floor plans to renders, memes to 3D.

## 2D Floor Plan → 3D

```
Based on this 2D floor plan, generate interior visualization.

Layout: Design board format
Main image: Wide-angle [ROOM] perspective (top 60%)
Below: 3 smaller renders - [ROOM A], [ROOM B], [ROOM C]

Style: [Modern minimalist / Scandinavian / Industrial]
Materials: [flooring], [walls], [textiles]
Lighting: Soft natural light, large windows
Quality: Photorealistic rendering
```

## Sketch → 3D Concept

```
Convert this sketch into [STYLE] visualization.
Perspective: [CAMERA ANGLE]
Lighting: [SETUP]
Quality: [photorealistic / stylized / rendered]
```

## 3D → 2D Technical

```
Flatten this 3D scene into [STYLE].
Views: [plan / elevation / section]
Labels: [ANNOTATIONS]
Line work: technical, precise
```

## Meme Conversion

```
Turn "[MEME NAME]" meme into [NEW STYLE].
Keep composition identical.
Character: [plush toy / realistic / cartoon]
Environment: [realistic flames / stylized / etc]
```

Example:
- "Turn 'This is Fine' dog into photorealistic 3D render"
- "Make the dog look like plush toy, fire realistic"

## Architectural Visualization

**Exterior:**
```
Generate exterior visualization from this elevation.
Time: [dawn / midday / dusk / night]
Weather: [clear / overcast / dramatic clouds]
Context: [landscaping / street / aerial view]
```

**Interior:**
```
Generate interior from this plan.
View: [living area / kitchen / bedroom]
Style: [AESTHETIC]
Lighting: [natural / artificial / mixed]
Props: [furniture / decor / people]
```

## Product 2D → 3D

```
Convert this flat design into 3D product mockup.
Material: [plastic / metal / fabric / glass]
Lighting: [studio / environmental]
Angle: [front / 3-quarter / top-down]
```

## Quality Levels

- "Sketch quality" - rough, conceptual
- "Presentation quality" - clean, professional
- "Photorealistic" - indistinguishable from photo
- "Stylized render" - artistic interpretation

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/dimensional.md -->


<!-- SOURCE_FILE_START: skills/image/references/editing.md -->
# SOURCE FILE: `skills/image/references/editing.md`

# Image Editing

Универсальные паттерны. Логика edit'а различается по моделям:

- **Nano Banana:** conversational, без масок. «Keep X same, change Y». Хорошо понимает физику и материалы.
- **GPT Image 2:** двухколоночная логика **Change / Preserve / Constraints**. Preserve list повторять каждую итерацию, иначе drift. Опционально `mask_image_url` для точечных edit'ов. Лучшая identity preservation. См. [gpt-image.md](gpt-image.md#editing--двухколоночная-логика).

Общее правило: **один edit за итерацию**, не пытайся менять всё разом.

## Object Removal
```
Remove [OBJECT] from this image.
Fill with [LOGICAL REPLACEMENT] matching surroundings.
Keep [PRESERVED ELEMENTS] exactly the same.
```

Examples:
- "Remove tourists, fill with cobblestones"
- "Remove car, extend street naturally"

## Object Addition
```
Add [OBJECT] to this image.
Position: [LOCATION]
Style: matching existing lighting
Scale: [RELATIVE SIZE]
```

## Lighting Control
```
Change lighting to [NEW LIGHTING].
Keep subject and composition same.
```

Vocabulary:
- Golden hour / sunset / warm backlight
- Overcast / soft / diffused
- Night / dramatic / single source
- Rim lighting / silhouette

## Seasonal/Weather
```
Turn scene into [SEASON/WEATHER].
Keep architecture exactly same.
Adjust: [snow/leaves/reflections/sky]
```

## Colorization

**Photo:**
```
Colorize this B&W photograph.
Era-appropriate colors for [DECADE].
Skin tones: natural, realistic
```

**Manga:**
```
Colorize this manga panel.
Style: [vibrant anime / muted realistic]
Effects: [glowing/neon] for energy elements
Maintain: line art integrity
```

## Restoration
```
Restore this damaged photograph.
Fix: [tears/scratches/fading/stains]
Enhance: sharpness, contrast
Preserve: original character and grain
```

## Localization
```
Translate all [SOURCE] text to [TARGET].
Keep everything else same.
Maintain: font style, sizing, position
```

Cultural adaptation:
```
Localize this [ORIGINAL] ad to [TARGET MARKET].
Background: [NEW LOCATION]
Translate: text to [LANGUAGE]
Keep: brand elements, core composition
```

## Physics-Aware

NBP understands materials:
```
Fill this glass with [LIQUID].
Add: refraction, meniscus, condensation
Match: existing lighting
```

```
Add [MATERIAL] texture to [SURFACE].
Properties: [matte/glossy], [rough/smooth]
```

## Conversational Refinement

After initial edit:
- "Make it warmer"
- "Increase contrast"
- "Soften the edges"
- "Add more detail to shadows"

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/editing.md -->


<!-- SOURCE_FILE_START: skills/image/references/golden-rules.md -->
# SOURCE FILE: `skills/image/references/golden-rules.md`

# Golden Rules

Универсальные принципы. Работают для **обеих** семей моделей (Nano Banana и GPT Image 2).
Для модельной специфики см. [nano-banana.md](nano-banana.md), [gpt-image.md](gpt-image.md).

## 1. Start with a Verb

Tell the model the primary operation: "Create", "Generate", "Design", "Transform", "Convert", "Edit". This sets the intent before details.

## 2. Positive Framing

Describe what you WANT, not what you don't want. The model understands presence better than absence.

- ✅ "empty street" → ❌ "street with no cars"
- ✅ "clean background" → ❌ "no clutter"  
- ✅ "solo portrait" → ❌ "no other people"

## 3. Edit, Don't Re-roll

Image 80% correct? Request specific change:
- "Change lighting to sunset"
- "Make text neon blue"
- "Move chart to right third"

## 4. Natural Language

❌ Bad: "Cool car, neon, city, night, 8k"
✅ Good: "A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. Neon signs reflect off wet pavement and metallic chassis."

## 5. Be Specific

| Element | Vague | Specific |
|---------|-------|----------|
| Subject | "a woman" | "sophisticated elderly woman in vintage Chanel-style suit" |
| Material | "shiny" | "brushed steel with matte finish" |
| Color | "dark green" | "#0d3d2d deep emerald" |
| Position | "on the right" | "right third, bleeding off edge" |

## 6. Provide Context

Context helps model make logical decisions:
- "for Brazilian gourmet cookbook" → infers professional plating, shallow DOF
- "for executive strategy presentation" → infers corporate aesthetic
- "for children's educational app" → infers friendly, colorful style

## 7. Quote Text Exactly

Any text for rendering goes in quotes:
- "[HEADLINE TEXT]"
- Labels: "[Revenue Growth]", "[Net Income]"
- Specify weight: bold, thin, extra bold
- Specify position: "upper third", "centered"

## Prompt Template

```
Create a [TYPE] for [CONTEXT].

Background: [Description with hex colors]. [Atmospheric effects].

[HERO ELEMENT]:
[Detailed description - position, lighting, angle]

Typography:
Line 1: "[TEXT]" in [weight], [color], [size], [position]
Line 2: "[TEXT]" in [weight], [color], [size], [position]

[ADDITIONAL ELEMENTS]

Mood: [Emotional descriptor]
Format: [ASPECT RATIO]
```

> **Thinking Mode** (NB only), **`quality: low/medium/high`** (GPT Image 2 only) — см. соответствующие references.

## Cost Optimization (Batch Work)

- **Nano Banana:** прогон вариантов на `0.5K` Flash → отбор → переген победителя на `2K`/`4K`.
- **GPT Image 2:** прогон на `quality: low` → отбор → переген на `medium` или `high`.

В обоих случаях: дешёвая разведка → дорогой финал.

## Conversational Refinement

After generation:
- "Change the headline color to #3b82f6"
- "Add subtle drop shadow to text"
- "Increase contrast, make it more dramatic"
- "Soften the background, add blur"

## Reference Images

Multi-image вход: **NB до 14**, **GPT Image 2 до 16**. Индексируй с ролью каждой картинки.

Используй для:

**Вписать в существующий дизайн:**
```
[Attach design/layout image]
Create content following this exact layout and style.
Replace [ELEMENT] with [NEW CONTENT].
Keep colors, typography, composition.
```

**Лицо/персонаж как референс:**
```
[Attach portrait]
Use this person's face. Keep features exactly the same.
Change: [expression/pose/setting]
```

**Продукт/объект как референс:**
```
[Attach product photo]
Place this product in [NEW CONTEXT].
Match lighting and perspective.
```

**Стиль как референс:**
```
[Attach style reference]
Create [NEW CONTENT] in this exact visual style.
Match colors, textures, mood.
```

**Несколько референсов сразу:**
```
[Attach Image 1 - face]
[Attach Image 2 - outfit]
[Attach Image 3 - background]
Combine: face from Image 1, outfit style from Image 2, setting from Image 3.
```

## World Knowledge Anchors

GPT Image 2 обладает глубокими знаниями о культуре, эпохах и визуальных стилях. Вместо описания каждой детали — дай модели культурный/временной/жанровый якорь, и она сама заполнит аутентичные детали.

### Три типа якорей

**Era anchors** — временной и географический маркер, который вызывает целый визуальный мир:
- "Bethel, NY, August 1969" → Woodstock aesthetic без необходимости описывать тай-дай, грязь, сцены
- "Berlin, November 1989" → падение стены, толпы, граффити, эйфория
- "Tokyo, 1982" → неоновый Shinjuku, аналоговая электроника, ранний cyberpunk

**Cultural anchors** — перенос визуального языка одного культурного объекта на другой контекст:
- "{game_title} in {real_city}" → автоматически применяет визуальный стиль игры к реальной локации (GTA style, Persona style, и т.д.)
- "Soviet constructivism poster about {modern_topic}" → стиль Родченко/Эль Лисицкого на современную тему
- "Ukiyo-e print of {modern_scene}" → японская гравюра с современным содержанием

**Genre anchors** — режиссёр/фотограф/движение как линза:
- "Peter Lindbergh influence" → сильный Ч/Б, минимальная ретушь, raw editorial
- "Wes Anderson palette" → симметричный кадр, пастельная палитра, центрированная композиция
- "Studio Ghibli mood" → мягкое акварельное небо, зелёная листва, тёплый ностальгический свет
- "Roger Deakins lighting" → натуральный свет, глубокие тени, кинематографичный объём

### Правила использования

1. **Используй как HIGH-LEVEL steering** — якорь задаёт настроение и эстетику, а не заменяет весь промпт
2. **Комбинируй с конкретными визуальными деталями** — якорь устанавливает мир, детали устанавливают специфику
3. **Не стакай несколько genre anchors** — выбери один. "Peter Lindbergh + Wes Anderson" = каша
4. **Era/cultural anchors работают лучше с GPT Image 2** (world knowledge). С Nano Banana результат менее предсказуем — NB больше опирается на явные описания

### Примеры

**Era anchor + конкретные детали:**
```
Create an editorial portrait set in Havana, 1957.

Subject: jazz musician leaning against pastel-colored colonial building,
holding trumpet loosely at his side. Linen suit, open collar.
Lighting: harsh Caribbean afternoon sun, deep shadows under awning.
Format: 3:4
```
> "Havana, 1957" вызывает: старые американские машины на заднем плане, облупившаяся штукатурка, кованые балконы, тропическая атмосфера — без необходимости это описывать.

**Cultural anchor + новый контекст:**
```
Create a scene of a quiet Kyoto temple garden, rendered in the visual style
of Studio Ghibli. Morning mist over moss-covered stones, a single monk
sweeping fallen maple leaves. Soft watercolor textures, warm nostalgic palette.
Format: 16:9
```
> "Studio Ghibli" задаёт акварельность, теплоту, ностальгию. Детали (мох, клён, монах) задают конкретную сцену.

**Genre anchor + специфика:**
```
Create a fashion editorial portrait with Peter Lindbergh influence.

Subject: model in oversized men's blazer, no makeup, wind-tousled hair.
Setting: empty winter beach, overcast sky.
Mood: raw, unpolished beauty
Format: 2:3
```
> "Peter Lindbergh influence" даёт: мощный Ч/Б (или desaturated), отсутствие ретуши, raw emotional quality. Детали (пляж, блейзер, ветер) конкретизируют кадр.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/golden-rules.md -->
