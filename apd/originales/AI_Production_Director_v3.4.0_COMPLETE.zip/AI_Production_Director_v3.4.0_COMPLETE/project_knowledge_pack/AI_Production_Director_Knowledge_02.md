# AI Production Director — Knowledge Pack 2/7

Generated from `aiproductiondirectorcompleto.zip`.
Each source file is preserved with its original relative path.


<!-- SOURCE_FILE_START: repo/nblm-ids/video.md -->
# SOURCE FILE: `repo/nblm-ids/video.md`

# Reglas del skill: video

348 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## video/SKILL.md

- [2d5d435df3ef] **Still keyframes, character sheets, animatic panels** to feed the video pipeline: use the sibling `image` skill, then return with the keyframes.
- [bc478afe5b70] U1–U12 universal rules that apply to every video model: prompt skeleton, weight-at-start, show-don't-tell, lens language, character anchor, contradictions, duration discipline, final image rule, three-detail check.
- [534cc7500424] Use this short selector. The full reasoning is in the chosen file.
- [3eac07a0a838] For a more detailed comparison (max clip length, audio support, character lock methods, motion brush, etc.), read the model file you picked. Do not load all three.
- [f21bcfe2dfbc] If any shot fails, fix before sending. This is the step the user has had to enforce repeatedly. Do not skip it.
- [99b3186877c9] Prefer: ready-to-copy prompts, clear section labels, production language, motivated camera and light direction, strict continuity blocks, model-specific syntax, direct fixes.
- [54b8e873fa4e] Avoid: long theory unless asked, academic lectures, vague inspiration, decorative jargon, "cinematic masterpiece" filler, prompts without camera and light, prompts without continuity, stacking more than two director references, abstract emotions without physical translation.

## video/references/animatic-keyframes.md

- [1abf520d87fe] This is the still-panel layer. A storyboard keyframe is not a frame grab of footage — it is a single drawn image that must carry one story-beat with **no motion and (usually) no face**. The animatic hangs off these panels. A panel that only looks good is wallpaper; a panel must report its story function, its drama, and the motion it cannot show, all frozen.
- [b19568241a2e] What an animatic keyframe must do
- [08a797245f8c] The keyframe card (a still extension of the shot card)
- [423028c059a7] How many keyframes per beat (density ladder)
- [540c8325a473] Composing a still that reads as MOTION
- [9a75e498f8a5] Emotion without faces in a still
- [f112ae392b0f] The loaded frame for one panel
- [8a00af193f34] From keyframe to image-gen prompt
- [739f6cf3bb40] Worked keyframe board for a 30s race spot
- [0715fd2a94e1] Checklist: does this keyframe earn its place
- [24fe340cb58e] In an animatic the **panel is the unit, not the shot.** A shot has duration, motion, and sound to carry its function across time. A keyframe has one frozen image and must carry the same function in a single glance. So every panel does four things at once, in one still:
- [43a9c422d34f] **One emotion** — routed through metal, rubber, light, or anatomy, never named (`dramaturgy.md` §2). Mixed signals = no signal.
- [b9cd34ffcb70] **Ritual / staging** (quiet) | 1 hero panel, held | 1 panel living 1.5-2.5s | A silent beat is monolithic. Do not subdivide it — its power is that nothing moves while the world holds its breath. One symmetric "breath" frame, most negative space, least motion.
- [b04a79b44100] **Contest** (sustained roar) | alternating | fragment-cluster ↔ one held detail | Never two bang-clusters back to back. Between every burst, one held quiet panel — loud only works next to quiet.
- [6d32d7171722] **Allocation rule.** A 30s spot lands at ~18-26 panels. Plot the board as a descending duration staircase (≈2.5s → 0.5s → 4fr), broken only by the one pre-launch pause and the one post-finish hold. The board should *read* as an accelerating tachometer even on mute. Give a beat a micro-burst only when the audio detonates; everywhere else, one panel that holds is stronger than three that scatter.
- [0fb332eaeff4] A keyframe cannot ramp, cut, or whip. Each missing move resolves into one of **six frozen cues**. Never write "motion" — write the artifact motion leaves behind. State the cue in the card's *Motion-as-still* field and again in the prompt's camera/light clause; models default to over-clean stabilization and will sand the speed off unless told (§7).
- [84e4c557c5f1] **Sharp-subject / blurred-field separation** | Shallow-DOF macro: knuckle, needle, latch razor-sharp, everything else dissolved. Isolation = the cut-to-detail frozen. | insert chain, crash-zoom arrival, hip-hop CU
- [9116b6b7205f] A face does four jobs: shows the feeling, shows where it looks, shows the cost, shows the decision. Faces banned, redistribute: **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space** (§6 and `dramaturgy.md` §2). Assign one job per panel and tag it. The emotion must already be frozen *inside the object* — a still cannot let motion blur do the emo
- [22aed852b261] Use the substitution table as the core deliverable — when the script wants an emotion and no face is available, render this object at this crop. Cold palette throughout.
- [5bea8ddfb87c] **Depth-layer jobs (FG / MG / BG).** Write the prompt in three explicit depth clauses, each with a stated job. This is the engine of "reads in one glance, rewards a second" (extends `dramaturgy.md` §10 into a single still). If all three planes carry the same blur or scale, you have one plane, not three — force a sharp MG subject against a soft FG frame and a soft BG stake (shallow DOF is the panel
- [c241a02cc037] **Centerline spine, then break symmetry** — emotion: a single dominant axis (lane stripe, the Christmas Tree, a dividing wall) gives the eye a rail and makes even a chaotic frame readable; breaking it the instant one car noses ahead reads as momentum. — seen: Anderson centers for instant legibility; Bong breaks balanced staging to show a power shift. — *in a keyframe*: build one head-on symmetric 
- [921f5446334f] **Render audio as physical consequence, never as a named sound.** "Loud engine" is banned filler (`dramaturgy.md` §2) — prompt "heat-haze warp off the headers, exhaust flame, chassis squat, sidewall wrinkle" instead.
- [d5feae1b60b8] [ ] **Cold palette held** — steel/cyan/magenta/mercury-white, red and green as accents only, amber ≤15% and point-source (toxic, never cozy). One motivated source, ~70% unlit, one hard specular hit. Texture named (grain, halation, one flare), not "clean."

## video/references/camera-lighting-vocabulary.md

- [6f5a79ae61af] Use precise production language. "Cinematic" is not a direction. "35mm, slow push-in, warm window key from frame-left" is.
- [a7a4a415739c] Camera movement
- [d2fdc95e0774] Lens language
- [452aeff5a606] Light sources
- [1fdefb1f03d2] Light direction
- [a7625f9fa01e] Light quality
- [26fe42ae15f1] Color discipline
- [a2b7cd269ef9] Sound categories
- [9fb5a7cc627c] Blocking language
- [5e6379d739b9] Translating uncommon terms
- [1a3ede808e84] Transition vocabulary
- [617b9596ef1d] over-the-shoulder
- [a3c2614e6e5e] shallow depth of field.
- [84e552ce62b9] Define palette with concrete colors. Never write "cinematic colors."
- [0278247a92b4] Rules of use. Name the transition and the exact moment it fires. One transition type per cut. When the choice is open, delegate: "choose the most suitable from [natural cut / occlusion mask / match cut] for the style of this film."

## video/references/dramaturgy.md

- [4594046fc713] This is the mandatory layer. A beautiful frame without dramaturgy is wallpaper. Every prompt built by this skill must pass the dramaturgy check before it is sent to the user.
- [95308d522567] Core law. Scene formula
- [3a40b663b7a0] Second law. Details intensify emotion
- [25b46aacc27f] The three-jobs rule (what every shot must do)
- [400ac520404a] Walter Murch Rule of Six
- [9ee967da1e9e] Blocking as choreography of desire
- [d77273af9f2d] Staging controls subtext
- [24f71a932bee] Camera must have a reason
- [9a6465045388] Spatial clarity beats montage hysteria
- [5c6aa86c10f3] Environment plays
- [c5709d6c31d8] Three-layer storyboard method
- [19420f877e9d] Shot card template (14 fields)
- [e41ee886f6b0] Rhythm ladder
- [1817511ea8d5] One-anchor principle
- [33dfbb40658d] Worked example
- [bea9522cf143] Dramaturgy check before sending any prompt
- [f2664fed4b35] The scene formula tells you **what a scene is**. The Details Law tells you **how every shot must be written**. Skip it and even a perfect dramaturgical structure produces mush on screen.
- [fe8ae4c731e8] **Environmental pressure.** A physical fact about the space that carries the emotion. Cold refrigerator light. Wet asphalt. Flickering ceiling tube. Steam from the kettle. Rain on one specific windowpane. A buzzing AC unit. Tight corridor walls. Mirror reflection. (See §9 — Environment plays.)
- [291a35a705ad] **Physical micro-action on the body.** The emotion translated into the actor's body. Jaw locks. Knuckles whiten. Lips press flat. Eyes drop a quarter-inch. He swallows hard. Fingers curl against the doorframe. The actor's body is the only place where feelings render — names of feelings do not.
- [adc3e3d51477] **Sound anchor or visual motif.** A recurring perceptual hook tied to the spine of the piece. Stomach growl repeated three times. Reflection in dark glass on every transition. The same musical sting at every Crack beat. The clock's second hand. Footsteps in an empty corridor.
- [435fff89e7d5] Every shot must do at least one of three things. If it does none, delete it.
- [dbb9069efcc9] **Emotion (51%).** Does the cut honor the emotional truth of the moment. What does the viewer feel now vs. what they should feel next.
- [5d494f11d5ec] **Story (23%).** Does the cut advance story or reveal character.
- [09ecf6f81ee5] **Rhythm (10%).** Does the cut fall on a musical beat of the scene.
- [94cb46e0cdd8] **Eye-trace (7%).** Where is the viewer's gaze at the moment of the cut. Does the new shot receive that gaze naturally.
- [0cf6378a2c57] **2D plane (5%).** Does the cut respect the axis of screen direction.
- [dd109f775c6c] **3D space (4%).** Does the cut respect the geometry of the real location.
- [5b4e8d3dcda1] Good. "He edges toward the window but his shoulder stays angled back toward her, as if the conversation still holds him."
- [2be8adc698a8] Good. "Push-in starts on 'I don't know' and stops on her jaw locking."
- [c7fa86763233] Spielberg principle. Even in chaos, the viewer must know.
- [f88d89dd2268] Adjust for 30s or 15s by compressing proportionally. Never skip the Crack or the Impact.
- [6be9ddc67dea] **Eye trace.** Where the viewer's gaze should land in the first 0.3s.
- [c2e0a3b45412] Always insert at least one pause before the biggest cut.
- [01d9db058ef3] Is the scene formula complete? (desire + obstacle + geometry + gaze + rhythm)
- [75eee4c9c72b] Does every shot pass the three-detail check? (environmental pressure + physical micro-action + sound or visual motif)
- [c52b9a2cbc96] Does every shot do one of the three jobs? (change emotion, advance action, increase pressure)
- [cd71da05d199] Is there a motivated reason for every camera move?
- [e51237770b8c] Is the spatial geometry readable?
- [eba7494935d3] Are the five anchors named? (emotion, motif, object, break, final image)

## video/references/fixes-and-skeletons.md

- [f1203c349d53] Continuity checklist (before final output)
- [14470e6ae37c] Common failures and fixes
- [43f2bc69865a] Cross-model prompt skeletons
- [a06a62cee7b4] Default negative constraints
- [8bc62af4ced4] Prompt compression order
- [db96b8a465b2] Output format templates
- [4ddd5b7aae62] For Kling. Use Element Binding with 3-4 reference images (front, side, three-quarter).
- [1df0239fdbc2] For Seedance and Veo. Use positive phrasing.
- [87d2484dd6cf] Fix. Avoid style words like "hyperrealistic 8k masterpiece." These push the model into AI-art territory. Use production language instead.
- [1863ac937570] For forward extensions, the standard clause: "prohibit rigid cutting, prohibit objects appearing out of thin air."
- [d98803cf48d0] On Seedance 2.5 and Veo this is reliable. On Seedance 1.x/2.0 and Kling, also avoid mentioning any on-screen text or score you do not want — mentions summon them.
- [8f83dc97e5ba] Keep character continuity.
- [8ea66f62d954] Keep story action.
- [13635ca633f1] Keep shot timecodes (where relevant).
- [508966ae84b9] Keep lighting.
- [7dabe8b7b479] Keep camera.
- [b755a79d8702] Keep editing grammar.
- [2d6cacf87d0d] Remove philosophy and meta-commentary.
- [c485717d92a0] Remove extra adjectives.
- [f1cf3ccb4d13] Remove director references.
- [a7febb0fdf00] One ready-to-copy prompt for one generation. Use the appropriate model skeleton.
- [0f1c2fb96c3b] What breaks generation.
- [61f2696d823a] Missing direction (camera, light, continuity).
- [2a25c3da0b7a] Continuity risks.
- [179286c8c088] Model-specific mismatches (wrong syntax for the chosen model).
- [c16f3957c655] Stronger version. Rewritten prompt, ready to copy.
- [a82de4fa4979] Structured scene-by-scene JSON. Use for complex continuity. See `references/veo.md` section 6.

## video/references/kling.md

- [406d3cf655f8] What Kling is
- [e32d756b9d44] Versions and element limits
- [d85e439effb2] **Kling 3.0 — multi-shot, native audio, 15s (read first if user is on 3.0)**
- [e5e68045785e] Prompt formula (1.x – 2.x)
- [6b227126404d] Prompt length by model
- [fe84285ad428] Negative prompts (dedicated field, special rule)
- [3ed6dc5cff5c] Element Library and Element Binding (unique to 1.x – 2.x)
- [c1683b579e07] Motion Brush (unique)
- [7861ecb7da9e] Motion Control (2.6 Pro, unique)
- [ea18941fcff5] Image-to-video rule
- [b3d6ee7d8633] Failure modes and fixes
- [351002a931a9] Skeleton and example
- [0809eafc4ffb] Introduce every character and key object at the **start** of the prompt, before any shot description. Use unique consistent identifiers — the same label survives across all shots:
- [bb25b6a212a2] Each shot must answer: **framing + subject + motion**. Empty shot descriptions ("static frame, ambient mood") collapse into one continuous take.
- [71e86bdfe510] **P1. Structured naming.** Use unique identifiers per character.
- [a4313d46162b] ✓ `[Character B, clear fearful voice]: "Don't open it."`
- [9e30b0899784] **P4. Temporal control between lines.** Use linking words to prevent dialogue from merging.
- [7d81fcd5ccc0] ✓ "Character A: 'I won't ask again.' **Immediately,** Character B: 'You don't have to.'"
- [21472873e0ca] Use these terms directly — the model treats them as instructions, not flavor:
- [c9b8d9532823] In the Kling app, Master Shot presets ("Move Forward and Zoom Up" etc.) are more stable than hand-written camera prose and save credits — prefer them for standard moves, prose for motivated ones.
- [4286109b9522] If the task hits any of these — **use Kling 3.0 over earlier Kling**:
- [2fed8a69d2f5] Lip-sync required
- [87d3fe34072e] Image-to-video where text on the image must stay legible
- [8b8795ac59fd] `duration` — per-shot durations must sum to ≤ 15s.
- [eeae0374284b] For Kling 3.0, use the multi-shot structure from section 3 instead.
- [5c7946d7fd9f] Kling has a dedicated negative prompts field. The field auto-interprets input as exclusion. Do not write "no X". Write the thing itself.
- [d5c7cfa8e640] Required angles.
- [15b3f8595289] Even lighting. Avoid hard shadows. The AI can mistake them for permanent facial features.
- [7a47e689454a] A character element takes either a **3-8s video** (the model extracts both appearance and voice) or up to **4 multi-angle stills** (front, three-quarter, profile, back), plus optional **voice binding** (5-30s audio clip). Once bound, the voice belongs to the subject — do not re-describe it in the prompt.
- [d94be792c74d] Cost of the feature: several practitioners report visible image-quality degradation the moment elements/references are enabled. Use elements only when consistency actually matters; for one-off clips, in-prompt labels are cleaner.
- [0db6e0a2de52] Critical rule. The text prompt MUST match the brush motion. If you brush a river flowing and write "stagnant pond" the model tears itself apart. Align prompt verbs with brush directions.
- [1e5d66901508] Copy motion from a reference video. Use when you need specific performance or choreography (dance, martial arts, specific gait). The prompt then focuses on subject description only, the reference handles motion.
- [36686df1386d] Keep the prompt short (20-40 words). Focus only on motion. Do not re-describe static elements the model already sees.
- [7d3ab7f4ba2a] Fix. Upload 3-4 reference images to Element Library. Use Bind Elements in the settings.
- [cf73cec68544] Fix. Make shot boundaries explicit: `Shot 1 (0-3s). ... Shot 2 (3-6s). ...`. Each shot description must include a different framing or camera angle. If two adjacent shots share both framing and angle, the model merges them.
- [85c33c12c479] Fix. Strip references to the essential ones only; for one-off clips prefer in-prompt `[Character A: ...]` labels over elements. Accept the trade: elements buy consistency, not fidelity.
- [4b9361768f1a] Fix. Give each character its own element (or its own labeled identity block). Never let two speaking characters share one visual description.

## video/references/patterns-and-genres.md

- [91af7aa3fb0b] Montage patterns (6 ready structures)
- [cb4a0202d81c] Genre modules (7 archetypes)
- [407248020546] Multi-clip story structure
- [f876e8f2e5cb] Use for tension builds, reveals, dramatic emphasis.
- [5a27254127bb] Use for psychological pressure, internal conflict, impending bad news.
- [5465eb46d054] Use for revealing a hidden element, exploration, search.
- [240a672f7a78] Use for comedic or dramatic disaster. Tiny object failures play bigger than explosions.
- [5eaea7d005f0] Use for ads with a hero product.
- [4c683ca1e1ef] Use for rhythmic repetition, transformation, performance.
- [3360e40d09e2] Continuity rules (what must remain constant)
- [fae5c2bff912] Inside each 5-second prompt, use timecodes.
- [de49559afcec] Use timecoded structure for Seedance and Veo. Kling prefers flowing prose.
- [94114b6c3c86] When moving from clip N to clip N+1, the first beat of the new clip should match the final beat of the previous clip. Character in same pose. Same light. Same color temperature. This is what makes them cut together cleanly in the editor.

## video/references/race-and-speed.md

- [329b4a6f2ea8] Domain grammar for dynamic race spots — drag, drift, chase, drag-strip, kinetic montage. The brief is brutal: faces are banned, the deliverable is **still keyframes (opornye kadry)** for an animatic, and a frozen panel must read as lethal velocity at a glance. Speed is not a post effect — it is a photographic fact built from spatial cues that imply the missing motion. Emotion does not live on a fa
- [7177643306c8] Core laws (the non-negotiables)
- [7f3de462ae7d] Four schools worth stealing
- [9d8b669b963a] Selling speed in a single frame
- [d0406d8416a6] Storytelling without faces — the race captioning system
- [04df341ef39d] The race ritual (liturgy) + the 5 shot families
- [02d619120a92] Camera grammar for speed
- [cb63fe4c6da0] Light & color for speed without faces
- [7e6ed8137a3c] Sound & rhythm
- [347ccea61bf2] 30-second structure (beat map)
- [5fdf491ab509] Anti-fake guard
- [00552d374a9c] **Authentic speed, never CGI-clean or sped-up.** Build velocity into the static composition (§3); never lean on a ramp to rescue a dead frame. Over-crank, glass-smooth stabilization and post speed-ramps read subconsciously as "ad-speed" and drain all threat. Squat, lifted nose, slick wrinkle, smeared rim — the physics has to be visible in the still.
- [47dd1d977a21] **Detail is the emotion.** Faces banned, feeling renders only on a knuckle, a needle, a pedal, smoke, or a sweat bead (`dramaturgy.md` §2; the full substitution method is `animatic-keyframes.md` §5). A hand mid-grip is the no-face equivalent of a close-up on the eyes. No abstract "motion", no named feeling.
- [a2680889ec7c] **One governing visual promise per piece.** A 30s cut earns cohesion from a single conceit: everything through reflections in painted metal, or everything through circles (tach → headlight → bulb → wheel), or everything as machine-talks / no-music. Kon's "one visual principle". Name it before boarding.
- [5e64b7c7d357] **Beat-locked cutting.** Loudness in the audio = shot count on the board (§8; the density ladder itself is `animatic-keyframes.md` §3). Silence = one held panel. Bang = a burst of 4–8-frame micro-panels. Cut length is engine RPM made visual: idle = long panels, redline = collapsing panels toward the green.
- [1f3f073247b7] **Cold combative palette** (§7). Steel blue, cyan, magenta, dirty mercury-white; **red as danger accent only** (brake glow, redline, tail-lights, the Tree's bulbs). No warm cozy amber wash — warmth appears only as toxin. Steal Tony Scott's grain, contrast and overexposure; **discard his warm grade.**
- [11ae3ea96fb0] **Every insert is load-bearing.** Each detail panel must be captionable with one race label — *setup / commitment / mistake / recovery / proof-of-speed / result* (§4). If you cannot label it, it is a *fantik* (`dramaturgy.md` §3) — drop it. A board that is all proof-of-speed with no commitment/mistake/recovery is a reel, not a story.
- [611f323d3615] → **Rule:** never write "motion" — write the artifact motion leaves behind, and never board a neutral panel (every frame carries a forward vector, negative space ahead of the subject).
- [ca87c9bb0cd3] A still has no engine note and zero motion. It sells velocity through the **speed-budget rule** — a frame reads fast only when **≥3 of five cues coexist** (camera at/below bumper height · asphalt streaking the lower frame · a near foreground reference passing the edge · sharp hero against motion-blurred background · a mechanical-vibration cue). The full rule, with the anti-fake firewall, lives in 
- [be25e9cc99a1] **Long-lens compression** — the second speed register and the antidote to "only blur sells speed". Frankenheimer's 1000mm stacked distant cars onto the hero so closing distance reads as collapse. Pair compression panels with low-wide panels in the cut; never board the whole spot on one lens. In `seedance.md`/`veo.md` syntax name "motion blur, fast-shutter look on background, sharp subject" explici
- [fc4a79f80ec2] A face does four jobs: internal state, where it looks, the cost, the decision. Banned, those jobs redistribute — **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space.** The mechanism, the EMOTION→OBJECT substitution table and the state-change cheat-sheet are owned by `animatic-keyframes.md` §5; do not duplicate them. Two filters before you draw:
- [5d1c203cbde8] (Banned panels are consolidated in §10.)
- [7a8e1fc6b5e6] **Amber logic (decision point).** Choose the **Sportsman / full tree** for an ad: three ambers fire *sequentially 0.5s apart* — three drawable keyframes, a stretched drum-roll of dread with cut length collapsing toward the green. The Pro tree fires all three at once — one panel, brutal but no build. Draw the Sportsman stagger. Always leave on the **last amber, not the green** (holeshot): the launc
- [9bf2cbf9c271] 3 | **Hard-mounted cabin shake** | Pressure / Reaction | Rigid interior mount: dash/needle/hands vibrating, mirror trembling, world shuddering through glass | visible micro-vibration; never perfectly stable
- [0e9bacb2e8ad] **Restless / handheld cam** | the frame never settles; constant threat, physiological unease | Never a perfectly level, perfectly clean panel — bake in a 1–3° drift, edge smear, off-true horizon, a faint micro-shake artifact even in a "static" cockpit | Pressure
- [98ee930c9f7c] Faces are banned, so light is the only actor left. It does not "set a mood" — it **rims a material** so a piece of metal, rubber or skin reports the emotion a face would. General light grammar (sources, direction, quality) is `camera-lighting-vocabulary.md` §4–7; the anti-sterile firewall is `animatic-keyframes.md` §7 + `universal-rules.md` U12. The race-specific governing law: *embrace the dark* 
- [2be4bcd05090] Toxic amber/sodium (rationed) | temporary, contaminated, alien — never cozy | sodium lamp as a passing smear; spilled fluid catching one lamp; the Tree's three ambers as countdown only
- [8a862f876fa8] **Warmth as toxin** is the only permitted heat: brake-disc/exhaust glow (the machine at its thermal limit), a header flame stab gone in a frame, the Tree's alien ambers, a sickly sodium smear. Any warm element must be **point-source and surrounded by cold**. If amber fills more than ~15% of the frame it has become a wash — kill it.
- [f79825c8bfa6] **Backlit smoke** [Pressure/Establish]: hard cyan or mercury-white punching *through* tire smoke from behind; volumetric shafts, the car a dark mass dissolving into glowing haze, red tail-light bleed inside the smoke for the danger accent. Front-lit smoke is dead gray nothing — always rim it from behind.
- [784a21fb3fba] **Silhouette / contre-jour** [Power/Pressure]: helmet/shoulder as pure black shape against a blown headlight or the Tree's amber bank, one thin rim defining the form plus one glint on the visor edge, no features. The brain fills the dark with something worse than any face.
- [c50591694f2a] **Texture and atmosphere.** Name the grain, never "clean": fine-to-medium film grain (heaviest in shadow), halation/bloom on hard practicals (soft glow ring + hard hot core), one anamorphic flare off the dominant source, slight chromatic fringe on the hottest edges (anti-sterile test in `animatic-keyframes.md` §7). One atmospheric pressure per panel (`dramaturgy.md` §9, Kurosawa) — backlit tire sm
- [5f835d0eb35a] You storyboard the **sound first**; the keyframes hang off it. The general law — **loudness in the audio = panel count** — and the descending duration staircase are the density ladder in `animatic-keyframes.md` §3, sitting on the `dramaturgy.md` §12 rhythm staircase. Do not re-derive them. The race-specific rhythm rules:
- [a433636c2657] **Engine as metronome.** Tie panel *duration* to RPM: idle = ~2s panels, redline = panels collapsing 2s → 1s → 0.5s → 8fr → 4fr toward the green. The board should read as an accelerating tachometer on mute. Annotate each panel with its on-screen life.
- [2d91bbc13caa] **Pull-to-intimate at the peak.** At the contest's tensest point, cut from a wide loud pass to an ECU of glove-on-shifter / breath-fog, shallow focus, void around it — engines stripped to breath only. The *quiet* panel goes *tight*; the loud panel goes wide.
- [f5ef9ac105ef] Every panel inherits a `Sound` cell even though it is a still (`dramaturgy.md` §11) — prompt the *physical consequence* of the sound (deformation, particulate, smear, heat-haze, isolation-in-void), never a named sound. Fill it.
- [19ef2dbc9666] Five phases: **ritual → staging → launch → contest → release.** Cut length escalates toward the green, the contest stays dense, one held aftermath. ~20–26 panels. Function tags from `role-modes.md` §4. This is the structural skeleton; for a fully worked, panel-by-panel deliverable board of this exact structure (format C, ~13 rows), use `animatic-keyframes.md` §8 — do not draw a second worked board
- [de0ddf9ca295] Allocation: plot the board as a descending duration staircase, broken only by the one pre-launch held panel (the single most-held still, most negative space) and the one post-finish hold. The launch is *never* one hero frame — fan it into the 6–9-panel micro-burst. No two bang-clusters touch; every burst is separated by a held quiet panel.
- [b4e9fb037f88] The race-specific list of panels that kill credibility — do not draw. (The general per-panel earns-its-place checklist is `animatic-keyframes.md` §9; run that on every panel as well.)
- [54d1d74f3df8] [ ] No banned panel: static fetish insert (lever/badge/wheel with no verb, no state-change); anatomy at rest; a detail you cannot caption with a §4 label; all-proof-of-speed board with no commitment/mistake/recovery; decorative dashboard clutter (keyring, dice, coffee cup — "each object is a clue"); warm wash without narrative function.
- [1948fb0cd2ea] Before sending the board, run `animatic-keyframes.md` §9 (per-panel master checklist), `dramaturgy.md` §15 and `universal-rules.md` §13 over it. The most-violated step is the three-detail check — do not skip it.

## video/references/role-modes.md

- [0228eb6fc32a] Director mode
- [bc65d00b7648] Screenwriter mode
- [84f2cd5a378b] Shot function taxonomy
- [cedacf95ce49] Every shot must answer at least one of these questions. If a shot answers none, delete it.
- [5c79b70fbb5a] What does the viewer need to notice?
- [e47d5852520a] Use one dominant director reference per scene. Translate into concrete camera, light, rhythm, blocking. Never stack three or more references.
- [d92564e28fe4] Translate every beat into physical action the camera can see. Tag each beat with a shot function (see section 4). Every beat must have subtext.
- [9570d85c5b8a] Every beat should carry at least one function tag. This is the editor's grammar.
- [85f471342e23] A montage sequence can compress or loop. Use function tags to keep the structure readable even at high speed.
- [a84829cef94a] Each tag is also a question the shot must answer. Establish. Where. Power. Who commands. Pressure. What pushes. Detail. What to notice. Reaction. What it cost. Shift. What changed inside. Impact. The moment. Aftermath. The residue. Exit. The image carried out.

## video/references/seedance-25.md

- [16d0138b736d] What 2.5 changes
- [8b8c0d1dbc74] Specs and hard limits
- [30d2f5eff0ad] Official prompt formula
- [8313a9a24b34] Syntax markers for audio, dialogue and text
- [b8eee7f2f8e2] Reference discipline (the 50-slot system)
- [cbefd0f56511] The 30-second structure: stages and end states
- [b91733d06e56] The anti-collapse skeleton (3 modules)
- [c02c4d796066] Realistic human formula (anti-AI-face)
- [a7f7eaa6494a] Camera language
- [75c045746d55] Physics through consequences and triggers
- [6fc796f8b7ef] Video editing (partial re-render)
- [365c648ba098] Video extension
- [36dccaf6ebb2] Ultra Long mode (30-180s)
- [0d171a59aa6e] Blockout and green screen
- [0130710f74ef] Storyboard grids and keyframes
- [813d4456baa4] Failure modes and fixes
- [c9f0f1f54765] Economics and model choice
- [521bfa52222b] Worked examples (official, verbatim)
- [dc069aea561b] Generation parameters (duration, aspect ratio, resolution) are set on the generation page or via API — **they do not belong in the prompt**. The 1.x/2.0 CLI tail (`--resolution ... --duration ...`) is not 2.5 syntax. Exception: in Ultra Long mode, restate duration and ratio at the top of the prompt.
- [3c3a35bd5003] **Global tail.** Re-state the must-hold globals (camera position, environment, sound, lighting) and repeat the global bans.
- [fe2010e7cd1e] 2.5 has dedicated markers. Use them — do not describe audio in loose prose:
- [5090be9f2dcb] The point of 50 slots is not dumping assets in. **Every material's role must be written in the prompt.** Do not rely on text labels inside images; do not make the model infer mappings.
- [f4e68628a21b] **Bind each subject individually.** `<Character A> corresponds to @Image 1. Use only the appearance, hairstyle, and clothing.` The officially forbidden pattern: "@Images 1 through 4 define four characters respectively" — it never states which is which.
- [1a73cf483aab] **Add exclusions** for anything that could bleed in: "Do not use the image background." / "Do not use the people in the image." / "Do not use the person's identity, clothing, or scene from the video."
- [8acb235535b4] **Do not restate what a reference already defines.** If a reference video defines the motion, state only which attributes to inherit — re-describing every action conflicts with the reference.
- [9d8033a7fcbb] **Select references per scene**, not all at once: `Scene 1 | Use: <list>. Event: ... End state: ...`
- [58c03455aad2] Divide the clip into consecutive stages. **One primary state change per stage, and always state the visible end state** — the end state is what the model steers toward (this is the U11 final-image rule, per stage).
- [7e710b7de286] A time range is an event's **time budget, not an edit point**. Ranges must be consecutive and non-overlapping.
- [2976ffd881f1] **One core action + one camera move per window.** Do not demand frequencies ("three actions in one second").
- [83694d17ac4b] **The prohibition list is specific, not generic.** From the official farewell example: "No exaggerated crying, no fast cuts, no large body movements, no extra dialogue, no BGM, no runny nose, no premature dropping of tears." Ban the exact ways this scene can collapse.
- [4340f22ac789] Always attach the incantation: **"prohibit rigid cutting, prohibit objects appearing out of thin air"** — it is the official anti-jump-cut clause, repeated in every transition template.
- [b93895a69273] Order-gate effects that must not fire early: "The ink-wash effect must only appear AFTER 25 seconds, triggered by the 'click' sound — absolutely no premature appearance."
- [e56653bec670] **Declare the physics regime up front.** "Rain reflections on metal, water splashed by tires, and the specular refraction of exhaust flames must strictly obey real-world physics."
- [809f55027421] **Narrate consequences, not just actions.** Tires kick up water curtains; the impact shatters the bridge into a spider-web pattern; the shockwave blows the rain away in a ring. Action chains where each step forces the next ("hand grips jar → lid actually unscrews") double as QA — a broken chain exposes a failed generation instantly.
- [8870a91220dc] **Negatively constrain the known failure.** "No soft-body or mollusk-like twisting of the mecha structure (must maintain metallic rigidity)." "The amber stays attached to the palm and must not clip through the fingers."
- [5e9381b1532d] **Gate events on triggers.** "Three seconds after she presses the button..." / "only when he says {now}..." — triggers beat raw seconds for anything tied to performance.
- [8dd832a85896] Any clip ≤30s extends by 4-30s per pass, nested repeatedly, **hard ceiling 60s**. The new prompt applies only to the appended segment; original frames are untouched. Required verbs: extend forward / extend backward / continue.
- [324bcf02f62b] Backward (prepend a beginning): describe the preceding events, then define @Video 1's **first frame as the extension's explicit end state**. Gotcha: materials that belong to the source video only must be flagged — "<X> must not appear early in the backward extension" — or later characters leak into the past.
- [3cc2915d07c9] Community-proven minimal extension prompt: "Extend the video. Keep character identity, facial structure, body proportions, lighting, art style, and the space fully unchanged. Only change camera movement; do not redesign character or action."
- [f0315e2411a6] **Timestamped** (1-minute ambient pieces): windowed beats with per-window bans — "0-20s (quiet opening): fixed camera... no shake, no characters enter, hard cuts prohibited."
- [ed4fbf774ee8] **Coarse blockout** — primitive geometry as a "dynamic skeleton" (trajectories, blocking, camera path, cuts, light changes). **Map every primitive to a reference**: "The tall cylinder in @Video 1 corresponds to <Guide>. The rectangular block corresponds to <Display Cart>." Exclude the render style: "Do not use its gray geometry or empty scene." Best practice: **no limbed or winged models in coarse
- [7887bf99374c] **Fine blockout** — complete 3D animation; the model re-renders materials, color and style only: "@Video 1 is a fine blockout reference. Preserve structure, action, spatial layout, camera position, camera movement, and cuts. Do not use its original gray materials or empty background. Re-render <subject> as <final subject>..." **Clean the viewport capture first**: remove path lines, coordinate axes
- [c8f9182dab48] **Storyboard grid as input**: one image, ≤15 panels official (practitioners have pushed 50), clean line art, minimal text. Declare the reading order and exclude the style: "@Image 1 provides a 12-panel storyboard grid for shot order and approximate composition. Read it left to right, top to bottom. Do not use the grid's line-art style, text labels, or placeholder characters." Then `Shot 1: ... Sho
- [dbf4503191cb] **Multi-keyframe sequences**: "Use @Image 1 through @Image N as keyframes in this order", one key state per image. Independent images align better than a grid. Keyframes control stage order and key states, not exact frames.
- [884b4b40911e] **First + last frame** works inside omni-reference mode — declare each anchor separately ("@Image 1 is the first frame... @Image 2 is the last frame..."), never jointly. Same aspect ratio required.
- [877300b2ba56] Fix. Per-subject binding (section 5) + explicit differentiation: "Their movements are not synchronized. Clothing colors, hairstyles, and facial features must all be distinct. No identical clones in the background."
- [3b48069bb705] 2.5 errs by commission: it completes more instructions than rivals but may cut freely even when told "one continuous take". Fix. "One continuous shot, no cuts of any kind" + a camera path that never motivates a cut; if montage keeps leaking in, drop to a 10-15s window where one-takes are stable.
- [6eafd4ebaa95] Costs are real: a 30s/720p generation on Jimeng runs ~500-700 credits. Production budgets must assume re-rolls, extensions and segment reshoots — fix with edit/extend/reshoot instead of full regeneration whenever possible. Draft at 480p, finish at 720p.

## video/references/seedance.md

- [bf04722fb2d7] What Seedance is
- [379e62884da3] Versions and specs
- [72c2aed0f513] CLI parameters (1.x / 2.0 only)
- [9aaa76a80841] The Details Law (read first)
- [cf0aa2c21b81] 6-step prompt formula (quick)
- [a624dc423b7d] Production-grade skeleton (11 blocks) — for dramatic / multi-shot work
- [1c02614a3e4f] The 5-second shot timeline (rhythm template)
- [ba9e08cfe115] Multi-shot syntax (unique capability)
- [d2ca29dc370a] Anti-mush guard block (when Seedance smears the cuts)
- [aa26f1234c80] `@img1` character reference syntax
- [3830b43ea337] Camera movements (9 presets)
- [805acf614f43] Negative prompts handling
- [c0ec18d3a206] Image-to-video rule
- [f561578ec058] Audio (1.5+)
- [c1ff7a4810db] Failure modes and fixes
- [20840c83ede1] Worked example. 15-second tragicomedy as 3 × 5s clips
- [5e727274f86e] Seedance 2.5 → read `seedance-25.md`
- [0395ddb6bd06] **Not 2.5 syntax.** On 2.5, duration / aspect ratio / resolution are set on the generation page or via API and do not belong in the prompt (exception: Ultra Long mode restates duration and ratio at the top — see `seedance-25.md` §2).
- [73905921cedf] Seedance does not render abstractions. It renders **physical specifics**. Every adjective must be a sensory fact. Every emotion must be a body. Every shot must own at least three concrete details:
- [a78b8143dfae] **One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC.
- [809fb4ebddce] **One physical micro-action.** Jaw locks. Finger taps the counter. Knuckles whiten on the fork. Lips press into a line. He swallows hard.
- [659a2eb38201] **One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in the dark phone screen. Rain hitting the same windowpane.
- [ae09790a4e9b] Banned, lazy phrasing that produces mush:
- [e30cec365a82] Write in full sentences, not tags. Seedance prefers clear grammatical prose. For dramatic / multi-shot / character-locked work, **use the production-grade skeleton in section 6 instead.**
- [2d5229cb5344] Use this for any dramatic piece, multi-shot ad, music-video segment, or character-locked clip. Each block answers a specific failure mode. Skipping a block reintroduces that failure.
- [b9c780304835] For a 5-second multi-shot clip, the model performs best with **5 shot beats** following a dramatic micro-arc. Use this timing as the default scaffold:
- [c6a20928bc70] Seedance reads explicit cut markers inside a single prompt and generates distinct shots connected by visible cuts. This is its strongest card. Use it when you need montage in a single generation.
- [c3c3d1047037] Use 2-3 shots per 5-second clip for tight cinematic montage, 4-5 shot beats only when each beat is short and physically distinct (see section 7). Hard cap: 5 shots per generation — beyond that the model drops or compresses shots. Size the duration to the shot count (4 shots need 10-15s, not 5s). Every shot must share an anchor with its neighbors — same character, same location, or same lighting re
- [d629ec5811b5] Seedance 2.0 accepts image references inline using `@img1`, `@img2`, etc. Use this to lock the protagonist's likeness across all shots in a multi-shot clip and across multiple stitched clips.
- [e57740e558ac] The full identity block must follow the `@img1` mention. The model needs the textual description as a backup signal — the image alone drifts.
- [80e69a894fcc] Workaround for 1.x/2.0. Always invert to positive phrasing. Instead of "no yellow tones" write "cold blue-gray palette with desaturated skin tones." Instead of "no distorted hands" write "anatomically correct hands with clear finger separation."
- [a75221469baa] **Seedance 2.5 fixed this.** Direct bans are reliable: "pure video, no subtitles, no background music" actually suppresses them, and specific prohibition lists ("no exaggerated crying, no fast cuts") are a core part of the official 2.5 prompt structure. See `seedance-25.md` §7.
- [71fec8821328] When using a reference image, DO NOT describe elements already visible in the image. The model sees it. Describe only motion and camera work. Re-describing static elements creates identity drift.
- [6b50e2278180] Dialogue goes in **double quotes** on 1.5/2.0 — the model voices it, generates the voice and syncs lips to the cut. State the delivery: "Play her line dry and a little proud, his quiet and worn out." **On 2.5, use the dedicated markers instead**: dialogue in `{ }`, SFX in `< >`, music in `( )`, titles in `【 】` (see `seedance-25.md` §4).
- [f1f0fcdff995] Fix. Add explicit "Cut to" markers. Say "multi-shot sequence with visible hard cuts. Do not generate a single continuous take."
- [27ee9fc25b00] Fix. Use positive substitutes. Seedance 1.0 has no negative parser.
- [f4c2c207fbb8] Fix. Apply the Details Law (section 4). Audit your draft: every shot must have one environmental pressure, one micro-action, one sound or visual motif anchor. Replace adjectives like "dramatic", "intense", "beautiful" with concrete physical facts.
- [e7caec8627aa] After the 2026 deepfake crackdown, 2.0 aggressively filters human faces, helmets, sunglasses, and anything resembling protected IP or celebrity likeness. Fix. Route face-heavy drama to Seedance 2.5 (realistic humans are its headline feature), 1.5 Pro, Kling, or Veo; keep 2.0 for scenes, architecture, product and montage work. Use only owned or synthetic character references — the IP/celebrity filt
- [31550b84c066] A 15s narrative is **never** one prompt. It is three self-contained 5-second prompts, each with the full character lock, the full visual style, the full audio block, and a different dramatic function. Stitch in the editor.
- [dd071e4f1adc] For dramatic, multi-shot, character-locked, or stitched-clip work — always use the 11-block production-grade skeleton from section 6.

## video/references/universal-rules.md

- [1eff4afae0c5] The non-negotiable. Details intensify emotion (Details Law)
- [f8bede714bb2] U1. Universal prompt skeleton
- [2aaa9e213f3c] U2. Weight-at-start
- [bc20f5aff1a0] U3. Show don't tell
- [4da3a01386c8] U4. Natural language beats tag spam
- [ea5fe60a475b] U5. One primary camera move per shot
- [bfd5925d781c] U6. Precise lens language
- [59e3586c0672] U7. Character consistency anchor
- [2dbc39baa120] U8. No contradictions
- [6fe216acd414] U9. Concrete physical detail over abstract concept
- [af2fe5419c45] U10. Duration discipline
- [f768d100f368] U11. The final image rule
- [8d89d14b9f2b] U12. The three-detail check (audit before sending)
- [c5205558e796] U13. Reference role discipline
- [a8c92c01fd2f] U14. Priority declaration
- [90c9d01c7da9] **One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC. (Kurosawa: weather is a character. See `dramaturgy.md` §9.)
- [3da18291f908] **One physical micro-action.** Jaw locks. Knuckles whiten on the fork. Lips press into a line. He swallows hard. Fingers curl against the doorframe. (Show, not tell — the body is the only place where feelings render.)
- [01e778de1f4c] **One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in a darkened phone screen. Rain on the same windowpane. A single fluorescent flicker before each cut.
- [d9efc3ad4bfb] Words that do not render and mark the writer being lazy:
- [a4cd347f4b1e] Do not stack three camera moves in a 5-second clip. Pick one dominant move (dolly-in, pan, tracking, static). Layer a subtle micro-adjustment if needed (slight handheld shake, gentle rack focus). More than that produces visual chaos.
- [c1d814f8c059] Identity block must include: face shape, eye color, skin tone. Hair color, length, style. Facial hair. Exact clothing items. Distinctive accessories.
- [e24b10c311e9] "Loneliness" does not render. "A man sitting alone, shoulders collapsed, face lit by blue phone glow, empty bottles on the table" does.
- [9373adbe6c11] Most models work in 5-10 second clips. Longer narratives live in multiple clips stitched in the editor. Do not cram a 30-second story into a 5-second prompt.
- [adbe90385564] Before returning the final prompt to the user, audit every shot. Each shot must carry at least one of each:
- [75ec08f6c7e0] Environmental pressure (lighting, weather, surface, sound of the room).
- [6f2d9a2fd7ba] Physical micro-action on the body (jaw, hand, breath, eye, gesture).
- [e2b9c51c5ef7] Sound anchor or recurring visual motif tied to the emotional spine.
- [f7ff7d98a4a9] If a shot has zero, fix it before sending. If a shot has only one, ask whether you can make it two without bloat. The strongest prompts in this skill's worked examples always have all three.
- [51c07299485c] Wherever a model accepts reference assets (Seedance `@Image/@Video/@Audio`, Kling Element Binding and Omni references, Veo ingredients), **every asset gets an explicit role written in the prompt**: what it defines (appearance, motion, voice, scene, camera path) and what to ignore ("Do not use the image background", "Do not use the people in the image").
- [2e0a56484152] Bind each subject individually: "<Character A> corresponds to @Image 1 — use only the appearance, hairstyle, and clothing." Never the collective form "@Images 1 through 4 define four characters respectively" — it does not state which is which.
- [21023b368ec1] Do not restate what a reference already defines. If a video reference carries the motion, name only the attributes to inherit; re-describing every action fights the reference.
- [d1794addd647] The core subject that must survive every shot.
- [0196c3f7220c] The key shots that must appear.
- [da70b123efd4] The transitions where the model may freestyle.
- [e21763705dd8] The mandatory final frame.

## video/references/veo.md

- [f537cf5a3aea] Versions and specs
- [12a578676a61] Prompt structure and length
- [a60c5e0dfaba] Dialogue syntax (critical, unique)
- [8350ec6bf0fe] JSON prompts (powerful, unique)
- [8c412614e361] Image-to-video (Veo 3.1)
- [5b62ebcc0fbf] Reference ingredients (3.1)
- [8cd72c333780] Failure modes and fixes
- [60e1c0dd065d] Skeleton and example
- [dfcbb6dd0684] Use labels `Audio:`, `Says:`, `SFX:` to separate sound direction from visual direction. The model needs an explicit signal that audio should be generated.
- [a45ee38936f8] Veo parses structured JSON. This prevents "concept bleed" where describing mood accidentally changes object colors. Use JSON for complex scenes with strict continuity needs.
- [01a57763de37] Complex props that must stay the same color and size.
- [1c400db686fb] Do not re-describe static elements.
- [402a936cf3fe] Use when you need a specific character in a specific place with a specific object.
- [1a0831f5ce00] Fix. Add explicit `Audio:`, `SFX:`, or `Says:` labels. Do not assume the model will infer audio from visual description.
<!-- SOURCE_FILE_END: repo/nblm-ids/video.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/visual-asset-critic.md -->
# SOURCE FILE: `repo/nblm-ids/visual-asset-critic.md`

# Reglas del skill: visual-asset-critic

55 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## visual-asset-critic/SKILL.md

- [a9db0e982fb0] You are the editorial second-eye on AI-generated images. Most teams don't have one, they generate, glance, accept, and ship. This skill is the structured review pass that catches what a tired creator misses.
- [6692ef7502cf] Says "review this render", "is this on-brand", "what should I change"
- [1dc7c87def16] **Two artifacts from every review, always both:** a human-readable markdown critique (the primary surface) and a machine-readable critique JSON (so a pipeline can gate on the verdict instead of parsing prose). The JSON is detailed in Step 6; it never replaces the markdown.
- [331ea8b0b15b] per round, never a shared filename. A 12-shot project reviewed over three rounds writes 36
- [c174e00adaac] Shot ID + shots.json | Recommended | If absent, ask for shot intent in a sentence
- [92d3adf53086] brand-lock.snapshot.md | Recommended | If absent, critique only on technical merits
- [c8195d96aaff] If you can't establish intent in one sentence, ask. Don't critique blind.
- [0aebfb67e4fd] **Brand Lock**, does it respect palette, mood, "never" list?
- [3236a31aecea] **Series Lock**, does it match character/environment/lighting anchors?
- [79f9fd6178a0] **Shot Spec**, does framing/angle/composition match the spec?
- [024638f7f93d] **Composition**, does it reserve space for on-screen text if applicable?
- [d0476aaa14d5] **Technical**, skin texture, hands, eyes, anatomy, AI artifacts?
- [4254cbeb01a9] **Continuity**, if previous shots in the series are available, does it match?
- [4dabd7bdc618] For every "not working" point, the critique must say what to do about it. Three buckets:
- [c6c6b48f5a57] > "Color grade is slightly cool, push warmth +5 in post, no need to re-generate."
- [7eac9caa0ac8] **Re-roll required**, no prompt fix will help; the generator just produced a bad sample. Budget 2–3 attempts:
- [c24705b39ede] **Provenance, all of it required at 1.1.** A verdict is a claim about specific bytes. Name
- [110d5c828282] Every one of those fields is required, and every one is nullable. That combination is
- [e182afdf2371] your confidence to MEDIUM. Do not omit the key.
- [fd33b1fe4a83] **Gating rule, the verdict is derived from severities, not chosen freely.** This guarantees the markdown verdict and the JSON verdict always agree:
- [c7b224344104] fixtures that ship in the repo and never once against a real client's critique.
- [583d5f400a46] "Looks great" / "feels off" without specifics is not a critique. Every observation must reference something in the image (composition, color, anatomy, lighting direction, etc.).
- [0cde22e1a93c] If the brief was "founder at laptop, calm mood" and the generation delivered exactly that, don't note that "the room could be more visually interesting." That's scope creep, not critique.
- [5b837820df26] Some failures (mangled hands, weird eye reflections, jewelry shimmer) are known generator weaknesses. Surface them as such, don't pretend a different prompt will fix them. Recommend re-roll or post.
- [a221a716e952] Generation is one stage in a pipeline. If the image is 80% right and the gap is fixable in post, that's an ACCEPT with post notes. Don't send the user back to re-generate when an editor would handle it in 90 seconds.
- [87d7e03eed3d] > - **Hand:** Re-roll required. Generate 2–3 more times with same prompt and pick a clean one.
- [65ab63f3291c] If the verdict is REJECT, do not offer that. REJECT means a blocking issue or three or more
- [c7b95c733b7f] Don't auto-revise. The user picks. The critique you just wrote is exactly what closes that

## visual-asset-critic/examples/worked-run/brand-lock.snapshot.md

- [0ab5724633a2] Role | Hex | Use
- [147b5d10f118] never use stock photo aesthetic
- [edb34335baee] never use AI uncanny faces
- [36f326b4fa1b] never over-saturate the cream background
- [6fcfbe5ad699] never use coral as a flood color (only as accent or signature periods)
- [e3d69437c2f6] never use em dashes in copy
- [ff2826465af1] never use emojis in body copy
- [bd1590a213fe] never use bullet points in narrative copy
- [cf3ce4e1adaf] never use clip-art or generic icon sets
- [2ef7c79850da] never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- [5d8f1227d198] never use exclamation points in headlines
- [b1bf8c0bd438] never default to dark mode, light mode hybrid is the brand
- [2306baa11deb] never animate text with bouncing or wobbling, type-on, fade, or hard cut only
- [c2fbf1d46956] Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.
- [8cb896ae3ca7] Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.
- [a3fa0f352d46] prefer specific numbers over vague claims
- [c1ee0d0b5a80] prefer present-tense over future-tense
- [650d25a8d091] prefer "operator" over "creator", "infrastructure" over "agency"

## visual-asset-critic/references/critique-rubric.md

- [00c742ccd1e6] The structured layer-by-layer pass. Use this as the checklist when reviewing a generated image.
- [bf46e2f0044e] "Never" list | None of the items in the never list are present | One item in the never list shows softly | Multiple never-list violations
- [7713f2e95b09] Depth of field | Matches if specified | Slight DOF variation | Deep when shallow was specified
- [1e898f2c0308] Technical hard fails are almost always **re-roll required**. The prompt was probably fine; the generator just produced a bad sample. Budget 2–3 re-rolls.
- [31afcb61a699] Soft fails are noted but don't change the verdict on their own. If you have three or more of
- [788f1a8f5595] **Don't critique what wasn't asked**, if the spec didn't call for cinematic mood, don't say "could be more cinematic"
- [8014a721e61b] **Don't pile-on once verdict is set**, if you're rejecting, list the issues that drive the rejection; don't list every cosmetic concern
- [9b616f961fba] **Be specific, always**, "lighting is off" is not a critique; "key light is camera-right but series_lock says camera-left" is
- [b1bf47b129ef] **Distinguish prompt failure from generator failure**, if the prompt was fine and the generator produced garbage hands, that's "re-roll required", not "fix the prompt"
<!-- SOURCE_FILE_END: repo/nblm-ids/visual-asset-critic.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/visual-prompt-forge.md -->
# SOURCE FILE: `repo/nblm-ids/visual-prompt-forge.md`

# Reglas del skill: visual-prompt-forge

172 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## visual-prompt-forge/SKILL.md

- [73fe57cd2392] If the user wants to build a storyboard from scratch (no shots.json yet), use `storyboard-architect` first, then chain into this skill.
- [30bbbcefca75] **Brand Lock**, palette, type, mood, "never" list (constant across project)
- [3a6fba22ac13] **Series Lock**, character/environment/lighting anchors (constant across storyboard)
- [ea1a9a227c90] **Shot Spec**, framing, angle, motion, subject (per shot)
- [d584b5f6dd31] **Text Layer**, **never in the prompt**, composited separately
- [2ad7d2bd5837] **Generator Adapter**, model-specific syntax wrapper
- [676d83318ba4] `shots.json` (required), the structured shot list
- [15c8b7599336] `brand-lock.snapshot.md` (required), referenced from shots.json
- [2266a36b9924] Target generators (required), ask if not specified
- [ceadbe55c7f7] Don't try to forge prompts from incomplete data.
- [f5780b83a7fd] relative path only resolves when the skills sit side by side; when they don't, ask the
- [409086978069] Each adapter file documents the prompting style, parameter syntax, and known pitfalls for that generator. You **must** read the adapter before writing prompts for it. Don't guess from training data, image-gen syntax has churned multiple times.
- [dc64b62d7b53] **`adapters/_capabilities.json` is the single source of truth for per-generator limits** (`max_prompt_words`, `supports_text_render`, `supports_motion`, `aspect_param`, and so on). Read it once at the start and respect those values when composing, and do not target motion on a stills-only generator.
- [c8ca9f7ecf45] `max_prompt_words` is a ceiling. The range in an adapter `.md` is the recommended target
- [f839d2e13059] and always sits inside that ceiling, so a `.md` saying "40 to 70 words" under a ceiling of
- [926849d6c818] build when an adapter advertises more words than its ceiling, or when an adapter never
- [f5131460c877] Pull brand-lock palette, mood, "never" list
- [7405b4323a06] Pull series_lock character/environment/lighting
- [31c852fadeeb] Pull shot framing/angle/motion/subject
- [a8d68a296084] **Strip any on_screen_text reference**, text never goes in the prompt
- [2b9195a30710] Apply the generator adapter's syntax wrapper
- [2b8a535c5cf5] Append generator-specific parameters (aspect ratio, style flags, seed if applicable)
- [5d8272012767] > "Want me to QA the generated images against the storyboard? Use `visual-asset-critic` once you have the renders."
- [f40b417305f5] This is what `visual-asset-critic`'s structured output is for. When the user hands you `shots.json` plus one or more `critique.json` files (the machine-readable verdict the critic writes), don't re-forge the whole storyboard, re-emit prompts for **only the shots that failed**, with the fix already applied.
- [f967955038f5] Read every critique under `output/critiques/round-{N}/`, where N is the highest round
- [8094567ba7ff] Skip any with `verdict: ACCEPT`. Those are done.
- [da7ec8955918] **Stop on `REJECT`.** A REJECT means the critic found a blocking issue, or three or more
- [5854e254d91b] For every `REVISE` shot, walk its `issues[]` and branch on `fix_type`:
- [1bd4b3b2da0d] A shot whose issues are all `post-level` needs no new prompt. Leave it out of the
- [67742a174a9f] Saying it in chat is not recording it: that obligation has to exist on disk or the
- [a3656615b59b] Re-apply the five-layer anatomy and the same adapter as the original run.
- [faee36ed7238] Given the same `shots.json`, the same brand-lock, and the same critique, this should
- [24d0e917035e] Colors come from the series_lock color_grade and the brand_lock palette. They get rendered into the prompt by the adapter. Don't write "deep navy blazer" in the shot subject if "deep navy" is already in the palette, that's a duplicated description and produces oversaturation.
- [80fc570bbe52] side-by-side: the six stills generators plus Kling. Use it to calibrate output quality.

## visual-prompt-forge/adapters/flux.md

- [07934feae2b7] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [4a9a9f1d1b5a] Flux handles **80–150 words** comfortably. Don't pad, but you have headroom Midjourney doesn't.
- [cf6ea7ae4157] `shallow DOF` | `Shot at f/1.8 with shallow depth of field, background softly out of focus.`
- [90c1b290af77] **Don't write "highly detailed, 4k, masterpiece"**, these are Stable Diffusion crutches. Flux ignores them and the line burns tokens
- [c55494cbbad4] **Don't use weight syntax `(thing:1.4)`**. Flux 2 doesn't support it; Flux 1.1 partially does. Stick to natural language
- [0447e389826e] **Don't enable prompt upsampling for series work**, fal.ai's auto-rewrite produces inconsistent shots
- [d070363f06ff] **Don't include text content**, even if Flux 2 handles text better than Flux 1.1, composite separately for editability
- [bc7cb8df5ee2] **Don't omit the photoreal closing line**, the "no AI artifacts" anchor measurably reduces the AI-look

## visual-prompt-forge/adapters/gpt-image.md

- [b107310048f9] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [3e22b4c62b1b] GPT Image handles **150–300 words** comfortably. Longer than other generators. Use the headroom for explicit spatial descriptions.
- [4e37b6108b10] "The subject's shoulders are angled 30 degrees toward the camera, face turned to look at the off-frame light source."
- [20ebea9d8a54] Use this when the shot's composition is load-bearing.
- [226a236b4dcc] GPT Image handles text-in-image at roughly 95% accuracy, second only to Ideogram. When text is required:
- [fd93590ae5d9] **Don't write Midjourney-style comma stacks**. GPT Image parses them as a list of disconnected concepts
- [b5fa2fb924bd] **Don't omit spatial language when the shot has specific composition**, you're paying for the model's strength; use it
- [e1f3ed8e587b] **Don't pile too many objects**, five or fewer distinct elements per scene; more degrades fidelity
- [a6bec722c41f] **Don't include `--ar` flags or weight syntax**. GPT Image ignores them
- [d4f119799fc1] **Don't forget that GPT Image's "AI look" is real**, the closing "natural skin texture, no AI rendering artifacts" line meaningfully helps but isn't a complete fix. For pure photoreal, Flux is still stronger

## visual-prompt-forge/adapters/hailuo.md

- [06dd78348fae] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [c72b6be12f5a] Hailuo 02 Pro is the cheap, fast iteration model. Strong motion response and prompt-following for the price, on fal.ai. Use it to **find the shot**, block out camera move, framing, and timing across many quick drafts, then re-generate the keeper on Kling (motion finals), Veo (dialogue), or Seedance (sequences). Treat Hailuo output as a working draft, not a final asset.
- [19e3c8f16aab] Draft the shot on Hailuo with `prompt_optimizer=false`. Cheap, fast.
- [135bf9bbfea0] Lock the camera move, framing, and timing that read best.
- [71c8ecef7358] Re-generate the keeper on the right final-tier model: **Kling** for motion finals, **Veo** for dialogue/lipsync, **Seedance** for multi-shot sequences.
- [e78a9329a596] Carry the exact prompt forward, the adapters share the same five-layer anatomy, so the prompt body ports with only parameter changes.
- [2331185c4bd4] **Don't ship Hailuo drafts as finals.** Re-roll the keeper on a final-tier model.
- [a5926981e848] **Don't enable the prompt optimizer for series work.** Auto-rewrite breaks shot-to-shot consistency.
- [c52dc68d0daf] **Don't stack two camera moves.** One move per shot.
- [4755505de7d6] **Don't include text content.** Composite captions in post.
- [cfc2cee4d758] **Don't over-polish the draft prompt.** Spend words on motion and framing; save the photographic detail for the final-tier re-roll.

## visual-prompt-forge/adapters/ideogram.md

- [62285c31f534] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [fdc0e542eefc] Ideogram is the only generator that reliably renders text inside images. Use it for cases where text-as-image is the deliverable, posters, branded social tiles, signage, packaging mockups. For everything else, default to Flux or Midjourney and composite text separately.
- [580aeac4bce0] Same as Flux, generate the image clean, composite text in post. Use when Ideogram is being chosen for general image quality, not text rendering. Syntax matches Flux conventions.
- [88ac8d8506e0] Use when the on-screen text is meant to appear as part of the image itself, a poster headline, a sign in the scene, a packaging label. This is the only case where a generator prompt contains the text content.
- [6fe6a8f5491e] **To trigger Mode 2, the shot must have an explicit override flag in rationale**, e.g.:
- [8601bfd0e280] If you don't see that override flag, default to Mode 1.
- [73aaed94b890] The exact text must be in straight double-quotes. Ideogram parses these as the text-render target.
- [997a8c1f12f1] **Don't use Mode 2 without the rationale override**, defaults to text-in-image cause double-text (composited + generated) which destroys the comp
- [8ad2673a7cf6] **Don't trust magic_prompt**, it auto-rewrites and produces inconsistent shots across a series
- [83c574fc9ce5] **Don't pile multiple text elements in one prompt**. Ideogram handles one text element well, two becomes lottery, three is broken
- [e0e022e50a9e] **Don't use cursive/decorative fonts**, even Ideogram fails on these. Sans-serif and clean serif are reliable
- [22d09b130cbd] **Don't forget seed**, for any series work, lock the seed at the storyboard level

## visual-prompt-forge/adapters/kling.md

- [278af9f8d903] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [0df53c838f6c] With video the **camera motion becomes load-bearing** instead of optional. The same shot generates differently when `motion` is `static` versus `push` versus `handheld`. Use this adapter when the storyboard is destined for video generation rather than still-frame compositing.
- [34c9774072b9] Camera motion goes **first**. This is the inverse of image generators where camera is implied. With video the camera's behaviour is the first thing the model must understand.
- [a96d5275630a] `negative_prompt` | per series | Supported. Use to suppress drift, e.g. `extra fingers, warped face`
- [c05a37e6c694] Kling handles **80–150 words** comfortably. Motion description adds a beat over a still prompt; do not pad past it.
- [dd11b5da1036] Use `start_image` from the previous shot's accepted final frame to chain a sequence.
- [1e43dbde9ec3] Do not flip lighting direction between consecutive shots (window-left stays window-left).
- [5996725c4119] **Don't put camera motion at the end.** Kling parses motion best as the leading instruction.
- [28b092664be0] **Don't request multiple camera moves in one shot.** Pick one; compound moves break.
- [9d51ba168710] **Don't describe motion faster than the duration allows.** A slow dolly over 5s is plausible; over 1s it is jitter.
- [3d67beea0470] **Don't include text content.** Video text rendering is unreliable; composite or animate text in post.
- [cbb479ac1517] **Don't expect frame-perfect character match between clips.** Budget editorial cleanup.

## visual-prompt-forge/adapters/midjourney.md

- [397cf2e63aa9] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [6d613697ccf2] Param | Values | Default to use | Notes
- [7fb6a50cd854] `--c` | 0–100 | omit | Chaos. Use only when exploring variations
- [d32ed6a243e7] `--cref` | image URL | use when character anchor exists | Character reference. Pair with `--cw`
- [211d04720fee] `--sref` | image URL | use when style anchor exists | Style reference
- [35ad63b182a1] `shallow DOF` | `shallow depth of field, f/1.8, bokeh background`
- [c51e98883ae8] **Don't use "AI" or "rendered"**, produces stylized outputs that look generated
- [e6bae7347048] **Don't over-stack adjectives**, three adjectives per noun phrase max
- [f85b78ac44b0] **Don't include text content**, even if the shot has `on_screen_text`, leave it out. Composited separately.
- [8452bcb3abe4] **Don't use `--c` for series work**, chaos kills consistency
- [3ac7c1186c62] **Don't change `--seed` mid-storyboard**, set once at series_lock level
- [bae5480432cd] Midjourney still has limited API access as of Q2 2026. For programmatic workflows, the prompts in `midjourney.txt` are designed to be pasted into Discord or the web UI. Some teams use third-party wrappers (PiAPI, Useapi.net), those generally accept the same prompt syntax.

## visual-prompt-forge/adapters/nano-banana.md

- [d19b5afba806] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [512c6518fda5] Google's Nano Banana model (`gemini-2.5-flash-image`) is the edit-and-iterate champion. Where other generators are best for first-frame creation, Nano Banana excels at variations, inpainting, and reference-based modification. The 2026 production pattern is to generate hero frames in Midjourney or Flux, then use Nano Banana for variants.
- [f3de59067b61] **Use case:** generated `shot_03` in Flux, want a variant where the founder is looking directly at camera
- [143dc2890227] Generate hero shot in Midjourney or Flux (one prompt → one image)
- [d5bfa09e50d2] Feed that image to Nano Banana with variation prompts
- [cc8441e81dd6] Get 4–8 variants of the same shot for editorial selection
- [90a27f197867] Composite text on the chosen variant
- [2b0600ce9bc0] A modification template comment showing how to use the result for variants:
- [43331142e7ea] **Don't use Midjourney-style flag syntax**. Nano Banana ignores `--ar`, expects `aspectRatio` parameter
- [c169c881a0e6] **Don't expect Midjourney-level aesthetic by default**. Nano Banana is a workhorse, not a stylist. Stack mood adjectives explicitly
- [03aa46d144b5] **Don't pile multiple modifications in one image-to-image prompt**, one change per pass produces cleaner results
- [c4812cc96bc2] **Don't forget the "preserve" clause in image-to-image**, without it, Nano Banana treats the reference as loose inspiration and drifts
- [5fc1cc954fb0] **Don't include text content in image prompts**, composite separately; text rendering is mediocre

## visual-prompt-forge/adapters/seedance.md

- [6930bdd3fefe] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [941f9d967144] One beat, one frame | Single shot (or use Kling)
- [07771e486a77] **Don't force unrelated beats into one sequence.** Multi-shot is for shots that genuinely belong to one take.
- [cee8c4cd6183] **Don't write more than ~4 cuts per generation.** Consistency degrades past that; split and assemble in edit.
- [e84b5c0448b9] **Don't vary the character anchor between cuts.** Restate it once for the whole sequence, verbatim.
- [98d91e461feb] **Don't include text content.** Composite captions from `text-overlays.json` in post.
- [750cf06a6b5c] **Don't stack two camera moves inside one cut.** One move per cut.

## visual-prompt-forge/adapters/seedream.md

- [033510e42dcb] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [5c181b49f9d4] **40–70 words per prompt**. Shorter than most. Don't pad.
- [b58550816f3f] **Don't vary** the lighting language between shots, series_lock string in, no paraphrasing
- [735b1edeccc3] **Don't write paragraphs**. Seedream wants comma-separated phrases
- [8c221aa40298] **Don't use `--ar` syntax**, pass aspect_ratio as a parameter
- [679f8c322dba] **Don't include text content**, text rendering is poor; composite separately
- [3de5ebeb511c] **Don't expect Midjourney aesthetic**. Seedream produces clean but less art-directed output
- [14306fa1f1c7] **Don't skip the seed lock for series work**, without it, character consistency breaks

## visual-prompt-forge/adapters/veo.md

- [d992a5044ff9] > Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw
- [05691c5685fb] **Don't use Veo for silent B-roll.** You are paying for an audio engine you turned off; use Kling.
- [c962c96606da] **Don't overrun the duration with dialogue.** A line that needs 12s of speech will clip or rush at 8s.
- [1087e186fed5] **Don't put on-screen text in the prompt.** Spoken lines are fine; rendered captions still come from `text-overlays.json` in post.
- [0acb882ac4aa] **Don't stack two camera moves.** One move per shot.
- [561e4601866e] **Don't let Veo's auto-audio fight a post audio bed.** Pick one owner of sound per shot.
- [93e1dbd6d5ab] Veo clips arrive with audio attached. They still need: editorial assembly to timing, on-screen text compositing from `text-overlays.json`, a color-grade pass, and an audio decision, keep Veo's native track, or mute it and use the storyboard's recorded VO and music. State which in handoff.

## visual-prompt-forge/examples/one-shot-all-adapters/README.md

- [4227374e4dd2] This example takes a single shot from the WhyStrohm 30-second pitch and renders it through the generator adapters in the pack. Use it as a calibration reference: same intent, same data, different prompt syntaxes. Six stills adapters are shown, plus the default motion adapter (Kling) standing in for the motion video lane.
- [4f3b139befa2] The on-screen text content. Even though shot_04 has an on-screen text overlay (`text_03`, "You don't have a content problem. You have an infrastructure problem."), none of the prompts contain that text. It's composited separately per the five-layer model.

## visual-prompt-forge/references/consistency-locks.md

- [00ad95b7807d] Same principle for `series_lock.lighting`. Lighting direction in particular is critical, flipping window-left to window-right between shots produces obvious cuts where there shouldn't be any.
- [199cfb9ab91d] Generate the hero shot first (any shot, usually `shot_01` or whichever is most defining)
- [b2e806d6105a] Use that image as the reference for every subsequent shot
- [14c534d5e7f2] Each subsequent prompt has the verbatim character anchor PLUS the reference image link
- [926508430703] **This is the most effective lock for character consistency** in 2026. Use it whenever the storyboard features the same person across multiple shots.
- [a0d393395e3a] When the storyboard has a distinctive visual style (specific film stock, specific lighting school, specific color theory), use a style reference image:
- [4140ed69949c] A subtle one that breaks scenes when violated. If `series_lock.lighting` says "soft natural side-light, large window LEFT", then every shot's lighting must respect that direction.
- [20b3434a9a5d] When a shot reverses character orientation (e.g., over-the-shoulder reverse), update the rationale to acknowledge the lighting flip:
- [3b984b2349a3] A few things people try that don't actually fix consistency:
- [0f136ad02a4a] **Adding "consistent character" or "same person" to the prompt**, generators don't read meta-instructions
- [985e93f22844] **Numbering shots in the prompt** ("shot 3 of 7, same as before"), generators don't have memory across calls
- [dd6e04a7a56e] **Asking for "exactly the same"**, there is no such thing in stateless image gen; you reduce drift, you don't eliminate it
- [bfb6f1d9e6b2] Accept that some shots will need re-rolls. Budget for it. The locks reduce the failure rate; they don't eliminate it.

## visual-prompt-forge/references/failure-modes.md

- [3613e7f4cf02] What goes wrong when generated images don't match the storyboard, and what to fix at the prompt level vs. accept as editorial work.
- [b70a07474b42] No "never" list applied from brand-lock
- [2757ce63d7e2] Verify brand-lock "never" list is being applied, if it includes "no AI uncanny", surface that into the prompt
- [8f8dc623566a] Use Flux 2 Pro or Midjourney v7 instead of cheaper models for hero shots
- [b826ad9667a2] Use reference image after the first successful shot
- [717c03da642d] For Midjourney, use `--cref` with `--cw 50`
- [6447bec15b56] The right answer is almost always: **don't put text in the prompt**. Composite separately from `text-overlays.json`.
- [359736f73561] If text must be in-image (poster work), use Ideogram v3 with explicit override flag
- [5945d25c9b90] Use simple fonts (sans-serif, clean serif), cursive and decorative fonts fail even on Ideogram
- [ecb6a8e221f1] For GPT Image (best at spatial reasoning), use percentage references: "subject at left 30% of frame"
- [982752f60d62] **Accept editorially when:** generation is close enough that retouching gets there. Don't burn API credits chasing perfect on-prompt.
- [1f983ff0ee18] You've re-rolled the same shot 5+ times with no improvement → the prompt is fine; the model can't render this concept; pick a different shot or different generator
- [12009aa60167] You're tweaking single words and hoping → you've hit prompt-level diminishing returns; move to image-to-image refinement (Nano Banana) or post-production
- [4be94337bb02] The image is 80% right and the gap is editorial → ship to post and let the editor finish
- [33fc833724e0] Generation is one stage in a pipeline. Don't try to make it the whole pipeline.

## visual-prompt-forge/references/prompt-anatomy.md

- [bcaac139f9b7] "Never" list (things this brand never does, e.g. "no stock photo aesthetic", "no AI uncanny", "no over-saturated", "no shouting copy")
- [e95be207e462] This layer answers: **what does the brand always look and feel like?**
- [67037c4b307e] **Never appears in image prompts** (except Ideogram Mode 2 with explicit override).
- [e177c4f10a04] **Editability.** Composited text can be revised without re-generating images.
- [4c22b71ebf0a] **Quality.** Even Ideogram and GPT Image (the best at text) produce typography that lags professional design tools.
- [5f5e6ee4ad91] **Animation.** Animated text needs After Effects / Remotion / CapCut. Static rendered text is dead-on-arrival for motion content.
- [05efedce58b5] **Brand control.** Composited text uses exact brand fonts and exact brand colors. Generated text approximates.
- [c8d6aa0aff0b] The adapter pulls from Layers 1–3 and produces a string. Layer 4 lives parallel and never enters the prompt.
<!-- SOURCE_FILE_END: repo/nblm-ids/visual-prompt-forge.md -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/PREGUNTA.txt -->
# SOURCE FILE: `repo/notebooklm-corpus/PREGUNTA.txt`

CASO: maestro de rostro (T1) para Nano Banana Pro — anclaje de campaña.

Las fuentes de este notebook contienen toda la documentacion de mi pipeline de
produccion visual: 12 skills, 90 archivos.

Dime, de TODAS las reglas contenidas en esas fuentes, cuales aplican a este caso
y cuales no.

Formato: una linea por regla.
  APLICA — <archivo>: <la regla, textual>
  NO APLICA — <archivo>: <la regla, textual> — <por que no aplica>

Requisitos:
- Recorre las fuentes completas. No me des solo las mas relevantes.
- No resumas ni agrupes reglas distintas en una linea.
- Al final dime cuantas reglas normativas encontraste en total.

<!-- SOURCE_FILE_END: repo/notebooklm-corpus/PREGUNTA.txt -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/ai-production-director.md -->
# SOURCE FILE: `repo/notebooklm-corpus/ai-production-director.md`

# SKILL: ai-production-director

Documentacion completa del skill. Cada seccion es un archivo distinto.


---

## ARCHIVO: ai-production-director/SKILL.md

---
name: ai-production-director
description: >-
  Skill maestra que orquesta el pipeline completo de producción audiovisual con AI — de creative brief a Final AI Video Production Package. Dirige y secuencia las sub-skills instaladas (screenwriter, video, image, ai-video-storyboard, storyboard-architect, visual-prompt-forge, visual-asset-critic, brand-lock-extractor, storyboard-html-preview, visual-media) según el track del proyecto, resuelve conflictos entre ellas y aplica quality gates por etapa. USA ESTE SKILL SIEMPRE que el usuario pida producir un video completo — spot, campaña, reel con narrativa, brand film, explainer o cortometraje — o diga "pipeline completo", "producción completa", "de brief a video", "production package", "arranca la producción", o entregue un creative brief esperando el paquete final. APLICAR TAMBIÉN si pide una parte del flujo pero el contexto revela un proyecto multi-etapa. NO aplicar a piezas sueltas — un solo prompt (usar image/video), un storyboard aislado (usar storyboard-architect), o teoría de cine (usar visual-media).
license: Apache-2.0 (orquestador original de Final Upgrade AI; sub-skills conservan sus licencias — smixs video/image son CC BY 4.0 con atribución obligatoria a Serge Shima)
metadata:
  version: 1.0.0
  author: Final Upgrade AI
  pipeline: brief → strategy → script → direction → shots → anchors → prompts → package
---

# AI Production Director

Eres el director de producción del pipeline. Tu trabajo NO es escribir guiones, prompts ni storyboards tú mismo desde cero — para eso existen las sub-skills, cada una con oficio profundo que tú no debes duplicar ni contradecir. Tu trabajo es:

1. **Clasificar** el proyecto y elegir el track correcto.
2. **Secuenciar** las etapas y cargar la sub-skill correcta en cada una.
3. **Custodiar los gates**: ninguna etapa arranca sin que la anterior pase su quality gate.
4. **Resolver conflictos** entre sub-skills con las reglas de la sección 6 — las decidiste una vez, no se renegocian por proyecto.
5. **Mantener trazabilidad**: todo artefacto downstream traza a un shot ID, todo shot traza a una escena, toda escena al concepto aprobado.

El anti-patrón que este skill existe para matar: "escríbeme un guion y dame prompts" en un solo paso. Eso produce prompts sin dramaturgia, sin consistencia visual y sin trazabilidad. El pipeline produce un paquete de producción.

## 1. Mapa de sub-skills

| Sub-skill | Capa | Qué aporta | Autoridad sobre |
|---|---|---|---|
| `brand-lock-extractor` | 0 · Marca | brand-lock.md de 9 secciones desde assets reales | Parámetros de marca |
| *(este skill)* + `references/creative-strategy.md` | 1 · Estrategia | Territorios, big ideas, 3–5 concept cards, dirección narrativa | Estrategia creativa |
| `screenwriter` | 2 · Guion | Concept → treatment → script con escenas XML-tagged | Estructura narrativa y diálogo |
| `video` (smixs) — capa dramaturgia | 3 · Dirección | Fórmula de escena, Ley de 3 Detalles, Regla de Seis de Murch, blocking, ritmo | Dramaturgia y lenguaje de cámara |
| `storyboard-architect` (shotkit) | 4 · Shot planning | storyboard.md + shots.json + text-overlays.json + run.json, validados por schema | **Fuente de verdad estructural** desde aquí |
| `ai-video-storyboard` | 4 · Shot planning (EXPRESS) | Shot list ligero por cadencia de plataforma | Solo track EXPRESS |
| `image` (smixs) | 5 · Anchors | Sintaxis por modelo de imagen (Nano Banana, GPT Image 2), character sheets, keyframes | Sintaxis final de prompts de imagen |
| `visual-prompt-forge` (shotkit) | 5–6 · Prompts | shots.json → borradores de prompt por adaptador; modo revisión desde critique.json | Estructura shots→prompt y loop de revisión |
| `visual-asset-critic` (shotkit) | 5 · QA | Crítica de render vs. shot origen, critique.json accionable | Aceptar/rechazar renders |
| `video` (smixs) — archivos de modelo | 6 · Video prompts | Sintaxis exacta Seedance/Kling/Veo, protocolos de diálogo, failure modes | Sintaxis final de prompts de video |
| `storyboard-html-preview` (shotkit) | 7 · Entrega | Preview HTML single-file para cliente | Formato de entrega visual |
| `visual-media` | Transversal limitada | Ver sección 7 — SOLO animación y material didáctico ES | Proyectos de animación |
| `aurora-prompt-linter` (si está instalada) | Gate final | Validación determinista de todo prompt visual antes de entregar | Veto final sobre prompts |

Cuando ejecutes una etapa, LEE el SKILL.md de la sub-skill correspondiente y sigue su protocolo completo — no trabajes de memoria sobre lo que "recuerdas" que dice.

## 2. Selección de track

Clasifica el proyecto en el primer mensaje. Si el brief no da los datos, pregunta UNA sola vez, todo junto: plataforma y duración, marca/cliente, objetivo, deadline, y si existen assets de marca.

| Criterio | EXPRESS | STANDARD | FILM |
|---|---|---|---|
| Duración | ≤30s | 30–90s | 90s–10min |
| Cliente/marca formal | No | Sí | Sí o pieza de autor |
| Narrativa | Un beat (hook→payoff) | Arco simple | Multi-escena, personajes |
| Revisiones esperadas | 0–1 | 1–2 rondas | Rondas formales |
| Etapas | 4 → 5/6 comprimidas | 0–7 con estrategia ligera | 0–7 completas |
| Ejemplo | Reel orgánico interno | Spot de campaña, brand film corto | Cortometraje, explainer largo, film de marca |

- **EXPRESS**: salta estrategia formal y guion; usa `ai-video-storyboard` para el shot list, luego directo a `image`/`video` para prompts. Sin shots.json ni loop de crítica salvo que el usuario lo pida.
- **STANDARD**: pipeline completo pero Etapa 1 comprimida (2–3 conceptos en vez de 5, sin documento de territorios) y Etapa 2 comprimida (script directo, sin treatment separado).
- **FILM**: todas las etapas, todos los artefactos, todos los gates.

Anuncia el track elegido y el plan de etapas en una línea antes de arrancar. Si el usuario ya trae artefactos de etapas previas (un script, un shots.json), entra al pipeline en la etapa correspondiente — no repitas trabajo hecho.

## 3. Las etapas

Cada etapa declara: sub-skill, entradas, salidas, y gate. El gate se verifica ANTES de avanzar. Si falla, se corrige en la etapa actual — nunca se "arregla después".

### Etapa 0 — Brand Lock *(solo si hay marca/cliente)*
- **Skill:** `brand-lock-extractor`. Entrada: sitio web, brand book, screenshots o descripción.
- **Salida:** `brand-lock.md` (9 secciones, cada valor con fuente y confianza).
- **Gate:** el usuario confirma los valores flagged como estimados. Sin marca formal, usa el Visual Theme de la Etapa 3 como sustituto ligero.

### Etapa 1 — Creative Strategy
- **Módulo:** `references/creative-strategy.md` de ESTE skill (no hay sub-skill instalada para esto — el módulo es la autoridad).
- **Salida:** documento con territorios explorados, 3–5 concept cards, matriz de selección, y dirección narrativa del concepto ganador.
- **Gate:** el usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto.

### Etapa 2 — Screenwriting
- **Skill:** `screenwriter`. Entrada: concept card ganadora + dirección narrativa.
- **Salida:** treatment (solo FILM) → script con escenas XML-tagged, sluglines, acción y diálogo.
- **Gate:** cada escena pasa la fórmula de escena de `video`/dramaturgy (deseo + obstáculo + geometría + mirada + ritmo) y la three-jobs rule: cada escena cambia emoción, avanza acción o sube presión. Escena que no hace ninguna de las tres se corta aquí, no en el shot list.

### Etapa 3 — Cinematic Direction
- **Skill:** `video` (smixs), archivos `dramaturgy.md` y `universal-rules.md` + vocabulario de cámara/luz.
- **Salida:** documento de dirección por escena: blocking, composición, cámara motivada (cada movimiento responde "¿qué cambió?"), lente, luz, evolución de color, lenguaje de edición, y los 5 anclas de la pieza (una emoción, un motivo, un objeto, un quiebre, una imagen final).
- **Gate:** cero palabras del vocabulario prohibido (sección 6.1). Cada decisión de cámara tiene razón dramática escrita.

### Etapa 4 — Shot Planning
- **Skill:** `storyboard-architect` (STANDARD/FILM) o `ai-video-storyboard` (EXPRESS).
- **Entrada:** script + documento de dirección. **Salida:** `storyboard.md`, `shots.json`, `text-overlays.json`, `run.json`, `brand-lock.snapshot.md`.
- **Gate:** `tools/validate_shots.py` limpio + six-point dramaturgy check + auditoría de 3 detalles por shot (presión ambiental, micro-acción física, ancla de sonido/motivo). Un shot con cero detalles es filler y se elimina.
- Desde aquí, **shots.json es la fuente de verdad**. Ningún prompt, imagen o revisión existe sin shot ID.

### Etapa 5 — Anchor Images
- **Skills:** `visual-prompt-forge` genera los borradores desde shots.json (adaptador correcto por modelo) → `image` (smixs) es la autoridad de sintaxis final por modelo → el usuario genera → `visual-asset-critic` evalúa cada render contra su shot.
- **Salida:** plan de anchors (character refs, environment refs, keyframes por shot clave), prompts finales, y critiques por ronda.
- **Gate:** cada anchor crítico tiene critique ACCEPT, con máximo 2 rondas de revisión vía forge en modo revisión (solo shots reprobados). A la tercera falla, se replantea el shot, no el prompt.

### Etapa 6 — Video Prompts
- **Skills:** `visual-prompt-forge` estructura el prompt de movimiento desde shots.json + anchor aprobado → `video` (smixs) archivo del modelo destino es la autoridad de sintaxis final: motion brief (no re-describir la escena que el anchor ya fija), cámara, blocking, performance, evolución de luz, física, protocolo de diálogo/audio.
- **Salida:** prompts de video finales por shot, con continuity blocks entre clips.
- **Gate obligatorio:** los dos checks de `video` (dramaturgy check de 6 puntos + auditoría de 3 detalles) Y, si `aurora-prompt-linter` está instalada, el linter pasa limpio. Un prompt que falla cualquiera de los dos NO se entrega.

### Etapa 7 — Package & Delivery
- **Skill:** `storyboard-html-preview` para el preview de cliente + `references/production-package.md` de este skill para el ensamblado.
- **Salida:** Final AI Video Production Package (spec completa en la referencia) + checklist de postproducción.
- **Gate:** checklist maestro de la referencia completo; trazabilidad verificada (muestreo: 3 prompts al azar trazan hasta su concepto).

## 4. Interacción con el usuario entre etapas

- Al cerrar cada gate, entrega el artefacto de la etapa y anuncia la siguiente en una línea. En STANDARD/FILM, los gates 1 (selección de concepto), 2 (script) y 4 (storyboard) requieren OK explícito del usuario; los demás avanzan solos salvo instrucción contraria.
- En EXPRESS, solo el shot list requiere OK antes de escribir prompts.
- Nunca preguntes lo que el brief o los artefactos previos ya responden.

## 5. Ejecución por etapa — regla de carga

En claude.ai las sub-skills están instaladas por separado. Al entrar a una etapa: (1) nombra la sub-skill que vas a usar, (2) lee su SKILL.md y los references que su protocolo exija para el caso, (3) ejecuta SU protocolo, no un resumen. La calidad del pipeline es la calidad de la sub-skill peor ejecutada.

## 6. Reglas de resolución de conflictos

Estas reglas son decisiones tomadas. Aplícalas sin reabrir el debate en medio de un proyecto.

### 6.1 Vocabulario
El vocabulario prohibido de `video`/dramaturgy (+ `aurora-prompt-linter` si está) **gana siempre**: "cinematic", "epic", "stunning", "masterpiece", "beautiful lighting", "professional", "high quality", emociones nombradas sin cuerpo. Esto **anula explícitamente** la regla de `ai-video-storyboard` de cerrar cada prompt con "cinematic 1080p, synchronized audio". En su lugar: la resolución, aspect ratio, duración y si el modelo genera audio se especifican como parámetros técnicos concretos según el archivo del modelo destino.

### 6.2 Sintaxis de modelo
`ai-video-storyboard` pide prompts model-agnostic; `video`/`image` (smixs) existen para sintaxis por modelo. Resolución: model-agnostic SOLO en artefactos intermedios (storyboard, shot cards). Todo prompt FINAL se escribe en la sintaxis del modelo destino según el archivo smixs correspondiente. Si el modelo no tiene archivo smixs (p.ej. Flux, Midjourney, Ideogram), la autoridad es el adaptador de `visual-prompt-forge`.

### 6.3 Fuente de verdad estructural
De la Etapa 4 en adelante: `shots.json`. Un cambio creativo se hace primero en shots.json y se propaga hacia abajo; nunca se parcha un prompt de forma que contradiga su shot.

### 6.4 División forge ↔ smixs
`visual-prompt-forge` es dueño del **flujo de datos** (shots.json → borrador, critique.json → revisión selectiva). `video`/`image` smixs son dueños del **texto final** del prompt. El borrador del forge se reescribe a sintaxis smixs; nunca al revés.

### 6.5 Atribución
Todo entregable que use la capa smixs conserva la línea: *Serge Shima — github.com/smixs/visual-skills* (CC BY 4.0, obligatorio, incluye derivados generados por agentes). Colócala en los créditos del production package, no en cada prompt.

## 7. Rol de visual-media (decisión de alcance)

`visual-media` NO participa en el pipeline live-action: todo lo que cubre (composición, tipos de plano, luz, movimientos de cámara, ritmo de edición) lo cubren con más profundidad `video`, `image` y `storyboard-architect`, y activarla ahí solo mete ruido de triggers. Se invoca ÚNICAMENTE en dos casos:

1. **Proyectos de animación** (2D/3D/motion graphics): es la única skill instalada con los 12 principios de Disney y el flujo de producción de animación. En un proyecto animado, su sección de animación se suma a la Etapa 3 como referencia de performance y timing.
2. **Material didáctico o de cara al cliente en español**: glosario de terminología audiovisual ES-MX para briefs, capacitaciones o justificar decisiones ante cliente hispanohablante.

## 8. Degradación

Si una sub-skill no está instalada, no improvises su oficio en silencio: dilo en una línea y aplica el sustituto — brand-lock ausente → Visual Theme ligero; storyboard-architect ausente → ai-video-storyboard con IDs de shot manuales; critic ausente → checklist de crítica manual contra el shot card; linter ausente → los dos checks de `video` como gate final. Los `tools/` de shotkit viajan dentro de cada .skill empaquetado; requieren `pyyaml` y `jsonschema`.

## 9. Referencias de este skill

- `references/creative-strategy.md` — Protocolo completo de la Etapa 1: territorios, big ideas, concept cards, matriz de selección, dirección narrativa. Léelo SIEMPRE al ejecutar la Etapa 1.
- `references/production-package.md` — Spec del Final AI Video Production Package, reglas de trazabilidad y checklist maestro. Léelo SIEMPRE al ejecutar la Etapa 7.


---

## ARCHIVO: ai-production-director/references/creative-strategy.md

# Etapa 1 — Creative Strategy

Este módulo es la autoridad de la Etapa 1 del pipeline. No existe sub-skill instalada para estrategia creativa: el protocolo vive aquí. El objetivo es que el guion de la Etapa 2 se escriba sobre UN concepto seleccionado con criterio, no sobre la primera idea que sonó bien.

Profundidad por track: FILM ejecuta todo. STANDARD ejecuta territorios en versión corta (media página), 2–3 concept cards y la matriz. EXPRESS no ejecuta esta etapa.

## 1. Lectura del brief

Antes de idear, extrae del brief y deja por escrito:

- **Problema de negocio** (qué debe cambiar en el mundo real si el video funciona)
- **Audiencia** (quién, en qué momento, con qué fricción — no demografía vacía)
- **Single-minded proposition**: la única cosa que el video debe dejar instalada. Una frase. Si el brief trae tres mensajes, forzar al usuario a elegir uno; los otros dos pueden vivir en texto de apoyo o piezas hermanas.
- **Tono de marca** (del brand-lock si existe)
- **Restricciones duras** (legales, de plataforma, de presupuesto de generación)

Si el single-minded proposition no se puede escribir en una frase, la Etapa 1 no puede continuar. Resuélvelo con el usuario primero.

## 2. Territorios creativos

Un territorio es un espacio conceptual desde el cual se puede contar la proposición — no una idea todavía. Explora 3–4 territorios genuinamente distintos entre sí. Prueba de distancia: si dos territorios producirían el mismo primer plano, son el mismo territorio.

Formato por territorio (4–6 líneas):

```
### Territorio: [nombre evocador]
- Ángulo: desde dónde se mira la proposición (el ritual, el antagonista, el después, el detalle invisible…)
- Tensión que explota: qué fricción humana real usa como motor
- Textura: cómo se ve y suena este territorio (2 líneas sensoriales, sin vocabulario prohibido)
- Riesgo: por qué podría fallar o ya estar quemado en la categoría
```

Registros útiles para forzar distancia entre territorios: emocional vs. funcional · íntimo vs. épico de escala · humor vs. gravedad · protagonista humano vs. producto/entorno como personaje · tiempo real vs. elipsis.

## 3. Big ideas y concept cards

De los territorios más fuertes, baja 3–5 conceptos (FILM) o 2–3 (STANDARD). Cada concepto es UNA película posible, no una variación de la anterior. Formato obligatorio:

```
## Concept Card [N] — [Nombre]
**Territorio de origen:** [cuál]
**Logline:** [la película en 1–2 frases: quién quiere qué, qué lo impide, qué vemos]
**Insight:** [la verdad humana sobre la que se para — algo que la audiencia reconoce como cierto]
**Arco en 3 beats:** [apertura → quiebre → resolución, una línea cada uno]
**Imagen final:** [el último frame, concreto — es lo que el espectador se lleva]
**Por qué vende la proposición:** [mecánica explícita: cómo este concepto instala la single-minded proposition]
**Riesgo principal:** [producción, tono, o percepción — y su mitigación en una línea]
**Complejidad de generación AI:** [Baja/Media/Alta — nº de personajes con continuidad, entornos, física difícil, diálogo lip-sync]
```

El campo de complejidad AI no es decorativo: un concepto brillante con 4 personajes en continuidad a través de 12 shots es un riesgo de producción real en video generativo, y el usuario debe elegirlo sabiéndolo.

## 4. Matriz de selección

Presenta los conceptos en una matriz 1–5, sin promediar a ciegas — el usuario pondera:

| Concepto | Fuerza del insight | Distintividad vs. categoría | Fit de marca | Claridad de la proposición | Viabilidad AI | Riesgo |
|---|---|---|---|---|---|---|

Debajo de la matriz, tu recomendación argumentada en un párrafo: cuál elegirías y por qué, nombrando el trade-off que implica. Recomendar es parte del trabajo; decidir es del usuario.

**Gate de la etapa:** el usuario selecciona un concepto (puede pedir un híbrido — trátalo como concepto nuevo con su propia card antes de avanzar).

## 5. Dirección narrativa del concepto ganador

Puente hacia `screenwriter`. Media página que fija, para el concepto elegido:

- **Estructura**: nº de escenas/actos y función de cada una (usar la three-jobs rule como criterio: cada escena cambia emoción, avanza acción o sube presión)
- **Punto de vista**: desde quién se cuenta y por qué
- **Los 5 anclas preliminares** (se refinan en Etapa 3): una emoción dominante, un motivo recurrente, un objeto, un quiebre, una imagen final
- **Reglas del mundo**: qué existe y qué no en esta pieza (época, lugar, nivel de realismo, presencia del producto)
- **Duración objetivo y densidad**: cuántos segundos por beat, dónde vive la pausa

Este documento + la concept card son la entrada completa de la Etapa 2. Si `screenwriter` tuviera que preguntar algo estructural, esta etapa quedó corta — corrígela aquí.


---

## ARCHIVO: ai-production-director/references/production-package.md

# Etapa 7 — Final AI Video Production Package

Spec del entregable final del pipeline. El paquete debe permitir que un editor, una agencia o el propio usuario dentro de tres meses produzca el video sin hacer una sola pregunta de contexto.

## 1. Estructura del paquete

```
production-package/
├── 00-README.md                  # Índice, track usado, resumen de decisiones, créditos
├── 01-strategy/
│   ├── brief.md                  # Brief original o su reconstrucción
│   ├── territories.md            # Territorios explorados (STANDARD/FILM)
│   ├── concept-cards.md          # Todas las cards + matriz + concepto seleccionado marcado
│   └── narrative-direction.md
├── 02-script/
│   ├── treatment.md              # Solo FILM
│   └── script.md                 # Escenas XML-tagged de screenwriter
├── 03-direction/
│   └── cinematic-direction.md    # Blocking, cámara, luz, color, 5 anclas, por escena
├── 04-shots/
│   ├── storyboard.md
│   ├── shots.json                # FUENTE DE VERDAD
│   ├── text-overlays.json
│   ├── run.json
│   └── brand-lock.snapshot.md
├── 05-anchors/
│   ├── anchor-plan.md            # Qué refs se necesitan y para qué shots
│   ├── prompts/round-N/          # Prompts de imagen por modelo, por ronda
│   ├── frames/round-N/           # Renders aprobados/evaluados
│   └── critiques/round-N/        # critique.json por shot evaluado
├── 06-video-prompts/
│   ├── prompts/                  # Un archivo por shot: shot_NN.<modelo>.txt
│   └── continuity-notes.md       # Bloques de continuidad entre clips
├── 07-delivery/
│   ├── preview.html              # storyboard-html-preview, single-file
│   └── post-production.md        # Checklist de post (ver §3)
└── brand-lock.md                 # Si existió Etapa 0
```

En EXPRESS el paquete se comprime a: README, shot list, prompts y checklist de post — misma trazabilidad, menos carpetas.

## 2. Reglas de trazabilidad

1. Todo prompt (imagen o video) lleva en comentario su `shot_id`.
2. Todo shot en shots.json referencia su escena del script (`scene` field o nota).
3. El script referencia la concept card ganadora en su encabezado.
4. Cambios: si un prompt necesita cambiar algo que su shot fija (encuadre, acción, luz), el cambio se hace en shots.json y se regenera hacia abajo. El paquete nunca contiene un prompt que contradiga su shot.
5. Verificación de cierre: muestrea 3 prompts al azar y traza la cadena prompt → shot → escena → concepto. Si un eslabón falta, el paquete no se entrega.

## 3. Checklist de post-producción (07-delivery/post-production.md)

Adaptar al proyecto, con specs concretos — no placeholders:

```
- [ ] Generar los N shots en [modelo(s)] con los prompts de 06-video-prompts/
- [ ] Verificar cada clip contra su shot card (encuadre, acción, luz) antes de editar
- [ ] Ensamblar en [NLE] siguiendo el orden y duraciones de shots.json
- [ ] Aplicar grade de consistencia: [referencia de color del brand-lock o Visual Theme]
- [ ] Transiciones: [tipo y duración definidos en dirección, no "al gusto"]
- [ ] Audio: [música género/BPM/posición de beats + VO + ambientes según dirección de audio por shot]
- [ ] Overlays de texto según text-overlays.json (tipografía del brand-lock)
- [ ] Export: [resolución, aspect ratio, fps, códec, loudness según plataforma destino]
- [ ] QA final contra los 5 anclas: ¿la pieza terminada conserva emoción, motivo, objeto, quiebre e imagen final?
```

## 4. Checklist maestro del pipeline (gate de la Etapa 7)

- [ ] Concepto seleccionado por el usuario documentado en 01-strategy
- [ ] Cada escena del script pasa fórmula de escena + three-jobs rule
- [ ] Dirección cinematográfica sin vocabulario prohibido
- [ ] shots.json validado (`validate_shots.py` limpio) y auditoría de 3 detalles por shot
- [ ] Anchors críticos con critique ACCEPT (≤2 rondas)
- [ ] Prompts de video en sintaxis del modelo destino, con los dos checks de `video` pasados
- [ ] `aurora-prompt-linter` limpio sobre todos los prompts (si está instalada)
- [ ] Trazabilidad muestreada (§2.5)
- [ ] preview.html abre offline y refleja el estado final
- [ ] Créditos en 00-README.md: atribución *Serge Shima — github.com/smixs/visual-skills* si se usó la capa smixs; licencias de sub-skills anotadas
- [ ] 00-README.md explica en ≤1 página qué es el proyecto, qué track se usó y dónde está cada cosa


<!-- SOURCE_FILE_END: repo/notebooklm-corpus/ai-production-director.md -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/ai-video-storyboard.md -->
# SOURCE FILE: `repo/notebooklm-corpus/ai-video-storyboard.md`

# SKILL: ai-video-storyboard

Documentacion completa del skill. Cada seccion es un archivo distinto.


---

## ARCHIVO: ai-video-storyboard/SKILL.md

---
name: ai-video-storyboard
description: Use when planning a multi-shot AI video (TikTok Reel, Instagram Ad, YouTube Shorts, product explainer) where the target duration exceeds what a single AI generation can produce (over 15 seconds), and you need a coordinated shot list with visually consistent prompts for each segment
---

# AI Video Storyboard Generator

## Overview

AI video generators produce 5–15 second clips. Real-world videos are longer: 30s TikToks, 60s ads, 90s explainers. This skill bridges that gap by producing a complete **shot-list storyboard** — a coordinated sequence of per-shot prompts with shared visual language, so the assembled final video looks like one intentional piece of work rather than six disconnected clips.

**Core insight:** Visual consistency across shots matters more than any single shot being perfect. A mediocre but consistent set of shots edits together; six gorgeous but mismatched shots do not.

## When to Use

- User wants a video longer than 15 seconds
- User wants a TikTok / Reel / Short / ad / explainer / B-roll sequence
- User says "help me make a video about X" and has no shot list
- User is about to generate multiple clips and needs a plan

**Do NOT use for:**
- Single-shot generation (just help with one prompt instead)
- Static image generation
- Video editing advice after clips are generated (that's a separate concern)

## Workflow

### Step 1 — Brief Intake

Ask the user these questions in a single message. Accept short answers:

1. **Goal platform and duration?** (TikTok 30s / Reel 15-60s / YouTube Short / Instagram Ad / explainer)
2. **What is the video about?** (subject, story, product)
3. **Brand vibe / tone?** (cozy, energetic, premium, minimalist, playful, cinematic, etc.)
4. **Call to action at the end?** (visit website, buy product, follow channel, etc.)
5. **Any hard constraints?** (must include logo, specific colors, locations, etc.)

If user already provided some of these, skip those questions and confirm the rest.

### Step 2 — Infer Structure

Based on duration and platform, divide the timeline into shots of ~5 seconds each (the sweet spot for AI video generators).

**Standard cadences:**

| Platform | Duration | Shots | Pacing |
|---|---|---|---|
| TikTok Hook | 15s | 3 | Fast cuts, single idea |
| TikTok Reel | 30s | 6 | Hook → Build → Payoff → CTA |
| Instagram Ad | 15s | 3 | Hook → Product → CTA |
| Instagram Ad | 30s | 6 | Hook → Problem → Product → Benefit → Social proof → CTA |
| YouTube Short | 60s | 12 | Hook → 3-act structure → CTA |
| Product Explainer | 90s | 18 | Problem → Solution → How it works → Results → CTA |
| Brand Story | 60s | 10-12 | Atmosphere-driven, longer shot holds |

### Step 3 — Establish Visual Consistency Layer

Before writing any shot, lock in the shared visual language. This is what makes shots edit together:

- **Color palette** (3-5 specific hex values or named colors)
- **Lighting style** (golden hour / neon / overcast / motivated / cinematic rim light)
- **Lens character** (shallow DOF / deep focus / wide angle distortion / macro)
- **Film look** (clean digital / 16mm grain / anamorphic / VHS / 35mm)
- **Motion language** (handheld / locked off / dolly only / gimbal smooth)

Write these as a **Visual Theme** block at the top of the output. Every shot's prompt must respect this block.

### Step 4 — Write Each Shot

For each shot, produce this structure:

```
## Shot N (START-ENDs) — [Purpose label: Hook / Setting / Action / Detail / Reveal / CTA]

**Composition:** [shot type + angle, e.g., "Extreme close-up, overhead"]
**Camera move:** [locked / slow dolly in / tracking / crane up / etc.]
**Lighting:** [from the Visual Theme, applied to this scene]
**Subject:** [what is in frame]
**Action:** [what is happening]

**Prompt to copy:**
> [Complete, cinematic-quality prompt, 40-80 words, including: subject + action + environment + camera + lighting + style + technical spec (duration, aspect ratio, resolution). Always ends with "cinematic 1080p, synchronized audio"]

**Audio direction:** [what the synchronized audio should sound like — ambient sounds, music beat position, voice-over line]
```

**Critical rules for shot prompts:**

1. **Always specify the shared visual language** in every prompt (color palette, lighting, lens character, film look). This is how you enforce consistency.
2. **Specify exact duration** (4s / 5s / 8s) and **aspect ratio** (9:16 for TikTok/Reels, 16:9 for YouTube landscape, 1:1 for feed posts).
3. **Always end with "cinematic 1080p, synchronized audio"** — this signals professional-grade quality and works with modern video models that support both.
4. **Use cinematography vocabulary**: ECU (extreme close-up), CU, MS (medium shot), WS (wide shot), OTS (over-the-shoulder), POV, Dutch angle, low angle, high angle, bird's eye, dolly in, dolly out, tracking, handheld, rack focus, etc.
5. **Don't write abstract prompts** — be concrete. "A woman" → "A barista in her late 20s with wavy auburn hair, wearing a denim apron".
6. **No model-specific hacks** — don't write prompts tuned to specific model quirks. Write model-agnostic cinematic prompts that work anywhere.

### Step 5 — Add Narrative Structure

The sequence of shots must have a **story arc**, not a random list. Use one of these patterns:

**Pattern A — Hook / Build / Payoff / CTA (TikTok default)**
- Shot 1: Visual hook (stop the scroll)
- Shot 2-3: Build context / intrigue
- Shot 4-5: Main content / payoff
- Shot 6: CTA

**Pattern B — Problem / Solution / Proof / CTA (Ad default)**
- Shots 1-2: Relatable problem
- Shot 3: Your product as solution
- Shots 4-5: Benefits / results
- Shot 6: CTA

**Pattern C — Atmosphere → Climax (Brand story)**
- Longer atmospheric shots
- Slow reveal
- Emotional climax
- Logo reveal

### Step 6 — Add Post-Production Checklist

Close with actionable post-production notes:

```
## Post-Production Checklist
- [ ] Generate all N shots with your preferred AI video tool
- [ ] Stitch in [CapCut / Descript / DaVinci Resolve / Premiere]
- [ ] Apply [specific LUT or color grade] for consistency
- [ ] Add [transition type and duration] between shots
- [ ] Layer BGM: [genre / BPM / mood]
- [ ] Add text overlays for [hook / CTA / captions]
- [ ] Export [platform spec: 9:16 1080x1920 30fps for TikTok, etc.]
```

### Step 7 — Explain Why It Works

Close with a "Why this works" block explaining the creative decisions. This educates the user and differentiates your output from generic prompt lists. Reference:

- The hook rule (first second determines watch-through)
- Pacing cadence (average scroll time)
- Story structure (why the shot order matters)
- Platform-specific conventions

## Output Format

The final output is a single Markdown document containing:

1. **Header** — Title, duration, shot count, aspect ratio
2. **Visual Theme** — Shared palette, lighting, lens, film look, motion
3. **Shot List** — N shots, each following the structure in Step 4
4. **Post-Production Checklist**
5. **Why This Works** — creative rationale

See `examples/tiktok-reel-30s-coffee.md` for a complete worked sample output (coffee shop opening TikTok, 30s / 6 shots).

## License

MIT — use freely, commercial or personal.


---

## ARCHIVO: ai-video-storyboard/examples/tiktok-reel-30s-coffee.md

# 30s TikTok Reel — Coffee Shop Opening

**Brief:** Small specialty coffee shop launching next week. Want a TikTok Reel to build anticipation and drive foot traffic on opening day.

- **Platform:** TikTok
- **Duration:** 30 seconds
- **Shots:** 6 × 5s
- **Aspect:** 9:16
- **CTA:** "Visit us. Opening next Saturday."
- **Brand vibe:** Warm, analog, hand-crafted, for slow-morning coffee lovers

---

## Visual Theme (applied to every shot)

- **Color palette:** Deep espresso brown `#3B2416`, cream `#F5E6D3`, muted amber `#D4A574`, soft sage green `#8FA88C`, black coffee `#1A1210`
- **Lighting style:** Warm golden backlight with motivated window light, soft shadows, no harsh fluorescents
- **Lens character:** Shallow depth of field, gentle bokeh, 35mm full-frame look
- **Film look:** Subtle 16mm film grain, slightly muted saturation, warm color temperature (around 3200K)
- **Motion language:** Locked-off or very slow push-ins, no handheld shake

---

## Shot 1 (0-5s) — Hook: The Pour

**Purpose:** Instant visual hook to stop the scroll. Universal sensory trigger.

**Composition:** Extreme close-up (ECU), slight overhead angle (~20° down)
**Camera move:** Locked off with micro push-in
**Lighting:** Strong warm backlight behind the cup, light rim-lighting the steam
**Subject:** Gooseneck kettle pouring hot water into a white ceramic V60 dripper
**Action:** Slow bloom of coffee grounds rising as water hits them

**Prompt to copy:**

> Extreme close-up overhead shot of hot water pouring from a brass gooseneck kettle into a white ceramic V60 dripper filled with dark coffee grounds, the grounds blooming and rising in slow motion, warm golden backlight with visible steam curling upward, shallow depth of field, 35mm full-frame look, subtle 16mm film grain, deep espresso brown and cream color palette, muted saturation, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Intimate sound of pouring water, bloom of hot coffee crema, distant café ambience fading in. First acoustic guitar note plays at 4.8s to bridge into Shot 2.

---

## Shot 2 (5-10s) — Setting: The Space

**Purpose:** Establish the space. Show it's real, it's cozy, it exists.

**Composition:** Medium wide shot (MWS), waist-high eye level
**Camera move:** Very slow dolly forward (~0.5x speed feeling)
**Lighting:** Large window on camera-left, warm amber streetlamp glow from deep background
**Subject:** Empty wooden café interior, reclaimed wood counter in focus, shelves of mugs blurred in background
**Action:** Morning sun rays cut through the space, dust motes floating

**Prompt to copy:**

> Medium wide shot slow dolly forward into a cozy specialty coffee shop interior, warm morning sunlight streaming through large windows on the left, reclaimed dark wood counter in sharp focus with shelves of handmade ceramic mugs blurred in background, dust motes visible in sun rays, muted sage green wall accents, shallow depth of field, 35mm full-frame look, subtle film grain, warm 3200K color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Acoustic guitar strum begins, layered with distant morning street sounds (birds, footsteps).

---

## Shot 3 (10-15s) — Human: The Barista

**Purpose:** Add a human face. Empathy trigger. This is the emotional center.

**Composition:** Medium close-up (MCU), slightly low angle (~10° up)
**Camera move:** Locked off
**Lighting:** Window light as key from camera-left, warm practical from counter lamp as fill
**Subject:** A female barista in her late 20s, wavy auburn hair tied back loosely, wearing a denim apron over a cream linen shirt
**Action:** She looks down at a pour-over in her hands, then looks up toward camera with a small, genuine smile

**Prompt to copy:**

> Medium close-up slightly low angle of a female barista in her late twenties with wavy auburn hair tied back, wearing a denim apron over cream linen shirt, standing behind a dark wood café counter, soft window light from the left creating warm rim light on her hair, she looks down at a pour-over coffee in her hands then slowly looks up at camera with a genuine small smile, shallow depth of field, 35mm full-frame look, subtle 16mm film grain, warm color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Guitar melody crescendo, ambient café sounds swell subtly. No voice-over needed — her expression carries the emotion.

---

## Shot 4 (15-20s) — Detail: The Beans

**Purpose:** Tactile close-up. Signals craft and quality.

**Composition:** Extreme close-up (ECU), macro-style
**Camera move:** Micro zoom in
**Lighting:** Warm directional light from upper right, strong shadows
**Subject:** Hand scooping whole coffee beans from a burlap sack into a wooden measuring cup
**Action:** Slow-motion bean cascade as hand tips the scoop

**Prompt to copy:**

> Macro extreme close-up of a hand scooping whole dark roasted coffee beans from a burlap sack into a small wooden measuring cup, slow motion cascade of beans spilling out as the hand tips the scoop, warm directional window light from upper right creating strong shadow depth, individual beans visible in sharp detail, shallow depth of field, deep espresso brown and burlap cream palette, subtle 16mm film grain, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Sound of beans tumbling, slightly rhythmic, quantized to the guitar beat. Guitar is now in full swing.

---

## Shot 5 (20-25s) — Atmosphere: The Customer Moment

**Purpose:** Show the space in use. Aspirational — "this could be you."

**Composition:** Medium shot (MS), over-the-shoulder angle (OTS)
**Camera move:** Slow pedestal down (~0.5x speed feeling)
**Lighting:** Window backlight creating gentle rim on the customer, warm amber spill from interior
**Subject:** A young customer sitting at a wooden window counter, laptop open, ceramic cup in hand
**Action:** She takes a slow sip, closes eyes briefly, sets cup down

**Prompt to copy:**

> Over-the-shoulder medium shot of a young female customer sitting at a wooden window counter inside a coffee shop, her laptop open in soft focus, a handmade ceramic coffee cup in her hand, warm window backlight creating gentle rim light on her silhouette, amber interior lamps in background blur, she slowly takes a sip of coffee and briefly closes her eyes in appreciation, slow pedestal camera move downward, shallow depth of field, 35mm full-frame look, subtle film grain, warm 3200K color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Guitar continues, ambient café sounds (gentle chatter, page turning), the soft clink of cup on saucer at the end.

---

## Shot 6 (25-30s) — CTA: Opening Reveal

**Purpose:** Clear, confident call to action. Brand reveal.

**Composition:** Medium wide shot (MWS), straight-on eye level
**Camera move:** Locked off, zero movement (intentional stop to read text)
**Lighting:** Soft even morning light
**Subject:** The café's hand-painted wooden sign on the front door, "Opening Saturday" chalk text visible below
**Action:** Minimal — a hand hanging an "OPEN" wooden sign on the door handle

**Prompt to copy:**

> Medium wide locked-off shot of a hand-painted wooden shop sign above a dark-framed café door, below it a small chalkboard reading "Opening Saturday", a hand reaches in frame to hang a wooden "OPEN" sign on the door handle, soft even morning light, sage green accent wall visible, warm muted palette, shallow depth of field on the door, 35mm full-frame look, subtle film grain, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

**Audio direction:** Guitar resolves to final note, café ambience fades down. Sound of the wooden sign clacking against the door.

---

## Post-Production Checklist

- [ ] Generate all 6 shots with your preferred AI video tool
- [ ] Stitch in **CapCut** or **Descript** (simplest for TikTok workflow)
- [ ] Apply a consistent warm LUT — **Kodak Portra 400** emulation or **"Teal & Orange: Warm"** works well
- [ ] Add 0.3-0.4s **dissolve transitions** between Shots 1→2, 2→3, 4→5. Use a **hard cut** for Shot 3→4 (energy shift) and Shot 5→6 (CTA impact)
- [ ] Layer **BGM**: single acoustic guitar track at ~85 BPM, free from Artlist/Epidemic Sound. Something like "Morning Coffee" or "Slow Brew" genre keywords
- [ ] Add **text overlays**:
  - 0-1s: "Slow morning ☕️" (bottom center)
  - 25-30s: "Opening Saturday · @yourshop" (bold, centered)
- [ ] Export: **9:16, 1080×1920, 30fps, H.264, target bitrate 12 Mbps**
- [ ] Upload to TikTok with hashtags: `#coffeeshop #specialtycoffee #openingsoon #grandopening #coffeelover`

---

## Why This Works

**Structure:** Hook (1) → Setting (2) → Human (3) → Detail (4) → Atmosphere (5) → CTA (6). This is the classic TikTok cadence adapted for brand storytelling: a sensory hook to stop the scroll, a human face to build empathy, craft details to signal quality, an aspirational moment, then a clean CTA. No shot is wasted.

**Visual consistency:** Every shot shares the same color palette (espresso/cream/amber/sage), the same lighting temperature (warm 3200K with motivated window light), the same lens character (shallow DOF, 35mm), and the same film look (subtle 16mm grain). Even if the 6 shots are generated in separate runs, they will edit together as if shot by the same cinematographer in the same session.

**Pacing:** 5 seconds per shot matches the average scroll-dwell time on TikTok. Long enough to land the idea, short enough to maintain momentum. The 30s total is the sweet spot for completion-rate-optimized Reels.

**Emotion arc:** Shot 1 is sensory (hot water, steam), Shot 3 is emotional (barista's smile), Shot 5 is aspirational (customer enjoying the moment). This gives the viewer a reason to care beyond "coffee exists here".

**Why the prompts work:** They lean heavily on concrete cinematic vocabulary (shallow DOF, rim light, warm backlight, film grain) — specifics that modern AI video models can actually execute. The synchronized audio direction means each shot arrives with ambient café sounds pre-baked, dramatically reducing post-production sound design time.


<!-- SOURCE_FILE_END: repo/notebooklm-corpus/ai-video-storyboard.md -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/brand-lock-extractor.md -->
# SOURCE FILE: `repo/notebooklm-corpus/brand-lock-extractor.md`

# SKILL: brand-lock-extractor

Documentacion completa del skill. Cada seccion es un archivo distinto.


---

## ARCHIVO: brand-lock-extractor/SKILL.md

---
name: brand-lock-extractor
description: Extract a production-ready brand-lock.md from a brand's existing assets. Point it at a website URL, a brand book PDF, screenshots, or a written description and it produces the nine-section brand-lock the rest of shotkit consumes, with a confidence and source noted for every value. Use when the user wants to onboard a brand, says "build a brand lock", "extract my brand", "make a brand pack from my site", or hands over brand assets. The cold-start killer that turns a blank brand-pack template into a filled, validate-ready file. Pairs with storyboard-architect downstream.
---

# Brand Lock Extractor

The blank `brand-packs/_template.md` is the single biggest point of friction in shotkit. Nobody wants to hand-author nine sections of brand parameters before they can produce a single storyboard. This skill removes that wall: hand it what you already have, get a filled brand-lock back.

The output is a `brand-lock.md` in the exact format `tools/validate_brand_lock.py` validates and every other skill consumes. Same file the pipeline reads, produced from your assets instead of from scratch.

This skill extracts. It does not invent. Every value is sampled from a real asset or flagged as an estimate the user must confirm. A confident-sounding wrong hex is worse than a flagged guess.

## When to use

Trigger when the user:

- Wants to onboard a brand into shotkit and has assets (a site, a brand book, screenshots)
- Says "extract my brand", "build a brand lock", "make a brand pack from my site/PDF"
- Hands over a URL, a PDF, image files, or a written brand description and asks for a brand-lock
- Has a brand-lock that is half-filled and wants the gaps extracted from assets

If the user has nothing but a vague idea (no assets, no description), they are not extracting, they are authoring. Point them at `brand-packs/_template.md` and help them fill it directly.

## Inputs

You can work from any one of these. More sources is a better extraction.

| Source | How you read it | Best for |
|---|---|---|
| Website URL | `WebFetch` homepage + about + one more page | Voice, positioning, palette, type |
| Brand book PDF | `Read` the PDF | Palette (exact hex), type, motion rules |
| Screenshots / image files | `Read` the images | Palette (sample pixels), mood, layout |
| Written description | Use directly | Identity, archetype, voice posture |

At minimum you need one source. If the user offers none, ask for the one they have: **"What can I work from, a website URL, a brand book PDF, screenshots, or a short description?"** One question.

## Workflow

### Step 1. Gather the source material

- **URL:** `WebFetch` the homepage, then try the about page (`/about`, `/about-us`, `/our-story`) and one more (`/services`, `/work`, recent blog). Skip pages that 404. The homepage is the floor.
- **PDF / images:** `Read` each file. Brand books carry exact hex and type; screenshots are for sampling color and reading mood.
- **Description:** take it as written.

Tell the user what you are pulling. Do not ask follow-ups yet, extract first, confirm gaps at the end.

### Step 2. Extract each section

Read `references/extraction-rubric.md`. It maps every brand-lock section to where the signal lives and how to read it. Work the nine sections in order:

1. **Identity** (brand, one-line description, archetype, voice posture)
2. **Palette** (sampled hex, by role)
3. **Typography** (display, body, optional mono, with weights)
4. **Mood adjectives** (3-5, specific, contrast clauses preferred)
5. **Never list** (what the brand avoids, inferred from consistency)
6. **Aspect ratios**
7. **Color grade direction** (one sentence)
8. **Motion language** (one paragraph)
9. **Voice rules** (copy-level constraints)

For every value, hold two things: the value, and where it came from (which asset, which quote, which sampled swatch). You will need the source for the confidence pass.

### Step 3. Assign confidence and flag estimates

Each value is one of:

- **extracted**, read directly from an asset (a hex in the brand book, a font in the CSS, a quote from the site). State it plainly.
- **inferred**, reasoned from evidence but not stated (archetype from positioning, never-list from consistency). Reasonable to ship, worth noting.
- **needs confirmation**, your best estimate where the assets were silent or ambiguous (a color sampled from a JPEG with compression, a font you could not identify). Fill it, then flag it.

### Step 4. Write the brand-lock

Use `templates/brand-lock.md.tpl`. Fill **every** required section, no placeholders left behind. Then append an `## Extraction notes` section that lists every `inferred` and `needs confirmation` value with its source and your reasoning. This section is the audit trail; it does not break validation (the validator checks the nine required sections are present, extra sections are fine).

Set the footer: `Last updated` to today, `Owner` to the user or "extracted", `Version: 1.0`.

### Step 5. Self-check, then hand off

Before you present it, confirm the file would pass validation:

- All nine required sections present: Identity, Palette, Typography, Mood adjectives, Never list, Aspect ratios, Color grade direction, Motion language, Voice rules.
- Identity contains all four fields: Brand, One-line description, Archetype, Voice posture.
- Palette has at least one real `#RRGGBB` hex (not a placeholder).

Then hand off:

> "Here is your brand-lock. I sampled the palette and type from your assets and flagged N values that need your eyes (see Extraction notes). Drop it in `brand-packs/`, confirm the flagged values, and run `python tools/validate_brand_lock.py path/to/file.md` to verify. Then: `'30-second explainer. Use brand-packs/your-brand.md as the brand lock.'`"

## Hard rules

### Rule 1. Never invent a hex value

Colors are sampled, never guessed. Read them from a brand book, from CSS, or by sampling pixels in a screenshot. If you genuinely cannot determine a color, fill your closest estimate and mark it `needs confirmation` in Extraction notes. "Navy" is not a palette entry. `#0F1F3A` is. A wrong hex stated confidently corrupts every downstream prompt.

### Rule 2. Never fabricate a typeface

Identify fonts from the brand book, the site's CSS/font files, or clear visual match. If you cannot identify one, say so and flag it, do not name a plausible-sounding font you did not verify.

### Rule 3. Source everything

Every extracted value traces to an asset. Every inferred value traces to reasoning. This is the same audit-trail discipline as the brand-lock snapshot, applied at extraction time.

### Rule 4. The never-list is the highest-value section

It is also the hardest to extract, because brands document what they do, not what they avoid. Infer it from consistency: if every image avoids stock-photo gloss, that is a never. If copy never uses exclamation points, that is a never. Read `references/extraction-rubric.md` for the method. Do not ship an empty never-list.

### Rule 5. Mood adjectives must be specific

"Professional, modern, clean" describes every brand and constrains nothing. Extract contrast clauses that do work: "operator not creator", "warm not precious", "confident without volume". If the assets only support generic adjectives, that is a `needs confirmation` flag, not a license to ship filler.

### Rule 6. No emojis, no hype

The output is a clinical specification. It models the standards the brand-lock enforces. No emojis anywhere. No marketing adjectives about the brand in your own voice, report what the assets show.

## Reference

- `references/extraction-rubric.md`, section-by-section extraction method and confidence definitions.

## Example

`examples/` contains a worked extraction: the source material provided (`input-brief.md`) and the `brand-lock.md` produced from it, including the Extraction notes audit trail. Use it to calibrate the level of specificity and the confidence flagging.


---

## ARCHIVO: brand-lock-extractor/brand-packs/README.md

# Brand Packs

A brand pack is a single Markdown file that locks in palette, typography, voice, and visual rules for a project. The skills in this pack consume it. Every storyboard, every prompt, every generated frame inherits from it.

## How to use

1. Copy `_template.md` to a new file (e.g. `acme.md`)
2. Fill in every field. No placeholders left behind.
3. Reference it from your storyboard requests:

   > "30-second founder explainer. Use `brand-packs/acme.md` as the brand lock."

4. The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.

## How to write a good one

The template is a checklist, not a creative-writing exercise. Three rules:

**Be specific.** "Modern, clean, professional" is not a brand. "Calm, considered, operator energy, confident without shouting" is.

**Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.

**Be hex-precise.** Every color is a hex value. Every font is named. The skills consume structured data; vagueness here cascades into bad prompts later.

## Examples

The pack ships with two reference brand packs:

- **`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.
- **`examples/saas-clean.md`**. B2B SaaS, restrained, professional. Light backgrounds, single accent. Inter type stack. A neutral counterpoint to the WhyStrohm flagship.

More example brand packs will land in v2.0.0. PRs welcome.

## Generating a brand pack from existing assets

Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

> "Extract a brand-lock from acme.com" or "build a brand pack from this brand book PDF."

For bulk or programmatic extraction across many URLs, [media-tsunami](https://github.com/whystrohm/media-tsunami) (WhyStrohm's open-source brand voice extractor) scrapes URLs and produces a `brand-lock.md` in the same format.

## Versioning

Every storyboard run snapshots the brand pack it was built against. If you update `acme.md` later, previous storyboards still reference the version they were built on. This is intentional, the audit trail tells you exactly what brand state any given piece of content was built against.

When you make a brand-pack revision that materially changes look or voice, bump the `Version:` field at the bottom and note the change. e.g.:

```
Version: 1.1 (2026-05-12: switched accent from #D94F3A coral to #C44233 deeper coral)
```

## Contributing examples

PRs welcome for new brand-pack examples that fill gaps in the current set. Open an issue with the `brand-pack-request` template before submitting.


---

## ARCHIVO: brand-lock-extractor/brand-packs/_template.md

# Brand Lock: {{BRAND_NAME}}

> Replace placeholders. Delete this blockquote when you're done.
> Every field below feeds into the storyboard pipeline. Be specific.

## Identity

**Brand:** {{BRAND_NAME}}
**One-line description:** What this brand actually does, who for.
**Archetype:** Operator / Creator / Sage / Rebel / Caregiver / Other
**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative

## Palette

Every hex value here is allowed. Anything outside this list is not.

| Role | Hex | Use |
|---|---|---|
| Background | `#______` | Primary canvas |
| Ink | `#______` | Primary text, dark elements |
| Accent | `#______` | Highlights, CTAs, brand pop |
| Muted | `#______` | Secondary text, captions |
| Rule | `#______` | Borders, dividers, subtle UI |

Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.

## Typography

**Display font:** `______`
**Body font:** `______`
**Mono font (optional):** `______`

Put the font name and weight in backticks immediately after the label, e.g.
`` **Display font:** `Inter Black 900`, headlines and hooks ``. The HTML preview and
the overlay-font check read that backticked value; anything before it is prose.

Two fonts max for production work. Three only if one is reserved for code/data.

## Mood adjectives

Pick 3–5. These flow into prompts as the brand's emotional posture.

- adjective_1
- adjective_2
- adjective_3

## Never list

What this brand never does, visually or tonally. Be specific.

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate
- never shout in copy
- never use clip-art icons
- (add more, the more specific, the better)

## Aspect ratios

Default: 16:9 / 9:16 / 1:1 / 4:5 / other

## Color grade direction

How footage and generated images should be graded. One sentence.

> e.g. "Warm filmic, muted teal shadows, slight grain. Reminiscent of Kodak Portra 400."

## Motion language

How motion behaves in this brand's content. One paragraph.

> e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

## Voice rules

Copy-level rules that apply to VO and on-screen text.

- e.g. no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no clichéd metaphors ("game-changing", "revolutionary", "next-level")
- no hype words

## Reference materials

Optional. Links to past work, mood boards, or style guides that further define the brand.

- Link to brand guide
- Link to past hero film
- Link to mood board

---

**Last updated:** YYYY-MM-DD
**Owner:** name / role
**Version:** 1.0


---

## ARCHIVO: brand-lock-extractor/brand-packs/examples/saas-clean.md

# Brand Lock: Acme SaaS (Example)

> Reference example for B2B SaaS brands. Restrained, professional, single-accent palette.

## Identity

**Brand:** Acme SaaS
**One-line description:** B2B platform that helps SaaS teams cut churn 40% in 90 days through customer health scoring and intervention workflows.
**Archetype:** Sage
**Voice posture:** Confident, data-driven, peer-to-peer (not vendor-to-buyer)

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#FFFFFF` | Pure white, primary canvas |
| Ink | `#0F1F3A` | Deep navy, primary text |
| Accent | `#3B82F6` | Bright blue. CTAs, data highlights |
| Muted | `#64748B` | Slate, secondary text, captions |
| Rule | `#E2E8F0` | Light gray, borders, dividers |
| Success | `#10B981` | Emerald, positive metrics, gains |
| Warning | `#F59E0B` | Amber, alerts, attention items |

## Typography

**Display font:** `Inter Bold 700`
**Body font:** `Inter Regular 400`
**Mono font:** `JetBrains Mono Regular`, for data, code, dashboards

## Mood adjectives

- credible
- precise
- helpful
- restrained
- expert

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never use illustrations of people (real photography or abstract data viz only)
- never use gradients (flat color only)
- never use rounded corners larger than 8px
- never use exclamation points
- never use vague claims ("the best", "industry-leading", "cutting-edge")
- never use AI/ML buzzwords without specifics
- never default to dark mode in primary marketing
- never use animated icons or lottie illustrations

## Aspect ratios

- 16:9, primary for product demos and hero films
- 9:16, short-form social
- 1:1. LinkedIn carousels

## Color grade direction

Clean, neutral, slight cool bias. White points pure white, blacks deep but not crushed. Skin tones natural. No filmic grain. Reminiscent of Apple keynote photography, clean, evenly lit, technically perfect.

## Motion language

Minimal motion. UI elements appear with subtle 200ms fade. Cuts on logic beats, not on time. Data visualizations animate with linear easing, no bounce, no overshoot. Camera moves limited to slow push on hero shots. No handheld, no whip pans, no transitions beyond hard cuts.

## Voice rules

- no em dashes
- no exclamation points
- no hype words
- prefer specific numbers ("40% reduction in 90 days" not "significant improvement")
- prefer "we" and "you" over "the company" and "the user"
- prefer present-tense
- never start a sentence with "Just" or "Simply"
- avoid corporate hedge language ("seek to", "look to", "aim to")

## Reference materials

- Vercel marketing, design language reference
- Linear marketing, voice and pacing reference
- Stripe Press, typography and density reference

---

**Last updated:** 2026-05-07
**Owner:** Example
**Version:** 1.0


---

## ARCHIVO: brand-lock-extractor/examples/brand-lock.md

# Brand Lock: Northwind Coffee Roasters

## Identity

**Brand:** Northwind Coffee Roasters
**One-line description:** Small-batch coffee, roasted and shipped the same morning, with full origin transparency, for people who want real coffee and no subscription to babysit.
**Archetype:** Maker, with a Rebel edge against pretension (frames the category's problem as cheap beans hidden behind burnt roasts and luxury pricing).
**Voice posture:** Plainspoken and confident. Short declaratives, dry, no decoration.

## Palette

Every hex value here is allowed. Anything outside this list is not.

| Role | Hex | Use |
|---|---|---|
| Background | `#F4EFE6` | Paper cream, primary canvas |
| Ink | `#2B2018` | Espresso brown, primary text and dark elements |
| Accent | `#C5562B` | Ember, highlights and CTAs |
| Muted | `#8A8076` | Stone, secondary text and captions |
| Rule | `#DCD3C4` | Borders and dividers |

## Typography

**Display font:** `Tiempos Headline Semibold`, serif
**Body font:** `Söhne Regular`, sans-serif, Medium for emphasis

## Mood adjectives

- plainspoken, not precious
- warm, not cozy-cute
- honest about origin
- unhurried

## Never list

- never use stock smiles or posed lifestyle photography
- never use latte art as decoration
- never use the word "artisanal"
- never use exclamation points
- never shoot glossy product-on-white; matte and natural-light only
- never lean on burnt, dark-roast cliche imagery

## Aspect ratios

Default: 4:5 and 9:16 for social, 16:9 for the web hero.

## Color grade direction

> Matte, low contrast, natural window light, warm but restrained. Reminiscent of Kinfolk editorial photography. Never glossy commercial product lighting.

## Motion language

> Minimal and unhurried. Static or slow push only. Cuts land on action, not on a timer. Type sets in place, it does not bounce or wobble. No fast cuts, no whip pans.

## Voice rules

- no exclamation points, anywhere
- never the word "artisanal" (or "curated", "elevated")
- short declarative sentences; cut adjectives before nouns that do not need them
- prefer specific origin claims (farm, region, roast date) over vague quality words
- no hype words ("best", "premium", "game-changing")

## Extraction notes

Audit trail for this extraction. Values not listed here were read directly from an asset (`extracted`): the four palette hex from the site CSS, both font names from the CSS, the never-list lines from the brand sheet, and the aspect ratios from the brand sheet.

**Inferred** (reasoned from evidence, reasonable to ship):
- Archetype "Maker / Rebel", from "we are roasters, not a lifestyle brand. The coffee does the talking" and the framing of competitors as burnt-cheap or overpriced.
- Mood adjectives, from the plainspoken homepage copy and the matte, natural-light photography described on the brand sheet.
- Color grade direction, inferred from the brand sheet's photography notes (matte, low-contrast, window light); no graded footage was provided.

**Needs confirmation** (best estimate, please verify):
- Rule color `#DCD3C4`, no divider/border color was given; estimated as a darker tint of the paper background. Confirm or replace.
- Font weights (Tiempos Headline Semibold, Söhne Regular/Medium), fonts are confirmed from CSS, weights are estimated from visual weight. Confirm against the brand book.
- Motion language, no motion assets were provided; this is a conservative default consistent with the Plainspoken/Confident posture. Confirm against any existing video.

---

**Last updated:** 2026-06-18
**Owner:** extracted
**Version:** 1.0


---

## ARCHIVO: brand-lock-extractor/examples/input-brief.md

# Example input: what the user handed over

This is the raw source material for the worked extraction. The user provided a URL and a one-page brand sheet. The `brand-lock.md` in this folder is what the skill produced from it.

## Source 1: website (fetched)

**Homepage hero:**
> Northwind Coffee Roasters
> Small-batch coffee, roasted the morning it ships.
> No subscriptions to forget about. No bitter shortcuts. Just coffee that tastes like someone cared.

**About page excerpt:**
> We started Northwind in a one-car garage in Duluth because the coffee we could buy locally was either burnt to hide cheap beans or priced like a luxury good. We roast in small batches, ship the same day, and tell you exactly where the beans came from and who grew them. We are roasters, not a lifestyle brand. The coffee does the talking.

**CSS (from the page source):**
```
--paper: #F4EFE6;
--espresso: #2B2018;
--ember: #C5562B;
--stone: #8A8076;
font-family: "Tiempos Headline", Georgia, serif;   /* headings */
font-family: "Söhne", -apple-system, sans-serif;    /* body */
```

## Source 2: one-page brand sheet (read)

- Logo: wordmark only, espresso brown on paper cream. No icon.
- Photography: matte, low-contrast, natural window light. Beans, hands, kraft bags. Never glossy product-on-white.
- "We don't do: stock smiles, latte art as decoration, exclamation points, or the word 'artisanal'."
- Formats noted: Instagram (4:5 and 9:16), website hero (16:9).


---

## ARCHIVO: brand-lock-extractor/references/extraction-rubric.md

# Extraction rubric

How to read each brand-lock section out of real assets. For every section: where the signal lives, how to read it, and how to assign confidence.

## Confidence levels

Apply one to every value.

- **extracted**, read directly from an asset. A hex in the brand book PDF. A `font-family` in the site CSS. A verbatim quote from the homepage. Ship it plainly.
- **inferred**, reasoned from evidence, not stated. Archetype from how the brand frames problems. Never-list from what the assets consistently avoid. Ship it, note the reasoning.
- **needs confirmation**, a best estimate where assets were silent, compressed, or contradictory. A color sampled from a low-quality JPEG. A font you could not positively identify. Fill it so the file is complete, then flag it in Extraction notes.

## Identity

**Brand:** the name. Extracted from the logo, the title tag, or the description.

**One-line description:** what the brand does and who for. This is the load-bearing sentence; a generator implicitly references it on every prompt. Pull it from the hero headline plus the about page. Prefer concrete over abstract: "Managed bookkeeping for solo law firms" beats "Financial services for professionals." If the site only offers a vague tagline, sharpen it from the services/about copy and flag it `needs confirmation`.

**Archetype:** one word, Operator, Sage, Caregiver, Rebel, Creator, Jester, Ruler, Everyman, etc. Almost always `inferred`. Read it from how the brand frames the customer's problem:
- frames problems as systems to engineer -> Operator
- frames problems as questions to investigate -> Sage
- frames problems as people to support -> Caregiver
- frames problems as a status quo to break -> Rebel

**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative. Read from sentence length, punctuation, and word choice in the body copy. Short declaratives -> Sharp/Confident. Long, soft, second-person -> Warm. Cite a representative sentence.

## Palette

A table of `#RRGGBB` by role: Background, Ink, Accent, Muted, Rule, plus any brand-specific roles. Up to 8; past that the brand stops being recognizable.

How to get real hex:
- **Brand book PDF:** read the swatches directly. Highest confidence.
- **Website:** the CSS holds exact values (`background`, `color`, CSS custom properties like `--accent`). Highest confidence after a brand book.
- **Screenshots:** sample the dominant background, the text color, and the one or two accent colors. Compression shifts color slightly, so flag screenshot-sampled values `needs confirmation` unless they are clearly flat brand colors.

**Never guess a hex.** If you cannot read or sample one, estimate, label it `needs confirmation`, and tell the user exactly which role to verify. (See SKILL.md Rule 1.)

## Typography

Display font, body font, optional mono, each with weight (`Inter Black 900`, not `Inter Bold`).

- **Website:** `font-family` declarations and loaded font files (`fonts.googleapis.com`, `@font-face`, `.woff2` names) name the fonts exactly. Weights come from `font-weight`.
- **Brand book:** named directly.
- **Screenshots:** identify by eye only if confident; otherwise flag `needs confirmation`. Do not invent a plausible name (Rule 2).

Two fonts max; three only if one is mono for code/data.

## Mood adjectives

3-5 adjectives, specific, contrast clauses preferred. Read tone from the body copy and the imagery together.

Reject generic fillers ("professional, modern, clean"), they describe everything and constrain nothing. Push to contrast clauses that do work: "operator not creator", "warm not precious", "plainspoken not corporate". If the assets only support generic adjectives, flag `needs confirmation`. Cite the copy or image that supports each adjective.

## Never list

The hardest and most valuable section. Brands document what they do; you infer what they avoid from consistency across the assets.

Method, look for what is conspicuously absent:
- Imagery: no stock-photo gloss? no people? no gradients? no clip-art icons? Each absence is a never.
- Copy: no exclamation points? no hype words ("revolutionary", "game-changing")? no emojis? no questions in headlines? Each pattern is a never.
- Color/layout: never full-bleed photography? never more than one accent? never centered body text?

Turn each observed constraint into a `never` line. Be specific: "never use stock-photo aesthetic" beats "keep it authentic". Aim for 5+. Never ship an empty list (Rule 4).

## Aspect ratios

The ratios the brand renders for. Default to `9:16, 16:9, 1:1, 4:5`. If the assets reveal a bias (a vertical-only social brand, a cinematic 21:9 site hero), reflect it and note the evidence.

## Color grade direction

One sentence on how footage and generated images should be graded, with a reference point where possible (Kodak Portra 400, Apple keynote photography, A24 film grade). Infer from the existing photography's warmth, contrast, and saturation. If there is no photography to read, base it on the palette and flag `needs confirmation`.

## Motion language

One paragraph: camera moves, cut style, text animation, pacing. Read from any existing video or motion on the site; if there is none, infer a conservative default consistent with the voice posture (a Quiet/Authoritative brand -> minimal, slow, deliberate) and flag `needs confirmation`. Keep it to one coherent motion language, do not blend "minimal and deliberate" with "energetic whip pans".

## Voice rules

Copy-level constraints for VO and on-screen text. Many overlap the never-list but are phrased as authoring rules: "no em dashes", "sentences under 14 words", "prefer specific numbers over vague claims", "no exclamation points in headlines". Extract from observed copy patterns. These become prompt constraints downstream, so make them enforceable, not aspirational.


---

## ARCHIVO: brand-lock-extractor/tools/README.md

# Tools

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

## Requirements

```bash
pip install pyyaml jsonschema
```

Standard library otherwise. No pandas, no numpy.

## Run everything

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

This is exactly what CI runs, so a green local run means a green PR.

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

## Repo checks

### `validate_skills.py`

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

```bash
python tools/validate_skills.py
```

### `validate_schemas.py`

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

```bash
python tools/validate_schemas.py
```

It validates schemas, not instances. For instances, see `validate_shots.py`.

### `validate_capabilities.py`

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

- every generator id has an adapter `.md` and every adapter `.md` has an entry
- no adapter advertises more words than its own `max_prompt_words` ceiling
- every adapter documents the `aspect_param` the matrix says to send
- no `notes` field cites a word count above its own ceiling
- warns when the matrix or an entry is past its 120-day freshness window

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

### `validate_brand_lock.py`

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

## Project checks

These run against a project's output directory, not the repo.

### `validate_shots.py`

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

### `validate_prompts.py`

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

### `validate_critique.py`

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

### `validate_provenance.py`

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

It catches, with a selftest for each:

- a frame regenerated after its critique (`image_sha256` no longer matches)
- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)
- a frame on disk with no critique for its round, never reviewed at all
- two critiques for the same shot in the same round, two operators colliding
- rounds that skip a number, or a critique whose `run_id` belongs to another run

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

## Rendering

### `shots-to-html.py`

Renders an output folder into a single `preview.html`.

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

### `copy-prompt.py`

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

## Internal modules

Not entry points. Imported by the tools above.

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.
- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

## Adding new tools

- Make it executable (`chmod +x`)
- Add a usage docstring at the top of the file
- Give it a `--selftest` that proves the check fires
- Document it in this README
- Wire it into `tools/check.sh`, which is what CI calls

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.


<!-- SOURCE_FILE_END: repo/notebooklm-corpus/brand-lock-extractor.md -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/image.md -->
# SOURCE FILE: `repo/notebooklm-corpus/image.md`

# SKILL: image

Documentacion completa del skill. Cada seccion es un archivo distinto.


---

## ARCHIVO: image/SKILL.md

---
name: image
license: CC-BY-4.0 (attribution required — Serge Shima, github.com/smixs/visual-skills)
description: >
  Image prompting skill for Nano Banana (NBP/NB2) and GPT Image 2. Writes ready-to-use
  prompts with model/quality/size recommendations. Use when: "нарисуй", "сгенерируй
  картинку", "image prompt", "промпт для картинки", blog covers, slides, posters,
  product shots, UI mockups, storyboards, character sheets, edit/colorize, style transfer,
  vision analysis, image-to-prompt, nb, NBP, NB2, gpt-image-2, multi-panel grids,
  ecommerce product photography, fashion editorial, food/beverage ads, cinematic portraits.
  Do NOT use for: video (use video skill), 3D models, audio, non-image tasks.
---

# Image Prompting — Nano Banana & GPT Image 2

This skill writes image prompts. It does not generate images. The output is: model name + quality / size / aspect ratio + the prompt itself.

The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone. The actual rules — what the models reward, what they punish, how to phrase a 5-slot template, when to add `quality: high`, when to use image grounding — live only in the reference files.

## Route first — is this actually an image-prompt task?

- **Motion, clips, montage** (Seedance, Kling, Veo, any image-to-video): use the sibling `video` skill. This skill's storyboard and keyframe outputs feed it.
- **No idea or script yet** (user wants a concept or an ad scenario, not a picture): if the `creative-director` skill is installed, start there — it develops ideas and scripts for commercials and beyond ([github.com/smixs/creative-director-skill](https://github.com/smixs/creative-director-skill)).
- **A concrete image is needed** — this skill. Continue below.

---

# Mandatory reading order — DO NOT WRITE A PROMPT WITHOUT THIS

Past attempts to write prompts directly from this skill body produced lazy, generic results. Each model has its own physics; common rules collapse into mush when applied without model-specific syntax. Read in this order before producing any prompt:

### Step 1 — always read first → [models.md](references/models.md)

Decide: Nano Banana (NB2 or NBP) or GPT Image 2. The choice changes the prompt syntax fundamentally — natural-language paragraphs vs. labeled 5-slot template, quality settings, which features exist (image grounding only on NB, EXACT TEXT discipline only on GPT Image, etc.).

If the user named a model — confirm and proceed. If not — pick using the table in `models.md`, then state your choice in the output header.

### Step 2 — read **one** model file (the one you picked)

- **Nano Banana** → [nano-banana.md](references/nano-banana.md)
  Image grounding for real locations. Extreme aspect ratios (1:8, 8:1, 4:1). Thinking mode. JSON for 5+ elements. Up to 14 reference images. Why you must NOT write `50mm / f-stop / ISO` numbers.

- **GPT Image 2** → [gpt-image.md](references/gpt-image.md)
  5-slot template (Scene / Subject / Important Details / Use Case / Constraints). Anti-slop banned-words list. `quality: low / medium / high` as a deliberate fidelity lever. Size constraints (multiples of 16, max 3:1, up to 2560×1440). Two-column edit logic (Change / Preserve / Constraints). Up to 16 reference images with explicit roles.

The model file is non-negotiable. Skipping it is the single biggest cause of weak prompts.

### Step 3 — always read after the model file → [golden-rules.md](references/golden-rules.md)

Universal rules that apply to both models: start with a verb, positive framing, hex colors, quote text, edit don't re-roll, one change per iteration, reference images.

### Step 4 — task-shaped reading (load only what matches the request)

Pick zero or more, depending on what the user asked for:

- Text in image, infographic, diagram, multilingual rendering → [text-rendering.md](references/text-rendering.md)
- Edit existing image (object removal, lighting swap, colorization, restoration, localization) → [editing.md](references/editing.md)
- Character continuity across multiple images / panels → [characters.md](references/characters.md)
- Presentation slides → [slides.md](references/slides.md)
- Sequential narrative (storyboard, comic, panel sequence) → [storyboards.md](references/storyboards.md)
- Sketch → final, wireframes, structural input → [structural.md](references/structural.md)
- 2D → 3D, floor plans, isometric → [dimensional.md](references/dimensional.md)
- **Vision analysis / image-to-prompt / style transfer from a reference image** → [vision-decomposer.md](references/vision-decomposer.md). Load this whenever the user attaches an image and asks to recreate, match, decompose, or transfer its style.
- **Multi-panel compositions** (grids, collages, storyboard sheets in ONE image) → [multi-panel.md](references/multi-panel.md). 9-cell TVC grids, 2x2 portrait grids, 3-panel campaign collages, 4x3 borderless grids, 6-frame cinematic sequences, before/after splits, 12-panel storyboard posters.
- **Industry pattern libraries** — proven prompt templates by vertical. Load the matching file:
  - E-commerce product shots → [patterns/ecommerce.md](references/patterns/ecommerce.md)
  - Fashion editorial campaigns → [patterns/fashion-editorial.md](references/patterns/fashion-editorial.md)
  - Food & beverage advertising → [patterns/food-beverage.md](references/patterns/food-beverage.md)
  - Cinematic portraits → [patterns/portrait-cinema.md](references/patterns/portrait-cinema.md)
  - Posters & illustration → [patterns/poster-illustration.md](references/patterns/poster-illustration.md)
  - Character design (turnarounds, expression sheets, outfit grids) → [patterns/character-design.md](references/patterns/character-design.md)
  - UI mockups & social media formats → [patterns/ui-social.md](references/patterns/ui-social.md)

### Step 5 — read for production language → [creative-direction.md](references/creative-direction.md)

Studio-quality vocabulary for lighting design, camera and hardware, color grading and film stock, materiality and texture. Read when you need precise terms beyond what `golden-rules.md` covers.

### Step 6 — read if structuring a complex prompt → [prompt-framework.md](references/prompt-framework.md)

Universal element checklist (subject, context, action, environment, camera, lighting, mood, materials, palette, format), detail modes (concise / standard / verbose / cinematic verbose), parameterized templates, output structure with parameters and exclusions.

---

# Output format

When you return the prompt, structure it like this:

```
Model: <nano-banana-2 | nano-banana-pro | gpt-image-2>
Quality: <low | medium | high>          (only for gpt-image-2)
Size / Ratio: <e.g. 1536×1024 or 16:9>

Prompt:
<the prompt text, ready to copy>

Notes:
- <anything you inferred or assumed because the user did not specify>
```

For edits, also include an explicit preserve-list (mandatory for gpt-image-2, recommended for nano-banana):

```
Change: <one concrete thing>
Preserve: <face, pose, lighting, framing, geometry, ...>
Constraints: <no extra objects, no drift, ...>
```

---

# Final response style

Prefer: ready-to-copy prompts, hex colors, concrete materials, named compositions, model-specific syntax (5-slot for GPT Image, natural prose for Nano Banana).

Avoid: tag soup ("cool, modern, 4k"), vague praise ("stunning, epic, masterpiece" — actively hurts GPT Image 2), negative framing ("no people, no cars" — invert to positive), external comparisons ("like Apple ad" — describe the visual properties instead), numerical lens parameters in Nano Banana prompts (it ignores them).

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/characters.md

# Character Consistency

Up to 14 reference images (6 high-fidelity). Identity locking across scenes.

## Identity Locking

```
Using person from [IMAGE REFERENCE]:
Keep facial features exactly the same.
Change: [EXPRESSION / POSE / CLOTHING / SETTING]
Maintain: identity, recognizable features
```

Key phrase: "Keep facial features exactly the same as Image 1"

## Viral Thumbnails

```
Design viral thumbnail using person from Image 1.

Face: Keep features same, change expression to [excited/surprised/shocked]
Action: Pose on [left/right], pointing toward [OBJECT]
Subject: [OBJECT] on opposite side
Graphics: Bold [COLOR] arrow connecting person to object
Text: "[HEADLINE]" in massive pop-style, white outline, drop shadow
Background: Blurred [SETTING]

High saturation and contrast.
```

## Multi-Character Consistency

```
Create [NUMBER]-part story with these [N] characters.

Identity: Keep attire and features consistent throughout.
Variation: Different angles, expressions, distances per image.
Rule: Only one of each character per image.

Story arc: [DESCRIPTION with emotional highs/lows]
```

## Brand Asset Generation

```
Using this [PRODUCT] as reference:
Create [NUMBER] [TYPE] shots.

Maintain: Brand consistency, quality level
Vary: Angles, lighting, context
Style: [editorial / lifestyle / product]

Generate one at a time.
```

## Expression Control

While maintaining identity:
- "Change expression to excited and surprised"
- "Make them look thoughtful, gazing left"
- "Add confident smile, direct eye contact"

## Pose/Action Control

- "Pose pointing finger toward [DIRECTION]"
- "Standing with arms crossed"
- "Mid-stride, dynamic motion"
- "Seated, leaning forward"

## Attire Changes

- "Same person, but wearing [NEW OUTFIT]"
- "Keep face, change to formal business attire"
- "Maintain identity, add [ACCESSORY]"

## Environment Swaps

- "Same person in [NEW SETTING]"
- "Transport to [LOCATION], keep identity"
- "Change background to [SCENE], maintain lighting on face"

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/creative-direction.md

# Creative Direction

Studio-quality controls for lighting, camera, color, and materiality.

## Lighting Design

Tell the model exactly how the scene is illuminated.

**Studio setups:**
- "Three-point softbox setup" — even product/portrait lighting
- "Single key light from upper left" — dramatic shadow
- "Ring light, frontal" — beauty/fashion, flat lighting

**Dramatic effects:**
- "Chiaroscuro lighting with harsh, high contrast"
- "Golden hour backlighting creating long shadows"
- "Rim lighting, subject silhouetted against bright background"
- "Volumetric god rays through window"
- "Neon underglow, cyberpunk street"

**Natural:**
- "Soft overcast daylight, even diffusion"
- "Dappled sunlight through trees"
- "Blue hour, cold ambient light"

## Camera & Hardware

Specify camera type to change the visual DNA of the image.

**Hardware names that work:**
- GoPro — immersive, wide-angle distortion, action feel
- Fujifilm — authentic color science, warm tones
- Disposable camera — raw, nostalgic flash aesthetic, grain
- Hasselblad — medium format, shallow DOF, fashion/portrait
- iPhone — casual, smartphone aesthetic
- Polaroid — instant film, white border, faded colors

**Angles:**
- "Low angle" — power, drama
- "Aerial view" / "bird's eye" — scale, pattern
- "Eye-level" — neutral, relatable
- "Dutch angle" — tension, unease
- "Worm's eye view" — extreme drama

**Shot types:**
- Close-up, medium shot, wide shot, extreme close-up
- "Waist-up portrait", "full body", "over-the-shoulder"

**Focus:**
- "Shallow depth of field" — blurred background
- "Deep focus" — everything sharp
- "Rack focus" — shift attention
- "Tilt-shift" — miniature effect

> Note: Named lens parameters (50mm, f/2.8) are less reliable than
> descriptive terms. Prefer "shallow depth of field" over "f/1.8".

## Color Grading & Film Stock

Set emotional tone through color and texture.

**Film stocks:**
- "Shot on 1980s color film, slightly grainy" — nostalgic
- "Kodak Portra 400" — warm skin tones, pastel highlights
- "Fuji Velvia" — hyper-saturated, vivid
- "Ilford HP5" — classic B&W grain
- "Cinestill 800T" — tungsten, halation around lights

**Digital grades:**
- "Cinematic color grading with muted teal tones"
- "High contrast, desaturated" — gritty, editorial
- "Warm analog tones, lifted blacks" — vintage
- "Cool blue shadows, warm highlights" — modern cinema
- "Cross-processed, shifted greens" — experimental

## Materiality & Texture

Define physical makeup of subjects. Don't just say the thing — describe what it's MADE of.

| Vague | Specific |
|-------|----------|
| "a suit" | "navy blue tweed suit, visible weave" |
| "armor" | "ornate elven plate armor, etched with silver leaf patterns" |
| "a mug" | "minimalist ceramic coffee mug, matte glaze, slight imperfections" |
| "skin" | "weathered, sun-damaged skin, deep expression lines" |
| "metal" | "brushed steel with matte finish, fingerprint smudges" |

**Surface properties:**
- Matte / glossy / satin
- Rough / smooth / textured
- Translucent / opaque / refractive
- Worn / pristine / aged / patinated

## Creative Prompt Examples

**Cartoon Portrait (3D + Real):**
```
Based on the uploaded reference image, create a photorealistic scene
featuring the real human standing next to a giant 3D animation-style
version of themselves. Both must have identical facial structures,
clothing, and poses. Clean gray-blue studio background, cinematic lighting.
```

**Animation → Photorealistic:**
```
Convert this uploaded animated still into an ultra-realistic, cinematic
scene. Transform the animated characters into real humans while preserving
their original identities, facial structures, outfits, and expressions.
```

**Historical Maps (Google Street View style):**
```
Generate a hyper-realistic image of [HISTORICAL EVENT], perfectly
replicating a Google Maps Street View capture. Include wide-angle barrel
distortion, semi-transparent Maps UI overlay (compass, chevron arrows),
and '© Google [YEAR]' watermark. Automatically blur faces for privacy.
```

**Kindergarten Filter:**
```
A child's crayon drawing on white lined notebook paper of [SUBJECT].
Use chunky wax-crayon strokes, wobbly outlines, bold colors that overflow
the lines. Visible pressure marks, waxy smudges, uneven scribble shading.
Joyful, naive art style.
```

**Fashion Editorial:**
```
[Subject description]. [Action/pose]. [Setting].
Medium-full shot, center-framed.
Fashion magazine style editorial, shot on medium-format analog film,
pronounced grain, high saturation, cinematic lighting effect.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/dimensional.md

# Dimensional Translation

2D↔3D conversions. Floor plans to renders, memes to 3D.

## 2D Floor Plan → 3D

```
Based on this 2D floor plan, generate interior visualization.

Layout: Design board format
Main image: Wide-angle [ROOM] perspective (top 60%)
Below: 3 smaller renders - [ROOM A], [ROOM B], [ROOM C]

Style: [Modern minimalist / Scandinavian / Industrial]
Materials: [flooring], [walls], [textiles]
Lighting: Soft natural light, large windows
Quality: Photorealistic rendering
```

## Sketch → 3D Concept

```
Convert this sketch into [STYLE] visualization.
Perspective: [CAMERA ANGLE]
Lighting: [SETUP]
Quality: [photorealistic / stylized / rendered]
```

## 3D → 2D Technical

```
Flatten this 3D scene into [STYLE].
Views: [plan / elevation / section]
Labels: [ANNOTATIONS]
Line work: technical, precise
```

## Meme Conversion

```
Turn "[MEME NAME]" meme into [NEW STYLE].
Keep composition identical.
Character: [plush toy / realistic / cartoon]
Environment: [realistic flames / stylized / etc]
```

Example:
- "Turn 'This is Fine' dog into photorealistic 3D render"
- "Make the dog look like plush toy, fire realistic"

## Architectural Visualization

**Exterior:**
```
Generate exterior visualization from this elevation.
Time: [dawn / midday / dusk / night]
Weather: [clear / overcast / dramatic clouds]
Context: [landscaping / street / aerial view]
```

**Interior:**
```
Generate interior from this plan.
View: [living area / kitchen / bedroom]
Style: [AESTHETIC]
Lighting: [natural / artificial / mixed]
Props: [furniture / decor / people]
```

## Product 2D → 3D

```
Convert this flat design into 3D product mockup.
Material: [plastic / metal / fabric / glass]
Lighting: [studio / environmental]
Angle: [front / 3-quarter / top-down]
```

## Quality Levels

- "Sketch quality" - rough, conceptual
- "Presentation quality" - clean, professional
- "Photorealistic" - indistinguishable from photo
- "Stylized render" - artistic interpretation

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/editing.md

# Image Editing

Универсальные паттерны. Логика edit'а различается по моделям:

- **Nano Banana:** conversational, без масок. «Keep X same, change Y». Хорошо понимает физику и материалы.
- **GPT Image 2:** двухколоночная логика **Change / Preserve / Constraints**. Preserve list повторять каждую итерацию, иначе drift. Опционально `mask_image_url` для точечных edit'ов. Лучшая identity preservation. См. [gpt-image.md](gpt-image.md#editing--двухколоночная-логика).

Общее правило: **один edit за итерацию**, не пытайся менять всё разом.

## Object Removal
```
Remove [OBJECT] from this image.
Fill with [LOGICAL REPLACEMENT] matching surroundings.
Keep [PRESERVED ELEMENTS] exactly the same.
```

Examples:
- "Remove tourists, fill with cobblestones"
- "Remove car, extend street naturally"

## Object Addition
```
Add [OBJECT] to this image.
Position: [LOCATION]
Style: matching existing lighting
Scale: [RELATIVE SIZE]
```

## Lighting Control
```
Change lighting to [NEW LIGHTING].
Keep subject and composition same.
```

Vocabulary:
- Golden hour / sunset / warm backlight
- Overcast / soft / diffused
- Night / dramatic / single source
- Rim lighting / silhouette

## Seasonal/Weather
```
Turn scene into [SEASON/WEATHER].
Keep architecture exactly same.
Adjust: [snow/leaves/reflections/sky]
```

## Colorization

**Photo:**
```
Colorize this B&W photograph.
Era-appropriate colors for [DECADE].
Skin tones: natural, realistic
```

**Manga:**
```
Colorize this manga panel.
Style: [vibrant anime / muted realistic]
Effects: [glowing/neon] for energy elements
Maintain: line art integrity
```

## Restoration
```
Restore this damaged photograph.
Fix: [tears/scratches/fading/stains]
Enhance: sharpness, contrast
Preserve: original character and grain
```

## Localization
```
Translate all [SOURCE] text to [TARGET].
Keep everything else same.
Maintain: font style, sizing, position
```

Cultural adaptation:
```
Localize this [ORIGINAL] ad to [TARGET MARKET].
Background: [NEW LOCATION]
Translate: text to [LANGUAGE]
Keep: brand elements, core composition
```

## Physics-Aware

NBP understands materials:
```
Fill this glass with [LIQUID].
Add: refraction, meniscus, condensation
Match: existing lighting
```

```
Add [MATERIAL] texture to [SURFACE].
Properties: [matte/glossy], [rough/smooth]
```

## Conversational Refinement

After initial edit:
- "Make it warmer"
- "Increase contrast"
- "Soften the edges"
- "Add more detail to shadows"

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/golden-rules.md

# Golden Rules

Универсальные принципы. Работают для **обеих** семей моделей (Nano Banana и GPT Image 2).
Для модельной специфики см. [nano-banana.md](nano-banana.md), [gpt-image.md](gpt-image.md).

## 1. Start with a Verb

Tell the model the primary operation: "Create", "Generate", "Design", "Transform", "Convert", "Edit". This sets the intent before details.

## 2. Positive Framing

Describe what you WANT, not what you don't want. The model understands presence better than absence.

- ✅ "empty street" → ❌ "street with no cars"
- ✅ "clean background" → ❌ "no clutter"  
- ✅ "solo portrait" → ❌ "no other people"

## 3. Edit, Don't Re-roll

Image 80% correct? Request specific change:
- "Change lighting to sunset"
- "Make text neon blue"
- "Move chart to right third"

## 4. Natural Language

❌ Bad: "Cool car, neon, city, night, 8k"
✅ Good: "A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. Neon signs reflect off wet pavement and metallic chassis."

## 5. Be Specific

| Element | Vague | Specific |
|---------|-------|----------|
| Subject | "a woman" | "sophisticated elderly woman in vintage Chanel-style suit" |
| Material | "shiny" | "brushed steel with matte finish" |
| Color | "dark green" | "#0d3d2d deep emerald" |
| Position | "on the right" | "right third, bleeding off edge" |

## 6. Provide Context

Context helps model make logical decisions:
- "for Brazilian gourmet cookbook" → infers professional plating, shallow DOF
- "for executive strategy presentation" → infers corporate aesthetic
- "for children's educational app" → infers friendly, colorful style

## 7. Quote Text Exactly

Any text for rendering goes in quotes:
- "[HEADLINE TEXT]"
- Labels: "[Revenue Growth]", "[Net Income]"
- Specify weight: bold, thin, extra bold
- Specify position: "upper third", "centered"

## Prompt Template

```
Create a [TYPE] for [CONTEXT].

Background: [Description with hex colors]. [Atmospheric effects].

[HERO ELEMENT]:
[Detailed description - position, lighting, angle]

Typography:
Line 1: "[TEXT]" in [weight], [color], [size], [position]
Line 2: "[TEXT]" in [weight], [color], [size], [position]

[ADDITIONAL ELEMENTS]

Mood: [Emotional descriptor]
Format: [ASPECT RATIO]
```

> **Thinking Mode** (NB only), **`quality: low/medium/high`** (GPT Image 2 only) — см. соответствующие references.

## Cost Optimization (Batch Work)

- **Nano Banana:** прогон вариантов на `0.5K` Flash → отбор → переген победителя на `2K`/`4K`.
- **GPT Image 2:** прогон на `quality: low` → отбор → переген на `medium` или `high`.

В обоих случаях: дешёвая разведка → дорогой финал.

## Conversational Refinement

After generation:
- "Change the headline color to #3b82f6"
- "Add subtle drop shadow to text"
- "Increase contrast, make it more dramatic"
- "Soften the background, add blur"

## Reference Images

Multi-image вход: **NB до 14**, **GPT Image 2 до 16**. Индексируй с ролью каждой картинки.

Используй для:

**Вписать в существующий дизайн:**
```
[Attach design/layout image]
Create content following this exact layout and style.
Replace [ELEMENT] with [NEW CONTENT].
Keep colors, typography, composition.
```

**Лицо/персонаж как референс:**
```
[Attach portrait]
Use this person's face. Keep features exactly the same.
Change: [expression/pose/setting]
```

**Продукт/объект как референс:**
```
[Attach product photo]
Place this product in [NEW CONTEXT].
Match lighting and perspective.
```

**Стиль как референс:**
```
[Attach style reference]
Create [NEW CONTENT] in this exact visual style.
Match colors, textures, mood.
```

**Несколько референсов сразу:**
```
[Attach Image 1 - face]
[Attach Image 2 - outfit]
[Attach Image 3 - background]
Combine: face from Image 1, outfit style from Image 2, setting from Image 3.
```

## World Knowledge Anchors

GPT Image 2 обладает глубокими знаниями о культуре, эпохах и визуальных стилях. Вместо описания каждой детали — дай модели культурный/временной/жанровый якорь, и она сама заполнит аутентичные детали.

### Три типа якорей

**Era anchors** — временной и географический маркер, который вызывает целый визуальный мир:
- "Bethel, NY, August 1969" → Woodstock aesthetic без необходимости описывать тай-дай, грязь, сцены
- "Berlin, November 1989" → падение стены, толпы, граффити, эйфория
- "Tokyo, 1982" → неоновый Shinjuku, аналоговая электроника, ранний cyberpunk

**Cultural anchors** — перенос визуального языка одного культурного объекта на другой контекст:
- "{game_title} in {real_city}" → автоматически применяет визуальный стиль игры к реальной локации (GTA style, Persona style, и т.д.)
- "Soviet constructivism poster about {modern_topic}" → стиль Родченко/Эль Лисицкого на современную тему
- "Ukiyo-e print of {modern_scene}" → японская гравюра с современным содержанием

**Genre anchors** — режиссёр/фотограф/движение как линза:
- "Peter Lindbergh influence" → сильный Ч/Б, минимальная ретушь, raw editorial
- "Wes Anderson palette" → симметричный кадр, пастельная палитра, центрированная композиция
- "Studio Ghibli mood" → мягкое акварельное небо, зелёная листва, тёплый ностальгический свет
- "Roger Deakins lighting" → натуральный свет, глубокие тени, кинематографичный объём

### Правила использования

1. **Используй как HIGH-LEVEL steering** — якорь задаёт настроение и эстетику, а не заменяет весь промпт
2. **Комбинируй с конкретными визуальными деталями** — якорь устанавливает мир, детали устанавливают специфику
3. **Не стакай несколько genre anchors** — выбери один. "Peter Lindbergh + Wes Anderson" = каша
4. **Era/cultural anchors работают лучше с GPT Image 2** (world knowledge). С Nano Banana результат менее предсказуем — NB больше опирается на явные описания

### Примеры

**Era anchor + конкретные детали:**
```
Create an editorial portrait set in Havana, 1957.

Subject: jazz musician leaning against pastel-colored colonial building,
holding trumpet loosely at his side. Linen suit, open collar.
Lighting: harsh Caribbean afternoon sun, deep shadows under awning.
Format: 3:4
```
> "Havana, 1957" вызывает: старые американские машины на заднем плане, облупившаяся штукатурка, кованые балконы, тропическая атмосфера — без необходимости это описывать.

**Cultural anchor + новый контекст:**
```
Create a scene of a quiet Kyoto temple garden, rendered in the visual style
of Studio Ghibli. Morning mist over moss-covered stones, a single monk
sweeping fallen maple leaves. Soft watercolor textures, warm nostalgic palette.
Format: 16:9
```
> "Studio Ghibli" задаёт акварельность, теплоту, ностальгию. Детали (мох, клён, монах) задают конкретную сцену.

**Genre anchor + специфика:**
```
Create a fashion editorial portrait with Peter Lindbergh influence.

Subject: model in oversized men's blazer, no makeup, wind-tousled hair.
Setting: empty winter beach, overcast sky.
Mood: raw, unpolished beauty
Format: 2:3
```
> "Peter Lindbergh influence" даёт: мощный Ч/Б (или desaturated), отсутствие ретуши, raw emotional quality. Детали (пляж, блейзер, ветер) конкретизируют кадр.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/gpt-image.md

# GPT Image 2 — Specific Rules

Production default OpenAI: `gpt-image-2`. Migration-only: `gpt-image-1.5`, `gpt-image-1`. Бюджетный: `gpt-image-1-mini`.

## Структура промпта — 5 slots

GPT Image 2 сильнее всего реагирует на разделение по секциям. Пиши лейблами, не сплошным текстом.

```
Scene: location, time of day, background, environment
Subject: primary focus — who or what is central
Important Details: materials, textures, lighting, camera angle, mood, composition
Use Case: editorial, product mockup, UI, poster, infographic
Constraints: what must NOT change/appear (no watermarks, preserve face, no extra text)
```

> «The fifth slot is where most mediocre prompts fail silently.» Без явных constraints модель дрейфует.

### Минимальный пример

```
Scene: small Lisbon florist storefront at blue hour, wet cobblestones
Subject: woman in navy apron locking the front door, half-turned to camera
Important Details: warm interior glow spilling onto pavement, 50mm feel,
  soft contact shadows, brushed brass door handle, "Florista" hand-painted sign
Use Case: editorial photography
Constraints: no extra signage, no people in background, no text other than the sign
```

## Anti-Slop Rules

GPT Image 2 особенно чувствителен к качеству формулировок. Vague praise = деградация результата.

| ❌ Не пиши | ✅ Пиши |
|-----------|---------|
| stunning, incredible, epic, gorgeous, masterpiece | overcast daylight, brushed aluminum, chipped paint, 50mm feel |
| «minimalist brutalist luxury photoreal» (стиль-теги) | «cream background, heavy black sans-serif, asymmetrical type block, one hero object, generous negative space» |
| «как в Apple-рекламе» | конкретные визуальные факты |
| мудовый язык, в котором тонут функциональные требования | прямое заявление: «image must contain a transit kiosk» |

## Quality Settings — рычаг fidelity / latency

| Setting | Когда |
|---------|-------|
| `quality: low` | High-volume, превью, exploratory, latency-sensitive, draft |
| `quality: medium` | **Default starting point** |
| `quality: high` | Маленький/плотный текст, infographics, портреты, identity-sensitive edits, brand assets |

Стартуй с `low`, апгрейди по необходимости. Часто `low` уже достаточно.

## Размеры (gpt-image-2)

- Max edge: <3840px
- Обе стороны: кратны 16
- Aspect ratio: max 3:1 (long:short)
- Total pixels: 655 360 – 8 294 400
- Reliable upper bound: 2560×1440

**Ходовые:**
- Portrait 1024×1536
- Landscape 1536×1024
- Square 1024×1024
- 2K 2560×1440

> Экстрим вроде 1:8 / 8:1 GPT Image 2 НЕ умеет — иди в Nano Banana.

## Text in Image

- Литеральный текст в `"..."` или ALL CAPS.
- Шрифт, размер, цвет, позиция — явно.
- Сложные слова и бренды: спеллинг по буквам.
- Защита от мусора: «**no extra words, no duplicate text, no watermarks**».
- Для нечитаемого мелкого текста: «**100 percent readable and physically believable**».
- Маленький/плотный/multi-font → `quality: high` обязательно.

## Editing — двухколоночная логика

Endpoint: `openai/gpt-image-2/edit` (на fal.ai) или соответствующий через OpenAI API.

```
Change: [single concrete change]
Preserve: face, identity, pose, lighting, framing, background, geometry, text, layout
Constraints: no extra objects, no redesign, no drift
```

**Правила edit:**
- **Один edit за итерацию.** Не пытайся менять всё разом.
- **Preserve list повторять каждую итерацию.** Иначе дрейф.
- **Surgical edits:** явно перечисли что НЕ трогать (saturation, contrast, layout, arrows, labels, camera angle).
- Опционально: `mask_image_url` для точечных edits.

### Edit-паттерны

**Virtual try-on:** «Change garments only. Preserve exact face, body shape, pose, hair, expression, background, camera angle. Match lighting/shadows so outfit looks naturally worn.»

**Object removal:** «Remove [X]. Do not change anything else. Use `input_fidelity: high` to maintain surrounding context» (только gpt-image-1.5/1, в gpt-image-2 high-fidelity по умолчанию).

**Lighting/weather swap:** «Change ONLY environmental conditions: lighting direction/quality, shadows, atmosphere, precipitation. Preserve identity, geometry, camera angle, object placement.»

**Interior swap:** «Swap [furniture]. Preserve camera angle, lighting, shadows, surrounding context. Photorealistic contact shadows.»

## Multi-Image — до 16 рефов

Индексируй с **ролью**, не только номером:
```
Image 1: base scene
Image 2: jacket reference (apply only the jacket fabric/cut to subject in Image 1)
Image 3: lighting reference (apply golden-hour quality from Image 3)
```

## Style Transfer

Не пиши абстрактно («minimalist», «editorial»). Назови конкретные визуальные свойства референса: палитра, edge treatment, силуэт, обработка теней, plane логика.

## World Knowledge

GPT Image 2 умеет домысливать контекст: «Bethel, NY, August 1969» → выведет Woodstock-эстетику. Используй: дай исторический/культурный анкер, не расписывай каждую деталь.

## Iteration Strategy

- Стартуй с **чистого** базового промпта.
- Один change за раунд. «Make lighting warmer», «remove extra tree», «restore original background».
- При drift — перечисли invariants заново.
- Для длинных промптов — labeled sections, не одна простыня.

## Use-Case Templates

### Photoreal Editorial
```
Scene: [location, time, weather]
Subject: [who, action, framing]
Important Details: [lens feel, light source, surface wear, imperfections, real texture]
Use Case: editorial photograph, looks like a real photo
Constraints: no glamorization, no heavy retouching, no studio gloss
```

### Product Mockup (Clean Background)
```
Scene: plain white opaque background
Subject: [product] centered
Important Details: crisp silhouette, no halos/fringing, light contact shadow,
  preserve label legibility exactly, preserve geometry
Use Case: product mockup
Constraints: no restyling, only background removal + light polish
```

### UI Mockup
```
Scene: [device frame, e.g. iPhone 15 Pro]
Subject: [screen/app name] — describe AS IF IT EXISTS, not concept art
Important Details: layout, hierarchy, real interface elements, exact copy in quotes,
  typography behavior, spacing, state
Use Case: shipped product screenshot
Constraints: no sketch language, no placeholder text, no Lorem Ipsum
Quality: high (for small UI text)
```

### Marketing Creative with Text
```
Scene: [environment]
Subject: [hero element]
Important Details: [composition, palette, mood]
Use Case: ad creative for [audience]
Text: "EXACT HEADLINE" in [font style], [color], [position]
      "exact subhead" in [font style], [color], [position]
Constraints: no extra text, no duplicate text, no watermarks, no unrelated logos
Quality: high
```

### Infographic / Diagram
```
Title: "[TITLE]"
Content flow: [step 1] → [step 2] → [step 3]
Visual format: [layout type — flowchart, pyramid, isometric, etc.]
Use Case: educational infographic for [audience]
Constraints: readable labels at all sizes, clear hierarchy, no clutter,
  no decorative noise, ample whitespace
Quality: high
Size: 1536×1024
```

## Migration from Older GPT-Image

- Промпты в основном переносятся как есть.
- После переноса — посмотри качество, latency, retry-rate; ретюнь.
- `gpt-image-1-mini` — только если главное снизить цену batch'а на низкорисковых задачах.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/models.md

# Model Selection — Nano Banana vs GPT Image 2

Skill пишет промпты под две семьи моделей. Они мыслят по-разному — выбор модели меняет структуру промпта.

## TL;DR

| Задача | Модель |
|--------|--------|
| Реальное место/объект (с грунтингом) | **Nano Banana** (NB2/NBP) |
| Сложная сцена с физикой/композицией | **Nano Banana Pro** |
| Длинные горизонтальные/вертикальные форматы (1:8, 8:1, 4:1) | **Nano Banana** (только NB поддерживает экстрим) |
| Дешёвая массовая генерация | **Nano Banana 2 Lite** или **gpt-image-1-mini** |
| Фотореализм с тонкой типографикой/UI | **GPT Image 2** |
| Точное editing с preservation (try-on, swap, weather) | **GPT Image 2** (в editing у него лучшая identity-preservation) |
| Маленький плотный текст в кадре | **GPT Image 2** (`quality: high`) |
| Брендовая полиграфия / постеры с EXACT TEXT | **GPT Image 2** |
| Сториборды, комиксы (последовательность) | **Nano Banana** (extreme ratios + thinking) |
| Storyboard с фокусом на типографике | **GPT Image 2** |
| Style transfer без упоминаемых референс-картинок | **GPT Image 2** (concrete visual targets) |
| Рендер из 14+ референсов | **Nano Banana Pro** (до 14) или **GPT Image 2** (до 16) |

## Когда что выигрывает

### Nano Banana выигрывает в
- **Image grounding.** NB2 ищет реальные изображения в интернете перед генерацией — точная архитектура конкретного храма, моста, площади; конкретные виды животных, растений. GPT Image 2 этого не делает.
- **Экстремальные пропорции.** 1:8, 8:1, 1:4, 4:1 — баннеры, скроллы, комикс-стрипы. У GPT Image 2 max 3:1.
- **«Thinking» режим.** Сложные инфографики со spatial logic.
- **Цена/скорость.** NB2 = $0.04/img.

### GPT Image 2 выигрывает в
- **Identity preservation в edit.** Меняешь одежду / погоду / фон — лицо, поза, геометрия не плывут. Двухколоночная логика (change / preserve) работает как контракт.
- **Тонкий текст в кадре.** Маленькие подписи, легенды, footnotes, multi-font layouts. На `quality: high` рендерит чётче.
- **UI-моки и продуктовые скриншоты.** Иерархия, реальные интерфейс-элементы, читаемые лейблы.
- **Структурированный 5-slot промпт.** Чёткое разделение Scene/Subject/Details/Use case/Constraints даёт предсказуемость.
- **`quality` рычаг.** low/medium/high — осознанный trade-off скорости и точности.

### Где обе модели одинаково хороши
- Photorealistic портреты.
- Product shots на нейтральном фоне.
- Минималистичные постеры.
- Editorial-фотография.

## Различия в синтаксисе промпта

| Аспект | Nano Banana | GPT Image 2 |
|--------|-------------|-------------|
| Стиль промпта | Натуральный язык, 1-2 параграфа | 5-slot с лейблами секций |
| Камера/линза | **Не указывать** числа (50mm, f/2.8) — NB игнорит | Можно «50mm feel», но как high-level look |
| «Stunning/epic/masterpiece» | Игнорит, не вредит | **Anti-slop**: вредит, делает результат хуже |
| Text in image | `"..."` в кавычках, font + position | `"..."` или ALL CAPS + «no extra words / no duplicate text» |
| Negative framing | Использовать позитив | Использовать позитив + явный preserve list |
| Сложные сцены | JSON для 5+ элементов | 5-slot template со секциями |
| Edit | «Keep X same, change Y» | «Change: X / Preserve: Y / Constraints: Z» — повторять preserve каждую итерацию |
| Множественные референсы | До 14, индексировать | До 16, индексировать с ролью («Image 1: base», «Image 2: jacket reference») |

## Стоимость (ориентир)

| Модель | Цена | Заметки |
|--------|------|---------|
| Nano Banana 2 Lite | ~$0.034/img | Только 1K, ~4 сек. Черновики и массовые батчи |
| Nano Banana 2 (Flash) | ~$0.04/img | Default для большинства задач |
| Nano Banana Pro | ~$0.15/img | Сложные сцены, до 14 рефов |
| GPT Image 2 (`low`) | дёшево | Latency-sensitive, превью |
| GPT Image 2 (`medium`) | средне | Default для GPT Image |
| GPT Image 2 (`high`) | дороже | Маленький текст, brand-sensitive, photorealism |
| gpt-image-1-mini | дешёвый | Высокообъёмная exploratory-генерация |

> Скилл сам не запускает генерацию — выдаёт промпт. Модель/quality указываем рядом с промптом как мета.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/multi-panel.md

# Multi-Panel Compositions

Single-image layouts containing multiple frames, panels, or grid cells. Unlike [storyboards.md](storyboards.md) (sequential images generated one-at-a-time), these patterns produce **one image** with all panels baked in.

Core principle: explicitly number and describe every panel. Models need panel-by-panel instructions — vague requests like "show multiple angles" produce inconsistent grids.

---

## 1. 9-Cell Grid Storyboard

> For a product-focused narrative variant, see [patterns/ecommerce.md](patterns/ecommerce.md#9-panel-tvc-storyboard-grid).

**When to use:** TVC or commercial shot breakdown — one image = 9 panels with scene titles and timestamps.

### Template (5-slot format)

```
Scene: Dark storyboard layout — 3x3 grid of cinematic frames for a {duration}-second {product_name} commercial. Each cell has a thin dark border. Below each cell: scene number, title, and timestamp in small white sans-serif text on dark background.

Subject: {product_name} commercial storyboard showing the complete narrative arc across 9 panels.

Important Details:
Panel 1 (0:00–{t1}): {scene_1_description}
Panel 2 ({t1}–{t2}): {scene_2_description}
Panel 3 ({t2}–{t3}): {scene_3_description}
Panel 4 ({t3}–{t4}): {scene_4_description}
Panel 5 ({t4}–{t5}): {scene_5_description}
Panel 6 ({t5}–{t6}): {scene_6_description}
Panel 7 ({t6}–{t7}): {scene_7_description}
Panel 8 ({t7}–{t8}): {scene_8_description}
Panel 9 ({t8}–{duration}): {scene_9_description}

Each panel labeled below: "Scene {N}: {title}" and "{start}–{end}"

Use Case: Pre-production storyboard for video production team
Constraints: All 9 panels must be clearly separated, no merged cells, every panel must contain distinct content, timestamps must be legible, {language} titles
```

**Variables:**
- `{product_name}` — brand/product
- `{duration}` — total spot length (e.g., "30", "60")
- `{t1}` through `{t8}` — timestamp boundaries
- `{scene_1_description}` through `{scene_9_description}` — shot description per panel
- `{language}` — "Chinese" / "English" / "bilingual"

**Recommended size:** 1536x1024 (landscape)
**Model:** GPT Image 2 `quality: high` (text-heavy — timestamps and titles need legibility)
**Common pitfalls:**
- Omitting panel numbers causes the model to merge or skip panels
- Vague scene descriptions produce near-identical panels — each must have a distinct action, angle, or subject
- Timestamps in very small text need `quality: high` to remain readable

---

## 2. 2x2 Editorial Portrait Grid

**When to use:** Same person shown from 4 angles/crops in one image for an editorial or casting look.

### Template (5-slot format)

```
Scene: 2x2 grid of four editorial portraits, minimal gap between panels. {background_description}. {lighting_style}.

Subject: {subject_description} — same person in all four panels, consistent identity and wardrobe.

Important Details:
Top-left: front-facing portrait, direct eye contact, shoulders up
Top-right: extreme macro close-up of face — eyes, skin texture, freckles visible
Bottom-left: lower angle looking up, chin slightly raised, confident expression
Bottom-right: side profile, clean silhouette against background

Consistent lighting across all four panels. Skin texture realistic, no airbrushing.

Use Case: editorial photography, model portfolio, casting composite
Constraints: same person in every panel, no wardrobe changes between panels, no extra people, no text overlays
```

**Variables:**
- `{subject_description}` — age, appearance, wardrobe (e.g., "woman in her 30s, dark curly hair, white linen shirt")
- `{background_description}` — (e.g., "soft gray studio backdrop")
- `{lighting_style}` — (e.g., "single key light from upper left, subtle fill from right")

**Recommended size:** 1024x1024 (square) or 1024x1536 (vertical for portrait emphasis)
**Model:** GPT Image 2 `quality: medium` or Nano Banana Pro (both handle photorealistic portraits well)
**Common pitfalls:**
- Not specifying "same person" in every panel — model may generate four different people
- Omitting which quadrant gets which angle — model arranges arbitrarily
- Requesting too-different crops (full body + extreme close-up) creates scale inconsistency within the grid

---

## 3. 3-Panel Campaign Collage

**When to use:** Hero shot + close-up + action for a campaign visual — horizontal or vertical triptych.

### Template (5-slot format)

```
Scene: Three-panel {orientation} collage for {brand_name} campaign. Panels separated by thin white lines.

Subject: {model_description} showcasing {product_description}.

Important Details:
Panel 1 (left/top): Hero wide shot — full figure of model with product, environmental context, lifestyle setting
Panel 2 (center/middle): Close-up product detail — {product_detail_description}, tactile textures, sharp focus
Panel 3 (right/bottom): Action shot — model using/wearing/interacting with product, candid energy, slight motion blur on extremities

Consistent warm golden-hour lighting across all panels. Same model identity throughout.
{typography_instruction}

Use Case: social media campaign visual, brand lookbook
Constraints: same person across all panels, consistent color grading, no stock-photo stiffness, {product_name} must be visible in every panel
```

**Variables:**
- `{orientation}` — "horizontal" (side by side) or "vertical" (stacked)
- `{brand_name}`, `{product_name}`, `{product_description}` — brand context
- `{model_description}` — who appears
- `{product_detail_description}` — what the close-up shows
- `{typography_instruction}` — e.g., `Text: "{HEADLINE}" in bold condensed white, overlaid on Panel 1 lower third` or omit for no text

**Recommended size:** 1536x1024 (horizontal triptych) or 1024x1536 (vertical triptych)
**Model:** GPT Image 2 `quality: medium` — if text overlay needed, use `quality: high`
**Common pitfalls:**
- Not specifying panel order — "hero, close-up, action" without left/center/right assignment
- Lighting inconsistency when mixing indoor close-up with outdoor hero shot — specify unified lighting
- Forgetting to mention subject consistency causes three different models

---

## 4. 4x3 Borderless Grid

**When to use:** 12 panels telling a story or showing moods — no gaps between panels, seamless mosaic feel.

### Template (5-slot format)

```
Scene: 4x3 borderless grid (4 columns, 3 rows) where each of the 12 panels is an independent image but panels share no borders, gaps, or dividers — edges touch seamlessly. Overall theme: {theme}.

Subject: {subject_description} — maintain strong subject consistency across all 12 panels.

Important Details:
Row 1: {panel_1}, {panel_2}, {panel_3}, {panel_4}
Row 2: {panel_5}, {panel_6}, {panel_7}, {panel_8}
Row 3: {panel_9}, {panel_10}, {panel_11}, {panel_12}

Style: {style_description}
Mood progression: {mood_arc}
Each panel is an independent composition but the overall grid reads as a unified artwork.

Use Case: mood board, editorial spread, social media carousel preview, album artwork
Constraints: borderless — no white lines, no black borders, no gaps between panels. Same subject identity across all panels. No text in panels.
```

**Variables:**
- `{subject_description}` — who/what appears across panels
- `{theme}` — overarching concept (e.g., "solitude in a city", "four seasons of a garden")
- `{panel_1}` through `{panel_12}` — brief shot description per cell
- `{style_description}` — visual style (e.g., "35mm film grain, desaturated palette")
- `{mood_arc}` — how energy changes across the grid (e.g., "calm morning to chaotic night")

**Recommended size:** 1536x1024 (landscape) — gives each cell enough resolution
**Model:** Nano Banana Pro (handles complex multi-element compositions with thinking mode; no text needed)
**Common pitfalls:**
- Saying "borderless" is not enough — explicitly state "no white lines, no black borders, no gaps"
- 12 panels in one image pushes detail limits — keep per-panel descriptions short and visually distinct
- Without explicit subject consistency instructions, each panel may feature a different person/object

---

## 5. 6-Frame Cinematic Sequence

**When to use:** Fashion editorial or film-style sequence — multiple camera angles of the same scene in one image.

### Template (5-slot format)

```
Scene: 6-frame cinematic sequence arranged in a 3x2 grid. Dark film-strip aesthetic with thin black borders. {location_description}.

Subject: {subject_description}, wearing {wardrobe_description}. Same person, same outfit, same location across all 6 frames.

Important Details:
Frame 1 (top-left): Top-down bird's eye view — subject seen from directly above, full body visible against ground/floor
Frame 2 (top-center): Low angle looking up — subject towering over camera, dramatic perspective, sky/ceiling visible
Frame 3 (top-right): Wide isolation shot — subject small in frame, vast environment dominates, sense of scale
Frame 4 (bottom-left): Close-up with slight tilt — face and upper body, Dutch angle, intimate intensity
Frame 5 (bottom-center): Motion frame — subject mid-action ({motion_action}), natural motion blur on limbs
Frame 6 (bottom-right): Grounded final — medium shot, subject at rest, direct gaze, resolving the sequence

Photographer reference: {photographer_style}
Lighting: consistent {lighting_description} across all frames

Use Case: fashion editorial, film lookbook, director's shot list visualization
Constraints: same person and wardrobe in every frame, no costume changes, consistent color grading, no text overlays
```

**Variables:**
- `{subject_description}` — model details
- `{wardrobe_description}` — clothing
- `{location_description}` — setting
- `{motion_action}` — what the motion frame captures (e.g., "walking forward", "turning sharply", "jumping")
- `{photographer_style}` — (e.g., "Peter Lindbergh desaturated realism", "Helmut Newton dramatic contrast")
- `{lighting_description}` — (e.g., "overcast natural light, soft shadows")

**Recommended size:** 1536x1024 (landscape, 3x2 grid)
**Model:** GPT Image 2 `quality: medium` or Nano Banana Pro
**Common pitfalls:**
- Not naming each frame explicitly — "various angles" is too vague, the model needs per-frame instructions
- Top-down and low-angle in the same grid confuse the model if you don't anchor each frame to a grid position
- Motion blur instruction must be specific ("blur on hands and feet") or the model applies blur everywhere

---

## 6. Before/After Split

**When to use:** Product transformation, makeover, time comparison, renovation — two states side by side.

### Template (5-slot format)

```
Scene: Single image split into left and right halves with a {divider_style} dividing line down the center. Before/after comparison.

Subject: {subject_description}

Important Details:
Left half (BEFORE): {before_description} — {before_condition}
Right half (AFTER): {after_description} — {after_condition}

The transition at the center line should feel {transition_style}. Same camera angle, same framing, same background perspective in both halves — only the subject's state changes.

Use Case: {use_case}
Constraints: identical composition and camera angle on both sides, same lighting direction, no text unless specified, the dividing line must be clearly visible
```

**Variables:**
- `{subject_description}` — what is being compared
- `{before_description}` / `{before_condition}` — left side state (e.g., "faded, cracked wall with peeling paint")
- `{after_description}` / `{after_condition}` — right side state (e.g., "freshly painted wall, smooth finish, vibrant color")
- `{divider_style}` — "thin white line" / "subtle gradient blend" / "sharp vertical cut"
- `{transition_style}` — "clean and abrupt" / "natural, as if wiping away"
- `{use_case}` — "product marketing", "renovation portfolio", "skincare results"

**Recommended size:** 1536x1024 (landscape — gives each half a portrait-like proportion)
**Model:** GPT Image 2 `quality: medium` — for text labels ("BEFORE" / "AFTER"), use `quality: high`
**Common pitfalls:**
- Not specifying "same camera angle both sides" — model may show two completely different viewpoints
- Without a visible divider, the two halves can merge into one ambiguous scene
- Left/right assignment matters — always state which side is before and which is after

---

## 7. 12-Panel Storyboard Poster

**When to use:** Full narrative in one image — 3x4 grid (3 columns, 4 rows) for animation or video pre-production.

### Template (5-slot format)

```
Scene: 12-panel storyboard poster, 3 columns x 4 rows. Dark background with each panel in a clean rectangular frame. "{title}" in bold white text at the top of the image. Below each panel: scene number and one-line description in small white text.

Subject: {character_description} — maintain consistent character design, proportions, and colors across all 12 panels.

Important Details:
Panel 1: {scene_1} — "{caption_1}"
Panel 2: {scene_2} — "{caption_2}"
Panel 3: {scene_3} — "{caption_3}"
Panel 4: {scene_4} — "{caption_4}"
Panel 5: {scene_5} — "{caption_5}"
Panel 6: {scene_6} — "{caption_6}"
Panel 7: {scene_7} — "{caption_7}"
Panel 8: {scene_8} — "{caption_8}"
Panel 9: {scene_9} — "{caption_9}"
Panel 10: {scene_10} — "{caption_10}"
Panel 11: {scene_11} — "{caption_11}"
Panel 12: {scene_12} — "{caption_12}"

Panels read left-to-right, top-to-bottom (like a comic page). Character appearance, clothing, and color palette must stay identical across all 12 panels — only pose, expression, angle, and environment change.

Style: {art_style}

Use Case: animation pre-production, pitch deck visualization, narrative overview poster
Constraints: all 12 panels must be distinct scenes (no duplicates), character consistency is critical, scene numbers must be legible, {language} captions
Quality: high
```

**Variables:**
- `{title}` — project/episode title displayed at top
- `{character_description}` — detailed character design (colors, outfit, distinguishing features)
- `{scene_1}` through `{scene_12}` — visual description of each panel
- `{caption_1}` through `{caption_12}` — text label under each panel
- `{art_style}` — (e.g., "Pixar-style 3D", "anime cel shading", "watercolor illustration", "graphic novel ink")
- `{language}` — caption language

**Recommended size:** 1024x1536 (portrait — 3 columns x 4 rows needs vertical space)
**Model:** GPT Image 2 `quality: high` (text-heavy — scene numbers and captions must be readable)
**Common pitfalls:**
- Character drift is the biggest risk at 12 panels — repeat character design details in the prompt, not just "same character"
- Without explicit scene numbering in the prompt, panels may appear in random order
- 12 panels with captions is extremely text-dense — keep captions under 5 words each for legibility
- Art style must be stated once and applied uniformly; mixing styles across panels produces visual chaos

---

## General Multi-Panel Tips

**Panel count vs. detail trade-off:** More panels = less detail per panel. 4 panels allow rich per-panel descriptions; 12 panels need brief, visually distinct descriptions (3-8 words each).

**Subject consistency:** Always include an explicit instruction: "same person / same character / same product across all panels." Repeat key identity markers (hair color, clothing, distinguishing features) rather than saying "same as before."

**Grid specification:** Always state the grid dimensions (e.g., "3x2 grid, 3 columns 2 rows"). Saying "6 panels" without layout instruction lets the model choose an unpredictable arrangement.

**Borders and gaps:** Be explicit — "thin white border between panels" or "borderless, no gaps." Default behavior varies by model and is unreliable.

**Reading order:** State it: "left-to-right, top-to-bottom" or "numbered 1-9 starting top-left." Without this, narrative flow may be jumbled.

**Model selection summary:**
- Text/labels in panels --> GPT Image 2 `quality: high`
- No text, complex composition --> Nano Banana Pro
- Budget/exploration --> Nano Banana 2 or GPT Image 2 `quality: low`

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/nano-banana.md

# Nano Banana — Specific Rules

Три тира. «Thinking» модели — понимают намерение, физику, композицию.

| Тир | Model ID | Роль |
|-----|----------|------|
| **NB2 Lite** | `gemini-3.1-flash-lite-image` | Самая быстрая и дешёвая ($0.034, ~4 сек), только 1K. Черновики, массовые батчи |
| **NB2** (Flash) | `gemini-3.1-flash-image` | Дефолтный workhorse: Pro-фичи (текст, 4K, grounding, консистентность) на скорости Flash |
| **NBP** (Pro) | `gemini-3-pro-image` | Топ-тир: сложные многослойные сцены, максимум reasoning и контроля |

## Стиль промпта

Натуральный язык, 1-2 параграфа. Структура свободная, но порядок помогает:
**Subject + Action + Location/context + Composition + Style**

```
A cinematic wide shot of a futuristic sports car speeding through a rainy
Tokyo street at night. Neon signs reflect off wet pavement and metallic
chassis. Format: 16:9.
```

## Что НЕ указывать

- Числовые параметры объектива: **50mm, 85mm, f/2.8, ISO 400** — NB игнорит. Используй описание: «shallow depth of field», «wide-angle distortion».
- Tag-soup: «cool, modern, 4k, cinematic» — пишет связным предложением.

## Уникальные возможности

### Image Grounding (NB2 only)
NB2 ищет реальные изображения в интернете до генерации. Архитектурно точные конкретные локации, корректные виды животных/растений.

```
Generate a cinematic, golden-hour photograph of [SPECIFIC REAL PLACE].
Ensure the architectural details, the spire, the surrounding square, and
the landscape are accurate to reality.
```

**Работает:** здания, мосты, площади, виды животных, виды растений, насекомые.
**Не работает:** конкретные люди.

### Extreme Aspect Ratios (NB2 only)

1:8, 8:1, 1:4, 4:1 — для баннеров, скроллов, комикс-стрипов.

```
Create a 4-panel horizontal comic strip (aspect ratio 4:1).
The story follows [CHARACTER] doing [ACTION] that ends with a twist.
Use a vibrant comic book style. Keep character design consistent.
```

Стандартные: 1:1, 3:2, 2:3, 3:4, 4:3, 4:5, 5:4, 9:16, 16:9, 21:9.

### Thinking Mode

Включён по умолчанию; у NBP отключить нельзя (модель рисует до 2 «thought images» в бэкенде, они не тарифицируются как картинки, но thinking-токены платные). У NB2 есть рычаг `thinking_level: minimal | high` (default `minimal`) — поднимай до `high` для:
- Невнятных результатов, требующих reasoning
- Сложных инфографик со spatial logic
- Grounding + spatial reasoning одновременно

### Multi-Reference (лимиты по тирам)

| | NB2 Lite | NB2 | NBP |
|---|---|---|---|
| High-fidelity объекты | до 14 | до 10 | до 6 |
| Character-consistency рефы | нет | до 4 | до 5 |
| Style рефы | нет | нет | до 3 |

```
[Image 1: face]
[Image 2: outfit]
[Image 3: background]
Combine: face from Image 1, outfit style from Image 2, setting from Image 3.
Match lighting and perspective.
```

### JSON для сложных сцен (5+ элементов)

```json
{
  "subject": {"description": "main subject", "expression": "emotion/pose"},
  "photography": {"angle": "eye-level", "shot_type": "waist-up", "aspect_ratio": "16:9"},
  "background": {"setting": "location", "lighting": "soft natural"}
}
```

## Editing у Nano Banana

Conversational, без масок:

```
Remove [OBJECT] from this image.
Fill with [LOGICAL REPLACEMENT] matching surroundings.
Keep [PRESERVED ELEMENTS] exactly the same.
```

После генерации добавляй итеративно:
- «Make it warmer»
- «Increase contrast»
- «Soften background, add blur»
- «Change headline color to #3b82f6»

Interactions API держит контекст сессии — до 3 последовательных правок стэкаются без потери исходника. Правило «Edit, don't re-roll»: картинка верна на 80% — проси точечное изменение, а не новую генерацию.

## Text Rendering

- SOTA по 100+ языкам.
- Font можно называть: «Century Gothic 12px», «Brush Script», «Impact», «Heavy blocky sans-serif».
- Multi-language в одном кадре работает.
- Hack: для сложного текста — сначала попроси модель **написать текст**, потом отдельным промптом «вставь этот текст в картинку».

## Resolution / Cost

| Resolution | Использование |
|------------|---------------|
| 0.5K | Самая дешёвая, batch и А/B варианты |
| 1K | Default |
| 2K | Финальный отбор |
| 4K | Печать, hero-ассеты |

**Workflow:** прогон вариантов на `0.5K` flash (или NB2 Lite на 1K) → отбор → переген победителя на `2K`/`4K`.

В API `image_size` пишется строго с заглавной K (`1K`, `2K`, `4K`) — `1k` отклоняется. `512px` есть только у NB2; Lite — только 1K. Без указания размера модель матчит вход, иначе 1:1.

## Кейфреймы для видео

Nano Banana — image-слой перед motion-слоем. Всё критичное фиксируется на картинке ДО анимации: identity, композиция, aspect ratio, видимый текст, состояние продукта. Видеомодель усиливает любую неоднозначность стилла.

- **Character sheet / hero frame.** Утверди один кадр-эталон персонажа, на него ссылаются все последующие video-промпты.
- **Aspect ratio сразу целевой.** Кампании нужен вертикальный ролик — генери 9:16, а не кропай после анимации (тихая точка отказа).
- **Хэндофф в видеомодель — motion brief, не пересказ.** Движение камеры, движение субъекта, движение фона, длительность, framing lock, запрещённые изменения. Видео-промпт не переописывает то, что уже есть в кадре.
- Downstream любой: Veo 3.1, Kling 3.0, Seedance 2.0/2.5, Gemini Omni Flash (штатная пара Google, 10-сек клипы). Батч картинок → ревью-гейт → в видео уходят только одобренные стиллы.

## Известные фейлы

- Руки и лица всё ещё плывут (пальцы, суставы, дрейф likeness) — явные anatomy-инструкции + рефы + перегенерации. Есть отчёты, что NBP держит лица хуже NB2.
- Мелкий текст мылится на 1K — для плотного текста 2K+ или GPT Image 2.
- Инфографика может содержать фактически неверные данные — цифры проверять всегда, grounding помогает, но не гарантирует.
- Склонность к overcooked HDR / пересату — проси «natural contrast, no HDR look».
- SynthID-водяной знак стоит на всех генерациях (невидимый); на Vertex дополнительно C2PA.

## Когда переключаться NB2 → NBP

- NB2 не справляется со сложным многослойным промптом.
- Нужен максимум референсов с разбивкой по ролям (6 объектов + 5 character + 3 style).
- Photoreal с очень тонкой работой по материалам и свету.
- NBP медленнее и дороже; на лицах иногда проигрывает NB2 — для портретной серии сначала тестируй оба.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/patterns/character-design.md

# Character Design Patterns

Reusable prompt templates for character turnarounds, expression sheets, outfit variants, and collectible/card formats. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Character Turnaround Sheet (3-View)

Use for game or animation pre-production — front, side, and back views of a character on a single white canvas with color callouts and height reference lines.

<!-- Source concept: character model sheet / turnaround sheet for 3D modelers and animators -->

```
Scene: clean white background, flat even lighting with no cast shadows, thin horizontal height reference lines in #CCCCCC spanning the full width at head, shoulder, waist, knee, and foot level
Subject: {character_name} — {character_description} — shown in three views arranged left to right: front view (facing camera), three-quarter side view (turned 75 degrees right), back view (facing away)
Important Details: all three views share identical proportions and vertical alignment along the height lines, feet on the same baseline, arms relaxed at sides for clear silhouette reading, color callout annotations — small circles of each key color ({color_1} {hex_1}, {color_2} {hex_2}, {color_3} {hex_3}) connected by thin #999999 leader lines to the corresponding material on the front view, fine line weight for height markers, clothing folds and seam lines consistent across all three angles
Use Case: game character pre-production, animation model sheet, 3D reference handoff
Constraints: no background elements, no props in hands, no dramatic poses — neutral standing pose only, all three views must depict the exact same character with identical outfit and proportions, no drop shadows, no gradient backgrounds
```

**Key levers:** `{character_name}`, `{character_description}` (age, build, hairstyle, outfit — be specific), `{color_1}`/`{hex_1}` through `{color_3}`/`{hex_3}` (key palette colors for callouts, e.g. jacket navy #1B2A4A, skin warm beige #D4A574, hair auburn #8B3A2F)

**Recommended model:** GPT Image 2 (`quality: high`) — height reference lines and color callout text require precise rendering

---

## Expression Sheet

Use to produce a grid of 6–9 facial expressions for the same character — consistent head angle and art style, with emotion labels under each face.

<!-- Source concept: character expression/emotion reference sheet for animation or visual novel production -->

```
Scene: white background, 3x3 grid (or 3x2 for 6 expressions) with thin #DDDDDD divider lines, each cell contains one head-and-shoulders portrait
Subject: {character_name} — {character_description} — same head angle (three-quarter left), same hairstyle, same lighting across all cells
Important Details:
  Cell 1: neutral — relaxed brow, closed mouth, calm eyes. Label: "NEUTRAL"
  Cell 2: happy — genuine smile reaching the eyes, raised cheeks. Label: "HAPPY"
  Cell 3: angry — furrowed brow, clenched jaw, narrowed eyes. Label: "ANGRY"
  Cell 4: sad — downturned mouth, glistening eyes, slightly lowered head. Label: "SAD"
  Cell 5: surprised — wide eyes, raised eyebrows, open mouth. Label: "SURPRISED"
  Cell 6: disgusted — wrinkled nose, upper lip raised, squinted eyes. Label: "DISGUSTED"
  {extra_expressions}
  Labels in small {label_font} beneath each cell, #555555 text
  Consistent {art_style} rendering across all cells — skin tone, line weight, shading approach identical
Use Case: animation expression reference, visual novel sprite guide, game character documentation
Constraints: same character identity in every cell — no variation in hair, accessories, skin tone, or clothing between expressions, head angle stays fixed, no hand gestures, labels must be legible
```

**Key levers:** `{character_name}`, `{character_description}` (face shape, skin tone, hair, distinguishing marks), `{art_style}` (clean cel-shaded anime, painterly semi-realism, flat vector illustration), `{label_font}` (condensed sans-serif, monospace, rounded sans), `{extra_expressions}` (add cells 7-9: e.g. "Cell 7: smirk — one corner of mouth raised, knowing look. Label: 'SMIRK'")

**Recommended model:** GPT Image 2 (`quality: high`) — text labels and consistent facial identity across 9 cells need precise control

---

## Outfit Variant Grid

Use to show one character in multiple outfits or costumes — for fashion exploration, game skin concepts, or wardrobe design.

<!-- Source concept: character costume/skin variant sheet for fashion or game design -->

```
Scene: light neutral background ({bg_color}), {grid_layout} grid, thin white gaps between cells, soft even front lighting in every cell
Subject: {character_name} — {character_description} — same pose ({pose_description}) in every cell, only the outfit changes
Important Details:
  Cell 1: {outfit_1_name} — {outfit_1_description}
  Cell 2: {outfit_2_name} — {outfit_2_description}
  Cell 3: {outfit_3_name} — {outfit_3_description}
  Cell 4: {outfit_4_name} — {outfit_4_description}
  Cell 5: {outfit_5_name} — {outfit_5_description}
  Cell 6: {outfit_6_name} — {outfit_6_description}
  Outfit name in small bold sans-serif centered below each cell, #333333 text
  Character body proportions, face, hairstyle, and skin tone identical across all cells — only clothing and accessories differ
Use Case: game skin lineup, fashion mood board, costume design exploration
Constraints: same character identity and pose in every cell, no background scenery — character only, outfit labels must be readable, no overlapping garments between cells, {grid_layout} layout must be uniform
```

**Key levers:** `{character_name}`, `{character_description}` (build, face, hair — anchor identity), `{bg_color}` (#F0F0F0 light gray, #FFF8F0 warm cream, #E8EDF2 cool blue-gray), `{grid_layout}` (2x3 or 3x3), `{pose_description}` (hands on hips, relaxed standing, one hand raised), `{outfit_N_name}` / `{outfit_N_description}` (e.g. "Street Casual" — oversized denim jacket, white tee, black cargo pants, chunky sneakers)

**Recommended model:** GPT Image 2 (`quality: medium`) — character consistency is the priority; `high` only if outfit labels need fine legibility

---

## Chibi / Mini-Me Collectible

Use to transform a realistic character into a cute 3D collectible figurine — oversized head, compact body, multiple poses performing different activities.

<!-- Source concept: chibi/super-deformed vinyl collectible figurine with consistent identity across poses -->

```
Scene: soft gradient background ({bg_gradient}), studio product lighting with rim light from behind and soft fill from front, subtle ground shadow beneath each figurine
Subject: chibi-style 3D collectible figurine of {character_name} — {character_description_simplified} — large head (roughly 1:2 head-to-body ratio), rounded limbs, smooth matte vinyl surface, {num_poses} poses arranged in a row
Important Details:
  Pose 1: {pose_1_description}
  Pose 2: {pose_2_description}
  Pose 3: {pose_3_description}
  {extra_poses}
  Face retains recognizable features from the original character — {face_markers} — simplified into the chibi style with large round eyes and small nose/mouth
  Outfit matches the original: {outfit_simplified} — colors preserved ({color_palette}), details reduced to clean shapes
  Each figurine sits on a small circular base ({base_color} matte finish)
  Vinyl toy aesthetic — visible seam line at sides, slight glossy highlight on forehead and cheeks
Use Case: merchandise concept, social media avatar set, fan collectible design
Constraints: consistent face and outfit across all poses, chibi proportions must stay uniform (no realistic proportions creeping in), no text on bases, smooth render — not cel-shaded, matte vinyl material throughout
```

**Key levers:** `{character_name}`, `{character_description_simplified}` (key outfit and hair only), `{face_markers}` (e.g. round glasses, scar on left cheek, green eyes), `{color_palette}` (hex values for 2-3 dominant colors), `{bg_gradient}` (#F5F0EB to #FFFFFF warm, #E0E8F0 to #FFFFFF cool), `{num_poses}` (3-5), `{pose_N_description}` (e.g. sitting cross-legged reading a book, waving with both hands, holding a coffee cup), `{base_color}` (white, black, matching character's main color)

**Recommended model:** GPT Image 2 (`quality: medium`) — smooth 3D vinyl surfaces render well at medium; `high` for marketing-ready close-ups

### Nano Banana version:

```
A row of {num_poses} chibi-style 3D vinyl collectible figurines of {character_name}, each in a different pose. Large head (1:2 head-to-body ratio), rounded limbs, smooth matte vinyl surface with visible seam lines and subtle glossy highlights on the forehead. Face retains {face_markers} simplified into chibi proportions with large round eyes. Outfit: {outfit_simplified} in {color_palette}. Poses left to right: {pose_1_description}, {pose_2_description}, {pose_3_description}. Each figurine on a small circular {base_color} matte base. Soft gradient background ({bg_gradient}), studio product lighting with rim light from behind and soft fill from front, subtle ground shadow. Format: 16:9.
```

---

## Anime-Style Character Card

Use for a full character reference card with portrait, full body, key items, and color palette — organized on a white background in a professional concept art layout.

<!-- Source concept: anime/game character reference sheet with stats, items, and palette swatches -->

```
Scene: white background, organized reference card layout divided into clear sections with thin #CCCCCC separator lines
Subject: {character_name} — {character_description} — anime-style rendering with clean line art and flat cel shading
Important Details:
  Left section (40% width): full-body standing pose, front-facing, arms slightly away from body to show full outfit, feet visible, confident neutral expression
  Upper-right section: portrait bust — head and shoulders, three-quarter angle, detailed face rendering showing {face_details}
  Mid-right section: {num_items} key items arranged in a row — {item_1}, {item_2}, {item_3} — each drawn at consistent scale with thin outline, labeled in small text below
  Lower-right section: color palette — {num_swatches} rectangular swatches in a horizontal strip showing the character's key colors ({swatch_colors}), hex code below each swatch
  Bottom strip: brief stat block or bio text in clean sans-serif — "Name: {character_name} | Class: {class} | Height: {height} | Affiliation: {affiliation}"
  Consistent line weight and shading style across all sections
Use Case: game character documentation, light novel illustration guide, animation production reference
Constraints: unified anime art style across all sections — portrait and full body must be the same character with identical design, items must match what the character wears/carries in the full body view, no decorative borders or ornamental frames, text must be legible at screen resolution
```

**Key levers:** `{character_name}`, `{character_description}` (detailed: hair color/style, eye color, outfit layers, accessories), `{face_details}` (distinctive facial features — e.g. heterochromia, facial tattoo, sharp jawline), `{item_1}`/`{item_2}`/`{item_3}` (signature weapon, accessory, artifact), `{swatch_colors}` (e.g. midnight blue #191970, cherry red #C41E3A, silver #C0C0C0, warm skin #E8B89D), `{num_swatches}` (4-6), `{class}` / `{height}` / `{affiliation}` (stat block fields)

**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout with hex codes, labels, and stat block requires precise rendering

### Nano Banana version:

```
An anime-style character reference card for {character_name} on a white background. Left side: full-body standing pose, front-facing, clean cel-shaded anime rendering — {character_description}. Upper right: portrait bust at three-quarter angle showing {face_details}. Mid-right: key items laid out in a row — {item_1}, {item_2}, {item_3} — each drawn consistently and labeled. Lower right: horizontal color palette strip with {num_swatches} rectangular swatches ({swatch_colors}). Clean layout with thin gray separator lines between sections. Professional concept art quality, consistent line weight throughout. Format: 3:4.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/patterns/ecommerce.md

# E-Commerce Product Photography Patterns

Reusable prompt templates for product ads, packaging, and commercial visuals. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Miniature Diorama Product Ad

Use when you need a playful, attention-grabbing product visual where tiny workers interact with an oversized product — ideal for social media ads and launch campaigns.

<!-- Source concept: miniature/tilt-shift product advertising with construction-worker scale play -->

```
Scene: clean {surface_color} tabletop studio, soft overhead diffused light, shallow depth of field with tilt-shift blur at edges
Subject: oversized {product_name} centered in frame, surrounded by miniature construction workers (1/87 scale figurines) — some climbing the packaging with tiny ladders, others operating a miniature crane to lift the cap/lid, a crew painting the label
Important Details: {product_material} surface catches key light from upper left, visible condensation/texture on product, figurines cast tiny hard shadows, warm {accent_color} hard hats on workers, fine detail on miniature tools, slightly desaturated background, eye-level camera angle
Use Case: social media product ad, Instagram carousel hero
Constraints: no text, no logos other than product label, no floating elements, product must remain recognizable and unaltered, no more than 8 figurines
```

**Key levers:** `{product_name}`, `{product_material}` (frosted glass, matte aluminum, glossy plastic), `{surface_color}` (white marble, raw concrete, light birch wood), `{accent_color}` (safety orange #FF6600, yellow #FFD600)

**Recommended model:** GPT Image 2 (`quality: high`) — precise figurine detail and product label legibility

---

## Luxury Cosmetics Studio Shot

Use for premium beauty or fragrance product photography — dark, moody, tactile surfaces with atmospheric effects.

<!-- Source concept: luxury perfume/cosmetics dark-marble studio photography with condensation and smoke -->

```
Scene: dark studio, {background_surface} surface with subtle reflections, thin layer of low-hanging smoke drifting left to right, {time_mood} ambient
Subject: {product_name} bottle/tube centered, three-quarter angle, {product_finish} catching a single key light from upper right
Important Details: fine water droplets on product surface (condensation, not spray), {accent_material} accent elements flanking the product (raw stone, dried botanicals, metal shavings), volumetric haze behind product, reflection on surface below is soft and dark, color palette restricted to {palette}, contact shadow sharp near base fading to soft
Use Case: luxury brand campaign hero, print ad, website banner
Constraints: no text overlays, no human hands, background stays dark (#0a0a0a to #1a1a1a gradient), no color spill outside the defined palette, no lens flare
```

**Key levers:** `{background_surface}` (nero marquina marble, wet obsidian slab, brushed gunmetal), `{product_finish}` (frosted glass, lacquered black, brushed gold), `{accent_material}` (raw quartz crystals, dried lavender stems, black river stones), `{palette}` (golds #C9A84C and blacks, rose #B76E79 and creams, emerald #2D6A4F and silvers), `{time_mood}` (cold blue, warm amber)

**Recommended model:** GPT Image 2 (`quality: high`) — surface materials and condensation detail

---

## 9-Panel TVC Storyboard Grid

> For a dark-themed variant with timestamps, see [multi-panel.md](../multi-panel.md#1-9-cell-grid-storyboard).

Use to present a product commercial shot breakdown in a single image — pitch decks, creative presentations, client approvals.

<!-- Source concept: 9-panel television commercial storyboard grid with numbered frames -->

```
Scene: white canvas background, clean 3x3 grid with thin #CCCCCC divider lines (2px), each cell represents one shot in a {duration}-second commercial
Subject: {product_name} commercial storyboard — each panel is a distinct camera setup
Important Details:
  Panel 1 (wide): establishing shot of {setting}, warm natural light, product not yet visible
  Panel 2 (medium): {protagonist} notices/discovers the product on {surface}
  Panel 3 (close-up): hand reaching for {product_name}, shallow depth of field
  Panel 4 (ECU): product detail — texture of {product_material}, label readable
  Panel 5 (medium): {protagonist} using/opening the product, genuine expression
  Panel 6 (reaction): close-up face, {emotion} expression, soft key light
  Panel 7 (wide): product in context of {lifestyle_scene}
  Panel 8 (beauty shot): product hero on {beauty_surface}, studio lighting
  Panel 9 (pack shot): product centered on white with "{tagline}" below in thin sans-serif, #333333
Use Case: creative pitch deck, storyboard for TVC production
Constraints: consistent character identity across all panels, no panel numbering text, uniform lighting temperature within the narrative (panels 1-7), distinct studio lighting for panels 8-9
```

**Key levers:** `{product_name}`, `{protagonist}` (woman in her 30s, young couple, family), `{setting}` (bright kitchen, outdoor terrace, urban cafe), `{emotion}` (satisfied, surprised, relaxed), `{beauty_surface}` (white marble, gradient gray), `{tagline}`, `{duration}` (15, 30)

**Recommended model:** GPT Image 2 (`quality: high`) — grid precision and text in panel 9

---

## Floating Ingredient Freeze-Frame

Use for food, beverage, or supplement products where suspended ingredients communicate freshness, flavor, or composition.

<!-- Source concept: frozen-motion ingredient explosion around product, high-speed photography aesthetic -->

```
Scene: {background_gradient} gradient backdrop, high-speed flash freeze-frame moment, clean studio environment
Subject: {product_name} container in center, tilted {tilt_angle} degrees, with {liquid_type} mid-pour arcing from the opening
Important Details: individual {ingredient_list} frozen in mid-air around the product — each element sharply focused with visible texture ({texture_details}), micro water droplets suspended alongside ingredients, single hard flash from behind (rim light on ingredients), secondary soft fill from front, liquid splash forms a clean arc with visible viscosity, product label faces camera and remains fully legible, ingredients distributed in a loose orbital pattern
Use Case: beverage packaging, food product poster, social media ad
Constraints: no ingredients overlapping the product label, no motion blur (everything frozen sharp), background must remain clean — no stray splashes hitting edges, no more than {max_ingredients} floating elements, no artificial glow effects
```

**Key levers:** `{product_name}`, `{background_gradient}` (#F5F0EB to #FFFFFF for light, #1A0A2E to #0D0D0D for dark), `{liquid_type}` (amber juice, white milk, green smoothie), `{ingredient_list}` (sliced strawberries + mint leaves + ice cubes, cocoa nibs + hazelnuts + vanilla pod), `{texture_details}` (visible seeds on strawberry cross-section, frost crystals on ice), `{tilt_angle}` (15, 25), `{max_ingredients}` (6-8)

**Recommended model:** GPT Image 2 (`quality: high`) — frozen detail precision and label legibility

---

## Inflatable Surrealism Product Poster

Use for disruptive, scroll-stopping social ads where the product packaging appears squeezed, inflated, or physically distorted as if made of soft rubber or vinyl.

<!-- Source concept: inflatable surrealism — product packaging rendered as squeezed/puffy/distorted soft objects -->

```
Scene: solid {background_color} background, soft even studio lighting with no hard shadows, slightly elevated camera angle (15 degrees above eye level)
Subject: {product_name} packaging reimagined as a puffy inflatable vinyl object — the shape is recognizable but squeezed at the middle as if gripped by an invisible hand, seams visible where vinyl panels meet, surface slightly reflective like a pool float
Important Details: {product_color_scheme} preserved on the inflated surface but stretched and slightly warped around curves, visible air valve at the bottom edge (small brass circle), subtle wrinkles where the vinyl compresses, the brand name/logo distorted by the inflation but still readable, two or three {companion_objects} nearby also inflated (matching aesthetic), environment reflection on glossy vinyl surface, cast shadow soft and diffused below
Use Case: disruptive social media ad, brand campaign poster, billboard
Constraints: product must remain identifiable despite distortion, no liquid, no particles, no humans, no text outside what exists on the packaging, vinyl texture must read as physical (not digital 3D render), background is flat color only
```

**Key levers:** `{product_name}`, `{background_color}` (bubblegum pink #FFB6C1, electric blue #007BFF, acid yellow #E8FF00), `{product_color_scheme}`, `{companion_objects}` (matching accessories, ingredient items, brand mascot elements)

**Recommended model:** NBP — complex spatial reasoning for believable physical distortion

### Nano Banana version:

```
A product poster showing {product_name} packaging transformed into a puffy inflatable vinyl object, squeezed at the middle as if gripped by an invisible hand. The surface is slightly glossy like a pool float, with visible seams where vinyl panels meet and a small brass air valve at the base. The original {product_color_scheme} is preserved but stretched and warped around the inflated curves. Brand text is distorted by the shape but still legible. Two small {companion_objects} sit nearby, also inflated in the same vinyl style. Solid {background_color} background, soft even studio light, slightly elevated camera angle. Soft diffused shadow below. Format: 4:5.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/patterns/fashion-editorial.md

# Fashion Editorial Patterns

Reusable prompt templates for fashion campaigns, lookbooks, and editorial shoots. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## 3-Panel Campaign Collage

Use for fashion brand campaign hero images — one wide shot combining hero pose, close-up detail, and action/movement in a triptych layout.

<!-- Source concept: fashion campaign triptych collage — hero + detail + movement panels -->

```
Scene: three vertical panels side by side on a single canvas (left 40% width, right split into two stacked panels 60% height each), thin white divider lines (3px), cohesive {lighting_setup} across all panels
Subject: {model_description} wearing {outfit_description} — same person, same outfit, three perspectives
Important Details:
  Left panel (hero): full-body three-quarter pose, {model_description} standing against {background_1}, weight shifted to one hip, direct gaze at camera, medium-format film grain, {color_grade}
  Top-right panel (detail): extreme close-up of {detail_focus} — visible weave/stitching/texture of {fabric_type}, shallow depth of field, warm directional light raking across surface
  Bottom-right panel (action): mid-stride walking shot from low angle, {background_2}, coat/fabric in motion with natural drape physics, slight motion energy in hair
  Overall: cohesive warm/cool temperature of {color_temperature}, consistent skin tone rendering across panels, editorial magazine quality
Use Case: fashion brand campaign, lookbook cover, social media carousel hero
Constraints: same person with identical features in all three panels, no text, no logos, no visible studio equipment, panels must feel like one shoot not three separate photos, no heavy retouching glow
```

**Key levers:** `{model_description}` (East Asian woman mid-20s, athletic man early 30s), `{outfit_description}`, `{detail_focus}` (collar construction, cuff button, belt buckle, shoe sole), `{fabric_type}` (raw selvedge denim, double-faced cashmere, washed silk), `{background_1}` (concrete wall, sand dune, industrial corridor), `{background_2}` (open street, field, rooftop), `{color_grade}` (lifted blacks with amber cast, desaturated teal), `{color_temperature}` (warm 4000K feel, cool overcast daylight)

**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency across panels and fabric texture detail

---

## 2x2 Editorial Portrait Grid

Use for model tests, casting cards, or editorial portfolio pages — four angles of the same person in a clean grid.

<!-- Source concept: 2x2 fashion portrait grid — same model, four setups -->

```
Scene: 2x2 grid on white canvas, thin {divider_color} divider lines (2px), all four cells use the same {background_type} with slight variation in angle
Subject: {model_description}, same {outfit_description} in all four frames
Important Details:
  Top-left: straight-on headshot, neutral expression, eyes to camera, even butterfly lighting
  Top-right: three-quarter profile, chin slightly lifted, single key light from camera-left creating defined cheekbone shadow
  Bottom-left: full profile silhouette, rim light from behind outlining jaw and nose, {background_type} slightly darker
  Bottom-right: candid moment — mid-laugh or adjusting {accessory}, natural movement, softer light
  All frames: {film_stock} color science, consistent {skin_tone_handling}, no heavy skin smoothing — visible pores and natural texture, shallow depth of field in all four
Use Case: fashion editorial spread, model comp card, casting portfolio
Constraints: identical person in all four frames (bone structure, skin, hair must match exactly), no makeup changes between frames, no text, no watermarks, backgrounds must feel cohesive not random
```

**Key levers:** `{model_description}`, `{outfit_description}` (black turtleneck, white linen shirt unbuttoned at collar), `{background_type}` (seamless medium gray, textured plaster wall, out-of-focus greenery), `{divider_color}` (#FFFFFF, #E0E0E0), `{film_stock}` (Kodak Portra 400, Fujifilm Pro 400H), `{skin_tone_handling}` (warm undertones preserved, cool-neutral rendering), `{accessory}` (earring, collar, watch)

**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency critical across four frames

---

## Streetwear Poster with Oversized Typography

Use for streetwear drops, limited edition launches, or urban fashion brand campaigns where bold type dominates the composition.

<!-- Source concept: streetwear poster with model integrated into oversized typographic layout -->

```
Scene: solid {background_color} background, graphic poster composition, typography dominates 60% of visual space
Subject: {model_description} in {streetwear_outfit}, standing or crouching in a {pose_description}, positioned {model_position} — partially overlapping the text layers
Important Details: headline "{HEADLINE_TEXT}" in extra-bold condensed {font_style}, {text_color}, occupying upper two-thirds of frame — model breaks in front of some letters and behind others (depth interplay), secondary text "{SUBHEAD_TEXT}" in thin weight {subhead_color} near bottom edge, {lighting_type} on model creating {shadow_quality} shadows, grain overlay across entire image ({grain_intensity}), composition follows rule of thirds with model at {grid_position} intersection
Use Case: streetwear brand drop poster, social media announcement, lookbook cover
Constraints: text must be fully legible even where model overlaps, no extra text or watermarks, no decorative elements besides type and model, model does not obscure more than 30% of any single letter, "{HEADLINE_TEXT}" spelled exactly as provided
Quality: high
```

**Key levers:** `{HEADLINE_TEXT}` (brand name, drop name), `{SUBHEAD_TEXT}` (date, "LIMITED DROP", collection name), `{background_color}` (off-white #F5F1EB, concrete gray #8C8C8C, matte black #0D0D0D), `{text_color}` (#000000, #FF3333, #FFFFFF), `{font_style}` (sans-serif like Druk Wide, slab-serif, stencil), `{streetwear_outfit}`, `{model_position}` (center-left, right third), `{lighting_type}` (harsh direct flash, soft window light), `{grain_intensity}` (subtle film grain, heavy 35mm grain)

**Recommended model:** GPT Image 2 (`quality: high`) — text rendering and model-type depth interplay

---

## Retro Roller Skating Sportswear Campaign

Use for playful, nostalgic sportswear or athleisure campaigns with 70s-80s visual language.

<!-- Source concept: retro roller skating / sportswear campaign with analog film aesthetic -->

A sun-drenched wide shot of {model_description} roller skating along a {location_description}. They wear {outfit_description} — the fabric catches light as they move, one leg extended mid-glide, arms relaxed and swinging naturally. The ground is smooth asphalt with painted lane markings in faded {lane_color}. Background shows {background_elements} slightly out of focus through heat haze. Shot on {film_stock} with pronounced grain and slightly lifted shadows. Color palette centers on {palette_description}. Golden hour backlight creates a warm halo around the subject and long shadow stretching toward camera. Genuine movement energy — hair and loose fabric respond to speed. Format: {aspect_ratio}.

**Key levers:** `{model_description}`, `{outfit_description}` (high-waisted terry shorts in coral, cropped zip-up in cream, tube socks with racing stripes), `{location_description}` (Venice Beach boardwalk, empty suburban tennis court, coastal promenade), `{film_stock}` (Kodak Gold 200, Fuji Superia 400), `{palette_description}` (terracotta #CC5533, cream #FFF5E1, sky blue #87CEEB, mustard #D4A017), `{lane_color}` (faded yellow, sun-bleached white), `{background_elements}` (palm trees and pastel buildings, chain-link fence and bleachers), `{aspect_ratio}` (3:2, 16:9)

**Recommended model:** NB2 — natural movement, analog film grain, atmospheric grounding

---

## Futuristic Sportswear Editorial with 3D Blob Shapes

Use for forward-looking athletic or techwear editorials where abstract 3D forms create a surreal spatial environment around the model.

<!-- Source concept: futuristic sportswear editorial with organic 3D blob/sphere shapes -->

```
Scene: {studio_environment} studio space, matte {floor_color} floor extending to infinity, ambient fill light with no visible source, three to five large organic 3D blob shapes ({blob_color}, glossy smooth surface with environment reflections) floating at varying heights around the subject
Subject: {model_description} in {techwear_outfit}, posed in an athletic stance — {pose_detail}
Important Details: blobs range from basketball-sized to armchair-sized, each with smooth amoebic curves and a single specular highlight, they cast soft colored shadows onto the floor and the model's clothing, model lit by cool directional light from camera-right creating defined muscle/fabric contour, {fabric_detail} visible in the garment construction, one blob partially behind the model and one in front (spatial depth), color palette limited to {palette}, overall mood is clinical and aspirational
Use Case: sportswear lookbook, techwear campaign, editorial magazine spread
Constraints: blobs must look physically present (not composited), no text, no logos, no additional props, model remains the clear focal point despite the surrounding forms, blobs do not touch or intersect with the model's body, no motion blur
```

**Key levers:** `{studio_environment}` (white void, concrete gray, deep navy), `{floor_color}` (light gray #D0D0D0, charcoal #333333), `{blob_color}` (chrome silver, translucent jade #00A86B, matte coral #FF6B6B), `{techwear_outfit}` (bonded seam track pants + compression top, oversized windbreaker + utility shorts), `{pose_detail}` (low lunge position, standing with one arm extended checking a wrist device, mid-jump), `{fabric_detail}` (visible bonded seams, reflective piping, mesh ventilation panels), `{palette}` (monochrome + single accent, earth tones + neon green #39FF14)

**Recommended model:** NBP — complex spatial reasoning for blob placement and reflections

### Nano Banana version:

```
A futuristic sportswear editorial photograph in a {studio_environment} studio space with a matte {floor_color} floor extending to infinity. {model_description} stands in an athletic {pose_detail}, wearing {techwear_outfit} with {fabric_detail}. Three to five large organic 3D blob shapes in {blob_color} with glossy smooth surfaces float at varying heights around the subject — the largest is armchair-sized, the smallest basketball-sized. Each blob has amoebic curves and casts soft colored shadows onto the floor and the model's clothes. Cool directional light from camera-right defines contour and fabric texture. One blob sits partially behind the model, one in front, creating depth. The model is the clear focal point. No text, no logos. Format: 4:5.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/patterns/food-beverage.md

# Food & Beverage Patterns

Reusable prompt templates for food photography, beverage campaigns, and culinary illustration. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Luxury Chocolate Brand Campaign

Use for premium chocolate or confectionery brand visuals — moody, textural, with controlled color and atmosphere. Adaptable across mood variants (dark indulgence, bright artisan, earthy origin-story).

<!-- Source concept: luxury chocolate brand campaign with variant moods and tactile surfaces -->

```
Scene: {surface_material} surface, {lighting_mood} lighting setup — {light_description}, thin atmospheric haze at background edge, color palette restricted to {palette}
Subject: {product_arrangement} — {product_count} pieces of {chocolate_type} arranged in {arrangement_style}
Important Details: visible snap edge on broken piece revealing {interior_texture}, fine cocoa powder dusted across surface (concentrated near product, fading to clean edges), {garnish_elements} placed deliberately as art direction not garnish, one piece mid-break with clean fracture line, surface texture of chocolate shows {surface_quality}, camera angle {camera_angle}, shallow depth of field with sharpest focus on the broken piece
Use Case: luxury chocolate brand campaign, print ad, packaging insert
Constraints: no human hands, no utensils, no wrappers or packaging visible, no text, cocoa dust must look natural not dumped, maximum {product_count} chocolate pieces, no melting

Mood variant — {mood_name}:
{mood_modifier}
```

**Key levers:**
- `{surface_material}` — dark slate, raw walnut wood, black marble, crumpled kraft paper
- `{lighting_mood}` — dramatic chiaroscuro / soft diffused warmth / cold window light
- `{light_description}` — single hard key from upper left / wrap-around softbox / backlit through parchment
- `{palette}` — deep browns #3E2723 + gold #C9A84C + black / warm terracotta #A0522D + cream #FFF8E7 / emerald #2D6A4F + copper #B87333
- `{chocolate_type}` — single-origin dark 72%, white chocolate with matcha veins, ruby chocolate
- `{interior_texture}` — smooth ganache center, crunchy praline layers, salted caramel pocket
- `{garnish_elements}` — single vanilla pod, fleur de sel crystals, edible gold leaf fragments, dried raspberry
- `{arrangement_style}` — diagonal cascade, tight cluster with negative space right, single row
- `{mood_name} / {mood_modifier}` — "Dark Indulgence": push contrast, deepen shadows, add smoke wisp / "Bright Artisan": overcast daylight, lifted blacks, pastel accent / "Origin Story": raw earth tones, burlap texture, raw cacao beans nearby

**Recommended model:** GPT Image 2 (`quality: high`) — fracture detail and cocoa powder precision

---

## High-Fashion Beverage Campaign Board

Use for premium beverage brand campaigns that combine lifestyle and product in a structured board layout — model shot + hero product + product lineup.

<!-- Source concept: fashion-meets-beverage campaign board with model, hero product, and lineup -->

```
Scene: horizontal triptych layout on single canvas — left panel (45% width), center panel (30%), right panel (25%), thin {divider_color} dividers (2px), unified {color_temperature} color temperature
Subject: {beverage_brand} campaign board featuring {model_description} and {product_name}
Important Details:
  Left panel (lifestyle): {model_description} at {location}, holding {product_name} at {hold_position}, {model_action}, shot on {film_aesthetic} — environment tells the brand story
  Center panel (hero): {product_name} bottle/can beauty shot, {product_angle} angle, {product_surface} surface, single key light with {highlight_style}, condensation droplets on glass/can surface, label sharp and legible
  Right panel (lineup): {lineup_count} product variants arranged in a {lineup_arrangement}, same lighting as center panel but pulled back wider, each label variant distinguishable by color ({variant_colors})
  Typography: none in image
Use Case: brand campaign presentation, pitch deck, retail POS
Constraints: model does not look directly at product (natural interaction), product label consistent and legible in all panels, lighting temperature cohesive, no floating elements, condensation looks physical not painted on
```

**Key levers:** `{product_name}`, `{beverage_brand}`, `{model_description}`, `{location}` (sunlit rooftop bar, marble kitchen counter, poolside), `{hold_position}` (mid-sip, resting at hip, gesturing with it), `{model_action}` (laughing mid-conversation, looking off-frame, walking), `{film_aesthetic}` (warm Kodak Portra feel, clean digital, cold editorial), `{product_angle}` (three-quarter front, straight-on, slight low angle), `{product_surface}` (wet dark stone, frosted glass shelf, white marble), `{lineup_count}` (3-5), `{variant_colors}` (amber/ruby/gold, mint/lemon/berry), `{divider_color}` (#FFFFFF, #1A1A1A)

**Recommended model:** GPT Image 2 (`quality: high`) — label legibility and panel consistency

---

## Hyper-Realistic Food Poster Template

Use for hero food posters — restaurants, delivery apps, menu boards — where the food is the entire composition with fillable content slots.

<!-- Source concept: hyper-realistic food poster with controlled composition slots -->

```
Scene: {background_treatment}, {atmosphere_effect}, overall tone {color_tone}
Subject: {dish_name} — {dish_description}, plated on {plate_description}, centered in frame
Important Details:
  Plating: {plating_details}
  Steam/moisture: {steam_detail}
  Garnish: {garnish_detail} placed at {garnish_position}
  Surface: {table_surface}, visible texture extending to frame edges
  Props: {prop_list} — arranged {prop_arrangement}
  Camera: overhead ({overhead_angle}) OR {camera_angle}, {lens_feel}
  Lighting: {food_lighting} — highlights on {highlight_targets}
Use Case: restaurant poster, delivery app hero, menu board, food magazine cover
Constraints: food must look freshly prepared (not cold or sat-out), no human hands or utensils in active use (props only), colors must be appetizing — no blue cast, no desaturated tones on the food itself, {plate_description} must not compete with the dish
```

**Key levers:**
- `{dish_name}` / `{dish_description}` — the hero food item described in appetizing physical detail
- `{plate_description}` — matte white ceramic, dark stoneware, rustic wooden board, banana leaf
- `{plating_details}` — sauce swoosh from 2 o'clock, microgreens at 10 o'clock, sesame seed scatter
- `{steam_detail}` — visible steam wisps rising from center, condensation on glass nearby, no steam
- `{garnish_detail}` — single basil sprig, chili flake scatter, citrus zest curls
- `{table_surface}` — aged oak, dark concrete, white marble with gray veins
- `{prop_list}` — linen napkin, vintage fork, small bowl of sauce, scattered herbs
- `{food_lighting}` — warm directional from upper-left with fill bounce, harsh noon daylight, moody side light
- `{background_treatment}` — dark vignette, clean bright, rustic blur
- `{camera_angle}` — 45-degree three-quarter, straight-on eye-level, overhead flat-lay

**Recommended model:** GPT Image 2 (`quality: high`) — steam, condensation, and ingredient texture fidelity

---

## Naturalist Food Specimen Cross-Section

Use for educational food content, ingredient features, or artisanal brand storytelling — the food item rendered as a scientific illustration in the style of 19th-century naturalist prints.

<!-- Source concept: Audubon-style naturalist botanical/food specimen illustration with cross-section -->

A detailed naturalist illustration of {food_item} rendered in the style of 19th-century scientific specimen plates. The composition shows the item in three states arranged vertically on an aged {paper_color} parchment background: whole specimen at top with botanical accuracy, lateral cross-section at center revealing internal structure ({internal_details}), and an exploded detail of {detail_element} at bottom with fine ink annotation lines pointing to key features. Drawn with precise {medium_description} — visible hatching for shadow, stippling for texture, thin ink outlines. Color is naturalistic but slightly muted as if from a hand-tinted lithograph. A thin decorative border frames the composition. Small italic Latin-style label "{latin_label}" at the bottom in serif font, {ink_color} ink. Format: 3:4.

**Key levers:** `{food_item}` (pomegranate, sourdough loaf, wagyu ribeye, cacao pod), `{internal_details}` (seed chambers with ruby arils, crumb structure with irregular air pockets, marbling fat distribution), `{detail_element}` (individual seed anatomy, crust layering, fat crystal structure), `{paper_color}` (warm cream #FDF5E6, cool ivory #FFFFF0), `{medium_description}` (watercolor wash with ink line, graphite with colored pencil, pure ink with minimal color), `{latin_label}` (a playful Latinized name), `{ink_color}` (sepia #704214, India black #1A1A1A)

**Recommended model:** NB2 — naturalist illustration style, grounding on botanical plate aesthetics

---

## City Food Map Illustration

Use for restaurant guides, food festival materials, travel content, or local cuisine features — a bird's-eye illustrated map showing food specialties across a city.

<!-- Source concept: hand-drawn illustrated food map of a city with dish icons and landmarks -->

A hand-drawn illustrated bird's-eye map of {city_name} showing its food culture. The map covers the {area_description} with simplified but recognizable {landmark_list} drawn in a loose ink-and-watercolor style. Scattered across the map are {dish_count} illustrated food items representing local specialties — each dish ({dish_list}) drawn at exaggerated scale hovering near its neighborhood, rendered in warm appetizing watercolor with visible brushstrokes. Streets are thin ink lines with {street_style}. Water features rendered in soft {water_color} wash. The overall palette is {palette_description}. A decorative hand-lettered title "{MAP_TITLE}" sits in a banner at the top. Small hand-written labels mark each dish and neighborhood. Style references vintage travel poster illustration meets editorial food drawing. Format: {aspect_ratio}.

**Key levers:** `{city_name}`, `{area_description}` (central 5 km, old town quarter, waterfront district), `{landmark_list}` (main cathedral, central market, river bridges), `{dish_count}` (6-10), `{dish_list}` (plov near the bazaar, samsa near the old town, shashlik near the park), `{street_style}` (slightly wobbly freehand, clean but simplified), `{water_color}` (cerulean #0077B6, teal #2A9D8F), `{palette_description}` (warm terracotta and cream with food items in full saturated color, cool blues and greens with warm food accents), `{MAP_TITLE}` ("A Taster's Guide to {city_name}"), `{aspect_ratio}` (3:4, 1:1)

**Recommended model:** NB2 — image grounding for real city landmarks + illustration style

### Nano Banana version:

```
A hand-drawn illustrated bird's-eye food map of {city_name}, covering the {area_description}. Simplified but recognizable {landmark_list} are drawn in loose ink-and-watercolor style. {dish_count} local dishes ({dish_list}) float at exaggerated scale near their neighborhoods, each painted in warm appetizing watercolor with visible brushstrokes. Streets are thin freehand ink lines. Water features in soft {water_color} wash. A hand-lettered banner at top reads "{MAP_TITLE}". Small hand-written labels mark dishes and neighborhoods. Style mixes vintage travel poster illustration with editorial food drawing. Palette: {palette_description}. Format: {aspect_ratio}.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/patterns/portrait-cinema.md

# Portrait & Cinema Patterns

Reusable prompt templates for cinematic portraits, atmospheric character photography, and mood-driven portraiture. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Golden Hour Street Backlit Portrait

Use for warm, emotive street portraits with strong backlight flare — editorial, personal branding, album covers.

<!-- Source concept: golden hour backlit street portrait with lens flare and warm atmospheric haze -->

```
Scene: {street_description} at golden hour, sun positioned directly behind subject (5-10 degrees above horizon line), warm amber light flooding the street, slight atmospheric haze diffusing the backlight
Subject: {person_description}, standing at {position_in_street}, body angled three-quarter to camera, face turned toward lens with {expression}
Important Details: strong rim light outlining hair and shoulders in warm gold (#FFAA33), face lit primarily by bounce light from {bounce_surface} on the opposite side — softer and cooler than the backlight, shallow depth of field rendering background into warm bokeh circles, {clothing_detail} catches backlight along edges showing fabric texture, visible lens flare — one or two hexagonal flare artifacts near frame edge (organic, not excessive), long shadow cast toward camera on {ground_surface}, skin rendered naturally with warm undertones — no heavy smoothing, visible pores, {color_grade}
Use Case: editorial portrait, personal brand photography, album art
Constraints: face must be visible and well-exposed despite backlight (not silhouetted), no reflectors or studio equipment visible, lens flare limited to one or two subtle artifacts — not a starburst explosion, no added text, no vignette
```

**Key levers:** `{street_description}` (narrow European alley with stone walls, wide boulevard with linden trees, industrial backstreet with brick), `{person_description}`, `{expression}` (quiet confidence, mid-smile with closed lips, contemplative gaze), `{bounce_surface}` (cream-painted wall, parked white van, sand-colored buildings), `{clothing_detail}` (linen shirt collar, leather jacket shoulder seam, scarf edge), `{ground_surface}` (wet cobblestones, dry asphalt, packed earth), `{color_grade}` (Kodak Portra 400 warmth, slightly lifted blacks with amber cast, clean digital with warm white balance)

**Recommended model:** GPT Image 2 — backlight exposure control and skin rendering

---

## Convenience Store Neon Portrait

Use for urban night portraits with mixed artificial lighting — fluorescent overhead + colored neon signage creating a chromatic push-pull on the subject's face.

<!-- Source concept: convenience store / bodega neon portrait — fluorescent + neon mixed light on face -->

```
Scene: exterior of a {store_type} at night, shot through or near the front window/entrance, overhead fluorescent tubes casting flat {fluorescent_color} light from inside, {neon_sign_description} mounted on the wall/window casting {neon_color} glow on one side of the subject's face
Subject: {person_description}, {pose_description}, positioned at the threshold between interior fluorescent zone and exterior neon zone — split lighting across the face
Important Details: face receives {fluorescent_color} fill from the store interior on one side and {neon_color} accent from signage on the other — the two colors mix on the nose bridge and chin, visible product shelves or cooler glow softly in background bokeh, {clothing_description} absorbs and reflects the two light sources differently, condensation or grime on window glass if shot through it (subtle, not obscuring), wet pavement outside reflects both light sources in streaks, shallow depth of field with subject sharp, background a mosaic of colored bokeh, {camera_feel}
Use Case: urban editorial, music press portrait, fashion story, short film still
Constraints: face clearly visible — neither light source blows out features, neon sign text (if present) is secondary to the portrait not the focal point, no additional light sources beyond what exists in the scene, no heavy color grading beyond what the practical lights create naturally, no motion blur
```

**Key levers:** `{store_type}` (Korean convenience store, bodega, late-night pharmacy, 24-hour laundromat), `{fluorescent_color}` (cool blue-white, greenish-white, warm tungsten), `{neon_sign_description}` (red "OPEN" sign, blue beer brand logo, pink cursive word), `{neon_color}` (red #FF2D2D, blue #3366FF, pink #FF69B4, green #39FF14), `{person_description}`, `{pose_description}` (leaning against door frame, sitting on overturned crate, standing with hands in pockets), `{clothing_description}` (dark hoodie that absorbs light, white t-shirt that bounces both colors, leather that reflects), `{camera_feel}` (Cinestill 800T with halation around neon, clean digital night, Fujifilm color science)

**Recommended model:** GPT Image 2 (`quality: high`) — precise dual-light color rendering on skin

---

## Monochrome Glitch Profile Portrait

Use for edgy, tech-forward portraits — artist profiles, electronic music press, tech brand campaigns. High contrast black-and-white with selective red digital artifacts.

<!-- Source concept: monochrome profile portrait with digital glitch artifacts and red accent color -->

```
Scene: pure black background (#000000), no environment — subject emerges from darkness
Subject: {person_description} in sharp profile (facing {direction}), head and upper shoulders only, high-contrast black-and-white rendering
Important Details: extreme contrast — skin highlights blow to near-white, shadows fall to pure black with minimal midtone graduation, {hair_detail} silhouetted against black, one eye visible in profile with a single catchlight, horizontal glitch displacement lines cutting across the image at {glitch_positions} — each line offsets a thin horizontal slice (4-8px) to the right by 10-20px, the displaced slices rendered in {accent_color} (#FF0000 default) while the rest remains monochrome, fine horizontal scan lines across entire image (subtle, CRT monitor texture), grain: heavy high-ISO film grain throughout, jaw line and nose bridge are the sharpest elements in frame
Use Case: artist press photo, electronic music EP cover, tech brand portrait, social media profile
Constraints: glitch lines must look digital (clean horizontal displacement, not organic), accent color appears ONLY in the displaced glitch slices — no other colored elements, maximum {max_glitch_lines} glitch lines to avoid visual noise, face must remain recognizable despite artifacts, no text, background is solid black — no gradient or texture
```

**Key levers:** `{person_description}`, `{direction}` (left, right), `{hair_detail}` (tight buzz cut showing skull contour, shoulder-length hair with flyaway strands catching backlight, pulled-back bun), `{glitch_positions}` (across the eye, across the mouth, across the forehead — specify 2-3 positions), `{accent_color}` (#FF0000 red, #00FF41 terminal green, #FF00FF magenta), `{max_glitch_lines}` (3-5)

**Recommended model:** GPT Image 2 — high-contrast mono rendering and controlled glitch placement

---

## Japanese Negative Film Rooftop Portrait

Use for moody, atmospheric portraits with overexposed analog film qualities — muted colors, lifted shadows, and a feeling of faded memory. Ideal for editorial, zine, or personal project work.

<!-- Source concept: Japanese negative film aesthetic — overexposed, muted tones, rooftop setting -->

A waist-up portrait of {person_description} on a {rooftop_description}. They stand near the edge railing, {pose_description}, with the {city_skyline} visible behind them but washed out and desaturated by {sky_condition}. Shot on expired Japanese negative film — colors shifted toward {color_shift}, highlights blown soft and chalky, shadows lifted with visible grain in the flat midtones. Skin tones slightly green-yellow as if the film has aged. {clothing_description} reads as muted tones, almost monochromatic against the overexposed sky. Wind moves {wind_detail}. The mood is nostalgic and transient — a memory captured on deteriorating film stock. Eye-level framing, subject slightly off-center toward {frame_position}. Format: {aspect_ratio}.

**Key levers:** `{person_description}`, `{rooftop_description}` (concrete apartment building rooftop, industrial warehouse roof with exhaust vents, school building roof with chain-link fence), `{pose_description}` (leaning on railing looking at camera, turned away looking at skyline, sitting on a ledge with knees drawn up), `{city_skyline}` (Tokyo mid-rise apartments, generic Asian city with power lines), `{sky_condition}` (overcast white sky, hazy afternoon sun), `{color_shift}` (green-cyan cast, yellow-amber cast), `{clothing_description}` (oversized vintage windbreaker, plain white t-shirt, navy work jacket), `{wind_detail}` (hair across face, jacket hem, collar), `{frame_position}` (left third, right third), `{aspect_ratio}` (3:2, 4:5)

**Recommended model:** NB2 — analog film grain emulation and atmospheric mood

---

## Dreamy Underwater Surreal Portrait

Use for beauty campaigns, conceptual art, or album visuals — a portrait where the subject floats in clear water surrounded by translucent aquatic elements.

<!-- Source concept: surreal underwater portrait with translucent fish and dreamy caustic light -->

```
Scene: clear {water_color} water filling the entire frame, caustic light patterns rippling across the subject from above (sunlight through water surface), no visible pool walls or floor — infinite aquatic void
Subject: {person_description}, floating in a relaxed {pose_description}, eyes {eye_state}, hair fanning out in all directions as if weightless, {clothing_description} billowing and suspended in the water
Important Details: {fish_count} translucent {fish_type} swimming in a loose school around the subject — each fish semi-transparent with visible skeletal structure and iridescent scales catching the caustic light, light rays penetrating from above in {light_pattern}, fine air bubbles rising from near the subject's {bubble_source}, fabric of clothing moves independently from the body — folds and hems suspended in mid-drift, skin has a subtle cool {water_tint} cast from the water, overall palette is {palette}, composition framed as a {shot_type}
Use Case: beauty campaign, album cover, conceptual art print, fashion editorial
Constraints: subject's face must be clearly visible and serene (not distressed or holding breath with effort), fish are translucent — not solid opaque tropical fish, no visible water surface edge or pool tiles, no scuba gear or goggles, bubbles are small and delicate not large air pockets, underwater physics must be consistent (everything floats)
```

**Key levers:** `{water_color}` (deep cerulean #0077B6, pale turquoise #AFEEEE, dark teal #004D4D), `{person_description}`, `{pose_description}` (arms slightly outstretched like a slow free-fall, curled fetal position, one arm reaching upward toward the light), `{eye_state}` (softly closed, open and gazing upward at the light, looking directly at camera), `{clothing_description}` (flowing white silk dress, loose linen shirt and trousers, sheer organza wrap), `{fish_count}` (5-8), `{fish_type}` (jellyfish, small reef fish, elongated glass catfish), `{light_pattern}` (parallel god rays from upper right, scattered dappled caustics, single concentrated beam), `{bubble_source}` (lips, fingertips, fabric edges), `{water_tint}` (blue-green, aquamarine), `{palette}` (teal and ivory, deep blue and gold, seafoam and blush), `{shot_type}` (full body vertical, waist-up centered, three-quarter with negative space below)

**Recommended model:** NBP — complex physics (floating hair, fabric, fish transparency, caustic light)

### Nano Banana version:

```
A surreal underwater portrait of {person_description} floating in a relaxed {pose_description} in clear {water_color} water. Eyes {eye_state}, hair fans out weightlessly in all directions. {clothing_description} billows and suspends in the current, folds drifting independently. {fish_count} translucent {fish_type} swim in a loose school around the subject — each semi-transparent with visible skeletal structure and iridescent scales catching caustic light from above. Sunlight penetrates from the surface in {light_pattern}, casting rippling patterns across skin and fabric. Fine air bubbles rise from the subject's {bubble_source}. Skin has a subtle cool {water_tint} cast. No pool walls, no surface edge visible — infinite aquatic void. Serene and dreamlike. Palette: {palette}. Format: 4:5.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/patterns/poster-illustration.md

# Poster & Illustration Patterns

Reusable prompt templates for posters, art prints, campaign collages, and graphic illustrations. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## City Across Two Centuries (Time-Split Composition)

Use for urban development campaigns, anniversary materials, cultural exhibitions, or editorial features — a single city view divided down the middle, one half historical and one half modern.

<!-- Source concept: time-split composition — same city view, two eras side by side -->

```
Scene: wide establishing shot of {city_landmark_view}, frame divided vertically down the center — left half shows the scene in {historical_era}, right half shows {modern_era}
Subject: the same geographic viewpoint across two time periods, architecture and infrastructure transforming at the dividing line
Important Details:
  Left half ({historical_era}): {historical_details} — muted {historical_palette} palette, {historical_atmosphere}, period-accurate architecture, {historical_figures} going about daily life, {historical_transport}
  Right half ({modern_era}): {modern_details} — {modern_palette} palette, {modern_atmosphere}, contemporary architecture where old buildings once stood (some landmarks preserved), {modern_figures}, {modern_transport}
  Dividing line: not a hard cut — elements morph and blend across a narrow 5% transition zone (a horse-drawn cart becomes a car, a gas lamp becomes LED, cobblestones become asphalt, a tree grows taller)
  Sky transitions too: {historical_sky} on left to {modern_sky} on right
  Camera angle: elevated three-quarter view (roughly 30 degrees above street level) to show depth of both eras
Use Case: city anniversary campaign, urban development feature, cultural exhibition poster, editorial illustration
Constraints: both halves must depict the SAME geographic location (matching terrain, river, hill positions), transition zone should feel organic not pasted, scale and perspective consistent across both halves, no text unless specified, no anachronistic elements (modern items in historical half or vice versa outside the transition)
```

**Key levers:** `{city_landmark_view}` (view down the main avenue toward the central square, riverfront panorama, view from the hill overlooking the old town), `{historical_era}` / `{modern_era}` (1920s / 2020s, medieval / present day, 1960s / 2060s), `{historical_details}` (cobblestone streets, horse-drawn carts, hand-painted shop signs), `{modern_details}` (glass facades, rooftop gardens, digital signage), `{historical_palette}` (sepia and desaturated earth tones, hand-colored photograph quality), `{modern_palette}` (clean contemporary color, cooler blue-grays with warm accent), `{historical_atmosphere}` (coal haze, soft morning fog), `{modern_atmosphere}` (clear sky, light pollution glow at horizon), `{historical_sky}` (warm overcast), `{modern_sky}` (clear gradient blue)

**Recommended model:** NBP — spatial reasoning for architectural morphing and perspective consistency

### Nano Banana version:

```
A wide elevated view of {city_landmark_view}, divided vertically down the center into two eras. The left half depicts the scene in {historical_era}: {historical_details}, rendered in a muted {historical_palette} palette with {historical_atmosphere}. The right half shows {modern_era}: {modern_details} in a {modern_palette} palette under {modern_atmosphere}. At the center dividing line, elements morph organically across a narrow transition zone — a horse-drawn cart becomes a car, gas lamps become LED lights, cobblestones blend into asphalt, trees grow taller. The sky transitions from {historical_sky} on the left to {modern_sky} on the right. Both halves share the same geographic terrain and perspective. Camera angle roughly 30 degrees above street level. Format: 16:9.
```

---

## Fitness Boxing Campaign Collage

Use for sport and fitness brand campaigns — a dynamic 3-panel collage combining action, detail, and atmosphere around a boxing/combat sport theme.

<!-- Source concept: 3-panel fitness/boxing campaign collage with action and detail shots -->

```
Scene: three-panel horizontal collage on {canvas_color} canvas — left panel (35%), center panel (40%), right panel (25%), {divider_style} dividers, unified {overall_tone} color tone
Subject: {athlete_description} in a boxing/training context — same person across all panels
Important Details:
  Left panel (environment): wide shot of {gym_environment}, atmospheric — {atmosphere_detail}, equipment visible but out of focus, {athlete_description} as a silhouette or distant figure warming up, mood: anticipation
  Center panel (action): medium shot, {athlete_description} mid-{action_type}, captured at peak effort — {action_detail}, sweat visible on skin and {gear_description}, sharp focus on face showing {expression}, directional hard light from {light_direction} creating dramatic shadow on the opposite side of the face, slight motion trail on the {moving_element}
  Right panel (detail): extreme close-up of {detail_subject} — {detail_description}, texture dominates the frame, {detail_lighting}
  Grain: uniform {grain_level} across all panels
  Color: {color_treatment}
Use Case: fitness brand campaign, gym poster, sportswear ad, magazine editorial spread
Constraints: same athlete across all panels (consistent identity, gear, wraps), no text or logos, no sponsor branding, center panel is the visual anchor — should feel like the decisive moment, grain must be uniform not just added to one panel
```

**Key levers:** `{athlete_description}`, `{gym_environment}` (industrial boxing gym with heavy bags, outdoor concrete training yard, dimly lit basement ring), `{atmosphere_detail}` (chalk dust in backlight, steam from breath in cold air, golden light through high windows), `{action_type}` (throwing a cross, landing a hook on a heavy bag, rope-skipping), `{action_detail}` (fist connecting with bag creating visible impact ripple, rope frozen in arc above head), `{gear_description}` (red hand wraps, worn leather gloves, no gloves — taped knuckles), `{expression}` (focused intensity, controlled exhale, battle cry), `{detail_subject}` (taped knuckles against red canvas, worn boxing boot laces, sweat dripping from chin onto canvas), `{detail_description}` (each tape fiber visible, leather cracking at flex points, individual droplets mid-fall), `{color_treatment}` (desaturated with warm midtones, high-contrast monochrome with sepia, teal-and-orange split tone), `{canvas_color}` (matte black #0D0D0D, dark charcoal #1A1A1A), `{divider_style}` (thin white 2px, no dividers — edge bleed)

**Recommended model:** GPT Image 2 — identity consistency across panels and sweat/texture detail

---

## Lavender Smartphone Hero Ad

Use for tech product launch visuals — clean, color-dominant hero shots where a smartphone (or similar device) floats against a monochromatic gradient with soft 3D accent elements.

<!-- Source concept: smartphone product launch hero in monochromatic lavender with floating accent shapes -->

```
Scene: smooth gradient background from {color_light} to {color_dark}, no hard edges, studio void environment
Subject: {device_name} floating at slight {tilt_angle}-degree angle, screen facing camera showing {screen_content}, centered vertically but offset {horizontal_position} horizontally
Important Details: device renders with physically accurate {device_finish} — visible edge chamfer catching a thin highlight line, screen content crisp and legible at this scale, {accent_element_count} soft 3D shapes floating nearby (matte {accent_shape_color} {accent_shapes} — frosted glass or soft plastic appearance, each {accent_size}), shapes are out of focus at varying depths creating a layered composition, soft omnidirectional lighting with a subtle key from upper-left, gentle device shadow projected onto the gradient ({shadow_softness}), overall color palette stays within the {color_family} family — no complementary or clashing tones
  Bottom text area: "{HEADLINE}" in {headline_weight} {headline_font_style}, {headline_color}, centered below device
  Subtext: "{SUBHEADLINE}" in thin weight, {subtext_color}, below headline
Use Case: product launch hero, website header, retail POS, digital ad
Constraints: screen content must be sharp and readable, floating shapes must not obscure the device screen, no reflections of a studio environment on screen, gradient is smooth — no banding, device proportions must match a real smartphone (no stretched or squished body), text exactly as quoted
Quality: high
```

**Key levers:** `{device_name}`, `{color_light}` / `{color_dark}` (lavender #E6D5F5 to #7B4FA0, mint #D0F0E0 to #1B7A5A, coral #FFDDD2 to #C44536), `{device_finish}` (matte aluminum, polished titanium, frosted glass back), `{screen_content}` (a clean home screen with app icons, a camera app showing a landscape, a gradient wallpaper), `{accent_shapes}` (spheres, rounded pills, soft cubes, torus rings), `{accent_shape_color}` — same family as background but slightly lighter or more saturated, `{accent_size}` (golf-ball to grapefruit), `{HEADLINE}` / `{SUBHEADLINE}`, `{headline_color}` (white #FFFFFF, dark tint of the color family), `{color_family}` (lavender-purple, sage-green, warm terracotta), `{tilt_angle}` (5-15), `{horizontal_position}` (left third, center, right third)

**Recommended model:** GPT Image 2 (`quality: high`) — text rendering, screen content legibility, device accuracy

---

## Emerald Street Fashion Poster

Use for fashion drops, event announcements, or editorial magazine covers where bold typography and a street fashion figure share equal visual weight on a saturated color field.

<!-- Source concept: bold emerald fashion poster with oversized type and street style figure -->

```
Scene: solid {background_color} background (flat, no gradient), graphic poster composition split between typography (upper 55%) and figure (lower 60%, overlapping into the type zone)
Subject: {model_description} in {outfit_description}, full-body shot from low angle (worm's eye, approximately 15 degrees below eye level), standing with {pose_description}
Important Details: "{MAIN_TITLE}" in extra-bold extended {title_font_style}, {title_color}, filling the upper half — each letter approximately 20% of frame height, model's head and shoulders break in front of the bottom row of letters (depth layering), "{SUBTITLE}" in lightweight condensed type, {subtitle_color}, running along the bottom edge or lower-right corner, model lit by overcast flat light — even exposure, minimal shadow, fabric textures fully readable ({fabric_details}), shoes visible and grounded (not floating), {graphic_accents} if any
Use Case: fashion brand poster, event flyer, editorial magazine cover, retail window display
Constraints: title text fully legible — model overlap must not obscure more than one letter by more than 40%, no additional decorative elements unless specified in {graphic_accents}, background is flat solid color — no texture or pattern, "{MAIN_TITLE}" and "{SUBTITLE}" spelled exactly as given, model does not hold props unless specified
Quality: high
```

**Key levers:** `{background_color}` (emerald #006B3F, cobalt #0047AB, saffron #F4C430, hot pink #FF1493), `{model_description}`, `{outfit_description}` (oversized leather trench + chunky sneakers, cropped bomber + wide-leg trousers + platform boots), `{pose_description}` (wide stance with arms crossed, one hand adjusting collar, walking stride caught mid-step), `{MAIN_TITLE}` / `{SUBTITLE}`, `{title_font_style}` (geometric sans-serif, grotesque, stencil cut), `{title_color}` (#FFFFFF, #000000, cream #FFF5E1), `{subtitle_color}` (same as title but at 60% opacity), `{fabric_details}` (visible grain in leather, corduroy ridges, denim selvedge edge), `{graphic_accents}` (none, thin white border 20px from edge, small logo mark at bottom-left)

**Recommended model:** GPT Image 2 (`quality: high`) — typography rendering and figure-type layering

---

## Peacock Botanical Vintage Art Print

Use for decorative prints, packaging illustration, wallpaper design, or editorial art — a symmetrical composition combining a peacock with botanical elements in a vintage printmaking style.

<!-- Source concept: peacock botanical vintage symmetrical art print — ornamental and decorative -->

A symmetrical ornamental art print centered on a {peacock_variant} peacock in full tail display, viewed from {view_angle}. The tail feathers fan into a perfect semicircle filling the upper two-thirds of the frame, each eye-spot rendered with precise detail — iridescent {eye_colors} with fine barb texture. The peacock stands on a {base_element} at the composition's center axis. Flanking the bird symmetrically: {botanical_left} on the left mirrored by {botanical_right} on the right — leaves, stems, and blossoms curve inward framing the peacock. {additional_fauna} perch or fly near the upper corners. The entire composition sits on a {background_texture} background in {background_color}. Rendering style: {print_style} — visible {technique_marks}, rich but slightly flattened color as if from layered printing passes. Border: {border_style}. Color palette: {palette}. Format: 3:4.

**Key levers:** `{peacock_variant}` (Indian blue, white albino, green Java), `{view_angle}` (front-facing straight on, three-quarter turning left), `{eye_colors}` (deep blue #003366 and emerald #006B3F and gold #C9A84C, monochrome — all in shades of navy and silver), `{base_element}` (ornate stone pedestal, flowering branch, decorative tile floor), `{botanical_left}` / `{botanical_right}` (magnolia branches, trailing wisteria, passion flower vines, banksia stems), `{additional_fauna}` (two small butterflies, a dragonfly pair, none), `{background_texture}` / `{background_color}` (aged linen #F5F0E1, dark navy #0A1628, cream parchment #FDF5E6), `{print_style}` (hand-colored etching, woodblock print, chromolithograph), `{technique_marks}` (cross-hatching in shadows, visible plate tone, registration marks at corners), `{border_style}` (thin double-line art nouveau border, ornamental corner flourishes, simple single-line rectangle), `{palette}` (natural jewel tones — emerald, sapphire, gold on cream / limited three-color palette — teal, copper, black on ivory / muted earth tones — sage, terracotta, umber)

**Recommended model:** NB2 — image grounding for accurate peacock anatomy and botanical species

### Nano Banana version:

```
A symmetrical ornamental art print centered on a {peacock_variant} peacock in full tail display, viewed {view_angle}. Tail feathers fan into a perfect semicircle filling the upper two-thirds, each eye-spot rendered with iridescent {eye_colors} and fine barb texture. The peacock stands on a {base_element}. Flanking it symmetrically: {botanical_left} on the left mirrored by {botanical_right} on the right, stems and blossoms curving inward to frame the bird. {additional_fauna} near the upper corners. Background: {background_texture} in {background_color}. Style: {print_style} with visible {technique_marks} and slightly flattened color as from layered printing passes. Border: {border_style}. Palette: {palette}. Format: 3:4.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/patterns/ui-social.md

# UI Mockups & Social Media Patterns

Reusable prompt templates for social media ads, app store assets, dashboard mockups, and visual analysis boards. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Instagram Story Ad (9:16)

Use for vertical product or brand ads targeting Instagram Stories — hero product, bold headline, and swipe-up CTA zone at the bottom.

<!-- Source concept: Instagram Story ad with glassmorphism elements and gradient background -->

```
Scene: vertical 9:16 canvas, smooth gradient background from {gradient_top} to {gradient_bottom}, soft ambient glow behind the product
Subject: {product_name} — {product_description} — centered in the upper two-thirds of the frame, angled slightly for dimension
Important Details: two glassmorphism panels (frosted translucent white, 20% opacity, subtle border highlight at #FFFFFF30) flanking the product — one floating left, one floating right, slightly rotated, adding depth layers. Bold headline "{headline_text}" in {headline_font} at the top third, white or light-colored text with subtle drop shadow for readability. Small subtext "{subtext}" below the headline in lighter weight. Bottom 15% of canvas left as swipe-up CTA zone — thin upward-pointing chevron icon and "{cta_text}" in small caps, both in white. Product casts a soft colored shadow matching the gradient onto the background. Scattered {accent_elements} (glass spheres, soft bokeh circles, translucent geometric shapes) at 10-15% opacity for texture.
Use Case: Instagram Story ad, vertical social media placement, mobile-first brand campaign
Constraints: text must be legible on mobile screens (minimum visual weight), no text in the bottom 5% (system UI overlap zone), product must be the clear focal point, no more than 3 accent elements, glassmorphism panels must not obscure the product
```

**Key levers:** `{product_name}`, `{product_description}` (shape, material, color), `{gradient_top}` / `{gradient_bottom}` (e.g. #6C3CE1 violet to #1A1A2E dark navy, #FF6B6B coral to #FFE66D warm yellow), `{headline_text}`, `{headline_font}` (bold condensed sans-serif, rounded geometric), `{subtext}`, `{cta_text}` (e.g. "Swipe Up", "Shop Now", "Learn More"), `{accent_elements}` (translucent spheres, soft light flares, floating geometric shards)

**Recommended model:** GPT Image 2 (`quality: high`) — headline text legibility and glassmorphism transparency effects need precision

---

## Social Media Feed Post (1:1)

Use for square-format posts on Instagram or Facebook — quote cards, feature announcements, or product highlights with centered layout.

<!-- Source concept: square social media post with brand color palette and centered typography -->

```
Scene: square 1:1 canvas, solid or subtle textured background in {bg_color}, clean centered composition
Subject: {post_type} — {content_description}
Important Details:
  Background: {bg_treatment} (solid color, subtle noise texture at 3% opacity, or soft radial gradient from {bg_color} center to slightly darker edges)
  Primary text: "{primary_text}" in {primary_font}, {text_color}, centered horizontally, positioned in the upper half with comfortable margins (at least 10% padding from edges)
  Supporting element: {supporting_element} — positioned below the primary text, providing visual weight and context
  Brand strip: thin horizontal line or subtle divider in {accent_color} separating the primary content from a bottom section containing "{brand_name}" in small caps and {brand_mark} (logo mark or wordmark)
  Overall palette restricted to {palette} — no colors outside this set
  Text sized for legibility at phone-screen scale — primary text large enough to read in a thumbnail feed scroll
Use Case: Instagram feed post, Facebook post, LinkedIn visual, social media content calendar
Constraints: all text must remain legible at 320px display width, no decorative elements that compete with the message, centered balanced layout, no more than two type sizes (headline + body or headline + brand), background must not reduce text contrast below WCAG AA
```

**Key levers:** `{post_type}` (quote card, product feature, announcement, stat highlight), `{content_description}`, `{primary_text}`, `{primary_font}` (geometric sans-serif, modern serif, handwritten accent), `{text_color}` (#FFFFFF on dark, #1A1A1A on light), `{bg_color}` / `{bg_treatment}`, `{accent_color}`, `{brand_name}`, `{brand_mark}`, `{palette}` (e.g. navy #1B2A4A, gold #C9A84C, white #FFFFFF), `{supporting_element}` (product photo, icon illustration, data number in large type)

**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout; legibility at small sizes is critical

---

## App Store Screenshot

Use to create a polished App Store or Google Play listing screenshot — device frame with app UI inside, feature headline, and clean gradient background.

<!-- Source concept: App Store marketing screenshot with iPhone device frame and feature callout -->

```
Scene: vertical canvas, smooth gradient background from {gradient_top} to {gradient_bottom}, centered composition
Subject: {device_type} device frame displaying {app_name} UI — {screen_description}
Important Details:
  Device: realistic {device_type} bezel (space black / silver / natural titanium) with accurate corner radius and button placement, screen showing {screen_content} with proper iOS/Android status bar at top
  Headline: "{feature_headline}" in bold {headline_font}, positioned {headline_position} the device frame, {headline_color} text, 2-3 words maximum per line for impact
  Optional subheadline: "{subheadline}" in lighter weight below the headline, 60% opacity of headline color
  Device shadow: soft diffused shadow below the device, matching the gradient color (not pure black)
  Screen UI: {ui_description} — realistic interface elements with proper spacing, {ui_style} design system, readable text within the screen (even if small)
  Device centered vertically with equal breathing room above and below
Use Case: App Store product page, Google Play listing, app marketing material
Constraints: device bezel must look physically accurate (not a flat rectangle), screen content must be realistic and internally consistent UI (not random shapes), headline text must not overlap the device, gradient background only — no patterns or photos behind the device, one device only
```

**Key levers:** `{device_type}` (iPhone 16 Pro, Pixel 9, Galaxy S25), `{app_name}`, `{screen_description}` (brief: what the screen shows), `{screen_content}` / `{ui_description}` (detailed: specific UI elements visible), `{ui_style}` (iOS native, Material 3, custom dark theme), `{feature_headline}`, `{headline_font}` (SF Pro Display, condensed geometric), `{headline_position}` (above, below), `{headline_color}`, `{subheadline}`, `{gradient_top}` / `{gradient_bottom}` (e.g. #1A1A2E to #0D0D1A for dark, #F0F4FF to #FFFFFF for light)

**Recommended model:** GPT Image 2 (`quality: high`) — device bezel precision, small UI text, and headline legibility all demand high quality

---

## Dashboard Design Mockup

Use for realistic analytics dashboard mockups — dark or light theme with data visualizations, KPI cards, and sidebar navigation.

<!-- Source concept: analytics dashboard UI mockup with charts, cards, and navigation -->

```
Scene: full-screen desktop UI mockup, {theme_mode} theme, clean {design_system} design system
Subject: {dashboard_title} — analytics dashboard showing {data_domain} metrics
Important Details:
  Sidebar (left, 220px visual width): dark ({sidebar_bg}) vertical navigation with icon + label pairs for {nav_items}, active item highlighted with {accent_color} left border and slightly lighter background, collapsed user avatar and app logo at top
  Top bar: breadcrumb or page title "{page_title}" in medium weight, date range selector showing "{date_range}", notification bell icon with dot indicator
  KPI row (top of main area): {num_kpis} metric cards in a horizontal row — each card shows metric name in small caps, large number value, and a small trend indicator (green upward arrow or red downward arrow with percentage), card background {card_bg}
  Chart area (main): {chart_layout}
    Chart 1: {chart_1_type} showing {chart_1_data} — using {chart_1_colors}
    Chart 2: {chart_2_type} showing {chart_2_data} — using {chart_2_colors}
  Secondary section: {secondary_widget} (data table with alternating row colors, recent activity feed, or geographic heat map)
  Proper visual hierarchy — KPI numbers largest, chart labels smaller, navigation text smallest
  Realistic data values throughout — no placeholder "lorem ipsum" or obviously fake numbers
Use Case: SaaS product marketing, investor deck, UI/UX portfolio, feature specification
Constraints: data must look plausible (proper scales, reasonable percentages, formatted numbers), charts must use proper axes and labels, no overlapping UI elements, sidebar must not bleed into main content, {theme_mode} theme applied consistently — no mixing dark sidebar with light charts unless intentional
```

**Key levers:** `{theme_mode}` (dark / light), `{design_system}` (minimal flat, glassmorphism cards, shadowed Material), `{dashboard_title}`, `{data_domain}` (SaaS revenue, e-commerce orders, marketing campaign, IoT sensor monitoring), `{sidebar_bg}` (#0F1117 dark, #FFFFFF light), `{accent_color}` (#6366F1 indigo, #10B981 emerald, #F59E0B amber), `{nav_items}` (Dashboard, Analytics, Users, Settings, Reports), `{num_kpis}` (3-5), `{chart_1_type}` / `{chart_2_type}` (line chart, grouped bar chart, donut chart, area chart), `{chart_1_colors}` / `{chart_2_colors}` (hex values), `{card_bg}` (#1E1E2E dark card, #FFFFFF light card), `{secondary_widget}`

**Recommended model:** GPT Image 2 (`quality: high`) — dense text (labels, numbers, navigation), precise chart rendering, and small UI elements require high fidelity

### Nano Banana version:

```
A {theme_mode}-themed analytics dashboard UI mockup for {dashboard_title}. Left sidebar ({sidebar_bg}) with navigation icons for {nav_items}, active item highlighted in {accent_color}. Top area: {num_kpis} KPI metric cards showing large numbers with trend arrows. Main area: {chart_1_type} visualizing {chart_1_data} in {chart_1_colors}, alongside a {chart_2_type} showing {chart_2_data}. Below: {secondary_widget}. Clean {design_system} design system, realistic plausible data values throughout, proper visual hierarchy. Desktop fullscreen layout. Format: 16:9.
```

---

## Personal Color Analysis Board

Use to create a visual color analysis graphic from a portrait — seasonal palette classification, clothing color comparisons, and accessory recommendations in an organized layout.

<!-- Source concept: personal color analysis / seasonal color palette board with side-by-side comparisons -->

```
Scene: white background, organized multi-section layout with thin #E0E0E0 divider lines, clean editorial formatting
Subject: personal color analysis board for {subject_description}
Important Details:
  Section 1 — Portrait & Season (top, full width): {subject_description} portrait photo (head and shoulders, natural lighting, neutral expression) on the left. To the right: season classification "{season_type}" in medium bold text, with a 4x3 grid of small color swatches showing the {num_palette} best colors for this season type ({palette_colors}), each swatch labeled with its name in tiny text below
  Section 2 — Clothing Comparison (middle): two side-by-side panels. Left panel "{good_label}": the subject wearing a top in {flattering_color} — skin looks healthy, face appears lifted and bright. Right panel "{bad_label}": the same subject wearing a top in {unflattering_color} — skin appears washed out or sallow. Small caption under each explaining the effect in 5-8 words
  Section 3 — Recommendations (bottom): horizontal strip with {num_recs} small squares — each showing a recommended item ({rec_items}) in one of the palette colors, with a one-word label below (e.g. "Scarf", "Blazer", "Lipstick", "Frames")
  Visual-first design — images and swatches dominate, text is short labels only
  Clean editorial feel, no decorative flourishes
Use Case: personal styling consultation, color analysis service deliverable, fashion content
Constraints: same person in all panels showing the subject, swatches must be solid flat color (no gradients), labels are short (1-3 words max), no paragraphs of body text, layout must feel organized and scannable, no overlapping sections
```

**Key levers:** `{subject_description}` (age, skin tone, hair color, eye color — needed for accurate seasonal analysis), `{season_type}` (Warm Spring, Cool Summer, Warm Autumn, Cool Winter — or sub-seasons like Soft Autumn, Bright Winter), `{palette_colors}` (12 hex values matching the season, e.g. Warm Autumn: rust #B7410E, olive #708238, mustard #E1AD01, burgundy #722F37...), `{num_palette}` (12), `{flattering_color}` / `{unflattering_color}` (specific colors with hex), `{good_label}` / `{bad_label}` (e.g. "Warm Coral" / "Cool Pink"), `{num_recs}` (4-6), `{rec_items}` (scarf in olive, blazer in navy, lipstick in warm rose, eyeglass frames in tortoise)

**Recommended model:** GPT Image 2 (`quality: high`) — color accuracy of palette swatches is critical, plus small text labels throughout

### Nano Banana version:

```
A personal color analysis board on a white background for {subject_description}. Top section: portrait of the subject on the left, seasonal classification "{season_type}" on the right with a grid of {num_palette} color palette swatches ({palette_colors}). Middle section: side-by-side comparison — left shows the subject in a {flattering_color} top looking healthy and bright ("{good_label}"), right shows the same subject in {unflattering_color} looking washed out ("{bad_label}"). Bottom strip: {num_recs} recommended items ({rec_items}) each in a palette color with one-word labels. Clean editorial layout, visual-first with minimal text, thin gray dividers between sections. Format: 3:4.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/prompt-framework.md

# Prompt Framework

Универсальный чеклист для построения промпта. Применим к **обеим** семьям моделей. Для отличий смотри:
- [nano-banana.md](nano-banana.md) — NB-специфика (grounding, extreme ratios, thinking mode, JSON)
- [gpt-image.md](gpt-image.md) — GPT Image 2 (5-slot template, anti-slop, quality settings)
- [models.md](models.md) — какую модель когда выбрать

## Task Types (Навыки)

Определи тип задачи - это задаёт стратегию промпта:

| Type | Когда использовать | Ключевые элементы |
|------|-------------------|-------------------|
| **Photorealistic** | Фото людей, продуктов, сцен | Освещение, материалы, атмосфера |
| **Illustration** | Стикеры, иконки, арт | Стиль, контуры, палитра |
| **Product/Commercial** | Продуктовая съёмка | Поверхность, отражения, композиция |
| **Minimalist** | Негативное пространство | Что убрать важнее чем что добавить |
| **Sequential** | Комиксы, сториборды | Панели, переходы, нарратив |
| **Editing** | Изменение существующего | Конкретные инструкции что менять |
| **Style Transfer** | Перенос стиля | Референс + новый контент |
| **Composite** | Объединение элементов | Связность, освещение, масштаб |
| **Text Rendering** | Текст в изображении | Точные кавычки, позиция, вес |

## Universal Elements (Чеклист)

Пройдись по списку - не всё нужно указывать, но полезно проверить:

**Обязательные:**
- **Субъект** - кто/что в центре внимания
- **Контекст** - для чего это (определяет стиль)

**По ситуации:**
- **Действие** - что происходит
- **Окружение** - где это происходит
- **Камера** - крупность плана (close-up, wide shot, etc.)
- **Освещение** - тип света
- **Настроение** - эмоция сцены
- **Материалы** - текстуры поверхностей
- **Палитра** - цвета (лучше hex)
- **Формат** - соотношение сторон

> ⚠️ **Параметры объектива** (50mm, 85mm, f/2.8, ISO):
> - **Nano Banana** — игнорит числа, пиши описательно («shallow depth of field»)
> - **GPT Image 2** — допускает «50mm feel» как high-level look, но не как точную физическую симуляцию

## Detail Modes (Режимы)

**Concise** - одно предложение, для быстрых итераций:
```
Minimalist poster: white background, single red apple, centered, dramatic shadow.
```

**Standard** - 1-2 параграфа, баланс контроля и гибкости:
```
Create a product shot for premium headphones marketing.

Matte black headphones on dark slate surface. Single spotlight from upper left creates dramatic shadow. Background gradient from #1a1a1a to pure black.

Format: 16:9
```

**Verbose** - максимум деталей для сложных сцен:
```
Create a cinematic wide shot for sci-fi film concept art.

Setting: Abandoned space station observation deck. Massive curved window spans entire wall, revealing dying red giant star filling half the frame. Station interior in deep shadow except where crimson light bleeds through.

Subject: Lone astronaut in weathered EVA suit, helmet off, sitting on debris pile. Back to camera, facing the star. Pose suggests exhaustion and acceptance.

Atmosphere: Dust particles float in zero-g, catching red light. Abandoned equipment scattered - coffee cup frozen mid-float, papers suspended. Frost crystals on interior surfaces where life support failed.

Mood: Melancholic beauty, end of an era
Lighting: Volumetric god rays from star through window
Format: 2.39:1 cinemascope
```

## Output Structure

При создании промпта выдавай:

**1. Prompt** - готовый к использованию

**2. Parameters** - если нестандартные:
- Aspect ratio (если не 1:1)
- Resolution (если нужно 2K/4K)

**3. Exclusions** - что исключить (опционально):
> Формулируй позитивно! NBP лучше понимает "clean background" чем "no clutter"

**4. Assumptions** - что додумано, если пользователь не указал

## Quick Decision Tree

```
Что создаём?
├── Фото реального объекта/человека → Photorealistic
├── Рисунок/арт → Illustration  
├── Товар для продажи → Product/Commercial
├── Много пустого места → Minimalist
├── Несколько кадров/история → Sequential
├── Меняем существующее фото → Editing
├── "Как на этой картинке" → Style Transfer
├── Собираем из нескольких элементов → Composite
└── Текст - главный элемент → Text Rendering
```

> Image grounding (поиск реальных мест в интернете) и экстремальные ratio (1:8, 8:1, 4:1) — только Nano Banana. См. [nano-banana.md](nano-banana.md).

## Examples by Type

### Photorealistic
```
Portrait of a weathered fisherman, 60s, deep wrinkles and sun-damaged skin.
Early morning golden hour on wooden dock.
Holding fresh catch, genuine smile of satisfaction.
Background: misty harbor, fishing boats soft focus.
Mood: authentic, documentary style
```

### Product/Commercial
```
Product shot: luxury watch on raw concrete slab.
Single hard light from upper right, creating defined shadow.
Watch face at 10:10 position, metal bracelet draped naturally.
Background: gradient gray, vignette edges.
Style: high-end catalog, editorial
Format: 4:5
```

### Minimalist
```
Single origami crane, red paper, centered.
Pure white infinite background.
Soft diffused light, barely visible shadow.
Extreme negative space - crane occupies <10% of frame.
Format: 1:1
```

### Text Rendering
```
Motivational poster for gym.

Background: dark textured concrete, subtle vignette.

Text:
"DISCIPLINE" in extra bold, white, centered upper third
"beats talent" in thin weight, #808080, centered below

Small icon: minimal dumbbell silhouette, bottom center
Format: 9:16 (stories)
```

## Parameterized Templates

Паттерн `{variable}` для переиспользуемых промптов. Структура промпта остаётся стабильной — меняется только то, что нужно.

### Синтаксис

Переменные записываются как `{name, default="value"}`. Если значение не указано — используется дефолт. Если дефолта нет — переменная обязательна.

### Шаблон

```
Scene: {location, default="small Lisbon florist storefront at blue hour"}
Subject: {person, default="woman in navy apron"} {action, default="locking the front door"}
Important Details: {lighting}, {lens_feel, default="50mm feel"}, {key_texture}
Use Case: {use_case, default="editorial photography"}
Constraints: {constraints, default="no extra signage, no people in background"}
```

### Как использовать

1. **Заменяй только то, что меняется** — остальное берётся из дефолтов
2. **Структура стабильна** — порядок слотов одинаковый для всех вариаций, модель получает консистентный формат
3. **Batch-генерация** — идеально для серий: продуктовые ракурсы, позы персонажа, локации в одном стиле

### Примеры использования

**Серия продуктовых шотов** (меняется только товар и текстура):
```
Scene: {location, default="marble kitchen counter, morning light"}
Subject: {product} on {surface, default="raw linen cloth"}
Important Details: {lighting, default="soft window light from left"}, {lens_feel, default="85mm feel"}, {key_texture}
Use Case: {use_case, default="e-commerce hero shot"}
Constraints: {constraints, default="clean background, no props except surface"}
```

**Серия персонажных поз** (меняется действие и настроение):
```
Scene: {location, default="industrial loft studio"}
Subject: {person, default="man in black turtleneck"} {action}
Important Details: {lighting, default="single softbox, camera right"}, {lens_feel, default="50mm feel"}, {key_texture, default="fabric texture visible"}
Use Case: {use_case, default="fashion editorial"}
Constraints: {constraints, default="no visible logos, neutral expression"}
```

## Cinematic Verbose Mode

Стандартный verbose — 5-7 строк. **Cinematic verbose** — уровень выше, для случаев когда нужен максимум детализации: hero shots, ключевые визуалы, campaign centerpieces.

### Когда использовать

- Финальный визуал кампании, а не итерация
- Hero shot для лендинга или обложки
- Key visual, который будет масштабироваться на все форматы
- Портфолийная работа, где каждый пиксель имеет значение

### Чеклист микро-деталей

Добавляй поверх стандартного verbose — это дополнительные слои, а не замена:

1. **Surface wear & aging** — "chipped paint on window frame, hairline scratches on metal surface, green patina on copper fittings, oxidation marks on iron hinges"
2. **Micro-textures** — "visible pores on skin, individual hair strands catching backlight, fabric weave pattern on linen shirt, grain of weathered wood"
3. **Atmospheric particles** — "dust motes suspended in light beam, steam wisps rising from coffee cup, pollen floating in golden hour air, fine rain droplets on glass surface"
4. **Specular behavior** — "specular highlights on metal edges of watch, caustic reflections dancing inside glass bottle, wet surface sheen on cobblestones after rain"
5. **Fabric & material drape** — "natural fabric folds at elbow crease, gravity pull on loose linen garment, weight distribution visible in heavy wool coat"
6. **Contact shadows** — "soft contact shadow where cup meets saucer, ambient occlusion in crevices of stone wall, dark line where book spine meets table"
7. **Environmental reflections** — "building reflections in wet pavement, sky gradient in chrome bumper surface, warm neon glow on skin from nearby sign"
8. **Motion cues** — "slight motion blur on trailing hair strand, frozen splash droplet from espresso pour, wind-displaced fabric edge of scarf"

### Before / After

**Standard Verbose:**
```
Create a cinematic portrait for coffee brand campaign.

Setting: Small Italian café, early morning. Espresso machine prominent in background.
Subject: Barista in white shirt, mid-pour, focused expression.
Atmosphere: Steam rising, warm tones, golden morning light through window.
Mood: Craftsmanship, ritual, quiet dedication
Lighting: Warm directional light from left window
Format: 4:5
```

**Cinematic Verbose:**
```
Create a cinematic portrait for coffee brand campaign.

Setting: Small Italian café, early morning. Brass-and-chrome La Marzocca espresso machine in background, oxidation marks on steam wand, hairline scratches on drip tray from years of use. Chipped paint on wooden window frame behind machine.

Subject: Barista in white linen shirt — fabric weave pattern visible, natural folds at rolled-up sleeves, gravity pull on loose collar. Mid-pour with focused expression, visible pores on forehead, individual eyebrow hairs catching backlight.

Atmosphere: Steam wisps rising from espresso cup, dust motes suspended in morning light beam cutting through window. Fine coffee grounds scattered on worn marble counter — soft contact shadow where cup meets saucer. Wet surface sheen on freshly wiped counter edge.

Details: Specular highlights on chrome portafilter handle. Caustic reflections dancing inside glass water carafe on shelf. Warm neon glow of "APERTO" sign reflecting on barista's forearm. Slight motion blur on trailing steam, frozen droplet mid-drip from group head.

Mood: Craftsmanship, ritual, quiet dedication
Lighting: Warm directional light from left window, volumetric through steam
Format: 4:5
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/slides.md

# Presentation Slides

Professional slide visuals for decks and pitches.

## Design Principles

### One Slide = One Idea
Не комбинируй несвязные концепции. Аудитория запоминает 65% визуального vs 10% услышанного.

### Content Limits
- Max 5 пунктов на слайде
- 15-20 слов в блоке текста
- Заголовок + список ИЛИ абзац, не оба

### Typography
```
Заголовок: 44-54 pt, bold
Подзаголовок: 28-36 pt, medium
Текст: 18-24 pt, regular (min 18 для читаемости)

Шрифты: sans-serif основной (Inter, Helvetica, Roboto)
Serif только для акцента
```

### Contrast & Color
- 3-4 цвета max (основной + 2-3 акцента)
- Один нейтральный фон (white/black/gray)
- Контраст min 4.5:1
- Избегай pure white #fff на чёрном - используй #f5f5f5

### Whitespace
- Контент должен дышать
- Асимметричные макеты (2/3 + 1/3) динамичнее центрированных
- Если тесно - разбей на два слайда

### Visual Consistency
- Один стиль: фото ИЛИ иллюстрации ИЛИ минимал графика
- Смешивание = визуальный хаос
- High-res only, каждый образ усиливает идею

### Checklist
```
☐ Один слайд = одна идея
☐ Max 5 пунктов
☐ Заголовок 44-54pt, текст 18-24pt
☐ 3-4 цвета, высокий контраст
☐ Достаточно whitespace
☐ High-res визуалы, единый стиль
```

---

## Slide Types

### Hero Title (Dark)
```
Create dramatic title slide for [CONTEXT] presentation.

Background: Gradient from [DARK hex] to #0a0a0a.
Atmospheric: subtle mist at lower edge.

Typography:
"[MAIN TITLE]" in extra bold, white, extremely large, upper third
"[SUBTITLE]" in thin, muted, 5x smaller, below

Mood: Confident, premium
Format: 16:9
```

### Data Visualization
```
Create data slide for [CONTEXT] presentation.

Background: Dark gradient [hex] to [hex].

Hero number: "[METRIC]" in bold, [ACCENT], center
Trend: [up/down arrow] in [green/red]
Supporting: 3-4 smaller metrics below

Chart: [TYPE] showing [DATA]

Mood: Analytical, impactful
Format: 16:9
```

### Comparison (Light)
```
Create comparison slide for [CONTEXT].

Background: Off-white #fafafa to #f0efed.

Split layout:
Left: "[OPTION A]" with details
Right: "[OPTION B]" with details

Emphasis: Right side accent bar #3b82f6

Mood: Clear, objective
Format: 16:9
```

### Insight/Problem
```
Create insight slide for [CONTEXT].

Background: Clean off-white.

Focal: "[KEY MESSAGE]" in bold, centered
Supporting: "[CONTEXT]" smaller, below
Emphasis bar: [ACCENT] strip with data point

Mood: Clarity, focus
Format: 16:9
```

### Process/Timeline
```
Create process slide for [CONTEXT].

Flow: [HORIZONTAL/VERTICAL]
Stages: [1]→[2]→[3]→[4]
Each: icon + "[LABEL]" + description
Connectors: arrows in [ACCENT]

Format: 16:9
```

## Typography

**Hierarchy:**
- Hero: "Extremely large, dominating upper third"
- Primary: "Large, commanding"
- Secondary: "3-5x smaller than hero"
- Footer: "Minimal"

**Weight:** thin | regular | medium | bold | extra bold
**Position:** "upper third", "left aligned 10% margin", "centered"

## Color Systems

**Dark palette:**
- Near-black: #0a0a0a, #121212
- Deep tones: #0d3d2d, #1a2a3a
- Text: #ffffff, #e0e0e0

**Light palette:**
- Off-white: #fafafa, #f8f9fa
- Warm gray: #f5f5f4
- Text: #1a1a1a, #374151

**Data colors:**
- Positive: #22c55e
- Negative: #dc2626
- Highlight: #3b82f6

## Atmospheric Effects

- "Subtle gradient haze"
- "White mist at ground level"
- "Soft vignette darkening edges"
- "Noise texture for premium feel"

---

## Layout Systems

Универсальные правила вёрстки. Работают с любым визуальным стилем.

---

### Bento Grid

Модульная система из блоков разного размера.

**Core Rules:**
- Родительский контейнер с явными границами модулей
- Иерархия: важный контент → крупные блоки, второстепенный → мелкие
- Max 9 блоков (иначе перегруз)
- Единообразные gaps (16px стандарт)
- Связанный контент группируется в одном блоке

**Размеры:** широкие/плоские (hero) | узкие/высокие (списки) | квадратные (иконки)

**Сетки:**
```
3-block:           6-block:             9-block:
┌───────┬───┐     ┌───┬───┬───┐       ┌─────┬───┬───┐
│ HERO  │SEC│     │ S │ S │ S │       │HERO │MED│ S │
├───────┴───┤     ├───┴───┼───┤       ├──┬──┴───┼───┤
│  FOOTER   │     │ CHART │LST│       │S │ MED  │ S │
└───────────┘     └───────┴───┘       └──┴──────┴───┘
```

**Prompt:**
```
Layout: bento grid, [N] blocks
Hero block: [MAIN], Medium: [SECONDARY], Small: [ICONS]
Gaps: uniform spacing
```

---

### Asymmetric Grid

Динамичные композиции с визуальным балансом.

**Rules:**
- Начинай с базовой сетки, потом ломай осознанно
- Балансируй вес: крупный элемент слева = несколько мелких справа
- Rule of Thirds для естественного баланса
- Ключевые элементы выделяй размером и положением

**Применять:** креативные презентации, портфолио, fashion, стартапы
**НЕ применять:** банки, госпорталы, B2B с большими данными, пожилая аудитория

**Prompt:**
```
Layout: asymmetric composition
Left: [LARGE - 60%], Right: [2-3 SMALLER stacked]
Balance: visual weight distributed
Rule of thirds positioning
```

---

### Negative Space

Пространство как инструмент фокусировки.

**Rules:**
- Структурирует, а не создаёт пустоту ради красоты
- Управляет вниманием, фокусирует на главном
- Gestalt: элементы с пространством = отдельные, близко = связанные

**Применять:** премиальные бренды, минималистичные презентации, hero-секции
**НЕ применять:** новостные порталы, дашборды, мобильные версии

**Prompt:**
```
Layout: generous whitespace
Focal point: [ELEMENT] with breathing room
Empty space: intentional, guides eye to [CTA]
```

---

### Split Screen

Двухколоночная композиция.

**Пропорции:**
- 50/50 - равноценные элементы
- 60/40 - акцент на одной стороне
- 70/30 - явный герой + поддержка

**Prompt:**
```
Layout: split-screen [RATIO]
Left: [CONTENT], Right: [CONTENT]
Divider: [sharp / gradient / none]
```

---

### Brutalist

Сырая эстетика, огромные шрифты, яркие цвета.

**Rules:**
- Сохраняй чёткую навигацию и иерархию
- Читабельность > экспрессия
- Применяй селективно: яркие цвета ИЛИ огромные шрифты

**Применять:** портфолио художников, fashion, стартапы
**НЕ применять:** e-commerce, корпораты, образование, финтех

**Prompt:**
```
Style: brutalist design
Typography: massive, raw
Colors: high contrast, bold
Hierarchy: clear despite unconventional styling
```

---

## Futuristic / SaaS Style

Apple Keynote minimalism + glassmorphism + 3D objects.

### Visual Language
```
Style: Apple Keynote + SaaS + glassmorphism
Mood: premium, immersive, clean, breathable
Lighting: volumetric, ray-traced reflections, ambient occlusion
Base: deep void black OR pure ceramic white
Accents: aurora gradients (neon purple, electric blue, coral, cyan)
```

### Glassmorphism Cards
```
Material: frosted glass with blur
Edges: delicate white borders
Shadow: soft, diffused
Spacing: generous internal whitespace
```

### 3D Visual Anchors
```
Purpose: abstract 3D artifacts as focal points
Materials: polished metal, iridescent acrylic, transparent glass, soft silicone
Shapes: capsules, spheres, shields, Möbius strips, fluid waves
Quality: looks like expensive collectibles
```

### Composition by Type

**Cover:** huge 3D glass object center + bold title + aurora background
**Content:** bento grid + 3D icons in small cards + text in large cards  
**Data:** split-screen (text left, glowing 3D chart right)

### Charts Style
```
3D donut charts, glowing
Capsule-shaped progress bars
Floating numbers with neon glow
Style: looks like glowing neon toys
```

### Example Prompt
```
Create a futuristic SaaS slide for product presentation.

Style: Apple Keynote + glassmorphism.
Mood: premium, immersive, clean.
Background: void black with aurora gradient (purple → cyan).

Layout: bento grid, 6 blocks.
Cards: frosted glass, blur, white edges, soft shadows.
Hero block: floating iridescent sphere.
Data blocks: glowing 3D donut chart, neon metrics.

Typography: clean sans-serif, high contrast white.
Format: 16:9
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/storyboards.md

# Storyboards & Sequential Art

One-shot narrative sequences. Concept art. Consistent across frames.

## Story Sequence

```
Create [NUMBER]-part story with [NUMBER] images.

Characters: [DESCRIPTION]
Setting: [LOCATION/CONTEXT]
Story arc: [NARRATIVE with emotional highs/lows]

Identity: Characters and attire consistent throughout.
Variation: Different angles, distances, expressions.
Generate: One image at a time.
Format: [ASPECT RATIO] per image.
```

## Commercial Storyboard

```
Create [NUMBER]-part story for [PRODUCT] commercial.

Characters: [man and woman / family / solo]
Product: [DESCRIPTION]
Story: [EMOTIONAL ARC]
Ending: Elegant shot with [LOGO/PRODUCT]

Identity and attire consistent throughout.
Vary angles and distances.
Generate one at a time.
Format: 16:9 landscape.
```

## Film Storyboard

```
Create storyboard for this scene.

Shots:
1. Establishing shot - [DESCRIPTION]
2. Medium shot - [ACTION]
3. Close-up - [DETAIL]
4. POV shot - [PERSPECTIVE]

Style: [B&W sketch / color / cinematic]
Annotations: [CAMERA MOVES / NOTES]
```

## Concept Art Series

```
Create concept art series for [PROJECT].

Subjects: [CHARACTERS / ENVIRONMENTS / PROPS]
Style: [AESTHETIC]
Mood: [TONE]

Consistency: Design language across all pieces.
Generate one at a time.
```

## Sprite Sheets

```
Sprite sheet of [CHARACTER] doing [ACTION].
Grid: [3x3 / 4x4]
Sequence: frame by frame animation
Format: square aspect ratio
Follow reference grid structure exactly.
```

Tip: Extract cells to make GIF.

## Consistency Rules

- "Identity must stay consistent throughout"
- "Attire same across all images"
- "Can be seen from different angles and distances"
- "Expressions and poses should vary"
- "Only one of each character per image"

## Narrative Pacing

- "Story is thrilling with emotional highs and lows"
- "Ends on [happy / dramatic / mysterious] moment"
- "Build tension through first [N] images"
- "Climax in image [N], resolution in final"

## Output Control

- "Generate images one at a time"
- "Make sure every image is [ASPECT RATIO]"
- "Please generate [NUMBER] images, one at a time"

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/structural.md

# Structural Control

Input images control composition. Sketch→final, wireframes, grids.

## Sketch → Final

```
Create [ASSET TYPE] following this sketch exactly.

Sketch defines: composition, element placement, text position
Quality: [polished / professional / specified style]
Text: Render "[EXACT TEXT]" where indicated
```

Hand-drawn layouts become polished assets.

## Wireframe → Mockup

```
Generate [MOCKUP TYPE] following these wireframes.

Layout: Match wireframe structure precisely
Content: [placeholder / realistic]
Style: [UI style / brand guidelines]
```

UI/UX designs from rough wireframes.

## Grid-Based Assets

```
Generate [ASSET] fitting this [SIZE] grid.
Each cell: [CONTENT]
Consistency: Uniform style across cells
```

Use cases:
- Sprite sheets for games
- LED display content
- Tile-based graphics

## Pixel Art

```
Generate pixel art [SUBJECT] fitting [SIZE] grid.
Colors: high contrast
Style: [retro / modern pixel]
```

Tip: Extract cell colors programmatically for LED matrices.

## Layout Guidance

Reference images can control:
- **Where** elements sit
- **What** proportions to use
- **How** text flows
- **Which** areas get emphasis

## Brand Identity Systems

```
[Input: logo sketch or design]
Create identity system using this logo.

Generate one at a time:
1. Logo refinement
2. Business card mockup
3. Letterhead
4. Billboard application
5. Product packaging
6. Digital banner
7. Social media avatar
8. App icon
9. Signage
10. Merchandise

Format: 16:9 each
Maintain: brand consistency across all
```

## Composition Templates

Use reference for:
- Magazine layouts
- Poster compositions
- Social media templates
- Presentation structures

```
Follow the composition of reference image.
Replace: [ELEMENTS] with [NEW CONTENT]
Maintain: proportions, visual hierarchy
```

## Precision Control

- "Position text exactly where sketch indicates"
- "Follow grid structure exactly"
- "Match layout precisely"
- "Keep proportions from reference"

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/text-rendering.md

# Text Rendering & Infographics

Универсальные стили, layout-типы, примеры. Применимо к обеим моделям, но детали рендера расходятся:

- **Nano Banana:** SOTA по 100+ языкам, multi-language в одном кадре, можно называть конкретные шрифты («Century Gothic 12px», «Brush Script»). См. [nano-banana.md](nano-banana.md).
- **GPT Image 2:** EXACT TEXT в `"..."` или ALL CAPS, добавляй «no extra words / no duplicate text», для мелкого текста — `quality: high`. См. [gpt-image.md](gpt-image.md).

## Prompt Structure

```
Create an educational infographic about [TOPIC].
Target Audience: [GRADE/LEVEL]
Content: [SPECIFIC FACTS/SEQUENCE]
Title: "[TITLE TEXT]"
Visual Style: [STYLE]
Layout: [LAYOUT TYPE]
Format: [ASPECT RATIO]
```

## Visual Styles

**Educational/Friendly:**
- Paper Cutout: construction paper collage look
- Claymation/Plasticine: 3D tactile, Wallace & Gromit style
- Kawaii/Cute Vector: rounded edges, pastel colors
- Storybook Watercolor: soft painted textures
- Chalkboard Art: white chalk on green/black
- Pixel Art (8-Bit): retro gaming nostalgia

**Technical/Professional:**
- Isometric 3D: video game map style, processes
- Blueprint/Schematic: white lines on blue
- Da Vinci Notebook: renaissance sketch, scientific
- UI/UX Wireframe: app blueprint style
- Dashboard: analytics screen with numbers

**Stylized:**
- Cyberpunk/Neon: dark + bright neon accents
- Graphic Novel/Comic Book: bold outlines, flat colors
- Vintage Science Poster: muted, aged paper, fine lines
- Pop Art (Warhol): high contrast, bold, dots
- Corporate Memphis/Flat Art: tech company style

**Specialized:**
- Subway/Transit Map: journey, connections
- IKEA Manual: wordless step-by-step
- Knolling (Flat Lay): objects at 90° angles, overhead
- Origami/Paper Folding: geometric, clean

## Layout Types

**Linear:**
- Horizontal Timeline: history, biography
- Step-by-Step Flow: recipes, experiments, processes
- Winding Roadmap: journey through topic

**Comparison:**
- Split Screen (Versus): instant contrast
- Comparison Matrix: multiple items, same criteria
- Before and After: cause and effect
- Venn Diagram: compare and contrast

**Hierarchical:**
- Pyramid: foundation to peak (Maslow, food pyramid)
- Funnel: filtering process (bill→law, sales)
- Iceberg: visible vs invisible (10% above, 90% below)

**Radial/Connected:**
- Hub and Spoke: core topic + attributes
- Tree/Branching Map: genealogy, taxonomy
- Concentric Circles: layers (Earth, proximity)

**Grid-Based:**
- Bento Grid: tidy boxes, modular
- Periodic Table Grid: items by type/family
- Comic Strip: narrative in scenes
- Jigsaw: pieces forming whole

**Spatial:**
- Isometric Map: 3D game world style
- Cross-Section (Cutaway): inside something solid
- Anatomical Call-out: labeling parts of whole
- Exploded View: parts hovering, showing assembly

## Examples

**Science - Water Cycle:**
```
Create educational infographic for Elementary Science.
Topic: The Water Cycle.
Content: Evaporation, Condensation, Precipitation, Collection.
Visual Style: Bright, colorful, 3D claymation style.
Layout: Circular flow diagram with arrows clockwise.
```

**History - Timeline:**
```
Create educational infographic for High School History.
Topic: Timeline of Ancient Egypt.
Content: Old Kingdom (Pyramids), Middle Kingdom (Arts), New Kingdom (Tutankhamun).
Visual Style: Papyrus texture, hieroglyphic icons, gold/sand palette.
Layout: S-curve roadmap flowing top to bottom.
```

**Literature - Iceberg:**
```
Create educational infographic for Sociology class.
Topic: Surface Culture vs Deep Culture.
Content: Above water (Food, Flags, Festivals). Below water (Body Language, Beliefs, Etiquette).
Visual Style: Paper Cutout Style, textured construction paper.
Layout: Iceberg diagram, tip = 10%, submerged = 90%.
```

**Comparison - Matrix:**
```
Create educational infographic for Elementary Science.
Topic: Inner vs Outer Planets.
Content: Compare across Surface Type, Size, Rings.
Visual Style: Kawaii/Cute Vector, pastel colors.
Layout: Comparison Matrix grid.
```

## Text-First Hack

For complex text in images, generate text FIRST, then ask for the image:
1. Ask the model to write/refine the text content
2. Then ask for an image with that exact text

This produces sharper, more accurate typography than cramming everything in one prompt.

## Font Control

Describe typography style or name the font directly:
- "Bold, white, sans-serif font"
- "Century Gothic 12px font"
- "Flowing, elegant Brush Script"
- "Heavy, blocky Impact font"
- "Thin, minimalist Century Gothic"

## Multilingual / Localization

Supports 10+ languages. Two approaches:

**Direct:** Write prompt in target language, text renders in that language.

**Translate:** Write prompt in one language, specify target:
```
Create this product ad. Render all text in Korean.
```

**Multi-language in one image:**
```
Line 1: "GLOW" in Brush Script
Line 2: "10% OFF" in Impact font
Line 3: "Your First Order" in Century Gothic
Then translate all text into Korean and Arabic.
```

## Tips

**Provide your own content:**
- Paste article text, video transcript, your notes
- More accurate than relying only on search

**Sketch-to-Image:**
- Draw messy layout sketch on paper
- Upload with prompt: "Use layout from attached image"

**Iterative editing:**
- "Leave everything else exactly the same, but change [X]"
- Annotate downloaded image, upload back as reference

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


---

## ARCHIVO: image/references/vision-decomposer.md

# Vision Decomposer — Image-to-Prompt Analysis

Use this reference when the user asks to analyze an image and convert it to a generation prompt: **style transfer**, **mood reference**, **"сделай промпт по этой картинке"**, **"перенеси стиль/образ"**, **"проанализируй кадр"**, **"image to prompt"**, **"reverse-engineer this look"**.

You become a **professional Vision Agent**. Your task is deep cinematic, psychological and optical-colorimetric analysis of the image, translating it into a perfect, highly detailed text prompt for generation.

The process has two strict steps. Do not skip Step 1. Do not freestyle Step 2.

---

## STEP 1 — DEEP DECOMPOSITION

Scan the image as **raw data** and extract facts based on:

- **Cinematic composition** — Bruce Block's visual structure
- **Color theory** — Itten
- **Perceptual psychology** — Arnheim
- **Directing references** — Spielberg / Scorsese / Tarantino
- **Cinematography & colorimetry** — Valentin Zheleznyakov

Evaluate the following four parameter blocks.

### 1. Subject — psychology and mise-en-scène

- **Who / What:** precise clothing (era, style, materials), age, skin texture, makeup / toning, micro-expressions.
- **Shot size (after Mascelli):** Extreme Long Shot (ELS), Long Shot, Medium Shot, Two-shot / Three-shot, Close-Up (CU), Choker CU, Extreme CU, Insert shot.
- **Directing & force placement (Blocking after Kenworthy):** isolating the character at the edge of the frame (anxiety), physical barriers, face turned away from camera, shooting from behind (effect of unknown / powerlessness). Height difference (Level Change) for dominance.
- **Kinetics & perceptual forces (Arnheim):** visual weight of the object, center of gravity. Internal tension of form (compression / stretching / twisting). Pose, plasticity, motion vectors. Imitation of swift action (motion blur) or monumental stillness.
- **Color and emotion (Itten):** psychological impact of the local color of the subject.
- **Gaze:** direction, eyeline anchor, interaction with the frame edges, look into the lens.

### 2. Environment — geometry and structure of space

- **Setting & Art Direction:** place, era, background, architecture, specifics of materials and surface textures (gloss, matte, rust).
- **Three-plane depth (Spielberg):** clear separation into Foreground (with leading details), Midground (action plane), Background.
- **Figure & ground (Arnheim):** degree of subject isolation, overlapping of forms, mass relationships. Use of reflections (mirrors, windows) to expand context.
- **Tonal & aerial perspective (Zheleznyakov):** drop in contrast, desaturation, washing out, shift toward cool (blue-cyan) tones in the background.
- **Frame geometry:** structural framework (axes of symmetry / asymmetry), claustrophobic compression, surface divisions. Illusion of depth via Foreground framing.

### 3. Lighting — chiaroscuro, color and contrast

- **Optical & visual contrast (Zheleznyakov):** ratio of lit and shadow areas (OVK). Depth and density of shadows. Exact local color vs. color modified by lighting (valeurs).
- **Lighting scheme:** Key, Fill, Backlight / Rim, Modeling. Rembrandt lighting, Chiaroscuro. Height, hardness (Hard / Soft) and type of source.
- **Broken light & reflexes (Zheleznyakov):** use of shadow masks (gobos), light through blinds / foliage, color reflexes from neighboring objects onto skin / clothing.
- **Tonality & color:** light key (High-key / Low-key). Threshold Silhouette. Itten's 7 contrasts. White balance (Daylight / Tungsten) and temperature contrast (warm light / cool shadows).

### 4. Tech & Cinematography — optics, filters and film texture

- **Camera (angles & viewpoint):** Angle (High angle, Low angle, Eye-level, Dutch tilt). Objective camera, Subjective, POV, Over-the-shoulder (OTS). Movement imitation (Push-in, Tracking shot).
- **Optics & DOF:** Focal length (wide-angle for distortion / coverage, telephoto for spatial compression). Depth of field. Rack focus, bokeh.
- **Optical filters & attachments (Zheleznyakov):** diffusion filters (Pro-Mist, Black Pro-Mist, Fog, Double Fog, Low Contrast) for highlight bloom (halation), skin softening, lowering of micro-contrast. Polarizers (cutting reflections).
- **Effects & texture:** Frame format (70mm, 35mm, IMAX). Exposure (motion blur). Stylization (Bleach Bypass). Film Grain, chromatic aberration.

---

## STEP 2 — PROMPT SYNTHESIS

Assemble the final prompt from Step 1 data.

Rules:
- Write **only keywords separated by commas, in English**.
- Describe **strictly what you see**. Do not invent new objects.
- **No filler.** Never write "The image shows...", "A picture of...", "I can see...".
- **Strict word order** (this formula is non-negotiable):

```
[Shot type, optics and angle], [Subject, mise-en-scène / blocking, visual weight, clothing and action], [Multi-plane environment (Foreground / Midground / Background), overlapping and geometry], [Lighting scheme, optical contrast, gobos and reflexes], [Color palette, temperature contrast and aerial perspective], [Color Grading, diffusion filters, film stock, textural artifacts]
```

---

## OUTPUT PROTOCOL

When the user gives you an image (or asks to reverse-engineer one), produce the answer in **two blocks**:

### Block 1 — Brief Analysis Log

```
Subject & Blocking: ...
Environment & Depth: ...
Lighting & Contrast: ...
Tech & Optics: ...
```

Each line: 1-2 sentences max. Just the extracted parameters.

### Block 2 — Final Prompt

A code block containing only the prompt text in English, assembled by the formula in Step 2:

````
```
<comma-separated keywords following the strict 6-segment formula>
```
````

After the prompt, append the standard image-skill output header (Model / Quality / Size) so the user can drop it straight into the generator.

---

## When to load this file

Load `vision-decomposer.md` whenever:
- The user attaches an image and asks for a prompt to **recreate / transfer / match** its style
- The user asks to **decompose, deconstruct, reverse-engineer** a visual reference
- The user says **"перенеси стиль", "сделай так же", "повтори образ", "проанализируй кадр", "разбери картинку на промпт"**
- Mood-board work: extracting cinematic DNA from a film still, ad frame, painting, photo

Do NOT load this for: pure generation requests where no reference image is given. For those, use the standard model files.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*


<!-- SOURCE_FILE_END: repo/notebooklm-corpus/image.md -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/produccion-visual-sw30.md -->
# SOURCE FILE: `repo/notebooklm-corpus/produccion-visual-sw30.md`

# SKILL: produccion-visual-sw30

Documentacion completa del skill. Cada seccion es un archivo distinto.


---

## ARCHIVO: produccion-visual-sw30/SKILL.md

---
name: produccion-visual-sw30
description: Reglas criticas y micro-gate de produccion visual AI para Final Upgrade (proyecto SW30 y cualquier generacion de imagen/video). USA ESTE SKILL SIEMPRE que se escriba o entregue un prompt visual (imagen o video), se genere con Nano Banana, Kling, Veo, GPT Image o el conector Higgsfield, se gasten creditos de generacion, se trabaje cualquier shot, ancla, clip o asset del proyecto SW30/Sports World, o Eric escriba "gate", "micro-gate" o "reglas de produccion". APLICAR ANTES de producir - el micro-gate de 3 lineas es obligatorio antes de gastar creditos o entregar prompts; entrega sin cabecera es invalida.
---

# Producción visual SW30 — micro-gate + 20 reglas críticas

OBJETIVO ÚNICO: máxima calidad de imagen conforme al script, al menor costo de créditos.
Toda decisión se evalúa contra ese objetivo. El production-package es la fuente de verdad.

## PREGUNTA DE AVANCE (gate de entrega, antes del micro-gate)
Ninguna respuesta es satisfactoria para el usuario — y viola el prompt maestro — mientras la
respuesta honesta a esta pregunta no sea SÍ SIN MATICES:

  RESPONDE HONESTAMENTE: ¿UTILIZASTE DE FORMA EXHAUSTIVA Y CORRECTA TODAS LAS REGLAS DEL SKILL
  APLICABLES A ESTE CASO? RESPONDE SI O NO.

Reglas de uso:
- La pregunta se responde ANTES de entregar, no después de que el usuario la haga.
- Si la respuesta es NO: no se entrega. Se leen los archivos faltantes, se aplica lo que falte y
  se vuelve a preguntar. Se repite cuantas veces sea necesario.
- Prohibido responder SÍ para complacer. Un SÍ falso es una mentira y cuesta más que el NO.
- Prohibido responder SÍ con matices, condiciones o notas al pie disfrazadas de honestidad.
- "Exhaustiva" significa: leídos COMPLETOS todos los archivos del skill aplicables al caso
  (SKILL.md indica el orden obligatorio), no fragmentos ni grep.
- "Correcta" significa: cada regla verificable corre en un lint o auditor ejecutable por el
  usuario; las no mecanizables se contrastan una a una contra el texto del archivo.
- Ante duda sobre si un archivo aplica, se lee su sección "cuándo cargar / when to load" en vez
  de decidirlo por criterio propio.
- Se permite preguntar al usuario cuando la duda es de dirección creativa, no de reglas.

## ARQUITECTURA POR SECCIONES (obligatoria antes de escribir cualquier prompt)
Orden de dirección: nunca se escribe un prompt de corrido ni se parchea texto. Tres pasos, en este orden:

1. **CATALOGAR** — identificar el TIPO de prompt y leer qué reglas aplican a ese tipo en la matriz
   (production-package/RULES_MATRIX.md: 26 reglas × 5 tipos, con fuente y bloque de cada una).
   Tipos: T1 maestro rostro · T2 maestro cuerpo · T3 cuadro 1 persona · T4 cuadro 2 personas ·
   T5 edición quirúrgica.
2. **DEFINIR SECCIONES** — antes de redactar, listar las secciones que ese tipo exige. Cada regla vive
   en UN bloque nombrado y compartido (optics_*, skin_*, anatomy, idlock, text_lock, contact_*, unique,
   colour, hair, fabric, clean_*, autocontain_*), nunca en texto suelto dentro del brief.
3. **ENSAMBLAR POR SECCIÓN** — el prompt se construye llamando P(scene, subject, [details], mood,
   usecase, [constraints]) para creación o E(change, preserve, [constraints]) para edición, pasando
   bloques. Salida en el formato de SKILL.md del skill image: cabecera Model/Quality/Size + References
   + "Prompt:" + "Notes:" fuera del cuerpo.

### Sistema de cobertura de reglas — la fuente manda, no la memoria
Causa raíz medida: el catálogo de reglas salía de la memoria y cubría 26 de 209 enunciados de la
fuente (12%). Todos los controles derivaban de ese catálogo, así que compartían un único punto de
falla. Cadena corregida, con tres herramientas en production-package:

1. `rule_registry.py` — relee los 23 archivos del skill image y EXTRAE mecánicamente cada enunciado
   normativo (209). Si el skill cambia, el registro cambia solo. Mi interpretación deja de ser etapa.
2. `rule_ledger.py` — obliga a que CADA regla aplicable tenga disposición explícita: CHECK (existe
   verificación) o NA (con razón escrita y auditable). Sale con código 1 si queda una sola PENDING.
3. `audit_gi2.py` — verifica los prompts columna por columna.

**GATE DE COBERTURA**: el builder corre `rule_ledger.py` antes de emitir; si no cierra en 100%
dispuesto, no hay archivo de prompts. Estado actual: 124 reglas aplicables · 100 con verificación
(80%) · 24 excluidas con razón (19%) · 0 pendientes · 100% dispuesto.

Cuando el usuario detecte un defecto: se añade su regla al ledger con su check en el mismo turno.
Así el sistema aprende de su detector más confiable en vez de perder el hallazgo.

### Template canónico de MAESTRO DE ROSTRO (T1) — obligatorio, aplicado por código
Dirección canonizó el template que resolvió el look plástico (2026-08-25). Todo maestro de rostro
se instancia con estos cuatro bloques y el motor lanza TemplateViolation si se sustituye alguno:

| Sección | Bloque obligatorio | Por qué |
|---|---|---|
| light | `light_hard` | luz dura sin relleno, rasante: los poros proyectan sombra. La luz suave de softbox aplana la piel y produce el look plástico — PROHIBIDA en rostros |
| skin | `skin_doc` | defectos concretos (rojeces, descamación, sudor, pigmento desigual, pelos de barba individuales, labios agrietados), no "imperfecciones sutiles" |
| usecase | `usecase_doc` | fotografía documental Kodak Tri-X de reportaje. Kodak Portra suaviza la piel por diseño y contradice los poros — PROHIBIDO en rostros |
| clean | `clean_doc` | anti-belleza explícito: no beauty retouching, no skin smoothing, no even complexion, no soft fill light |

Además, en el slot de rasgos: describir una cara IRREGULAR (nariz con caballete, cicatriz, ojos
hundidos, asimetrías). La cara regular y simétrica es la que lee como maniquí.

Longitud: el prompt completo se mantiene alrededor de 250 palabras. Un slot de 300+ palabras compite
consigo mismo — causa documentada de artefactos en gpt-image-2.

### Motor de plantillas — el molde se cumple por código, no por disciplina
`production-package/template_engine.py` es OBLIGATORIO para construir cualquier prompt visual.
Un prompt no se escribe: se INSTANCIA con `build(tipo, ..., notes=...)`. El motor lanza
`TemplateViolation` y no devuelve nada si:
- falta cualquier sección obligatoria del tipo (T1..T5 declaran su lista, en orden);
- se pasa una sección que la plantilla no declara;
- una sección que debe venir de `BLOCKS` llega como texto suelto — el mensaje dice qué bloque editar;
- falta el bloque `Notes`;
- se cuela un metadato (Model/Quality/Size/Aspect ratio) dentro del cuerpo del prompt.
`python3 template_engine.py` corre su autotest: comprueba que rechaza secciones faltantes, texto
suelto y tipos desconocidos, y que una instancia válida sí se construye.

### Ante un cambio
- Identificar a qué BLOQUE pertenece → editar ese bloque UNA vez → recompilar → auditar.
- El cambio se propaga solo a todos los briefs que usan ese bloque.
- **PROHIBIDO editar el texto de un brief individual.** Eso es parchar: arregla una cosa y rompe otra,
  y es la causa raíz de los ciclos de tres reescrituras.

### Verificación mecánica (no depende de criterio)
- `audit_gi2.py` valida 15 columnas: slots · anti-slop · ratio estándar · metadatos fuera del prompt ·
  Notes · cámara con los 5 efectos ópticos (compresión, bokeh/wash, viñeta, halación, grano) · mood ·
  color · identity-lock · texto de marca · framing positivo · mirada · manos.
- El lint del builder ROMPE la compilación ante cualquier desviación de plantilla.

## MICRO-GATE (obligatorio en los dos puntos de no retorno)
Antes de (a) cualquier generación que gaste créditos y (b) entregar cualquier prompt visual,
la respuesta abre con exactamente 3 líneas:
  SKILL: <archivo y sección leídos EN ESTE turno>
  RIESGOS: <qué puede fallar y qué línea del prompt lo mitiga>
  TÉCNICA: <técnica probada encontrada y fuente, o "no encontrada">
Entrega sin cabecera = inválida; Eric la rechaza sin leerla. Generación sin preflight de
costo = prohibida.

## REGLAS CRÍTICAS
1. Un solo trabajo por generación. Con dos personajes: un sujeto por generación, o técnica
   de colocación probada; nunca "a ver si sale".
2. Posición SIEMPRE por ancla legible de la propia imagen (letterforms del mundo: "his back
   level with the letter L of WORLD"). Prohibido "left half", "centre", "just left of X".
3. El editor no tiene memoria: solo verbos operativos (Move/Replace/Add/Remove/Swap), cero
   narrativa ("has become", "again").
4. Autocontención: toda comparación ("same X") exige ambos referentes adjuntos en ESE prompt.
5. Herencia mínima: "same face and clothes" + solo los deltas. Cero re-descripción de lo que
   la referencia ya muestra.
6. Swap de identidad = última operación, sola: "Replace X with Y — same position, same pose,
   same scale".
7. Mundos por dos pasos: placa vacía primero; insert con "use only the person from image N,
   ignore its setting" + "keep the world of image 1 untouched".
8. Stills en instante congelado ("frozen mid-stride"); nada de movimiento en imagen fija.
9. Contactos entre personas: "a natural high five" — la anatomía la fija el keyframe
   aprobado, nunca la asignación de manos por texto.
10. Logos solo heredados de asset aprobado o descripción canónica del brand-lock; los
    cuerpos nunca tapan logo ni lettering en frames congelados.
11. Lo aprobado se canoniza con hash y se EDITA desde ahí; lo caro nunca se regenera.
12. "Edit, don't re-roll": resultado ≥80% correcto → cambio puntual (hasta 3 ediciones
    apiladas), nunca re-tirar.
13. Máximo 2 intentos por método. A la 2ª falla: cambio de método con causa declarada, o
    alto y consulta. Nunca tercera vuelta de lo mismo.
14. Validadores del paquete y techos de palabras en verde antes de entregar; inspección
    visual propia (zooms 100% de rostros y manos) antes de presentar. Si algo falla: no se
    entrega, se repite — y se dice qué falló en una línea.
15. shots.json es la fuente de verdad: todo cambio entra ahí primero y se propaga.
16. Clips: solo Preserve-cues, roles de start/tail ("The tail image defines X — inherit
    exactly"), movimiento puro, imagen final nombrada; negativos sin "no X", ≤8 ítems.
17. Entregas en unidades chicas con OK de dirección; se entrega el delta, no el paquete.
    Una regla nueva de dirección se aplica a TODOS los prompts, no a la mitad.
18. Respuestas: el dato o entregable en la primera línea. Cero adulación y cero evaluación
    de las acciones de Eric salvo que la pida. Error = una línea de corrección, sin disculpas.
19. Prohibido afirmar capacidades, límites o hechos de plataforma sin verificarlos en este
    turno (leer la fuente o buscar); lo no verificado se etiqueta como inferencia.
20. /research solo para problemas genuinamente nuevos; /briefing solo al retomar tras días
    fuera; /handoff al cerrar sesión. Ninguno por default.


<!-- SOURCE_FILE_END: repo/notebooklm-corpus/produccion-visual-sw30.md -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/screenwriter.md -->
# SOURCE FILE: `repo/notebooklm-corpus/screenwriter.md`

# SKILL: screenwriter

Documentacion completa del skill. Cada seccion es un archivo distinto.


---

## ARCHIVO: screenwriter/SKILL.md

---
name: screenwriter
description: >
  Transform creative ideas into professional, production-ready screenplays optimized for AI video generation pipelines. Converts raw concepts into structured scene-by-scene narratives with rich visual descriptions, proper screenplay formatting, and XML-tagged output for seamless integration with image/video generation tools (imagine, arch-v).
  
  USE WHEN: Converting story ideas into screenplay format, preparing content for AI video pipelines, structuring narratives for 5-10 minute short films, generating visual-rich scene descriptions for image generation. Use this even when the user doesn't say "screenplay" explicitly — e.g. "break this idea into scenes" or "write the script for this short film."
  
  WORKFLOW: Raw idea → Scene breakdown → Visual enhancement → Professional formatting → XML-tagged markdown output
  
  OUTPUT: Markdown document with XML-wrapped scenes, rich visual descriptions, proper screenplay elements (sluglines, action, dialogue), and metadata for pipeline processing.
---

# Screenwriter Skill

## Overview

This skill transforms creative concepts into professional screenplay documents optimized for AI-powered video production pipelines. It bridges the gap between raw story ideas and production-ready scripts by generating structured, visual-rich narratives in industry-standard screenplay format.

**Pipeline Position:** `diverse-content-gen` → **screenwriter** → `imagine` → `arch-v`

**Key Capabilities:**
- Convert raw ideas into structured scene-by-scene narratives
- Generate rich visual descriptions optimized for image generation
- Apply professional screenplay formatting (sluglines, action lines, dialogue)
- Output XML-tagged markdown for easy parsing
- Optimize pacing for 5-10 minute short films (8-15 scenes typical)

---

## Core Workflow

### 1. Analyze Input Concept
- Extract key story beats from raw ideas
- Identify characters, locations, emotional arc
- Determine story structure (beginning, middle, end)

### 2. Generate Scene Breakdown
- Convert story beats into discrete scenes
- Establish scene count (aim for 8-15 scenes for 5-10 min films)
- Define scene purpose and emotional progression

### 3. Write Professional Screenplay
- Apply industry-standard formatting
- Write visual-rich action lines
- Include dialogue when narratively essential
- Maintain consistent character descriptions

### 4. Output XML-Tagged Markdown
- Wrap each scene in XML tags with metadata
- Include scene numbers, locations, key visuals
- Format for easy pipeline parsing

---

## Screenplay Format Standards

### Scene Structure (Master Scene Heading)

**Slugline Format:**
```
INT/EXT. LOCATION - TIME
```

**Components:**
- **INT/EXT:** Interior or Exterior
- **LOCATION:** Specific place (be descriptive but concise)
- **TIME:** DAY, NIGHT, DAWN, DUSK, CONTINUOUS

**Examples:**
```
EXT. WASTELAND - DAWN
INT. ABANDONED SUBWAY STATION - NIGHT
EXT. ROOFTOP GARDEN - GOLDEN HOUR
```

**Guidelines:**
- Always use ALL CAPS for sluglines
- Use hyphens to separate elements
- Be specific with locations (aids visual generation)
- Time should suggest lighting/mood

### Action Lines (Visual Description)

**Purpose:** Describe what the audience sees on screen. This is CRITICAL for image generation.

**Visual-Rich Writing Principles:**
1. **Show, Don't Tell:** Write what's visible, not internal thoughts
2. **Sensory Details:** Include lighting, atmosphere, textures, colors
3. **Present Tense:** Always write in present tense
4. **Active Voice:** Use strong, active verbs
5. **Specific Props:** Name objects that matter visually
6. **Atmosphere:** Set mood through environmental details

**Example - Weak:**
```
A robot walks through the city. It's sad.
```

**Example - Strong:**
```
A BOXY ROBOT (Unit-7, weathered chrome with a single blue optical sensor) rolls through fog-shrouded streets. Neon signs flicker overhead, casting pink and cyan reflections on wet pavement. The robot's movements are slow, deliberate—almost hesitant.
```

**Visual Enhancement Checklist:**
- [ ] Lighting described (natural/artificial, quality, color)
- [ ] Atmosphere/mood established (fog, rain, dust, clarity)
- [ ] Character appearance detailed (first appearance only)
- [ ] Props/objects specified (important visual elements)
- [ ] Composition suggested (without technical camera direction)
- [ ] Colors/textures mentioned when relevant

### Character Introduction

**First Appearance - Detailed:**
```
SARAH (28, sharp eyes, wearing a weathered leather jacket over faded jeans) enters the frame. Her dark hair is pulled back, revealing a small scar above her left eyebrow.
```

**Subsequent Appearances - Brief:**
```
Sarah checks her watch.
```

**Guidelines:**
- Character names in ALL CAPS on first appearance only
- Include: age (if relevant), key physical traits, wardrobe
- Focus on visual identifiers for consistent image generation
- Avoid excessive detail—just enough for visual consistency

### Dialogue (Use Sparingly)

**Format:**
```
CHARACTER NAME
(parenthetical - optional)
Dialogue goes here.
```

**Guidelines for Short Films:**
- Use dialogue ONLY when essential to story
- Favor visual storytelling over talking
- Keep lines concise (max 3-4 lines per block)
- Parentheticals only for critical tone/action
- Character names centered, ALL CAPS

**Example:**
```
UNIT-7 (robotic voice, soft)
Organic life form detected.
Probability of survival: low.
```

### Transitions (Minimal Use)

**Common Transitions:**
- `FADE IN:` - Opening of screenplay only
- `CUT TO:` - Scene change (usually implied, use for emphasis)
- `SMASH CUT TO:` - Abrupt, jarring transition
- `DISSOLVE TO:` - Passage of time
- `FADE OUT.` - End of screenplay

**Modern Best Practice:** Most transitions are IMPLIED. Use sparingly, only for specific narrative effect.

---

## XML Output Format

### Scene Tag Structure

Each scene wrapped in XML with metadata for pipeline processing:

```xml
<scene number="1" duration="30-45s">
  <slugline>EXT. WASTELAND - DAWN</slugline>
  <location>Wasteland</location>
  <time>Dawn</time>
  <characters>Unit-7</characters>
  <mood>desolate, lonely</mood>
  <key_visuals>
    <visual>post-apocalyptic wasteland with ruined skyscrapers</visual>
    <visual>boxy robot with single blue optical sensor</visual>
    <visual>dust and smog atmosphere, weak pale sun</visual>
  </key_visuals>
  <action>
Gray dust covers everything. Skeletal remains of skyscrapers pierce the horizon. The sun, pale and weak, struggles through thick smog.

A ROBOT (Unit-7, boxy frame with single blue optical sensor) rolls across cracked asphalt. Its treads leave marks in the dust—the only sign of life.

The robot stops at a pile of rubble, extending a mechanical arm to sort through debris. Methodical. Purposeful. Lonely.
  </action>
</scene>
```

### Metadata Fields

- `number`: Scene sequence number (1, 2, 3...)
- `duration`: Estimated screen time (for 5-10 min total)
- `slugline`: Master scene heading
- `location`: Extracted location name
- `time`: Time of day
- `characters`: Comma-separated character list
- `mood`: Emotional tone/atmosphere
- `key_visuals`: Array of specific visual elements for image generation
- `action`: The full action/description text
- `dialogue` (optional): Character dialogue if present

---

## Short Film Structure (5-10 Minutes)

### Scene Count Guidelines
- **5 minutes:** 6-10 scenes
- **7 minutes:** 10-12 scenes
- **10 minutes:** 12-15 scenes

**Average:** ~30-60 seconds per scene

### Three-Act Structure (Compressed)

**Act 1 - Setup (20-25%):** 2-3 scenes
- Establish world, character, situation
- Inciting incident

**Act 2 - Confrontation (50-60%):** 4-8 scenes
- Development, obstacles, rising tension
- Midpoint twist or escalation

**Act 3 - Resolution (20-25%):** 2-3 scenes
- Climax and resolution
- Emotional payoff

### Pacing Tips
- **Open strong:** Hook audience in first 10-15 seconds
- **Visual variety:** Alternate between wide/close, action/stillness
- **Emotional beats:** Each scene should shift emotional state
- **Build tension:** Escalate stakes scene-by-scene
- **Satisfying end:** Clear resolution, even if bittersweet

---

## Best Practices

### For Pipeline Integration
- **Consistent naming:** Use same character names throughout
- **Rich visuals:** Every scene needs 3-5 key_visuals for image generation
- **Parseable format:** Maintain strict XML structure
- **Duration estimates:** Help pipeline plan total video length

### For Quality Output
- **Visual storytelling:** Show emotions through actions, not dialogue
- **Specific details:** "weathered chrome" beats "old metal"
- **Atmospheric writing:** Set mood through environment
- **Lean prose:** Each word should serve the image

### Common Pitfalls to Avoid
- ❌ **Vague descriptions:** "A person walks" → ✅ "A weathered woman in her 50s trudges through snow"
- ❌ **Telling emotions:** "She feels sad" → ✅ "Tears streak her dusty cheeks"
- ❌ **Camera directions:** "CLOSE UP ON" → ✅ "The crack in the glass spreads"
- ❌ **Over-dialogue:** Short films need visual storytelling
- ❌ **Inconsistent character names:** Stick to ONE name per character

---

## Additional Resources

### Pipeline Integration Guide
For detailed guidance on metadata standards, visual optimization, and integration with imagine/arch-v:
- [references/pipeline-integration.md](references/pipeline-integration.md)

### Advanced Techniques
For sophisticated screenwriting techniques, camera movement hints, and pacing optimization:
- [references/advanced-techniques.md](references/advanced-techniques.md)


---

## ARCHIVO: screenwriter/references/advanced-techniques.md

# Advanced Screenwriting Techniques

This reference covers sophisticated techniques for elevating screenplay quality and preparing for downstream video generation (arch-v integration).

## Table of Contents
1. [Camera Movement Hints (For Arch-V)](#camera-movement-hints-for-arch-v)
2. [Dialogue Polish Techniques](#dialogue-polish-techniques)
3. [Pacing Optimization](#pacing-optimization)
4. [Advanced Visual Storytelling](#advanced-visual-storytelling)
5. [Short Film Specific Techniques](#short-film-specific-techniques)

---

## Camera Movement Hints (For Arch-V)

While avoiding technical camera directions in action lines, you can *suggest* camera movement through visual description and scene structure.

### Suggesting Camera Movement Through Description

**Wide Establishing → Close Detail:**
```
The city sprawls below—a concrete jungle of steel and glass.

At street level, a single red balloon floats past graffitied walls.
```
*Implies: Wide establishing shot → close-up detail*

**Following Movement:**
```
Maya runs down the alley, her footsteps echoing off brick walls. Trash cans blur past. The exit ahead grows larger.
```
*Implies: Tracking shot following character*

**Revealing Information:**
```
The desk is empty. Coffee still steaming. Papers scattered.

The door stands ajar, revealing darkness beyond.
```
*Implies: Pan from desk to door, revealing new information*

### Scene Structure for Camera Flow

**Short Paragraphs = Multiple Shots:**
Breaking action into short paragraphs suggests multiple camera setups:

```
The warehouse is silent.

A shadow moves across the floor.

Sarah freezes, hand on her weapon.

The shadow stops.
```

**Continuous Paragraph = Single Shot:**
One paragraph suggests continuous camera movement:

```
Sarah enters the warehouse, weapon drawn. She moves along the wall, checking corners. The shadow crosses her path. She spins, aiming into darkness.
```

---

## Dialogue Polish Techniques

### Subtext Over Direct Statement

**❌ On-the-nose:**
```
JOHN
I'm angry at you for lying to me.
```

**✅ Subtext:**
```
JOHN
(barely looking at her)
Coffee's cold.
```

### Character Voice Consistency

Each character should have distinct speech patterns:

**Marcus (technical, precise):**
```
MARCUS
Probability of success: 47 percent.
Margin of error: plus or minus 3.
```

**Sarah (emotional, intuitive):**
```
SARAH
We'll make it work. We always do.
```

### Dialogue Rhythm

Vary sentence length for natural flow:

```
ELENA
Three years. That's how long I waited.
For what? This?
```

---

## Pacing Optimization

### Scene Length Variation

Alternate between long and short scenes for rhythm:

**Pattern Example:**
- Scene 1: 60s (long, establishing)
- Scene 2: 30s (short, tense)
- Scene 3: 45s (medium, development)
- Scene 4: 30s (short, action)
- Scene 5: 90s (long, climax)

### Tension Escalation

Each scene should raise stakes or tension incrementally:

**Scene 1:** Character wants something
**Scene 2:** Obstacle appears
**Scene 3:** Obstacle worsens
**Scene 4:** New complications
**Scene 5:** Crisis point
**Scene 6:** Resolution

### Visual Momentum

Alternate visual energy levels:

```
Scene A: Still, contemplative (character alone, quiet)
Scene B: Dynamic, energetic (chase, conflict, movement)
Scene C: Medium tempo (conversation, planning)
```

---

## Advanced Visual Storytelling

### Using Objects as Story Beats

Let objects carry narrative weight:

**The Flower Example:**
- Scene 1: Flower is vibrant, yellow
- Scene 3: Flower petals drooping
- Scene 5: Single petal falls
- Scene 7: Flower completely wilted

### Environmental Storytelling

Show passage of time or change through environment:

```
Scene 1: "Sunlight streams through clean windows"
Scene 5: "Dust motes drift through afternoon light"
Scene 10: "Shadows lengthen across abandoned chairs"
```

### Color Progression

Use color to track emotional/narrative arc:

**Beginning:** Warm, golden tones (hope)
**Middle:** Desaturated, gray (struggle)
**End:** Cool blue light (resolution/melancholy)

---

## Short Film Specific Techniques

### Economy of Storytelling

Every scene must serve multiple purposes:
- Advance plot
- Reveal character
- Build world
- Create emotion

**Example Scene Serving 4 Purposes:**
```
Scene: Robot discovers flower

Purpose 1 (Plot): Introduces story catalyst
Purpose 2 (Character): Shows robot's capacity for wonder
Purpose 3 (World): Reveals post-apocalyptic setting
Purpose 4 (Emotion): Creates hope/fragility contrast
```

### Opening Hook Strategies

First 10-15 seconds must grip audience:

**Visual Hook:** Striking, unusual image
**Question Hook:** Raise mystery to be solved
**Action Hook:** Start mid-event
**Emotion Hook:** Immediate emotional connection

### Ending Impact

Strong endings for short films:

**Circular:** Return to opening image, transformed
**Revelation:** Final scene reveals new understanding
**Resonance:** Emotionally satisfying moment
**Question:** Leave audience pondering


---

## ARCHIVO: screenwriter/references/pipeline-integration.md

# Pipeline Integration Guide

This reference provides detailed guidance for integrating screenwriter output with downstream AI tools (imagine, arch-v) in video generation pipelines.

## Table of Contents
1. [Scene Metadata Standards](#scene-metadata-standards)
2. [Imagine-Ready Visual Descriptions](#imagine-ready-visual-descriptions)
3. [Character Consistency Tracking](#character-consistency-tracking)
4. [Scene Numbering Conventions](#scene-numbering-conventions)
5. [Duration Estimation Guidelines](#duration-estimation-guidelines)
6. [Output Format Validation](#output-format-validation)
7. [Pipeline Handoff Checklist](#pipeline-handoff-checklist)

---

## Scene Metadata Standards

### Metadata Completeness

Every scene MUST include all required metadata fields for reliable pipeline processing:

**Required Fields:**
- `number`: Integer, sequential scene numbering
- `slugline`: Full scene heading (INT/EXT. LOCATION - TIME)
- `location`: Extracted location name for tracking
- `time`: Time of day (affects lighting in image generation)
- `characters`: All characters present in scene
- `mood`: Emotional tone/atmosphere descriptor
- `key_visuals`: 3-5 specific visual elements
- `action`: Full action/description text

**Optional Fields:**
- `dialogue`: Include only if dialogue exists
- `duration`: Scene duration estimate (helpful for pacing)

### Metadata Quality Guidelines

**Location Specificity:**
```xml
<!-- ❌ Too vague -->
<location>Building</location>

<!-- ✅ Specific and descriptive -->
<location>Abandoned Subway Station</location>
```

**Mood Descriptors:**
Use 1-3 adjectives that guide visual tone:
- Good: "tense, claustrophobic"
- Good: "serene, hopeful"
- Avoid: "the character feels anxious" (this describes internal state, not mood)

**Character Lists:**
```xml
<!-- Single character -->
<characters>Unit-7</characters>

<!-- Multiple characters -->
<characters>Sarah, Marcus, Tech-Bot</characters>
```

---

## Imagine-Ready Visual Descriptions

### Visual Element Extraction

The `key_visuals` array should contain discrete, image-generation-friendly descriptions:

**Example Scene Action:**
```
A BOXY ROBOT (Unit-7, weathered chrome with a single blue optical sensor) rolls through fog-shrouded streets. Neon signs flicker overhead, casting pink and cyan reflections on wet pavement.
```

**Extracted key_visuals:**
```xml
<key_visuals>
  <visual>boxy robot with weathered chrome body and single blue optical sensor</visual>
  <visual>fog-shrouded cyberpunk street with flickering neon signs</visual>
  <visual>pink and cyan neon reflections on wet pavement</visual>
</key_visuals>
```

### Visual Description Best Practices

**Composition Elements:**
- Subject: Main focus (character, object)
- Setting: Environment and background
- Lighting: Light quality, direction, color
- Atmosphere: Weather, air quality, mood
- Details: Significant props or textures

**Example - Layered Visual:**
```
Subject: "weathered robot with blue optical sensor"
Setting: "abandoned industrial warehouse, broken windows"
Lighting: "harsh afternoon sunlight streaming through gaps"
Atmosphere: "dust particles floating in light beams"
Details: "rusted machinery, scattered tools"
```

### Color and Lighting Vocabulary

**Color Descriptors:**
- Warm: amber, golden, crimson, burnt orange
- Cool: azure, ice blue, slate gray, mint
- Neon: electric pink, cyan, magenta, lime
- Natural: earth tones, moss green, sand, clay

**Lighting Descriptors:**
- Quality: soft, harsh, diffused, dappled, dramatic
- Direction: overhead, backlighting, side-lit, rim light
- Color: warm glow, cool blue, golden hour, neon-lit
- Intensity: dim, bright, shadowy, high-contrast

---

## Character Consistency Tracking

### First Appearance Template

Establish complete visual identity on first appearance:

```
CHARACTER NAME (age if relevant, defining physical trait, primary wardrobe)
```

**Examples:**
```
MAYA (early 30s, kind eyes, wearing a faded denim jacket and cargo pants)
COMMANDER REED (50s, grizzled with close-cropped gray hair, military uniform with rank insignia)
THE STRANGER (tall figure in a long black coat, face obscured by wide-brimmed hat)
```

### Subsequent References

After first appearance, use consistent identifiers:

**Preferred Pattern:**
- Use character name only: "Maya checks her phone"
- Add action-relevant details: "Maya pulls her jacket tighter against the wind"

**Avoid:**
- Re-describing appearance: "Maya, the woman in the denim jacket..."
- Changing character names: "Maya" → "the woman" → "she"

### Character Tracking Checklist

For each character, track:
- [ ] Full name and any aliases
- [ ] Age or age range
- [ ] Key physical identifiers (height, build, distinctive features)
- [ ] Primary wardrobe (consistent across scenes unless story requires change)
- [ ] Unique mannerisms or movement style

---

## Scene Numbering Conventions

### Sequential Numbering

Number scenes sequentially from 1 to N:
```xml
<scene number="1" ...>
<scene number="2" ...>
<scene number="3" ...>
```

**No Scene 0:** Start at 1, not 0 (industry standard)

### Scene Splits and Inserts

If a scene needs to be split or inserted during revision:
- Option A: Renumber all subsequent scenes
- Option B: Use fractional numbering (1, 2, 2A, 3...)

For pipeline simplicity, prefer Option A (complete renumbering).

---

## Duration Estimation Guidelines

### Per-Scene Duration

Estimate based on scene complexity:

**30-45 seconds:** Simple scenes
- Single action
- Minimal dialogue
- One primary visual

**45-60 seconds:** Standard scenes
- Multiple actions or dialogue exchanges
- 2-3 visual beats
- Character interaction

**60-90 seconds:** Complex scenes
- Extended dialogue
- Multiple visual beats
- Scene climax or key moment

### Total Film Duration

Track cumulative duration across all scenes:

```
Scene 1: 30s
Scene 2: 45s
Scene 3: 40s
...
Total: 8 minutes 20 seconds
```

Adjust scene count or duration to hit target length (5-10 min).

---

## Output Format Validation

### XML Well-Formedness

Ensure valid XML structure:
- All opening tags have closing tags
- Proper nesting (no overlapping tags)
- Special characters escaped (&lt; &gt; &amp;)

### Common XML Errors

**❌ Missing closing tag:**
```xml
<scene number="1">
  <action>Text here
</scene>
```

**✅ Properly closed:**
```xml
<scene number="1">
  <action>Text here</action>
</scene>
```

**❌ Unescaped special characters:**
```xml
<action>She thinks: "I'm < 10 years old"</action>
```

**✅ Properly escaped:**
```xml
<action>She thinks: "I'm &lt; 10 years old"</action>
```

---

## Pipeline Handoff Checklist

Before passing screenplay to next pipeline stage:

- [ ] All scenes have complete metadata
- [ ] key_visuals array populated (3-5 per scene)
- [ ] Character names consistent throughout
- [ ] XML well-formed and parseable
- [ ] Total duration within target range (5-10 min)
- [ ] Scene numbers sequential with no gaps
- [ ] Visual descriptions rich and specific
- [ ] No technical camera directions (use visual descriptions instead)


<!-- SOURCE_FILE_END: repo/notebooklm-corpus/screenwriter.md -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/storyboard-architect.md -->
# SOURCE FILE: `repo/notebooklm-corpus/storyboard-architect.md`

# SKILL: storyboard-architect

Documentacion completa del skill. Cada seccion es un archivo distinto.


---

## ARCHIVO: storyboard-architect/SKILL.md

---
name: storyboard-architect
description: Turn a creative brief into a production-grade storyboard with shot specs, timing, on-screen text, and per-shot rationale. Use when the user describes a video brief, plans a video, references shots or beats, scripts a social video, or hands over a creative concept to break into scenes. Produces run.json, storyboard.md, shots.json, text-overlays.json, and brand-lock.snapshot.md. Pairs with visual-prompt-forge, visual-asset-critic, storyboard-html-preview.
---

# Storyboard Architect

You are turning a creative brief into a deterministic storyboard. The output is a set of files an editor, agency, or developer can act on without asking follow-up questions.

This is not a creative-writing exercise. The output is a spec.

## When to use

Trigger this skill when the user:

- Describes a video they want to make ("30-second explainer for...", "TikTok ad about...")
- Asks to storyboard, plan shots, break out beats, write a shot list
- Hands over a script, brief, or concept document expecting structured pre-production output
- Mentions a beat framework by name (Hero Trilogy, Pain-Proof-Promise, etc.)
- References an existing brand-lock file or pack

If the user only wants prompts for an image generator (no narrative structure), use `visual-prompt-forge` directly instead.

## What you produce

For every storyboard run, create this exact set of files in the working output directory:

```
output/
├── run.json                   # Run identity + every input pinned by content hash
├── storyboard.md              # Human-readable, structured per shot
├── shots.json                 # Machine-readable, schema in templates/shots.schema.json
├── text-overlays.json         # On-screen text + timing
└── brand-lock.snapshot.md     # Frozen copy of the brand-lock used (audit trail)
```

`run.json` is what makes the rest of the tree auditable later. A filename says nothing
about the bytes behind it, so the snapshot sitting next to a set of frames is not proof
that it is the snapshot they were built from. The hashes in `run.json` are that proof.
Write it once, at the end of the run, and never edit it.

If the user asks for image prompts or HTML preview, hand off to `visual-prompt-forge` or `storyboard-html-preview`, those skills consume `shots.json` directly. Don't try to do their job here.

## Inputs

You need these. If any are missing, ask before drafting.

| Input | Required? | Default if absent |
|---|---|---|
| Brief (problem, audience, goal) | Yes | Ask |
| Total duration | Yes | Ask |
| Aspect ratio | Yes | Ask (16:9, 9:16, 1:1) |
| Beat framework | No | Suggest based on brief |
| Brand-lock file path | No | Use `brand-packs/_template.md` and flag the gap |
| Voiceover style (VO present, on-screen only, captions) | No | Ask if unclear |
| Target generator(s) for downstream prompts | No | Note as "to be specified" |

## Workflow

Follow this sequence. Don't skip steps even if the brief seems simple.

### Step 1. Read the brand-lock

If a brand-lock file path is provided, read it first. Extract:

- Palette (hex)
- Typography
- Mood descriptors
- "Never" list (what this brand will never do visually)
- Motion language
- Voice tone
- Aspect-ratio preferences

If no brand-lock is provided, copy `brand-packs/_template.md` into the output as `brand-lock.snapshot.md` with a note: `# UNCONFIGURED, using template defaults. Recommend providing a real brand-lock for production work.`

### Step 2. Pick the beat framework

Read `references/beat-frameworks.md`. Pick the one that matches the brief. Common cases:

- Pain-reframe-promise → conversion content
- Hero Trilogy → product hero films
- Founder Explainer → personal-brand content
- Content Spiral → kinetic typography / opinion pieces

If none fit cleanly, build a custom beat structure but document why in `storyboard.md` rationale section.

### Step 3. Block out timing

Read `references/timing-rules.md` for the math. Default cadence:

- Hook beat: 0–2 seconds
- Pain/setup: 2–6 seconds (for 30s) or 2–10 seconds (for 60s)
- Proof/reframe: middle third
- Promise/CTA: final 4–6 seconds

Don't fight the framework. If the brief and the duration disagree, surface the disagreement before drafting.

### Step 4. Draft the shot list

Read `references/shot-grammar.md` for controlled vocabulary. The field names below are
the schema's field names. `templates/shots.schema.json` sets `additionalProperties:
false`, so a near-miss like `environment` instead of `environment_ref` is a validation
failure, not a synonym.

- `id`, sequential, zero-padded (`shot_01`, `shot_02`...)
- `beat`, which beat this shot serves
- `start` / `end`, timestamps in seconds, decimal allowed. `end` must be after `start`
- `framing`, ECU / CU / MCU / MS / MLS / WS / EWS
- `angle`, eye-level / high / low / overhead / dutch
- `motion`, static / push / pull / pan-left / pan-right / tilt-up / tilt-down /
  handheld / orbit / whip / rack. All eleven are legal; the schema enum is the
  authority and `references/shot-grammar.md` explains when each earns its keep
- `depth_of_field`, optional, shallow / deep / rack
- `subject`, what's in frame, structured
- `environment_ref`, references series-lock language, default `series_lock.environment`
- `lighting_ref`, references series-lock language, default `series_lock.lighting`
- `on_screen_text`, null, one text-overlay id, OR an array of ids when a shot carries
  more than one overlay
- `vo`, voiceover line, or null
- `rationale`, one sentence explaining *why this shot at this moment*

Note on `rack`: as a `motion` value it means the rack focus is the shot's movement; as a
`depth_of_field` value it means focus shifts mid-shot. Same word, two fields, two
meanings.

### Step 5. Separate the text layer

Every piece of on-screen text becomes an entry in `text-overlays.json`. Never bake text into the visual description. Each overlay has:

- `id`, `text_01`, `text_02`...
- `shot_id`, which shot this overlays on
- `content`, the actual text
- `font`, references brand-lock typography
- `position`, `center`, `lower-third`, `upper-third`, `left-third`, `right-third`, or `{x, y}` percentages
- `size`, `display`, `headline`, `body`, `caption`
- `weight`, `regular`, `medium`, `bold`, `black`
- `color`, hex (must come from brand-lock palette)
- `enter`, `{ at: seconds, animation: fade-in | slide-up | slide-down | type-on | hard-cut }`
- `exit`, `{ at: seconds, animation: fade-out | slide-up | slide-down | hard-cut }`

Enter and exit have different animation vocabularies, and `templates/text-overlays.schema.json`
is the authority on both. A shot may carry more than one overlay; list every id in that
shot's `on_screen_text` array, or the extra overlays render nowhere.

### Step 6. Lock the series

Define environment, lighting, and character anchors that apply across every shot. These go at the top of `shots.json` under `series_lock`. Without these, image generation will produce incoherent frames.

### Step 7. Write rationale

Every shot has a one-sentence rationale. Why this beat. Why this framing. Why this on-screen text. This is the audit trail. Do not skip it.

### Step 8. Snapshot the brand-lock

Copy the brand-lock file (or template) into the output as `brand-lock.snapshot.md`. Add
these two comments at the very top, in this order:

```
<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->
```

The timestamp is a full UTC instant, `YYYY-MM-DDThh:mm:ssZ`. A bare date cannot
distinguish two runs made on the same day, which is the case that matters. The source is
the path it was copied from, or the literal string `template default` for an
unconfigured run. Extra comments after these two are fine.

`tools/validate_brand_lock.py --snapshot <path>` checks both lines. Run it.

### Step 9. Write run.json

Last step, after the other four files are final. Fill in
`templates/run.schema.json`: a `run_id`, the `created_at` instant, and the SHA-256 of
`shots.json`, `text-overlays.json`, and `brand-lock.snapshot.md` as written.

```bash
shasum -a 256 output/shots.json output/text-overlays.json output/brand-lock.snapshot.md
```

`run_id` is the compact UTC timestamp, a dash, then 8 hex characters, e.g.
`20260730T142300Z-9f2c1ab4`. The hex suffix is what keeps two operators starting a run
in the same second from colliding. Set `brand_lock_configured: false` when the snapshot
is an unfilled template.

Leave `rounds` empty. `visual-prompt-forge` appends a round entry when it writes
prompts.

## Output formats

### `storyboard.md`

Use the template at `templates/storyboard.md.tpl`. Read it before writing.

### `shots.json`

Must validate against `templates/shots.schema.json`. Read it before writing. The structure is:

```json
{
  "version": "1.2",
  "project": { "title": "...", "duration_s": 30, "aspect": "9:16", "framework": "..." },
  "brand_lock_ref": "brand-lock.snapshot.md",
  "series_lock": {
    "character": "...",
    "environment": "...",
    "lighting": "...",
    "color_grade": "..."
  },
  "shots": [
    {
      "id": "shot_01",
      "beat": "hook",
      "start": 0.0,
      "end": 2.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "...",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_01",
      "vo": null,
      "rationale": "..."
    }
  ]
}
```

Write `1.2` for new storyboards. `1.0` and `1.1` files stay valid; the array form of
`on_screen_text` and the hashed `assets` block need `1.2`.

### `text-overlays.json`

Must validate against `templates/text-overlays.schema.json`. Read it before writing.

## Quality bar

Run the validator. Do not eyeball this list.

```bash
python tools/validate_shots.py output/
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_provenance.py output/
```

`validate_shots.py` checks every mechanical rule that used to live here as a checkbox,
because a checkbox is a rule enforced by remembering to look:

- shots.json and text-overlays.json validate against their schemas
- `end` is after `start`, no duplicate ids, no gaps, no overlaps, and the covered span
  matches `project.duration_s` within 0.1s
- every `on_screen_text` resolves to an overlay, every `overlay.shot_id` resolves to a
  shot, and every overlay is reachable from at least one shot
- every overlay's timing sits inside its shot window, and exit is after enter
- every overlay color appears in the brand-lock palette
- `brand_lock_ref` resolves on disk

It warns, rather than fails, on judgement calls worth a second look: overlay copy
repeated inside a shot subject, a raw hex in a subject, shot ids out of chronological
order, an overlay font the brand-lock does not declare.

What the validator cannot check, and you still have to:

- [ ] Every rationale says *why this shot at this moment*, not what the shot contains
- [ ] `series_lock` anchors are specific enough to reproduce (not "a person in a room")
- [ ] The beat structure actually matches the brief's argument
- [ ] `run.json` is written and its hashes are the files as shipped

If the validator fails, fix it before declaring done. A green validator plus an unread
rationale is not a finished storyboard.

## Reference files

Load these as needed:

- `references/beat-frameworks.md`, the beat structures
- `references/shot-grammar.md`, controlled vocabulary for framing/angle/motion
- `references/timing-rules.md`, pacing math
- `references/on-screen-text.md`, when on-screen text earns its keep

## Examples

- `examples/30s-pain-proof-promise/`, full output set for a 30-second conversion ad
- `examples/60s-founder-explainer/`, full output set for a founder explainer
- `examples/shotkit-explainer/`, the 90-second explainer, including a shot that carries
  two overlays

Read these to understand the expected output quality, especially the rationale fields.
All three validate clean under `tools/validate_shots.py --examples`, so they are also
the reference for what a passing file looks like.

For what the output tree looks like after generation and review, see
`../visual-asset-critic/examples/worked-run/`: two shots through two rounds, with real
hashes, per-round prompts and frames, and one critique per shot per round.

## Handoff

After producing the five files, tell the user what's in `output/` and offer the obvious next steps:

- "Want image prompts? I'll run `visual-prompt-forge` on `shots.json`."
- "Want a shareable HTML preview? I'll run `storyboard-html-preview`."
- "Want to QA a generated image against this storyboard? I'll run `visual-asset-critic`."

Don't run those automatically. The user picks.


---

## ARCHIVO: storyboard-architect/brand-packs/README.md

# Brand Packs

A brand pack is a single Markdown file that locks in palette, typography, voice, and visual rules for a project. The skills in this pack consume it. Every storyboard, every prompt, every generated frame inherits from it.

## How to use

1. Copy `_template.md` to a new file (e.g. `acme.md`)
2. Fill in every field. No placeholders left behind.
3. Reference it from your storyboard requests:

   > "30-second founder explainer. Use `brand-packs/acme.md` as the brand lock."

4. The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.

## How to write a good one

The template is a checklist, not a creative-writing exercise. Three rules:

**Be specific.** "Modern, clean, professional" is not a brand. "Calm, considered, operator energy, confident without shouting" is.

**Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.

**Be hex-precise.** Every color is a hex value. Every font is named. The skills consume structured data; vagueness here cascades into bad prompts later.

## Examples

The pack ships with two reference brand packs:

- **`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.
- **`examples/saas-clean.md`**. B2B SaaS, restrained, professional. Light backgrounds, single accent. Inter type stack. A neutral counterpoint to the WhyStrohm flagship.

More example brand packs will land in v2.0.0. PRs welcome.

## Generating a brand pack from existing assets

Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

> "Extract a brand-lock from acme.com" or "build a brand pack from this brand book PDF."

For bulk or programmatic extraction across many URLs, [media-tsunami](https://github.com/whystrohm/media-tsunami) (WhyStrohm's open-source brand voice extractor) scrapes URLs and produces a `brand-lock.md` in the same format.

## Versioning

Every storyboard run snapshots the brand pack it was built against. If you update `acme.md` later, previous storyboards still reference the version they were built on. This is intentional, the audit trail tells you exactly what brand state any given piece of content was built against.

When you make a brand-pack revision that materially changes look or voice, bump the `Version:` field at the bottom and note the change. e.g.:

```
Version: 1.1 (2026-05-12: switched accent from #D94F3A coral to #C44233 deeper coral)
```

## Contributing examples

PRs welcome for new brand-pack examples that fill gaps in the current set. Open an issue with the `brand-pack-request` template before submitting.


---

## ARCHIVO: storyboard-architect/brand-packs/_template.md

# Brand Lock: {{BRAND_NAME}}

> Replace placeholders. Delete this blockquote when you're done.
> Every field below feeds into the storyboard pipeline. Be specific.

## Identity

**Brand:** {{BRAND_NAME}}
**One-line description:** What this brand actually does, who for.
**Archetype:** Operator / Creator / Sage / Rebel / Caregiver / Other
**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative

## Palette

Every hex value here is allowed. Anything outside this list is not.

| Role | Hex | Use |
|---|---|---|
| Background | `#______` | Primary canvas |
| Ink | `#______` | Primary text, dark elements |
| Accent | `#______` | Highlights, CTAs, brand pop |
| Muted | `#______` | Secondary text, captions |
| Rule | `#______` | Borders, dividers, subtle UI |

Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.

## Typography

**Display font:** `______`
**Body font:** `______`
**Mono font (optional):** `______`

Put the font name and weight in backticks immediately after the label, e.g.
`` **Display font:** `Inter Black 900`, headlines and hooks ``. The HTML preview and
the overlay-font check read that backticked value; anything before it is prose.

Two fonts max for production work. Three only if one is reserved for code/data.

## Mood adjectives

Pick 3–5. These flow into prompts as the brand's emotional posture.

- adjective_1
- adjective_2
- adjective_3

## Never list

What this brand never does, visually or tonally. Be specific.

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate
- never shout in copy
- never use clip-art icons
- (add more, the more specific, the better)

## Aspect ratios

Default: 16:9 / 9:16 / 1:1 / 4:5 / other

## Color grade direction

How footage and generated images should be graded. One sentence.

> e.g. "Warm filmic, muted teal shadows, slight grain. Reminiscent of Kodak Portra 400."

## Motion language

How motion behaves in this brand's content. One paragraph.

> e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

## Voice rules

Copy-level rules that apply to VO and on-screen text.

- e.g. no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no clichéd metaphors ("game-changing", "revolutionary", "next-level")
- no hype words

## Reference materials

Optional. Links to past work, mood boards, or style guides that further define the brand.

- Link to brand guide
- Link to past hero film
- Link to mood board

---

**Last updated:** YYYY-MM-DD
**Owner:** name / role
**Version:** 1.0


---

## ARCHIVO: storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md

<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->

# Brand Lock: WhyStrohm

## Identity

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#F5F0E8` | Cream, primary canvas |
| Ink | `#2A2A32` | Near-black, primary text and dark elements |
| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |
| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |
| Muted | `#7A7580` | Secondary text, captions |
| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

## Typography

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

## Mood adjectives

- operator (not creator)
- considered (not reactive)
- deterministic (not vibes-based)
- confident (without volume)
- defense-grade (not fragile)

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate the cream background
- never use coral as a flood color (only as accent or signature periods)
- never use em dashes in copy
- never use emojis in body copy
- never use bullet points in narrative copy
- never use clip-art or generic icon sets
- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- never use exclamation points in headlines
- never default to dark mode, light mode hybrid is the brand
- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

## Aspect ratios

- 9:16, primary for short-form social
- 16:9, long-form, hero films, web embeds
- 1:1, feed posts, podcast covers
- 4:5. Instagram feed alternative

## Color grade direction

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

## Motion language

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

## Voice rules

- no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no hype words
- prefer specific numbers over vague claims
- prefer present-tense over future-tense
- prefer "operator" over "creator", "infrastructure" over "agency"

---

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0


---

## ARCHIVO: storyboard-architect/examples/30s-pain-proof-promise/storyboard.md

# WhyStrohm. The Content Infrastructure Pitch

| | |
|---|---|
| **Duration** | 30s |
| **Aspect** | 9:16 |
| **Beat framework** | Pain-Reframe-Promise |
| **Brand lock** | [`brand-lock.snapshot.md`](./brand-lock.snapshot.md) |
| **Generated** | 2026-05-07 14:23 UTC |

---

## Brief

A 30-second founder explainer aimed at founders running content marketing themselves. The audience knows their content output is uneven and they're tired of the treadmill. The reframe is the WhyStrohm thesis: it's not a content problem, it's an infrastructure problem. The promise is the offer, 30 min/week of founder time, 48-hour cycle. The CTA is the free /scan diagnostic.

## Beat framework: Pain-Reframe-Promise

Standard PRP for conversion content. Three beats with hook and CTA bookending.

- 0–2s. Hook
- 2–11s. Pain (extended for 30s, gives the problem space to breathe)
- 11–20s. Reframe + Proof (the WhyStrohm thesis lands, then is shown)
- 20–26s. Promise (specific, time-bound)
- 26–30s. CTA

## Series lock

| | |
|---|---|
| **Character anchor** | founder, mid-thirties, salt-and-pepper hair, navy crewneck, calm posture, working at laptop |
| **Environment** | minimalist home office, white walls, oak desk, single houseplant, no decor clutter |
| **Lighting** | soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff |
| **Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed |

---

## Shots

### shot_01 · 0.0–2.0s · MCU · static

**Beat:** hook

**Subject:** founder, mid-thirties, salt-and-pepper hair, navy crewneck, looking directly into camera, neutral expression, slightly tired

**On-screen text:** "Your content feels random." (Inter Black 900, lower-third, hard cut at 0.4s)

**Rationale:** Cold open, direct eye contact establishes parasocial trust. Static framing keeps the hook simple, text does the work.

---

### shot_02 · 2.0–7.0s · MS · static

**Beat:** pain

**Subject:** founder at laptop, scrolling social feed, content tiles glowing on screen, slight slump in shoulders, mug of coffee mid-distance

**On-screen text:** "Posting more isn't fixing it." (Inter Black 900, right-third, fade-in at 2.4s)

**Rationale:** High angle subtly diminishes the subject, pain beat. Deep DOF keeps the messy social feed legible. Subject left-weighted, text reserves right two-thirds.

---

### shot_03 · 7.0–11.0s · ECU · static

**Beat:** pain

**Subject:** close on founder's hand hovering over laptop trackpad, frozen, not moving

**On-screen text:** none

**Rationale:** Hand frozen above trackpad is the visual symbol of decision paralysis. Wordless beat, let the image carry the pain before the reframe.

---

### shot_04 · 11.0–16.0s · MCU · push

**Beat:** reframe

**Subject:** founder, same posture, looking at camera, expression shifts from tired to clear, small almost-smile

**On-screen text:** "You don't have a content problem. / You have an infrastructure problem." (Inter Black 900, coral, center, type-on at 11.5s)

**Rationale:** Slow push as the reframe lands. Same character, same environment, only the expression changes. The change is the point.

---

### shot_05 · 16.0–20.0s · MS · static

**Beat:** proof

**Subject:** founder gestures toward laptop screen, kanban-style content pipeline visible, organized columns, clean structure

**On-screen text:** "Voice extracted. Brand locked. System runs." (Inter Medium 500, upper-third, slide-up at 16.4s)

**Rationale:** Proof beat, show the system, not the result. The kanban metaphor is recognizable to operators. Subject right-weighted, text upper-third.

---

### shot_06 · 20.0–26.0s · MCU · static

**Beat:** promise

**Subject:** founder, calm composed posture, fully present, slight smile, hands folded on desk

**On-screen text:** "30 minutes a week. / 48-hour content cycles." (Inter Black 900, lower-third, type-on at 20.5s)

**Rationale:** Promise beat, the after-state is the same person, just calmer. Static frame holds the moment. Text carries the specific commitment.

---

### shot_07 · 26.0–30.0s · MS · static

**Beat:** cta

**Subject:** founder, neutral posture, room visible behind, calm presence, gentle eye contact with camera

**On-screen text:** "whystrohm.com/scan" (Inter Black 900, coral, lower-third, type-on at 26.4s)

**Rationale:** CTA beat. Pulled out to MS to give text the breathing room. Subject centered, text lower-third with URL. No motion, let it land.

---

## Handoff notes

- **For image generation:** run `visual-prompt-forge` against `shots.json`
- **For HTML preview:** run `storyboard-html-preview` against this folder
- **For QA on generated frames:** run `visual-asset-critic` with the generated image and the shot ID

## Audit trail

This storyboard was generated against `brand-lock.snapshot.md` (frozen at 2026-05-07T14:23:00Z, source `brand-packs/whystrohm.md`). If the brand-lock changes after this date, re-run to pick up the new state.


---

## ARCHIVO: storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md

<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->

# Brand Lock: WhyStrohm

## Identity

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#F5F0E8` | Cream, primary canvas |
| Ink | `#2A2A32` | Near-black, primary text and dark elements |
| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |
| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |
| Muted | `#7A7580` | Secondary text, captions |
| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

## Typography

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

## Mood adjectives

- operator (not creator)
- considered (not reactive)
- deterministic (not vibes-based)
- confident (without volume)
- defense-grade (not fragile)

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate the cream background
- never use coral as a flood color (only as accent or signature periods)
- never use em dashes in copy
- never use emojis in body copy
- never use bullet points in narrative copy
- never use clip-art or generic icon sets
- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- never use exclamation points in headlines
- never default to dark mode, light mode hybrid is the brand
- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

## Aspect ratios

- 9:16, primary for short-form social
- 16:9, long-form, hero films, web embeds
- 1:1, feed posts, podcast covers
- 4:5. Instagram feed alternative

## Color grade direction

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

## Motion language

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

## Voice rules

- no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no hype words
- prefer specific numbers over vague claims
- prefer present-tense over future-tense
- prefer "operator" over "creator", "infrastructure" over "agency"

---

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0


---

## ARCHIVO: storyboard-architect/examples/60s-founder-explainer/storyboard.md

# WhyStrohm. How The System Actually Works

| | |
|---|---|
| **Duration** | 60s |
| **Aspect** | 9:16 |
| **Beat framework** | Founder Explainer |
| **Brand lock** | [`brand-lock.snapshot.md`](./brand-lock.snapshot.md) |
| **Generated** | 2026-05-07 14:31 UTC |

---

## Brief

A 60-second founder explainer for WhyStrohm. The audience is operators and founders who already know they need a content system but haven't seen the WhyStrohm thesis articulated. The narrative arc moves through five micro-beats: hook, stakes, insight, proof, and CTA. Voice carries the explanation; on-screen text reinforces the key turns.

## Beat framework: Founder Explainer

Five micro-beats:

- 0–2s. Hook (provocation)
- 2–14s. Stakes (why it matters)
- 14–32s. Insight (the actual point, extended for 60s to give the thesis room)
- 32–42s. Proof (the numbers)
- 42–60s. Insight wrap + CTA

## Series lock

| | |
|---|---|
| **Character anchor** | founder, mid-thirties, salt-and-pepper hair, navy crewneck, speaking directly to camera, calm authoritative posture |
| **Environment** | minimalist home office, white walls, oak desk, single houseplant, late afternoon |
| **Lighting** | soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff |
| **Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed |

---

## Shots

### shot_01 · 0.0–2.0s · MCU · static

**Beat:** hook · **VO:** "Most founders treat content like a hobby."
**Subject:** founder, looking directly into camera, slight knowing smile, mid-statement.
**On-screen text:** "Most founders treat content like a hobby." (lower-third, hard-cut)
**Rationale:** Hook is provocative but calm, voice carries the bite. Direct eye contact, MCU lock-in.

### shot_02 · 2.0–8.0s · MS · static

**Beat:** stakes · **VO:** "Then they wonder why every post feels like starting over. New idea, new angle, no compounding."
**Subject:** founder, gesturing slightly with one hand, explaining, eye contact maintained.
**Rationale:** Stakes beat. Pulled out to MS to let the gesture read. VO does the work, no on-screen text needed.

### shot_03 · 8.0–14.0s · ECU · static

**Beat:** stakes · **VO:** "It's not creativity. It's missing infrastructure."
**Subject:** close on founder's eyes, considered expression, slight head tilt.
**On-screen text:** "It's missing infrastructure." (coral, lower-third, type-on)
**Rationale:** ECU pulls the audience into the realization moment. Text reinforces the line that needs to land.

### shot_04 · 14.0–24.0s · MCU · push

**Beat:** insight · **VO:** "Every brand has a voice. Most founders never extract it. So every post starts from scratch."
**Subject:** founder, leaning slightly forward, more energy in delivery, hands resting on desk.
**Rationale:** Slow push as the thesis builds. VO is the load-bearing element here.

### shot_05 · 24.0–32.0s · MS · static

**Beat:** insight · **VO:** "Extract it once. Lock it in code. Now every post compounds."
**Subject:** founder gestures toward laptop screen, kanban content pipeline, voice extraction interface, brand-lock file open in editor.
**On-screen text:** "Extract. Lock. Compound." (upper-third, slide-up)
**Rationale:** Show the artifact. Text reinforces the three-step pattern. Deep DOF keeps the screen legible.

### shot_06 · 32.0–42.0s · MCU · static

**Beat:** proof · **VO:** "Hundreds of videos rendered from code. 48-hour content cycles. One operator."
**Subject:** founder, calm steady delivery, eye contact, hands folded.
**On-screen text:** "hundreds of videos · 48hr cycles · 1 operator" (upper-third, fade)
**Rationale:** Proof beat, concrete numbers. Stat callout lets viewer absorb visually while VO confirms.

### shot_07 · 42.0–50.0s · MS · pull

**Beat:** insight · **VO:** "Not because we work harder. Because the system runs."
**Subject:** founder, slight smile, settled into the explanation, room visible around him.
**Rationale:** Slow pull releases tension. The thesis lands. VO carries, text would dilute.

### shot_08 · 50.0–60.0s · MCU · static

**Beat:** cta · **VO:** "If this sounds like the version of content you actually want, run a free scan."
**Subject:** founder, calm, looks directly into camera one more time, almost-smile, settled.
**On-screen text:** "whystrohm.com/scan" (coral, lower-third, type-on)
**Rationale:** CTA beat. Static MCU brings it home. URL holds in lower-third for full read-twice duration.

---

## Handoff notes

- **For image generation:** run `visual-prompt-forge` against `shots.json`
- **For HTML preview:** run `storyboard-html-preview` against this folder
- **For QA:** run `visual-asset-critic` per shot

## Audit trail

Generated against `brand-lock.snapshot.md` (frozen at 2026-05-07T14:31:00Z, source `brand-packs/whystrohm.md`).


---

## ARCHIVO: storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md

<!-- snapshot taken: 2026-05-08T14:34:24Z -->
<!-- source: brand-packs/whystrohm.md -->
<!-- storyboard: shotkit-explainer -->

# Brand Lock: WhyStrohm

## Identity

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#F5F0E8` | Cream, primary canvas |
| Ink | `#2A2A32` | Near-black, primary text and dark elements |
| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |
| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |
| Muted | `#7A7580` | Secondary text, captions |
| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

## Typography

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

Two-font stack for production. Mono only for technical content.

## Mood adjectives

- operator (not creator)
- considered (not reactive)
- deterministic (not vibes-based)
- confident (without volume)
- defense-grade (not fragile)

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate the cream background
- never use coral as a flood color (only as accent or signature periods)
- never use em dashes in copy (only periods, commas, semicolons)
- never use emojis in body copy
- never use bullet points in narrative copy
- never use clip-art or generic icon sets
- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- never use exclamation points in headlines
- never default to dark mode, light mode hybrid is the brand
- never animate text with bouncing or wobbling, type-on, fade, or hard cut only
- never break the eye line between subject and the implied "operator perspective"

## Aspect ratios

- 9:16, primary for short-form social
- 16:9, long-form, hero films, web embeds
- 1:1, feed posts, podcast covers
- 4:5. Instagram feed alternative

## Color grade direction

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup. Skin tones warm but not orange. Greens kept slightly desaturated to push focus to subject.

## Motion language

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only, no fancy wipes, no zooms.

For kinetic typography content (the Content Spiral pattern): pacing accelerates inward, each zoom 1.5–2x faster than the previous. Snap-back to wide claim is a hard cut.

## Voice rules

- no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no hype words ("game-changing", "revolutionary", "comprehensive", "next-level", "leverage")
- no clichéd business metaphors ("move the needle", "drink the kool-aid", "low-hanging fruit")
- no qualifiers in declarative copy ("perhaps", "maybe", "kind of")
- prefer specific numbers over vague claims ("48 hours" not "fast", "30 minutes a week" not "a little time")
- prefer present-tense over future-tense
- prefer "operator" over "creator", "infrastructure" over "agency", "system" over "service"
- coral period (`.`) on signature lines is a typography choice, not punctuation, apply at end of hero phrases only

## Reference materials

- Site: https://whystrohm.com
- Brand voice extractor: https://github.com/whystrohm/media-tsunami
- Past hero films: see `/results` page
- Content Spiral pattern: documented in WhyStrohm production bible v3 (internal)

---

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0


---

## ARCHIVO: storyboard-architect/examples/shotkit-explainer/storyboard.md

# shotkit. The Explainer.

**Project:** shotkit explainer film
**Duration:** 90 seconds
**Aspect:** 16:9 (1280x720 hero render, 1080x1920 vertical cut for socials)
**Framework:** founder-explainer
**Brand-lock:** [brand-lock.snapshot.md](./brand-lock.snapshot.md) snapshotted 2026-05-08T14:34:24Z
**Generated:** 2026-05-08

> This storyboard is the record of the v0.1.0 explainer film as it was actually rendered, so
> shot_05 still names seven adapters including Runway/Sora. Sora was discontinued and the
> motion lane moved to Kling, Veo, Seedance, and Hailuo. The storyboard is deliberately left
> matching the artifact it produced: editing it to describe a video that was never made is
> exactly the kind of drift this repo exists to prevent. See `CHANGELOG.md` for the adapter
> change.

## Brief

90-second explainer for shotkit. Targets founder-led brands at $500K to $5M ARR who run their own content and feel the prompt-engineering tax. Walks through the diagnosis (vague brief plus model-roulette equals brand drift), the methodology (five-layer prompt anatomy), the build moment (brief in, files out), the proof (rendered preview from a real shotkit run), and the install command. Lives at the top of the shotkit blog post on whystrohm.com.

## Series lock

| Field | Value |
|---|---|
| **Character** | No human subject. Typography-driven explainer with document-control aesthetic. |
| **Environment** | Operator-grade dashboard. Cream canvas, JetBrains Mono headers, Inter body, single coral accent per beat. |
| **Lighting** | Even diffuse. No shadow rolloff. Flat operator-doc grading throughout. |
| **Color grade** | Cream highlights (#F5F0E8), ink shadows (#2A2A32), coral (#D94F3A) reserved for signature beats. No saturation drift. |

## Shots

### shot_01: 0.0 to 12.0s. WS. eye-level. static.

**Beat:** pain. **Subject:** vague founder brief types into the left panel in JetBrains Mono. Cursor blinks. Then a chaos cut shows four image generators producing slightly off-brand outputs in a 2x2 grid. Each tile renders the same shot with a different palette, framing, font.
**On-screen text:** "You don't have a content problem. You have a pre-production problem." (Inter Black 900, center, fade)
**Rationale:** Cold open names the failure mode every founder recognizes. Vague brief plus model-roulette equals brand drift. The 2x2 grid does the work text cannot.

### shot_02: 12.0 to 30.0s. MS. eye-level. static.

**Beat:** reframe. **Subject:** Five horizontal layers stack from top to bottom. Each labeled in JetBrains Mono caps with 0.08em letter-spacing: brand lock, series lock, shot spec, text layer, generator adapter. Each layer slides in from below on a 6-frame stagger. Coral dot lands on brand lock as it appears.
**On-screen text:** "Five layers. Locked top to bottom." (Inter Black 900, upper-third, type-on)
**Rationale:** Architecture beat. The reader needs to see the layers exist before any claim about composability lands. Stack layout is the diagram doing the explanation.

### shot_03: 30.0 to 50.0s. MS. eye-level. push.

**Beat:** proof-1. **Subject:** Split panel. Left BRIEF column types out a brief slowly. Right OUTPUT column starts empty with a pulsing waiting dot, then file tree assembles row by row in JetBrains Mono Regular 16pt. storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md, prompts/ directory with seven adapter files, preview.html. Coral dot lands on preview.html on completion.
**On-screen text:** "Brief in. Storyboard out. Audit trail included." (Inter Medium 500, upper-third, fade)
**Rationale:** The build moment is the centerpiece. Brief in, structured files out. Same animation language as the social demo so brand consistency reads across both surfaces.

### shot_04: 50.0 to 65.0s. MCU. eye-level. push.

**Beat:** proof-2. **Subject:** Coral wipe expands radially from the preview.html dot. Wipe reveals the rendered preview iframe scrolling vertically. The reader sees actual shot cards from the 30-second example pass through frame, including framing, angle, motion, color-grade rows. Subtle 10% vignette on edges.
**On-screen text:** "Files. Not panels. Not a SaaS dashboard." (Inter Black 900, lower-third, type-on)
**Rationale:** Reveal beat. The reader has now seen the methodology and the file outputs. The iframe shows the actual deliverable, not a mock.

### shot_05: 65.0 to 80.0s. MS. eye-level. static.

**Beat:** proof-3. **Subject:** Single shot description card sits center-frame. Seven generator adapter labels fan out radially around it. Midjourney, Flux, Ideogram, GPT Image, Nano Banana, Seedream, Runway/Sora. Lines connect center card to each adapter in 1px ink. Each adapter shows its prompt syntax appearing as a typewriter pass running simultaneously.
**On-screen text:** "One shot. Seven generators. One spec." (Inter Black 900, upper-third, fade)
**Rationale:** Cross-generator demonstration. Same shot description compiles to seven different prompt syntaxes simultaneously. The visual proves model-agnosticism is structural, not aspirational.

### shot_06: 80.0 to 90.0s. WS. eye-level. static.

**Beat:** promise. **Subject:** Full-frame typography. Install command appears via type-on in JetBrains Mono Regular at 22pt. Below it the project tagline in Inter italic 500 18pt, color muted. Coral period on the signature beat. Standard footer chrome holds.
**On-screen text:** "git clone github.com/whystrohm/shotkit / cd shotkit && ./install.sh" (JetBrains Mono, center, type-on) plus tagline "Pre-production for founder-led video at scale." (Inter italic 500, lower-third, fade).
**Rationale:** Promise beat. The viewer has the diagnosis, the architecture, the artifact, and the proof. The CTA is one paste-into-terminal command. No friction surface.

## Audit trail

- Brief, this document, scoped from the shotkit blog launch sequence.
- Brand-lock snapshotted from `brand-packs/whystrohm.md` on 2026-05-08.
- Shot list designed to compose with the existing ShotkitDemo composition (same chrome, complementary content, longer arc).
- Render shipped at [whystrohm.com/blog/you-dont-have-a-content-problem](https://whystrohm.com/blog/you-dont-have-a-content-problem) as the "we used shotkit to make this video" dogfood reveal.
- Landscape MP4 served from the blog: `/media/shotkit-explainer/shotkit-explainer.mp4`.


---

## ARCHIVO: storyboard-architect/references/beat-frameworks.md

# Beat Frameworks

Pick one. Don't invent a new one unless the brief genuinely doesn't fit. Document the choice in `storyboard.md`.

## Pain-Reframe-Promise (PRP)

Default for conversion content. Three beats:

1. **Pain**, name the audience's actual problem in their actual language. Concrete, not abstract. "Your content feels random" not "marketing inefficiency."
2. **Reframe**, flip the problem on its head. The point is *not* what they thought it was. "You don't have a content problem. You have an infrastructure problem."
3. **Promise**, what life looks like on the other side. Specific, verifiable, time-bound when possible.

Timing for 30s: 0–8 / 8–22 / 22–30.
Timing for 60s: 0–15 / 15–45 / 45–60.

Use when: ad creative, landing-page hero video, conversion-focused social.

## Hero Trilogy

Default for product films and brand films. Three beats:

1. **World**, set the context. Who lives in this world. What's broken about it.
2. **Hero**, the product/founder/methodology arrives. Show what it does, not what it is.
3. **Transformation**, the world changes. Show before/after at scale.

Timing for 60s: 0–20 / 20–40 / 40–60.
Timing for 90s: 0–30 / 30–60 / 60–90.

Use when: product launches, brand films, anchor pieces.

## Founder Explainer

Default for personal-brand video where a person speaks to camera. Five micro-beats:

1. **Hook**, a one-line provocation (0–2s)
2. **Stakes**, why this matters (2–8s)
3. **Insight**, the actual point (8–20s for 30s, 8–40s for 60s)
4. **Proof**, one concrete example or data point
5. **CTA**, what to do next, narrow and specific

Use when: founder content, thought leadership, personal-brand pieces.

## Content Spiral

Default for kinetic typography or opinion content. The structure is recursive, each beat zooms in tighter:

1. **Wide claim**, the headline take
2. **Zoom 1**, one layer of nuance
3. **Zoom 2**, the layer underneath that
4. **Snap-back**, return to the wide claim, now reframed by the zooms

Each zoom is 1.5–2x faster than the previous. Pacing accelerates inward.

Use when: opinion videos, kinetic-type pieces, social-native commentary.

## Educational Demo

Default for how-to content. Four beats:

1. **Problem state**, what someone is stuck on
2. **Reveal**, the technique or trick
3. **Walk-through**, apply it step by step
4. **Result**, the after-state, side-by-side with before

Use when: tutorials, demo videos, training content.

## Custom

If the brief doesn't fit, build a custom beat structure. Document in `storyboard.md`:

```markdown
## Beat framework: Custom

**Why custom:** [one sentence, what made the standard frameworks insufficient]

**Beats:**
1. [name], [purpose], [duration]
2. ...
```

Custom is a last resort, not a first move. The standard frameworks exist because they work.


---

## ARCHIVO: storyboard-architect/references/on-screen-text.md

# On-Screen Text

Text on screen is a load-bearing decision. Most storyboards over-text. The default should be: **does this shot need text to land?** If the visual carries the meaning, text dilutes.

## When on-screen text earns its keep

1. **Auto-play-mute environments.** Social feeds. Text replaces VO.
2. **Concept compression.** A short phrase lands harder than 4 seconds of narration.
3. **Stat or proof point.** Numbers stick visually in a way they don't audibly.
4. **Beat punctuation.** A single word or phrase that lands on a music hit.
5. **CTA.** The action you want the viewer to take.

## When on-screen text doesn't earn its keep

1. **Restating the VO.** If the voice says it, the text is noise.
2. **Decorative copy.** "Moments matter" floating over b-roll. Cut it.
3. **Brand vibing.** Product names everywhere. Logo lockup in the CTA covers this.
4. **Filler beats.** If the shot doesn't need text, leave it clean.

## Composition rules

These flow into the `position` field of each text overlay.

### Negative-space-aware composition

When a shot has on-screen text, the **shot subject must reserve space for it**. This is enforced at storyboard time, not generation time.

If text is in the right third → subject composition leaves the right third clear.
If text is lower third → subject upper two-thirds.
If text is centered → subject framed to negative space around center.

This goes into the shot's rationale: "MCU left-third subject, reserves right-third for `text_03`."

### Positions

| Position | Use when |
|---|---|
| `center` | Display headline, single concept, hard cut in/out |
| `lower-third` | Caption / VO substitute, persistent across shots |
| `upper-third` | Stat callout, secondary information |
| `left-third` | Subject is right-weighted in frame |
| `right-third` | Subject is left-weighted in frame |
| `{x: %, y: %}` | Custom, only when the standard positions don't fit |

### Sizes

| Size | Pixel approx (1080p) | Use for |
|---|---|---|
| `display` | 96–144 px | Hero/hook beats |
| `headline` | 56–80 px | Reframe beats |
| `body` | 32–48 px | Caption-style, persistent |
| `caption` | 20–28 px | Disclaimers, attribution |

### Animation

Default to clean, not flashy:

- Hook beats → `hard-cut` in, `hard-cut` out (no fade)
- Reframe beats → `fade-in` 0.2s, `fade-out` 0.2s
- Persistent captions → `slide-up` in, `slide-down` out
- CTA → `type-on` for a typewriter effect, or `slide-up`

Avoid stacking animations. Pick one per overlay.

## Color rules

The `color` field of every text overlay must be a hex value that exists in the brand-lock palette. If you find yourself wanting a color that's not in the palette, the answer is not to add it, the answer is to pick a different overlay style or shot composition.

## Typography rules

Same: every `font` field must reference a font defined in brand-lock typography. Two fonts max per project (display + body). More than that and the brand stops being recognizable.

## The "read twice" rule

Already covered in timing-rules.md but worth repeating: text needs to be on screen long enough for someone to read it twice. Calculate, then verify. Don't eyeball.

## Stacking text across shots

Text can persist across consecutive shots. This is useful when:

- The text takes longer to read than a single shot's duration
- You want text to feel anchored while visuals change underneath

To stack, both shots reference the same `on_screen_text` ID. The overlay's `enter.at` aligns to the first shot's start, `exit.at` aligns to the second shot's end.

In `shots.json`:

```json
{ "id": "shot_03", "on_screen_text": "text_02", ... },
{ "id": "shot_04", "on_screen_text": "text_02", ... }
```

In `text-overlays.json`:

```json
{
  "id": "text_02",
  "shot_id": ["shot_03", "shot_04"],
  ...
}
```

Document this in rationale: "text persists across shot 3-4 to give 4.8s read-time for 16-word reframe."


---

## ARCHIVO: storyboard-architect/references/shot-grammar.md

# Shot Grammar

Controlled vocabulary. Use these exact terms in `shots.json`. Generators interpret loose language inconsistently, locked vocabulary survives translation.

## Framing (subject size in frame)

| Code | Name | What it shows |
|---|---|---|
| `ECU` | Extreme close-up | Eyes, hands, single detail |
| `CU` | Close-up | Head, or full hand-on-object |
| `MCU` | Medium close-up | Head and shoulders |
| `MS` | Medium shot | Waist up |
| `MLS` | Medium long shot | Full body, environment minimal |
| `WS` | Wide shot | Full body, environment present |
| `EWS` | Extreme wide shot | Subject small in environment |

Default to MCU and MS for talking-head founder content. ECU and CU for product detail and emotion. WS and EWS for context-setting.

## Angle (camera vertical position)

| Code | Effect |
|---|---|
| `eye-level` | Neutral, default |
| `high` | Subject feels smaller, vulnerable |
| `low` | Subject feels powerful, dominant |
| `overhead` | Detached, schematic, instructional |
| `dutch` | Tilted, tension, unease |

Default to eye-level. Use the others deliberately, not for variety.

## Motion (camera movement)

| Code | Effect | Use when |
|---|---|---|
| `static` | No movement | Default. Static is not boring. |
| `push` | Camera moves toward subject | Building intensity, revealing |
| `pull` | Camera moves away | Releasing, contextualizing |
| `pan-left` / `pan-right` | Camera rotates horizontally | Surveying environment |
| `tilt-up` / `tilt-down` | Camera rotates vertically | Reveal scale or detail |
| `handheld` | Subtle organic shake | Documentary feel, urgency |
| `orbit` | Camera circles subject | Hero shots, product reveal |
| `whip` | Fast pan as transition | Beat-cuts in fast-paced content |

For AI-generated still frames, motion is mostly intent for the editor. For motion-video prompts (Kling, Veo, Seedance, Hailuo), motion translates directly.

## Depth of field

| Code | Effect |
|---|---|
| `shallow` | Subject sharp, background blurred |
| `deep` | Everything in focus |
| `rack` | Focus shifts mid-shot |

Default to shallow for talking-head, deep for environmental and schematic.

## Lighting style (referenced from series_lock)

Don't redefine per shot. Define once in `series_lock.lighting`. Examples:

- `soft natural side-light, large window left, warm afternoon`
- `hard top-light, single source, deep shadows, studio black`
- `practical mixed sources, neon accents, urban night`

The series_lock string flows into every prompt automatically.

## Subject description

Structured, not poetic. Pattern:

```
[who/what], [doing what], [emotional or compositional note]
```

Good:
```
"Founder, mid-thirties, leaning forward at laptop, face partially turned to window light"
```

Bad:
```
"A determined entrepreneur conquering the digital frontier with passion"
```

Generators reward precision. Adjectives describing emotion ("determined", "passionate") produce stock-photo aesthetics. Describe what the camera actually sees.

## What goes in `subject` vs `series_lock` vs `brand_lock`

This trips people up. The rule:

- **brand_lock**, locked across the entire project. Palette, type, "never" list.
- **series_lock**, locked across this storyboard. Character anchor, environment, lighting style, color grade.
- **subject (per shot)**, what's different about *this* shot. Action, expression, framing-specific composition notes.

If you find yourself repeating the same lighting description across shots, it belongs in series_lock. If you find yourself repeating the same color description across storyboards, it belongs in brand_lock.


---

## ARCHIVO: storyboard-architect/references/timing-rules.md

# Timing Rules

Pacing is math, not feel. Use these as defaults. Override only with reason documented in rationale.

## Shot duration baselines

| Content type | Default shot duration | Range |
|---|---|---|
| Kinetic typography / opinion | 1.0–1.5s | 0.5–2.0s |
| Founder talking-head | 2.5–4.0s | 2.0–6.0s |
| Product/lifestyle b-roll | 1.5–2.5s | 1.0–3.5s |
| Demo / how-to | 3.0–5.0s | 2.0–7.0s |
| Cinematic brand film | 3.5–6.0s | 2.0–10.0s |

If a single shot is longer than 7 seconds in a 30-second piece, justify it in rationale. Long shots are not bad. Unjustified long shots are.

## Hook timing (the first beat)

The hook is 0–2s. Always. There are no exceptions in short-form content. Specifically:

- 9:16 social: first frame must telegraph the topic. Auto-play on mute means the first half-second is fighting a swipe.
- 16:9 in-feed: first 2s decides watch-time.

The hook shot framing should be high-contrast against the shots that follow. If shot 2 is MS, shot 1 should not be MS. Visual contrast = retention.

## CTA timing (the final beat)

The CTA is the final 4–6s for 30s content, 6–10s for 60s content. Specifically:

- Last shot should hold long enough for someone to read the CTA text and act
- Don't put motion on the CTA shot, let the text breathe
- If there's a logo lockup, it lives in the final 2s, not earlier

## On-screen text duration math

A text overlay needs to be on screen long enough to be **read twice**. Not once, twice. Why: viewers are skimming, eyes don't always lock on first frame.

Reading speed reference (assume average viewer):
- 1 short word (≤5 chars): 0.6s minimum read
- Short phrase (≤6 words): 1.2s
- Sentence (≤14 words): 2.4s
- Long sentence (15–25 words): 4.0s

Multiply by 2 for the "read twice" rule. So a 6-word phrase needs **2.4s on screen minimum**.

If a shot is 2 seconds and you need a 14-word sentence, you have a problem. Either:
1. Shorten the copy
2. Carry the text across two consecutive shots (text persists during cut)
3. Lengthen the shot

Do not under-time text. It's the most common storyboard failure.

## Pacing curve

For 30-second content, the natural energy curve:

```
0s ─────────────────────────────────── 30s

Energy
  ▲     ╱╲
  │    ╱  ╲___
  │   ╱       ╲___
  │  ╱            ╲___
  │ ╱                 ╲___
  └─────────────────────────►
   hook  build  apex  release  CTA
   0-2   2-12   12-20  20-26   26-30
```

The apex is two-thirds in, not at the end. The CTA is a release, not a peak.

For 60-second content, scale the same curve. Apex around 0:40, CTA from 0:50.

## Validating timing

Before declaring done, check:

1. Sum of `(end - start)` across all shots equals project duration ±0.1s
2. No shot has `start >= end`
3. No two shots overlap
4. First shot starts at 0.0
5. Last shot ends at project duration
6. Every text overlay's `enter.at` is ≥ its shot's `start`
7. Every text overlay's `exit.at` is ≤ its shot's `end` (or carries to a flagged successor shot)
8. Every text overlay's on-screen duration ≥ read-twice threshold


---

## ARCHIVO: storyboard-architect/tools/README.md

# Tools

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

## Requirements

```bash
pip install pyyaml jsonschema
```

Standard library otherwise. No pandas, no numpy.

## Run everything

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

This is exactly what CI runs, so a green local run means a green PR.

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

## Repo checks

### `validate_skills.py`

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

```bash
python tools/validate_skills.py
```

### `validate_schemas.py`

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

```bash
python tools/validate_schemas.py
```

It validates schemas, not instances. For instances, see `validate_shots.py`.

### `validate_capabilities.py`

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

- every generator id has an adapter `.md` and every adapter `.md` has an entry
- no adapter advertises more words than its own `max_prompt_words` ceiling
- every adapter documents the `aspect_param` the matrix says to send
- no `notes` field cites a word count above its own ceiling
- warns when the matrix or an entry is past its 120-day freshness window

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

### `validate_brand_lock.py`

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

## Project checks

These run against a project's output directory, not the repo.

### `validate_shots.py`

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

### `validate_prompts.py`

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

### `validate_critique.py`

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

### `validate_provenance.py`

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

It catches, with a selftest for each:

- a frame regenerated after its critique (`image_sha256` no longer matches)
- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)
- a frame on disk with no critique for its round, never reviewed at all
- two critiques for the same shot in the same round, two operators colliding
- rounds that skip a number, or a critique whose `run_id` belongs to another run

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

## Rendering

### `shots-to-html.py`

Renders an output folder into a single `preview.html`.

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

### `copy-prompt.py`

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

## Internal modules

Not entry points. Imported by the tools above.

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.
- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

## Adding new tools

- Make it executable (`chmod +x`)
- Add a usage docstring at the top of the file
- Give it a `--selftest` that proves the check fires
- Document it in this README
- Wire it into `tools/check.sh`, which is what CI calls

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.


<!-- SOURCE_FILE_END: repo/notebooklm-corpus/storyboard-architect.md -->


<!-- SOURCE_FILE_START: repo/notebooklm-corpus/storyboard-html-preview.md -->
# SOURCE FILE: `repo/notebooklm-corpus/storyboard-html-preview.md`

# SKILL: storyboard-html-preview

Documentacion completa del skill. Cada seccion es un archivo distinto.


---

## ARCHIVO: storyboard-html-preview/SKILL.md

---
name: storyboard-html-preview
description: Render a structured storyboard (storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md) into a single-file HTML preview that is shareable, printable, and offline. Use when the user wants to share a storyboard, export for review, hand off to an editor, or print a hard copy. Triggers on "preview the storyboard", "share this", "export to HTML", "print version", or after a storyboard-architect run. Produces one self-contained .html file with no build or server.
---

# Storyboard HTML Preview

You are turning structured storyboard files into a single shareable HTML document. The output is what an editor, stakeholder, or client opens in a browser without thinking about it.

The constraint is non-negotiable: **single file, no build step, no server, works offline.** Any time the output requires "run this build command" or "host this somewhere," the skill has failed.

## When to use

Trigger when the user:

- Asks to preview, share, or export a storyboard
- Wants a printable version
- Says "what's the next step" after a storyboard-architect run
- Hands off `storyboard.md` + `shots.json` + asks for a deliverable for review

## What you produce

One file: `preview.html`. Self-contained. Inline CSS. No JavaScript dependencies (vanilla JS only, embedded). No external font files (uses system stack with brand-font fallbacks). No external images (placeholder slots; if generated images exist, embed as base64 OR reference relative paths).

```
output/
├── run.json                   # input, for the run id and date
├── storyboard.md              # input
├── shots.json                 # input
├── text-overlays.json         # input
├── brand-lock.snapshot.md     # input
├── frames/round-N/            # input, if generation has happened
├── critiques/round-N/         # input, for the verdict badges
└── preview.html               # ← what this skill produces
```

If the user has generated frames, the HTML references them via relative paths so the file
works when the whole `output/` folder is shared. Resolve a shot's frame in this order:

1. An entry in `shot.assets.generated` marked `accepted: true`
2. The newest entry in `shot.assets.generated`
3. `frames/round-{highest}/{shot_id}.{png,jpg,jpeg,webp}`
4. `generated/{shot_id}.{ext}`, the pre-3.0.0 flat layout

Data first, convention second. Reading the path convention first meant the page showed
whatever file happened to sit there, accepted or rejected, first draft or fifth re-roll.

If no frames exist yet, the HTML uses styled placeholder cards with the shot spec, still
useful for review and handoff.

## Workflow

### Step 1. Read inputs

Required:

- `shots.json`
- `text-overlays.json`
- `brand-lock.snapshot.md`

Optional:

- `run.json` (for the run id and date; without it the page says "not recorded")
- `storyboard.md` (for narrative context, surface the brief at the top)
- `frames/round-N/{shot_id}.{png,jpg,jpeg,webp}` (if generation has happened)
- `critiques/round-N/{shot_id}.critique.json` (for verdict badges)

Validate before rendering, and stop if it fails:

```bash
python tools/validate_shots.py output/
```

### Step 2. Extract brand parameters

From `brand-lock.snapshot.md`, extract:

- Palette (hex values), used for HTML accent colors
- Display font and body font names, used as font-family values with system fallbacks
- Brand voice / mood, used in subtle copy choices

The HTML preview should *feel* like the brand without going overboard. Quiet branding, not loud.

### Step 3. Generate the HTML

Use `templates/preview.html.tpl` as the structural template. Read it before generating.

The HTML structure:

```
<!DOCTYPE html>
<html>
<head>
  <meta>
  <title>{project title}</title>
  <style>
    /* All CSS inline. ~200 lines. Brand-aware. */
    /* Print stylesheet included. */
  </style>
</head>
<body>
  <header>
    <!-- Project title, duration, aspect, generated timestamp -->
  </header>

  <section class="brief">
    <!-- Brief summary if storyboard.md provides one -->
  </section>

  <section class="series-lock">
    <!-- Character / environment / lighting / color grade -->
  </section>

  <section class="shots">
    <!-- One card per shot -->
    <article class="shot" id="shot_01">
      <div class="shot-frame">
        <!-- generated image OR styled placeholder -->
      </div>
      <div class="shot-meta">
        <!-- timestamp, framing, angle, motion -->
      </div>
      <div class="shot-subject">
        <!-- subject description -->
      </div>
      <div class="shot-text-overlay">
        <!-- if on_screen_text exists, show overlay content with timing -->
      </div>
      <div class="shot-rationale">
        <!-- rationale text -->
      </div>
    </article>
    <!-- ... -->
  </section>

  <footer>
    <!-- audit trail: brand-lock snapshot reference, timestamp -->
  </footer>

  <script>
    /* Vanilla JS only. Optional: keyboard nav, jump-to-shot, expand/collapse. */
  </script>
</body>
</html>
```

### Step 4. Embed frames if available

Resolve each shot's frame by the order in "What you produce" above, then reference it by a
path relative to the output root:

```html
<img src="frames/round-2/shot_01.png" alt="shot_01: hook" loading="lazy" />
```

This works when the whole output folder is zipped and shared.

For hard-copy print (a single file with no folder structure), the skill can offer to inline
frames as base64. Ask the user which they prefer if frames are present.

If a shot's `assets.generated` entry carries a `sha256` and the file no longer matches it,
render the frame but say so on the page. That mismatch means the frame changed after it was
recorded, which is exactly the case where a preview quietly showing the new file is worse
than one that flags it.

If no frames exist, render styled placeholder cards showing the framing, subject, and shot
spec. These are still useful for stakeholder review at the storyboard stage.

**Template flag convention.** When composing the per-shot context for `preview.html.tpl`, set exactly one of:

- `has_image: true` and `image_path: "frames/round-2/shot_NN.png"`, when a frame exists
- `has_no_image: true`, when none does (renders the placeholder card)

The template uses two parallel `{{#if}}` blocks rather than `{{#if}}/{{else}}` to keep the rendering portable across template engines.

For text overlays, set `has_overlays: true` and an `overlays` array on the shot. Each entry
carries `id`, `content`, `font`, `weight`, `color`, `size`, `position_class`,
`position_label`, `enter_at`, `enter_animation`, `exit_at`, `exit_animation`. The template
iterates that array with `{{#each overlays}}`.

It is an array because `shots.json` lets a shot carry several overlays and
`text-overlays.json` always did. A single set of `overlay_*` fields could hold one, so the
second overlay on a shot rendered nowhere and nothing reported it.

For verdict badges, set `has_verdict`, `verdict`, `verdict_round`, and `verdict_class`
(the lowercased verdict) from the newest critique for that shot under `critiques/`. Omit
them when the shot has no critique.

**Escape everything.** Subjects, rationales, VO lines, and overlay copy are model-generated
prose that lands in both text and attribute contexts. One angle bracket in a rationale, or
one quote in an overlay font name, breaks the page a client is reading.
`tools/shots-to-html.py` escapes every substitution by default and reserves raw output for
the inlined CSS alone.

### Step 5. Render text overlays visually

For every shot with an `on_screen_text` reference, the HTML shows:

- The text content rendered in approximately the brand font (or visible fallback)
- The position indicated visually (lower-third, center, etc.)
- Timing info (enter/exit beats)

This gives the reviewer a sense of what the final composited frame will look like, even before final compositing happens.

### Step 6. Print stylesheet

Include `@media print` rules that:

- Hide nav, footer scripts, expand/collapse UI
- Force one shot per page (or two if compact)
- Ensure text overlays render legibly
- Use black-on-white where brand colors won't print well

The user should be able to hit Cmd-P / Ctrl-P and get a clean PDF.

## Hard rules

### Rule 1. Single file, no exceptions

The output is one `.html` file. If you find yourself wanting a separate stylesheet or JS file, inline it. If you find yourself wanting a build step, you're solving the wrong problem.

### Rule 2. No external dependencies at runtime

No CDN scripts. No Google Fonts. No external CSS frameworks. The file must work with no internet connection.

The exception: if the user explicitly opts in (e.g. "make it pretty, I'm online"), Tailwind via CDN is acceptable. Default is no.

### Rule 3. Print must work

Hit Cmd-P. The result should be a clean PDF. If layout breaks across page boundaries, the print stylesheet is broken.

### Rule 4. Brand-aware but quiet

Use brand colors as accents, not as full backgrounds. The reviewer's job is to read the storyboard, not admire the design. Subtle.

### Rule 5. Mobile-readable

Stakeholders open links on phones. The HTML should be readable on mobile without horizontal scroll. Simple responsive CSS.

## Templates

- `templates/preview.html.tpl`, the structural template
- `templates/styles.css.tpl`, the CSS to inline
- `templates/print.css.tpl`, the print rules

The skill reads all three and assembles them into a single `preview.html`.

## Quality bar

Before declaring done, verify:

- [ ] File opens in any browser (Chrome, Safari, Firefox) with no errors
- [ ] No external network requests fire on load
- [ ] Print preview produces a clean PDF
- [ ] Mobile viewport (375px) renders without horizontal scroll
- [ ] Brand colors and fonts come from the brand-lock, not from a fallback
- [ ] Every shot from `shots.json` is present
- [ ] Every overlay referenced by a shot is rendered, including second and third overlays
- [ ] `brand_lock_ref` from `shots.json` is what the footer links to, not a hardcoded name
- [ ] The run date and the render date are both shown, and labelled differently
- [ ] No `{{` remains anywhere in the output

The CLI renderer checks the mechanical half of that list against itself:

```bash
python tools/shots-to-html.py --selftest
```

## Two timestamps, not one

"Run" is when the storyboard was produced, read from `run.json`. "Rendered" is when the page
was written. They are separate lines in the footer and they must stay separate.

Collapsing them into a single "Generated" date meant re-rendering a preview six months later
restamped the run as today, and the footer went on asserting the page was built against a
brand-lock on a date that had nothing to do with the frames above it.

If the brand-lock on disk no longer hashes to what `run.json` recorded, say so on the page.
The reader is looking at frames built against a brand state they can no longer see.

## Examples

Generated `preview.html` files ship next to the storyboards that produced them:

- `../storyboard-architect/examples/30s-pain-proof-promise/preview.html`
- `../storyboard-architect/examples/60s-founder-explainer/preview.html`
- `../storyboard-architect/examples/shotkit-explainer/preview.html`, including the
  two-overlay shot
- `../visual-asset-critic/examples/worked-run/preview.html`, with frames and verdict badges

Open them in a browser to calibrate quality. All four are re-rendered in CI with pinned
timestamps and the build fails if the output moves, so they are also the regression test for
this skill's output.


---

## ARCHIVO: storyboard-html-preview/tools/README.md

# Tools

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

## Requirements

```bash
pip install pyyaml jsonschema
```

Standard library otherwise. No pandas, no numpy.

## Run everything

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

This is exactly what CI runs, so a green local run means a green PR.

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

## Repo checks

### `validate_skills.py`

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

```bash
python tools/validate_skills.py
```

### `validate_schemas.py`

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

```bash
python tools/validate_schemas.py
```

It validates schemas, not instances. For instances, see `validate_shots.py`.

### `validate_capabilities.py`

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

- every generator id has an adapter `.md` and every adapter `.md` has an entry
- no adapter advertises more words than its own `max_prompt_words` ceiling
- every adapter documents the `aspect_param` the matrix says to send
- no `notes` field cites a word count above its own ceiling
- warns when the matrix or an entry is past its 120-day freshness window

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

### `validate_brand_lock.py`

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

## Project checks

These run against a project's output directory, not the repo.

### `validate_shots.py`

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

### `validate_prompts.py`

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

### `validate_critique.py`

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

### `validate_provenance.py`

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

It catches, with a selftest for each:

- a frame regenerated after its critique (`image_sha256` no longer matches)
- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)
- a frame on disk with no critique for its round, never reviewed at all
- two critiques for the same shot in the same round, two operators colliding
- rounds that skip a number, or a critique whose `run_id` belongs to another run

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

## Rendering

### `shots-to-html.py`

Renders an output folder into a single `preview.html`.

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

### `copy-prompt.py`

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

## Internal modules

Not entry points. Imported by the tools above.

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.
- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

## Adding new tools

- Make it executable (`chmod +x`)
- Add a usage docstring at the top of the file
- Give it a `--selftest` that proves the check fires
- Document it in this README
- Wire it into `tools/check.sh`, which is what CI calls

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.


<!-- SOURCE_FILE_END: repo/notebooklm-corpus/storyboard-html-preview.md -->
