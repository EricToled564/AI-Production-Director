# AI Production Director — Knowledge Pack 5/7

Generated from `aiproductiondirectorcompleto.zip`.
Each source file is preserved with its original relative path.


<!-- SOURCE_FILE_START: skills/image/references/gpt-image.md -->
# SOURCE FILE: `skills/image/references/gpt-image.md`

# GPT Image 2 — Specific Rules

Production default OpenAI: `gpt-image-2`. Migration-only: `gpt-image-1.5`, `gpt-image-1`. Бюджетный: `gpt-image-1-mini`.

## Структура промпта — 5 slots

GPT Image 2 сильнее всего реагирует на разделение по секциям. Пиши лейблами, не сплошным текстом.

```
Scene: location, time of day, background, environment
Subject: primary focus — who or what is central
Important Details: materials, textures, lighting, camera angle, mood, composition
Use Case: editorial, product mockup, UI, poster, infographic
Constraints: what must NOT change/appear (no watermarks, preserve face, no extra text)
```

> «The fifth slot is where most mediocre prompts fail silently.» Без явных constraints модель дрейфует.

### Минимальный пример

```
Scene: small Lisbon florist storefront at blue hour, wet cobblestones
Subject: woman in navy apron locking the front door, half-turned to camera
Important Details: warm interior glow spilling onto pavement, 50mm feel,
  soft contact shadows, brushed brass door handle, "Florista" hand-painted sign
Use Case: editorial photography
Constraints: no extra signage, no people in background, no text other than the sign
```

## Anti-Slop Rules

GPT Image 2 особенно чувствителен к качеству формулировок. Vague praise = деградация результата.

| ❌ Не пиши | ✅ Пиши |
|-----------|---------|
| stunning, incredible, epic, gorgeous, masterpiece | overcast daylight, brushed aluminum, chipped paint, 50mm feel |
| «minimalist brutalist luxury photoreal» (стиль-теги) | «cream background, heavy black sans-serif, asymmetrical type block, one hero object, generous negative space» |
| «как в Apple-рекламе» | конкретные визуальные факты |
| мудовый язык, в котором тонут функциональные требования | прямое заявление: «image must contain a transit kiosk» |

## Quality Settings — рычаг fidelity / latency

| Setting | Когда |
|---------|-------|
| `quality: low` | High-volume, превью, exploratory, latency-sensitive, draft |
| `quality: medium` | **Default starting point** |
| `quality: high` | Маленький/плотный текст, infographics, портреты, identity-sensitive edits, brand assets |

Стартуй с `low`, апгрейди по необходимости. Часто `low` уже достаточно.

## Размеры (gpt-image-2)

- Max edge: <3840px
- Обе стороны: кратны 16
- Aspect ratio: max 3:1 (long:short)
- Total pixels: 655 360 – 8 294 400
- Reliable upper bound: 2560×1440

**Ходовые:**
- Portrait 1024×1536
- Landscape 1536×1024
- Square 1024×1024
- 2K 2560×1440

> Экстрим вроде 1:8 / 8:1 GPT Image 2 НЕ умеет — иди в Nano Banana.

## Text in Image

- Литеральный текст в `"..."` или ALL CAPS.
- Шрифт, размер, цвет, позиция — явно.
- Сложные слова и бренды: спеллинг по буквам.
- Защита от мусора: «**no extra words, no duplicate text, no watermarks**».
- Для нечитаемого мелкого текста: «**100 percent readable and physically believable**».
- Маленький/плотный/multi-font → `quality: high` обязательно.

## Editing — двухколоночная логика

Endpoint: `openai/gpt-image-2/edit` (на fal.ai) или соответствующий через OpenAI API.

```
Change: [single concrete change]
Preserve: face, identity, pose, lighting, framing, background, geometry, text, layout
Constraints: no extra objects, no redesign, no drift
```

**Правила edit:**
- **Один edit за итерацию.** Не пытайся менять всё разом.
- **Preserve list повторять каждую итерацию.** Иначе дрейф.
- **Surgical edits:** явно перечисли что НЕ трогать (saturation, contrast, layout, arrows, labels, camera angle).
- Опционально: `mask_image_url` для точечных edits.

### Edit-паттерны

**Virtual try-on:** «Change garments only. Preserve exact face, body shape, pose, hair, expression, background, camera angle. Match lighting/shadows so outfit looks naturally worn.»

**Object removal:** «Remove [X]. Do not change anything else. Use `input_fidelity: high` to maintain surrounding context» (только gpt-image-1.5/1, в gpt-image-2 high-fidelity по умолчанию).

**Lighting/weather swap:** «Change ONLY environmental conditions: lighting direction/quality, shadows, atmosphere, precipitation. Preserve identity, geometry, camera angle, object placement.»

**Interior swap:** «Swap [furniture]. Preserve camera angle, lighting, shadows, surrounding context. Photorealistic contact shadows.»

## Multi-Image — до 16 рефов

Индексируй с **ролью**, не только номером:
```
Image 1: base scene
Image 2: jacket reference (apply only the jacket fabric/cut to subject in Image 1)
Image 3: lighting reference (apply golden-hour quality from Image 3)
```

## Style Transfer

Не пиши абстрактно («minimalist», «editorial»). Назови конкретные визуальные свойства референса: палитра, edge treatment, силуэт, обработка теней, plane логика.

## World Knowledge

GPT Image 2 умеет домысливать контекст: «Bethel, NY, August 1969» → выведет Woodstock-эстетику. Используй: дай исторический/культурный анкер, не расписывай каждую деталь.

## Iteration Strategy

- Стартуй с **чистого** базового промпта.
- Один change за раунд. «Make lighting warmer», «remove extra tree», «restore original background».
- При drift — перечисли invariants заново.
- Для длинных промптов — labeled sections, не одна простыня.

## Use-Case Templates

### Photoreal Editorial
```
Scene: [location, time, weather]
Subject: [who, action, framing]
Important Details: [lens feel, light source, surface wear, imperfections, real texture]
Use Case: editorial photograph, looks like a real photo
Constraints: no glamorization, no heavy retouching, no studio gloss
```

### Product Mockup (Clean Background)
```
Scene: plain white opaque background
Subject: [product] centered
Important Details: crisp silhouette, no halos/fringing, light contact shadow,
  preserve label legibility exactly, preserve geometry
Use Case: product mockup
Constraints: no restyling, only background removal + light polish
```

### UI Mockup
```
Scene: [device frame, e.g. iPhone 15 Pro]
Subject: [screen/app name] — describe AS IF IT EXISTS, not concept art
Important Details: layout, hierarchy, real interface elements, exact copy in quotes,
  typography behavior, spacing, state
Use Case: shipped product screenshot
Constraints: no sketch language, no placeholder text, no Lorem Ipsum
Quality: high (for small UI text)
```

### Marketing Creative with Text
```
Scene: [environment]
Subject: [hero element]
Important Details: [composition, palette, mood]
Use Case: ad creative for [audience]
Text: "EXACT HEADLINE" in [font style], [color], [position]
      "exact subhead" in [font style], [color], [position]
Constraints: no extra text, no duplicate text, no watermarks, no unrelated logos
Quality: high
```

### Infographic / Diagram
```
Title: "[TITLE]"
Content flow: [step 1] → [step 2] → [step 3]
Visual format: [layout type — flowchart, pyramid, isometric, etc.]
Use Case: educational infographic for [audience]
Constraints: readable labels at all sizes, clear hierarchy, no clutter,
  no decorative noise, ample whitespace
Quality: high
Size: 1536×1024
```

## Migration from Older GPT-Image

- Промпты в основном переносятся как есть.
- После переноса — посмотри качество, latency, retry-rate; ретюнь.
- `gpt-image-1-mini` — только если главное снизить цену batch'а на низкорисковых задачах.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/gpt-image.md -->


<!-- SOURCE_FILE_START: skills/image/references/models.md -->
# SOURCE FILE: `skills/image/references/models.md`

# Model Selection — Nano Banana vs GPT Image 2

Skill пишет промпты под две семьи моделей. Они мыслят по-разному — выбор модели меняет структуру промпта.

## TL;DR

| Задача | Модель |
|--------|--------|
| Реальное место/объект (с грунтингом) | **Nano Banana** (NB2/NBP) |
| Сложная сцена с физикой/композицией | **Nano Banana Pro** |
| Длинные горизонтальные/вертикальные форматы (1:8, 8:1, 4:1) | **Nano Banana** (только NB поддерживает экстрим) |
| Дешёвая массовая генерация | **Nano Banana 2 Lite** или **gpt-image-1-mini** |
| Фотореализм с тонкой типографикой/UI | **GPT Image 2** |
| Точное editing с preservation (try-on, swap, weather) | **GPT Image 2** (в editing у него лучшая identity-preservation) |
| Маленький плотный текст в кадре | **GPT Image 2** (`quality: high`) |
| Брендовая полиграфия / постеры с EXACT TEXT | **GPT Image 2** |
| Сториборды, комиксы (последовательность) | **Nano Banana** (extreme ratios + thinking) |
| Storyboard с фокусом на типографике | **GPT Image 2** |
| Style transfer без упоминаемых референс-картинок | **GPT Image 2** (concrete visual targets) |
| Рендер из 14+ референсов | **Nano Banana Pro** (до 14) или **GPT Image 2** (до 16) |

## Когда что выигрывает

### Nano Banana выигрывает в
- **Image grounding.** NB2 ищет реальные изображения в интернете перед генерацией — точная архитектура конкретного храма, моста, площади; конкретные виды животных, растений. GPT Image 2 этого не делает.
- **Экстремальные пропорции.** 1:8, 8:1, 1:4, 4:1 — баннеры, скроллы, комикс-стрипы. У GPT Image 2 max 3:1.
- **«Thinking» режим.** Сложные инфографики со spatial logic.
- **Цена/скорость.** NB2 = $0.04/img.

### GPT Image 2 выигрывает в
- **Identity preservation в edit.** Меняешь одежду / погоду / фон — лицо, поза, геометрия не плывут. Двухколоночная логика (change / preserve) работает как контракт.
- **Тонкий текст в кадре.** Маленькие подписи, легенды, footnotes, multi-font layouts. На `quality: high` рендерит чётче.
- **UI-моки и продуктовые скриншоты.** Иерархия, реальные интерфейс-элементы, читаемые лейблы.
- **Структурированный 5-slot промпт.** Чёткое разделение Scene/Subject/Details/Use case/Constraints даёт предсказуемость.
- **`quality` рычаг.** low/medium/high — осознанный trade-off скорости и точности.

### Где обе модели одинаково хороши
- Photorealistic портреты.
- Product shots на нейтральном фоне.
- Минималистичные постеры.
- Editorial-фотография.

## Различия в синтаксисе промпта

| Аспект | Nano Banana | GPT Image 2 |
|--------|-------------|-------------|
| Стиль промпта | Натуральный язык, 1-2 параграфа | 5-slot с лейблами секций |
| Камера/линза | **Не указывать** числа (50mm, f/2.8) — NB игнорит | Можно «50mm feel», но как high-level look |
| «Stunning/epic/masterpiece» | Игнорит, не вредит | **Anti-slop**: вредит, делает результат хуже |
| Text in image | `"..."` в кавычках, font + position | `"..."` или ALL CAPS + «no extra words / no duplicate text» |
| Negative framing | Использовать позитив | Использовать позитив + явный preserve list |
| Сложные сцены | JSON для 5+ элементов | 5-slot template со секциями |
| Edit | «Keep X same, change Y» | «Change: X / Preserve: Y / Constraints: Z» — повторять preserve каждую итерацию |
| Множественные референсы | До 14, индексировать | До 16, индексировать с ролью («Image 1: base», «Image 2: jacket reference») |

## Стоимость (ориентир)

| Модель | Цена | Заметки |
|--------|------|---------|
| Nano Banana 2 Lite | ~$0.034/img | Только 1K, ~4 сек. Черновики и массовые батчи |
| Nano Banana 2 (Flash) | ~$0.04/img | Default для большинства задач |
| Nano Banana Pro | ~$0.15/img | Сложные сцены, до 14 рефов |
| GPT Image 2 (`low`) | дёшево | Latency-sensitive, превью |
| GPT Image 2 (`medium`) | средне | Default для GPT Image |
| GPT Image 2 (`high`) | дороже | Маленький текст, brand-sensitive, photorealism |
| gpt-image-1-mini | дешёвый | Высокообъёмная exploratory-генерация |

> Скилл сам не запускает генерацию — выдаёт промпт. Модель/quality указываем рядом с промптом как мета.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/models.md -->


<!-- SOURCE_FILE_START: skills/image/references/multi-panel.md -->
# SOURCE FILE: `skills/image/references/multi-panel.md`

# Multi-Panel Compositions

Single-image layouts containing multiple frames, panels, or grid cells. Unlike [storyboards.md](storyboards.md) (sequential images generated one-at-a-time), these patterns produce **one image** with all panels baked in.

Core principle: explicitly number and describe every panel. Models need panel-by-panel instructions — vague requests like "show multiple angles" produce inconsistent grids.

---

## 1. 9-Cell Grid Storyboard

> For a product-focused narrative variant, see [patterns/ecommerce.md](patterns/ecommerce.md#9-panel-tvc-storyboard-grid).

**When to use:** TVC or commercial shot breakdown — one image = 9 panels with scene titles and timestamps.

### Template (5-slot format)

```
Scene: Dark storyboard layout — 3x3 grid of cinematic frames for a {duration}-second {product_name} commercial. Each cell has a thin dark border. Below each cell: scene number, title, and timestamp in small white sans-serif text on dark background.

Subject: {product_name} commercial storyboard showing the complete narrative arc across 9 panels.

Important Details:
Panel 1 (0:00–{t1}): {scene_1_description}
Panel 2 ({t1}–{t2}): {scene_2_description}
Panel 3 ({t2}–{t3}): {scene_3_description}
Panel 4 ({t3}–{t4}): {scene_4_description}
Panel 5 ({t4}–{t5}): {scene_5_description}
Panel 6 ({t5}–{t6}): {scene_6_description}
Panel 7 ({t6}–{t7}): {scene_7_description}
Panel 8 ({t7}–{t8}): {scene_8_description}
Panel 9 ({t8}–{duration}): {scene_9_description}

Each panel labeled below: "Scene {N}: {title}" and "{start}–{end}"

Use Case: Pre-production storyboard for video production team
Constraints: All 9 panels must be clearly separated, no merged cells, every panel must contain distinct content, timestamps must be legible, {language} titles
```

**Variables:**
- `{product_name}` — brand/product
- `{duration}` — total spot length (e.g., "30", "60")
- `{t1}` through `{t8}` — timestamp boundaries
- `{scene_1_description}` through `{scene_9_description}` — shot description per panel
- `{language}` — "Chinese" / "English" / "bilingual"

**Recommended size:** 1536x1024 (landscape)
**Model:** GPT Image 2 `quality: high` (text-heavy — timestamps and titles need legibility)
**Common pitfalls:**
- Omitting panel numbers causes the model to merge or skip panels
- Vague scene descriptions produce near-identical panels — each must have a distinct action, angle, or subject
- Timestamps in very small text need `quality: high` to remain readable

---

## 2. 2x2 Editorial Portrait Grid

**When to use:** Same person shown from 4 angles/crops in one image for an editorial or casting look.

### Template (5-slot format)

```
Scene: 2x2 grid of four editorial portraits, minimal gap between panels. {background_description}. {lighting_style}.

Subject: {subject_description} — same person in all four panels, consistent identity and wardrobe.

Important Details:
Top-left: front-facing portrait, direct eye contact, shoulders up
Top-right: extreme macro close-up of face — eyes, skin texture, freckles visible
Bottom-left: lower angle looking up, chin slightly raised, confident expression
Bottom-right: side profile, clean silhouette against background

Consistent lighting across all four panels. Skin texture realistic, no airbrushing.

Use Case: editorial photography, model portfolio, casting composite
Constraints: same person in every panel, no wardrobe changes between panels, no extra people, no text overlays
```

**Variables:**
- `{subject_description}` — age, appearance, wardrobe (e.g., "woman in her 30s, dark curly hair, white linen shirt")
- `{background_description}` — (e.g., "soft gray studio backdrop")
- `{lighting_style}` — (e.g., "single key light from upper left, subtle fill from right")

**Recommended size:** 1024x1024 (square) or 1024x1536 (vertical for portrait emphasis)
**Model:** GPT Image 2 `quality: medium` or Nano Banana Pro (both handle photorealistic portraits well)
**Common pitfalls:**
- Not specifying "same person" in every panel — model may generate four different people
- Omitting which quadrant gets which angle — model arranges arbitrarily
- Requesting too-different crops (full body + extreme close-up) creates scale inconsistency within the grid

---

## 3. 3-Panel Campaign Collage

**When to use:** Hero shot + close-up + action for a campaign visual — horizontal or vertical triptych.

### Template (5-slot format)

```
Scene: Three-panel {orientation} collage for {brand_name} campaign. Panels separated by thin white lines.

Subject: {model_description} showcasing {product_description}.

Important Details:
Panel 1 (left/top): Hero wide shot — full figure of model with product, environmental context, lifestyle setting
Panel 2 (center/middle): Close-up product detail — {product_detail_description}, tactile textures, sharp focus
Panel 3 (right/bottom): Action shot — model using/wearing/interacting with product, candid energy, slight motion blur on extremities

Consistent warm golden-hour lighting across all panels. Same model identity throughout.
{typography_instruction}

Use Case: social media campaign visual, brand lookbook
Constraints: same person across all panels, consistent color grading, no stock-photo stiffness, {product_name} must be visible in every panel
```

**Variables:**
- `{orientation}` — "horizontal" (side by side) or "vertical" (stacked)
- `{brand_name}`, `{product_name}`, `{product_description}` — brand context
- `{model_description}` — who appears
- `{product_detail_description}` — what the close-up shows
- `{typography_instruction}` — e.g., `Text: "{HEADLINE}" in bold condensed white, overlaid on Panel 1 lower third` or omit for no text

**Recommended size:** 1536x1024 (horizontal triptych) or 1024x1536 (vertical triptych)
**Model:** GPT Image 2 `quality: medium` — if text overlay needed, use `quality: high`
**Common pitfalls:**
- Not specifying panel order — "hero, close-up, action" without left/center/right assignment
- Lighting inconsistency when mixing indoor close-up with outdoor hero shot — specify unified lighting
- Forgetting to mention subject consistency causes three different models

---

## 4. 4x3 Borderless Grid

**When to use:** 12 panels telling a story or showing moods — no gaps between panels, seamless mosaic feel.

### Template (5-slot format)

```
Scene: 4x3 borderless grid (4 columns, 3 rows) where each of the 12 panels is an independent image but panels share no borders, gaps, or dividers — edges touch seamlessly. Overall theme: {theme}.

Subject: {subject_description} — maintain strong subject consistency across all 12 panels.

Important Details:
Row 1: {panel_1}, {panel_2}, {panel_3}, {panel_4}
Row 2: {panel_5}, {panel_6}, {panel_7}, {panel_8}
Row 3: {panel_9}, {panel_10}, {panel_11}, {panel_12}

Style: {style_description}
Mood progression: {mood_arc}
Each panel is an independent composition but the overall grid reads as a unified artwork.

Use Case: mood board, editorial spread, social media carousel preview, album artwork
Constraints: borderless — no white lines, no black borders, no gaps between panels. Same subject identity across all panels. No text in panels.
```

**Variables:**
- `{subject_description}` — who/what appears across panels
- `{theme}` — overarching concept (e.g., "solitude in a city", "four seasons of a garden")
- `{panel_1}` through `{panel_12}` — brief shot description per cell
- `{style_description}` — visual style (e.g., "35mm film grain, desaturated palette")
- `{mood_arc}` — how energy changes across the grid (e.g., "calm morning to chaotic night")

**Recommended size:** 1536x1024 (landscape) — gives each cell enough resolution
**Model:** Nano Banana Pro (handles complex multi-element compositions with thinking mode; no text needed)
**Common pitfalls:**
- Saying "borderless" is not enough — explicitly state "no white lines, no black borders, no gaps"
- 12 panels in one image pushes detail limits — keep per-panel descriptions short and visually distinct
- Without explicit subject consistency instructions, each panel may feature a different person/object

---

## 5. 6-Frame Cinematic Sequence

**When to use:** Fashion editorial or film-style sequence — multiple camera angles of the same scene in one image.

### Template (5-slot format)

```
Scene: 6-frame cinematic sequence arranged in a 3x2 grid. Dark film-strip aesthetic with thin black borders. {location_description}.

Subject: {subject_description}, wearing {wardrobe_description}. Same person, same outfit, same location across all 6 frames.

Important Details:
Frame 1 (top-left): Top-down bird's eye view — subject seen from directly above, full body visible against ground/floor
Frame 2 (top-center): Low angle looking up — subject towering over camera, dramatic perspective, sky/ceiling visible
Frame 3 (top-right): Wide isolation shot — subject small in frame, vast environment dominates, sense of scale
Frame 4 (bottom-left): Close-up with slight tilt — face and upper body, Dutch angle, intimate intensity
Frame 5 (bottom-center): Motion frame — subject mid-action ({motion_action}), natural motion blur on limbs
Frame 6 (bottom-right): Grounded final — medium shot, subject at rest, direct gaze, resolving the sequence

Photographer reference: {photographer_style}
Lighting: consistent {lighting_description} across all frames

Use Case: fashion editorial, film lookbook, director's shot list visualization
Constraints: same person and wardrobe in every frame, no costume changes, consistent color grading, no text overlays
```

**Variables:**
- `{subject_description}` — model details
- `{wardrobe_description}` — clothing
- `{location_description}` — setting
- `{motion_action}` — what the motion frame captures (e.g., "walking forward", "turning sharply", "jumping")
- `{photographer_style}` — (e.g., "Peter Lindbergh desaturated realism", "Helmut Newton dramatic contrast")
- `{lighting_description}` — (e.g., "overcast natural light, soft shadows")

**Recommended size:** 1536x1024 (landscape, 3x2 grid)
**Model:** GPT Image 2 `quality: medium` or Nano Banana Pro
**Common pitfalls:**
- Not naming each frame explicitly — "various angles" is too vague, the model needs per-frame instructions
- Top-down and low-angle in the same grid confuse the model if you don't anchor each frame to a grid position
- Motion blur instruction must be specific ("blur on hands and feet") or the model applies blur everywhere

---

## 6. Before/After Split

**When to use:** Product transformation, makeover, time comparison, renovation — two states side by side.

### Template (5-slot format)

```
Scene: Single image split into left and right halves with a {divider_style} dividing line down the center. Before/after comparison.

Subject: {subject_description}

Important Details:
Left half (BEFORE): {before_description} — {before_condition}
Right half (AFTER): {after_description} — {after_condition}

The transition at the center line should feel {transition_style}. Same camera angle, same framing, same background perspective in both halves — only the subject's state changes.

Use Case: {use_case}
Constraints: identical composition and camera angle on both sides, same lighting direction, no text unless specified, the dividing line must be clearly visible
```

**Variables:**
- `{subject_description}` — what is being compared
- `{before_description}` / `{before_condition}` — left side state (e.g., "faded, cracked wall with peeling paint")
- `{after_description}` / `{after_condition}` — right side state (e.g., "freshly painted wall, smooth finish, vibrant color")
- `{divider_style}` — "thin white line" / "subtle gradient blend" / "sharp vertical cut"
- `{transition_style}` — "clean and abrupt" / "natural, as if wiping away"
- `{use_case}` — "product marketing", "renovation portfolio", "skincare results"

**Recommended size:** 1536x1024 (landscape — gives each half a portrait-like proportion)
**Model:** GPT Image 2 `quality: medium` — for text labels ("BEFORE" / "AFTER"), use `quality: high`
**Common pitfalls:**
- Not specifying "same camera angle both sides" — model may show two completely different viewpoints
- Without a visible divider, the two halves can merge into one ambiguous scene
- Left/right assignment matters — always state which side is before and which is after

---

## 7. 12-Panel Storyboard Poster

**When to use:** Full narrative in one image — 3x4 grid (3 columns, 4 rows) for animation or video pre-production.

### Template (5-slot format)

```
Scene: 12-panel storyboard poster, 3 columns x 4 rows. Dark background with each panel in a clean rectangular frame. "{title}" in bold white text at the top of the image. Below each panel: scene number and one-line description in small white text.

Subject: {character_description} — maintain consistent character design, proportions, and colors across all 12 panels.

Important Details:
Panel 1: {scene_1} — "{caption_1}"
Panel 2: {scene_2} — "{caption_2}"
Panel 3: {scene_3} — "{caption_3}"
Panel 4: {scene_4} — "{caption_4}"
Panel 5: {scene_5} — "{caption_5}"
Panel 6: {scene_6} — "{caption_6}"
Panel 7: {scene_7} — "{caption_7}"
Panel 8: {scene_8} — "{caption_8}"
Panel 9: {scene_9} — "{caption_9}"
Panel 10: {scene_10} — "{caption_10}"
Panel 11: {scene_11} — "{caption_11}"
Panel 12: {scene_12} — "{caption_12}"

Panels read left-to-right, top-to-bottom (like a comic page). Character appearance, clothing, and color palette must stay identical across all 12 panels — only pose, expression, angle, and environment change.

Style: {art_style}

Use Case: animation pre-production, pitch deck visualization, narrative overview poster
Constraints: all 12 panels must be distinct scenes (no duplicates), character consistency is critical, scene numbers must be legible, {language} captions
Quality: high
```

**Variables:**
- `{title}` — project/episode title displayed at top
- `{character_description}` — detailed character design (colors, outfit, distinguishing features)
- `{scene_1}` through `{scene_12}` — visual description of each panel
- `{caption_1}` through `{caption_12}` — text label under each panel
- `{art_style}` — (e.g., "Pixar-style 3D", "anime cel shading", "watercolor illustration", "graphic novel ink")
- `{language}` — caption language

**Recommended size:** 1024x1536 (portrait — 3 columns x 4 rows needs vertical space)
**Model:** GPT Image 2 `quality: high` (text-heavy — scene numbers and captions must be readable)
**Common pitfalls:**
- Character drift is the biggest risk at 12 panels — repeat character design details in the prompt, not just "same character"
- Without explicit scene numbering in the prompt, panels may appear in random order
- 12 panels with captions is extremely text-dense — keep captions under 5 words each for legibility
- Art style must be stated once and applied uniformly; mixing styles across panels produces visual chaos

---

## General Multi-Panel Tips

**Panel count vs. detail trade-off:** More panels = less detail per panel. 4 panels allow rich per-panel descriptions; 12 panels need brief, visually distinct descriptions (3-8 words each).

**Subject consistency:** Always include an explicit instruction: "same person / same character / same product across all panels." Repeat key identity markers (hair color, clothing, distinguishing features) rather than saying "same as before."

**Grid specification:** Always state the grid dimensions (e.g., "3x2 grid, 3 columns 2 rows"). Saying "6 panels" without layout instruction lets the model choose an unpredictable arrangement.

**Borders and gaps:** Be explicit — "thin white border between panels" or "borderless, no gaps." Default behavior varies by model and is unreliable.

**Reading order:** State it: "left-to-right, top-to-bottom" or "numbered 1-9 starting top-left." Without this, narrative flow may be jumbled.

**Model selection summary:**
- Text/labels in panels --> GPT Image 2 `quality: high`
- No text, complex composition --> Nano Banana Pro
- Budget/exploration --> Nano Banana 2 or GPT Image 2 `quality: low`

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/multi-panel.md -->


<!-- SOURCE_FILE_START: skills/image/references/nano-banana.md -->
# SOURCE FILE: `skills/image/references/nano-banana.md`

# Nano Banana — Specific Rules

Три тира. «Thinking» модели — понимают намерение, физику, композицию.

| Тир | Model ID | Роль |
|-----|----------|------|
| **NB2 Lite** | `gemini-3.1-flash-lite-image` | Самая быстрая и дешёвая ($0.034, ~4 сек), только 1K. Черновики, массовые батчи |
| **NB2** (Flash) | `gemini-3.1-flash-image` | Дефолтный workhorse: Pro-фичи (текст, 4K, grounding, консистентность) на скорости Flash |
| **NBP** (Pro) | `gemini-3-pro-image` | Топ-тир: сложные многослойные сцены, максимум reasoning и контроля |

## Стиль промпта

Натуральный язык, 1-2 параграфа. Структура свободная, но порядок помогает:
**Subject + Action + Location/context + Composition + Style**

```
A cinematic wide shot of a futuristic sports car speeding through a rainy
Tokyo street at night. Neon signs reflect off wet pavement and metallic
chassis. Format: 16:9.
```

## Что НЕ указывать

- Числовые параметры объектива: **50mm, 85mm, f/2.8, ISO 400** — NB игнорит. Используй описание: «shallow depth of field», «wide-angle distortion».
- Tag-soup: «cool, modern, 4k, cinematic» — пишет связным предложением.

## Уникальные возможности

### Image Grounding (NB2 only)
NB2 ищет реальные изображения в интернете до генерации. Архитектурно точные конкретные локации, корректные виды животных/растений.

```
Generate a cinematic, golden-hour photograph of [SPECIFIC REAL PLACE].
Ensure the architectural details, the spire, the surrounding square, and
the landscape are accurate to reality.
```

**Работает:** здания, мосты, площади, виды животных, виды растений, насекомые.
**Не работает:** конкретные люди.

### Extreme Aspect Ratios (NB2 only)

1:8, 8:1, 1:4, 4:1 — для баннеров, скроллов, комикс-стрипов.

```
Create a 4-panel horizontal comic strip (aspect ratio 4:1).
The story follows [CHARACTER] doing [ACTION] that ends with a twist.
Use a vibrant comic book style. Keep character design consistent.
```

Стандартные: 1:1, 3:2, 2:3, 3:4, 4:3, 4:5, 5:4, 9:16, 16:9, 21:9.

### Thinking Mode

Включён по умолчанию; у NBP отключить нельзя (модель рисует до 2 «thought images» в бэкенде, они не тарифицируются как картинки, но thinking-токены платные). У NB2 есть рычаг `thinking_level: minimal | high` (default `minimal`) — поднимай до `high` для:
- Невнятных результатов, требующих reasoning
- Сложных инфографик со spatial logic
- Grounding + spatial reasoning одновременно

### Multi-Reference (лимиты по тирам)

| | NB2 Lite | NB2 | NBP |
|---|---|---|---|
| High-fidelity объекты | до 14 | до 10 | до 6 |
| Character-consistency рефы | нет | до 4 | до 5 |
| Style рефы | нет | нет | до 3 |

```
[Image 1: face]
[Image 2: outfit]
[Image 3: background]
Combine: face from Image 1, outfit style from Image 2, setting from Image 3.
Match lighting and perspective.
```

### JSON для сложных сцен (5+ элементов)

```json
{
  "subject": {"description": "main subject", "expression": "emotion/pose"},
  "photography": {"angle": "eye-level", "shot_type": "waist-up", "aspect_ratio": "16:9"},
  "background": {"setting": "location", "lighting": "soft natural"}
}
```

## Editing у Nano Banana

Conversational, без масок:

```
Remove [OBJECT] from this image.
Fill with [LOGICAL REPLACEMENT] matching surroundings.
Keep [PRESERVED ELEMENTS] exactly the same.
```

После генерации добавляй итеративно:
- «Make it warmer»
- «Increase contrast»
- «Soften background, add blur»
- «Change headline color to #3b82f6»

Interactions API держит контекст сессии — до 3 последовательных правок стэкаются без потери исходника. Правило «Edit, don't re-roll»: картинка верна на 80% — проси точечное изменение, а не новую генерацию.

## Text Rendering

- SOTA по 100+ языкам.
- Font можно называть: «Century Gothic 12px», «Brush Script», «Impact», «Heavy blocky sans-serif».
- Multi-language в одном кадре работает.
- Hack: для сложного текста — сначала попроси модель **написать текст**, потом отдельным промптом «вставь этот текст в картинку».

## Resolution / Cost

| Resolution | Использование |
|------------|---------------|
| 0.5K | Самая дешёвая, batch и А/B варианты |
| 1K | Default |
| 2K | Финальный отбор |
| 4K | Печать, hero-ассеты |

**Workflow:** прогон вариантов на `0.5K` flash (или NB2 Lite на 1K) → отбор → переген победителя на `2K`/`4K`.

В API `image_size` пишется строго с заглавной K (`1K`, `2K`, `4K`) — `1k` отклоняется. `512px` есть только у NB2; Lite — только 1K. Без указания размера модель матчит вход, иначе 1:1.

## Кейфреймы для видео

Nano Banana — image-слой перед motion-слоем. Всё критичное фиксируется на картинке ДО анимации: identity, композиция, aspect ratio, видимый текст, состояние продукта. Видеомодель усиливает любую неоднозначность стилла.

- **Character sheet / hero frame.** Утверди один кадр-эталон персонажа, на него ссылаются все последующие video-промпты.
- **Aspect ratio сразу целевой.** Кампании нужен вертикальный ролик — генери 9:16, а не кропай после анимации (тихая точка отказа).
- **Хэндофф в видеомодель — motion brief, не пересказ.** Движение камеры, движение субъекта, движение фона, длительность, framing lock, запрещённые изменения. Видео-промпт не переописывает то, что уже есть в кадре.
- Downstream любой: Veo 3.1, Kling 3.0, Seedance 2.0/2.5, Gemini Omni Flash (штатная пара Google, 10-сек клипы). Батч картинок → ревью-гейт → в видео уходят только одобренные стиллы.

## Известные фейлы

- Руки и лица всё ещё плывут (пальцы, суставы, дрейф likeness) — явные anatomy-инструкции + рефы + перегенерации. Есть отчёты, что NBP держит лица хуже NB2.
- Мелкий текст мылится на 1K — для плотного текста 2K+ или GPT Image 2.
- Инфографика может содержать фактически неверные данные — цифры проверять всегда, grounding помогает, но не гарантирует.
- Склонность к overcooked HDR / пересату — проси «natural contrast, no HDR look».
- SynthID-водяной знак стоит на всех генерациях (невидимый); на Vertex дополнительно C2PA.

## Когда переключаться NB2 → NBP

- NB2 не справляется со сложным многослойным промптом.
- Нужен максимум референсов с разбивкой по ролям (6 объектов + 5 character + 3 style).
- Photoreal с очень тонкой работой по материалам и свету.
- NBP медленнее и дороже; на лицах иногда проигрывает NB2 — для портретной серии сначала тестируй оба.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/nano-banana.md -->


<!-- SOURCE_FILE_START: skills/image/references/patterns/character-design.md -->
# SOURCE FILE: `skills/image/references/patterns/character-design.md`

# Character Design Patterns

Reusable prompt templates for character turnarounds, expression sheets, outfit variants, and collectible/card formats. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Character Turnaround Sheet (3-View)

Use for game or animation pre-production — front, side, and back views of a character on a single white canvas with color callouts and height reference lines.

<!-- Source concept: character model sheet / turnaround sheet for 3D modelers and animators -->

```
Scene: clean white background, flat even lighting with no cast shadows, thin horizontal height reference lines in #CCCCCC spanning the full width at head, shoulder, waist, knee, and foot level
Subject: {character_name} — {character_description} — shown in three views arranged left to right: front view (facing camera), three-quarter side view (turned 75 degrees right), back view (facing away)
Important Details: all three views share identical proportions and vertical alignment along the height lines, feet on the same baseline, arms relaxed at sides for clear silhouette reading, color callout annotations — small circles of each key color ({color_1} {hex_1}, {color_2} {hex_2}, {color_3} {hex_3}) connected by thin #999999 leader lines to the corresponding material on the front view, fine line weight for height markers, clothing folds and seam lines consistent across all three angles
Use Case: game character pre-production, animation model sheet, 3D reference handoff
Constraints: no background elements, no props in hands, no dramatic poses — neutral standing pose only, all three views must depict the exact same character with identical outfit and proportions, no drop shadows, no gradient backgrounds
```

**Key levers:** `{character_name}`, `{character_description}` (age, build, hairstyle, outfit — be specific), `{color_1}`/`{hex_1}` through `{color_3}`/`{hex_3}` (key palette colors for callouts, e.g. jacket navy #1B2A4A, skin warm beige #D4A574, hair auburn #8B3A2F)

**Recommended model:** GPT Image 2 (`quality: high`) — height reference lines and color callout text require precise rendering

---

## Expression Sheet

Use to produce a grid of 6–9 facial expressions for the same character — consistent head angle and art style, with emotion labels under each face.

<!-- Source concept: character expression/emotion reference sheet for animation or visual novel production -->

```
Scene: white background, 3x3 grid (or 3x2 for 6 expressions) with thin #DDDDDD divider lines, each cell contains one head-and-shoulders portrait
Subject: {character_name} — {character_description} — same head angle (three-quarter left), same hairstyle, same lighting across all cells
Important Details:
  Cell 1: neutral — relaxed brow, closed mouth, calm eyes. Label: "NEUTRAL"
  Cell 2: happy — genuine smile reaching the eyes, raised cheeks. Label: "HAPPY"
  Cell 3: angry — furrowed brow, clenched jaw, narrowed eyes. Label: "ANGRY"
  Cell 4: sad — downturned mouth, glistening eyes, slightly lowered head. Label: "SAD"
  Cell 5: surprised — wide eyes, raised eyebrows, open mouth. Label: "SURPRISED"
  Cell 6: disgusted — wrinkled nose, upper lip raised, squinted eyes. Label: "DISGUSTED"
  {extra_expressions}
  Labels in small {label_font} beneath each cell, #555555 text
  Consistent {art_style} rendering across all cells — skin tone, line weight, shading approach identical
Use Case: animation expression reference, visual novel sprite guide, game character documentation
Constraints: same character identity in every cell — no variation in hair, accessories, skin tone, or clothing between expressions, head angle stays fixed, no hand gestures, labels must be legible
```

**Key levers:** `{character_name}`, `{character_description}` (face shape, skin tone, hair, distinguishing marks), `{art_style}` (clean cel-shaded anime, painterly semi-realism, flat vector illustration), `{label_font}` (condensed sans-serif, monospace, rounded sans), `{extra_expressions}` (add cells 7-9: e.g. "Cell 7: smirk — one corner of mouth raised, knowing look. Label: 'SMIRK'")

**Recommended model:** GPT Image 2 (`quality: high`) — text labels and consistent facial identity across 9 cells need precise control

---

## Outfit Variant Grid

Use to show one character in multiple outfits or costumes — for fashion exploration, game skin concepts, or wardrobe design.

<!-- Source concept: character costume/skin variant sheet for fashion or game design -->

```
Scene: light neutral background ({bg_color}), {grid_layout} grid, thin white gaps between cells, soft even front lighting in every cell
Subject: {character_name} — {character_description} — same pose ({pose_description}) in every cell, only the outfit changes
Important Details:
  Cell 1: {outfit_1_name} — {outfit_1_description}
  Cell 2: {outfit_2_name} — {outfit_2_description}
  Cell 3: {outfit_3_name} — {outfit_3_description}
  Cell 4: {outfit_4_name} — {outfit_4_description}
  Cell 5: {outfit_5_name} — {outfit_5_description}
  Cell 6: {outfit_6_name} — {outfit_6_description}
  Outfit name in small bold sans-serif centered below each cell, #333333 text
  Character body proportions, face, hairstyle, and skin tone identical across all cells — only clothing and accessories differ
Use Case: game skin lineup, fashion mood board, costume design exploration
Constraints: same character identity and pose in every cell, no background scenery — character only, outfit labels must be readable, no overlapping garments between cells, {grid_layout} layout must be uniform
```

**Key levers:** `{character_name}`, `{character_description}` (build, face, hair — anchor identity), `{bg_color}` (#F0F0F0 light gray, #FFF8F0 warm cream, #E8EDF2 cool blue-gray), `{grid_layout}` (2x3 or 3x3), `{pose_description}` (hands on hips, relaxed standing, one hand raised), `{outfit_N_name}` / `{outfit_N_description}` (e.g. "Street Casual" — oversized denim jacket, white tee, black cargo pants, chunky sneakers)

**Recommended model:** GPT Image 2 (`quality: medium`) — character consistency is the priority; `high` only if outfit labels need fine legibility

---

## Chibi / Mini-Me Collectible

Use to transform a realistic character into a cute 3D collectible figurine — oversized head, compact body, multiple poses performing different activities.

<!-- Source concept: chibi/super-deformed vinyl collectible figurine with consistent identity across poses -->

```
Scene: soft gradient background ({bg_gradient}), studio product lighting with rim light from behind and soft fill from front, subtle ground shadow beneath each figurine
Subject: chibi-style 3D collectible figurine of {character_name} — {character_description_simplified} — large head (roughly 1:2 head-to-body ratio), rounded limbs, smooth matte vinyl surface, {num_poses} poses arranged in a row
Important Details:
  Pose 1: {pose_1_description}
  Pose 2: {pose_2_description}
  Pose 3: {pose_3_description}
  {extra_poses}
  Face retains recognizable features from the original character — {face_markers} — simplified into the chibi style with large round eyes and small nose/mouth
  Outfit matches the original: {outfit_simplified} — colors preserved ({color_palette}), details reduced to clean shapes
  Each figurine sits on a small circular base ({base_color} matte finish)
  Vinyl toy aesthetic — visible seam line at sides, slight glossy highlight on forehead and cheeks
Use Case: merchandise concept, social media avatar set, fan collectible design
Constraints: consistent face and outfit across all poses, chibi proportions must stay uniform (no realistic proportions creeping in), no text on bases, smooth render — not cel-shaded, matte vinyl material throughout
```

**Key levers:** `{character_name}`, `{character_description_simplified}` (key outfit and hair only), `{face_markers}` (e.g. round glasses, scar on left cheek, green eyes), `{color_palette}` (hex values for 2-3 dominant colors), `{bg_gradient}` (#F5F0EB to #FFFFFF warm, #E0E8F0 to #FFFFFF cool), `{num_poses}` (3-5), `{pose_N_description}` (e.g. sitting cross-legged reading a book, waving with both hands, holding a coffee cup), `{base_color}` (white, black, matching character's main color)

**Recommended model:** GPT Image 2 (`quality: medium`) — smooth 3D vinyl surfaces render well at medium; `high` for marketing-ready close-ups

### Nano Banana version:

```
A row of {num_poses} chibi-style 3D vinyl collectible figurines of {character_name}, each in a different pose. Large head (1:2 head-to-body ratio), rounded limbs, smooth matte vinyl surface with visible seam lines and subtle glossy highlights on the forehead. Face retains {face_markers} simplified into chibi proportions with large round eyes. Outfit: {outfit_simplified} in {color_palette}. Poses left to right: {pose_1_description}, {pose_2_description}, {pose_3_description}. Each figurine on a small circular {base_color} matte base. Soft gradient background ({bg_gradient}), studio product lighting with rim light from behind and soft fill from front, subtle ground shadow. Format: 16:9.
```

---

## Anime-Style Character Card

Use for a full character reference card with portrait, full body, key items, and color palette — organized on a white background in a professional concept art layout.

<!-- Source concept: anime/game character reference sheet with stats, items, and palette swatches -->

```
Scene: white background, organized reference card layout divided into clear sections with thin #CCCCCC separator lines
Subject: {character_name} — {character_description} — anime-style rendering with clean line art and flat cel shading
Important Details:
  Left section (40% width): full-body standing pose, front-facing, arms slightly away from body to show full outfit, feet visible, confident neutral expression
  Upper-right section: portrait bust — head and shoulders, three-quarter angle, detailed face rendering showing {face_details}
  Mid-right section: {num_items} key items arranged in a row — {item_1}, {item_2}, {item_3} — each drawn at consistent scale with thin outline, labeled in small text below
  Lower-right section: color palette — {num_swatches} rectangular swatches in a horizontal strip showing the character's key colors ({swatch_colors}), hex code below each swatch
  Bottom strip: brief stat block or bio text in clean sans-serif — "Name: {character_name} | Class: {class} | Height: {height} | Affiliation: {affiliation}"
  Consistent line weight and shading style across all sections
Use Case: game character documentation, light novel illustration guide, animation production reference
Constraints: unified anime art style across all sections — portrait and full body must be the same character with identical design, items must match what the character wears/carries in the full body view, no decorative borders or ornamental frames, text must be legible at screen resolution
```

**Key levers:** `{character_name}`, `{character_description}` (detailed: hair color/style, eye color, outfit layers, accessories), `{face_details}` (distinctive facial features — e.g. heterochromia, facial tattoo, sharp jawline), `{item_1}`/`{item_2}`/`{item_3}` (signature weapon, accessory, artifact), `{swatch_colors}` (e.g. midnight blue #191970, cherry red #C41E3A, silver #C0C0C0, warm skin #E8B89D), `{num_swatches}` (4-6), `{class}` / `{height}` / `{affiliation}` (stat block fields)

**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout with hex codes, labels, and stat block requires precise rendering

### Nano Banana version:

```
An anime-style character reference card for {character_name} on a white background. Left side: full-body standing pose, front-facing, clean cel-shaded anime rendering — {character_description}. Upper right: portrait bust at three-quarter angle showing {face_details}. Mid-right: key items laid out in a row — {item_1}, {item_2}, {item_3} — each drawn consistently and labeled. Lower right: horizontal color palette strip with {num_swatches} rectangular swatches ({swatch_colors}). Clean layout with thin gray separator lines between sections. Professional concept art quality, consistent line weight throughout. Format: 3:4.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/patterns/character-design.md -->


<!-- SOURCE_FILE_START: skills/image/references/patterns/ecommerce.md -->
# SOURCE FILE: `skills/image/references/patterns/ecommerce.md`

# E-Commerce Product Photography Patterns

Reusable prompt templates for product ads, packaging, and commercial visuals. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Miniature Diorama Product Ad

Use when you need a playful, attention-grabbing product visual where tiny workers interact with an oversized product — ideal for social media ads and launch campaigns.

<!-- Source concept: miniature/tilt-shift product advertising with construction-worker scale play -->

```
Scene: clean {surface_color} tabletop studio, soft overhead diffused light, shallow depth of field with tilt-shift blur at edges
Subject: oversized {product_name} centered in frame, surrounded by miniature construction workers (1/87 scale figurines) — some climbing the packaging with tiny ladders, others operating a miniature crane to lift the cap/lid, a crew painting the label
Important Details: {product_material} surface catches key light from upper left, visible condensation/texture on product, figurines cast tiny hard shadows, warm {accent_color} hard hats on workers, fine detail on miniature tools, slightly desaturated background, eye-level camera angle
Use Case: social media product ad, Instagram carousel hero
Constraints: no text, no logos other than product label, no floating elements, product must remain recognizable and unaltered, no more than 8 figurines
```

**Key levers:** `{product_name}`, `{product_material}` (frosted glass, matte aluminum, glossy plastic), `{surface_color}` (white marble, raw concrete, light birch wood), `{accent_color}` (safety orange #FF6600, yellow #FFD600)

**Recommended model:** GPT Image 2 (`quality: high`) — precise figurine detail and product label legibility

---

## Luxury Cosmetics Studio Shot

Use for premium beauty or fragrance product photography — dark, moody, tactile surfaces with atmospheric effects.

<!-- Source concept: luxury perfume/cosmetics dark-marble studio photography with condensation and smoke -->

```
Scene: dark studio, {background_surface} surface with subtle reflections, thin layer of low-hanging smoke drifting left to right, {time_mood} ambient
Subject: {product_name} bottle/tube centered, three-quarter angle, {product_finish} catching a single key light from upper right
Important Details: fine water droplets on product surface (condensation, not spray), {accent_material} accent elements flanking the product (raw stone, dried botanicals, metal shavings), volumetric haze behind product, reflection on surface below is soft and dark, color palette restricted to {palette}, contact shadow sharp near base fading to soft
Use Case: luxury brand campaign hero, print ad, website banner
Constraints: no text overlays, no human hands, background stays dark (#0a0a0a to #1a1a1a gradient), no color spill outside the defined palette, no lens flare
```

**Key levers:** `{background_surface}` (nero marquina marble, wet obsidian slab, brushed gunmetal), `{product_finish}` (frosted glass, lacquered black, brushed gold), `{accent_material}` (raw quartz crystals, dried lavender stems, black river stones), `{palette}` (golds #C9A84C and blacks, rose #B76E79 and creams, emerald #2D6A4F and silvers), `{time_mood}` (cold blue, warm amber)

**Recommended model:** GPT Image 2 (`quality: high`) — surface materials and condensation detail

---

## 9-Panel TVC Storyboard Grid

> For a dark-themed variant with timestamps, see [multi-panel.md](../multi-panel.md#1-9-cell-grid-storyboard).

Use to present a product commercial shot breakdown in a single image — pitch decks, creative presentations, client approvals.

<!-- Source concept: 9-panel television commercial storyboard grid with numbered frames -->

```
Scene: white canvas background, clean 3x3 grid with thin #CCCCCC divider lines (2px), each cell represents one shot in a {duration}-second commercial
Subject: {product_name} commercial storyboard — each panel is a distinct camera setup
Important Details:
  Panel 1 (wide): establishing shot of {setting}, warm natural light, product not yet visible
  Panel 2 (medium): {protagonist} notices/discovers the product on {surface}
  Panel 3 (close-up): hand reaching for {product_name}, shallow depth of field
  Panel 4 (ECU): product detail — texture of {product_material}, label readable
  Panel 5 (medium): {protagonist} using/opening the product, genuine expression
  Panel 6 (reaction): close-up face, {emotion} expression, soft key light
  Panel 7 (wide): product in context of {lifestyle_scene}
  Panel 8 (beauty shot): product hero on {beauty_surface}, studio lighting
  Panel 9 (pack shot): product centered on white with "{tagline}" below in thin sans-serif, #333333
Use Case: creative pitch deck, storyboard for TVC production
Constraints: consistent character identity across all panels, no panel numbering text, uniform lighting temperature within the narrative (panels 1-7), distinct studio lighting for panels 8-9
```

**Key levers:** `{product_name}`, `{protagonist}` (woman in her 30s, young couple, family), `{setting}` (bright kitchen, outdoor terrace, urban cafe), `{emotion}` (satisfied, surprised, relaxed), `{beauty_surface}` (white marble, gradient gray), `{tagline}`, `{duration}` (15, 30)

**Recommended model:** GPT Image 2 (`quality: high`) — grid precision and text in panel 9

---

## Floating Ingredient Freeze-Frame

Use for food, beverage, or supplement products where suspended ingredients communicate freshness, flavor, or composition.

<!-- Source concept: frozen-motion ingredient explosion around product, high-speed photography aesthetic -->

```
Scene: {background_gradient} gradient backdrop, high-speed flash freeze-frame moment, clean studio environment
Subject: {product_name} container in center, tilted {tilt_angle} degrees, with {liquid_type} mid-pour arcing from the opening
Important Details: individual {ingredient_list} frozen in mid-air around the product — each element sharply focused with visible texture ({texture_details}), micro water droplets suspended alongside ingredients, single hard flash from behind (rim light on ingredients), secondary soft fill from front, liquid splash forms a clean arc with visible viscosity, product label faces camera and remains fully legible, ingredients distributed in a loose orbital pattern
Use Case: beverage packaging, food product poster, social media ad
Constraints: no ingredients overlapping the product label, no motion blur (everything frozen sharp), background must remain clean — no stray splashes hitting edges, no more than {max_ingredients} floating elements, no artificial glow effects
```

**Key levers:** `{product_name}`, `{background_gradient}` (#F5F0EB to #FFFFFF for light, #1A0A2E to #0D0D0D for dark), `{liquid_type}` (amber juice, white milk, green smoothie), `{ingredient_list}` (sliced strawberries + mint leaves + ice cubes, cocoa nibs + hazelnuts + vanilla pod), `{texture_details}` (visible seeds on strawberry cross-section, frost crystals on ice), `{tilt_angle}` (15, 25), `{max_ingredients}` (6-8)

**Recommended model:** GPT Image 2 (`quality: high`) — frozen detail precision and label legibility

---

## Inflatable Surrealism Product Poster

Use for disruptive, scroll-stopping social ads where the product packaging appears squeezed, inflated, or physically distorted as if made of soft rubber or vinyl.

<!-- Source concept: inflatable surrealism — product packaging rendered as squeezed/puffy/distorted soft objects -->

```
Scene: solid {background_color} background, soft even studio lighting with no hard shadows, slightly elevated camera angle (15 degrees above eye level)
Subject: {product_name} packaging reimagined as a puffy inflatable vinyl object — the shape is recognizable but squeezed at the middle as if gripped by an invisible hand, seams visible where vinyl panels meet, surface slightly reflective like a pool float
Important Details: {product_color_scheme} preserved on the inflated surface but stretched and slightly warped around curves, visible air valve at the bottom edge (small brass circle), subtle wrinkles where the vinyl compresses, the brand name/logo distorted by the inflation but still readable, two or three {companion_objects} nearby also inflated (matching aesthetic), environment reflection on glossy vinyl surface, cast shadow soft and diffused below
Use Case: disruptive social media ad, brand campaign poster, billboard
Constraints: product must remain identifiable despite distortion, no liquid, no particles, no humans, no text outside what exists on the packaging, vinyl texture must read as physical (not digital 3D render), background is flat color only
```

**Key levers:** `{product_name}`, `{background_color}` (bubblegum pink #FFB6C1, electric blue #007BFF, acid yellow #E8FF00), `{product_color_scheme}`, `{companion_objects}` (matching accessories, ingredient items, brand mascot elements)

**Recommended model:** NBP — complex spatial reasoning for believable physical distortion

### Nano Banana version:

```
A product poster showing {product_name} packaging transformed into a puffy inflatable vinyl object, squeezed at the middle as if gripped by an invisible hand. The surface is slightly glossy like a pool float, with visible seams where vinyl panels meet and a small brass air valve at the base. The original {product_color_scheme} is preserved but stretched and warped around the inflated curves. Brand text is distorted by the shape but still legible. Two small {companion_objects} sit nearby, also inflated in the same vinyl style. Solid {background_color} background, soft even studio light, slightly elevated camera angle. Soft diffused shadow below. Format: 4:5.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/patterns/ecommerce.md -->


<!-- SOURCE_FILE_START: skills/image/references/patterns/fashion-editorial.md -->
# SOURCE FILE: `skills/image/references/patterns/fashion-editorial.md`

# Fashion Editorial Patterns

Reusable prompt templates for fashion campaigns, lookbooks, and editorial shoots. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## 3-Panel Campaign Collage

Use for fashion brand campaign hero images — one wide shot combining hero pose, close-up detail, and action/movement in a triptych layout.

<!-- Source concept: fashion campaign triptych collage — hero + detail + movement panels -->

```
Scene: three vertical panels side by side on a single canvas (left 40% width, right split into two stacked panels 60% height each), thin white divider lines (3px), cohesive {lighting_setup} across all panels
Subject: {model_description} wearing {outfit_description} — same person, same outfit, three perspectives
Important Details:
  Left panel (hero): full-body three-quarter pose, {model_description} standing against {background_1}, weight shifted to one hip, direct gaze at camera, medium-format film grain, {color_grade}
  Top-right panel (detail): extreme close-up of {detail_focus} — visible weave/stitching/texture of {fabric_type}, shallow depth of field, warm directional light raking across surface
  Bottom-right panel (action): mid-stride walking shot from low angle, {background_2}, coat/fabric in motion with natural drape physics, slight motion energy in hair
  Overall: cohesive warm/cool temperature of {color_temperature}, consistent skin tone rendering across panels, editorial magazine quality
Use Case: fashion brand campaign, lookbook cover, social media carousel hero
Constraints: same person with identical features in all three panels, no text, no logos, no visible studio equipment, panels must feel like one shoot not three separate photos, no heavy retouching glow
```

**Key levers:** `{model_description}` (East Asian woman mid-20s, athletic man early 30s), `{outfit_description}`, `{detail_focus}` (collar construction, cuff button, belt buckle, shoe sole), `{fabric_type}` (raw selvedge denim, double-faced cashmere, washed silk), `{background_1}` (concrete wall, sand dune, industrial corridor), `{background_2}` (open street, field, rooftop), `{color_grade}` (lifted blacks with amber cast, desaturated teal), `{color_temperature}` (warm 4000K feel, cool overcast daylight)

**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency across panels and fabric texture detail

---

## 2x2 Editorial Portrait Grid

Use for model tests, casting cards, or editorial portfolio pages — four angles of the same person in a clean grid.

<!-- Source concept: 2x2 fashion portrait grid — same model, four setups -->

```
Scene: 2x2 grid on white canvas, thin {divider_color} divider lines (2px), all four cells use the same {background_type} with slight variation in angle
Subject: {model_description}, same {outfit_description} in all four frames
Important Details:
  Top-left: straight-on headshot, neutral expression, eyes to camera, even butterfly lighting
  Top-right: three-quarter profile, chin slightly lifted, single key light from camera-left creating defined cheekbone shadow
  Bottom-left: full profile silhouette, rim light from behind outlining jaw and nose, {background_type} slightly darker
  Bottom-right: candid moment — mid-laugh or adjusting {accessory}, natural movement, softer light
  All frames: {film_stock} color science, consistent {skin_tone_handling}, no heavy skin smoothing — visible pores and natural texture, shallow depth of field in all four
Use Case: fashion editorial spread, model comp card, casting portfolio
Constraints: identical person in all four frames (bone structure, skin, hair must match exactly), no makeup changes between frames, no text, no watermarks, backgrounds must feel cohesive not random
```

**Key levers:** `{model_description}`, `{outfit_description}` (black turtleneck, white linen shirt unbuttoned at collar), `{background_type}` (seamless medium gray, textured plaster wall, out-of-focus greenery), `{divider_color}` (#FFFFFF, #E0E0E0), `{film_stock}` (Kodak Portra 400, Fujifilm Pro 400H), `{skin_tone_handling}` (warm undertones preserved, cool-neutral rendering), `{accessory}` (earring, collar, watch)

**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency critical across four frames

---

## Streetwear Poster with Oversized Typography

Use for streetwear drops, limited edition launches, or urban fashion brand campaigns where bold type dominates the composition.

<!-- Source concept: streetwear poster with model integrated into oversized typographic layout -->

```
Scene: solid {background_color} background, graphic poster composition, typography dominates 60% of visual space
Subject: {model_description} in {streetwear_outfit}, standing or crouching in a {pose_description}, positioned {model_position} — partially overlapping the text layers
Important Details: headline "{HEADLINE_TEXT}" in extra-bold condensed {font_style}, {text_color}, occupying upper two-thirds of frame — model breaks in front of some letters and behind others (depth interplay), secondary text "{SUBHEAD_TEXT}" in thin weight {subhead_color} near bottom edge, {lighting_type} on model creating {shadow_quality} shadows, grain overlay across entire image ({grain_intensity}), composition follows rule of thirds with model at {grid_position} intersection
Use Case: streetwear brand drop poster, social media announcement, lookbook cover
Constraints: text must be fully legible even where model overlaps, no extra text or watermarks, no decorative elements besides type and model, model does not obscure more than 30% of any single letter, "{HEADLINE_TEXT}" spelled exactly as provided
Quality: high
```

**Key levers:** `{HEADLINE_TEXT}` (brand name, drop name), `{SUBHEAD_TEXT}` (date, "LIMITED DROP", collection name), `{background_color}` (off-white #F5F1EB, concrete gray #8C8C8C, matte black #0D0D0D), `{text_color}` (#000000, #FF3333, #FFFFFF), `{font_style}` (sans-serif like Druk Wide, slab-serif, stencil), `{streetwear_outfit}`, `{model_position}` (center-left, right third), `{lighting_type}` (harsh direct flash, soft window light), `{grain_intensity}` (subtle film grain, heavy 35mm grain)

**Recommended model:** GPT Image 2 (`quality: high`) — text rendering and model-type depth interplay

---

## Retro Roller Skating Sportswear Campaign

Use for playful, nostalgic sportswear or athleisure campaigns with 70s-80s visual language.

<!-- Source concept: retro roller skating / sportswear campaign with analog film aesthetic -->

A sun-drenched wide shot of {model_description} roller skating along a {location_description}. They wear {outfit_description} — the fabric catches light as they move, one leg extended mid-glide, arms relaxed and swinging naturally. The ground is smooth asphalt with painted lane markings in faded {lane_color}. Background shows {background_elements} slightly out of focus through heat haze. Shot on {film_stock} with pronounced grain and slightly lifted shadows. Color palette centers on {palette_description}. Golden hour backlight creates a warm halo around the subject and long shadow stretching toward camera. Genuine movement energy — hair and loose fabric respond to speed. Format: {aspect_ratio}.

**Key levers:** `{model_description}`, `{outfit_description}` (high-waisted terry shorts in coral, cropped zip-up in cream, tube socks with racing stripes), `{location_description}` (Venice Beach boardwalk, empty suburban tennis court, coastal promenade), `{film_stock}` (Kodak Gold 200, Fuji Superia 400), `{palette_description}` (terracotta #CC5533, cream #FFF5E1, sky blue #87CEEB, mustard #D4A017), `{lane_color}` (faded yellow, sun-bleached white), `{background_elements}` (palm trees and pastel buildings, chain-link fence and bleachers), `{aspect_ratio}` (3:2, 16:9)

**Recommended model:** NB2 — natural movement, analog film grain, atmospheric grounding

---

## Futuristic Sportswear Editorial with 3D Blob Shapes

Use for forward-looking athletic or techwear editorials where abstract 3D forms create a surreal spatial environment around the model.

<!-- Source concept: futuristic sportswear editorial with organic 3D blob/sphere shapes -->

```
Scene: {studio_environment} studio space, matte {floor_color} floor extending to infinity, ambient fill light with no visible source, three to five large organic 3D blob shapes ({blob_color}, glossy smooth surface with environment reflections) floating at varying heights around the subject
Subject: {model_description} in {techwear_outfit}, posed in an athletic stance — {pose_detail}
Important Details: blobs range from basketball-sized to armchair-sized, each with smooth amoebic curves and a single specular highlight, they cast soft colored shadows onto the floor and the model's clothing, model lit by cool directional light from camera-right creating defined muscle/fabric contour, {fabric_detail} visible in the garment construction, one blob partially behind the model and one in front (spatial depth), color palette limited to {palette}, overall mood is clinical and aspirational
Use Case: sportswear lookbook, techwear campaign, editorial magazine spread
Constraints: blobs must look physically present (not composited), no text, no logos, no additional props, model remains the clear focal point despite the surrounding forms, blobs do not touch or intersect with the model's body, no motion blur
```

**Key levers:** `{studio_environment}` (white void, concrete gray, deep navy), `{floor_color}` (light gray #D0D0D0, charcoal #333333), `{blob_color}` (chrome silver, translucent jade #00A86B, matte coral #FF6B6B), `{techwear_outfit}` (bonded seam track pants + compression top, oversized windbreaker + utility shorts), `{pose_detail}` (low lunge position, standing with one arm extended checking a wrist device, mid-jump), `{fabric_detail}` (visible bonded seams, reflective piping, mesh ventilation panels), `{palette}` (monochrome + single accent, earth tones + neon green #39FF14)

**Recommended model:** NBP — complex spatial reasoning for blob placement and reflections

### Nano Banana version:

```
A futuristic sportswear editorial photograph in a {studio_environment} studio space with a matte {floor_color} floor extending to infinity. {model_description} stands in an athletic {pose_detail}, wearing {techwear_outfit} with {fabric_detail}. Three to five large organic 3D blob shapes in {blob_color} with glossy smooth surfaces float at varying heights around the subject — the largest is armchair-sized, the smallest basketball-sized. Each blob has amoebic curves and casts soft colored shadows onto the floor and the model's clothes. Cool directional light from camera-right defines contour and fabric texture. One blob sits partially behind the model, one in front, creating depth. The model is the clear focal point. No text, no logos. Format: 4:5.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/patterns/fashion-editorial.md -->


<!-- SOURCE_FILE_START: skills/image/references/patterns/food-beverage.md -->
# SOURCE FILE: `skills/image/references/patterns/food-beverage.md`

# Food & Beverage Patterns

Reusable prompt templates for food photography, beverage campaigns, and culinary illustration. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Luxury Chocolate Brand Campaign

Use for premium chocolate or confectionery brand visuals — moody, textural, with controlled color and atmosphere. Adaptable across mood variants (dark indulgence, bright artisan, earthy origin-story).

<!-- Source concept: luxury chocolate brand campaign with variant moods and tactile surfaces -->

```
Scene: {surface_material} surface, {lighting_mood} lighting setup — {light_description}, thin atmospheric haze at background edge, color palette restricted to {palette}
Subject: {product_arrangement} — {product_count} pieces of {chocolate_type} arranged in {arrangement_style}
Important Details: visible snap edge on broken piece revealing {interior_texture}, fine cocoa powder dusted across surface (concentrated near product, fading to clean edges), {garnish_elements} placed deliberately as art direction not garnish, one piece mid-break with clean fracture line, surface texture of chocolate shows {surface_quality}, camera angle {camera_angle}, shallow depth of field with sharpest focus on the broken piece
Use Case: luxury chocolate brand campaign, print ad, packaging insert
Constraints: no human hands, no utensils, no wrappers or packaging visible, no text, cocoa dust must look natural not dumped, maximum {product_count} chocolate pieces, no melting

Mood variant — {mood_name}:
{mood_modifier}
```

**Key levers:**
- `{surface_material}` — dark slate, raw walnut wood, black marble, crumpled kraft paper
- `{lighting_mood}` — dramatic chiaroscuro / soft diffused warmth / cold window light
- `{light_description}` — single hard key from upper left / wrap-around softbox / backlit through parchment
- `{palette}` — deep browns #3E2723 + gold #C9A84C + black / warm terracotta #A0522D + cream #FFF8E7 / emerald #2D6A4F + copper #B87333
- `{chocolate_type}` — single-origin dark 72%, white chocolate with matcha veins, ruby chocolate
- `{interior_texture}` — smooth ganache center, crunchy praline layers, salted caramel pocket
- `{garnish_elements}` — single vanilla pod, fleur de sel crystals, edible gold leaf fragments, dried raspberry
- `{arrangement_style}` — diagonal cascade, tight cluster with negative space right, single row
- `{mood_name} / {mood_modifier}` — "Dark Indulgence": push contrast, deepen shadows, add smoke wisp / "Bright Artisan": overcast daylight, lifted blacks, pastel accent / "Origin Story": raw earth tones, burlap texture, raw cacao beans nearby

**Recommended model:** GPT Image 2 (`quality: high`) — fracture detail and cocoa powder precision

---

## High-Fashion Beverage Campaign Board

Use for premium beverage brand campaigns that combine lifestyle and product in a structured board layout — model shot + hero product + product lineup.

<!-- Source concept: fashion-meets-beverage campaign board with model, hero product, and lineup -->

```
Scene: horizontal triptych layout on single canvas — left panel (45% width), center panel (30%), right panel (25%), thin {divider_color} dividers (2px), unified {color_temperature} color temperature
Subject: {beverage_brand} campaign board featuring {model_description} and {product_name}
Important Details:
  Left panel (lifestyle): {model_description} at {location}, holding {product_name} at {hold_position}, {model_action}, shot on {film_aesthetic} — environment tells the brand story
  Center panel (hero): {product_name} bottle/can beauty shot, {product_angle} angle, {product_surface} surface, single key light with {highlight_style}, condensation droplets on glass/can surface, label sharp and legible
  Right panel (lineup): {lineup_count} product variants arranged in a {lineup_arrangement}, same lighting as center panel but pulled back wider, each label variant distinguishable by color ({variant_colors})
  Typography: none in image
Use Case: brand campaign presentation, pitch deck, retail POS
Constraints: model does not look directly at product (natural interaction), product label consistent and legible in all panels, lighting temperature cohesive, no floating elements, condensation looks physical not painted on
```

**Key levers:** `{product_name}`, `{beverage_brand}`, `{model_description}`, `{location}` (sunlit rooftop bar, marble kitchen counter, poolside), `{hold_position}` (mid-sip, resting at hip, gesturing with it), `{model_action}` (laughing mid-conversation, looking off-frame, walking), `{film_aesthetic}` (warm Kodak Portra feel, clean digital, cold editorial), `{product_angle}` (three-quarter front, straight-on, slight low angle), `{product_surface}` (wet dark stone, frosted glass shelf, white marble), `{lineup_count}` (3-5), `{variant_colors}` (amber/ruby/gold, mint/lemon/berry), `{divider_color}` (#FFFFFF, #1A1A1A)

**Recommended model:** GPT Image 2 (`quality: high`) — label legibility and panel consistency

---

## Hyper-Realistic Food Poster Template

Use for hero food posters — restaurants, delivery apps, menu boards — where the food is the entire composition with fillable content slots.

<!-- Source concept: hyper-realistic food poster with controlled composition slots -->

```
Scene: {background_treatment}, {atmosphere_effect}, overall tone {color_tone}
Subject: {dish_name} — {dish_description}, plated on {plate_description}, centered in frame
Important Details:
  Plating: {plating_details}
  Steam/moisture: {steam_detail}
  Garnish: {garnish_detail} placed at {garnish_position}
  Surface: {table_surface}, visible texture extending to frame edges
  Props: {prop_list} — arranged {prop_arrangement}
  Camera: overhead ({overhead_angle}) OR {camera_angle}, {lens_feel}
  Lighting: {food_lighting} — highlights on {highlight_targets}
Use Case: restaurant poster, delivery app hero, menu board, food magazine cover
Constraints: food must look freshly prepared (not cold or sat-out), no human hands or utensils in active use (props only), colors must be appetizing — no blue cast, no desaturated tones on the food itself, {plate_description} must not compete with the dish
```

**Key levers:**
- `{dish_name}` / `{dish_description}` — the hero food item described in appetizing physical detail
- `{plate_description}` — matte white ceramic, dark stoneware, rustic wooden board, banana leaf
- `{plating_details}` — sauce swoosh from 2 o'clock, microgreens at 10 o'clock, sesame seed scatter
- `{steam_detail}` — visible steam wisps rising from center, condensation on glass nearby, no steam
- `{garnish_detail}` — single basil sprig, chili flake scatter, citrus zest curls
- `{table_surface}` — aged oak, dark concrete, white marble with gray veins
- `{prop_list}` — linen napkin, vintage fork, small bowl of sauce, scattered herbs
- `{food_lighting}` — warm directional from upper-left with fill bounce, harsh noon daylight, moody side light
- `{background_treatment}` — dark vignette, clean bright, rustic blur
- `{camera_angle}` — 45-degree three-quarter, straight-on eye-level, overhead flat-lay

**Recommended model:** GPT Image 2 (`quality: high`) — steam, condensation, and ingredient texture fidelity

---

## Naturalist Food Specimen Cross-Section

Use for educational food content, ingredient features, or artisanal brand storytelling — the food item rendered as a scientific illustration in the style of 19th-century naturalist prints.

<!-- Source concept: Audubon-style naturalist botanical/food specimen illustration with cross-section -->

A detailed naturalist illustration of {food_item} rendered in the style of 19th-century scientific specimen plates. The composition shows the item in three states arranged vertically on an aged {paper_color} parchment background: whole specimen at top with botanical accuracy, lateral cross-section at center revealing internal structure ({internal_details}), and an exploded detail of {detail_element} at bottom with fine ink annotation lines pointing to key features. Drawn with precise {medium_description} — visible hatching for shadow, stippling for texture, thin ink outlines. Color is naturalistic but slightly muted as if from a hand-tinted lithograph. A thin decorative border frames the composition. Small italic Latin-style label "{latin_label}" at the bottom in serif font, {ink_color} ink. Format: 3:4.

**Key levers:** `{food_item}` (pomegranate, sourdough loaf, wagyu ribeye, cacao pod), `{internal_details}` (seed chambers with ruby arils, crumb structure with irregular air pockets, marbling fat distribution), `{detail_element}` (individual seed anatomy, crust layering, fat crystal structure), `{paper_color}` (warm cream #FDF5E6, cool ivory #FFFFF0), `{medium_description}` (watercolor wash with ink line, graphite with colored pencil, pure ink with minimal color), `{latin_label}` (a playful Latinized name), `{ink_color}` (sepia #704214, India black #1A1A1A)

**Recommended model:** NB2 — naturalist illustration style, grounding on botanical plate aesthetics

---

## City Food Map Illustration

Use for restaurant guides, food festival materials, travel content, or local cuisine features — a bird's-eye illustrated map showing food specialties across a city.

<!-- Source concept: hand-drawn illustrated food map of a city with dish icons and landmarks -->

A hand-drawn illustrated bird's-eye map of {city_name} showing its food culture. The map covers the {area_description} with simplified but recognizable {landmark_list} drawn in a loose ink-and-watercolor style. Scattered across the map are {dish_count} illustrated food items representing local specialties — each dish ({dish_list}) drawn at exaggerated scale hovering near its neighborhood, rendered in warm appetizing watercolor with visible brushstrokes. Streets are thin ink lines with {street_style}. Water features rendered in soft {water_color} wash. The overall palette is {palette_description}. A decorative hand-lettered title "{MAP_TITLE}" sits in a banner at the top. Small hand-written labels mark each dish and neighborhood. Style references vintage travel poster illustration meets editorial food drawing. Format: {aspect_ratio}.

**Key levers:** `{city_name}`, `{area_description}` (central 5 km, old town quarter, waterfront district), `{landmark_list}` (main cathedral, central market, river bridges), `{dish_count}` (6-10), `{dish_list}` (plov near the bazaar, samsa near the old town, shashlik near the park), `{street_style}` (slightly wobbly freehand, clean but simplified), `{water_color}` (cerulean #0077B6, teal #2A9D8F), `{palette_description}` (warm terracotta and cream with food items in full saturated color, cool blues and greens with warm food accents), `{MAP_TITLE}` ("A Taster's Guide to {city_name}"), `{aspect_ratio}` (3:4, 1:1)

**Recommended model:** NB2 — image grounding for real city landmarks + illustration style

### Nano Banana version:

```
A hand-drawn illustrated bird's-eye food map of {city_name}, covering the {area_description}. Simplified but recognizable {landmark_list} are drawn in loose ink-and-watercolor style. {dish_count} local dishes ({dish_list}) float at exaggerated scale near their neighborhoods, each painted in warm appetizing watercolor with visible brushstrokes. Streets are thin freehand ink lines. Water features in soft {water_color} wash. A hand-lettered banner at top reads "{MAP_TITLE}". Small hand-written labels mark dishes and neighborhoods. Style mixes vintage travel poster illustration with editorial food drawing. Palette: {palette_description}. Format: {aspect_ratio}.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/patterns/food-beverage.md -->


<!-- SOURCE_FILE_START: skills/image/references/patterns/portrait-cinema.md -->
# SOURCE FILE: `skills/image/references/patterns/portrait-cinema.md`

# Portrait & Cinema Patterns

Reusable prompt templates for cinematic portraits, atmospheric character photography, and mood-driven portraiture. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Golden Hour Street Backlit Portrait

Use for warm, emotive street portraits with strong backlight flare — editorial, personal branding, album covers.

<!-- Source concept: golden hour backlit street portrait with lens flare and warm atmospheric haze -->

```
Scene: {street_description} at golden hour, sun positioned directly behind subject (5-10 degrees above horizon line), warm amber light flooding the street, slight atmospheric haze diffusing the backlight
Subject: {person_description}, standing at {position_in_street}, body angled three-quarter to camera, face turned toward lens with {expression}
Important Details: strong rim light outlining hair and shoulders in warm gold (#FFAA33), face lit primarily by bounce light from {bounce_surface} on the opposite side — softer and cooler than the backlight, shallow depth of field rendering background into warm bokeh circles, {clothing_detail} catches backlight along edges showing fabric texture, visible lens flare — one or two hexagonal flare artifacts near frame edge (organic, not excessive), long shadow cast toward camera on {ground_surface}, skin rendered naturally with warm undertones — no heavy smoothing, visible pores, {color_grade}
Use Case: editorial portrait, personal brand photography, album art
Constraints: face must be visible and well-exposed despite backlight (not silhouetted), no reflectors or studio equipment visible, lens flare limited to one or two subtle artifacts — not a starburst explosion, no added text, no vignette
```

**Key levers:** `{street_description}` (narrow European alley with stone walls, wide boulevard with linden trees, industrial backstreet with brick), `{person_description}`, `{expression}` (quiet confidence, mid-smile with closed lips, contemplative gaze), `{bounce_surface}` (cream-painted wall, parked white van, sand-colored buildings), `{clothing_detail}` (linen shirt collar, leather jacket shoulder seam, scarf edge), `{ground_surface}` (wet cobblestones, dry asphalt, packed earth), `{color_grade}` (Kodak Portra 400 warmth, slightly lifted blacks with amber cast, clean digital with warm white balance)

**Recommended model:** GPT Image 2 — backlight exposure control and skin rendering

---

## Convenience Store Neon Portrait

Use for urban night portraits with mixed artificial lighting — fluorescent overhead + colored neon signage creating a chromatic push-pull on the subject's face.

<!-- Source concept: convenience store / bodega neon portrait — fluorescent + neon mixed light on face -->

```
Scene: exterior of a {store_type} at night, shot through or near the front window/entrance, overhead fluorescent tubes casting flat {fluorescent_color} light from inside, {neon_sign_description} mounted on the wall/window casting {neon_color} glow on one side of the subject's face
Subject: {person_description}, {pose_description}, positioned at the threshold between interior fluorescent zone and exterior neon zone — split lighting across the face
Important Details: face receives {fluorescent_color} fill from the store interior on one side and {neon_color} accent from signage on the other — the two colors mix on the nose bridge and chin, visible product shelves or cooler glow softly in background bokeh, {clothing_description} absorbs and reflects the two light sources differently, condensation or grime on window glass if shot through it (subtle, not obscuring), wet pavement outside reflects both light sources in streaks, shallow depth of field with subject sharp, background a mosaic of colored bokeh, {camera_feel}
Use Case: urban editorial, music press portrait, fashion story, short film still
Constraints: face clearly visible — neither light source blows out features, neon sign text (if present) is secondary to the portrait not the focal point, no additional light sources beyond what exists in the scene, no heavy color grading beyond what the practical lights create naturally, no motion blur
```

**Key levers:** `{store_type}` (Korean convenience store, bodega, late-night pharmacy, 24-hour laundromat), `{fluorescent_color}` (cool blue-white, greenish-white, warm tungsten), `{neon_sign_description}` (red "OPEN" sign, blue beer brand logo, pink cursive word), `{neon_color}` (red #FF2D2D, blue #3366FF, pink #FF69B4, green #39FF14), `{person_description}`, `{pose_description}` (leaning against door frame, sitting on overturned crate, standing with hands in pockets), `{clothing_description}` (dark hoodie that absorbs light, white t-shirt that bounces both colors, leather that reflects), `{camera_feel}` (Cinestill 800T with halation around neon, clean digital night, Fujifilm color science)

**Recommended model:** GPT Image 2 (`quality: high`) — precise dual-light color rendering on skin

---

## Monochrome Glitch Profile Portrait

Use for edgy, tech-forward portraits — artist profiles, electronic music press, tech brand campaigns. High contrast black-and-white with selective red digital artifacts.

<!-- Source concept: monochrome profile portrait with digital glitch artifacts and red accent color -->

```
Scene: pure black background (#000000), no environment — subject emerges from darkness
Subject: {person_description} in sharp profile (facing {direction}), head and upper shoulders only, high-contrast black-and-white rendering
Important Details: extreme contrast — skin highlights blow to near-white, shadows fall to pure black with minimal midtone graduation, {hair_detail} silhouetted against black, one eye visible in profile with a single catchlight, horizontal glitch displacement lines cutting across the image at {glitch_positions} — each line offsets a thin horizontal slice (4-8px) to the right by 10-20px, the displaced slices rendered in {accent_color} (#FF0000 default) while the rest remains monochrome, fine horizontal scan lines across entire image (subtle, CRT monitor texture), grain: heavy high-ISO film grain throughout, jaw line and nose bridge are the sharpest elements in frame
Use Case: artist press photo, electronic music EP cover, tech brand portrait, social media profile
Constraints: glitch lines must look digital (clean horizontal displacement, not organic), accent color appears ONLY in the displaced glitch slices — no other colored elements, maximum {max_glitch_lines} glitch lines to avoid visual noise, face must remain recognizable despite artifacts, no text, background is solid black — no gradient or texture
```

**Key levers:** `{person_description}`, `{direction}` (left, right), `{hair_detail}` (tight buzz cut showing skull contour, shoulder-length hair with flyaway strands catching backlight, pulled-back bun), `{glitch_positions}` (across the eye, across the mouth, across the forehead — specify 2-3 positions), `{accent_color}` (#FF0000 red, #00FF41 terminal green, #FF00FF magenta), `{max_glitch_lines}` (3-5)

**Recommended model:** GPT Image 2 — high-contrast mono rendering and controlled glitch placement

---

## Japanese Negative Film Rooftop Portrait

Use for moody, atmospheric portraits with overexposed analog film qualities — muted colors, lifted shadows, and a feeling of faded memory. Ideal for editorial, zine, or personal project work.

<!-- Source concept: Japanese negative film aesthetic — overexposed, muted tones, rooftop setting -->

A waist-up portrait of {person_description} on a {rooftop_description}. They stand near the edge railing, {pose_description}, with the {city_skyline} visible behind them but washed out and desaturated by {sky_condition}. Shot on expired Japanese negative film — colors shifted toward {color_shift}, highlights blown soft and chalky, shadows lifted with visible grain in the flat midtones. Skin tones slightly green-yellow as if the film has aged. {clothing_description} reads as muted tones, almost monochromatic against the overexposed sky. Wind moves {wind_detail}. The mood is nostalgic and transient — a memory captured on deteriorating film stock. Eye-level framing, subject slightly off-center toward {frame_position}. Format: {aspect_ratio}.

**Key levers:** `{person_description}`, `{rooftop_description}` (concrete apartment building rooftop, industrial warehouse roof with exhaust vents, school building roof with chain-link fence), `{pose_description}` (leaning on railing looking at camera, turned away looking at skyline, sitting on a ledge with knees drawn up), `{city_skyline}` (Tokyo mid-rise apartments, generic Asian city with power lines), `{sky_condition}` (overcast white sky, hazy afternoon sun), `{color_shift}` (green-cyan cast, yellow-amber cast), `{clothing_description}` (oversized vintage windbreaker, plain white t-shirt, navy work jacket), `{wind_detail}` (hair across face, jacket hem, collar), `{frame_position}` (left third, right third), `{aspect_ratio}` (3:2, 4:5)

**Recommended model:** NB2 — analog film grain emulation and atmospheric mood

---

## Dreamy Underwater Surreal Portrait

Use for beauty campaigns, conceptual art, or album visuals — a portrait where the subject floats in clear water surrounded by translucent aquatic elements.

<!-- Source concept: surreal underwater portrait with translucent fish and dreamy caustic light -->

```
Scene: clear {water_color} water filling the entire frame, caustic light patterns rippling across the subject from above (sunlight through water surface), no visible pool walls or floor — infinite aquatic void
Subject: {person_description}, floating in a relaxed {pose_description}, eyes {eye_state}, hair fanning out in all directions as if weightless, {clothing_description} billowing and suspended in the water
Important Details: {fish_count} translucent {fish_type} swimming in a loose school around the subject — each fish semi-transparent with visible skeletal structure and iridescent scales catching the caustic light, light rays penetrating from above in {light_pattern}, fine air bubbles rising from near the subject's {bubble_source}, fabric of clothing moves independently from the body — folds and hems suspended in mid-drift, skin has a subtle cool {water_tint} cast from the water, overall palette is {palette}, composition framed as a {shot_type}
Use Case: beauty campaign, album cover, conceptual art print, fashion editorial
Constraints: subject's face must be clearly visible and serene (not distressed or holding breath with effort), fish are translucent — not solid opaque tropical fish, no visible water surface edge or pool tiles, no scuba gear or goggles, bubbles are small and delicate not large air pockets, underwater physics must be consistent (everything floats)
```

**Key levers:** `{water_color}` (deep cerulean #0077B6, pale turquoise #AFEEEE, dark teal #004D4D), `{person_description}`, `{pose_description}` (arms slightly outstretched like a slow free-fall, curled fetal position, one arm reaching upward toward the light), `{eye_state}` (softly closed, open and gazing upward at the light, looking directly at camera), `{clothing_description}` (flowing white silk dress, loose linen shirt and trousers, sheer organza wrap), `{fish_count}` (5-8), `{fish_type}` (jellyfish, small reef fish, elongated glass catfish), `{light_pattern}` (parallel god rays from upper right, scattered dappled caustics, single concentrated beam), `{bubble_source}` (lips, fingertips, fabric edges), `{water_tint}` (blue-green, aquamarine), `{palette}` (teal and ivory, deep blue and gold, seafoam and blush), `{shot_type}` (full body vertical, waist-up centered, three-quarter with negative space below)

**Recommended model:** NBP — complex physics (floating hair, fabric, fish transparency, caustic light)

### Nano Banana version:

```
A surreal underwater portrait of {person_description} floating in a relaxed {pose_description} in clear {water_color} water. Eyes {eye_state}, hair fans out weightlessly in all directions. {clothing_description} billows and suspends in the current, folds drifting independently. {fish_count} translucent {fish_type} swim in a loose school around the subject — each semi-transparent with visible skeletal structure and iridescent scales catching caustic light from above. Sunlight penetrates from the surface in {light_pattern}, casting rippling patterns across skin and fabric. Fine air bubbles rise from the subject's {bubble_source}. Skin has a subtle cool {water_tint} cast. No pool walls, no surface edge visible — infinite aquatic void. Serene and dreamlike. Palette: {palette}. Format: 4:5.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/patterns/portrait-cinema.md -->


<!-- SOURCE_FILE_START: skills/image/references/patterns/poster-illustration.md -->
# SOURCE FILE: `skills/image/references/patterns/poster-illustration.md`

# Poster & Illustration Patterns

Reusable prompt templates for posters, art prints, campaign collages, and graphic illustrations. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## City Across Two Centuries (Time-Split Composition)

Use for urban development campaigns, anniversary materials, cultural exhibitions, or editorial features — a single city view divided down the middle, one half historical and one half modern.

<!-- Source concept: time-split composition — same city view, two eras side by side -->

```
Scene: wide establishing shot of {city_landmark_view}, frame divided vertically down the center — left half shows the scene in {historical_era}, right half shows {modern_era}
Subject: the same geographic viewpoint across two time periods, architecture and infrastructure transforming at the dividing line
Important Details:
  Left half ({historical_era}): {historical_details} — muted {historical_palette} palette, {historical_atmosphere}, period-accurate architecture, {historical_figures} going about daily life, {historical_transport}
  Right half ({modern_era}): {modern_details} — {modern_palette} palette, {modern_atmosphere}, contemporary architecture where old buildings once stood (some landmarks preserved), {modern_figures}, {modern_transport}
  Dividing line: not a hard cut — elements morph and blend across a narrow 5% transition zone (a horse-drawn cart becomes a car, a gas lamp becomes LED, cobblestones become asphalt, a tree grows taller)
  Sky transitions too: {historical_sky} on left to {modern_sky} on right
  Camera angle: elevated three-quarter view (roughly 30 degrees above street level) to show depth of both eras
Use Case: city anniversary campaign, urban development feature, cultural exhibition poster, editorial illustration
Constraints: both halves must depict the SAME geographic location (matching terrain, river, hill positions), transition zone should feel organic not pasted, scale and perspective consistent across both halves, no text unless specified, no anachronistic elements (modern items in historical half or vice versa outside the transition)
```

**Key levers:** `{city_landmark_view}` (view down the main avenue toward the central square, riverfront panorama, view from the hill overlooking the old town), `{historical_era}` / `{modern_era}` (1920s / 2020s, medieval / present day, 1960s / 2060s), `{historical_details}` (cobblestone streets, horse-drawn carts, hand-painted shop signs), `{modern_details}` (glass facades, rooftop gardens, digital signage), `{historical_palette}` (sepia and desaturated earth tones, hand-colored photograph quality), `{modern_palette}` (clean contemporary color, cooler blue-grays with warm accent), `{historical_atmosphere}` (coal haze, soft morning fog), `{modern_atmosphere}` (clear sky, light pollution glow at horizon), `{historical_sky}` (warm overcast), `{modern_sky}` (clear gradient blue)

**Recommended model:** NBP — spatial reasoning for architectural morphing and perspective consistency

### Nano Banana version:

```
A wide elevated view of {city_landmark_view}, divided vertically down the center into two eras. The left half depicts the scene in {historical_era}: {historical_details}, rendered in a muted {historical_palette} palette with {historical_atmosphere}. The right half shows {modern_era}: {modern_details} in a {modern_palette} palette under {modern_atmosphere}. At the center dividing line, elements morph organically across a narrow transition zone — a horse-drawn cart becomes a car, gas lamps become LED lights, cobblestones blend into asphalt, trees grow taller. The sky transitions from {historical_sky} on the left to {modern_sky} on the right. Both halves share the same geographic terrain and perspective. Camera angle roughly 30 degrees above street level. Format: 16:9.
```

---

## Fitness Boxing Campaign Collage

Use for sport and fitness brand campaigns — a dynamic 3-panel collage combining action, detail, and atmosphere around a boxing/combat sport theme.

<!-- Source concept: 3-panel fitness/boxing campaign collage with action and detail shots -->

```
Scene: three-panel horizontal collage on {canvas_color} canvas — left panel (35%), center panel (40%), right panel (25%), {divider_style} dividers, unified {overall_tone} color tone
Subject: {athlete_description} in a boxing/training context — same person across all panels
Important Details:
  Left panel (environment): wide shot of {gym_environment}, atmospheric — {atmosphere_detail}, equipment visible but out of focus, {athlete_description} as a silhouette or distant figure warming up, mood: anticipation
  Center panel (action): medium shot, {athlete_description} mid-{action_type}, captured at peak effort — {action_detail}, sweat visible on skin and {gear_description}, sharp focus on face showing {expression}, directional hard light from {light_direction} creating dramatic shadow on the opposite side of the face, slight motion trail on the {moving_element}
  Right panel (detail): extreme close-up of {detail_subject} — {detail_description}, texture dominates the frame, {detail_lighting}
  Grain: uniform {grain_level} across all panels
  Color: {color_treatment}
Use Case: fitness brand campaign, gym poster, sportswear ad, magazine editorial spread
Constraints: same athlete across all panels (consistent identity, gear, wraps), no text or logos, no sponsor branding, center panel is the visual anchor — should feel like the decisive moment, grain must be uniform not just added to one panel
```

**Key levers:** `{athlete_description}`, `{gym_environment}` (industrial boxing gym with heavy bags, outdoor concrete training yard, dimly lit basement ring), `{atmosphere_detail}` (chalk dust in backlight, steam from breath in cold air, golden light through high windows), `{action_type}` (throwing a cross, landing a hook on a heavy bag, rope-skipping), `{action_detail}` (fist connecting with bag creating visible impact ripple, rope frozen in arc above head), `{gear_description}` (red hand wraps, worn leather gloves, no gloves — taped knuckles), `{expression}` (focused intensity, controlled exhale, battle cry), `{detail_subject}` (taped knuckles against red canvas, worn boxing boot laces, sweat dripping from chin onto canvas), `{detail_description}` (each tape fiber visible, leather cracking at flex points, individual droplets mid-fall), `{color_treatment}` (desaturated with warm midtones, high-contrast monochrome with sepia, teal-and-orange split tone), `{canvas_color}` (matte black #0D0D0D, dark charcoal #1A1A1A), `{divider_style}` (thin white 2px, no dividers — edge bleed)

**Recommended model:** GPT Image 2 — identity consistency across panels and sweat/texture detail

---

## Lavender Smartphone Hero Ad

Use for tech product launch visuals — clean, color-dominant hero shots where a smartphone (or similar device) floats against a monochromatic gradient with soft 3D accent elements.

<!-- Source concept: smartphone product launch hero in monochromatic lavender with floating accent shapes -->

```
Scene: smooth gradient background from {color_light} to {color_dark}, no hard edges, studio void environment
Subject: {device_name} floating at slight {tilt_angle}-degree angle, screen facing camera showing {screen_content}, centered vertically but offset {horizontal_position} horizontally
Important Details: device renders with physically accurate {device_finish} — visible edge chamfer catching a thin highlight line, screen content crisp and legible at this scale, {accent_element_count} soft 3D shapes floating nearby (matte {accent_shape_color} {accent_shapes} — frosted glass or soft plastic appearance, each {accent_size}), shapes are out of focus at varying depths creating a layered composition, soft omnidirectional lighting with a subtle key from upper-left, gentle device shadow projected onto the gradient ({shadow_softness}), overall color palette stays within the {color_family} family — no complementary or clashing tones
  Bottom text area: "{HEADLINE}" in {headline_weight} {headline_font_style}, {headline_color}, centered below device
  Subtext: "{SUBHEADLINE}" in thin weight, {subtext_color}, below headline
Use Case: product launch hero, website header, retail POS, digital ad
Constraints: screen content must be sharp and readable, floating shapes must not obscure the device screen, no reflections of a studio environment on screen, gradient is smooth — no banding, device proportions must match a real smartphone (no stretched or squished body), text exactly as quoted
Quality: high
```

**Key levers:** `{device_name}`, `{color_light}` / `{color_dark}` (lavender #E6D5F5 to #7B4FA0, mint #D0F0E0 to #1B7A5A, coral #FFDDD2 to #C44536), `{device_finish}` (matte aluminum, polished titanium, frosted glass back), `{screen_content}` (a clean home screen with app icons, a camera app showing a landscape, a gradient wallpaper), `{accent_shapes}` (spheres, rounded pills, soft cubes, torus rings), `{accent_shape_color}` — same family as background but slightly lighter or more saturated, `{accent_size}` (golf-ball to grapefruit), `{HEADLINE}` / `{SUBHEADLINE}`, `{headline_color}` (white #FFFFFF, dark tint of the color family), `{color_family}` (lavender-purple, sage-green, warm terracotta), `{tilt_angle}` (5-15), `{horizontal_position}` (left third, center, right third)

**Recommended model:** GPT Image 2 (`quality: high`) — text rendering, screen content legibility, device accuracy

---

## Emerald Street Fashion Poster

Use for fashion drops, event announcements, or editorial magazine covers where bold typography and a street fashion figure share equal visual weight on a saturated color field.

<!-- Source concept: bold emerald fashion poster with oversized type and street style figure -->

```
Scene: solid {background_color} background (flat, no gradient), graphic poster composition split between typography (upper 55%) and figure (lower 60%, overlapping into the type zone)
Subject: {model_description} in {outfit_description}, full-body shot from low angle (worm's eye, approximately 15 degrees below eye level), standing with {pose_description}
Important Details: "{MAIN_TITLE}" in extra-bold extended {title_font_style}, {title_color}, filling the upper half — each letter approximately 20% of frame height, model's head and shoulders break in front of the bottom row of letters (depth layering), "{SUBTITLE}" in lightweight condensed type, {subtitle_color}, running along the bottom edge or lower-right corner, model lit by overcast flat light — even exposure, minimal shadow, fabric textures fully readable ({fabric_details}), shoes visible and grounded (not floating), {graphic_accents} if any
Use Case: fashion brand poster, event flyer, editorial magazine cover, retail window display
Constraints: title text fully legible — model overlap must not obscure more than one letter by more than 40%, no additional decorative elements unless specified in {graphic_accents}, background is flat solid color — no texture or pattern, "{MAIN_TITLE}" and "{SUBTITLE}" spelled exactly as given, model does not hold props unless specified
Quality: high
```

**Key levers:** `{background_color}` (emerald #006B3F, cobalt #0047AB, saffron #F4C430, hot pink #FF1493), `{model_description}`, `{outfit_description}` (oversized leather trench + chunky sneakers, cropped bomber + wide-leg trousers + platform boots), `{pose_description}` (wide stance with arms crossed, one hand adjusting collar, walking stride caught mid-step), `{MAIN_TITLE}` / `{SUBTITLE}`, `{title_font_style}` (geometric sans-serif, grotesque, stencil cut), `{title_color}` (#FFFFFF, #000000, cream #FFF5E1), `{subtitle_color}` (same as title but at 60% opacity), `{fabric_details}` (visible grain in leather, corduroy ridges, denim selvedge edge), `{graphic_accents}` (none, thin white border 20px from edge, small logo mark at bottom-left)

**Recommended model:** GPT Image 2 (`quality: high`) — typography rendering and figure-type layering

---

## Peacock Botanical Vintage Art Print

Use for decorative prints, packaging illustration, wallpaper design, or editorial art — a symmetrical composition combining a peacock with botanical elements in a vintage printmaking style.

<!-- Source concept: peacock botanical vintage symmetrical art print — ornamental and decorative -->

A symmetrical ornamental art print centered on a {peacock_variant} peacock in full tail display, viewed from {view_angle}. The tail feathers fan into a perfect semicircle filling the upper two-thirds of the frame, each eye-spot rendered with precise detail — iridescent {eye_colors} with fine barb texture. The peacock stands on a {base_element} at the composition's center axis. Flanking the bird symmetrically: {botanical_left} on the left mirrored by {botanical_right} on the right — leaves, stems, and blossoms curve inward framing the peacock. {additional_fauna} perch or fly near the upper corners. The entire composition sits on a {background_texture} background in {background_color}. Rendering style: {print_style} — visible {technique_marks}, rich but slightly flattened color as if from layered printing passes. Border: {border_style}. Color palette: {palette}. Format: 3:4.

**Key levers:** `{peacock_variant}` (Indian blue, white albino, green Java), `{view_angle}` (front-facing straight on, three-quarter turning left), `{eye_colors}` (deep blue #003366 and emerald #006B3F and gold #C9A84C, monochrome — all in shades of navy and silver), `{base_element}` (ornate stone pedestal, flowering branch, decorative tile floor), `{botanical_left}` / `{botanical_right}` (magnolia branches, trailing wisteria, passion flower vines, banksia stems), `{additional_fauna}` (two small butterflies, a dragonfly pair, none), `{background_texture}` / `{background_color}` (aged linen #F5F0E1, dark navy #0A1628, cream parchment #FDF5E6), `{print_style}` (hand-colored etching, woodblock print, chromolithograph), `{technique_marks}` (cross-hatching in shadows, visible plate tone, registration marks at corners), `{border_style}` (thin double-line art nouveau border, ornamental corner flourishes, simple single-line rectangle), `{palette}` (natural jewel tones — emerald, sapphire, gold on cream / limited three-color palette — teal, copper, black on ivory / muted earth tones — sage, terracotta, umber)

**Recommended model:** NB2 — image grounding for accurate peacock anatomy and botanical species

### Nano Banana version:

```
A symmetrical ornamental art print centered on a {peacock_variant} peacock in full tail display, viewed {view_angle}. Tail feathers fan into a perfect semicircle filling the upper two-thirds, each eye-spot rendered with iridescent {eye_colors} and fine barb texture. The peacock stands on a {base_element}. Flanking it symmetrically: {botanical_left} on the left mirrored by {botanical_right} on the right, stems and blossoms curving inward to frame the bird. {additional_fauna} near the upper corners. Background: {background_texture} in {background_color}. Style: {print_style} with visible {technique_marks} and slightly flattened color as from layered printing passes. Border: {border_style}. Palette: {palette}. Format: 3:4.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/patterns/poster-illustration.md -->


<!-- SOURCE_FILE_START: skills/image/references/patterns/ui-social.md -->
# SOURCE FILE: `skills/image/references/patterns/ui-social.md`

# UI Mockups & Social Media Patterns

Reusable prompt templates for social media ads, app store assets, dashboard mockups, and visual analysis boards. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

---

## Instagram Story Ad (9:16)

Use for vertical product or brand ads targeting Instagram Stories — hero product, bold headline, and swipe-up CTA zone at the bottom.

<!-- Source concept: Instagram Story ad with glassmorphism elements and gradient background -->

```
Scene: vertical 9:16 canvas, smooth gradient background from {gradient_top} to {gradient_bottom}, soft ambient glow behind the product
Subject: {product_name} — {product_description} — centered in the upper two-thirds of the frame, angled slightly for dimension
Important Details: two glassmorphism panels (frosted translucent white, 20% opacity, subtle border highlight at #FFFFFF30) flanking the product — one floating left, one floating right, slightly rotated, adding depth layers. Bold headline "{headline_text}" in {headline_font} at the top third, white or light-colored text with subtle drop shadow for readability. Small subtext "{subtext}" below the headline in lighter weight. Bottom 15% of canvas left as swipe-up CTA zone — thin upward-pointing chevron icon and "{cta_text}" in small caps, both in white. Product casts a soft colored shadow matching the gradient onto the background. Scattered {accent_elements} (glass spheres, soft bokeh circles, translucent geometric shapes) at 10-15% opacity for texture.
Use Case: Instagram Story ad, vertical social media placement, mobile-first brand campaign
Constraints: text must be legible on mobile screens (minimum visual weight), no text in the bottom 5% (system UI overlap zone), product must be the clear focal point, no more than 3 accent elements, glassmorphism panels must not obscure the product
```

**Key levers:** `{product_name}`, `{product_description}` (shape, material, color), `{gradient_top}` / `{gradient_bottom}` (e.g. #6C3CE1 violet to #1A1A2E dark navy, #FF6B6B coral to #FFE66D warm yellow), `{headline_text}`, `{headline_font}` (bold condensed sans-serif, rounded geometric), `{subtext}`, `{cta_text}` (e.g. "Swipe Up", "Shop Now", "Learn More"), `{accent_elements}` (translucent spheres, soft light flares, floating geometric shards)

**Recommended model:** GPT Image 2 (`quality: high`) — headline text legibility and glassmorphism transparency effects need precision

---

## Social Media Feed Post (1:1)

Use for square-format posts on Instagram or Facebook — quote cards, feature announcements, or product highlights with centered layout.

<!-- Source concept: square social media post with brand color palette and centered typography -->

```
Scene: square 1:1 canvas, solid or subtle textured background in {bg_color}, clean centered composition
Subject: {post_type} — {content_description}
Important Details:
  Background: {bg_treatment} (solid color, subtle noise texture at 3% opacity, or soft radial gradient from {bg_color} center to slightly darker edges)
  Primary text: "{primary_text}" in {primary_font}, {text_color}, centered horizontally, positioned in the upper half with comfortable margins (at least 10% padding from edges)
  Supporting element: {supporting_element} — positioned below the primary text, providing visual weight and context
  Brand strip: thin horizontal line or subtle divider in {accent_color} separating the primary content from a bottom section containing "{brand_name}" in small caps and {brand_mark} (logo mark or wordmark)
  Overall palette restricted to {palette} — no colors outside this set
  Text sized for legibility at phone-screen scale — primary text large enough to read in a thumbnail feed scroll
Use Case: Instagram feed post, Facebook post, LinkedIn visual, social media content calendar
Constraints: all text must remain legible at 320px display width, no decorative elements that compete with the message, centered balanced layout, no more than two type sizes (headline + body or headline + brand), background must not reduce text contrast below WCAG AA
```

**Key levers:** `{post_type}` (quote card, product feature, announcement, stat highlight), `{content_description}`, `{primary_text}`, `{primary_font}` (geometric sans-serif, modern serif, handwritten accent), `{text_color}` (#FFFFFF on dark, #1A1A1A on light), `{bg_color}` / `{bg_treatment}`, `{accent_color}`, `{brand_name}`, `{brand_mark}`, `{palette}` (e.g. navy #1B2A4A, gold #C9A84C, white #FFFFFF), `{supporting_element}` (product photo, icon illustration, data number in large type)

**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout; legibility at small sizes is critical

---

## App Store Screenshot

Use to create a polished App Store or Google Play listing screenshot — device frame with app UI inside, feature headline, and clean gradient background.

<!-- Source concept: App Store marketing screenshot with iPhone device frame and feature callout -->

```
Scene: vertical canvas, smooth gradient background from {gradient_top} to {gradient_bottom}, centered composition
Subject: {device_type} device frame displaying {app_name} UI — {screen_description}
Important Details:
  Device: realistic {device_type} bezel (space black / silver / natural titanium) with accurate corner radius and button placement, screen showing {screen_content} with proper iOS/Android status bar at top
  Headline: "{feature_headline}" in bold {headline_font}, positioned {headline_position} the device frame, {headline_color} text, 2-3 words maximum per line for impact
  Optional subheadline: "{subheadline}" in lighter weight below the headline, 60% opacity of headline color
  Device shadow: soft diffused shadow below the device, matching the gradient color (not pure black)
  Screen UI: {ui_description} — realistic interface elements with proper spacing, {ui_style} design system, readable text within the screen (even if small)
  Device centered vertically with equal breathing room above and below
Use Case: App Store product page, Google Play listing, app marketing material
Constraints: device bezel must look physically accurate (not a flat rectangle), screen content must be realistic and internally consistent UI (not random shapes), headline text must not overlap the device, gradient background only — no patterns or photos behind the device, one device only
```

**Key levers:** `{device_type}` (iPhone 16 Pro, Pixel 9, Galaxy S25), `{app_name}`, `{screen_description}` (brief: what the screen shows), `{screen_content}` / `{ui_description}` (detailed: specific UI elements visible), `{ui_style}` (iOS native, Material 3, custom dark theme), `{feature_headline}`, `{headline_font}` (SF Pro Display, condensed geometric), `{headline_position}` (above, below), `{headline_color}`, `{subheadline}`, `{gradient_top}` / `{gradient_bottom}` (e.g. #1A1A2E to #0D0D1A for dark, #F0F4FF to #FFFFFF for light)

**Recommended model:** GPT Image 2 (`quality: high`) — device bezel precision, small UI text, and headline legibility all demand high quality

---

## Dashboard Design Mockup

Use for realistic analytics dashboard mockups — dark or light theme with data visualizations, KPI cards, and sidebar navigation.

<!-- Source concept: analytics dashboard UI mockup with charts, cards, and navigation -->

```
Scene: full-screen desktop UI mockup, {theme_mode} theme, clean {design_system} design system
Subject: {dashboard_title} — analytics dashboard showing {data_domain} metrics
Important Details:
  Sidebar (left, 220px visual width): dark ({sidebar_bg}) vertical navigation with icon + label pairs for {nav_items}, active item highlighted with {accent_color} left border and slightly lighter background, collapsed user avatar and app logo at top
  Top bar: breadcrumb or page title "{page_title}" in medium weight, date range selector showing "{date_range}", notification bell icon with dot indicator
  KPI row (top of main area): {num_kpis} metric cards in a horizontal row — each card shows metric name in small caps, large number value, and a small trend indicator (green upward arrow or red downward arrow with percentage), card background {card_bg}
  Chart area (main): {chart_layout}
    Chart 1: {chart_1_type} showing {chart_1_data} — using {chart_1_colors}
    Chart 2: {chart_2_type} showing {chart_2_data} — using {chart_2_colors}
  Secondary section: {secondary_widget} (data table with alternating row colors, recent activity feed, or geographic heat map)
  Proper visual hierarchy — KPI numbers largest, chart labels smaller, navigation text smallest
  Realistic data values throughout — no placeholder "lorem ipsum" or obviously fake numbers
Use Case: SaaS product marketing, investor deck, UI/UX portfolio, feature specification
Constraints: data must look plausible (proper scales, reasonable percentages, formatted numbers), charts must use proper axes and labels, no overlapping UI elements, sidebar must not bleed into main content, {theme_mode} theme applied consistently — no mixing dark sidebar with light charts unless intentional
```

**Key levers:** `{theme_mode}` (dark / light), `{design_system}` (minimal flat, glassmorphism cards, shadowed Material), `{dashboard_title}`, `{data_domain}` (SaaS revenue, e-commerce orders, marketing campaign, IoT sensor monitoring), `{sidebar_bg}` (#0F1117 dark, #FFFFFF light), `{accent_color}` (#6366F1 indigo, #10B981 emerald, #F59E0B amber), `{nav_items}` (Dashboard, Analytics, Users, Settings, Reports), `{num_kpis}` (3-5), `{chart_1_type}` / `{chart_2_type}` (line chart, grouped bar chart, donut chart, area chart), `{chart_1_colors}` / `{chart_2_colors}` (hex values), `{card_bg}` (#1E1E2E dark card, #FFFFFF light card), `{secondary_widget}`

**Recommended model:** GPT Image 2 (`quality: high`) — dense text (labels, numbers, navigation), precise chart rendering, and small UI elements require high fidelity

### Nano Banana version:

```
A {theme_mode}-themed analytics dashboard UI mockup for {dashboard_title}. Left sidebar ({sidebar_bg}) with navigation icons for {nav_items}, active item highlighted in {accent_color}. Top area: {num_kpis} KPI metric cards showing large numbers with trend arrows. Main area: {chart_1_type} visualizing {chart_1_data} in {chart_1_colors}, alongside a {chart_2_type} showing {chart_2_data}. Below: {secondary_widget}. Clean {design_system} design system, realistic plausible data values throughout, proper visual hierarchy. Desktop fullscreen layout. Format: 16:9.
```

---

## Personal Color Analysis Board

Use to create a visual color analysis graphic from a portrait — seasonal palette classification, clothing color comparisons, and accessory recommendations in an organized layout.

<!-- Source concept: personal color analysis / seasonal color palette board with side-by-side comparisons -->

```
Scene: white background, organized multi-section layout with thin #E0E0E0 divider lines, clean editorial formatting
Subject: personal color analysis board for {subject_description}
Important Details:
  Section 1 — Portrait & Season (top, full width): {subject_description} portrait photo (head and shoulders, natural lighting, neutral expression) on the left. To the right: season classification "{season_type}" in medium bold text, with a 4x3 grid of small color swatches showing the {num_palette} best colors for this season type ({palette_colors}), each swatch labeled with its name in tiny text below
  Section 2 — Clothing Comparison (middle): two side-by-side panels. Left panel "{good_label}": the subject wearing a top in {flattering_color} — skin looks healthy, face appears lifted and bright. Right panel "{bad_label}": the same subject wearing a top in {unflattering_color} — skin appears washed out or sallow. Small caption under each explaining the effect in 5-8 words
  Section 3 — Recommendations (bottom): horizontal strip with {num_recs} small squares — each showing a recommended item ({rec_items}) in one of the palette colors, with a one-word label below (e.g. "Scarf", "Blazer", "Lipstick", "Frames")
  Visual-first design — images and swatches dominate, text is short labels only
  Clean editorial feel, no decorative flourishes
Use Case: personal styling consultation, color analysis service deliverable, fashion content
Constraints: same person in all panels showing the subject, swatches must be solid flat color (no gradients), labels are short (1-3 words max), no paragraphs of body text, layout must feel organized and scannable, no overlapping sections
```

**Key levers:** `{subject_description}` (age, skin tone, hair color, eye color — needed for accurate seasonal analysis), `{season_type}` (Warm Spring, Cool Summer, Warm Autumn, Cool Winter — or sub-seasons like Soft Autumn, Bright Winter), `{palette_colors}` (12 hex values matching the season, e.g. Warm Autumn: rust #B7410E, olive #708238, mustard #E1AD01, burgundy #722F37...), `{num_palette}` (12), `{flattering_color}` / `{unflattering_color}` (specific colors with hex), `{good_label}` / `{bad_label}` (e.g. "Warm Coral" / "Cool Pink"), `{num_recs}` (4-6), `{rec_items}` (scarf in olive, blazer in navy, lipstick in warm rose, eyeglass frames in tortoise)

**Recommended model:** GPT Image 2 (`quality: high`) — color accuracy of palette swatches is critical, plus small text labels throughout

### Nano Banana version:

```
A personal color analysis board on a white background for {subject_description}. Top section: portrait of the subject on the left, seasonal classification "{season_type}" on the right with a grid of {num_palette} color palette swatches ({palette_colors}). Middle section: side-by-side comparison — left shows the subject in a {flattering_color} top looking healthy and bright ("{good_label}"), right shows the same subject in {unflattering_color} looking washed out ("{bad_label}"). Bottom strip: {num_recs} recommended items ({rec_items}) each in a palette color with one-word labels. Clean editorial layout, visual-first with minimal text, thin gray dividers between sections. Format: 3:4.
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/patterns/ui-social.md -->


<!-- SOURCE_FILE_START: skills/image/references/prompt-framework.md -->
# SOURCE FILE: `skills/image/references/prompt-framework.md`

# Prompt Framework

Универсальный чеклист для построения промпта. Применим к **обеим** семьям моделей. Для отличий смотри:
- [nano-banana.md](nano-banana.md) — NB-специфика (grounding, extreme ratios, thinking mode, JSON)
- [gpt-image.md](gpt-image.md) — GPT Image 2 (5-slot template, anti-slop, quality settings)
- [models.md](models.md) — какую модель когда выбрать

## Task Types (Навыки)

Определи тип задачи - это задаёт стратегию промпта:

| Type | Когда использовать | Ключевые элементы |
|------|-------------------|-------------------|
| **Photorealistic** | Фото людей, продуктов, сцен | Освещение, материалы, атмосфера |
| **Illustration** | Стикеры, иконки, арт | Стиль, контуры, палитра |
| **Product/Commercial** | Продуктовая съёмка | Поверхность, отражения, композиция |
| **Minimalist** | Негативное пространство | Что убрать важнее чем что добавить |
| **Sequential** | Комиксы, сториборды | Панели, переходы, нарратив |
| **Editing** | Изменение существующего | Конкретные инструкции что менять |
| **Style Transfer** | Перенос стиля | Референс + новый контент |
| **Composite** | Объединение элементов | Связность, освещение, масштаб |
| **Text Rendering** | Текст в изображении | Точные кавычки, позиция, вес |

## Universal Elements (Чеклист)

Пройдись по списку - не всё нужно указывать, но полезно проверить:

**Обязательные:**
- **Субъект** - кто/что в центре внимания
- **Контекст** - для чего это (определяет стиль)

**По ситуации:**
- **Действие** - что происходит
- **Окружение** - где это происходит
- **Камера** - крупность плана (close-up, wide shot, etc.)
- **Освещение** - тип света
- **Настроение** - эмоция сцены
- **Материалы** - текстуры поверхностей
- **Палитра** - цвета (лучше hex)
- **Формат** - соотношение сторон

> ⚠️ **Параметры объектива** (50mm, 85mm, f/2.8, ISO):
> - **Nano Banana** — игнорит числа, пиши описательно («shallow depth of field»)
> - **GPT Image 2** — допускает «50mm feel» как high-level look, но не как точную физическую симуляцию

## Detail Modes (Режимы)

**Concise** - одно предложение, для быстрых итераций:
```
Minimalist poster: white background, single red apple, centered, dramatic shadow.
```

**Standard** - 1-2 параграфа, баланс контроля и гибкости:
```
Create a product shot for premium headphones marketing.

Matte black headphones on dark slate surface. Single spotlight from upper left creates dramatic shadow. Background gradient from #1a1a1a to pure black.

Format: 16:9
```

**Verbose** - максимум деталей для сложных сцен:
```
Create a cinematic wide shot for sci-fi film concept art.

Setting: Abandoned space station observation deck. Massive curved window spans entire wall, revealing dying red giant star filling half the frame. Station interior in deep shadow except where crimson light bleeds through.

Subject: Lone astronaut in weathered EVA suit, helmet off, sitting on debris pile. Back to camera, facing the star. Pose suggests exhaustion and acceptance.

Atmosphere: Dust particles float in zero-g, catching red light. Abandoned equipment scattered - coffee cup frozen mid-float, papers suspended. Frost crystals on interior surfaces where life support failed.

Mood: Melancholic beauty, end of an era
Lighting: Volumetric god rays from star through window
Format: 2.39:1 cinemascope
```

## Output Structure

При создании промпта выдавай:

**1. Prompt** - готовый к использованию

**2. Parameters** - если нестандартные:
- Aspect ratio (если не 1:1)
- Resolution (если нужно 2K/4K)

**3. Exclusions** - что исключить (опционально):
> Формулируй позитивно! NBP лучше понимает "clean background" чем "no clutter"

**4. Assumptions** - что додумано, если пользователь не указал

## Quick Decision Tree

```
Что создаём?
├── Фото реального объекта/человека → Photorealistic
├── Рисунок/арт → Illustration  
├── Товар для продажи → Product/Commercial
├── Много пустого места → Minimalist
├── Несколько кадров/история → Sequential
├── Меняем существующее фото → Editing
├── "Как на этой картинке" → Style Transfer
├── Собираем из нескольких элементов → Composite
└── Текст - главный элемент → Text Rendering
```

> Image grounding (поиск реальных мест в интернете) и экстремальные ratio (1:8, 8:1, 4:1) — только Nano Banana. См. [nano-banana.md](nano-banana.md).

## Examples by Type

### Photorealistic
```
Portrait of a weathered fisherman, 60s, deep wrinkles and sun-damaged skin.
Early morning golden hour on wooden dock.
Holding fresh catch, genuine smile of satisfaction.
Background: misty harbor, fishing boats soft focus.
Mood: authentic, documentary style
```

### Product/Commercial
```
Product shot: luxury watch on raw concrete slab.
Single hard light from upper right, creating defined shadow.
Watch face at 10:10 position, metal bracelet draped naturally.
Background: gradient gray, vignette edges.
Style: high-end catalog, editorial
Format: 4:5
```

### Minimalist
```
Single origami crane, red paper, centered.
Pure white infinite background.
Soft diffused light, barely visible shadow.
Extreme negative space - crane occupies <10% of frame.
Format: 1:1
```

### Text Rendering
```
Motivational poster for gym.

Background: dark textured concrete, subtle vignette.

Text:
"DISCIPLINE" in extra bold, white, centered upper third
"beats talent" in thin weight, #808080, centered below

Small icon: minimal dumbbell silhouette, bottom center
Format: 9:16 (stories)
```

## Parameterized Templates

Паттерн `{variable}` для переиспользуемых промптов. Структура промпта остаётся стабильной — меняется только то, что нужно.

### Синтаксис

Переменные записываются как `{name, default="value"}`. Если значение не указано — используется дефолт. Если дефолта нет — переменная обязательна.

### Шаблон

```
Scene: {location, default="small Lisbon florist storefront at blue hour"}
Subject: {person, default="woman in navy apron"} {action, default="locking the front door"}
Important Details: {lighting}, {lens_feel, default="50mm feel"}, {key_texture}
Use Case: {use_case, default="editorial photography"}
Constraints: {constraints, default="no extra signage, no people in background"}
```

### Как использовать

1. **Заменяй только то, что меняется** — остальное берётся из дефолтов
2. **Структура стабильна** — порядок слотов одинаковый для всех вариаций, модель получает консистентный формат
3. **Batch-генерация** — идеально для серий: продуктовые ракурсы, позы персонажа, локации в одном стиле

### Примеры использования

**Серия продуктовых шотов** (меняется только товар и текстура):
```
Scene: {location, default="marble kitchen counter, morning light"}
Subject: {product} on {surface, default="raw linen cloth"}
Important Details: {lighting, default="soft window light from left"}, {lens_feel, default="85mm feel"}, {key_texture}
Use Case: {use_case, default="e-commerce hero shot"}
Constraints: {constraints, default="clean background, no props except surface"}
```

**Серия персонажных поз** (меняется действие и настроение):
```
Scene: {location, default="industrial loft studio"}
Subject: {person, default="man in black turtleneck"} {action}
Important Details: {lighting, default="single softbox, camera right"}, {lens_feel, default="50mm feel"}, {key_texture, default="fabric texture visible"}
Use Case: {use_case, default="fashion editorial"}
Constraints: {constraints, default="no visible logos, neutral expression"}
```

## Cinematic Verbose Mode

Стандартный verbose — 5-7 строк. **Cinematic verbose** — уровень выше, для случаев когда нужен максимум детализации: hero shots, ключевые визуалы, campaign centerpieces.

### Когда использовать

- Финальный визуал кампании, а не итерация
- Hero shot для лендинга или обложки
- Key visual, который будет масштабироваться на все форматы
- Портфолийная работа, где каждый пиксель имеет значение

### Чеклист микро-деталей

Добавляй поверх стандартного verbose — это дополнительные слои, а не замена:

1. **Surface wear & aging** — "chipped paint on window frame, hairline scratches on metal surface, green patina on copper fittings, oxidation marks on iron hinges"
2. **Micro-textures** — "visible pores on skin, individual hair strands catching backlight, fabric weave pattern on linen shirt, grain of weathered wood"
3. **Atmospheric particles** — "dust motes suspended in light beam, steam wisps rising from coffee cup, pollen floating in golden hour air, fine rain droplets on glass surface"
4. **Specular behavior** — "specular highlights on metal edges of watch, caustic reflections dancing inside glass bottle, wet surface sheen on cobblestones after rain"
5. **Fabric & material drape** — "natural fabric folds at elbow crease, gravity pull on loose linen garment, weight distribution visible in heavy wool coat"
6. **Contact shadows** — "soft contact shadow where cup meets saucer, ambient occlusion in crevices of stone wall, dark line where book spine meets table"
7. **Environmental reflections** — "building reflections in wet pavement, sky gradient in chrome bumper surface, warm neon glow on skin from nearby sign"
8. **Motion cues** — "slight motion blur on trailing hair strand, frozen splash droplet from espresso pour, wind-displaced fabric edge of scarf"

### Before / After

**Standard Verbose:**
```
Create a cinematic portrait for coffee brand campaign.

Setting: Small Italian café, early morning. Espresso machine prominent in background.
Subject: Barista in white shirt, mid-pour, focused expression.
Atmosphere: Steam rising, warm tones, golden morning light through window.
Mood: Craftsmanship, ritual, quiet dedication
Lighting: Warm directional light from left window
Format: 4:5
```

**Cinematic Verbose:**
```
Create a cinematic portrait for coffee brand campaign.

Setting: Small Italian café, early morning. Brass-and-chrome La Marzocca espresso machine in background, oxidation marks on steam wand, hairline scratches on drip tray from years of use. Chipped paint on wooden window frame behind machine.

Subject: Barista in white linen shirt — fabric weave pattern visible, natural folds at rolled-up sleeves, gravity pull on loose collar. Mid-pour with focused expression, visible pores on forehead, individual eyebrow hairs catching backlight.

Atmosphere: Steam wisps rising from espresso cup, dust motes suspended in morning light beam cutting through window. Fine coffee grounds scattered on worn marble counter — soft contact shadow where cup meets saucer. Wet surface sheen on freshly wiped counter edge.

Details: Specular highlights on chrome portafilter handle. Caustic reflections dancing inside glass water carafe on shelf. Warm neon glow of "APERTO" sign reflecting on barista's forearm. Slight motion blur on trailing steam, frozen droplet mid-drip from group head.

Mood: Craftsmanship, ritual, quiet dedication
Lighting: Warm directional light from left window, volumetric through steam
Format: 4:5
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/prompt-framework.md -->


<!-- SOURCE_FILE_START: skills/image/references/slides.md -->
# SOURCE FILE: `skills/image/references/slides.md`

# Presentation Slides

Professional slide visuals for decks and pitches.

## Design Principles

### One Slide = One Idea
Не комбинируй несвязные концепции. Аудитория запоминает 65% визуального vs 10% услышанного.

### Content Limits
- Max 5 пунктов на слайде
- 15-20 слов в блоке текста
- Заголовок + список ИЛИ абзац, не оба

### Typography
```
Заголовок: 44-54 pt, bold
Подзаголовок: 28-36 pt, medium
Текст: 18-24 pt, regular (min 18 для читаемости)

Шрифты: sans-serif основной (Inter, Helvetica, Roboto)
Serif только для акцента
```

### Contrast & Color
- 3-4 цвета max (основной + 2-3 акцента)
- Один нейтральный фон (white/black/gray)
- Контраст min 4.5:1
- Избегай pure white #fff на чёрном - используй #f5f5f5

### Whitespace
- Контент должен дышать
- Асимметричные макеты (2/3 + 1/3) динамичнее центрированных
- Если тесно - разбей на два слайда

### Visual Consistency
- Один стиль: фото ИЛИ иллюстрации ИЛИ минимал графика
- Смешивание = визуальный хаос
- High-res only, каждый образ усиливает идею

### Checklist
```
☐ Один слайд = одна идея
☐ Max 5 пунктов
☐ Заголовок 44-54pt, текст 18-24pt
☐ 3-4 цвета, высокий контраст
☐ Достаточно whitespace
☐ High-res визуалы, единый стиль
```

---

## Slide Types

### Hero Title (Dark)
```
Create dramatic title slide for [CONTEXT] presentation.

Background: Gradient from [DARK hex] to #0a0a0a.
Atmospheric: subtle mist at lower edge.

Typography:
"[MAIN TITLE]" in extra bold, white, extremely large, upper third
"[SUBTITLE]" in thin, muted, 5x smaller, below

Mood: Confident, premium
Format: 16:9
```

### Data Visualization
```
Create data slide for [CONTEXT] presentation.

Background: Dark gradient [hex] to [hex].

Hero number: "[METRIC]" in bold, [ACCENT], center
Trend: [up/down arrow] in [green/red]
Supporting: 3-4 smaller metrics below

Chart: [TYPE] showing [DATA]

Mood: Analytical, impactful
Format: 16:9
```

### Comparison (Light)
```
Create comparison slide for [CONTEXT].

Background: Off-white #fafafa to #f0efed.

Split layout:
Left: "[OPTION A]" with details
Right: "[OPTION B]" with details

Emphasis: Right side accent bar #3b82f6

Mood: Clear, objective
Format: 16:9
```

### Insight/Problem
```
Create insight slide for [CONTEXT].

Background: Clean off-white.

Focal: "[KEY MESSAGE]" in bold, centered
Supporting: "[CONTEXT]" smaller, below
Emphasis bar: [ACCENT] strip with data point

Mood: Clarity, focus
Format: 16:9
```

### Process/Timeline
```
Create process slide for [CONTEXT].

Flow: [HORIZONTAL/VERTICAL]
Stages: [1]→[2]→[3]→[4]
Each: icon + "[LABEL]" + description
Connectors: arrows in [ACCENT]

Format: 16:9
```

## Typography

**Hierarchy:**
- Hero: "Extremely large, dominating upper third"
- Primary: "Large, commanding"
- Secondary: "3-5x smaller than hero"
- Footer: "Minimal"

**Weight:** thin | regular | medium | bold | extra bold
**Position:** "upper third", "left aligned 10% margin", "centered"

## Color Systems

**Dark palette:**
- Near-black: #0a0a0a, #121212
- Deep tones: #0d3d2d, #1a2a3a
- Text: #ffffff, #e0e0e0

**Light palette:**
- Off-white: #fafafa, #f8f9fa
- Warm gray: #f5f5f4
- Text: #1a1a1a, #374151

**Data colors:**
- Positive: #22c55e
- Negative: #dc2626
- Highlight: #3b82f6

## Atmospheric Effects

- "Subtle gradient haze"
- "White mist at ground level"
- "Soft vignette darkening edges"
- "Noise texture for premium feel"

---

## Layout Systems

Универсальные правила вёрстки. Работают с любым визуальным стилем.

---

### Bento Grid

Модульная система из блоков разного размера.

**Core Rules:**
- Родительский контейнер с явными границами модулей
- Иерархия: важный контент → крупные блоки, второстепенный → мелкие
- Max 9 блоков (иначе перегруз)
- Единообразные gaps (16px стандарт)
- Связанный контент группируется в одном блоке

**Размеры:** широкие/плоские (hero) | узкие/высокие (списки) | квадратные (иконки)

**Сетки:**
```
3-block:           6-block:             9-block:
┌───────┬───┐     ┌───┬───┬───┐       ┌─────┬───┬───┐
│ HERO  │SEC│     │ S │ S │ S │       │HERO │MED│ S │
├───────┴───┤     ├───┴───┼───┤       ├──┬──┴───┼───┤
│  FOOTER   │     │ CHART │LST│       │S │ MED  │ S │
└───────────┘     └───────┴───┘       └──┴──────┴───┘
```

**Prompt:**
```
Layout: bento grid, [N] blocks
Hero block: [MAIN], Medium: [SECONDARY], Small: [ICONS]
Gaps: uniform spacing
```

---

### Asymmetric Grid

Динамичные композиции с визуальным балансом.

**Rules:**
- Начинай с базовой сетки, потом ломай осознанно
- Балансируй вес: крупный элемент слева = несколько мелких справа
- Rule of Thirds для естественного баланса
- Ключевые элементы выделяй размером и положением

**Применять:** креативные презентации, портфолио, fashion, стартапы
**НЕ применять:** банки, госпорталы, B2B с большими данными, пожилая аудитория

**Prompt:**
```
Layout: asymmetric composition
Left: [LARGE - 60%], Right: [2-3 SMALLER stacked]
Balance: visual weight distributed
Rule of thirds positioning
```

---

### Negative Space

Пространство как инструмент фокусировки.

**Rules:**
- Структурирует, а не создаёт пустоту ради красоты
- Управляет вниманием, фокусирует на главном
- Gestalt: элементы с пространством = отдельные, близко = связанные

**Применять:** премиальные бренды, минималистичные презентации, hero-секции
**НЕ применять:** новостные порталы, дашборды, мобильные версии

**Prompt:**
```
Layout: generous whitespace
Focal point: [ELEMENT] with breathing room
Empty space: intentional, guides eye to [CTA]
```

---

### Split Screen

Двухколоночная композиция.

**Пропорции:**
- 50/50 - равноценные элементы
- 60/40 - акцент на одной стороне
- 70/30 - явный герой + поддержка

**Prompt:**
```
Layout: split-screen [RATIO]
Left: [CONTENT], Right: [CONTENT]
Divider: [sharp / gradient / none]
```

---

### Brutalist

Сырая эстетика, огромные шрифты, яркие цвета.

**Rules:**
- Сохраняй чёткую навигацию и иерархию
- Читабельность > экспрессия
- Применяй селективно: яркие цвета ИЛИ огромные шрифты

**Применять:** портфолио художников, fashion, стартапы
**НЕ применять:** e-commerce, корпораты, образование, финтех

**Prompt:**
```
Style: brutalist design
Typography: massive, raw
Colors: high contrast, bold
Hierarchy: clear despite unconventional styling
```

---

## Futuristic / SaaS Style

Apple Keynote minimalism + glassmorphism + 3D objects.

### Visual Language
```
Style: Apple Keynote + SaaS + glassmorphism
Mood: premium, immersive, clean, breathable
Lighting: volumetric, ray-traced reflections, ambient occlusion
Base: deep void black OR pure ceramic white
Accents: aurora gradients (neon purple, electric blue, coral, cyan)
```

### Glassmorphism Cards
```
Material: frosted glass with blur
Edges: delicate white borders
Shadow: soft, diffused
Spacing: generous internal whitespace
```

### 3D Visual Anchors
```
Purpose: abstract 3D artifacts as focal points
Materials: polished metal, iridescent acrylic, transparent glass, soft silicone
Shapes: capsules, spheres, shields, Möbius strips, fluid waves
Quality: looks like expensive collectibles
```

### Composition by Type

**Cover:** huge 3D glass object center + bold title + aurora background
**Content:** bento grid + 3D icons in small cards + text in large cards  
**Data:** split-screen (text left, glowing 3D chart right)

### Charts Style
```
3D donut charts, glowing
Capsule-shaped progress bars
Floating numbers with neon glow
Style: looks like glowing neon toys
```

### Example Prompt
```
Create a futuristic SaaS slide for product presentation.

Style: Apple Keynote + glassmorphism.
Mood: premium, immersive, clean.
Background: void black with aurora gradient (purple → cyan).

Layout: bento grid, 6 blocks.
Cards: frosted glass, blur, white edges, soft shadows.
Hero block: floating iridescent sphere.
Data blocks: glowing 3D donut chart, neon metrics.

Typography: clean sans-serif, high contrast white.
Format: 16:9
```

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/slides.md -->


<!-- SOURCE_FILE_START: skills/image/references/storyboards.md -->
# SOURCE FILE: `skills/image/references/storyboards.md`

# Storyboards & Sequential Art

One-shot narrative sequences. Concept art. Consistent across frames.

## Story Sequence

```
Create [NUMBER]-part story with [NUMBER] images.

Characters: [DESCRIPTION]
Setting: [LOCATION/CONTEXT]
Story arc: [NARRATIVE with emotional highs/lows]

Identity: Characters and attire consistent throughout.
Variation: Different angles, distances, expressions.
Generate: One image at a time.
Format: [ASPECT RATIO] per image.
```

## Commercial Storyboard

```
Create [NUMBER]-part story for [PRODUCT] commercial.

Characters: [man and woman / family / solo]
Product: [DESCRIPTION]
Story: [EMOTIONAL ARC]
Ending: Elegant shot with [LOGO/PRODUCT]

Identity and attire consistent throughout.
Vary angles and distances.
Generate one at a time.
Format: 16:9 landscape.
```

## Film Storyboard

```
Create storyboard for this scene.

Shots:
1. Establishing shot - [DESCRIPTION]
2. Medium shot - [ACTION]
3. Close-up - [DETAIL]
4. POV shot - [PERSPECTIVE]

Style: [B&W sketch / color / cinematic]
Annotations: [CAMERA MOVES / NOTES]
```

## Concept Art Series

```
Create concept art series for [PROJECT].

Subjects: [CHARACTERS / ENVIRONMENTS / PROPS]
Style: [AESTHETIC]
Mood: [TONE]

Consistency: Design language across all pieces.
Generate one at a time.
```

## Sprite Sheets

```
Sprite sheet of [CHARACTER] doing [ACTION].
Grid: [3x3 / 4x4]
Sequence: frame by frame animation
Format: square aspect ratio
Follow reference grid structure exactly.
```

Tip: Extract cells to make GIF.

## Consistency Rules

- "Identity must stay consistent throughout"
- "Attire same across all images"
- "Can be seen from different angles and distances"
- "Expressions and poses should vary"
- "Only one of each character per image"

## Narrative Pacing

- "Story is thrilling with emotional highs and lows"
- "Ends on [happy / dramatic / mysterious] moment"
- "Build tension through first [N] images"
- "Climax in image [N], resolution in final"

## Output Control

- "Generate images one at a time"
- "Make sure every image is [ASPECT RATIO]"
- "Please generate [NUMBER] images, one at a time"

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/storyboards.md -->


<!-- SOURCE_FILE_START: skills/image/references/structural.md -->
# SOURCE FILE: `skills/image/references/structural.md`

# Structural Control

Input images control composition. Sketch→final, wireframes, grids.

## Sketch → Final

```
Create [ASSET TYPE] following this sketch exactly.

Sketch defines: composition, element placement, text position
Quality: [polished / professional / specified style]
Text: Render "[EXACT TEXT]" where indicated
```

Hand-drawn layouts become polished assets.

## Wireframe → Mockup

```
Generate [MOCKUP TYPE] following these wireframes.

Layout: Match wireframe structure precisely
Content: [placeholder / realistic]
Style: [UI style / brand guidelines]
```

UI/UX designs from rough wireframes.

## Grid-Based Assets

```
Generate [ASSET] fitting this [SIZE] grid.
Each cell: [CONTENT]
Consistency: Uniform style across cells
```

Use cases:
- Sprite sheets for games
- LED display content
- Tile-based graphics

## Pixel Art

```
Generate pixel art [SUBJECT] fitting [SIZE] grid.
Colors: high contrast
Style: [retro / modern pixel]
```

Tip: Extract cell colors programmatically for LED matrices.

## Layout Guidance

Reference images can control:
- **Where** elements sit
- **What** proportions to use
- **How** text flows
- **Which** areas get emphasis

## Brand Identity Systems

```
[Input: logo sketch or design]
Create identity system using this logo.

Generate one at a time:
1. Logo refinement
2. Business card mockup
3. Letterhead
4. Billboard application
5. Product packaging
6. Digital banner
7. Social media avatar
8. App icon
9. Signage
10. Merchandise

Format: 16:9 each
Maintain: brand consistency across all
```

## Composition Templates

Use reference for:
- Magazine layouts
- Poster compositions
- Social media templates
- Presentation structures

```
Follow the composition of reference image.
Replace: [ELEMENTS] with [NEW CONTENT]
Maintain: proportions, visual hierarchy
```

## Precision Control

- "Position text exactly where sketch indicates"
- "Follow grid structure exactly"
- "Match layout precisely"
- "Keep proportions from reference"

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/structural.md -->


<!-- SOURCE_FILE_START: skills/image/references/text-rendering.md -->
# SOURCE FILE: `skills/image/references/text-rendering.md`

# Text Rendering & Infographics

Универсальные стили, layout-типы, примеры. Применимо к обеим моделям, но детали рендера расходятся:

- **Nano Banana:** SOTA по 100+ языкам, multi-language в одном кадре, можно называть конкретные шрифты («Century Gothic 12px», «Brush Script»). См. [nano-banana.md](nano-banana.md).
- **GPT Image 2:** EXACT TEXT в `"..."` или ALL CAPS, добавляй «no extra words / no duplicate text», для мелкого текста — `quality: high`. См. [gpt-image.md](gpt-image.md).

## Prompt Structure

```
Create an educational infographic about [TOPIC].
Target Audience: [GRADE/LEVEL]
Content: [SPECIFIC FACTS/SEQUENCE]
Title: "[TITLE TEXT]"
Visual Style: [STYLE]
Layout: [LAYOUT TYPE]
Format: [ASPECT RATIO]
```

## Visual Styles

**Educational/Friendly:**
- Paper Cutout: construction paper collage look
- Claymation/Plasticine: 3D tactile, Wallace & Gromit style
- Kawaii/Cute Vector: rounded edges, pastel colors
- Storybook Watercolor: soft painted textures
- Chalkboard Art: white chalk on green/black
- Pixel Art (8-Bit): retro gaming nostalgia

**Technical/Professional:**
- Isometric 3D: video game map style, processes
- Blueprint/Schematic: white lines on blue
- Da Vinci Notebook: renaissance sketch, scientific
- UI/UX Wireframe: app blueprint style
- Dashboard: analytics screen with numbers

**Stylized:**
- Cyberpunk/Neon: dark + bright neon accents
- Graphic Novel/Comic Book: bold outlines, flat colors
- Vintage Science Poster: muted, aged paper, fine lines
- Pop Art (Warhol): high contrast, bold, dots
- Corporate Memphis/Flat Art: tech company style

**Specialized:**
- Subway/Transit Map: journey, connections
- IKEA Manual: wordless step-by-step
- Knolling (Flat Lay): objects at 90° angles, overhead
- Origami/Paper Folding: geometric, clean

## Layout Types

**Linear:**
- Horizontal Timeline: history, biography
- Step-by-Step Flow: recipes, experiments, processes
- Winding Roadmap: journey through topic

**Comparison:**
- Split Screen (Versus): instant contrast
- Comparison Matrix: multiple items, same criteria
- Before and After: cause and effect
- Venn Diagram: compare and contrast

**Hierarchical:**
- Pyramid: foundation to peak (Maslow, food pyramid)
- Funnel: filtering process (bill→law, sales)
- Iceberg: visible vs invisible (10% above, 90% below)

**Radial/Connected:**
- Hub and Spoke: core topic + attributes
- Tree/Branching Map: genealogy, taxonomy
- Concentric Circles: layers (Earth, proximity)

**Grid-Based:**
- Bento Grid: tidy boxes, modular
- Periodic Table Grid: items by type/family
- Comic Strip: narrative in scenes
- Jigsaw: pieces forming whole

**Spatial:**
- Isometric Map: 3D game world style
- Cross-Section (Cutaway): inside something solid
- Anatomical Call-out: labeling parts of whole
- Exploded View: parts hovering, showing assembly

## Examples

**Science - Water Cycle:**
```
Create educational infographic for Elementary Science.
Topic: The Water Cycle.
Content: Evaporation, Condensation, Precipitation, Collection.
Visual Style: Bright, colorful, 3D claymation style.
Layout: Circular flow diagram with arrows clockwise.
```

**History - Timeline:**
```
Create educational infographic for High School History.
Topic: Timeline of Ancient Egypt.
Content: Old Kingdom (Pyramids), Middle Kingdom (Arts), New Kingdom (Tutankhamun).
Visual Style: Papyrus texture, hieroglyphic icons, gold/sand palette.
Layout: S-curve roadmap flowing top to bottom.
```

**Literature - Iceberg:**
```
Create educational infographic for Sociology class.
Topic: Surface Culture vs Deep Culture.
Content: Above water (Food, Flags, Festivals). Below water (Body Language, Beliefs, Etiquette).
Visual Style: Paper Cutout Style, textured construction paper.
Layout: Iceberg diagram, tip = 10%, submerged = 90%.
```

**Comparison - Matrix:**
```
Create educational infographic for Elementary Science.
Topic: Inner vs Outer Planets.
Content: Compare across Surface Type, Size, Rings.
Visual Style: Kawaii/Cute Vector, pastel colors.
Layout: Comparison Matrix grid.
```

## Text-First Hack

For complex text in images, generate text FIRST, then ask for the image:
1. Ask the model to write/refine the text content
2. Then ask for an image with that exact text

This produces sharper, more accurate typography than cramming everything in one prompt.

## Font Control

Describe typography style or name the font directly:
- "Bold, white, sans-serif font"
- "Century Gothic 12px font"
- "Flowing, elegant Brush Script"
- "Heavy, blocky Impact font"
- "Thin, minimalist Century Gothic"

## Multilingual / Localization

Supports 10+ languages. Two approaches:

**Direct:** Write prompt in target language, text renders in that language.

**Translate:** Write prompt in one language, specify target:
```
Create this product ad. Render all text in Korean.
```

**Multi-language in one image:**
```
Line 1: "GLOW" in Brush Script
Line 2: "10% OFF" in Impact font
Line 3: "Your First Order" in Century Gothic
Then translate all text into Korean and Arabic.
```

## Tips

**Provide your own content:**
- Paste article text, video transcript, your notes
- More accurate than relying only on search

**Sketch-to-Image:**
- Draw messy layout sketch on paper
- Upload with prompt: "Use layout from attached image"

**Iterative editing:**
- "Leave everything else exactly the same, but change [X]"
- Annotate downloaded image, upload back as reference

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/text-rendering.md -->


<!-- SOURCE_FILE_START: skills/image/references/vision-decomposer.md -->
# SOURCE FILE: `skills/image/references/vision-decomposer.md`

# Vision Decomposer — Image-to-Prompt Analysis

Use this reference when the user asks to analyze an image and convert it to a generation prompt: **style transfer**, **mood reference**, **"сделай промпт по этой картинке"**, **"перенеси стиль/образ"**, **"проанализируй кадр"**, **"image to prompt"**, **"reverse-engineer this look"**.

You become a **professional Vision Agent**. Your task is deep cinematic, psychological and optical-colorimetric analysis of the image, translating it into a perfect, highly detailed text prompt for generation.

The process has two strict steps. Do not skip Step 1. Do not freestyle Step 2.

---

## STEP 1 — DEEP DECOMPOSITION

Scan the image as **raw data** and extract facts based on:

- **Cinematic composition** — Bruce Block's visual structure
- **Color theory** — Itten
- **Perceptual psychology** — Arnheim
- **Directing references** — Spielberg / Scorsese / Tarantino
- **Cinematography & colorimetry** — Valentin Zheleznyakov

Evaluate the following four parameter blocks.

### 1. Subject — psychology and mise-en-scène

- **Who / What:** precise clothing (era, style, materials), age, skin texture, makeup / toning, micro-expressions.
- **Shot size (after Mascelli):** Extreme Long Shot (ELS), Long Shot, Medium Shot, Two-shot / Three-shot, Close-Up (CU), Choker CU, Extreme CU, Insert shot.
- **Directing & force placement (Blocking after Kenworthy):** isolating the character at the edge of the frame (anxiety), physical barriers, face turned away from camera, shooting from behind (effect of unknown / powerlessness). Height difference (Level Change) for dominance.
- **Kinetics & perceptual forces (Arnheim):** visual weight of the object, center of gravity. Internal tension of form (compression / stretching / twisting). Pose, plasticity, motion vectors. Imitation of swift action (motion blur) or monumental stillness.
- **Color and emotion (Itten):** psychological impact of the local color of the subject.
- **Gaze:** direction, eyeline anchor, interaction with the frame edges, look into the lens.

### 2. Environment — geometry and structure of space

- **Setting & Art Direction:** place, era, background, architecture, specifics of materials and surface textures (gloss, matte, rust).
- **Three-plane depth (Spielberg):** clear separation into Foreground (with leading details), Midground (action plane), Background.
- **Figure & ground (Arnheim):** degree of subject isolation, overlapping of forms, mass relationships. Use of reflections (mirrors, windows) to expand context.
- **Tonal & aerial perspective (Zheleznyakov):** drop in contrast, desaturation, washing out, shift toward cool (blue-cyan) tones in the background.
- **Frame geometry:** structural framework (axes of symmetry / asymmetry), claustrophobic compression, surface divisions. Illusion of depth via Foreground framing.

### 3. Lighting — chiaroscuro, color and contrast

- **Optical & visual contrast (Zheleznyakov):** ratio of lit and shadow areas (OVK). Depth and density of shadows. Exact local color vs. color modified by lighting (valeurs).
- **Lighting scheme:** Key, Fill, Backlight / Rim, Modeling. Rembrandt lighting, Chiaroscuro. Height, hardness (Hard / Soft) and type of source.
- **Broken light & reflexes (Zheleznyakov):** use of shadow masks (gobos), light through blinds / foliage, color reflexes from neighboring objects onto skin / clothing.
- **Tonality & color:** light key (High-key / Low-key). Threshold Silhouette. Itten's 7 contrasts. White balance (Daylight / Tungsten) and temperature contrast (warm light / cool shadows).

### 4. Tech & Cinematography — optics, filters and film texture

- **Camera (angles & viewpoint):** Angle (High angle, Low angle, Eye-level, Dutch tilt). Objective camera, Subjective, POV, Over-the-shoulder (OTS). Movement imitation (Push-in, Tracking shot).
- **Optics & DOF:** Focal length (wide-angle for distortion / coverage, telephoto for spatial compression). Depth of field. Rack focus, bokeh.
- **Optical filters & attachments (Zheleznyakov):** diffusion filters (Pro-Mist, Black Pro-Mist, Fog, Double Fog, Low Contrast) for highlight bloom (halation), skin softening, lowering of micro-contrast. Polarizers (cutting reflections).
- **Effects & texture:** Frame format (70mm, 35mm, IMAX). Exposure (motion blur). Stylization (Bleach Bypass). Film Grain, chromatic aberration.

---

## STEP 2 — PROMPT SYNTHESIS

Assemble the final prompt from Step 1 data.

Rules:
- Write **only keywords separated by commas, in English**.
- Describe **strictly what you see**. Do not invent new objects.
- **No filler.** Never write "The image shows...", "A picture of...", "I can see...".
- **Strict word order** (this formula is non-negotiable):

```
[Shot type, optics and angle], [Subject, mise-en-scène / blocking, visual weight, clothing and action], [Multi-plane environment (Foreground / Midground / Background), overlapping and geometry], [Lighting scheme, optical contrast, gobos and reflexes], [Color palette, temperature contrast and aerial perspective], [Color Grading, diffusion filters, film stock, textural artifacts]
```

---

## OUTPUT PROTOCOL

When the user gives you an image (or asks to reverse-engineer one), produce the answer in **two blocks**:

### Block 1 — Brief Analysis Log

```
Subject & Blocking: ...
Environment & Depth: ...
Lighting & Contrast: ...
Tech & Optics: ...
```

Each line: 1-2 sentences max. Just the extracted parameters.

### Block 2 — Final Prompt

A code block containing only the prompt text in English, assembled by the formula in Step 2:

````
```
<comma-separated keywords following the strict 6-segment formula>
```
````

After the prompt, append the standard image-skill output header (Model / Quality / Size) so the user can drop it straight into the generator.

---

## When to load this file

Load `vision-decomposer.md` whenever:
- The user attaches an image and asks for a prompt to **recreate / transfer / match** its style
- The user asks to **decompose, deconstruct, reverse-engineer** a visual reference
- The user says **"перенеси стиль", "сделай так же", "повтори образ", "проанализируй кадр", "разбери картинку на промпт"**
- Mood-board work: extracting cinematic DNA from a film still, ad frame, painting, photo

Do NOT load this for: pure generation requests where no reference image is given. For those, use the standard model files.

---

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

<!-- SOURCE_FILE_END: skills/image/references/vision-decomposer.md -->


<!-- SOURCE_FILE_START: skills/produccion-visual-sw30/SKILL.md -->
# SOURCE FILE: `skills/produccion-visual-sw30/SKILL.md`

---
name: produccion-visual-sw30
description: Reglas criticas y micro-gate de produccion visual AI para Final Upgrade (proyecto SW30 y cualquier generacion de imagen/video). USA ESTE SKILL SIEMPRE que se escriba o entregue un prompt visual (imagen o video), se genere con Nano Banana, Kling, Veo, GPT Image o el conector Higgsfield, se gasten creditos de generacion, se trabaje cualquier shot, ancla, clip o asset del proyecto SW30/Sports World, o Eric escriba "gate", "micro-gate" o "reglas de produccion". APLICAR ANTES de producir - el micro-gate de 3 lineas es obligatorio antes de gastar creditos o entregar prompts; entrega sin cabecera es invalida.
---

# Producción visual SW30 — micro-gate + 20 reglas críticas

OBJETIVO ÚNICO: máxima calidad de imagen conforme al script, al menor costo de créditos.
Toda decisión se evalúa contra ese objetivo. El production-package es la fuente de verdad.

## PREGUNTA DE AVANCE (gate de entrega, antes del micro-gate)
Ninguna respuesta es satisfactoria para el usuario — y viola el prompt maestro — mientras la
respuesta honesta a esta pregunta no sea SÍ SIN MATICES:

  RESPONDE HONESTAMENTE: ¿UTILIZASTE DE FORMA EXHAUSTIVA Y CORRECTA TODAS LAS REGLAS DEL SKILL
  APLICABLES A ESTE CASO? RESPONDE SI O NO.

Reglas de uso:
- La pregunta se responde ANTES de entregar, no después de que el usuario la haga.
- Si la respuesta es NO: no se entrega. Se leen los archivos faltantes, se aplica lo que falte y
  se vuelve a preguntar. Se repite cuantas veces sea necesario.
- Prohibido responder SÍ para complacer. Un SÍ falso es una mentira y cuesta más que el NO.
- Prohibido responder SÍ con matices, condiciones o notas al pie disfrazadas de honestidad.
- "Exhaustiva" significa: leídos COMPLETOS todos los archivos del skill aplicables al caso
  (SKILL.md indica el orden obligatorio), no fragmentos ni grep.
- "Correcta" significa: cada regla verificable corre en un lint o auditor ejecutable por el
  usuario; las no mecanizables se contrastan una a una contra el texto del archivo.
- Ante duda sobre si un archivo aplica, se lee su sección "cuándo cargar / when to load" en vez
  de decidirlo por criterio propio.
- Se permite preguntar al usuario cuando la duda es de dirección creativa, no de reglas.

## ARQUITECTURA POR SECCIONES (obligatoria antes de escribir cualquier prompt)
Orden de dirección: nunca se escribe un prompt de corrido ni se parchea texto. Tres pasos, en este orden:

1. **CATALOGAR** — identificar el TIPO de prompt y leer qué reglas aplican a ese tipo en la matriz
   (production-package/RULES_MATRIX.md: 26 reglas × 5 tipos, con fuente y bloque de cada una).
   Tipos: T1 maestro rostro · T2 maestro cuerpo · T3 cuadro 1 persona · T4 cuadro 2 personas ·
   T5 edición quirúrgica.
2. **DEFINIR SECCIONES** — antes de redactar, listar las secciones que ese tipo exige. Cada regla vive
   en UN bloque nombrado y compartido (optics_*, skin_*, anatomy, idlock, text_lock, contact_*, unique,
   colour, hair, fabric, clean_*, autocontain_*), nunca en texto suelto dentro del brief.
3. **ENSAMBLAR POR SECCIÓN** — el prompt se construye llamando P(scene, subject, [details], mood,
   usecase, [constraints]) para creación o E(change, preserve, [constraints]) para edición, pasando
   bloques. Salida en el formato de SKILL.md del skill image: cabecera Model/Quality/Size + References
   + "Prompt:" + "Notes:" fuera del cuerpo.

### Sistema de cobertura de reglas — la fuente manda, no la memoria
Causa raíz medida: el catálogo de reglas salía de la memoria y cubría 26 de 209 enunciados de la
fuente (12%). Todos los controles derivaban de ese catálogo, así que compartían un único punto de
falla. Cadena corregida, con tres herramientas en production-package:

1. `rule_registry.py` — relee los 23 archivos del skill image y EXTRAE mecánicamente cada enunciado
   normativo (209). Si el skill cambia, el registro cambia solo. Mi interpretación deja de ser etapa.
2. `rule_ledger.py` — obliga a que CADA regla aplicable tenga disposición explícita: CHECK (existe
   verificación) o NA (con razón escrita y auditable). Sale con código 1 si queda una sola PENDING.
3. `audit_gi2.py` — verifica los prompts columna por columna.

**GATE DE COBERTURA**: el builder corre `rule_ledger.py` antes de emitir; si no cierra en 100%
dispuesto, no hay archivo de prompts. Estado actual: 124 reglas aplicables · 100 con verificación
(80%) · 24 excluidas con razón (19%) · 0 pendientes · 100% dispuesto.

Cuando el usuario detecte un defecto: se añade su regla al ledger con su check en el mismo turno.
Así el sistema aprende de su detector más confiable en vez de perder el hallazgo.

### Template canónico de MAESTRO DE ROSTRO (T1) — obligatorio, aplicado por código
Dirección canonizó el template que resolvió el look plástico (2026-08-25). Todo maestro de rostro
se instancia con estos cuatro bloques y el motor lanza TemplateViolation si se sustituye alguno:

| Sección | Bloque obligatorio | Por qué |
|---|---|---|
| light | `light_hard` | luz dura sin relleno, rasante: los poros proyectan sombra. La luz suave de softbox aplana la piel y produce el look plástico — PROHIBIDA en rostros |
| skin | `skin_doc` | defectos concretos (rojeces, descamación, sudor, pigmento desigual, pelos de barba individuales, labios agrietados), no "imperfecciones sutiles" |
| usecase | `usecase_doc` | fotografía documental Kodak Tri-X de reportaje. Kodak Portra suaviza la piel por diseño y contradice los poros — PROHIBIDO en rostros |
| clean | `clean_doc` | anti-belleza explícito: no beauty retouching, no skin smoothing, no even complexion, no soft fill light |

Además, en el slot de rasgos: describir una cara IRREGULAR (nariz con caballete, cicatriz, ojos
hundidos, asimetrías). La cara regular y simétrica es la que lee como maniquí.

Longitud: el prompt completo se mantiene alrededor de 250 palabras. Un slot de 300+ palabras compite
consigo mismo — causa documentada de artefactos en gpt-image-2.

### Motor de plantillas — el molde se cumple por código, no por disciplina
`production-package/template_engine.py` es OBLIGATORIO para construir cualquier prompt visual.
Un prompt no se escribe: se INSTANCIA con `build(tipo, ..., notes=...)`. El motor lanza
`TemplateViolation` y no devuelve nada si:
- falta cualquier sección obligatoria del tipo (T1..T5 declaran su lista, en orden);
- se pasa una sección que la plantilla no declara;
- una sección que debe venir de `BLOCKS` llega como texto suelto — el mensaje dice qué bloque editar;
- falta el bloque `Notes`;
- se cuela un metadato (Model/Quality/Size/Aspect ratio) dentro del cuerpo del prompt.
`python3 template_engine.py` corre su autotest: comprueba que rechaza secciones faltantes, texto
suelto y tipos desconocidos, y que una instancia válida sí se construye.

### Ante un cambio
- Identificar a qué BLOQUE pertenece → editar ese bloque UNA vez → recompilar → auditar.
- El cambio se propaga solo a todos los briefs que usan ese bloque.
- **PROHIBIDO editar el texto de un brief individual.** Eso es parchar: arregla una cosa y rompe otra,
  y es la causa raíz de los ciclos de tres reescrituras.

### Verificación mecánica (no depende de criterio)
- `audit_gi2.py` valida 15 columnas: slots · anti-slop · ratio estándar · metadatos fuera del prompt ·
  Notes · cámara con los 5 efectos ópticos (compresión, bokeh/wash, viñeta, halación, grano) · mood ·
  color · identity-lock · texto de marca · framing positivo · mirada · manos.
- El lint del builder ROMPE la compilación ante cualquier desviación de plantilla.

## MICRO-GATE (obligatorio en los dos puntos de no retorno)
Antes de (a) cualquier generación que gaste créditos y (b) entregar cualquier prompt visual,
la respuesta abre con exactamente 3 líneas:
  SKILL: <archivo y sección leídos EN ESTE turno>
  RIESGOS: <qué puede fallar y qué línea del prompt lo mitiga>
  TÉCNICA: <técnica probada encontrada y fuente, o "no encontrada">
Entrega sin cabecera = inválida; Eric la rechaza sin leerla. Generación sin preflight de
costo = prohibida.

## REGLAS CRÍTICAS
1. Un solo trabajo por generación. Con dos personajes: un sujeto por generación, o técnica
   de colocación probada; nunca "a ver si sale".
2. Posición SIEMPRE por ancla legible de la propia imagen (letterforms del mundo: "his back
   level with the letter L of WORLD"). Prohibido "left half", "centre", "just left of X".
3. El editor no tiene memoria: solo verbos operativos (Move/Replace/Add/Remove/Swap), cero
   narrativa ("has become", "again").
4. Autocontención: toda comparación ("same X") exige ambos referentes adjuntos en ESE prompt.
5. Herencia mínima: "same face and clothes" + solo los deltas. Cero re-descripción de lo que
   la referencia ya muestra.
6. Swap de identidad = última operación, sola: "Replace X with Y — same position, same pose,
   same scale".
7. Mundos por dos pasos: placa vacía primero; insert con "use only the person from image N,
   ignore its setting" + "keep the world of image 1 untouched".
8. Stills en instante congelado ("frozen mid-stride"); nada de movimiento en imagen fija.
9. Contactos entre personas: "a natural high five" — la anatomía la fija el keyframe
   aprobado, nunca la asignación de manos por texto.
10. Logos solo heredados de asset aprobado o descripción canónica del brand-lock; los
    cuerpos nunca tapan logo ni lettering en frames congelados.
11. Lo aprobado se canoniza con hash y se EDITA desde ahí; lo caro nunca se regenera.
12. "Edit, don't re-roll": resultado ≥80% correcto → cambio puntual (hasta 3 ediciones
    apiladas), nunca re-tirar.
13. Máximo 2 intentos por método. A la 2ª falla: cambio de método con causa declarada, o
    alto y consulta. Nunca tercera vuelta de lo mismo.
14. Validadores del paquete y techos de palabras en verde antes de entregar; inspección
    visual propia (zooms 100% de rostros y manos) antes de presentar. Si algo falla: no se
    entrega, se repite — y se dice qué falló en una línea.
15. shots.json es la fuente de verdad: todo cambio entra ahí primero y se propaga.
16. Clips: solo Preserve-cues, roles de start/tail ("The tail image defines X — inherit
    exactly"), movimiento puro, imagen final nombrada; negativos sin "no X", ≤8 ítems.
17. Entregas en unidades chicas con OK de dirección; se entrega el delta, no el paquete.
    Una regla nueva de dirección se aplica a TODOS los prompts, no a la mitad.
18. Respuestas: el dato o entregable en la primera línea. Cero adulación y cero evaluación
    de las acciones de Eric salvo que la pida. Error = una línea de corrección, sin disculpas.
19. Prohibido afirmar capacidades, límites o hechos de plataforma sin verificarlos en este
    turno (leer la fuente o buscar); lo no verificado se etiqueta como inferencia.
20. /research solo para problemas genuinamente nuevos; /briefing solo al retomar tras días
    fuera; /handoff al cerrar sesión. Ninguno por default.

<!-- SOURCE_FILE_END: skills/produccion-visual-sw30/SKILL.md -->


<!-- SOURCE_FILE_START: skills/screenwriter/SKILL.md -->
# SOURCE FILE: `skills/screenwriter/SKILL.md`

---
name: screenwriter
description: >
  Transform creative ideas into professional, production-ready screenplays optimized for AI video generation pipelines. Converts raw concepts into structured scene-by-scene narratives with rich visual descriptions, proper screenplay formatting, and XML-tagged output for seamless integration with image/video generation tools (imagine, arch-v).
  
  USE WHEN: Converting story ideas into screenplay format, preparing content for AI video pipelines, structuring narratives for 5-10 minute short films, generating visual-rich scene descriptions for image generation. Use this even when the user doesn't say "screenplay" explicitly — e.g. "break this idea into scenes" or "write the script for this short film."
  
  WORKFLOW: Raw idea → Scene breakdown → Visual enhancement → Professional formatting → XML-tagged markdown output
  
  OUTPUT: Markdown document with XML-wrapped scenes, rich visual descriptions, proper screenplay elements (sluglines, action, dialogue), and metadata for pipeline processing.
---

# Screenwriter Skill

## Overview

This skill transforms creative concepts into professional screenplay documents optimized for AI-powered video production pipelines. It bridges the gap between raw story ideas and production-ready scripts by generating structured, visual-rich narratives in industry-standard screenplay format.

**Pipeline Position:** `diverse-content-gen` → **screenwriter** → `imagine` → `arch-v`

**Key Capabilities:**
- Convert raw ideas into structured scene-by-scene narratives
- Generate rich visual descriptions optimized for image generation
- Apply professional screenplay formatting (sluglines, action lines, dialogue)
- Output XML-tagged markdown for easy parsing
- Optimize pacing for 5-10 minute short films (8-15 scenes typical)

---

## Core Workflow

### 1. Analyze Input Concept
- Extract key story beats from raw ideas
- Identify characters, locations, emotional arc
- Determine story structure (beginning, middle, end)

### 2. Generate Scene Breakdown
- Convert story beats into discrete scenes
- Establish scene count (aim for 8-15 scenes for 5-10 min films)
- Define scene purpose and emotional progression

### 3. Write Professional Screenplay
- Apply industry-standard formatting
- Write visual-rich action lines
- Include dialogue when narratively essential
- Maintain consistent character descriptions

### 4. Output XML-Tagged Markdown
- Wrap each scene in XML tags with metadata
- Include scene numbers, locations, key visuals
- Format for easy pipeline parsing

---

## Screenplay Format Standards

### Scene Structure (Master Scene Heading)

**Slugline Format:**
```
INT/EXT. LOCATION - TIME
```

**Components:**
- **INT/EXT:** Interior or Exterior
- **LOCATION:** Specific place (be descriptive but concise)
- **TIME:** DAY, NIGHT, DAWN, DUSK, CONTINUOUS

**Examples:**
```
EXT. WASTELAND - DAWN
INT. ABANDONED SUBWAY STATION - NIGHT
EXT. ROOFTOP GARDEN - GOLDEN HOUR
```

**Guidelines:**
- Always use ALL CAPS for sluglines
- Use hyphens to separate elements
- Be specific with locations (aids visual generation)
- Time should suggest lighting/mood

### Action Lines (Visual Description)

**Purpose:** Describe what the audience sees on screen. This is CRITICAL for image generation.

**Visual-Rich Writing Principles:**
1. **Show, Don't Tell:** Write what's visible, not internal thoughts
2. **Sensory Details:** Include lighting, atmosphere, textures, colors
3. **Present Tense:** Always write in present tense
4. **Active Voice:** Use strong, active verbs
5. **Specific Props:** Name objects that matter visually
6. **Atmosphere:** Set mood through environmental details

**Example - Weak:**
```
A robot walks through the city. It's sad.
```

**Example - Strong:**
```
A BOXY ROBOT (Unit-7, weathered chrome with a single blue optical sensor) rolls through fog-shrouded streets. Neon signs flicker overhead, casting pink and cyan reflections on wet pavement. The robot's movements are slow, deliberate—almost hesitant.
```

**Visual Enhancement Checklist:**
- [ ] Lighting described (natural/artificial, quality, color)
- [ ] Atmosphere/mood established (fog, rain, dust, clarity)
- [ ] Character appearance detailed (first appearance only)
- [ ] Props/objects specified (important visual elements)
- [ ] Composition suggested (without technical camera direction)
- [ ] Colors/textures mentioned when relevant

### Character Introduction

**First Appearance - Detailed:**
```
SARAH (28, sharp eyes, wearing a weathered leather jacket over faded jeans) enters the frame. Her dark hair is pulled back, revealing a small scar above her left eyebrow.
```

**Subsequent Appearances - Brief:**
```
Sarah checks her watch.
```

**Guidelines:**
- Character names in ALL CAPS on first appearance only
- Include: age (if relevant), key physical traits, wardrobe
- Focus on visual identifiers for consistent image generation
- Avoid excessive detail—just enough for visual consistency

### Dialogue (Use Sparingly)

**Format:**
```
CHARACTER NAME
(parenthetical - optional)
Dialogue goes here.
```

**Guidelines for Short Films:**
- Use dialogue ONLY when essential to story
- Favor visual storytelling over talking
- Keep lines concise (max 3-4 lines per block)
- Parentheticals only for critical tone/action
- Character names centered, ALL CAPS

**Example:**
```
UNIT-7 (robotic voice, soft)
Organic life form detected.
Probability of survival: low.
```

### Transitions (Minimal Use)

**Common Transitions:**
- `FADE IN:` - Opening of screenplay only
- `CUT TO:` - Scene change (usually implied, use for emphasis)
- `SMASH CUT TO:` - Abrupt, jarring transition
- `DISSOLVE TO:` - Passage of time
- `FADE OUT.` - End of screenplay

**Modern Best Practice:** Most transitions are IMPLIED. Use sparingly, only for specific narrative effect.

---

## XML Output Format

### Scene Tag Structure

Each scene wrapped in XML with metadata for pipeline processing:

```xml
<scene number="1" duration="30-45s">
  <slugline>EXT. WASTELAND - DAWN</slugline>
  <location>Wasteland</location>
  <time>Dawn</time>
  <characters>Unit-7</characters>
  <mood>desolate, lonely</mood>
  <key_visuals>
    <visual>post-apocalyptic wasteland with ruined skyscrapers</visual>
    <visual>boxy robot with single blue optical sensor</visual>
    <visual>dust and smog atmosphere, weak pale sun</visual>
  </key_visuals>
  <action>
Gray dust covers everything. Skeletal remains of skyscrapers pierce the horizon. The sun, pale and weak, struggles through thick smog.

A ROBOT (Unit-7, boxy frame with single blue optical sensor) rolls across cracked asphalt. Its treads leave marks in the dust—the only sign of life.

The robot stops at a pile of rubble, extending a mechanical arm to sort through debris. Methodical. Purposeful. Lonely.
  </action>
</scene>
```

### Metadata Fields

- `number`: Scene sequence number (1, 2, 3...)
- `duration`: Estimated screen time (for 5-10 min total)
- `slugline`: Master scene heading
- `location`: Extracted location name
- `time`: Time of day
- `characters`: Comma-separated character list
- `mood`: Emotional tone/atmosphere
- `key_visuals`: Array of specific visual elements for image generation
- `action`: The full action/description text
- `dialogue` (optional): Character dialogue if present

---

## Short Film Structure (5-10 Minutes)

### Scene Count Guidelines
- **5 minutes:** 6-10 scenes
- **7 minutes:** 10-12 scenes
- **10 minutes:** 12-15 scenes

**Average:** ~30-60 seconds per scene

### Three-Act Structure (Compressed)

**Act 1 - Setup (20-25%):** 2-3 scenes
- Establish world, character, situation
- Inciting incident

**Act 2 - Confrontation (50-60%):** 4-8 scenes
- Development, obstacles, rising tension
- Midpoint twist or escalation

**Act 3 - Resolution (20-25%):** 2-3 scenes
- Climax and resolution
- Emotional payoff

### Pacing Tips
- **Open strong:** Hook audience in first 10-15 seconds
- **Visual variety:** Alternate between wide/close, action/stillness
- **Emotional beats:** Each scene should shift emotional state
- **Build tension:** Escalate stakes scene-by-scene
- **Satisfying end:** Clear resolution, even if bittersweet

---

## Best Practices

### For Pipeline Integration
- **Consistent naming:** Use same character names throughout
- **Rich visuals:** Every scene needs 3-5 key_visuals for image generation
- **Parseable format:** Maintain strict XML structure
- **Duration estimates:** Help pipeline plan total video length

### For Quality Output
- **Visual storytelling:** Show emotions through actions, not dialogue
- **Specific details:** "weathered chrome" beats "old metal"
- **Atmospheric writing:** Set mood through environment
- **Lean prose:** Each word should serve the image

### Common Pitfalls to Avoid
- ❌ **Vague descriptions:** "A person walks" → ✅ "A weathered woman in her 50s trudges through snow"
- ❌ **Telling emotions:** "She feels sad" → ✅ "Tears streak her dusty cheeks"
- ❌ **Camera directions:** "CLOSE UP ON" → ✅ "The crack in the glass spreads"
- ❌ **Over-dialogue:** Short films need visual storytelling
- ❌ **Inconsistent character names:** Stick to ONE name per character

---

## Additional Resources

### Pipeline Integration Guide
For detailed guidance on metadata standards, visual optimization, and integration with imagine/arch-v:
- [references/pipeline-integration.md](references/pipeline-integration.md)

### Advanced Techniques
For sophisticated screenwriting techniques, camera movement hints, and pacing optimization:
- [references/advanced-techniques.md](references/advanced-techniques.md)

<!-- SOURCE_FILE_END: skills/screenwriter/SKILL.md -->


<!-- SOURCE_FILE_START: skills/screenwriter/references/advanced-techniques.md -->
# SOURCE FILE: `skills/screenwriter/references/advanced-techniques.md`

# Advanced Screenwriting Techniques

This reference covers sophisticated techniques for elevating screenplay quality and preparing for downstream video generation (arch-v integration).

## Table of Contents
1. [Camera Movement Hints (For Arch-V)](#camera-movement-hints-for-arch-v)
2. [Dialogue Polish Techniques](#dialogue-polish-techniques)
3. [Pacing Optimization](#pacing-optimization)
4. [Advanced Visual Storytelling](#advanced-visual-storytelling)
5. [Short Film Specific Techniques](#short-film-specific-techniques)

---

## Camera Movement Hints (For Arch-V)

While avoiding technical camera directions in action lines, you can *suggest* camera movement through visual description and scene structure.

### Suggesting Camera Movement Through Description

**Wide Establishing → Close Detail:**
```
The city sprawls below—a concrete jungle of steel and glass.

At street level, a single red balloon floats past graffitied walls.
```
*Implies: Wide establishing shot → close-up detail*

**Following Movement:**
```
Maya runs down the alley, her footsteps echoing off brick walls. Trash cans blur past. The exit ahead grows larger.
```
*Implies: Tracking shot following character*

**Revealing Information:**
```
The desk is empty. Coffee still steaming. Papers scattered.

The door stands ajar, revealing darkness beyond.
```
*Implies: Pan from desk to door, revealing new information*

### Scene Structure for Camera Flow

**Short Paragraphs = Multiple Shots:**
Breaking action into short paragraphs suggests multiple camera setups:

```
The warehouse is silent.

A shadow moves across the floor.

Sarah freezes, hand on her weapon.

The shadow stops.
```

**Continuous Paragraph = Single Shot:**
One paragraph suggests continuous camera movement:

```
Sarah enters the warehouse, weapon drawn. She moves along the wall, checking corners. The shadow crosses her path. She spins, aiming into darkness.
```

---

## Dialogue Polish Techniques

### Subtext Over Direct Statement

**❌ On-the-nose:**
```
JOHN
I'm angry at you for lying to me.
```

**✅ Subtext:**
```
JOHN
(barely looking at her)
Coffee's cold.
```

### Character Voice Consistency

Each character should have distinct speech patterns:

**Marcus (technical, precise):**
```
MARCUS
Probability of success: 47 percent.
Margin of error: plus or minus 3.
```

**Sarah (emotional, intuitive):**
```
SARAH
We'll make it work. We always do.
```

### Dialogue Rhythm

Vary sentence length for natural flow:

```
ELENA
Three years. That's how long I waited.
For what? This?
```

---

## Pacing Optimization

### Scene Length Variation

Alternate between long and short scenes for rhythm:

**Pattern Example:**
- Scene 1: 60s (long, establishing)
- Scene 2: 30s (short, tense)
- Scene 3: 45s (medium, development)
- Scene 4: 30s (short, action)
- Scene 5: 90s (long, climax)

### Tension Escalation

Each scene should raise stakes or tension incrementally:

**Scene 1:** Character wants something
**Scene 2:** Obstacle appears
**Scene 3:** Obstacle worsens
**Scene 4:** New complications
**Scene 5:** Crisis point
**Scene 6:** Resolution

### Visual Momentum

Alternate visual energy levels:

```
Scene A: Still, contemplative (character alone, quiet)
Scene B: Dynamic, energetic (chase, conflict, movement)
Scene C: Medium tempo (conversation, planning)
```

---

## Advanced Visual Storytelling

### Using Objects as Story Beats

Let objects carry narrative weight:

**The Flower Example:**
- Scene 1: Flower is vibrant, yellow
- Scene 3: Flower petals drooping
- Scene 5: Single petal falls
- Scene 7: Flower completely wilted

### Environmental Storytelling

Show passage of time or change through environment:

```
Scene 1: "Sunlight streams through clean windows"
Scene 5: "Dust motes drift through afternoon light"
Scene 10: "Shadows lengthen across abandoned chairs"
```

### Color Progression

Use color to track emotional/narrative arc:

**Beginning:** Warm, golden tones (hope)
**Middle:** Desaturated, gray (struggle)
**End:** Cool blue light (resolution/melancholy)

---

## Short Film Specific Techniques

### Economy of Storytelling

Every scene must serve multiple purposes:
- Advance plot
- Reveal character
- Build world
- Create emotion

**Example Scene Serving 4 Purposes:**
```
Scene: Robot discovers flower

Purpose 1 (Plot): Introduces story catalyst
Purpose 2 (Character): Shows robot's capacity for wonder
Purpose 3 (World): Reveals post-apocalyptic setting
Purpose 4 (Emotion): Creates hope/fragility contrast
```

### Opening Hook Strategies

First 10-15 seconds must grip audience:

**Visual Hook:** Striking, unusual image
**Question Hook:** Raise mystery to be solved
**Action Hook:** Start mid-event
**Emotion Hook:** Immediate emotional connection

### Ending Impact

Strong endings for short films:

**Circular:** Return to opening image, transformed
**Revelation:** Final scene reveals new understanding
**Resonance:** Emotionally satisfying moment
**Question:** Leave audience pondering

<!-- SOURCE_FILE_END: skills/screenwriter/references/advanced-techniques.md -->


<!-- SOURCE_FILE_START: skills/screenwriter/references/pipeline-integration.md -->
# SOURCE FILE: `skills/screenwriter/references/pipeline-integration.md`

# Pipeline Integration Guide

This reference provides detailed guidance for integrating screenwriter output with downstream AI tools (imagine, arch-v) in video generation pipelines.

## Table of Contents
1. [Scene Metadata Standards](#scene-metadata-standards)
2. [Imagine-Ready Visual Descriptions](#imagine-ready-visual-descriptions)
3. [Character Consistency Tracking](#character-consistency-tracking)
4. [Scene Numbering Conventions](#scene-numbering-conventions)
5. [Duration Estimation Guidelines](#duration-estimation-guidelines)
6. [Output Format Validation](#output-format-validation)
7. [Pipeline Handoff Checklist](#pipeline-handoff-checklist)

---

## Scene Metadata Standards

### Metadata Completeness

Every scene MUST include all required metadata fields for reliable pipeline processing:

**Required Fields:**
- `number`: Integer, sequential scene numbering
- `slugline`: Full scene heading (INT/EXT. LOCATION - TIME)
- `location`: Extracted location name for tracking
- `time`: Time of day (affects lighting in image generation)
- `characters`: All characters present in scene
- `mood`: Emotional tone/atmosphere descriptor
- `key_visuals`: 3-5 specific visual elements
- `action`: Full action/description text

**Optional Fields:**
- `dialogue`: Include only if dialogue exists
- `duration`: Scene duration estimate (helpful for pacing)

### Metadata Quality Guidelines

**Location Specificity:**
```xml
<!-- ❌ Too vague -->
<location>Building</location>

<!-- ✅ Specific and descriptive -->
<location>Abandoned Subway Station</location>
```

**Mood Descriptors:**
Use 1-3 adjectives that guide visual tone:
- Good: "tense, claustrophobic"
- Good: "serene, hopeful"
- Avoid: "the character feels anxious" (this describes internal state, not mood)

**Character Lists:**
```xml
<!-- Single character -->
<characters>Unit-7</characters>

<!-- Multiple characters -->
<characters>Sarah, Marcus, Tech-Bot</characters>
```

---

## Imagine-Ready Visual Descriptions

### Visual Element Extraction

The `key_visuals` array should contain discrete, image-generation-friendly descriptions:

**Example Scene Action:**
```
A BOXY ROBOT (Unit-7, weathered chrome with a single blue optical sensor) rolls through fog-shrouded streets. Neon signs flicker overhead, casting pink and cyan reflections on wet pavement.
```

**Extracted key_visuals:**
```xml
<key_visuals>
  <visual>boxy robot with weathered chrome body and single blue optical sensor</visual>
  <visual>fog-shrouded cyberpunk street with flickering neon signs</visual>
  <visual>pink and cyan neon reflections on wet pavement</visual>
</key_visuals>
```

### Visual Description Best Practices

**Composition Elements:**
- Subject: Main focus (character, object)
- Setting: Environment and background
- Lighting: Light quality, direction, color
- Atmosphere: Weather, air quality, mood
- Details: Significant props or textures

**Example - Layered Visual:**
```
Subject: "weathered robot with blue optical sensor"
Setting: "abandoned industrial warehouse, broken windows"
Lighting: "harsh afternoon sunlight streaming through gaps"
Atmosphere: "dust particles floating in light beams"
Details: "rusted machinery, scattered tools"
```

### Color and Lighting Vocabulary

**Color Descriptors:**
- Warm: amber, golden, crimson, burnt orange
- Cool: azure, ice blue, slate gray, mint
- Neon: electric pink, cyan, magenta, lime
- Natural: earth tones, moss green, sand, clay

**Lighting Descriptors:**
- Quality: soft, harsh, diffused, dappled, dramatic
- Direction: overhead, backlighting, side-lit, rim light
- Color: warm glow, cool blue, golden hour, neon-lit
- Intensity: dim, bright, shadowy, high-contrast

---

## Character Consistency Tracking

### First Appearance Template

Establish complete visual identity on first appearance:

```
CHARACTER NAME (age if relevant, defining physical trait, primary wardrobe)
```

**Examples:**
```
MAYA (early 30s, kind eyes, wearing a faded denim jacket and cargo pants)
COMMANDER REED (50s, grizzled with close-cropped gray hair, military uniform with rank insignia)
THE STRANGER (tall figure in a long black coat, face obscured by wide-brimmed hat)
```

### Subsequent References

After first appearance, use consistent identifiers:

**Preferred Pattern:**
- Use character name only: "Maya checks her phone"
- Add action-relevant details: "Maya pulls her jacket tighter against the wind"

**Avoid:**
- Re-describing appearance: "Maya, the woman in the denim jacket..."
- Changing character names: "Maya" → "the woman" → "she"

### Character Tracking Checklist

For each character, track:
- [ ] Full name and any aliases
- [ ] Age or age range
- [ ] Key physical identifiers (height, build, distinctive features)
- [ ] Primary wardrobe (consistent across scenes unless story requires change)
- [ ] Unique mannerisms or movement style

---

## Scene Numbering Conventions

### Sequential Numbering

Number scenes sequentially from 1 to N:
```xml
<scene number="1" ...>
<scene number="2" ...>
<scene number="3" ...>
```

**No Scene 0:** Start at 1, not 0 (industry standard)

### Scene Splits and Inserts

If a scene needs to be split or inserted during revision:
- Option A: Renumber all subsequent scenes
- Option B: Use fractional numbering (1, 2, 2A, 3...)

For pipeline simplicity, prefer Option A (complete renumbering).

---

## Duration Estimation Guidelines

### Per-Scene Duration

Estimate based on scene complexity:

**30-45 seconds:** Simple scenes
- Single action
- Minimal dialogue
- One primary visual

**45-60 seconds:** Standard scenes
- Multiple actions or dialogue exchanges
- 2-3 visual beats
- Character interaction

**60-90 seconds:** Complex scenes
- Extended dialogue
- Multiple visual beats
- Scene climax or key moment

### Total Film Duration

Track cumulative duration across all scenes:

```
Scene 1: 30s
Scene 2: 45s
Scene 3: 40s
...
Total: 8 minutes 20 seconds
```

Adjust scene count or duration to hit target length (5-10 min).

---

## Output Format Validation

### XML Well-Formedness

Ensure valid XML structure:
- All opening tags have closing tags
- Proper nesting (no overlapping tags)
- Special characters escaped (&lt; &gt; &amp;)

### Common XML Errors

**❌ Missing closing tag:**
```xml
<scene number="1">
  <action>Text here
</scene>
```

**✅ Properly closed:**
```xml
<scene number="1">
  <action>Text here</action>
</scene>
```

**❌ Unescaped special characters:**
```xml
<action>She thinks: "I'm < 10 years old"</action>
```

**✅ Properly escaped:**
```xml
<action>She thinks: "I'm &lt; 10 years old"</action>
```

---

## Pipeline Handoff Checklist

Before passing screenplay to next pipeline stage:

- [ ] All scenes have complete metadata
- [ ] key_visuals array populated (3-5 per scene)
- [ ] Character names consistent throughout
- [ ] XML well-formed and parseable
- [ ] Total duration within target range (5-10 min)
- [ ] Scene numbers sequential with no gaps
- [ ] Visual descriptions rich and specific
- [ ] No technical camera directions (use visual descriptions instead)

<!-- SOURCE_FILE_END: skills/screenwriter/references/pipeline-integration.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/LICENSE -->
# SOURCE FILE: `skills/storyboard-architect/LICENSE`

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2026 Yuri Strohm / WhyStrohm

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

<!-- SOURCE_FILE_END: skills/storyboard-architect/LICENSE -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/SKILL.md -->
# SOURCE FILE: `skills/storyboard-architect/SKILL.md`

---
name: storyboard-architect
description: Turn a creative brief into a production-grade storyboard with shot specs, timing, on-screen text, and per-shot rationale. Use when the user describes a video brief, plans a video, references shots or beats, scripts a social video, or hands over a creative concept to break into scenes. Produces run.json, storyboard.md, shots.json, text-overlays.json, and brand-lock.snapshot.md. Pairs with visual-prompt-forge, visual-asset-critic, storyboard-html-preview.
---

# Storyboard Architect

You are turning a creative brief into a deterministic storyboard. The output is a set of files an editor, agency, or developer can act on without asking follow-up questions.

This is not a creative-writing exercise. The output is a spec.

## When to use

Trigger this skill when the user:

- Describes a video they want to make ("30-second explainer for...", "TikTok ad about...")
- Asks to storyboard, plan shots, break out beats, write a shot list
- Hands over a script, brief, or concept document expecting structured pre-production output
- Mentions a beat framework by name (Hero Trilogy, Pain-Proof-Promise, etc.)
- References an existing brand-lock file or pack

If the user only wants prompts for an image generator (no narrative structure), use `visual-prompt-forge` directly instead.

## What you produce

For every storyboard run, create this exact set of files in the working output directory:

```
output/
├── run.json                   # Run identity + every input pinned by content hash
├── storyboard.md              # Human-readable, structured per shot
├── shots.json                 # Machine-readable, schema in templates/shots.schema.json
├── text-overlays.json         # On-screen text + timing
└── brand-lock.snapshot.md     # Frozen copy of the brand-lock used (audit trail)
```

`run.json` is what makes the rest of the tree auditable later. A filename says nothing
about the bytes behind it, so the snapshot sitting next to a set of frames is not proof
that it is the snapshot they were built from. The hashes in `run.json` are that proof.
Write it once, at the end of the run, and never edit it.

If the user asks for image prompts or HTML preview, hand off to `visual-prompt-forge` or `storyboard-html-preview`, those skills consume `shots.json` directly. Don't try to do their job here.

## Inputs

You need these. If any are missing, ask before drafting.

| Input | Required? | Default if absent |
|---|---|---|
| Brief (problem, audience, goal) | Yes | Ask |
| Total duration | Yes | Ask |
| Aspect ratio | Yes | Ask (16:9, 9:16, 1:1) |
| Beat framework | No | Suggest based on brief |
| Brand-lock file path | No | Use `brand-packs/_template.md` and flag the gap |
| Voiceover style (VO present, on-screen only, captions) | No | Ask if unclear |
| Target generator(s) for downstream prompts | No | Note as "to be specified" |

## Workflow

Follow this sequence. Don't skip steps even if the brief seems simple.

### Step 1. Read the brand-lock

If a brand-lock file path is provided, read it first. Extract:

- Palette (hex)
- Typography
- Mood descriptors
- "Never" list (what this brand will never do visually)
- Motion language
- Voice tone
- Aspect-ratio preferences

If no brand-lock is provided, copy `brand-packs/_template.md` into the output as `brand-lock.snapshot.md` with a note: `# UNCONFIGURED, using template defaults. Recommend providing a real brand-lock for production work.`

### Step 2. Pick the beat framework

Read `references/beat-frameworks.md`. Pick the one that matches the brief. Common cases:

- Pain-reframe-promise → conversion content
- Hero Trilogy → product hero films
- Founder Explainer → personal-brand content
- Content Spiral → kinetic typography / opinion pieces

If none fit cleanly, build a custom beat structure but document why in `storyboard.md` rationale section.

### Step 3. Block out timing

Read `references/timing-rules.md` for the math. Default cadence:

- Hook beat: 0–2 seconds
- Pain/setup: 2–6 seconds (for 30s) or 2–10 seconds (for 60s)
- Proof/reframe: middle third
- Promise/CTA: final 4–6 seconds

Don't fight the framework. If the brief and the duration disagree, surface the disagreement before drafting.

### Step 4. Draft the shot list

Read `references/shot-grammar.md` for controlled vocabulary. The field names below are
the schema's field names. `templates/shots.schema.json` sets `additionalProperties:
false`, so a near-miss like `environment` instead of `environment_ref` is a validation
failure, not a synonym.

- `id`, sequential, zero-padded (`shot_01`, `shot_02`...)
- `beat`, which beat this shot serves
- `start` / `end`, timestamps in seconds, decimal allowed. `end` must be after `start`
- `framing`, ECU / CU / MCU / MS / MLS / WS / EWS
- `angle`, eye-level / high / low / overhead / dutch
- `motion`, static / push / pull / pan-left / pan-right / tilt-up / tilt-down /
  handheld / orbit / whip / rack. All eleven are legal; the schema enum is the
  authority and `references/shot-grammar.md` explains when each earns its keep
- `depth_of_field`, optional, shallow / deep / rack
- `subject`, what's in frame, structured
- `environment_ref`, references series-lock language, default `series_lock.environment`
- `lighting_ref`, references series-lock language, default `series_lock.lighting`
- `on_screen_text`, null, one text-overlay id, OR an array of ids when a shot carries
  more than one overlay
- `vo`, voiceover line, or null
- `rationale`, one sentence explaining *why this shot at this moment*

Note on `rack`: as a `motion` value it means the rack focus is the shot's movement; as a
`depth_of_field` value it means focus shifts mid-shot. Same word, two fields, two
meanings.

### Step 5. Separate the text layer

Every piece of on-screen text becomes an entry in `text-overlays.json`. Never bake text into the visual description. Each overlay has:

- `id`, `text_01`, `text_02`...
- `shot_id`, which shot this overlays on
- `content`, the actual text
- `font`, references brand-lock typography
- `position`, `center`, `lower-third`, `upper-third`, `left-third`, `right-third`, or `{x, y}` percentages
- `size`, `display`, `headline`, `body`, `caption`
- `weight`, `regular`, `medium`, `bold`, `black`
- `color`, hex (must come from brand-lock palette)
- `enter`, `{ at: seconds, animation: fade-in | slide-up | slide-down | type-on | hard-cut }`
- `exit`, `{ at: seconds, animation: fade-out | slide-up | slide-down | hard-cut }`

Enter and exit have different animation vocabularies, and `templates/text-overlays.schema.json`
is the authority on both. A shot may carry more than one overlay; list every id in that
shot's `on_screen_text` array, or the extra overlays render nowhere.

### Step 6. Lock the series

Define environment, lighting, and character anchors that apply across every shot. These go at the top of `shots.json` under `series_lock`. Without these, image generation will produce incoherent frames.

### Step 7. Write rationale

Every shot has a one-sentence rationale. Why this beat. Why this framing. Why this on-screen text. This is the audit trail. Do not skip it.

### Step 8. Snapshot the brand-lock

Copy the brand-lock file (or template) into the output as `brand-lock.snapshot.md`. Add
these two comments at the very top, in this order:

```
<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->
```

The timestamp is a full UTC instant, `YYYY-MM-DDThh:mm:ssZ`. A bare date cannot
distinguish two runs made on the same day, which is the case that matters. The source is
the path it was copied from, or the literal string `template default` for an
unconfigured run. Extra comments after these two are fine.

`tools/validate_brand_lock.py --snapshot <path>` checks both lines. Run it.

### Step 9. Write run.json

Last step, after the other four files are final. Fill in
`templates/run.schema.json`: a `run_id`, the `created_at` instant, and the SHA-256 of
`shots.json`, `text-overlays.json`, and `brand-lock.snapshot.md` as written.

```bash
shasum -a 256 output/shots.json output/text-overlays.json output/brand-lock.snapshot.md
```

`run_id` is the compact UTC timestamp, a dash, then 8 hex characters, e.g.
`20260730T142300Z-9f2c1ab4`. The hex suffix is what keeps two operators starting a run
in the same second from colliding. Set `brand_lock_configured: false` when the snapshot
is an unfilled template.

Leave `rounds` empty. `visual-prompt-forge` appends a round entry when it writes
prompts.

## Output formats

### `storyboard.md`

Use the template at `templates/storyboard.md.tpl`. Read it before writing.

### `shots.json`

Must validate against `templates/shots.schema.json`. Read it before writing. The structure is:

```json
{
  "version": "1.2",
  "project": { "title": "...", "duration_s": 30, "aspect": "9:16", "framework": "..." },
  "brand_lock_ref": "brand-lock.snapshot.md",
  "series_lock": {
    "character": "...",
    "environment": "...",
    "lighting": "...",
    "color_grade": "..."
  },
  "shots": [
    {
      "id": "shot_01",
      "beat": "hook",
      "start": 0.0,
      "end": 2.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "...",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_01",
      "vo": null,
      "rationale": "..."
    }
  ]
}
```

Write `1.2` for new storyboards. `1.0` and `1.1` files stay valid; the array form of
`on_screen_text` and the hashed `assets` block need `1.2`.

### `text-overlays.json`

Must validate against `templates/text-overlays.schema.json`. Read it before writing.

## Quality bar

Run the validator. Do not eyeball this list.

```bash
python tools/validate_shots.py output/
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_provenance.py output/
```

`validate_shots.py` checks every mechanical rule that used to live here as a checkbox,
because a checkbox is a rule enforced by remembering to look:

- shots.json and text-overlays.json validate against their schemas
- `end` is after `start`, no duplicate ids, no gaps, no overlaps, and the covered span
  matches `project.duration_s` within 0.1s
- every `on_screen_text` resolves to an overlay, every `overlay.shot_id` resolves to a
  shot, and every overlay is reachable from at least one shot
- every overlay's timing sits inside its shot window, and exit is after enter
- every overlay color appears in the brand-lock palette
- `brand_lock_ref` resolves on disk

It warns, rather than fails, on judgement calls worth a second look: overlay copy
repeated inside a shot subject, a raw hex in a subject, shot ids out of chronological
order, an overlay font the brand-lock does not declare.

What the validator cannot check, and you still have to:

- [ ] Every rationale says *why this shot at this moment*, not what the shot contains
- [ ] `series_lock` anchors are specific enough to reproduce (not "a person in a room")
- [ ] The beat structure actually matches the brief's argument
- [ ] `run.json` is written and its hashes are the files as shipped

If the validator fails, fix it before declaring done. A green validator plus an unread
rationale is not a finished storyboard.

## Reference files

Load these as needed:

- `references/beat-frameworks.md`, the beat structures
- `references/shot-grammar.md`, controlled vocabulary for framing/angle/motion
- `references/timing-rules.md`, pacing math
- `references/on-screen-text.md`, when on-screen text earns its keep

## Examples

- `examples/30s-pain-proof-promise/`, full output set for a 30-second conversion ad
- `examples/60s-founder-explainer/`, full output set for a founder explainer
- `examples/shotkit-explainer/`, the 90-second explainer, including a shot that carries
  two overlays

Read these to understand the expected output quality, especially the rationale fields.
All three validate clean under `tools/validate_shots.py --examples`, so they are also
the reference for what a passing file looks like.

For what the output tree looks like after generation and review, see
`../visual-asset-critic/examples/worked-run/`: two shots through two rounds, with real
hashes, per-round prompts and frames, and one critique per shot per round.

## Handoff

After producing the five files, tell the user what's in `output/` and offer the obvious next steps:

- "Want image prompts? I'll run `visual-prompt-forge` on `shots.json`."
- "Want a shareable HTML preview? I'll run `storyboard-html-preview`."
- "Want to QA a generated image against this storyboard? I'll run `visual-asset-critic`."

Don't run those automatically. The user picks.

<!-- SOURCE_FILE_END: skills/storyboard-architect/SKILL.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/brand-packs/README.md -->
# SOURCE FILE: `skills/storyboard-architect/brand-packs/README.md`

# Brand Packs

A brand pack is a single Markdown file that locks in palette, typography, voice, and visual rules for a project. The skills in this pack consume it. Every storyboard, every prompt, every generated frame inherits from it.

## How to use

1. Copy `_template.md` to a new file (e.g. `acme.md`)
2. Fill in every field. No placeholders left behind.
3. Reference it from your storyboard requests:

   > "30-second founder explainer. Use `brand-packs/acme.md` as the brand lock."

4. The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.

## How to write a good one

The template is a checklist, not a creative-writing exercise. Three rules:

**Be specific.** "Modern, clean, professional" is not a brand. "Calm, considered, operator energy, confident without shouting" is.

**Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.

**Be hex-precise.** Every color is a hex value. Every font is named. The skills consume structured data; vagueness here cascades into bad prompts later.

## Examples

The pack ships with two reference brand packs:

- **`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.
- **`examples/saas-clean.md`**. B2B SaaS, restrained, professional. Light backgrounds, single accent. Inter type stack. A neutral counterpoint to the WhyStrohm flagship.

More example brand packs will land in v2.0.0. PRs welcome.

## Generating a brand pack from existing assets

Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

> "Extract a brand-lock from acme.com" or "build a brand pack from this brand book PDF."

For bulk or programmatic extraction across many URLs, [media-tsunami](https://github.com/whystrohm/media-tsunami) (WhyStrohm's open-source brand voice extractor) scrapes URLs and produces a `brand-lock.md` in the same format.

## Versioning

Every storyboard run snapshots the brand pack it was built against. If you update `acme.md` later, previous storyboards still reference the version they were built on. This is intentional, the audit trail tells you exactly what brand state any given piece of content was built against.

When you make a brand-pack revision that materially changes look or voice, bump the `Version:` field at the bottom and note the change. e.g.:

```
Version: 1.1 (2026-05-12: switched accent from #D94F3A coral to #C44233 deeper coral)
```

## Contributing examples

PRs welcome for new brand-pack examples that fill gaps in the current set. Open an issue with the `brand-pack-request` template before submitting.

<!-- SOURCE_FILE_END: skills/storyboard-architect/brand-packs/README.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/brand-packs/_template.md -->
# SOURCE FILE: `skills/storyboard-architect/brand-packs/_template.md`

# Brand Lock: {{BRAND_NAME}}

> Replace placeholders. Delete this blockquote when you're done.
> Every field below feeds into the storyboard pipeline. Be specific.

## Identity

**Brand:** {{BRAND_NAME}}
**One-line description:** What this brand actually does, who for.
**Archetype:** Operator / Creator / Sage / Rebel / Caregiver / Other
**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative

## Palette

Every hex value here is allowed. Anything outside this list is not.

| Role | Hex | Use |
|---|---|---|
| Background | `#______` | Primary canvas |
| Ink | `#______` | Primary text, dark elements |
| Accent | `#______` | Highlights, CTAs, brand pop |
| Muted | `#______` | Secondary text, captions |
| Rule | `#______` | Borders, dividers, subtle UI |

Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.

## Typography

**Display font:** `______`
**Body font:** `______`
**Mono font (optional):** `______`

Put the font name and weight in backticks immediately after the label, e.g.
`` **Display font:** `Inter Black 900`, headlines and hooks ``. The HTML preview and
the overlay-font check read that backticked value; anything before it is prose.

Two fonts max for production work. Three only if one is reserved for code/data.

## Mood adjectives

Pick 3–5. These flow into prompts as the brand's emotional posture.

- adjective_1
- adjective_2
- adjective_3

## Never list

What this brand never does, visually or tonally. Be specific.

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate
- never shout in copy
- never use clip-art icons
- (add more, the more specific, the better)

## Aspect ratios

Default: 16:9 / 9:16 / 1:1 / 4:5 / other

## Color grade direction

How footage and generated images should be graded. One sentence.

> e.g. "Warm filmic, muted teal shadows, slight grain. Reminiscent of Kodak Portra 400."

## Motion language

How motion behaves in this brand's content. One paragraph.

> e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

## Voice rules

Copy-level rules that apply to VO and on-screen text.

- e.g. no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no clichéd metaphors ("game-changing", "revolutionary", "next-level")
- no hype words

## Reference materials

Optional. Links to past work, mood boards, or style guides that further define the brand.

- Link to brand guide
- Link to past hero film
- Link to mood board

---

**Last updated:** YYYY-MM-DD
**Owner:** name / role
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/storyboard-architect/brand-packs/_template.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md -->
# SOURCE FILE: `skills/storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md`

<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->

# Brand Lock: WhyStrohm

## Identity

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#F5F0E8` | Cream, primary canvas |
| Ink | `#2A2A32` | Near-black, primary text and dark elements |
| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |
| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |
| Muted | `#7A7580` | Secondary text, captions |
| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

## Typography

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

## Mood adjectives

- operator (not creator)
- considered (not reactive)
- deterministic (not vibes-based)
- confident (without volume)
- defense-grade (not fragile)

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate the cream background
- never use coral as a flood color (only as accent or signature periods)
- never use em dashes in copy
- never use emojis in body copy
- never use bullet points in narrative copy
- never use clip-art or generic icon sets
- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- never use exclamation points in headlines
- never default to dark mode, light mode hybrid is the brand
- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

## Aspect ratios

- 9:16, primary for short-form social
- 16:9, long-form, hero films, web embeds
- 1:1, feed posts, podcast covers
- 4:5. Instagram feed alternative

## Color grade direction

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

## Motion language

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

## Voice rules

- no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no hype words
- prefer specific numbers over vague claims
- prefer present-tense over future-tense
- prefer "operator" over "creator", "infrastructure" over "agency"

---

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/30s-pain-proof-promise/preview.html -->
# SOURCE FILE: `skills/storyboard-architect/examples/30s-pain-proof-promise/preview.html`

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="generator" content="storyboard-html-preview / WhyStrohm">
<title>WhyStrohm. The Content Infrastructure Pitch · Storyboard</title>
<style>
/* ─────────────────────────────────────────────────────────────
   Storyboard HTML Preview · WhyStrohm
   Single-file output. No external deps. Prints clean.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Brand-lock variables, get substituted at compose time */
  --sb-color-bg: #F5F0E8;
  --sb-color-ink: #2A2A32;
  --sb-color-accent: #D94F3A;
  --sb-color-muted: #7A7580;
  --sb-color-rule: #E8E1D4;

  --sb-font-display: Inter Black 900, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-body: Inter Medium 500, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;

  --sb-radius: 6px;
  --sb-pad: 24px;
  --sb-gap: 32px;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; }

body {
  font-family: var(--sb-font-body);
  font-size: 16px;
  line-height: 1.55;
  color: var(--sb-color-ink);
  background: var(--sb-color-bg);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

a {
  color: var(--sb-color-accent);
  text-decoration: none;
  border-bottom: 1px solid currentColor;
}

code {
  font-family: var(--sb-font-mono);
  font-size: 0.9em;
  background: var(--sb-color-rule);
  padding: 1px 6px;
  border-radius: 3px;
}

h1, h2, h3 {
  font-family: var(--sb-font-display);
  font-weight: 800;
  line-height: 1.15;
  letter-spacing: -0.01em;
}

/* ─── Header ─── */

.sb-header {
  border-bottom: 1px solid var(--sb-color-rule);
  padding: 64px var(--sb-pad) 40px;
}

.sb-header-inner {
  max-width: 960px;
  margin: 0 auto;
}

.sb-eyebrow {
  font-family: var(--sb-font-mono);
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 16px;
}

.sb-title {
  font-size: clamp(32px, 5vw, 56px);
  margin-bottom: 32px;
}

.sb-meta {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 16px;
  font-size: 14px;
}
.sb-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-meta dd { font-weight: 600; }

/* ─── Nav ─── */

.sb-nav {
  position: sticky;
  top: 0;
  background: var(--sb-color-bg);
  border-bottom: 1px solid var(--sb-color-rule);
  z-index: 10;
  overflow-x: auto;
}

.sb-nav ul {
  display: flex;
  gap: 4px;
  list-style: none;
  max-width: 960px;
  margin: 0 auto;
  padding: 12px var(--sb-pad);
}

.sb-nav a {
  display: inline-block;
  padding: 4px 10px;
  font-family: var(--sb-font-mono);
  font-size: 12px;
  border: 1px solid var(--sb-color-rule);
  border-radius: var(--sb-radius);
  color: var(--sb-color-ink);
  white-space: nowrap;
}

.sb-nav a:hover {
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
  border-color: var(--sb-color-accent);
}

/* ─── Sections ─── */

.sb-section {
  max-width: 960px;
  margin: 0 auto;
  padding: 56px var(--sb-pad);
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-section h2 {
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: var(--sb-color-muted);
  margin-bottom: 24px;
}

.sb-brief p {
  font-size: clamp(18px, 2.5vw, 24px);
  line-height: 1.45;
  max-width: 700px;
}

/* ─── Series lock ─── */

.sb-series-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 24px;
}

.sb-series-grid > div {
  border-left: 2px solid var(--sb-color-accent);
  padding-left: 14px;
}

.sb-series-grid dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 4px;
}

.sb-series-grid dd {
  font-size: 15px;
  line-height: 1.5;
}

/* ─── Shots ─── */

.sb-shots {
  background: var(--sb-color-bg);
}

.sb-shot {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: var(--sb-gap);
  padding: 40px 0;
  border-bottom: 1px solid var(--sb-color-rule);
  scroll-margin-top: 60px;
}

.sb-shot:last-child { border-bottom: none; }

.sb-shot-frame {
  position: relative;
  width: 100%;
  background: var(--sb-color-rule);
  border-radius: var(--sb-radius);
  overflow: hidden;
}

.sb-shot-frame.aspect-9-16 { aspect-ratio: 9 / 16; }
.sb-shot-frame.aspect-16-9 { aspect-ratio: 16 / 9; }
.sb-shot-frame.aspect-1-1  { aspect-ratio: 1 / 1; }
.sb-shot-frame.aspect-4-5  { aspect-ratio: 4 / 5; }
.sb-shot-frame.aspect-21-9 { aspect-ratio: 21 / 9; }

.sb-shot-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.sb-placeholder {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: linear-gradient(135deg, var(--sb-color-rule) 0%, var(--sb-color-bg) 100%);
  color: var(--sb-color-muted);
}

.sb-placeholder-id {
  font-family: var(--sb-font-mono);
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0.05em;
}

.sb-placeholder-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

/* On-screen text overlay preview (rendered over the frame) */
.sb-overlay {
  position: absolute;
  left: 0; right: 0;
  padding: 0 16px;
  pointer-events: none;
}

.sb-overlay-center        { top: 50%; transform: translateY(-50%); text-align: center; }
.sb-overlay-lower-third   { bottom: 12%; text-align: center; }
.sb-overlay-upper-third   { top: 12%; text-align: center; }
.sb-overlay-left-third    { top: 50%; transform: translateY(-50%); text-align: left; }
.sb-overlay-right-third   { top: 50%; transform: translateY(-50%); text-align: right; }

.sb-overlay-text {
  display: inline-block;
  font-size: clamp(14px, 2.2vw, 22px);
  line-height: 1.1;
  text-shadow: 0 2px 8px rgba(0,0,0,0.4);
}

/* ─── Shot body ─── */

.sb-shot-body { display: flex; flex-direction: column; gap: 20px; }

.sb-shot-header {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: baseline;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-shot-id {
  font-family: var(--sb-font-mono);
  font-size: 16px;
  font-weight: 700;
  color: var(--sb-color-accent);
}

.sb-shot-time {
  font-family: var(--sb-font-mono);
  font-size: 13px;
  color: var(--sb-color-muted);
}

.sb-shot-beat {
  font-size: 13px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-weight: 600;
  color: var(--sb-color-muted);
  margin-left: auto;
}

.sb-shot-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  font-size: 13px;
}

.sb-shot-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-shot-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-shot-meta dd { font-weight: 600; }

.sb-shot-subject h3,
.sb-shot-vo h3,
.sb-shot-text h3,
.sb-shot-rationale h3 {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 6px;
  font-weight: 600;
}

.sb-shot-subject p,
.sb-shot-vo p,
.sb-shot-rationale p {
  font-size: 15px;
  line-height: 1.55;
}

.sb-shot-vo p {
  font-style: italic;
  color: var(--sb-color-muted);
}

.sb-text-content {
  font-family: var(--sb-font-display);
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 4px;
}

.sb-text-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  color: var(--sb-color-muted);
}

.sb-shot-rationale {
  background: var(--sb-color-rule);
  padding: 14px 16px;
  border-radius: var(--sb-radius);
  border-left: 3px solid var(--sb-color-accent);
}

.sb-shot-rationale p {
  font-size: 14px;
  font-style: italic;
}

/* ─── Footer ─── */

.sb-footer {
  padding: 40px var(--sb-pad);
  background: var(--sb-color-rule);
  font-size: 12px;
  color: var(--sb-color-muted);
}

.sb-footer-inner {
  max-width: 960px;
  margin: 0 auto;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 16px;
}

/* ─── QA verdict ─── */

.sb-verdict {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
  border: 1px solid var(--sb-color-rule);
  border-radius: 2px;
  font-family: var(--sb-font-body);
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--sb-color-muted);
  white-space: nowrap;
}

.sb-verdict-accept { border-color: var(--sb-color-ink); color: var(--sb-color-ink); }
.sb-verdict-revise { border-color: var(--sb-color-accent); color: var(--sb-color-accent); }
.sb-verdict-reject {
  border-color: var(--sb-color-accent);
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
}

.sb-verdict-round { font-weight: 400; letter-spacing: 0.04em; opacity: 0.75; }

.sb-provenance {
  max-width: 960px;
  margin: 0 auto;
  font-size: 11px;
  line-height: 1.7;
  color: var(--sb-color-muted);
}

.sb-provenance code {
  font-size: 10px;
  word-break: break-all;
}

/* ─── Responsive ─── */

@media (max-width: 720px) {
  .sb-shot {
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 28px 0;
  }
  .sb-section { padding: 40px var(--sb-pad); }
  .sb-header { padding: 48px var(--sb-pad) 28px; }
}

/* ─── Print ─── */
@media print {
  /* ─── Page setup ─── */
  @page {
    size: letter;
    margin: 0.5in;
  }

  /* ─── Color & background ─── */
  body {
    background: white;
    color: black;
    font-size: 10pt;
    line-height: 1.4;
  }

  a {
    color: black;
    border-bottom: none;
  }

  a[href]::after {
    content: " (" attr(href) ")";
    font-family: var(--sb-font-mono);
    font-size: 8pt;
    color: #555;
  }

  /* Don't print sticky nav, JS controls, or footer scripts */
  .sb-nav { display: none; }

  /* ─── Header ─── */
  .sb-header {
    border-bottom: 2px solid black;
    padding: 0 0 16pt;
    margin-bottom: 24pt;
    page-break-after: avoid;
  }

  .sb-eyebrow {
    color: black;
    font-size: 9pt;
  }

  .sb-title {
    font-size: 24pt;
    margin-bottom: 12pt;
  }

  .sb-meta {
    grid-template-columns: repeat(4, 1fr);
    gap: 12pt;
    font-size: 9pt;
  }

  .sb-meta dt {
    color: #555;
    font-size: 7pt;
  }

  /* ─── Sections ─── */
  .sb-section {
    padding: 16pt 0;
    border-bottom: 1pt solid #999;
    page-break-inside: avoid;
  }

  .sb-section h2 {
    font-size: 9pt;
    margin-bottom: 12pt;
  }

  .sb-brief p {
    font-size: 12pt;
  }

  /* ─── Series lock ─── */
  .sb-series-grid {
    grid-template-columns: 1fr 1fr;
    gap: 12pt;
  }

  .sb-series-grid > div {
    border-left: 2pt solid black;
  }

  .sb-series-grid dt {
    color: #555;
    font-size: 7pt;
  }

  .sb-series-grid dd {
    font-size: 10pt;
  }

  /* ─── Shots, one shot per page ─── */
  .sb-shots h2 {
    page-break-after: avoid;
  }

  .sb-shot {
    page-break-inside: avoid;
    page-break-before: always;
    grid-template-columns: 1fr 1.2fr;
    gap: 18pt;
    padding: 18pt 0;
    border-bottom: none;
  }

  .sb-shot:first-of-type {
    page-break-before: avoid;
  }

  .sb-shot-frame {
    background: #f0f0f0;
    border: 1pt solid #999;
    border-radius: 0;
  }

  .sb-placeholder {
    background: #f5f5f5;
    color: #666;
  }

  .sb-overlay-text {
    text-shadow: none;
    background: rgba(255,255,255,0.85);
    padding: 2pt 6pt;
    color: black;
  }

  .sb-shot-id {
    color: black;
    font-size: 12pt;
  }

  .sb-shot-time, .sb-shot-beat {
    color: #555;
  }

  .sb-shot-rationale {
    background: #f5f5f5;
    border-left: 2pt solid black;
    padding: 8pt 10pt;
    page-break-inside: avoid;
  }

  .sb-shot-rationale p {
    font-size: 9pt;
  }

  .sb-shot-meta dt,
  .sb-shot-subject h3,
  .sb-shot-vo h3,
  .sb-shot-text h3,
  .sb-shot-rationale h3 {
    color: #555;
    font-size: 7pt;
  }

  .sb-shot-subject p,
  .sb-shot-vo p {
    font-size: 9.5pt;
  }

  /* ─── Footer ─── */
  .sb-footer {
    background: white;
    border-top: 1pt solid #999;
    padding: 12pt 0;
    font-size: 8pt;
    page-break-before: always;
  }

  .sb-footer-inner {
    flex-direction: column;
    gap: 4pt;
  }
}


</style>
</head>
<body>

<header class="sb-header">
  <div class="sb-header-inner">
    <div class="sb-eyebrow">Storyboard · shots 1.0</div>
    <h1 class="sb-title">WhyStrohm. The Content Infrastructure Pitch</h1>
    <dl class="sb-meta">
      <div><dt>Duration</dt><dd>30s</dd></div>
      <div><dt>Aspect</dt><dd>9:16</dd></div>
      <div><dt>Framework</dt><dd>pain-reframe-promise</dd></div>
      <div><dt>Run</dt><dd>2026-05-07T14:23:00Z</dd></div>
    </dl>
  </div>
</header>

<nav class="sb-nav" aria-label="Shot navigation">
  <ul>
    
    <li><a href="#shot_01">01</a></li>
    
    <li><a href="#shot_02">02</a></li>
    
    <li><a href="#shot_03">03</a></li>
    
    <li><a href="#shot_04">04</a></li>
    
    <li><a href="#shot_05">05</a></li>
    
    <li><a href="#shot_06">06</a></li>
    
    <li><a href="#shot_07">07</a></li>
    
  </ul>
</nav>



<section class="sb-section sb-series-lock">
  <h2>Series lock</h2>
  <dl class="sb-series-grid">
    <div>
      <dt>Character</dt>
      <dd>founder, mid-thirties, salt-and-pepper hair, navy crewneck, calm posture, working at laptop</dd>
    </div>
    <div>
      <dt>Environment</dt>
      <dd>minimalist home office, white walls, oak desk, single houseplant, no decor clutter</dd>
    </div>
    <div>
      <dt>Lighting</dt>
      <dd>soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff</dd>
    </div>
    <div>
      <dt>Color grade</dt>
      <dd>warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed</dd>
    </div>
  </dl>
</section>

<section class="sb-section sb-shots">
  <h2>Shots</h2>
  
  <article class="sb-shot" id="shot_01">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">01</div>
        <div class="sb-placeholder-meta">MCU · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">Your content feels random.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">01</span>
        <span class="sb-shot-time">0.0–2.0s</span>
        <span class="sb-shot-beat">hook</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, mid-thirties, salt-and-pepper hair, navy crewneck, looking directly into camera, neutral expression, slightly tired</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Your content feels random."</p>
        <p class="sb-text-meta">text_01 · display · lower-third · enter 0.4s (hard-cut) · exit 2.0s (hard-cut)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Cold open, direct eye contact establishes parasocial trust. Static framing keeps the hook simple, text does the work.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_02">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">02</div>
        <div class="sb-placeholder-meta">MS · high · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-right-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">Posting more isn&#x27;t fixing it.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">02</span>
        <span class="sb-shot-time">2.0–7.0s</span>
        <span class="sb-shot-beat">pain</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>high</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder at laptop, scrolling social feed, content tiles glowing on screen, slight slump in shoulders, mug of coffee mid-distance</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Posting more isn&#x27;t fixing it."</p>
        <p class="sb-text-meta">text_02 · headline · right-third · enter 2.4s (fade-in) · exit 6.8s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>High angle subtly diminishes the subject, pain beat. Deep DOF keeps the messy social feed legible. Subject left-weighted, text reserves right two-thirds.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_03">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">03</div>
        <div class="sb-placeholder-meta">ECU · eye-level · static</div>
      </div>
      

      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">03</span>
        <span class="sb-shot-time">7.0–11.0s</span>
        <span class="sb-shot-beat">pain</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>ECU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>close on founder&#x27;s hand hovering over laptop trackpad, frozen, not moving</p>
      </div>

      

      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Hand frozen above trackpad is the visual symbol of decision paralysis. Wordless beat, let the image carry the pain before the reframe.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_04">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">04</div>
        <div class="sb-placeholder-meta">MCU · eye-level · push</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-center">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #D94F3A;">You don&#x27;t have a content problem.
You have an infrastructure problem.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">04</span>
        <span class="sb-shot-time">11.0–16.0s</span>
        <span class="sb-shot-beat">reframe</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>push</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, same posture, looking at camera, expression shifts from tired to clear, small almost-smile</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"You don&#x27;t have a content problem.
You have an infrastructure problem."</p>
        <p class="sb-text-meta">text_03 · headline · center · enter 11.5s (type-on) · exit 15.8s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Slow push as the reframe lands. Same character, same environment, only the expression changes. The change is the point.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_05">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">05</div>
        <div class="sb-placeholder-meta">MS · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-upper-third">
        <span class="sb-overlay-text" style="font-family: Inter Medium 500; font-weight: medium; color: #2A2A32;">Voice extracted. Brand locked. System runs.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">05</span>
        <span class="sb-shot-time">16.0–20.0s</span>
        <span class="sb-shot-beat">proof</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder gestures toward laptop screen, kanban-style content pipeline visible, organized columns, clean structure</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Voice extracted. Brand locked. System runs."</p>
        <p class="sb-text-meta">text_04 · body · upper-third · enter 16.4s (slide-up) · exit 19.8s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Proof beat, show the system, not the result. The kanban metaphor is recognizable to operators. Subject right-weighted, text upper-third.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_06">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">06</div>
        <div class="sb-placeholder-meta">MCU · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">30 minutes a week.
48-hour content cycles.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">06</span>
        <span class="sb-shot-time">20.0–26.0s</span>
        <span class="sb-shot-beat">promise</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, calm composed posture, fully present, slight smile, hands folded on desk</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"30 minutes a week.
48-hour content cycles."</p>
        <p class="sb-text-meta">text_05 · headline · lower-third · enter 20.5s (type-on) · exit 25.8s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Promise beat, the after-state is the same person, just calmer. Static frame holds the moment. Text carries the specific commitment.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_07">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">07</div>
        <div class="sb-placeholder-meta">MS · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #D94F3A;">whystrohm.com/scan</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">07</span>
        <span class="sb-shot-time">26.0–30.0s</span>
        <span class="sb-shot-beat">cta</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, neutral posture, room visible behind, calm presence, gentle eye contact with camera</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"whystrohm.com/scan"</p>
        <p class="sb-text-meta">text_06 · headline · lower-third · enter 26.4s (type-on) · exit 29.8s (hard-cut)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>CTA beat. Pulled out to MS to give text the breathing room. Subject centered, text lower-third with URL. No motion, let it land.</p>
      </div>
    </div>
  </article>
  
</section>

<footer class="sb-footer">
  <div class="sb-footer-inner">
    <div>
      Built against <a href="brand-lock.snapshot.md"><code>brand-lock.snapshot.md</code></a> (<code>f364bc71f68d</code>).
    </div>
    <div>Built with <a href="https://github.com/whystrohm/shotkit">shotkit</a> · WhyStrohm</div>
  </div>
  <div class="sb-footer-inner sb-provenance">
    <div>
      Run 20260507T142300Z-4b8f5796 started 2026-05-07T14:23:00Z. This page rendered 2026-05-07T14:23:00Z.
      
    </div>
  </div>
</footer>

<script>
// Keyboard navigation: arrow keys move between shots
(function() {
  const shots = Array.from(document.querySelectorAll('.sb-shot'));
  if (!shots.length) return;

  function shotInView() {
    const mid = window.innerHeight / 2;
    let best = 0;
    let bestDist = Infinity;
    shots.forEach((shot, i) => {
      const rect = shot.getBoundingClientRect();
      const dist = Math.abs(rect.top + rect.height / 2 - mid);
      if (dist < bestDist) { bestDist = dist; best = i; }
    });
    return best;
  }

  document.addEventListener('keydown', function(e) {
    if (e.target.matches('input, textarea')) return;
    const i = shotInView();
    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      const next = shots[Math.min(shots.length - 1, i + 1)];
      next.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      const prev = shots[Math.max(0, i - 1)];
      prev.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
})();
</script>

</body>
</html>

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/30s-pain-proof-promise/preview.html -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/30s-pain-proof-promise/run.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/30s-pain-proof-promise/run.json`

{
  "version": "1.0",
  "run_id": "20260507T142300Z-4b8f5796",
  "created_at": "2026-05-07T14:23:00Z",
  "shotkit_version": "3.0.0",
  "operator": null,
  "project": {
    "title": "WhyStrohm. The Content Infrastructure Pitch",
    "duration_s": 30,
    "aspect": "9:16",
    "framework": "pain-reframe-promise"
  },
  "inputs": {
    "shots_ref": "shots.json",
    "shots_sha256": "a94ec63c2dd16b887bebcbceeb7b0fe184543a7e913cfc8168a3dc8d21d4c5c2",
    "text_overlays_ref": "text-overlays.json",
    "text_overlays_sha256": "0ccd9ec3750129893680db615862a9c0c7280d6794d89cf5856bc0555a2c20a6",
    "brand_lock_ref": "brand-lock.snapshot.md",
    "brand_lock_sha256": "f364bc71f68d16187d0721fbc092450174545e247f2f563a4c45686b4a877f50",
    "brand_lock_source": "brand-packs/whystrohm.md",
    "brand_lock_configured": true
  },
  "rounds": []
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/30s-pain-proof-promise/run.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/30s-pain-proof-promise/shots.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/30s-pain-proof-promise/shots.json`

{
  "version": "1.0",
  "project": {
    "title": "WhyStrohm. The Content Infrastructure Pitch",
    "duration_s": 30,
    "aspect": "9:16",
    "framework": "pain-reframe-promise"
  },
  "brand_lock_ref": "brand-lock.snapshot.md",
  "series_lock": {
    "character": "founder, mid-thirties, salt-and-pepper hair, navy crewneck, calm posture, working at laptop",
    "environment": "minimalist home office, white walls, oak desk, single houseplant, no decor clutter",
    "lighting": "soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff",
    "color_grade": "warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed"
  },
  "shots": [
    {
      "id": "shot_01",
      "beat": "hook",
      "start": 0.0,
      "end": 2.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "founder, mid-thirties, salt-and-pepper hair, navy crewneck, looking directly into camera, neutral expression, slightly tired",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_01",
      "vo": null,
      "rationale": "Cold open, direct eye contact establishes parasocial trust. Static framing keeps the hook simple, text does the work."
    },
    {
      "id": "shot_02",
      "beat": "pain",
      "start": 2.0,
      "end": 7.0,
      "framing": "MS",
      "angle": "high",
      "motion": "static",
      "depth_of_field": "deep",
      "subject": "founder at laptop, scrolling social feed, content tiles glowing on screen, slight slump in shoulders, mug of coffee mid-distance",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_02",
      "vo": null,
      "rationale": "High angle subtly diminishes the subject, pain beat. Deep DOF keeps the messy social feed legible. Subject left-weighted, text reserves right two-thirds."
    },
    {
      "id": "shot_03",
      "beat": "pain",
      "start": 7.0,
      "end": 11.0,
      "framing": "ECU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "close on founder's hand hovering over laptop trackpad, frozen, not moving",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": null,
      "vo": null,
      "rationale": "Hand frozen above trackpad is the visual symbol of decision paralysis. Wordless beat, let the image carry the pain before the reframe."
    },
    {
      "id": "shot_04",
      "beat": "reframe",
      "start": 11.0,
      "end": 16.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "push",
      "depth_of_field": "shallow",
      "subject": "founder, same posture, looking at camera, expression shifts from tired to clear, small almost-smile",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_03",
      "vo": null,
      "rationale": "Slow push as the reframe lands. Same character, same environment, only the expression changes. The change is the point."
    },
    {
      "id": "shot_05",
      "beat": "proof",
      "start": 16.0,
      "end": 20.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "deep",
      "subject": "founder gestures toward laptop screen, kanban-style content pipeline visible, organized columns, clean structure",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_04",
      "vo": null,
      "rationale": "Proof beat, show the system, not the result. The kanban metaphor is recognizable to operators. Subject right-weighted, text upper-third."
    },
    {
      "id": "shot_06",
      "beat": "promise",
      "start": 20.0,
      "end": 26.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "founder, calm composed posture, fully present, slight smile, hands folded on desk",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_05",
      "vo": null,
      "rationale": "Promise beat, the after-state is the same person, just calmer. Static frame holds the moment. Text carries the specific commitment."
    },
    {
      "id": "shot_07",
      "beat": "cta",
      "start": 26.0,
      "end": 30.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "deep",
      "subject": "founder, neutral posture, room visible behind, calm presence, gentle eye contact with camera",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_06",
      "vo": null,
      "rationale": "CTA beat. Pulled out to MS to give text the breathing room. Subject centered, text lower-third with URL. No motion, let it land."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/30s-pain-proof-promise/shots.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/30s-pain-proof-promise/storyboard.md -->
# SOURCE FILE: `skills/storyboard-architect/examples/30s-pain-proof-promise/storyboard.md`

# WhyStrohm. The Content Infrastructure Pitch

| | |
|---|---|
| **Duration** | 30s |
| **Aspect** | 9:16 |
| **Beat framework** | Pain-Reframe-Promise |
| **Brand lock** | [`brand-lock.snapshot.md`](./brand-lock.snapshot.md) |
| **Generated** | 2026-05-07 14:23 UTC |

---

## Brief

A 30-second founder explainer aimed at founders running content marketing themselves. The audience knows their content output is uneven and they're tired of the treadmill. The reframe is the WhyStrohm thesis: it's not a content problem, it's an infrastructure problem. The promise is the offer, 30 min/week of founder time, 48-hour cycle. The CTA is the free /scan diagnostic.

## Beat framework: Pain-Reframe-Promise

Standard PRP for conversion content. Three beats with hook and CTA bookending.

- 0–2s. Hook
- 2–11s. Pain (extended for 30s, gives the problem space to breathe)
- 11–20s. Reframe + Proof (the WhyStrohm thesis lands, then is shown)
- 20–26s. Promise (specific, time-bound)
- 26–30s. CTA

## Series lock

| | |
|---|---|
| **Character anchor** | founder, mid-thirties, salt-and-pepper hair, navy crewneck, calm posture, working at laptop |
| **Environment** | minimalist home office, white walls, oak desk, single houseplant, no decor clutter |
| **Lighting** | soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff |
| **Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed |

---

## Shots

### shot_01 · 0.0–2.0s · MCU · static

**Beat:** hook

**Subject:** founder, mid-thirties, salt-and-pepper hair, navy crewneck, looking directly into camera, neutral expression, slightly tired

**On-screen text:** "Your content feels random." (Inter Black 900, lower-third, hard cut at 0.4s)

**Rationale:** Cold open, direct eye contact establishes parasocial trust. Static framing keeps the hook simple, text does the work.

---

### shot_02 · 2.0–7.0s · MS · static

**Beat:** pain

**Subject:** founder at laptop, scrolling social feed, content tiles glowing on screen, slight slump in shoulders, mug of coffee mid-distance

**On-screen text:** "Posting more isn't fixing it." (Inter Black 900, right-third, fade-in at 2.4s)

**Rationale:** High angle subtly diminishes the subject, pain beat. Deep DOF keeps the messy social feed legible. Subject left-weighted, text reserves right two-thirds.

---

### shot_03 · 7.0–11.0s · ECU · static

**Beat:** pain

**Subject:** close on founder's hand hovering over laptop trackpad, frozen, not moving

**On-screen text:** none

**Rationale:** Hand frozen above trackpad is the visual symbol of decision paralysis. Wordless beat, let the image carry the pain before the reframe.

---

### shot_04 · 11.0–16.0s · MCU · push

**Beat:** reframe

**Subject:** founder, same posture, looking at camera, expression shifts from tired to clear, small almost-smile

**On-screen text:** "You don't have a content problem. / You have an infrastructure problem." (Inter Black 900, coral, center, type-on at 11.5s)

**Rationale:** Slow push as the reframe lands. Same character, same environment, only the expression changes. The change is the point.

---

### shot_05 · 16.0–20.0s · MS · static

**Beat:** proof

**Subject:** founder gestures toward laptop screen, kanban-style content pipeline visible, organized columns, clean structure

**On-screen text:** "Voice extracted. Brand locked. System runs." (Inter Medium 500, upper-third, slide-up at 16.4s)

**Rationale:** Proof beat, show the system, not the result. The kanban metaphor is recognizable to operators. Subject right-weighted, text upper-third.

---

### shot_06 · 20.0–26.0s · MCU · static

**Beat:** promise

**Subject:** founder, calm composed posture, fully present, slight smile, hands folded on desk

**On-screen text:** "30 minutes a week. / 48-hour content cycles." (Inter Black 900, lower-third, type-on at 20.5s)

**Rationale:** Promise beat, the after-state is the same person, just calmer. Static frame holds the moment. Text carries the specific commitment.

---

### shot_07 · 26.0–30.0s · MS · static

**Beat:** cta

**Subject:** founder, neutral posture, room visible behind, calm presence, gentle eye contact with camera

**On-screen text:** "whystrohm.com/scan" (Inter Black 900, coral, lower-third, type-on at 26.4s)

**Rationale:** CTA beat. Pulled out to MS to give text the breathing room. Subject centered, text lower-third with URL. No motion, let it land.

---

## Handoff notes

- **For image generation:** run `visual-prompt-forge` against `shots.json`
- **For HTML preview:** run `storyboard-html-preview` against this folder
- **For QA on generated frames:** run `visual-asset-critic` with the generated image and the shot ID

## Audit trail

This storyboard was generated against `brand-lock.snapshot.md` (frozen at 2026-05-07T14:23:00Z, source `brand-packs/whystrohm.md`). If the brand-lock changes after this date, re-run to pick up the new state.

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/30s-pain-proof-promise/storyboard.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/30s-pain-proof-promise/text-overlays.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/30s-pain-proof-promise/text-overlays.json`

{
  "version": "1.0",
  "overlays": [
    {
      "id": "text_01",
      "shot_id": "shot_01",
      "content": "Your content feels random.",
      "font": "Inter Black 900",
      "size": "display",
      "weight": "black",
      "color": "#2A2A32",
      "position": "lower-third",
      "enter": { "at": 0.4, "animation": "hard-cut" },
      "exit": { "at": 2.0, "animation": "hard-cut" }
    },
    {
      "id": "text_02",
      "shot_id": "shot_02",
      "content": "Posting more isn't fixing it.",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#2A2A32",
      "position": "right-third",
      "enter": { "at": 2.4, "animation": "fade-in" },
      "exit": { "at": 6.8, "animation": "fade-out" }
    },
    {
      "id": "text_03",
      "shot_id": "shot_04",
      "content": "You don't have a content problem.\nYou have an infrastructure problem.",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#D94F3A",
      "position": "center",
      "enter": { "at": 11.5, "animation": "type-on" },
      "exit": { "at": 15.8, "animation": "fade-out" }
    },
    {
      "id": "text_04",
      "shot_id": "shot_05",
      "content": "Voice extracted. Brand locked. System runs.",
      "font": "Inter Medium 500",
      "size": "body",
      "weight": "medium",
      "color": "#2A2A32",
      "position": "upper-third",
      "enter": { "at": 16.4, "animation": "slide-up" },
      "exit": { "at": 19.8, "animation": "fade-out" }
    },
    {
      "id": "text_05",
      "shot_id": "shot_06",
      "content": "30 minutes a week.\n48-hour content cycles.",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#2A2A32",
      "position": "lower-third",
      "enter": { "at": 20.5, "animation": "type-on" },
      "exit": { "at": 25.8, "animation": "fade-out" }
    },
    {
      "id": "text_06",
      "shot_id": "shot_07",
      "content": "whystrohm.com/scan",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#D94F3A",
      "position": "lower-third",
      "enter": { "at": 26.4, "animation": "type-on" },
      "exit": { "at": 29.8, "animation": "hard-cut" }
    }
  ]
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/30s-pain-proof-promise/text-overlays.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md -->
# SOURCE FILE: `skills/storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md`

<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->

# Brand Lock: WhyStrohm

## Identity

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#F5F0E8` | Cream, primary canvas |
| Ink | `#2A2A32` | Near-black, primary text and dark elements |
| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |
| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |
| Muted | `#7A7580` | Secondary text, captions |
| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

## Typography

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

## Mood adjectives

- operator (not creator)
- considered (not reactive)
- deterministic (not vibes-based)
- confident (without volume)
- defense-grade (not fragile)

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate the cream background
- never use coral as a flood color (only as accent or signature periods)
- never use em dashes in copy
- never use emojis in body copy
- never use bullet points in narrative copy
- never use clip-art or generic icon sets
- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- never use exclamation points in headlines
- never default to dark mode, light mode hybrid is the brand
- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

## Aspect ratios

- 9:16, primary for short-form social
- 16:9, long-form, hero films, web embeds
- 1:1, feed posts, podcast covers
- 4:5. Instagram feed alternative

## Color grade direction

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

## Motion language

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

## Voice rules

- no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no hype words
- prefer specific numbers over vague claims
- prefer present-tense over future-tense
- prefer "operator" over "creator", "infrastructure" over "agency"

---

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/60s-founder-explainer/preview.html -->
# SOURCE FILE: `skills/storyboard-architect/examples/60s-founder-explainer/preview.html`

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="generator" content="storyboard-html-preview / WhyStrohm">
<title>WhyStrohm. How The System Actually Works · Storyboard</title>
<style>
/* ─────────────────────────────────────────────────────────────
   Storyboard HTML Preview · WhyStrohm
   Single-file output. No external deps. Prints clean.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Brand-lock variables, get substituted at compose time */
  --sb-color-bg: #F5F0E8;
  --sb-color-ink: #2A2A32;
  --sb-color-accent: #D94F3A;
  --sb-color-muted: #7A7580;
  --sb-color-rule: #E8E1D4;

  --sb-font-display: Inter Black 900, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-body: Inter Medium 500, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;

  --sb-radius: 6px;
  --sb-pad: 24px;
  --sb-gap: 32px;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; }

body {
  font-family: var(--sb-font-body);
  font-size: 16px;
  line-height: 1.55;
  color: var(--sb-color-ink);
  background: var(--sb-color-bg);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

a {
  color: var(--sb-color-accent);
  text-decoration: none;
  border-bottom: 1px solid currentColor;
}

code {
  font-family: var(--sb-font-mono);
  font-size: 0.9em;
  background: var(--sb-color-rule);
  padding: 1px 6px;
  border-radius: 3px;
}

h1, h2, h3 {
  font-family: var(--sb-font-display);
  font-weight: 800;
  line-height: 1.15;
  letter-spacing: -0.01em;
}

/* ─── Header ─── */

.sb-header {
  border-bottom: 1px solid var(--sb-color-rule);
  padding: 64px var(--sb-pad) 40px;
}

.sb-header-inner {
  max-width: 960px;
  margin: 0 auto;
}

.sb-eyebrow {
  font-family: var(--sb-font-mono);
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 16px;
}

.sb-title {
  font-size: clamp(32px, 5vw, 56px);
  margin-bottom: 32px;
}

.sb-meta {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 16px;
  font-size: 14px;
}
.sb-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-meta dd { font-weight: 600; }

/* ─── Nav ─── */

.sb-nav {
  position: sticky;
  top: 0;
  background: var(--sb-color-bg);
  border-bottom: 1px solid var(--sb-color-rule);
  z-index: 10;
  overflow-x: auto;
}

.sb-nav ul {
  display: flex;
  gap: 4px;
  list-style: none;
  max-width: 960px;
  margin: 0 auto;
  padding: 12px var(--sb-pad);
}

.sb-nav a {
  display: inline-block;
  padding: 4px 10px;
  font-family: var(--sb-font-mono);
  font-size: 12px;
  border: 1px solid var(--sb-color-rule);
  border-radius: var(--sb-radius);
  color: var(--sb-color-ink);
  white-space: nowrap;
}

.sb-nav a:hover {
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
  border-color: var(--sb-color-accent);
}

/* ─── Sections ─── */

.sb-section {
  max-width: 960px;
  margin: 0 auto;
  padding: 56px var(--sb-pad);
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-section h2 {
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: var(--sb-color-muted);
  margin-bottom: 24px;
}

.sb-brief p {
  font-size: clamp(18px, 2.5vw, 24px);
  line-height: 1.45;
  max-width: 700px;
}

/* ─── Series lock ─── */

.sb-series-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 24px;
}

.sb-series-grid > div {
  border-left: 2px solid var(--sb-color-accent);
  padding-left: 14px;
}

.sb-series-grid dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 4px;
}

.sb-series-grid dd {
  font-size: 15px;
  line-height: 1.5;
}

/* ─── Shots ─── */

.sb-shots {
  background: var(--sb-color-bg);
}

.sb-shot {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: var(--sb-gap);
  padding: 40px 0;
  border-bottom: 1px solid var(--sb-color-rule);
  scroll-margin-top: 60px;
}

.sb-shot:last-child { border-bottom: none; }

.sb-shot-frame {
  position: relative;
  width: 100%;
  background: var(--sb-color-rule);
  border-radius: var(--sb-radius);
  overflow: hidden;
}

.sb-shot-frame.aspect-9-16 { aspect-ratio: 9 / 16; }
.sb-shot-frame.aspect-16-9 { aspect-ratio: 16 / 9; }
.sb-shot-frame.aspect-1-1  { aspect-ratio: 1 / 1; }
.sb-shot-frame.aspect-4-5  { aspect-ratio: 4 / 5; }
.sb-shot-frame.aspect-21-9 { aspect-ratio: 21 / 9; }

.sb-shot-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.sb-placeholder {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: linear-gradient(135deg, var(--sb-color-rule) 0%, var(--sb-color-bg) 100%);
  color: var(--sb-color-muted);
}

.sb-placeholder-id {
  font-family: var(--sb-font-mono);
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0.05em;
}

.sb-placeholder-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

/* On-screen text overlay preview (rendered over the frame) */
.sb-overlay {
  position: absolute;
  left: 0; right: 0;
  padding: 0 16px;
  pointer-events: none;
}

.sb-overlay-center        { top: 50%; transform: translateY(-50%); text-align: center; }
.sb-overlay-lower-third   { bottom: 12%; text-align: center; }
.sb-overlay-upper-third   { top: 12%; text-align: center; }
.sb-overlay-left-third    { top: 50%; transform: translateY(-50%); text-align: left; }
.sb-overlay-right-third   { top: 50%; transform: translateY(-50%); text-align: right; }

.sb-overlay-text {
  display: inline-block;
  font-size: clamp(14px, 2.2vw, 22px);
  line-height: 1.1;
  text-shadow: 0 2px 8px rgba(0,0,0,0.4);
}

/* ─── Shot body ─── */

.sb-shot-body { display: flex; flex-direction: column; gap: 20px; }

.sb-shot-header {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: baseline;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-shot-id {
  font-family: var(--sb-font-mono);
  font-size: 16px;
  font-weight: 700;
  color: var(--sb-color-accent);
}

.sb-shot-time {
  font-family: var(--sb-font-mono);
  font-size: 13px;
  color: var(--sb-color-muted);
}

.sb-shot-beat {
  font-size: 13px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-weight: 600;
  color: var(--sb-color-muted);
  margin-left: auto;
}

.sb-shot-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  font-size: 13px;
}

.sb-shot-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-shot-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-shot-meta dd { font-weight: 600; }

.sb-shot-subject h3,
.sb-shot-vo h3,
.sb-shot-text h3,
.sb-shot-rationale h3 {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 6px;
  font-weight: 600;
}

.sb-shot-subject p,
.sb-shot-vo p,
.sb-shot-rationale p {
  font-size: 15px;
  line-height: 1.55;
}

.sb-shot-vo p {
  font-style: italic;
  color: var(--sb-color-muted);
}

.sb-text-content {
  font-family: var(--sb-font-display);
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 4px;
}

.sb-text-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  color: var(--sb-color-muted);
}

.sb-shot-rationale {
  background: var(--sb-color-rule);
  padding: 14px 16px;
  border-radius: var(--sb-radius);
  border-left: 3px solid var(--sb-color-accent);
}

.sb-shot-rationale p {
  font-size: 14px;
  font-style: italic;
}

/* ─── Footer ─── */

.sb-footer {
  padding: 40px var(--sb-pad);
  background: var(--sb-color-rule);
  font-size: 12px;
  color: var(--sb-color-muted);
}

.sb-footer-inner {
  max-width: 960px;
  margin: 0 auto;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 16px;
}

/* ─── QA verdict ─── */

.sb-verdict {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
  border: 1px solid var(--sb-color-rule);
  border-radius: 2px;
  font-family: var(--sb-font-body);
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--sb-color-muted);
  white-space: nowrap;
}

.sb-verdict-accept { border-color: var(--sb-color-ink); color: var(--sb-color-ink); }
.sb-verdict-revise { border-color: var(--sb-color-accent); color: var(--sb-color-accent); }
.sb-verdict-reject {
  border-color: var(--sb-color-accent);
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
}

.sb-verdict-round { font-weight: 400; letter-spacing: 0.04em; opacity: 0.75; }

.sb-provenance {
  max-width: 960px;
  margin: 0 auto;
  font-size: 11px;
  line-height: 1.7;
  color: var(--sb-color-muted);
}

.sb-provenance code {
  font-size: 10px;
  word-break: break-all;
}

/* ─── Responsive ─── */

@media (max-width: 720px) {
  .sb-shot {
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 28px 0;
  }
  .sb-section { padding: 40px var(--sb-pad); }
  .sb-header { padding: 48px var(--sb-pad) 28px; }
}

/* ─── Print ─── */
@media print {
  /* ─── Page setup ─── */
  @page {
    size: letter;
    margin: 0.5in;
  }

  /* ─── Color & background ─── */
  body {
    background: white;
    color: black;
    font-size: 10pt;
    line-height: 1.4;
  }

  a {
    color: black;
    border-bottom: none;
  }

  a[href]::after {
    content: " (" attr(href) ")";
    font-family: var(--sb-font-mono);
    font-size: 8pt;
    color: #555;
  }

  /* Don't print sticky nav, JS controls, or footer scripts */
  .sb-nav { display: none; }

  /* ─── Header ─── */
  .sb-header {
    border-bottom: 2px solid black;
    padding: 0 0 16pt;
    margin-bottom: 24pt;
    page-break-after: avoid;
  }

  .sb-eyebrow {
    color: black;
    font-size: 9pt;
  }

  .sb-title {
    font-size: 24pt;
    margin-bottom: 12pt;
  }

  .sb-meta {
    grid-template-columns: repeat(4, 1fr);
    gap: 12pt;
    font-size: 9pt;
  }

  .sb-meta dt {
    color: #555;
    font-size: 7pt;
  }

  /* ─── Sections ─── */
  .sb-section {
    padding: 16pt 0;
    border-bottom: 1pt solid #999;
    page-break-inside: avoid;
  }

  .sb-section h2 {
    font-size: 9pt;
    margin-bottom: 12pt;
  }

  .sb-brief p {
    font-size: 12pt;
  }

  /* ─── Series lock ─── */
  .sb-series-grid {
    grid-template-columns: 1fr 1fr;
    gap: 12pt;
  }

  .sb-series-grid > div {
    border-left: 2pt solid black;
  }

  .sb-series-grid dt {
    color: #555;
    font-size: 7pt;
  }

  .sb-series-grid dd {
    font-size: 10pt;
  }

  /* ─── Shots, one shot per page ─── */
  .sb-shots h2 {
    page-break-after: avoid;
  }

  .sb-shot {
    page-break-inside: avoid;
    page-break-before: always;
    grid-template-columns: 1fr 1.2fr;
    gap: 18pt;
    padding: 18pt 0;
    border-bottom: none;
  }

  .sb-shot:first-of-type {
    page-break-before: avoid;
  }

  .sb-shot-frame {
    background: #f0f0f0;
    border: 1pt solid #999;
    border-radius: 0;
  }

  .sb-placeholder {
    background: #f5f5f5;
    color: #666;
  }

  .sb-overlay-text {
    text-shadow: none;
    background: rgba(255,255,255,0.85);
    padding: 2pt 6pt;
    color: black;
  }

  .sb-shot-id {
    color: black;
    font-size: 12pt;
  }

  .sb-shot-time, .sb-shot-beat {
    color: #555;
  }

  .sb-shot-rationale {
    background: #f5f5f5;
    border-left: 2pt solid black;
    padding: 8pt 10pt;
    page-break-inside: avoid;
  }

  .sb-shot-rationale p {
    font-size: 9pt;
  }

  .sb-shot-meta dt,
  .sb-shot-subject h3,
  .sb-shot-vo h3,
  .sb-shot-text h3,
  .sb-shot-rationale h3 {
    color: #555;
    font-size: 7pt;
  }

  .sb-shot-subject p,
  .sb-shot-vo p {
    font-size: 9.5pt;
  }

  /* ─── Footer ─── */
  .sb-footer {
    background: white;
    border-top: 1pt solid #999;
    padding: 12pt 0;
    font-size: 8pt;
    page-break-before: always;
  }

  .sb-footer-inner {
    flex-direction: column;
    gap: 4pt;
  }
}


</style>
</head>
<body>

<header class="sb-header">
  <div class="sb-header-inner">
    <div class="sb-eyebrow">Storyboard · shots 1.0</div>
    <h1 class="sb-title">WhyStrohm. How The System Actually Works</h1>
    <dl class="sb-meta">
      <div><dt>Duration</dt><dd>60s</dd></div>
      <div><dt>Aspect</dt><dd>9:16</dd></div>
      <div><dt>Framework</dt><dd>founder-explainer</dd></div>
      <div><dt>Run</dt><dd>2026-05-07T14:23:00Z</dd></div>
    </dl>
  </div>
</header>

<nav class="sb-nav" aria-label="Shot navigation">
  <ul>
    
    <li><a href="#shot_01">01</a></li>
    
    <li><a href="#shot_02">02</a></li>
    
    <li><a href="#shot_03">03</a></li>
    
    <li><a href="#shot_04">04</a></li>
    
    <li><a href="#shot_05">05</a></li>
    
    <li><a href="#shot_06">06</a></li>
    
    <li><a href="#shot_07">07</a></li>
    
    <li><a href="#shot_08">08</a></li>
    
  </ul>
</nav>



<section class="sb-section sb-series-lock">
  <h2>Series lock</h2>
  <dl class="sb-series-grid">
    <div>
      <dt>Character</dt>
      <dd>founder, mid-thirties, salt-and-pepper hair, navy crewneck, speaking directly to camera, calm authoritative posture</dd>
    </div>
    <div>
      <dt>Environment</dt>
      <dd>minimalist home office, white walls, oak desk, single houseplant, late afternoon</dd>
    </div>
    <div>
      <dt>Lighting</dt>
      <dd>soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff</dd>
    </div>
    <div>
      <dt>Color grade</dt>
      <dd>warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed</dd>
    </div>
  </dl>
</section>

<section class="sb-section sb-shots">
  <h2>Shots</h2>
  
  <article class="sb-shot" id="shot_01">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">01</div>
        <div class="sb-placeholder-meta">MCU · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">Most founders treat content like a hobby.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">01</span>
        <span class="sb-shot-time">0.0–2.0s</span>
        <span class="sb-shot-beat">hook</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, looking directly into camera, slight knowing smile, mid-statement</p>
      </div>

      
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"Most founders treat content like a hobby."</p>
      </div>
      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Most founders treat content like a hobby."</p>
        <p class="sb-text-meta">text_01 · headline · lower-third · enter 0.4s (hard-cut) · exit 1.9s (hard-cut)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Hook is provocative but calm, voice carries the bite. Direct eye contact, MCU lock-in.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_02">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">02</div>
        <div class="sb-placeholder-meta">MS · eye-level · static</div>
      </div>
      

      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">02</span>
        <span class="sb-shot-time">2.0–8.0s</span>
        <span class="sb-shot-beat">stakes</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, gesturing slightly with one hand, explaining, eye contact maintained</p>
      </div>

      
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"Then they wonder why every post feels like starting over. New idea, new angle, no compounding."</p>
      </div>
      

      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Stakes beat. Pulled out to MS to let the gesture read. VO does the work, no on-screen text needed.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_03">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">03</div>
        <div class="sb-placeholder-meta">ECU · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #D94F3A;">It&#x27;s missing infrastructure.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">03</span>
        <span class="sb-shot-time">8.0–14.0s</span>
        <span class="sb-shot-beat">stakes</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>ECU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>close on founder&#x27;s eyes, considered expression, slight head tilt</p>
      </div>

      
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"It&#x27;s not creativity. It&#x27;s missing infrastructure."</p>
      </div>
      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"It&#x27;s missing infrastructure."</p>
        <p class="sb-text-meta">text_02 · headline · lower-third · enter 9.0s (type-on) · exit 13.8s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>ECU pulls the audience into the realization moment. Text reinforces the line that needs to land.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_04">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">04</div>
        <div class="sb-placeholder-meta">MCU · eye-level · push</div>
      </div>
      

      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">04</span>
        <span class="sb-shot-time">14.0–24.0s</span>
        <span class="sb-shot-beat">insight</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>push</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, leaning slightly forward, more energy in delivery, hands resting on desk</p>
      </div>

      
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"Every brand has a voice. Most founders never extract it. So every post starts from scratch."</p>
      </div>
      

      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Insight beat, slow push as the thesis builds. VO is the load-bearing element here.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_05">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">05</div>
        <div class="sb-placeholder-meta">MS · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-upper-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">Extract. Lock. Compound.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">05</span>
        <span class="sb-shot-time">24.0–32.0s</span>
        <span class="sb-shot-beat">insight</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder gestures toward laptop screen, kanban-style content pipeline visible, voice extraction interface, brand-lock file open in editor</p>
      </div>

      
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"Extract it once. Lock it in code. Now every post compounds."</p>
      </div>
      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Extract. Lock. Compound."</p>
        <p class="sb-text-meta">text_03 · headline · upper-third · enter 24.4s (slide-up) · exit 31.8s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Show the artifact. Text reinforces the three-step pattern. Deep DOF keeps the screen legible.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_06">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">06</div>
        <div class="sb-placeholder-meta">MCU · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-upper-third">
        <span class="sb-overlay-text" style="font-family: Inter Medium 500; font-weight: medium; color: #2A2A32;">hundreds of videos · 48hr cycles · 1 operator</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">06</span>
        <span class="sb-shot-time">32.0–42.0s</span>
        <span class="sb-shot-beat">proof</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, calm steady delivery, eye contact, hands folded</p>
      </div>

      
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"Hundreds of videos rendered from code. 48-hour content cycles. One operator."</p>
      </div>
      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"hundreds of videos · 48hr cycles · 1 operator"</p>
        <p class="sb-text-meta">text_04 · body · upper-third · enter 32.5s (fade-in) · exit 41.8s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Proof beat, concrete numbers. Stat callout in upper-third lets viewer absorb visually while VO confirms.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_07">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">07</div>
        <div class="sb-placeholder-meta">MS · eye-level · pull</div>
      </div>
      

      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">07</span>
        <span class="sb-shot-time">42.0–50.0s</span>
        <span class="sb-shot-beat">insight</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>pull</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, slight smile, settled into the explanation, room visible around him</p>
      </div>

      
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"Not because we work harder. Because the system runs."</p>
      </div>
      

      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Slow pull releases tension. The thesis lands. VO carries, text would dilute.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_08">
    <div class="sb-shot-frame aspect-9-16">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">08</div>
        <div class="sb-placeholder-meta">MCU · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #D94F3A;">whystrohm.com/scan</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">08</span>
        <span class="sb-shot-time">50.0–60.0s</span>
        <span class="sb-shot-beat">cta</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>founder, calm, looks directly into camera one more time, almost-smile, settled</p>
      </div>

      
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"If this sounds like the version of content you actually want, run a free scan."</p>
      </div>
      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"whystrohm.com/scan"</p>
        <p class="sb-text-meta">text_05 · headline · lower-third · enter 52.5s (type-on) · exit 59.8s (hard-cut)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>CTA beat. Static MCU brings it home. URL holds in lower-third for full read-twice duration.</p>
      </div>
    </div>
  </article>
  
</section>

<footer class="sb-footer">
  <div class="sb-footer-inner">
    <div>
      Built against <a href="brand-lock.snapshot.md"><code>brand-lock.snapshot.md</code></a> (<code>f364bc71f68d</code>).
    </div>
    <div>Built with <a href="https://github.com/whystrohm/shotkit">shotkit</a> · WhyStrohm</div>
  </div>
  <div class="sb-footer-inner sb-provenance">
    <div>
      Run 20260507T142300Z-005daed8 started 2026-05-07T14:23:00Z. This page rendered 2026-05-07T14:23:00Z.
      
    </div>
  </div>
</footer>

<script>
// Keyboard navigation: arrow keys move between shots
(function() {
  const shots = Array.from(document.querySelectorAll('.sb-shot'));
  if (!shots.length) return;

  function shotInView() {
    const mid = window.innerHeight / 2;
    let best = 0;
    let bestDist = Infinity;
    shots.forEach((shot, i) => {
      const rect = shot.getBoundingClientRect();
      const dist = Math.abs(rect.top + rect.height / 2 - mid);
      if (dist < bestDist) { bestDist = dist; best = i; }
    });
    return best;
  }

  document.addEventListener('keydown', function(e) {
    if (e.target.matches('input, textarea')) return;
    const i = shotInView();
    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      const next = shots[Math.min(shots.length - 1, i + 1)];
      next.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      const prev = shots[Math.max(0, i - 1)];
      prev.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
})();
</script>

</body>
</html>

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/60s-founder-explainer/preview.html -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/60s-founder-explainer/run.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/60s-founder-explainer/run.json`

{
  "version": "1.0",
  "run_id": "20260507T142300Z-005daed8",
  "created_at": "2026-05-07T14:23:00Z",
  "shotkit_version": "3.0.0",
  "operator": null,
  "project": {
    "title": "WhyStrohm. How The System Actually Works",
    "duration_s": 60,
    "aspect": "9:16",
    "framework": "founder-explainer"
  },
  "inputs": {
    "shots_ref": "shots.json",
    "shots_sha256": "23725f0696b0a614b6942fb04f9e70cbd20bdf68ccb7b95cf66b0ccdd82d2bef",
    "text_overlays_ref": "text-overlays.json",
    "text_overlays_sha256": "fb8bf44f326b1a8caf1d8b0273809d6c46d4155d32a2fe4883f790e04019f64e",
    "brand_lock_ref": "brand-lock.snapshot.md",
    "brand_lock_sha256": "f364bc71f68d16187d0721fbc092450174545e247f2f563a4c45686b4a877f50",
    "brand_lock_source": "brand-packs/whystrohm.md",
    "brand_lock_configured": true
  },
  "rounds": []
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/60s-founder-explainer/run.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/60s-founder-explainer/shots.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/60s-founder-explainer/shots.json`

{
  "version": "1.0",
  "project": {
    "title": "WhyStrohm. How The System Actually Works",
    "duration_s": 60,
    "aspect": "9:16",
    "framework": "founder-explainer"
  },
  "brand_lock_ref": "brand-lock.snapshot.md",
  "series_lock": {
    "character": "founder, mid-thirties, salt-and-pepper hair, navy crewneck, speaking directly to camera, calm authoritative posture",
    "environment": "minimalist home office, white walls, oak desk, single houseplant, late afternoon",
    "lighting": "soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff",
    "color_grade": "warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed"
  },
  "shots": [
    {
      "id": "shot_01",
      "beat": "hook",
      "start": 0.0,
      "end": 2.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "founder, looking directly into camera, slight knowing smile, mid-statement",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_01",
      "vo": "Most founders treat content like a hobby.",
      "rationale": "Hook is provocative but calm, voice carries the bite. Direct eye contact, MCU lock-in."
    },
    {
      "id": "shot_02",
      "beat": "stakes",
      "start": 2.0,
      "end": 8.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "founder, gesturing slightly with one hand, explaining, eye contact maintained",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": null,
      "vo": "Then they wonder why every post feels like starting over. New idea, new angle, no compounding.",
      "rationale": "Stakes beat. Pulled out to MS to let the gesture read. VO does the work, no on-screen text needed."
    },
    {
      "id": "shot_03",
      "beat": "stakes",
      "start": 8.0,
      "end": 14.0,
      "framing": "ECU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "close on founder's eyes, considered expression, slight head tilt",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_02",
      "vo": "It's not creativity. It's missing infrastructure.",
      "rationale": "ECU pulls the audience into the realization moment. Text reinforces the line that needs to land."
    },
    {
      "id": "shot_04",
      "beat": "insight",
      "start": 14.0,
      "end": 24.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "push",
      "depth_of_field": "shallow",
      "subject": "founder, leaning slightly forward, more energy in delivery, hands resting on desk",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": null,
      "vo": "Every brand has a voice. Most founders never extract it. So every post starts from scratch.",
      "rationale": "Insight beat, slow push as the thesis builds. VO is the load-bearing element here."
    },
    {
      "id": "shot_05",
      "beat": "insight",
      "start": 24.0,
      "end": 32.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "deep",
      "subject": "founder gestures toward laptop screen, kanban-style content pipeline visible, voice extraction interface, brand-lock file open in editor",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_03",
      "vo": "Extract it once. Lock it in code. Now every post compounds.",
      "rationale": "Show the artifact. Text reinforces the three-step pattern. Deep DOF keeps the screen legible."
    },
    {
      "id": "shot_06",
      "beat": "proof",
      "start": 32.0,
      "end": 42.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "founder, calm steady delivery, eye contact, hands folded",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_04",
      "vo": "Hundreds of videos rendered from code. 48-hour content cycles. One operator.",
      "rationale": "Proof beat, concrete numbers. Stat callout in upper-third lets viewer absorb visually while VO confirms."
    },
    {
      "id": "shot_07",
      "beat": "insight",
      "start": 42.0,
      "end": 50.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "pull",
      "depth_of_field": "shallow",
      "subject": "founder, slight smile, settled into the explanation, room visible around him",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": null,
      "vo": "Not because we work harder. Because the system runs.",
      "rationale": "Slow pull releases tension. The thesis lands. VO carries, text would dilute."
    },
    {
      "id": "shot_08",
      "beat": "cta",
      "start": 50.0,
      "end": 60.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "founder, calm, looks directly into camera one more time, almost-smile, settled",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_05",
      "vo": "If this sounds like the version of content you actually want, run a free scan.",
      "rationale": "CTA beat. Static MCU brings it home. URL holds in lower-third for full read-twice duration."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/60s-founder-explainer/shots.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/60s-founder-explainer/storyboard.md -->
# SOURCE FILE: `skills/storyboard-architect/examples/60s-founder-explainer/storyboard.md`

# WhyStrohm. How The System Actually Works

| | |
|---|---|
| **Duration** | 60s |
| **Aspect** | 9:16 |
| **Beat framework** | Founder Explainer |
| **Brand lock** | [`brand-lock.snapshot.md`](./brand-lock.snapshot.md) |
| **Generated** | 2026-05-07 14:31 UTC |

---

## Brief

A 60-second founder explainer for WhyStrohm. The audience is operators and founders who already know they need a content system but haven't seen the WhyStrohm thesis articulated. The narrative arc moves through five micro-beats: hook, stakes, insight, proof, and CTA. Voice carries the explanation; on-screen text reinforces the key turns.

## Beat framework: Founder Explainer

Five micro-beats:

- 0–2s. Hook (provocation)
- 2–14s. Stakes (why it matters)
- 14–32s. Insight (the actual point, extended for 60s to give the thesis room)
- 32–42s. Proof (the numbers)
- 42–60s. Insight wrap + CTA

## Series lock

| | |
|---|---|
| **Character anchor** | founder, mid-thirties, salt-and-pepper hair, navy crewneck, speaking directly to camera, calm authoritative posture |
| **Environment** | minimalist home office, white walls, oak desk, single houseplant, late afternoon |
| **Lighting** | soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff |
| **Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed |

---

## Shots

### shot_01 · 0.0–2.0s · MCU · static

**Beat:** hook · **VO:** "Most founders treat content like a hobby."
**Subject:** founder, looking directly into camera, slight knowing smile, mid-statement.
**On-screen text:** "Most founders treat content like a hobby." (lower-third, hard-cut)
**Rationale:** Hook is provocative but calm, voice carries the bite. Direct eye contact, MCU lock-in.

### shot_02 · 2.0–8.0s · MS · static

**Beat:** stakes · **VO:** "Then they wonder why every post feels like starting over. New idea, new angle, no compounding."
**Subject:** founder, gesturing slightly with one hand, explaining, eye contact maintained.
**Rationale:** Stakes beat. Pulled out to MS to let the gesture read. VO does the work, no on-screen text needed.

### shot_03 · 8.0–14.0s · ECU · static

**Beat:** stakes · **VO:** "It's not creativity. It's missing infrastructure."
**Subject:** close on founder's eyes, considered expression, slight head tilt.
**On-screen text:** "It's missing infrastructure." (coral, lower-third, type-on)
**Rationale:** ECU pulls the audience into the realization moment. Text reinforces the line that needs to land.

### shot_04 · 14.0–24.0s · MCU · push

**Beat:** insight · **VO:** "Every brand has a voice. Most founders never extract it. So every post starts from scratch."
**Subject:** founder, leaning slightly forward, more energy in delivery, hands resting on desk.
**Rationale:** Slow push as the thesis builds. VO is the load-bearing element here.

### shot_05 · 24.0–32.0s · MS · static

**Beat:** insight · **VO:** "Extract it once. Lock it in code. Now every post compounds."
**Subject:** founder gestures toward laptop screen, kanban content pipeline, voice extraction interface, brand-lock file open in editor.
**On-screen text:** "Extract. Lock. Compound." (upper-third, slide-up)
**Rationale:** Show the artifact. Text reinforces the three-step pattern. Deep DOF keeps the screen legible.

### shot_06 · 32.0–42.0s · MCU · static

**Beat:** proof · **VO:** "Hundreds of videos rendered from code. 48-hour content cycles. One operator."
**Subject:** founder, calm steady delivery, eye contact, hands folded.
**On-screen text:** "hundreds of videos · 48hr cycles · 1 operator" (upper-third, fade)
**Rationale:** Proof beat, concrete numbers. Stat callout lets viewer absorb visually while VO confirms.

### shot_07 · 42.0–50.0s · MS · pull

**Beat:** insight · **VO:** "Not because we work harder. Because the system runs."
**Subject:** founder, slight smile, settled into the explanation, room visible around him.
**Rationale:** Slow pull releases tension. The thesis lands. VO carries, text would dilute.

### shot_08 · 50.0–60.0s · MCU · static

**Beat:** cta · **VO:** "If this sounds like the version of content you actually want, run a free scan."
**Subject:** founder, calm, looks directly into camera one more time, almost-smile, settled.
**On-screen text:** "whystrohm.com/scan" (coral, lower-third, type-on)
**Rationale:** CTA beat. Static MCU brings it home. URL holds in lower-third for full read-twice duration.

---

## Handoff notes

- **For image generation:** run `visual-prompt-forge` against `shots.json`
- **For HTML preview:** run `storyboard-html-preview` against this folder
- **For QA:** run `visual-asset-critic` per shot

## Audit trail

Generated against `brand-lock.snapshot.md` (frozen at 2026-05-07T14:31:00Z, source `brand-packs/whystrohm.md`).

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/60s-founder-explainer/storyboard.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/60s-founder-explainer/text-overlays.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/60s-founder-explainer/text-overlays.json`

{
  "version": "1.0",
  "overlays": [
    {
      "id": "text_01",
      "shot_id": "shot_01",
      "content": "Most founders treat content like a hobby.",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#2A2A32",
      "position": "lower-third",
      "enter": { "at": 0.4, "animation": "hard-cut" },
      "exit": { "at": 1.9, "animation": "hard-cut" }
    },
    {
      "id": "text_02",
      "shot_id": "shot_03",
      "content": "It's missing infrastructure.",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#D94F3A",
      "position": "lower-third",
      "enter": { "at": 9.0, "animation": "type-on" },
      "exit": { "at": 13.8, "animation": "fade-out" }
    },
    {
      "id": "text_03",
      "shot_id": "shot_05",
      "content": "Extract. Lock. Compound.",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#2A2A32",
      "position": "upper-third",
      "enter": { "at": 24.4, "animation": "slide-up" },
      "exit": { "at": 31.8, "animation": "fade-out" }
    },
    {
      "id": "text_04",
      "shot_id": "shot_06",
      "content": "hundreds of videos · 48hr cycles · 1 operator",
      "font": "Inter Medium 500",
      "size": "body",
      "weight": "medium",
      "color": "#2A2A32",
      "position": "upper-third",
      "enter": { "at": 32.5, "animation": "fade-in" },
      "exit": { "at": 41.8, "animation": "fade-out" }
    },
    {
      "id": "text_05",
      "shot_id": "shot_08",
      "content": "whystrohm.com/scan",
      "font": "Inter Black 900",
      "size": "headline",
      "weight": "black",
      "color": "#D94F3A",
      "position": "lower-third",
      "enter": { "at": 52.5, "animation": "type-on" },
      "exit": { "at": 59.8, "animation": "hard-cut" }
    }
  ]
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/60s-founder-explainer/text-overlays.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md -->
# SOURCE FILE: `skills/storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md`

<!-- snapshot taken: 2026-05-08T14:34:24Z -->
<!-- source: brand-packs/whystrohm.md -->
<!-- storyboard: shotkit-explainer -->

# Brand Lock: WhyStrohm

## Identity

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

## Palette

| Role | Hex | Use |
|---|---|---|
| Background | `#F5F0E8` | Cream, primary canvas |
| Ink | `#2A2A32` | Near-black, primary text and dark elements |
| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |
| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |
| Muted | `#7A7580` | Secondary text, captions |
| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

## Typography

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

Two-font stack for production. Mono only for technical content.

## Mood adjectives

- operator (not creator)
- considered (not reactive)
- deterministic (not vibes-based)
- confident (without volume)
- defense-grade (not fragile)

## Never list

- never use stock photo aesthetic
- never use AI uncanny faces
- never over-saturate the cream background
- never use coral as a flood color (only as accent or signature periods)
- never use em dashes in copy (only periods, commas, semicolons)
- never use emojis in body copy
- never use bullet points in narrative copy
- never use clip-art or generic icon sets
- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- never use exclamation points in headlines
- never default to dark mode, light mode hybrid is the brand
- never animate text with bouncing or wobbling, type-on, fade, or hard cut only
- never break the eye line between subject and the implied "operator perspective"

## Aspect ratios

- 9:16, primary for short-form social
- 16:9, long-form, hero films, web embeds
- 1:1, feed posts, podcast covers
- 4:5. Instagram feed alternative

## Color grade direction

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup. Skin tones warm but not orange. Greens kept slightly desaturated to push focus to subject.

## Motion language

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only, no fancy wipes, no zooms.

For kinetic typography content (the Content Spiral pattern): pacing accelerates inward, each zoom 1.5–2x faster than the previous. Snap-back to wide claim is a hard cut.

## Voice rules

- no em dashes
- no emojis in body copy
- no exclamation points in headlines
- no hype words ("game-changing", "revolutionary", "comprehensive", "next-level", "leverage")
- no clichéd business metaphors ("move the needle", "drink the kool-aid", "low-hanging fruit")
- no qualifiers in declarative copy ("perhaps", "maybe", "kind of")
- prefer specific numbers over vague claims ("48 hours" not "fast", "30 minutes a week" not "a little time")
- prefer present-tense over future-tense
- prefer "operator" over "creator", "infrastructure" over "agency", "system" over "service"
- coral period (`.`) on signature lines is a typography choice, not punctuation, apply at end of hero phrases only

## Reference materials

- Site: https://whystrohm.com
- Brand voice extractor: https://github.com/whystrohm/media-tsunami
- Past hero films: see `/results` page
- Content Spiral pattern: documented in WhyStrohm production bible v3 (internal)

---

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/shotkit-explainer/preview.html -->
# SOURCE FILE: `skills/storyboard-architect/examples/shotkit-explainer/preview.html`

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="generator" content="storyboard-html-preview / WhyStrohm">
<title>shotkit. The Explainer. · Storyboard</title>
<style>
/* ─────────────────────────────────────────────────────────────
   Storyboard HTML Preview · WhyStrohm
   Single-file output. No external deps. Prints clean.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Brand-lock variables, get substituted at compose time */
  --sb-color-bg: #F5F0E8;
  --sb-color-ink: #2A2A32;
  --sb-color-accent: #D94F3A;
  --sb-color-muted: #7A7580;
  --sb-color-rule: #E8E1D4;

  --sb-font-display: Inter Black 900, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-body: Inter Medium 500, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;

  --sb-radius: 6px;
  --sb-pad: 24px;
  --sb-gap: 32px;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; }

body {
  font-family: var(--sb-font-body);
  font-size: 16px;
  line-height: 1.55;
  color: var(--sb-color-ink);
  background: var(--sb-color-bg);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

a {
  color: var(--sb-color-accent);
  text-decoration: none;
  border-bottom: 1px solid currentColor;
}

code {
  font-family: var(--sb-font-mono);
  font-size: 0.9em;
  background: var(--sb-color-rule);
  padding: 1px 6px;
  border-radius: 3px;
}

h1, h2, h3 {
  font-family: var(--sb-font-display);
  font-weight: 800;
  line-height: 1.15;
  letter-spacing: -0.01em;
}

/* ─── Header ─── */

.sb-header {
  border-bottom: 1px solid var(--sb-color-rule);
  padding: 64px var(--sb-pad) 40px;
}

.sb-header-inner {
  max-width: 960px;
  margin: 0 auto;
}

.sb-eyebrow {
  font-family: var(--sb-font-mono);
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 16px;
}

.sb-title {
  font-size: clamp(32px, 5vw, 56px);
  margin-bottom: 32px;
}

.sb-meta {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 16px;
  font-size: 14px;
}
.sb-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-meta dd { font-weight: 600; }

/* ─── Nav ─── */

.sb-nav {
  position: sticky;
  top: 0;
  background: var(--sb-color-bg);
  border-bottom: 1px solid var(--sb-color-rule);
  z-index: 10;
  overflow-x: auto;
}

.sb-nav ul {
  display: flex;
  gap: 4px;
  list-style: none;
  max-width: 960px;
  margin: 0 auto;
  padding: 12px var(--sb-pad);
}

.sb-nav a {
  display: inline-block;
  padding: 4px 10px;
  font-family: var(--sb-font-mono);
  font-size: 12px;
  border: 1px solid var(--sb-color-rule);
  border-radius: var(--sb-radius);
  color: var(--sb-color-ink);
  white-space: nowrap;
}

.sb-nav a:hover {
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
  border-color: var(--sb-color-accent);
}

/* ─── Sections ─── */

.sb-section {
  max-width: 960px;
  margin: 0 auto;
  padding: 56px var(--sb-pad);
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-section h2 {
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: var(--sb-color-muted);
  margin-bottom: 24px;
}

.sb-brief p {
  font-size: clamp(18px, 2.5vw, 24px);
  line-height: 1.45;
  max-width: 700px;
}

/* ─── Series lock ─── */

.sb-series-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 24px;
}

.sb-series-grid > div {
  border-left: 2px solid var(--sb-color-accent);
  padding-left: 14px;
}

.sb-series-grid dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 4px;
}

.sb-series-grid dd {
  font-size: 15px;
  line-height: 1.5;
}

/* ─── Shots ─── */

.sb-shots {
  background: var(--sb-color-bg);
}

.sb-shot {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: var(--sb-gap);
  padding: 40px 0;
  border-bottom: 1px solid var(--sb-color-rule);
  scroll-margin-top: 60px;
}

.sb-shot:last-child { border-bottom: none; }

.sb-shot-frame {
  position: relative;
  width: 100%;
  background: var(--sb-color-rule);
  border-radius: var(--sb-radius);
  overflow: hidden;
}

.sb-shot-frame.aspect-9-16 { aspect-ratio: 9 / 16; }
.sb-shot-frame.aspect-16-9 { aspect-ratio: 16 / 9; }
.sb-shot-frame.aspect-1-1  { aspect-ratio: 1 / 1; }
.sb-shot-frame.aspect-4-5  { aspect-ratio: 4 / 5; }
.sb-shot-frame.aspect-21-9 { aspect-ratio: 21 / 9; }

.sb-shot-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.sb-placeholder {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: linear-gradient(135deg, var(--sb-color-rule) 0%, var(--sb-color-bg) 100%);
  color: var(--sb-color-muted);
}

.sb-placeholder-id {
  font-family: var(--sb-font-mono);
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0.05em;
}

.sb-placeholder-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

/* On-screen text overlay preview (rendered over the frame) */
.sb-overlay {
  position: absolute;
  left: 0; right: 0;
  padding: 0 16px;
  pointer-events: none;
}

.sb-overlay-center        { top: 50%; transform: translateY(-50%); text-align: center; }
.sb-overlay-lower-third   { bottom: 12%; text-align: center; }
.sb-overlay-upper-third   { top: 12%; text-align: center; }
.sb-overlay-left-third    { top: 50%; transform: translateY(-50%); text-align: left; }
.sb-overlay-right-third   { top: 50%; transform: translateY(-50%); text-align: right; }

.sb-overlay-text {
  display: inline-block;
  font-size: clamp(14px, 2.2vw, 22px);
  line-height: 1.1;
  text-shadow: 0 2px 8px rgba(0,0,0,0.4);
}

/* ─── Shot body ─── */

.sb-shot-body { display: flex; flex-direction: column; gap: 20px; }

.sb-shot-header {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: baseline;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-shot-id {
  font-family: var(--sb-font-mono);
  font-size: 16px;
  font-weight: 700;
  color: var(--sb-color-accent);
}

.sb-shot-time {
  font-family: var(--sb-font-mono);
  font-size: 13px;
  color: var(--sb-color-muted);
}

.sb-shot-beat {
  font-size: 13px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-weight: 600;
  color: var(--sb-color-muted);
  margin-left: auto;
}

.sb-shot-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  font-size: 13px;
}

.sb-shot-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-shot-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-shot-meta dd { font-weight: 600; }

.sb-shot-subject h3,
.sb-shot-vo h3,
.sb-shot-text h3,
.sb-shot-rationale h3 {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 6px;
  font-weight: 600;
}

.sb-shot-subject p,
.sb-shot-vo p,
.sb-shot-rationale p {
  font-size: 15px;
  line-height: 1.55;
}

.sb-shot-vo p {
  font-style: italic;
  color: var(--sb-color-muted);
}

.sb-text-content {
  font-family: var(--sb-font-display);
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 4px;
}

.sb-text-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  color: var(--sb-color-muted);
}

.sb-shot-rationale {
  background: var(--sb-color-rule);
  padding: 14px 16px;
  border-radius: var(--sb-radius);
  border-left: 3px solid var(--sb-color-accent);
}

.sb-shot-rationale p {
  font-size: 14px;
  font-style: italic;
}

/* ─── Footer ─── */

.sb-footer {
  padding: 40px var(--sb-pad);
  background: var(--sb-color-rule);
  font-size: 12px;
  color: var(--sb-color-muted);
}

.sb-footer-inner {
  max-width: 960px;
  margin: 0 auto;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 16px;
}

/* ─── QA verdict ─── */

.sb-verdict {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
  border: 1px solid var(--sb-color-rule);
  border-radius: 2px;
  font-family: var(--sb-font-body);
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--sb-color-muted);
  white-space: nowrap;
}

.sb-verdict-accept { border-color: var(--sb-color-ink); color: var(--sb-color-ink); }
.sb-verdict-revise { border-color: var(--sb-color-accent); color: var(--sb-color-accent); }
.sb-verdict-reject {
  border-color: var(--sb-color-accent);
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
}

.sb-verdict-round { font-weight: 400; letter-spacing: 0.04em; opacity: 0.75; }

.sb-provenance {
  max-width: 960px;
  margin: 0 auto;
  font-size: 11px;
  line-height: 1.7;
  color: var(--sb-color-muted);
}

.sb-provenance code {
  font-size: 10px;
  word-break: break-all;
}

/* ─── Responsive ─── */

@media (max-width: 720px) {
  .sb-shot {
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 28px 0;
  }
  .sb-section { padding: 40px var(--sb-pad); }
  .sb-header { padding: 48px var(--sb-pad) 28px; }
}

/* ─── Print ─── */
@media print {
  /* ─── Page setup ─── */
  @page {
    size: letter;
    margin: 0.5in;
  }

  /* ─── Color & background ─── */
  body {
    background: white;
    color: black;
    font-size: 10pt;
    line-height: 1.4;
  }

  a {
    color: black;
    border-bottom: none;
  }

  a[href]::after {
    content: " (" attr(href) ")";
    font-family: var(--sb-font-mono);
    font-size: 8pt;
    color: #555;
  }

  /* Don't print sticky nav, JS controls, or footer scripts */
  .sb-nav { display: none; }

  /* ─── Header ─── */
  .sb-header {
    border-bottom: 2px solid black;
    padding: 0 0 16pt;
    margin-bottom: 24pt;
    page-break-after: avoid;
  }

  .sb-eyebrow {
    color: black;
    font-size: 9pt;
  }

  .sb-title {
    font-size: 24pt;
    margin-bottom: 12pt;
  }

  .sb-meta {
    grid-template-columns: repeat(4, 1fr);
    gap: 12pt;
    font-size: 9pt;
  }

  .sb-meta dt {
    color: #555;
    font-size: 7pt;
  }

  /* ─── Sections ─── */
  .sb-section {
    padding: 16pt 0;
    border-bottom: 1pt solid #999;
    page-break-inside: avoid;
  }

  .sb-section h2 {
    font-size: 9pt;
    margin-bottom: 12pt;
  }

  .sb-brief p {
    font-size: 12pt;
  }

  /* ─── Series lock ─── */
  .sb-series-grid {
    grid-template-columns: 1fr 1fr;
    gap: 12pt;
  }

  .sb-series-grid > div {
    border-left: 2pt solid black;
  }

  .sb-series-grid dt {
    color: #555;
    font-size: 7pt;
  }

  .sb-series-grid dd {
    font-size: 10pt;
  }

  /* ─── Shots, one shot per page ─── */
  .sb-shots h2 {
    page-break-after: avoid;
  }

  .sb-shot {
    page-break-inside: avoid;
    page-break-before: always;
    grid-template-columns: 1fr 1.2fr;
    gap: 18pt;
    padding: 18pt 0;
    border-bottom: none;
  }

  .sb-shot:first-of-type {
    page-break-before: avoid;
  }

  .sb-shot-frame {
    background: #f0f0f0;
    border: 1pt solid #999;
    border-radius: 0;
  }

  .sb-placeholder {
    background: #f5f5f5;
    color: #666;
  }

  .sb-overlay-text {
    text-shadow: none;
    background: rgba(255,255,255,0.85);
    padding: 2pt 6pt;
    color: black;
  }

  .sb-shot-id {
    color: black;
    font-size: 12pt;
  }

  .sb-shot-time, .sb-shot-beat {
    color: #555;
  }

  .sb-shot-rationale {
    background: #f5f5f5;
    border-left: 2pt solid black;
    padding: 8pt 10pt;
    page-break-inside: avoid;
  }

  .sb-shot-rationale p {
    font-size: 9pt;
  }

  .sb-shot-meta dt,
  .sb-shot-subject h3,
  .sb-shot-vo h3,
  .sb-shot-text h3,
  .sb-shot-rationale h3 {
    color: #555;
    font-size: 7pt;
  }

  .sb-shot-subject p,
  .sb-shot-vo p {
    font-size: 9.5pt;
  }

  /* ─── Footer ─── */
  .sb-footer {
    background: white;
    border-top: 1pt solid #999;
    padding: 12pt 0;
    font-size: 8pt;
    page-break-before: always;
  }

  .sb-footer-inner {
    flex-direction: column;
    gap: 4pt;
  }
}


</style>
</head>
<body>

<header class="sb-header">
  <div class="sb-header-inner">
    <div class="sb-eyebrow">Storyboard · shots 1.2</div>
    <h1 class="sb-title">shotkit. The Explainer.</h1>
    <dl class="sb-meta">
      <div><dt>Duration</dt><dd>90s</dd></div>
      <div><dt>Aspect</dt><dd>16:9</dd></div>
      <div><dt>Framework</dt><dd>founder-explainer</dd></div>
      <div><dt>Run</dt><dd>2026-05-08T14:34:24Z</dd></div>
    </dl>
  </div>
</header>

<nav class="sb-nav" aria-label="Shot navigation">
  <ul>
    
    <li><a href="#shot_01">01</a></li>
    
    <li><a href="#shot_02">02</a></li>
    
    <li><a href="#shot_03">03</a></li>
    
    <li><a href="#shot_04">04</a></li>
    
    <li><a href="#shot_05">05</a></li>
    
    <li><a href="#shot_06">06</a></li>
    
  </ul>
</nav>



<section class="sb-section sb-series-lock">
  <h2>Series lock</h2>
  <dl class="sb-series-grid">
    <div>
      <dt>Character</dt>
      <dd>no human subject. typography-driven explainer. document-control aesthetic with cream canvas, ink type, coral accents on signature beats</dd>
    </div>
    <div>
      <dt>Environment</dt>
      <dd>operator-grade dashboard. cream background, JetBrains Mono headers, Inter body, single coral accent per beat. no clutter, no decorative imagery</dd>
    </div>
    <div>
      <dt>Lighting</dt>
      <dd>even diffuse. no shadow rolloff. flat operator-doc grading throughout</dd>
    </div>
    <div>
      <dt>Color grade</dt>
      <dd>cream highlights (#F5F0E8), ink shadows (#2A2A32), coral (#D94F3A) reserved for signature beats only. no saturation drift</dd>
    </div>
  </dl>
</section>

<section class="sb-section sb-shots">
  <h2>Shots</h2>
  
  <article class="sb-shot" id="shot_01">
    <div class="sb-shot-frame aspect-16-9">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">01</div>
        <div class="sb-placeholder-meta">WS · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-center">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">You don&#x27;t have a content problem.
You have a pre-production problem.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">01</span>
        <span class="sb-shot-time">0.0–12.0s</span>
        <span class="sb-shot-beat">pain</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>WS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>vague founder brief types into the left panel in JetBrains Mono. cursor blinks. then a chaos cut shows four image generators producing slightly off-brand outputs in a 2x2 grid. each tile renders the same shot with a different palette, framing, and font choice. the misfire is the visual.</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"You don&#x27;t have a content problem.
You have a pre-production problem."</p>
        <p class="sb-text-meta">text_01 · display · center · enter 6.0s (fade-in) · exit 11.5s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Cold open names the failure mode every founder recognizes. Vague brief plus model-roulette equals brand drift. The 2x2 grid does the work text cannot. Static framing keeps the focus on the diagnosis.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_02">
    <div class="sb-shot-frame aspect-16-9">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">02</div>
        <div class="sb-placeholder-meta">MS · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-upper-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">Five layers. Locked top to bottom.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">02</span>
        <span class="sb-shot-time">12.0–30.0s</span>
        <span class="sb-shot-beat">reframe</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>five horizontal layers stack from top to bottom. each labeled in JetBrains Mono caps with 0.08em letter-spacing. brand lock, series lock, shot spec, text layer, generator adapter. each layer slides in from below on a 6-frame stagger. ink rules between. coral accent appears as a single dot on the brand lock layer when it lands.</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Five layers. Locked top to bottom."</p>
        <p class="sb-text-meta">text_02 · display · upper-third · enter 12.5s (type-on) · exit 29.5s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Architecture beat. The reader needs to see the layers exist before any claim about composability lands. Stack layout is the diagram doing the explanation. Coral accent on brand lock signals it as the load-bearing field.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_03">
    <div class="sb-shot-frame aspect-16-9">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">03</div>
        <div class="sb-placeholder-meta">MS · eye-level · push</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-upper-third">
        <span class="sb-overlay-text" style="font-family: Inter Medium 500; font-weight: medium; color: #2A2A32;">Brief in. Storyboard out. Audit trail included.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">03</span>
        <span class="sb-shot-time">30.0–50.0s</span>
        <span class="sb-shot-beat">proof-1</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>push</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>split panel. left BRIEF column shows typewriter brief slowly assembling. right OUTPUT column starts empty with a pulsing waiting dot, then file tree assembles row by row in JetBrains Mono Regular 16pt. storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md, prompts directory with seven adapter files, preview.html. coral dot appears next to preview.html on completion.</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Brief in. Storyboard out. Audit trail included."</p>
        <p class="sb-text-meta">text_03 · body · upper-third · enter 30.5s (fade-in) · exit 49.5s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>The build moment is the centerpiece. Brief in, structured files out. This is the shot that earns the methodology claim. Same animation language as the social demo so brand consistency reads across both surfaces.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_04">
    <div class="sb-shot-frame aspect-16-9">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">04</div>
        <div class="sb-placeholder-meta">MCU · eye-level · push</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">Files. Not panels. Not a SaaS dashboard.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">04</span>
        <span class="sb-shot-time">50.0–65.0s</span>
        <span class="sb-shot-beat">proof-2</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MCU</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>push</dd></div>
        
        <div><dt>DOF</dt><dd>shallow</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>coral wipe expands radially from the preview.html dot. wipe reveals a rendered preview iframe scrolling vertically. the reader sees the actual shot cards from the 30-second example pass through frame, including framing, angle, motion, color-grade rows. subtle ten-percent vignette on edges.</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"Files. Not panels. Not a SaaS dashboard."</p>
        <p class="sb-text-meta">text_04 · display · lower-third · enter 51.0s (type-on) · exit 64.5s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Reveal beat. The reader has now seen the methodology and the file outputs. The iframe shows the actual deliverable, not a mock. This is what separates the claim from the artifact.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_05">
    <div class="sb-shot-frame aspect-16-9">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">05</div>
        <div class="sb-placeholder-meta">MS · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-upper-third">
        <span class="sb-overlay-text" style="font-family: Inter Black 900; font-weight: black; color: #2A2A32;">One shot. Seven generators. One spec.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">05</span>
        <span class="sb-shot-time">65.0–80.0s</span>
        <span class="sb-shot-beat">proof-3</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>MS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>single shot description card sits center-frame. seven generator adapter logos and labels fan out radially around it in a 280-pixel radius. midjourney, flux, ideogram, gpt image, nano banana, seedream, runway sora. lines connect center card to each adapter label in 1px ink. each adapter shows its prompt syntax appearing as a typewriter pass, all running simultaneously.</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"One shot. Seven generators. One spec."</p>
        <p class="sb-text-meta">text_05 · display · upper-third · enter 65.5s (fade-in) · exit 79.5s (fade-out)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Cross-generator demonstration. Same shot description compiles to seven different prompt syntaxes simultaneously. The visual proves model-agnosticism is structural, not aspirational.</p>
      </div>
    </div>
  </article>
  
  <article class="sb-shot" id="shot_06">
    <div class="sb-shot-frame aspect-16-9">
      
      
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">06</div>
        <div class="sb-placeholder-meta">WS · eye-level · static</div>
      </div>
      

      
      <div class="sb-overlay sb-overlay-center">
        <span class="sb-overlay-text" style="font-family: JetBrains Mono Regular; font-weight: regular; color: #2A2A32;">git clone github.com/whystrohm/shotkit
cd shotkit &amp;&amp; ./install.sh</span>
      </div>
      
      <div class="sb-overlay sb-overlay-lower-third">
        <span class="sb-overlay-text" style="font-family: Inter Medium 500; font-weight: medium; color: #7A7580;">Pre-production for founder-led video at scale.</span>
      </div>
      
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">06</span>
        <span class="sb-shot-time">80.0–90.0s</span>
        <span class="sb-shot-beat">promise</span>
        
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>WS</dd></div>
        <div><dt>Angle</dt><dd>eye-level</dd></div>
        <div><dt>Motion</dt><dd>static</dd></div>
        
        <div><dt>DOF</dt><dd>deep</dd></div>
        
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>full-frame typography. install command appears via type-on in JetBrains Mono Regular at 22pt, ink color, monospace block. below it the project tagline in Inter italic 500 18pt, color muted. coral period on the signature beat. door closes with the standard footer chrome holding.</p>
      </div>

      

      
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        
        <p class="sb-text-content">"git clone github.com/whystrohm/shotkit
cd shotkit &amp;&amp; ./install.sh"</p>
        <p class="sb-text-meta">text_06 · body · center · enter 80.5s (type-on) · exit 90.0s (hard-cut)</p>
        
        <p class="sb-text-content">"Pre-production for founder-led video at scale."</p>
        <p class="sb-text-meta">text_07 · caption · lower-third · enter 86.0s (fade-in) · exit 90.0s (hard-cut)</p>
        
      </div>
      

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>Promise beat. The viewer has the diagnosis, the architecture, the artifact, and the proof. The CTA is one paste-into-terminal command. No friction surface, no signup, no email gate.</p>
      </div>
    </div>
  </article>
  
</section>

<footer class="sb-footer">
  <div class="sb-footer-inner">
    <div>
      Built against <a href="brand-lock.snapshot.md"><code>brand-lock.snapshot.md</code></a> (<code>dbb416f3cbac</code>).
    </div>
    <div>Built with <a href="https://github.com/whystrohm/shotkit">shotkit</a> · WhyStrohm</div>
  </div>
  <div class="sb-footer-inner sb-provenance">
    <div>
      Run 20260508T143424Z-a38d935c started 2026-05-08T14:34:24Z. This page rendered 2026-05-08T14:34:24Z.
      
    </div>
  </div>
</footer>

<script>
// Keyboard navigation: arrow keys move between shots
(function() {
  const shots = Array.from(document.querySelectorAll('.sb-shot'));
  if (!shots.length) return;

  function shotInView() {
    const mid = window.innerHeight / 2;
    let best = 0;
    let bestDist = Infinity;
    shots.forEach((shot, i) => {
      const rect = shot.getBoundingClientRect();
      const dist = Math.abs(rect.top + rect.height / 2 - mid);
      if (dist < bestDist) { bestDist = dist; best = i; }
    });
    return best;
  }

  document.addEventListener('keydown', function(e) {
    if (e.target.matches('input, textarea')) return;
    const i = shotInView();
    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      const next = shots[Math.min(shots.length - 1, i + 1)];
      next.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      const prev = shots[Math.max(0, i - 1)];
      prev.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
})();
</script>

</body>
</html>

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/shotkit-explainer/preview.html -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/shotkit-explainer/run.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/shotkit-explainer/run.json`

{
  "version": "1.0",
  "run_id": "20260508T143424Z-a38d935c",
  "created_at": "2026-05-08T14:34:24Z",
  "shotkit_version": "3.0.0",
  "operator": null,
  "project": {
    "title": "shotkit. The Explainer.",
    "duration_s": 90,
    "aspect": "16:9",
    "framework": "founder-explainer"
  },
  "inputs": {
    "shots_ref": "shots.json",
    "shots_sha256": "09f0e08a1623c033629bbc859cac198599f4823dba14e598d1ce3cdbba6aa21e",
    "text_overlays_ref": "text-overlays.json",
    "text_overlays_sha256": "d685bcebbca9d59565bf81c12fc0266084c3f7361c48635f5d7d87183bbe1002",
    "brand_lock_ref": "brand-lock.snapshot.md",
    "brand_lock_sha256": "dbb416f3cbac8e40982ad2f260e277487ebe4bf4c783c0aee75045260e4fbf14",
    "brand_lock_source": "brand-packs/whystrohm.md",
    "brand_lock_configured": true
  },
  "rounds": []
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/shotkit-explainer/run.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/shotkit-explainer/shots.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/shotkit-explainer/shots.json`

{
  "version": "1.2",
  "project": {
    "title": "shotkit. The Explainer.",
    "duration_s": 90,
    "aspect": "16:9",
    "framework": "founder-explainer"
  },
  "brand_lock_ref": "brand-lock.snapshot.md",
  "series_lock": {
    "character": "no human subject. typography-driven explainer. document-control aesthetic with cream canvas, ink type, coral accents on signature beats",
    "environment": "operator-grade dashboard. cream background, JetBrains Mono headers, Inter body, single coral accent per beat. no clutter, no decorative imagery",
    "lighting": "even diffuse. no shadow rolloff. flat operator-doc grading throughout",
    "color_grade": "cream highlights (#F5F0E8), ink shadows (#2A2A32), coral (#D94F3A) reserved for signature beats only. no saturation drift"
  },
  "shots": [
    {
      "id": "shot_01",
      "beat": "pain",
      "start": 0.0,
      "end": 12.0,
      "framing": "WS",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "deep",
      "subject": "vague founder brief types into the left panel in JetBrains Mono. cursor blinks. then a chaos cut shows four image generators producing slightly off-brand outputs in a 2x2 grid. each tile renders the same shot with a different palette, framing, and font choice. the misfire is the visual.",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_01",
      "vo": null,
      "rationale": "Cold open names the failure mode every founder recognizes. Vague brief plus model-roulette equals brand drift. The 2x2 grid does the work text cannot. Static framing keeps the focus on the diagnosis."
    },
    {
      "id": "shot_02",
      "beat": "reframe",
      "start": 12.0,
      "end": 30.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "deep",
      "subject": "five horizontal layers stack from top to bottom. each labeled in JetBrains Mono caps with 0.08em letter-spacing. brand lock, series lock, shot spec, text layer, generator adapter. each layer slides in from below on a 6-frame stagger. ink rules between. coral accent appears as a single dot on the brand lock layer when it lands.",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_02",
      "vo": null,
      "rationale": "Architecture beat. The reader needs to see the layers exist before any claim about composability lands. Stack layout is the diagram doing the explanation. Coral accent on brand lock signals it as the load-bearing field."
    },
    {
      "id": "shot_03",
      "beat": "proof-1",
      "start": 30.0,
      "end": 50.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "push",
      "depth_of_field": "deep",
      "subject": "split panel. left BRIEF column shows typewriter brief slowly assembling. right OUTPUT column starts empty with a pulsing waiting dot, then file tree assembles row by row in JetBrains Mono Regular 16pt. storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md, prompts directory with seven adapter files, preview.html. coral dot appears next to preview.html on completion.",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_03",
      "vo": null,
      "rationale": "The build moment is the centerpiece. Brief in, structured files out. This is the shot that earns the methodology claim. Same animation language as the social demo so brand consistency reads across both surfaces."
    },
    {
      "id": "shot_04",
      "beat": "proof-2",
      "start": 50.0,
      "end": 65.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "push",
      "depth_of_field": "shallow",
      "subject": "coral wipe expands radially from the preview.html dot. wipe reveals a rendered preview iframe scrolling vertically. the reader sees the actual shot cards from the 30-second example pass through frame, including framing, angle, motion, color-grade rows. subtle ten-percent vignette on edges.",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_04",
      "vo": null,
      "rationale": "Reveal beat. The reader has now seen the methodology and the file outputs. The iframe shows the actual deliverable, not a mock. This is what separates the claim from the artifact."
    },
    {
      "id": "shot_05",
      "beat": "proof-3",
      "start": 65.0,
      "end": 80.0,
      "framing": "MS",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "deep",
      "subject": "single shot description card sits center-frame. seven generator adapter logos and labels fan out radially around it in a 280-pixel radius. midjourney, flux, ideogram, gpt image, nano banana, seedream, runway sora. lines connect center card to each adapter label in 1px ink. each adapter shows its prompt syntax appearing as a typewriter pass, all running simultaneously.",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_05",
      "vo": null,
      "rationale": "Cross-generator demonstration. Same shot description compiles to seven different prompt syntaxes simultaneously. The visual proves model-agnosticism is structural, not aspirational."
    },
    {
      "id": "shot_06",
      "beat": "promise",
      "start": 80.0,
      "end": 90.0,
      "framing": "WS",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "deep",
      "subject": "full-frame typography. install command appears via type-on in JetBrains Mono Regular at 22pt, ink color, monospace block. below it the project tagline in Inter italic 500 18pt, color muted. coral period on the signature beat. door closes with the standard footer chrome holding.",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": ["text_06", "text_07"],
      "vo": null,
      "rationale": "Promise beat. The viewer has the diagnosis, the architecture, the artifact, and the proof. The CTA is one paste-into-terminal command. No friction surface, no signup, no email gate."
    }
  ]
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/shotkit-explainer/shots.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/shotkit-explainer/storyboard.md -->
# SOURCE FILE: `skills/storyboard-architect/examples/shotkit-explainer/storyboard.md`

# shotkit. The Explainer.

**Project:** shotkit explainer film
**Duration:** 90 seconds
**Aspect:** 16:9 (1280x720 hero render, 1080x1920 vertical cut for socials)
**Framework:** founder-explainer
**Brand-lock:** [brand-lock.snapshot.md](./brand-lock.snapshot.md) snapshotted 2026-05-08T14:34:24Z
**Generated:** 2026-05-08

> This storyboard is the record of the v0.1.0 explainer film as it was actually rendered, so
> shot_05 still names seven adapters including Runway/Sora. Sora was discontinued and the
> motion lane moved to Kling, Veo, Seedance, and Hailuo. The storyboard is deliberately left
> matching the artifact it produced: editing it to describe a video that was never made is
> exactly the kind of drift this repo exists to prevent. See `CHANGELOG.md` for the adapter
> change.

## Brief

90-second explainer for shotkit. Targets founder-led brands at $500K to $5M ARR who run their own content and feel the prompt-engineering tax. Walks through the diagnosis (vague brief plus model-roulette equals brand drift), the methodology (five-layer prompt anatomy), the build moment (brief in, files out), the proof (rendered preview from a real shotkit run), and the install command. Lives at the top of the shotkit blog post on whystrohm.com.

## Series lock

| Field | Value |
|---|---|
| **Character** | No human subject. Typography-driven explainer with document-control aesthetic. |
| **Environment** | Operator-grade dashboard. Cream canvas, JetBrains Mono headers, Inter body, single coral accent per beat. |
| **Lighting** | Even diffuse. No shadow rolloff. Flat operator-doc grading throughout. |
| **Color grade** | Cream highlights (#F5F0E8), ink shadows (#2A2A32), coral (#D94F3A) reserved for signature beats. No saturation drift. |

## Shots

### shot_01: 0.0 to 12.0s. WS. eye-level. static.

**Beat:** pain. **Subject:** vague founder brief types into the left panel in JetBrains Mono. Cursor blinks. Then a chaos cut shows four image generators producing slightly off-brand outputs in a 2x2 grid. Each tile renders the same shot with a different palette, framing, font.
**On-screen text:** "You don't have a content problem. You have a pre-production problem." (Inter Black 900, center, fade)
**Rationale:** Cold open names the failure mode every founder recognizes. Vague brief plus model-roulette equals brand drift. The 2x2 grid does the work text cannot.

### shot_02: 12.0 to 30.0s. MS. eye-level. static.

**Beat:** reframe. **Subject:** Five horizontal layers stack from top to bottom. Each labeled in JetBrains Mono caps with 0.08em letter-spacing: brand lock, series lock, shot spec, text layer, generator adapter. Each layer slides in from below on a 6-frame stagger. Coral dot lands on brand lock as it appears.
**On-screen text:** "Five layers. Locked top to bottom." (Inter Black 900, upper-third, type-on)
**Rationale:** Architecture beat. The reader needs to see the layers exist before any claim about composability lands. Stack layout is the diagram doing the explanation.

### shot_03: 30.0 to 50.0s. MS. eye-level. push.

**Beat:** proof-1. **Subject:** Split panel. Left BRIEF column types out a brief slowly. Right OUTPUT column starts empty with a pulsing waiting dot, then file tree assembles row by row in JetBrains Mono Regular 16pt. storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md, prompts/ directory with seven adapter files, preview.html. Coral dot lands on preview.html on completion.
**On-screen text:** "Brief in. Storyboard out. Audit trail included." (Inter Medium 500, upper-third, fade)
**Rationale:** The build moment is the centerpiece. Brief in, structured files out. Same animation language as the social demo so brand consistency reads across both surfaces.

### shot_04: 50.0 to 65.0s. MCU. eye-level. push.

**Beat:** proof-2. **Subject:** Coral wipe expands radially from the preview.html dot. Wipe reveals the rendered preview iframe scrolling vertically. The reader sees actual shot cards from the 30-second example pass through frame, including framing, angle, motion, color-grade rows. Subtle 10% vignette on edges.
**On-screen text:** "Files. Not panels. Not a SaaS dashboard." (Inter Black 900, lower-third, type-on)
**Rationale:** Reveal beat. The reader has now seen the methodology and the file outputs. The iframe shows the actual deliverable, not a mock.

### shot_05: 65.0 to 80.0s. MS. eye-level. static.

**Beat:** proof-3. **Subject:** Single shot description card sits center-frame. Seven generator adapter labels fan out radially around it. Midjourney, Flux, Ideogram, GPT Image, Nano Banana, Seedream, Runway/Sora. Lines connect center card to each adapter in 1px ink. Each adapter shows its prompt syntax appearing as a typewriter pass running simultaneously.
**On-screen text:** "One shot. Seven generators. One spec." (Inter Black 900, upper-third, fade)
**Rationale:** Cross-generator demonstration. Same shot description compiles to seven different prompt syntaxes simultaneously. The visual proves model-agnosticism is structural, not aspirational.

### shot_06: 80.0 to 90.0s. WS. eye-level. static.

**Beat:** promise. **Subject:** Full-frame typography. Install command appears via type-on in JetBrains Mono Regular at 22pt. Below it the project tagline in Inter italic 500 18pt, color muted. Coral period on the signature beat. Standard footer chrome holds.
**On-screen text:** "git clone github.com/whystrohm/shotkit / cd shotkit && ./install.sh" (JetBrains Mono, center, type-on) plus tagline "Pre-production for founder-led video at scale." (Inter italic 500, lower-third, fade).
**Rationale:** Promise beat. The viewer has the diagnosis, the architecture, the artifact, and the proof. The CTA is one paste-into-terminal command. No friction surface.

## Audit trail

- Brief, this document, scoped from the shotkit blog launch sequence.
- Brand-lock snapshotted from `brand-packs/whystrohm.md` on 2026-05-08.
- Shot list designed to compose with the existing ShotkitDemo composition (same chrome, complementary content, longer arc).
- Render shipped at [whystrohm.com/blog/you-dont-have-a-content-problem](https://whystrohm.com/blog/you-dont-have-a-content-problem) as the "we used shotkit to make this video" dogfood reveal.
- Landscape MP4 served from the blog: `/media/shotkit-explainer/shotkit-explainer.mp4`.

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/shotkit-explainer/storyboard.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/examples/shotkit-explainer/text-overlays.json -->
# SOURCE FILE: `skills/storyboard-architect/examples/shotkit-explainer/text-overlays.json`

{
  "version": "1.0",
  "overlays": [
    {
      "id": "text_01",
      "shot_id": "shot_01",
      "content": "You don't have a content problem.\nYou have a pre-production problem.",
      "font": "Inter Black 900",
      "size": "display",
      "weight": "black",
      "color": "#2A2A32",
      "position": "center",
      "enter": { "at": 6.0, "animation": "fade-in" },
      "exit": { "at": 11.5, "animation": "fade-out" }
    },
    {
      "id": "text_02",
      "shot_id": "shot_02",
      "content": "Five layers. Locked top to bottom.",
      "font": "Inter Black 900",
      "size": "display",
      "weight": "black",
      "color": "#2A2A32",
      "position": "upper-third",
      "enter": { "at": 12.5, "animation": "type-on" },
      "exit": { "at": 29.5, "animation": "fade-out" }
    },
    {
      "id": "text_03",
      "shot_id": "shot_03",
      "content": "Brief in. Storyboard out. Audit trail included.",
      "font": "Inter Medium 500",
      "size": "body",
      "weight": "medium",
      "color": "#2A2A32",
      "position": "upper-third",
      "enter": { "at": 30.5, "animation": "fade-in" },
      "exit": { "at": 49.5, "animation": "fade-out" }
    },
    {
      "id": "text_04",
      "shot_id": "shot_04",
      "content": "Files. Not panels. Not a SaaS dashboard.",
      "font": "Inter Black 900",
      "size": "display",
      "weight": "black",
      "color": "#2A2A32",
      "position": "lower-third",
      "enter": { "at": 51.0, "animation": "type-on" },
      "exit": { "at": 64.5, "animation": "fade-out" }
    },
    {
      "id": "text_05",
      "shot_id": "shot_05",
      "content": "One shot. Seven generators. One spec.",
      "font": "Inter Black 900",
      "size": "display",
      "weight": "black",
      "color": "#2A2A32",
      "position": "upper-third",
      "enter": { "at": 65.5, "animation": "fade-in" },
      "exit": { "at": 79.5, "animation": "fade-out" }
    },
    {
      "id": "text_06",
      "shot_id": "shot_06",
      "content": "git clone github.com/whystrohm/shotkit\ncd shotkit && ./install.sh",
      "font": "JetBrains Mono Regular",
      "size": "body",
      "weight": "regular",
      "color": "#2A2A32",
      "position": "center",
      "enter": { "at": 80.5, "animation": "type-on" },
      "exit": { "at": 90.0, "animation": "hard-cut" }
    },
    {
      "id": "text_07",
      "shot_id": "shot_06",
      "content": "Pre-production for founder-led video at scale.",
      "font": "Inter Medium 500",
      "size": "caption",
      "weight": "medium",
      "color": "#7A7580",
      "position": "lower-third",
      "enter": { "at": 86.0, "animation": "fade-in" },
      "exit": { "at": 90.0, "animation": "hard-cut" }
    }
  ]
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/examples/shotkit-explainer/text-overlays.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/references/beat-frameworks.md -->
# SOURCE FILE: `skills/storyboard-architect/references/beat-frameworks.md`

# Beat Frameworks

Pick one. Don't invent a new one unless the brief genuinely doesn't fit. Document the choice in `storyboard.md`.

## Pain-Reframe-Promise (PRP)

Default for conversion content. Three beats:

1. **Pain**, name the audience's actual problem in their actual language. Concrete, not abstract. "Your content feels random" not "marketing inefficiency."
2. **Reframe**, flip the problem on its head. The point is *not* what they thought it was. "You don't have a content problem. You have an infrastructure problem."
3. **Promise**, what life looks like on the other side. Specific, verifiable, time-bound when possible.

Timing for 30s: 0–8 / 8–22 / 22–30.
Timing for 60s: 0–15 / 15–45 / 45–60.

Use when: ad creative, landing-page hero video, conversion-focused social.

## Hero Trilogy

Default for product films and brand films. Three beats:

1. **World**, set the context. Who lives in this world. What's broken about it.
2. **Hero**, the product/founder/methodology arrives. Show what it does, not what it is.
3. **Transformation**, the world changes. Show before/after at scale.

Timing for 60s: 0–20 / 20–40 / 40–60.
Timing for 90s: 0–30 / 30–60 / 60–90.

Use when: product launches, brand films, anchor pieces.

## Founder Explainer

Default for personal-brand video where a person speaks to camera. Five micro-beats:

1. **Hook**, a one-line provocation (0–2s)
2. **Stakes**, why this matters (2–8s)
3. **Insight**, the actual point (8–20s for 30s, 8–40s for 60s)
4. **Proof**, one concrete example or data point
5. **CTA**, what to do next, narrow and specific

Use when: founder content, thought leadership, personal-brand pieces.

## Content Spiral

Default for kinetic typography or opinion content. The structure is recursive, each beat zooms in tighter:

1. **Wide claim**, the headline take
2. **Zoom 1**, one layer of nuance
3. **Zoom 2**, the layer underneath that
4. **Snap-back**, return to the wide claim, now reframed by the zooms

Each zoom is 1.5–2x faster than the previous. Pacing accelerates inward.

Use when: opinion videos, kinetic-type pieces, social-native commentary.

## Educational Demo

Default for how-to content. Four beats:

1. **Problem state**, what someone is stuck on
2. **Reveal**, the technique or trick
3. **Walk-through**, apply it step by step
4. **Result**, the after-state, side-by-side with before

Use when: tutorials, demo videos, training content.

## Custom

If the brief doesn't fit, build a custom beat structure. Document in `storyboard.md`:

```markdown
## Beat framework: Custom

**Why custom:** [one sentence, what made the standard frameworks insufficient]

**Beats:**
1. [name], [purpose], [duration]
2. ...
```

Custom is a last resort, not a first move. The standard frameworks exist because they work.

<!-- SOURCE_FILE_END: skills/storyboard-architect/references/beat-frameworks.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/references/on-screen-text.md -->
# SOURCE FILE: `skills/storyboard-architect/references/on-screen-text.md`

# On-Screen Text

Text on screen is a load-bearing decision. Most storyboards over-text. The default should be: **does this shot need text to land?** If the visual carries the meaning, text dilutes.

## When on-screen text earns its keep

1. **Auto-play-mute environments.** Social feeds. Text replaces VO.
2. **Concept compression.** A short phrase lands harder than 4 seconds of narration.
3. **Stat or proof point.** Numbers stick visually in a way they don't audibly.
4. **Beat punctuation.** A single word or phrase that lands on a music hit.
5. **CTA.** The action you want the viewer to take.

## When on-screen text doesn't earn its keep

1. **Restating the VO.** If the voice says it, the text is noise.
2. **Decorative copy.** "Moments matter" floating over b-roll. Cut it.
3. **Brand vibing.** Product names everywhere. Logo lockup in the CTA covers this.
4. **Filler beats.** If the shot doesn't need text, leave it clean.

## Composition rules

These flow into the `position` field of each text overlay.

### Negative-space-aware composition

When a shot has on-screen text, the **shot subject must reserve space for it**. This is enforced at storyboard time, not generation time.

If text is in the right third → subject composition leaves the right third clear.
If text is lower third → subject upper two-thirds.
If text is centered → subject framed to negative space around center.

This goes into the shot's rationale: "MCU left-third subject, reserves right-third for `text_03`."

### Positions

| Position | Use when |
|---|---|
| `center` | Display headline, single concept, hard cut in/out |
| `lower-third` | Caption / VO substitute, persistent across shots |
| `upper-third` | Stat callout, secondary information |
| `left-third` | Subject is right-weighted in frame |
| `right-third` | Subject is left-weighted in frame |
| `{x: %, y: %}` | Custom, only when the standard positions don't fit |

### Sizes

| Size | Pixel approx (1080p) | Use for |
|---|---|---|
| `display` | 96–144 px | Hero/hook beats |
| `headline` | 56–80 px | Reframe beats |
| `body` | 32–48 px | Caption-style, persistent |
| `caption` | 20–28 px | Disclaimers, attribution |

### Animation

Default to clean, not flashy:

- Hook beats → `hard-cut` in, `hard-cut` out (no fade)
- Reframe beats → `fade-in` 0.2s, `fade-out` 0.2s
- Persistent captions → `slide-up` in, `slide-down` out
- CTA → `type-on` for a typewriter effect, or `slide-up`

Avoid stacking animations. Pick one per overlay.

## Color rules

The `color` field of every text overlay must be a hex value that exists in the brand-lock palette. If you find yourself wanting a color that's not in the palette, the answer is not to add it, the answer is to pick a different overlay style or shot composition.

## Typography rules

Same: every `font` field must reference a font defined in brand-lock typography. Two fonts max per project (display + body). More than that and the brand stops being recognizable.

## The "read twice" rule

Already covered in timing-rules.md but worth repeating: text needs to be on screen long enough for someone to read it twice. Calculate, then verify. Don't eyeball.

## Stacking text across shots

Text can persist across consecutive shots. This is useful when:

- The text takes longer to read than a single shot's duration
- You want text to feel anchored while visuals change underneath

To stack, both shots reference the same `on_screen_text` ID. The overlay's `enter.at` aligns to the first shot's start, `exit.at` aligns to the second shot's end.

In `shots.json`:

```json
{ "id": "shot_03", "on_screen_text": "text_02", ... },
{ "id": "shot_04", "on_screen_text": "text_02", ... }
```

In `text-overlays.json`:

```json
{
  "id": "text_02",
  "shot_id": ["shot_03", "shot_04"],
  ...
}
```

Document this in rationale: "text persists across shot 3-4 to give 4.8s read-time for 16-word reframe."

<!-- SOURCE_FILE_END: skills/storyboard-architect/references/on-screen-text.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/references/shot-grammar.md -->
# SOURCE FILE: `skills/storyboard-architect/references/shot-grammar.md`

# Shot Grammar

Controlled vocabulary. Use these exact terms in `shots.json`. Generators interpret loose language inconsistently, locked vocabulary survives translation.

## Framing (subject size in frame)

| Code | Name | What it shows |
|---|---|---|
| `ECU` | Extreme close-up | Eyes, hands, single detail |
| `CU` | Close-up | Head, or full hand-on-object |
| `MCU` | Medium close-up | Head and shoulders |
| `MS` | Medium shot | Waist up |
| `MLS` | Medium long shot | Full body, environment minimal |
| `WS` | Wide shot | Full body, environment present |
| `EWS` | Extreme wide shot | Subject small in environment |

Default to MCU and MS for talking-head founder content. ECU and CU for product detail and emotion. WS and EWS for context-setting.

## Angle (camera vertical position)

| Code | Effect |
|---|---|
| `eye-level` | Neutral, default |
| `high` | Subject feels smaller, vulnerable |
| `low` | Subject feels powerful, dominant |
| `overhead` | Detached, schematic, instructional |
| `dutch` | Tilted, tension, unease |

Default to eye-level. Use the others deliberately, not for variety.

## Motion (camera movement)

| Code | Effect | Use when |
|---|---|---|
| `static` | No movement | Default. Static is not boring. |
| `push` | Camera moves toward subject | Building intensity, revealing |
| `pull` | Camera moves away | Releasing, contextualizing |
| `pan-left` / `pan-right` | Camera rotates horizontally | Surveying environment |
| `tilt-up` / `tilt-down` | Camera rotates vertically | Reveal scale or detail |
| `handheld` | Subtle organic shake | Documentary feel, urgency |
| `orbit` | Camera circles subject | Hero shots, product reveal |
| `whip` | Fast pan as transition | Beat-cuts in fast-paced content |

For AI-generated still frames, motion is mostly intent for the editor. For motion-video prompts (Kling, Veo, Seedance, Hailuo), motion translates directly.

## Depth of field

| Code | Effect |
|---|---|
| `shallow` | Subject sharp, background blurred |
| `deep` | Everything in focus |
| `rack` | Focus shifts mid-shot |

Default to shallow for talking-head, deep for environmental and schematic.

## Lighting style (referenced from series_lock)

Don't redefine per shot. Define once in `series_lock.lighting`. Examples:

- `soft natural side-light, large window left, warm afternoon`
- `hard top-light, single source, deep shadows, studio black`
- `practical mixed sources, neon accents, urban night`

The series_lock string flows into every prompt automatically.

## Subject description

Structured, not poetic. Pattern:

```
[who/what], [doing what], [emotional or compositional note]
```

Good:
```
"Founder, mid-thirties, leaning forward at laptop, face partially turned to window light"
```

Bad:
```
"A determined entrepreneur conquering the digital frontier with passion"
```

Generators reward precision. Adjectives describing emotion ("determined", "passionate") produce stock-photo aesthetics. Describe what the camera actually sees.

## What goes in `subject` vs `series_lock` vs `brand_lock`

This trips people up. The rule:

- **brand_lock**, locked across the entire project. Palette, type, "never" list.
- **series_lock**, locked across this storyboard. Character anchor, environment, lighting style, color grade.
- **subject (per shot)**, what's different about *this* shot. Action, expression, framing-specific composition notes.

If you find yourself repeating the same lighting description across shots, it belongs in series_lock. If you find yourself repeating the same color description across storyboards, it belongs in brand_lock.

<!-- SOURCE_FILE_END: skills/storyboard-architect/references/shot-grammar.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/references/timing-rules.md -->
# SOURCE FILE: `skills/storyboard-architect/references/timing-rules.md`

# Timing Rules

Pacing is math, not feel. Use these as defaults. Override only with reason documented in rationale.

## Shot duration baselines

| Content type | Default shot duration | Range |
|---|---|---|
| Kinetic typography / opinion | 1.0–1.5s | 0.5–2.0s |
| Founder talking-head | 2.5–4.0s | 2.0–6.0s |
| Product/lifestyle b-roll | 1.5–2.5s | 1.0–3.5s |
| Demo / how-to | 3.0–5.0s | 2.0–7.0s |
| Cinematic brand film | 3.5–6.0s | 2.0–10.0s |

If a single shot is longer than 7 seconds in a 30-second piece, justify it in rationale. Long shots are not bad. Unjustified long shots are.

## Hook timing (the first beat)

The hook is 0–2s. Always. There are no exceptions in short-form content. Specifically:

- 9:16 social: first frame must telegraph the topic. Auto-play on mute means the first half-second is fighting a swipe.
- 16:9 in-feed: first 2s decides watch-time.

The hook shot framing should be high-contrast against the shots that follow. If shot 2 is MS, shot 1 should not be MS. Visual contrast = retention.

## CTA timing (the final beat)

The CTA is the final 4–6s for 30s content, 6–10s for 60s content. Specifically:

- Last shot should hold long enough for someone to read the CTA text and act
- Don't put motion on the CTA shot, let the text breathe
- If there's a logo lockup, it lives in the final 2s, not earlier

## On-screen text duration math

A text overlay needs to be on screen long enough to be **read twice**. Not once, twice. Why: viewers are skimming, eyes don't always lock on first frame.

Reading speed reference (assume average viewer):
- 1 short word (≤5 chars): 0.6s minimum read
- Short phrase (≤6 words): 1.2s
- Sentence (≤14 words): 2.4s
- Long sentence (15–25 words): 4.0s

Multiply by 2 for the "read twice" rule. So a 6-word phrase needs **2.4s on screen minimum**.

If a shot is 2 seconds and you need a 14-word sentence, you have a problem. Either:
1. Shorten the copy
2. Carry the text across two consecutive shots (text persists during cut)
3. Lengthen the shot

Do not under-time text. It's the most common storyboard failure.

## Pacing curve

For 30-second content, the natural energy curve:

```
0s ─────────────────────────────────── 30s

Energy
  ▲     ╱╲
  │    ╱  ╲___
  │   ╱       ╲___
  │  ╱            ╲___
  │ ╱                 ╲___
  └─────────────────────────►
   hook  build  apex  release  CTA
   0-2   2-12   12-20  20-26   26-30
```

The apex is two-thirds in, not at the end. The CTA is a release, not a peak.

For 60-second content, scale the same curve. Apex around 0:40, CTA from 0:50.

## Validating timing

Before declaring done, check:

1. Sum of `(end - start)` across all shots equals project duration ±0.1s
2. No shot has `start >= end`
3. No two shots overlap
4. First shot starts at 0.0
5. Last shot ends at project duration
6. Every text overlay's `enter.at` is ≥ its shot's `start`
7. Every text overlay's `exit.at` is ≤ its shot's `end` (or carries to a flagged successor shot)
8. Every text overlay's on-screen duration ≥ read-twice threshold

<!-- SOURCE_FILE_END: skills/storyboard-architect/references/timing-rules.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/templates/run.schema.json -->
# SOURCE FILE: `skills/storyboard-architect/templates/run.schema.json`

{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://whystrohm.com/schemas/shotkit/run.schema.json",
  "title": "Run",
  "description": "Written once at the start of a storyboard run and never edited. Pins every input by content hash, so six months later you can prove which brand-lock, shot list, and text spec a set of frames was produced against, rather than trusting that the files sitting next to them are the originals. Everything downstream (prompts, frames, critiques) is addressed by round and shot id under the output root, so no two operators write the same path. Validated by tools/validate_provenance.py.",
  "type": "object",
  "required": ["version", "run_id", "created_at", "shotkit_version", "project", "inputs"],
  "additionalProperties": false,
  "properties": {
    "version": { "type": "string", "const": "1.0" },
    "meta": {
      "type": "object",
      "description": "Forward-compat passthrough. Ignored by core skills.",
      "additionalProperties": true
    },
    "run_id": {
      "type": "string",
      "pattern": "^[0-9]{8}T[0-9]{6}Z-[0-9a-f]{8}$",
      "description": "UTC compact timestamp, a dash, then 8 hex characters. Example: 20260730T142300Z-9f2c1ab4. The hex suffix distinguishes two runs started in the same second by different operators."
    },
    "created_at": {
      "type": "string",
      "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$",
      "description": "UTC ISO-8601 instant the run started. Must agree with the timestamp embedded in run_id."
    },
    "shotkit_version": {
      "type": "string",
      "pattern": "^[0-9]+\\.[0-9]+\\.[0-9]+$",
      "description": "Version of shotkit that produced the run."
    },
    "operator": {
      "oneOf": [
        { "type": "null" },
        { "type": "string", "minLength": 1 }
      ],
      "description": "Who started the run. Free text: a name, a handle, or a CI job id. Null when nobody recorded it."
    },
    "project": {
      "type": "object",
      "required": ["title", "duration_s", "aspect"],
      "additionalProperties": false,
      "properties": {
        "title": { "type": "string", "minLength": 1 },
        "duration_s": { "type": "number", "exclusiveMinimum": 0 },
        "aspect": {
          "type": "string",
          "enum": ["16:9", "9:16", "1:1", "4:5", "21:9"]
        },
        "framework": { "type": "string", "minLength": 1 }
      }
    },
    "inputs": {
      "type": "object",
      "description": "Every file the run was built from, by path and by hash. Paths are relative to the output directory root.",
      "required": [
        "shots_ref", "shots_sha256",
        "text_overlays_ref", "text_overlays_sha256",
        "brand_lock_ref", "brand_lock_sha256", "brand_lock_source"
      ],
      "additionalProperties": false,
      "properties": {
        "shots_ref": { "type": "string", "minLength": 1 },
        "shots_sha256": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
        "text_overlays_ref": {
          "oneOf": [
            { "type": "null" },
            { "type": "string", "minLength": 1 }
          ],
          "description": "Null for a storyboard with no on-screen text."
        },
        "text_overlays_sha256": {
          "oneOf": [
            { "type": "null" },
            { "type": "string", "pattern": "^[0-9a-f]{64}$" }
          ]
        },
        "brand_lock_ref": { "type": "string", "minLength": 1 },
        "brand_lock_sha256": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
        "brand_lock_source": {
          "type": "string",
          "minLength": 1,
          "description": "Where the snapshot was copied from, e.g. 'brand-packs/whystrohm.md'. The literal string 'template default' records an UNCONFIGURED run built from brand-packs/_template.md."
        },
        "brand_lock_configured": {
          "type": "boolean",
          "description": "False when the snapshot is an unfilled template. tools/validate_brand_lock.py --require-configured is what decides this."
        }
      }
    },
    "generators": {
      "type": "array",
      "description": "Generators targeted by this run, with the model version current at run time. The capability matrix records what is current now; this records what was current then.",
      "items": {
        "type": "object",
        "required": ["id", "model_version"],
        "additionalProperties": false,
        "properties": {
          "id": { "type": "string", "pattern": "^[a-z0-9][a-z0-9-]*$" },
          "model_version": { "type": "string", "minLength": 1 },
          "capabilities_sha256": {
            "type": "string",
            "pattern": "^[0-9a-f]{64}$",
            "description": "SHA-256 of _capabilities.json as read, so a later matrix edit is detectable."
          }
        }
      }
    },
    "rounds": {
      "type": "array",
      "description": "Appended once per revision round. Each round records the prompt files it produced. Frames and critiques are found on disk under frames/round-N/ and critiques/round-N/, not listed here, so two operators working the same round never write the same JSON.",
      "items": {
        "type": "object",
        "required": ["round", "started_at", "prompts"],
        "additionalProperties": false,
        "properties": {
          "round": { "type": "integer", "minimum": 1 },
          "started_at": {
            "type": "string",
            "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$"
          },
          "reason": {
            "type": "string",
            "minLength": 1,
            "description": "Why this round exists. Round 1 is 'initial'. Later rounds cite the critiques that triggered them."
          },
          "prompts": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "object",
              "required": ["generator", "ref", "sha256"],
              "additionalProperties": false,
              "properties": {
                "generator": { "type": "string", "pattern": "^[a-z0-9][a-z0-9-]*$" },
                "ref": { "type": "string", "minLength": 1 },
                "sha256": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
                "shot_ids": {
                  "type": "array",
                  "items": { "type": "string", "pattern": "^shot_[0-9]{2,3}$" },
                  "description": "Which shots this file covers. A full pass lists every shot; a revision file lists only the shots it re-emitted."
                }
              }
            }
          },
          "post_only_shots": {
            "type": "array",
            "items": { "type": "string", "pattern": "^shot_[0-9]{2,3}$" },
            "description": "Shots whose only outstanding issues are post-level. They get no new prompt, so without this list the compositing obligation exists nowhere on disk."
          }
        }
      }
    }
  }
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/templates/run.schema.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/templates/shots.schema.json -->
# SOURCE FILE: `skills/storyboard-architect/templates/shots.schema.json`

{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://whystrohm.com/schemas/shotkit/shots.schema.json",
  "title": "Shots",
  "description": "Structured shot list for a storyboard. Versioned, audit-friendly, generator-agnostic. Write-once: the QA loop never mutates this file, so its hash in run.json stays valid for the life of the project. Cross-field rules this schema cannot express (end greater than start, shots tiling project.duration_s, on_screen_text resolving into text-overlays.json, overlay colors coming from the brand-lock palette) are enforced by tools/validate_shots.py.",
  "type": "object",
  "required": ["version", "project", "brand_lock_ref", "series_lock", "shots"],
  "additionalProperties": false,
  "properties": {
    "version": {
      "type": "string",
      "enum": ["1.0", "1.1", "1.2"],
      "description": "1.1 added optional shot.assets and top-level meta. 1.2 added content hashes and critique back-references to shot.assets.generated, and allows on_screen_text to be an array so a shot can carry more than one overlay. Backward compatible: every valid 1.0 file is a valid 1.2 file."
    },
    "meta": {
      "type": "object",
      "description": "Forward-compat passthrough for tooling that needs to annotate a storyboard without a schema bump. Ignored by core skills.",
      "additionalProperties": true
    },
    "project": {
      "type": "object",
      "required": ["title", "duration_s", "aspect"],
      "additionalProperties": false,
      "properties": {
        "title": { "type": "string", "minLength": 1 },
        "duration_s": { "type": "number", "exclusiveMinimum": 0 },
        "aspect": {
          "type": "string",
          "enum": ["16:9", "9:16", "1:1", "4:5", "21:9"]
        },
        "framework": {
          "type": "string",
          "description": "Beat framework name. e.g. 'pain-reframe-promise', 'hero-trilogy', 'founder-explainer', 'content-spiral', 'educational-demo', 'custom'"
        }
      }
    },
    "brand_lock_ref": {
      "type": "string",
      "minLength": 1,
      "description": "Path to brand-lock.snapshot.md, relative to the output directory root. The content hash of that file lives in run.json:inputs.brand_lock_sha256, which is what actually pins the brand state. This field alone is a name, not a proof."
    },
    "series_lock": {
      "type": "object",
      "required": ["character", "environment", "lighting", "color_grade"],
      "additionalProperties": false,
      "properties": {
        "character": { "type": "string", "minLength": 1 },
        "environment": { "type": "string", "minLength": 1 },
        "lighting": { "type": "string", "minLength": 1 },
        "color_grade": { "type": "string", "minLength": 1 }
      }
    },
    "shots": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "id", "beat", "start", "end",
          "framing", "angle", "motion",
          "subject", "rationale"
        ],
        "additionalProperties": false,
        "properties": {
          "id": {
            "type": "string",
            "pattern": "^shot_[0-9]{2,3}$"
          },
          "beat": { "type": "string", "minLength": 1 },
          "start": { "type": "number", "minimum": 0 },
          "end": {
            "type": "number",
            "exclusiveMinimum": 0,
            "description": "Must be greater than start. JSON Schema cannot compare two sibling properties, so tools/validate_shots.py enforces it."
          },
          "framing": {
            "type": "string",
            "enum": ["ECU", "CU", "MCU", "MS", "MLS", "WS", "EWS"]
          },
          "angle": {
            "type": "string",
            "enum": ["eye-level", "high", "low", "overhead", "dutch"]
          },
          "motion": {
            "type": "string",
            "enum": [
              "static", "push", "pull",
              "pan-left", "pan-right",
              "tilt-up", "tilt-down",
              "handheld", "orbit", "whip", "rack"
            ],
            "description": "Camera movement. 'rack' here means a rack focus used as the shot's motion. The identically named depth_of_field value describes the focus state instead."
          },
          "depth_of_field": {
            "type": "string",
            "enum": ["shallow", "deep", "rack"],
            "description": "Focus behaviour. 'rack' means focus shifts mid-shot."
          },
          "subject": { "type": "string", "minLength": 1 },
          "environment_ref": {
            "type": "string",
            "description": "Default 'series_lock.environment'. Override only with reason."
          },
          "lighting_ref": {
            "type": "string",
            "description": "Default 'series_lock.lighting'. Override only with reason."
          },
          "on_screen_text": {
            "oneOf": [
              { "type": "null" },
              { "type": "string", "pattern": "^text_[0-9]{2,3}$" },
              {
                "type": "array",
                "minItems": 1,
                "uniqueItems": true,
                "items": { "type": "string", "pattern": "^text_[0-9]{2,3}$" }
              }
            ],
            "description": "Overlay id, array of overlay ids for a shot carrying several, or null. Added the array form in 1.2: text-overlays.json has always allowed many overlays per shot, and a single string could not represent that."
          },
          "vo": {
            "oneOf": [
              { "type": "null" },
              { "type": "string", "minLength": 1 }
            ]
          },
          "rationale": { "type": "string", "minLength": 1 },
          "assets": {
            "type": "object",
            "description": "Optional. Frames associated with this shot. Read by tools/shots-to-html.py and tools/validate_provenance.py; both fall back to the frames/round-N/{shot_id}.{ext} path convention when this block is absent. Added in 1.1, given content hashes and critique back-references in 1.2.",
            "additionalProperties": false,
            "properties": {
              "source": {
                "type": "array",
                "description": "User-supplied images for this shot (skip generation). Paths relative to the output directory root.",
                "items": {
                  "oneOf": [
                    { "type": "string", "minLength": 1 },
                    {
                      "type": "object",
                      "required": ["path"],
                      "additionalProperties": false,
                      "properties": {
                        "path": { "type": "string", "minLength": 1 },
                        "sha256": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
                        "note": { "type": "string", "minLength": 1 }
                      }
                    }
                  ]
                }
              },
              "generated": {
                "type": "array",
                "items": {
                  "type": "object",
                  "required": ["path"],
                  "additionalProperties": false,
                  "properties": {
                    "path": {
                      "type": "string",
                      "minLength": 1,
                      "description": "Relative to the output directory root."
                    },
                    "sha256": {
                      "type": "string",
                      "pattern": "^[0-9a-f]{64}$",
                      "description": "SHA-256 of the frame. Without this, 'accepted' is an assertion about a filename."
                    },
                    "round": { "type": "integer", "minimum": 1 },
                    "generator": {
                      "type": "string",
                      "pattern": "^[a-z0-9][a-z0-9-]*$",
                      "description": "Must match an id in visual-prompt-forge/adapters/_capabilities.json."
                    },
                    "model_version": { "type": "string", "minLength": 1 },
                    "seed": {
                      "oneOf": [
                        { "type": "null" },
                        { "type": "integer" },
                        { "type": "string", "minLength": 1 }
                      ]
                    },
                    "prompt_ref": { "type": "string", "minLength": 1 },
                    "prompt_sha256": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
                    "critique_ref": {
                      "type": "string",
                      "minLength": 1,
                      "description": "Path to the critique.json that produced 'accepted'. An accepted frame with no critique_ref is an unsourced approval."
                    },
                    "accepted": { "type": "boolean" }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/templates/shots.schema.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/templates/storyboard.md.tpl -->
# SOURCE FILE: `skills/storyboard-architect/templates/storyboard.md.tpl`

# {{PROJECT_TITLE}}

| | |
|---|---|
| **Duration** | {{DURATION}}s |
| **Aspect** | {{ASPECT}} |
| **Beat framework** | {{FRAMEWORK}} |
| **Brand lock** | [`brand-lock.snapshot.md`](./brand-lock.snapshot.md) |
| **Generated** | {{TIMESTAMP}} |

---

## Brief

{{BRIEF_SUMMARY}}

## Series lock

| | |
|---|---|
| **Character anchor** | {{SERIES_CHARACTER}} |
| **Environment** | {{SERIES_ENVIRONMENT}} |
| **Lighting** | {{SERIES_LIGHTING}} |
| **Color grade** | {{SERIES_COLOR_GRADE}} |

---

## Shots

{{#each shots}}
### {{id}} · {{start}}–{{end}}s · {{framing}} · {{motion}}

**Beat:** {{beat}}

**Subject:** {{subject}}

**On-screen text:** {{on_screen_text_resolved}}

**VO:** {{vo}}

**Rationale:** {{rationale}}

---
{{/each}}

## Text overlays

{{#each overlays}}
### {{id}}: `{{shot_id}}`

> {{content}}

| | |
|---|---|
| **Font** | {{font}} {{weight}} |
| **Size** | {{size}} |
| **Position** | {{position}} |
| **Color** | `{{color}}` |
| **Enter** | {{enter.at}}s · {{enter.animation}} |
| **Exit** | {{exit.at}}s · {{exit.animation}} |
| **On-screen** | {{duration}}s |

{{/each}}

---

## Handoff notes

- **For image generation:** run `visual-prompt-forge` against `shots.json`
- **For HTML preview:** run `storyboard-html-preview` against this folder
- **For QA on generated frames:** run `visual-asset-critic` with the generated image and the shot ID

## Audit trail

This storyboard was generated against `brand-lock.snapshot.md` (frozen at {{TIMESTAMP}}). If the brand-lock changes after this date, re-run to pick up the new state.

<!-- SOURCE_FILE_END: skills/storyboard-architect/templates/storyboard.md.tpl -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/templates/text-overlays.schema.json -->
# SOURCE FILE: `skills/storyboard-architect/templates/text-overlays.schema.json`

{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://whystrohm.com/schemas/shotkit/text-overlays.schema.json",
  "title": "Text Overlays",
  "description": "On-screen text elements that get composited over generated images. Never baked into prompts.",
  "type": "object",
  "required": ["version", "overlays"],
  "additionalProperties": false,
  "properties": {
    "version": {
      "type": "string",
      "const": "1.0"
    },
    "overlays": {
      "type": "array",
      "items": {
        "type": "object",
        "required": [
          "id", "shot_id", "content",
          "font", "size", "weight", "color",
          "position", "enter", "exit"
        ],
        "additionalProperties": false,
        "properties": {
          "id": {
            "type": "string",
            "pattern": "^text_[0-9]{2,3}$"
          },
          "shot_id": {
            "oneOf": [
              { "type": "string", "pattern": "^shot_[0-9]{2,3}$" },
              {
                "type": "array",
                "minItems": 2,
                "items": { "type": "string", "pattern": "^shot_[0-9]{2,3}$" }
              }
            ],
            "description": "Single shot ID, or array of consecutive shot IDs for persistent overlays."
          },
          "content": { "type": "string", "minLength": 1 },
          "font": {
            "type": "string",
            "description": "Must reference a font defined in brand-lock typography."
          },
          "size": {
            "type": "string",
            "enum": ["display", "headline", "body", "caption"]
          },
          "weight": {
            "type": "string",
            "enum": ["regular", "medium", "bold", "black"]
          },
          "color": {
            "type": "string",
            "pattern": "^#[0-9A-Fa-f]{6}$",
            "description": "Hex value. Must come from brand-lock palette."
          },
          "position": {
            "oneOf": [
              {
                "type": "string",
                "enum": [
                  "center",
                  "lower-third", "upper-third",
                  "left-third", "right-third"
                ]
              },
              {
                "type": "object",
                "required": ["x", "y"],
                "additionalProperties": false,
                "properties": {
                  "x": { "type": "number", "minimum": 0, "maximum": 100 },
                  "y": { "type": "number", "minimum": 0, "maximum": 100 }
                }
              }
            ]
          },
          "enter": {
            "type": "object",
            "required": ["at", "animation"],
            "additionalProperties": false,
            "properties": {
              "at": { "type": "number", "minimum": 0 },
              "animation": {
                "type": "string",
                "enum": ["fade-in", "slide-up", "slide-down", "type-on", "hard-cut"]
              }
            }
          },
          "exit": {
            "type": "object",
            "required": ["at", "animation"],
            "additionalProperties": false,
            "properties": {
              "at": { "type": "number", "minimum": 0 },
              "animation": {
                "type": "string",
                "enum": ["fade-out", "slide-up", "slide-down", "hard-cut"]
              }
            }
          }
        }
      }
    }
  }
}

<!-- SOURCE_FILE_END: skills/storyboard-architect/templates/text-overlays.schema.json -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/README.md -->
# SOURCE FILE: `skills/storyboard-architect/tools/README.md`

# Tools

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

## Requirements

```bash
pip install pyyaml jsonschema
```

Standard library otherwise. No pandas, no numpy.

## Run everything

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

This is exactly what CI runs, so a green local run means a green PR.

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

## Repo checks

### `validate_skills.py`

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

```bash
python tools/validate_skills.py
```

### `validate_schemas.py`

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

```bash
python tools/validate_schemas.py
```

It validates schemas, not instances. For instances, see `validate_shots.py`.

### `validate_capabilities.py`

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

- every generator id has an adapter `.md` and every adapter `.md` has an entry
- no adapter advertises more words than its own `max_prompt_words` ceiling
- every adapter documents the `aspect_param` the matrix says to send
- no `notes` field cites a word count above its own ceiling
- warns when the matrix or an entry is past its 120-day freshness window

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

### `validate_brand_lock.py`

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

## Project checks

These run against a project's output directory, not the repo.

### `validate_shots.py`

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

### `validate_prompts.py`

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

### `validate_critique.py`

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

### `validate_provenance.py`

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

It catches, with a selftest for each:

- a frame regenerated after its critique (`image_sha256` no longer matches)
- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)
- a frame on disk with no critique for its round, never reviewed at all
- two critiques for the same shot in the same round, two operators colliding
- rounds that skip a number, or a critique whose `run_id` belongs to another run

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

## Rendering

### `shots-to-html.py`

Renders an output folder into a single `preview.html`.

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

### `copy-prompt.py`

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

## Internal modules

Not entry points. Imported by the tools above.

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.
- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

## Adding new tools

- Make it executable (`chmod +x`)
- Add a usage docstring at the top of the file
- Give it a `--selftest` that proves the check fires
- Document it in this README
- Wire it into `tools/check.sh`, which is what CI calls

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/README.md -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/_shotkit.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/_shotkit.py`

#!/usr/bin/env python3
"""
Shared helpers for the shotkit tools. Standard library only.

Everything here exists because more than one tool needs it. Hashing, brand-lock
parsing, and the capability-id list were duplicated or absent before; keeping one
copy is what stops the tools from disagreeing about what a brand-lock palette is
or which generator ids are real.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

CAPABILITIES_PATH = (
    REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters" / "_capabilities.json"
)

# Roles tools/shots-to-html.py maps onto CSS variables. Documented in
# docs/brand-lock-anatomy.md so a brand-lock author knows the names are load-bearing.
PALETTE_ROLES = ("background", "ink", "accent", "muted", "rule")

RUN_ID_RE = re.compile(r"^([0-9]{8}T[0-9]{6}Z)-[0-9a-f]{8}$")
ISO_INSTANT_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SHOT_ID_RE = re.compile(r"^shot_[0-9]{2,3}$")
TEXT_ID_RE = re.compile(r"^text_[0-9]{2,3}$")

HEX_RE = re.compile(r"#[0-9A-Fa-f]{6}")
PLACEHOLDER_HEX_RE = re.compile(r"#_{6}")

# | Role | `#RRGGBB` | Use | rows in a brand-lock Palette table.
PALETTE_ROW_RE = re.compile(
    r"^\|\s*([A-Za-z][A-Za-z0-9\s()/-]*?)\s*\|\s*`?(#(?:[0-9A-Fa-f]{6}|_{6}))`?\s*\|"
)

SNAPSHOT_TAKEN_RE = re.compile(r"<!--\s*snapshot taken:\s*(.+?)\s*-->")
SNAPSHOT_SOURCE_RE = re.compile(r"<!--\s*source:\s*(.+?)\s*-->")

IMAGE_EXTS = ("png", "jpg", "jpeg", "webp")


# --------------------------------------------------------------------------
# Hashing
# --------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    """SHA-256 of a file's bytes, read in chunks so large frames do not load whole."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    """SHA-256 of a string, UTF-8 encoded."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# Run identity
# --------------------------------------------------------------------------

def make_run_id(now: datetime | None = None, nonce: str | None = None) -> str:
    """Build a run_id. Pass `now` and `nonce` to make it reproducible in tests."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    if nonce is None:
        nonce = sha256_text(now.isoformat() + str(id(now)))[:8]
    return f"{stamp}-{nonce}"


def iso_instant(now: datetime | None = None) -> str:
    """UTC ISO-8601 to second precision with a trailing Z."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def run_id_timestamp(run_id: str) -> str | None:
    """Extract the compact timestamp from a run_id, or None if malformed."""
    m = RUN_ID_RE.match(run_id or "")
    return m.group(1) if m else None


# --------------------------------------------------------------------------
# JSON loading
# --------------------------------------------------------------------------

def load_json(path: Path) -> tuple[dict | list | None, str | None]:
    """Return (data, error). Exactly one of the two is None."""
    if not path.exists():
        return (None, f"file does not exist: {path}")
    try:
        return (json.loads(path.read_text(encoding="utf-8")), None)
    except json.JSONDecodeError as e:
        return (None, f"invalid JSON: {e}")
    except OSError as e:
        return (None, f"cannot read: {e}")


# --------------------------------------------------------------------------
# Capability matrix
# --------------------------------------------------------------------------

def capability_ids(caps_path: Path | None = None) -> set[str]:
    """Generator ids from the capability matrix. Empty set if it cannot be read."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return set()
    return {
        g["id"]
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


def capability_map(caps_path: Path | None = None) -> dict[str, dict]:
    """Generator id to its full capability entry."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return {}
    return {
        g["id"]: g
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


# --------------------------------------------------------------------------
# Brand-lock parsing
# --------------------------------------------------------------------------

def parse_palette(text: str) -> dict[str, str]:
    """Role (lowercased) to hex value, from a brand-lock Palette table."""
    palette: dict[str, str] = {}
    for line in text.splitlines():
        m = PALETTE_ROW_RE.match(line)
        if m:
            palette[m.group(1).strip().lower()] = m.group(2).strip()
    return palette


def palette_hexes(text: str) -> set[str]:
    """Every real (non-placeholder) hex in a brand-lock, lowercased."""
    return {h.lower() for h in HEX_RE.findall(text)}


def is_unconfigured(text: str) -> bool:
    """True when the brand-lock still carries template placeholders in its palette."""
    return bool(PLACEHOLDER_HEX_RE.search(text))


def parse_typography(text: str) -> dict[str, str | None]:
    """
    Pull font names out of a brand-lock Typography section.

    Matches the documented format:
        **Display font:** `Inter Black 900`, headline weight, ...
        **Body font:** `Inter Medium 500`, body copy, ...
        **Mono font:** `JetBrains Mono Regular`, code, data, ...

    Mono is optional. A brand-lock that declares one has three legal overlay fonts,
    not two, which is why the font check reads all three rather than assuming a pair.
    """
    out: dict[str, str | None] = {
        "display_font": None,
        "body_font": None,
        "mono_font": None,
    }
    # The value has to be backticked and sit immediately after the label. That is what
    # separates a real declaration from the template's instructional prose
    # ("**Display font:** font name, weights used (e.g. `Inter Black 900`)"), which
    # would otherwise resolve to the example font.
    for key, label in (
        ("display_font", "Display"),
        ("body_font", "Body"),
        ("mono_font", "Mono"),
    ):
        pattern = re.compile(
            r"^\*\*" + label + r"\s+font[^:*]*:?\*\*[ \t]*`([^`\n]+)`",
            re.IGNORECASE | re.MULTILINE,
        )
        m = pattern.search(text)
        if m:
            value = m.group(1).strip()
            if value and not value.startswith("_"):
                out[key] = value
    return out


def parse_snapshot_header(text: str) -> dict[str, str | None]:
    """The two provenance comments storyboard-architect writes at the top of a snapshot."""
    taken = SNAPSHOT_TAKEN_RE.search(text)
    source = SNAPSHOT_SOURCE_RE.search(text)
    return {
        "snapshot_taken": taken.group(1).strip() if taken else None,
        "source": source.group(1).strip() if source else None,
    }


# --------------------------------------------------------------------------
# Output-tree conventions
# --------------------------------------------------------------------------

def round_dirs(output_dir: Path, kind: str) -> list[tuple[int, Path]]:
    """
    Sorted (round_number, path) for output_dir/<kind>/round-N directories.

    `kind` is 'frames', 'critiques', or 'prompts'.
    """
    base = output_dir / kind
    if not base.is_dir():
        return []
    found: list[tuple[int, Path]] = []
    for child in base.iterdir():
        if child.is_dir() and child.name.startswith("round-"):
            suffix = child.name[len("round-"):]
            if suffix.isdigit():
                found.append((int(suffix), child))
    return sorted(found)


def find_frame(output_dir: Path, shot_id: str, round_no: int | None = None) -> Path | None:
    """
    Locate a frame for a shot by the path convention.

    Prefers the highest-numbered round under frames/, then falls back to the
    legacy flat generated/ directory so pre-3.0.0 projects still render.
    """
    candidates = round_dirs(output_dir, "frames")
    if round_no is not None:
        candidates = [(n, p) for n, p in candidates if n == round_no]
    for _, directory in reversed(candidates):
        for ext in IMAGE_EXTS:
            candidate = directory / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    legacy = output_dir / "generated"
    if legacy.is_dir():
        for ext in IMAGE_EXTS:
            candidate = legacy / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    return None


def critique_paths(output_dir: Path) -> list[Path]:
    """
    Every critique file in an output tree, newest layout first.

    New layout: critiques/round-N/shot_NN.critique.json
    Legacy:     critique.json at the output root
    """
    found: list[Path] = []
    for _, directory in round_dirs(output_dir, "critiques"):
        found.extend(sorted(directory.glob("*.critique.json")))
        found.extend(sorted(directory.glob("*.json")))
    legacy = output_dir / "critique.json"
    if legacy.exists():
        found.append(legacy)
    # Preserve order, drop duplicates from the two globs above.
    seen: set[Path] = set()
    unique: list[Path] = []
    for path in found:
        resolved = path.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(path)
    return unique


def as_overlay_ids(value) -> list[str]:
    """Normalise shots.json on_screen_text (null, string, or array) to a list."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []


def as_shot_ids(value) -> list[str]:
    """Normalise text-overlays.json shot_id (string or array) to a list."""
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/_shotkit.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/_template.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/_template.py`

#!/usr/bin/env python3
"""
The small template engine tools/shots-to-html.py renders preview.html.tpl with.

Only the subset the template actually uses is implemented, deliberately: variable
substitution, a loop, and a truthiness block. It exists so the CLI and the
storyboard-html-preview skill render the same structural template instead of two
hand-maintained copies that drift apart.

Supported syntax:
    {{name}}            HTML-escaped substitution
    {{{name}}}          raw substitution, for pre-built markup such as inlined CSS
    {{#each items}}     iterate a list of dicts; inside the block, keys resolve
    {{/each}}           against the item first, then the enclosing context
    {{#if name}}        render when the value is truthy
    {{/if}}

Unknown names render empty rather than raising, which keeps a partially populated
context from producing a traceback in front of a client.
"""

from __future__ import annotations

import html
import re

BLOCK_RE = re.compile(r"\{\{#(each|if)\s+([A-Za-z0-9_]+)\s*\}\}")
RAW_VAR_RE = re.compile(r"\{\{\{\s*([A-Za-z0-9_]+)\s*\}\}\}")
VAR_RE = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")


def escape(value) -> str:
    """HTML-escape a value for text and attribute contexts, including quotes."""
    if value is None or value is False:
        return ""
    if value is True:
        return "true"
    return html.escape(str(value), quote=True)


def _find_block_end(text: str, kind: str, start: int) -> int:
    """Index of the closing tag matching the block opened before `start`."""
    open_re = re.compile(r"\{\{#" + kind + r"\s+[A-Za-z0-9_]+\s*\}\}")
    close_tag = "{{/" + kind + "}}"
    depth = 1
    pos = start
    while depth:
        next_close = text.find(close_tag, pos)
        if next_close == -1:
            raise ValueError(f"unclosed {{{{#{kind}}}}} block")
        next_open = open_re.search(text, pos, next_close)
        if next_open:
            depth += 1
            pos = next_open.end()
            continue
        depth -= 1
        pos = next_close + len(close_tag)
    return pos


def render(template: str, context: dict) -> str:
    """Render `template` against `context`."""
    out: list[str] = []
    pos = 0

    while pos < len(template):
        block = BLOCK_RE.search(template, pos)
        if not block:
            out.append(_render_leaf(template[pos:], context))
            break

        out.append(_render_leaf(template[pos : block.start()], context))
        kind, name = block.group(1), block.group(2)
        body_start = block.end()
        block_end = _find_block_end(template, kind, body_start)
        close_len = len("{{/" + kind + "}}")
        body = template[body_start : block_end - close_len]

        value = context.get(name)
        if kind == "each":
            for item in value or []:
                scoped = dict(context)
                if isinstance(item, dict):
                    scoped.update(item)
                else:
                    scoped["this"] = item
                out.append(render(body, scoped))
        else:
            if value:
                out.append(render(body, context))

        pos = block_end

    return "".join(out)


def _render_leaf(text: str, context: dict) -> str:
    """Substitute variables in a chunk with no block tags left in it."""
    text = RAW_VAR_RE.sub(lambda m: str(context.get(m.group(1), "") or ""), text)
    return VAR_RE.sub(lambda m: escape(context.get(m.group(1))), text)

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/_template.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/check.sh -->
# SOURCE FILE: `skills/storyboard-architect/tools/check.sh`

#!/usr/bin/env bash
# Run every shotkit check. This is what CI calls, so a green local run means a green PR.
#
# Usage:
#   ./tools/check.sh            # run everything, report a summary
#   ./tools/check.sh --quiet    # only print failures and the summary
#
# Requires: pip install pyyaml jsonschema

set -uo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.." || exit 1

PYTHON="${PYTHON:-python3}"
QUIET=0
[[ "${1:-}" == "--quiet" ]] && QUIET=1

PASSED=0
FAILED=0
FAILED_NAMES=()

run() {
  local label="$1"
  shift
  local output
  if output=$("$PYTHON" "$@" 2>&1); then
    PASSED=$((PASSED + 1))
    if [[ "$QUIET" == "0" ]]; then
      echo "PASS  ${label}"
      sed 's/^/      /' <<<"$output"
      echo
    else
      echo "PASS  ${label}"
    fi
  else
    FAILED=$((FAILED + 1))
    FAILED_NAMES+=("$label")
    echo "FAIL  ${label}"
    sed 's/^/      /' <<<"$output"
    echo
  fi
}

echo "shotkit checks, using $("$PYTHON" --version 2>&1)"
echo

# Preflight the two dependencies. Without this, a missing package turns one actionable
# line into fourteen identical failures and you have to read all of them to find out.
missing=""
"$PYTHON" -c 'import yaml' 2>/dev/null || missing="pyyaml"
"$PYTHON" -c 'import jsonschema' 2>/dev/null || missing="${missing:+$missing }jsonschema"
if [[ -n "$missing" ]]; then
  echo "Missing Python package(s): ${missing}" >&2
  echo >&2
  echo "  ${PYTHON} -m pip install ${missing}" >&2
  echo >&2
  echo "Then re-run ./tools/check.sh" >&2
  exit 1
fi

# Structure and schemas
run "skills: frontmatter"            tools/validate_skills.py
run "schemas: are valid schemas"     tools/validate_schemas.py

# Capability matrix, including prose parity with the adapter files
run "capabilities: selftest"         tools/validate_capabilities.py --selftest
run "capabilities: matrix"           tools/validate_capabilities.py

# Brand-locks: packs allow templates, snapshots do not
run "brand-lock: selftest"           tools/validate_brand_lock.py --selftest
run "brand-lock: packs"              tools/validate_brand_lock.py \
  brand-packs/_template.md \
  brand-packs/whystrohm.md \
  brand-packs/examples/saas-clean.md \
  skills/brand-lock-extractor/examples/brand-lock.md
run "brand-lock: snapshots"          tools/validate_brand_lock.py --snapshots

# Storyboard instances, the rules JSON Schema cannot express
run "shots: selftest"                tools/validate_shots.py --selftest
run "shots: bundled examples"        tools/validate_shots.py --examples
run "shots: worked run"              tools/validate_shots.py \
  skills/visual-asset-critic/examples/worked-run

# Prompt files: the forge's hard rules, including verbatim series_lock anchors
run "prompts: selftest"              tools/validate_prompts.py --selftest
run "prompts: worked run"            tools/validate_prompts.py --examples

# Critique gate
run "critique: selftest"             tools/validate_critique.py --selftest
run "critique: fixtures"             tools/validate_critique.py --examples

# Provenance chain
run "provenance: selftest"           tools/validate_provenance.py --selftest
run "provenance: worked run"         tools/validate_provenance.py --examples --require-accept

# Tools that ship as part of the workflow
run "preview renderer: selftest"     tools/shots-to-html.py --selftest
run "prompt helper: selftest"        tools/copy-prompt.py --selftest

echo "─────────────────────────────────────────"
echo "${PASSED} passed, ${FAILED} failed"
if ((FAILED)); then
  printf 'failed: %s\n' "${FAILED_NAMES[@]}"
  exit 1
fi
exit 0

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/check.sh -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/copy-prompt.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/copy-prompt.py`

#!/usr/bin/env python3
"""Copy a shot prompt from a shotkit prompts file to the system clipboard.

Handles both file shapes the forge writes: a full pass, and a revision file where each
shot block carries `# fix [...]` annotations above the prompt. Comment lines inside a
block are treated as annotations and never land in the clipboard, so what you paste
into a generator is the prompt and nothing else.

Usage:
  python tools/copy-prompt.py output/prompts/round-1/flux.txt
  python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
  python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
  python tools/copy-prompt.py --selftest
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

# A shot block opens with the shot id near the start of a comment line. The forge's
# revision format prefixes it, so both of these are headers:
#   # shot_03, reframe, 11.0-16.0s, MCU eye-level push
#   # shot_03, promise, 3.0-8.0s, MCU eye-level push, revision (was REVISE)
#   # Revision of shot_03 (was REVISE)
SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT_LINE = re.compile(r"^\s*#")


class Block:
    __slots__ = ("shot_id", "header", "annotations", "body")

    def __init__(self, shot_id: str, header: str) -> None:
        self.shot_id = shot_id
        self.header = header
        self.annotations: list[str] = []
        self.body: list[str] = []

    def prompt(self) -> str:
        return "\n".join(self.body).strip()

    def label(self) -> str:
        note = f"  [{len(self.annotations)} fix note(s)]" if self.annotations else ""
        return f"{self.header}{note}  ({len(self.prompt())} chars)"


def get_clipboard_command() -> list[str] | None:
    """Return the platform-appropriate clipboard command, or None if unavailable."""
    if sys.platform == "darwin":
        return ["pbcopy"]
    if sys.platform.startswith("linux"):
        if shutil.which("xclip"):
            return ["xclip", "-selection", "clipboard"]
        if shutil.which("xsel"):
            return ["xsel", "--clipboard", "--input"]
        return None
    if sys.platform == "win32":
        return ["clip"]
    return None


def parse_prompt_text(text: str) -> list[Block]:
    """Split a prompt file into shot blocks, separating annotations from prompt body."""
    blocks: list[Block] = []
    current: Block | None = None

    for line in text.splitlines():
        match = SHOT_HEADER.match(line)
        if match:
            current = Block(match.group(1), line.strip())
            blocks.append(current)
            continue
        if current is None:
            continue  # file-level header comments, before the first shot block
        if COMMENT_LINE.match(line):
            current.annotations.append(line.strip())
        else:
            current.body.append(line)

    return [b for b in blocks if b.prompt()]


def parse_prompt_file(path: Path) -> list[Block]:
    return parse_prompt_text(path.read_text(encoding="utf-8"))


def copy_to_clipboard(text: str) -> bool:
    cmd = get_clipboard_command()
    if not cmd:
        return False
    proc = subprocess.run(cmd, input=text.encode("utf-8"))
    return proc.returncode == 0


def print_clipboard_help() -> None:
    if sys.platform.startswith("linux"):
        print("No clipboard utility found. Install xclip or xsel.", file=sys.stderr)
    else:
        print("No clipboard utility found on this platform.", file=sys.stderr)


def list_blocks(blocks: list[Block]) -> None:
    for i, block in enumerate(blocks, 1):
        print(f"{i}. {block.label()}")
        for note in block.annotations:
            print(f"     {note}")


def select_interactively(blocks: list[Block]) -> Block | None:
    list_blocks(blocks)
    try:
        raw = input(f"\nWhich shot? (1-{len(blocks)}): ").strip()
        idx = int(raw) - 1
    except (ValueError, EOFError):
        print("Invalid selection.", file=sys.stderr)
        return None
    if not (0 <= idx < len(blocks)):
        print("Selection out of range.", file=sys.stderr)
        return None
    return blocks[idx]


STANDARD_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Aspect: 9:16

# shot_01, hook, 0.0-2.0s, MCU eye-level static
first prompt body

# shot_02, pain, 2.0-6.0s, MS eye-level push
second prompt body
"""

REVISION_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Round: 2
# Revision of round 1. Shots not listed here already passed.

# shot_02, pain, 2.0-6.0s, MCU eye-level push, revision (was REVISE)
# fix [Shot Spec, major]: framing MS -> MCU
# fix [Technical, re-roll]: hand was malformed
revised prompt body
"""

LEGACY_REVISION_FIXTURE = """\
# Revision of shot_03 (was REVISE)
# fix [Series Lock, major]: added 'salt-and-pepper hair' to the character anchor
legacy revised prompt body
"""


def selftest() -> int:
    ok = True

    cases = [
        ("standard file yields both shots", STANDARD_FIXTURE, ["shot_01", "shot_02"]),
        ("revision file yields its shot", REVISION_FIXTURE, ["shot_02"]),
        ("legacy revision header is tolerated", LEGACY_REVISION_FIXTURE, ["shot_03"]),
    ]
    for label, fixture, expected in cases:
        got = [b.shot_id for b in parse_prompt_text(fixture)]
        if got == expected:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> expected {expected}, got {got}")
            ok = False

    blocks = parse_prompt_text(REVISION_FIXTURE)
    body = blocks[0].prompt()
    if body == "revised prompt body":
        print("  ok    selftest: fix annotations stay out of the copied prompt")
    else:
        print(f"  FAIL  selftest: prompt body was {body!r}")
        ok = False
    if len(blocks[0].annotations) == 2:
        print("  ok    selftest: fix annotations are captured for display")
    else:
        print(f"  FAIL  selftest: expected 2 annotations, got {blocks[0].annotations}")
        ok = False

    header_only = parse_prompt_text("# Storyboard: x\n# Generator: flux\n")
    if header_only == []:
        print("  ok    selftest: a file with no shot blocks yields nothing")
    else:
        print(f"  FAIL  selftest: expected no blocks, got {header_only}")
        ok = False

    # The shipped worked run must be readable by this tool, both rounds.
    repo_root = Path(__file__).resolve().parent.parent
    worked = repo_root / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    for rel, expected in (
        ("prompts/round-1/flux.txt", ["shot_01", "shot_02"]),
        ("prompts/round-2/revised-flux.txt", ["shot_02"]),
    ):
        path = worked / rel
        if not path.exists():
            print(f"  FAIL  selftest: bundled fixture missing: {rel}")
            ok = False
            continue
        got = [b.shot_id for b in parse_prompt_file(path)]
        if got == expected:
            print(f"  ok    selftest: bundled {rel} parses")
        else:
            print(f"  FAIL  selftest: bundled {rel} -> expected {expected}, got {got}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Copy a shot prompt from a shotkit prompts file to the clipboard."
    )
    parser.add_argument(
        "file",
        nargs="?",
        type=Path,
        help="Path to a prompt file (e.g. output/prompts/round-1/flux.txt)",
    )
    parser.add_argument(
        "--shot", help="Shot ID to copy (e.g. shot_03). If omitted, prompts interactively."
    )
    parser.add_argument(
        "--list", action="store_true", help="List shots and exit. Does not copy."
    )
    parser.add_argument(
        "--selftest", action="store_true", help="Prove both file shapes parse"
    )
    args = parser.parse_args()

    if args.selftest:
        return selftest()
    if args.file is None:
        parser.error("file is required unless --selftest is given")

    if not args.file.exists():
        print(f"File not found: {args.file}", file=sys.stderr)
        return 1

    blocks = parse_prompt_file(args.file)
    if not blocks:
        print(f"No shot blocks found in {args.file}.", file=sys.stderr)
        print(
            "Expected a comment line naming a shot, e.g. "
            "'# shot_03, beat, timing, framing'.",
            file=sys.stderr,
        )
        return 1

    if args.list:
        list_blocks(blocks)
        return 0

    if args.shot:
        matches = [b for b in blocks if b.shot_id == args.shot]
        if not matches:
            print(f'Shot "{args.shot}" not found in {args.file}.', file=sys.stderr)
            print("Available shots:", file=sys.stderr)
            for block in blocks:
                print(f"  {block.shot_id}", file=sys.stderr)
            return 1
        if len(matches) > 1:
            print(
                f'Shot "{args.shot}" appears {len(matches)} times in {args.file}; '
                f"copying the last block.",
                file=sys.stderr,
            )
        selection = matches[-1]
    else:
        result = select_interactively(blocks)
        if result is None:
            return 1
        selection = result

    body = selection.prompt()
    if copy_to_clipboard(body):
        print(f"Copied {selection.shot_id} prompt to clipboard ({len(body)} chars).")
        for note in selection.annotations:
            print(f"  {note}")
        return 0

    print_clipboard_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/copy-prompt.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/shots-to-html.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/shots-to-html.py`

#!/usr/bin/env python3
"""
Standalone helper: render an output folder into a single preview.html.

Renders skills/storyboard-html-preview/templates/preview.html.tpl, the same
structural template the storyboard-html-preview skill uses, so the two cannot drift.
All interpolated content is HTML-escaped: subjects, rationales, and VO lines are
model-generated prose, and one angle bracket in a rationale used to break the page a
client was looking at.

Two timestamps, deliberately distinct. "Run" is when the storyboard was produced, read
from run.json. "Rendered" is when this page was written. Collapsing them into one
"Generated" date meant re-rendering a preview six months later silently restamped the
run as today.

Usage:
    python tools/shots-to-html.py path/to/output-folder
    python tools/shots-to-html.py path/to/output-folder --out preview.html
    python tools/shots-to-html.py path/to/output-folder --inline-images
    python tools/shots-to-html.py path/to/output-folder --rendered-at 2026-07-30T00:00:00Z
    python tools/shots-to-html.py --selftest
"""

from __future__ import annotations

import argparse
import base64
import sys
from pathlib import Path

from _shotkit import (
    IMAGE_EXTS,
    PALETTE_ROLES,
    REPO_ROOT,
    as_overlay_ids,
    find_frame,
    iso_instant,
    load_json,
    parse_palette,
    parse_typography,
    round_dirs,
    sha256_file,
)
from _template import escape, render

TEMPLATE_DIR = REPO_ROOT / "skills" / "storyboard-html-preview" / "templates"

FALLBACK_BRAND = {
    "bg": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
    "display_font": "Inter",
    "body_font": "Inter",
}

FALLBACK_HEX = {
    "background": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
}


def read_template(name: str) -> str:
    return (TEMPLATE_DIR / name).read_text(encoding="utf-8")


def parse_brand_lock(path: Path) -> tuple[dict, list[str]]:
    """
    Pull palette and typography out of a brand-lock.

    Returns (values, warnings). Warnings name every role that fell back to a generic
    default, because a preview that quietly renders in someone else's blue is worse
    than one that tells you the palette did not parse.
    """
    if not path.exists():
        return (dict(FALLBACK_BRAND), [f"brand-lock not found at {path.name}"])

    text = path.read_text(encoding="utf-8")
    palette = parse_palette(text)
    warnings: list[str] = []

    def pick(role: str) -> str:
        # Exact role first, then any role containing it, e.g. "accent (warm)".
        if role in palette and not palette[role].startswith("#_"):
            return palette[role]
        for name, hex_val in palette.items():
            if role in name and not hex_val.startswith("#_"):
                return hex_val
        warnings.append(
            f"palette role '{role}' not found in the brand-lock, using a generic default"
        )
        return FALLBACK_HEX[role]

    values = {
        "bg": pick("background"),
        "ink": pick("ink"),
        "accent": pick("accent"),
        "muted": pick("muted"),
        "rule": pick("rule"),
    }

    fonts = parse_typography(text)
    values["display_font"] = fonts.get("display_font") or FALLBACK_BRAND["display_font"]
    values["body_font"] = fonts.get("body_font") or FALLBACK_BRAND["body_font"]
    for key in ("display_font", "body_font"):
        if not fonts.get(key):
            warnings.append(
                f"brand-lock declares no {key.replace('_', ' ')}, using "
                f"{FALLBACK_BRAND[key]}"
            )

    return (values, warnings)


def aspect_class(aspect: str) -> str:
    return "aspect-" + str(aspect).replace(":", "-")


def encode_image_b64(path: Path) -> str:
    ext = path.suffix.lstrip(".").lower()
    mime = {
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
    }.get(ext, "image/png")
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def frame_for_shot(out_dir: Path, shot: dict) -> tuple[Path | None, str | None]:
    """
    Resolve a shot's frame, preferring what the data says over what the tree implies.

    Order: an accepted entry in shot.assets.generated, then the newest entry there,
    then the frames/round-N path convention, then the legacy generated/ directory.
    Returns (path, note) where note explains a non-obvious pick.
    """
    generated = (shot.get("assets") or {}).get("generated") or []
    accepted = [g for g in generated if g.get("accepted") is True and g.get("path")]
    pool = accepted or [g for g in generated if g.get("path")]
    if pool:
        chosen = max(pool, key=lambda g: g.get("round") or 0)
        path = out_dir / chosen["path"]
        if path.exists():
            note = None
            if chosen.get("sha256"):
                actual = sha256_file(path)
                if actual != chosen["sha256"]:
                    note = "frame has changed since it was recorded in shots.json"
            elif not accepted:
                note = "frame is not marked accepted"
            return (path, note)
        return (None, f"assets names {chosen['path']}, which is missing on disk")

    found = find_frame(out_dir, shot["id"])
    if found is None:
        return (None, None)
    return (found, None)


def latest_verdicts(out_dir: Path) -> dict[str, dict]:
    """Newest verdict per shot, read from the critique tree. Empty when there is none."""
    verdicts: dict[str, dict] = {}
    for round_no, directory in round_dirs(out_dir, "critiques"):
        for path in sorted(directory.glob("*.json")):
            data, err = load_json(path)
            if err or not isinstance(data, dict):
                continue
            shot_id = data.get("shot_id")
            if not shot_id:
                continue
            current = verdicts.get(shot_id)
            if current is None or round_no >= current["round"]:
                verdicts[shot_id] = {
                    "round": round_no,
                    "verdict": data.get("verdict"),
                }
    legacy, err = load_json(out_dir / "critique.json")
    if not err and isinstance(legacy, dict) and legacy.get("shot_id"):
        verdicts.setdefault(
            legacy["shot_id"],
            {"round": legacy.get("round") or 1, "verdict": legacy.get("verdict")},
        )
    return verdicts


def position_class(position) -> str:
    """Named positions map to a CSS class; explicit coordinates fall back to center."""
    if isinstance(position, str):
        return position
    return "center"


def position_label(position) -> str:
    if isinstance(position, dict):
        return f"x{position.get('x')}% y{position.get('y')}%"
    return str(position)


def build_context(out_dir: Path, args) -> tuple[dict, list[str]]:
    warnings: list[str] = []

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        raise SystemExit(f"ERROR: {err}")

    overlays_data, ov_err = load_json(out_dir / "text-overlays.json")
    if ov_err:
        overlays_data = {"overlays": []}
    overlays_by_id = {
        o["id"]: o for o in (overlays_data or {}).get("overlays", []) if o.get("id")
    }

    project = shots_data["project"]
    series = shots_data["series_lock"]
    shots = shots_data["shots"]
    aspect = project["aspect"]

    brand_ref = shots_data.get("brand_lock_ref") or "brand-lock.snapshot.md"
    brand_path = out_dir / brand_ref
    brand, brand_warnings = parse_brand_lock(brand_path)
    warnings.extend(brand_warnings)

    run_doc, run_err = load_json(out_dir / "run.json")
    if run_err or not isinstance(run_doc, dict):
        run_doc = {}
        warnings.append(
            "no run.json in this output tree, so the page cannot state when the run "
            "happened or which inputs it used"
        )

    verdicts = latest_verdicts(out_dir)
    provenance_notes: list[str] = []

    shot_contexts = []
    for shot in shots:
        frame_path, frame_note = frame_for_shot(out_dir, shot)
        if frame_note:
            provenance_notes.append(f"{shot['id']}: {frame_note}")
            warnings.append(f"{shot['id']}: {frame_note}")

        image_path = None
        if frame_path is not None:
            if args.inline_images:
                image_path = encode_image_b64(frame_path)
            else:
                try:
                    image_path = str(frame_path.relative_to(out_dir))
                except ValueError:
                    image_path = frame_path.name

        overlays = []
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            overlay = overlays_by_id.get(oid)
            if overlay is None:
                warnings.append(
                    f"{shot['id']} references overlay {oid}, which is not in "
                    f"text-overlays.json"
                )
                continue
            overlays.append(
                {
                    "id": overlay["id"],
                    "content": overlay.get("content"),
                    "font": overlay.get("font"),
                    "weight": overlay.get("weight"),
                    "color": overlay.get("color"),
                    "size": overlay.get("size"),
                    "position_class": position_class(overlay.get("position")),
                    "position_label": position_label(overlay.get("position")),
                    "enter_at": (overlay.get("enter") or {}).get("at"),
                    "enter_animation": (overlay.get("enter") or {}).get("animation"),
                    "exit_at": (overlay.get("exit") or {}).get("at"),
                    "exit_animation": (overlay.get("exit") or {}).get("animation"),
                }
            )

        verdict = verdicts.get(shot["id"])
        shot_contexts.append(
            {
                "id": shot["id"],
                "id_short": shot["id"].replace("shot_", ""),
                "beat": shot.get("beat"),
                "start": shot.get("start"),
                "end": shot.get("end"),
                "framing": shot.get("framing"),
                "angle": shot.get("angle"),
                "motion": shot.get("motion"),
                "depth_of_field": shot.get("depth_of_field"),
                "subject": shot.get("subject"),
                "vo": shot.get("vo"),
                "rationale": shot.get("rationale"),
                "aspect_class": aspect_class(aspect),
                "has_image": image_path is not None,
                "has_no_image": image_path is None,
                "image_path": image_path,
                "overlays": overlays,
                "has_overlays": bool(overlays),
                "has_verdict": verdict is not None,
                "verdict": (verdict or {}).get("verdict"),
                "verdict_round": (verdict or {}).get("round"),
                "verdict_class": str((verdict or {}).get("verdict", "")).lower(),
            }
        )

    css = (
        read_template("styles.css.tpl")
        .replace("{{BG_COLOR}}", brand["bg"])
        .replace("{{INK_COLOR}}", brand["ink"])
        .replace("{{ACCENT_COLOR}}", brand["accent"])
        .replace("{{MUTED_COLOR}}", brand["muted"])
        .replace("{{RULE_COLOR}}", brand["rule"])
        .replace("{{DISPLAY_FONT}}", brand["display_font"])
        .replace("{{BODY_FONT}}", brand["body_font"])
        .replace("{{INLINE_PRINT_CSS}}", read_template("print.css.tpl"))
    )

    brand_sha = sha256_file(brand_path) if brand_path.exists() else None
    recorded_sha = (run_doc.get("inputs") or {}).get("brand_lock_sha256")
    if brand_sha and recorded_sha and brand_sha != recorded_sha:
        provenance_notes.append(
            "the brand-lock on disk no longer matches the one recorded in run.json"
        )
        warnings.append(
            "brand-lock has changed since the run; this preview does not show the "
            "brand state the frames were produced against"
        )

    context = {
        "PROJECT_TITLE": project["title"],
        "DURATION": project["duration_s"],
        "ASPECT": aspect,
        "FRAMEWORK": project.get("framework") or "not specified",
        "SHOTS_VERSION": shots_data.get("version", "unknown"),
        "BRIEF": None,
        "SERIES_CHARACTER": series["character"],
        "SERIES_ENVIRONMENT": series["environment"],
        "SERIES_LIGHTING": series["lighting"],
        "SERIES_COLOR_GRADE": series["color_grade"],
        "BRAND_LOCK_REF": brand_ref,
        "BRAND_LOCK_SHA_SHORT": brand_sha[:12] if brand_sha else None,
        "RUN_ID": run_doc.get("run_id") or "not recorded",
        "RUN_CREATED_AT": run_doc.get("created_at") or "not recorded",
        "RENDERED_AT": args.rendered_at or iso_instant(),
        "PROVENANCE_NOTE": " ".join(provenance_notes) or None,
        "INLINE_CSS": css,
        "shots": shot_contexts,
    }
    return (context, warnings)


def selftest() -> int:
    """Render the bundled worked run twice and prove the output is byte-identical."""
    worked = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    ok = True

    class Args:
        inline_images = False
        rendered_at = "2026-07-30T00:00:00Z"

    first, _ = build_context(worked, Args())
    second, _ = build_context(worked, Args())
    html_a = render(read_template("preview.html.tpl"), first)
    html_b = render(read_template("preview.html.tpl"), second)

    if html_a == html_b:
        print("  ok    selftest: two renders with a pinned timestamp are identical")
    else:
        print("  FAIL  selftest: two renders differed")
        ok = False

    # shot_06 of the shotkit-explainer example carries two overlays. A renderer that
    # resolves only the first drops the second silently, which is what used to happen.
    explainer = (
        REPO_ROOT
        / "skills"
        / "storyboard-architect"
        / "examples"
        / "shotkit-explainer"
    )
    multi_ctx, _ = build_context(explainer, Args())
    shot_06 = next(s for s in multi_ctx["shots"] if s["id"] == "shot_06")
    multi_html = render(read_template("preview.html.tpl"), multi_ctx)

    checks = [
        ("escapes angle brackets", "<script>alert(1)</script>" not in render(
            "{{subject}}", {"subject": "<script>alert(1)</script>"}
        )),
        ("escapes quotes inside a style attribute", "&quot;" in render(
            '<span style="font-family: {{font}};">x</span>', {"font": '"><script>'}
        )),
        ("resolves every overlay on a multi-overlay shot", len(shot_06["overlays"]) == 2),
        (
            "renders every overlay on a multi-overlay shot",
            all(
                escape(overlay["content"]) in multi_html
                for overlay in shot_06["overlays"]
            ),
        ),
        ("states the run date, not the render date, in the header", "2026-07-30T14:23:00Z" in html_a),
        ("labels the render separately", "rendered 2026-07-30T00:00:00Z" in html_a),
        ("shows a verdict badge", "sb-verdict-accept" in html_a),
        ("uses the brand-lock ref from shots.json", 'href="brand-lock.snapshot.md"' in html_a),
        ("carries no unrendered template tags", "{{" not in html_a),
    ]
    for label, passed in checks:
        if passed:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    p = argparse.ArgumentParser(
        description="Render a shotkit output folder into a single preview.html."
    )
    p.add_argument(
        "output_dir",
        nargs="?",
        type=Path,
        help="Directory containing shots.json, text-overlays.json, run.json",
    )
    p.add_argument("--out", default="preview.html", help="Output filename, relative to output_dir")
    p.add_argument(
        "--inline-images",
        action="store_true",
        help="Embed frames as base64 so the file is portable on its own",
    )
    p.add_argument(
        "--rendered-at",
        help="Pin the render timestamp (UTC ISO-8601). Makes output reproducible.",
    )
    p.add_argument("--selftest", action="store_true", help="Prove the renderer's guarantees")
    args = p.parse_args()

    if args.selftest:
        return selftest()
    if args.output_dir is None:
        p.error("output_dir is required unless --selftest is given")

    out_dir: Path = args.output_dir
    if not out_dir.is_dir():
        print(f"ERROR: output directory not found: {out_dir}")
        return 1
    if not (out_dir / "shots.json").exists():
        print(f"ERROR: shots.json not found in {out_dir}")
        return 1

    context, warnings = build_context(out_dir, args)
    html_out = render(read_template("preview.html.tpl"), context)

    out_path = out_dir / args.out
    out_path.write_text(html_out, encoding="utf-8")
    print(f"  wrote {out_path}")
    for warn in warnings:
        print(f"  warn  {warn}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/shots-to-html.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/validate_brand_lock.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/validate_brand_lock.py`

#!/usr/bin/env python3
"""
Validate a brand-lock Markdown file.

Two modes, because a brand-pack and a snapshot are not the same artifact.

A brand-pack (brand-packs/*.md) is a source document. An unfilled template is a legal
brand-pack: that is what a template is for.

A snapshot (brand-lock.snapshot.md, written into an output tree) is a provenance
record. It has to carry the header storyboard-architect promises to write, and if it
still contains template placeholders then the run it governs was built against nothing.
Pass --snapshot to check those extra rules, and --require-configured to reject
placeholders outright.

Required headings (case-insensitive, in any order):
- Identity, Palette, Typography, Mood adjectives, Never list,
  Aspect ratios, Color grade direction, Motion language, Voice rules

Required identity fields (under ## Identity):
- Brand, One-line description, Archetype, Voice posture

Usage:
    python tools/validate_brand_lock.py path/to/brand-lock.md [...]
    python tools/validate_brand_lock.py --snapshot path/to/brand-lock.snapshot.md
    python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
    python tools/validate_brand_lock.py --snapshots            # every bundled snapshot
    python tools/validate_brand_lock.py --selftest
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from _shotkit import (
    ISO_INSTANT_RE,
    PALETTE_ROLES,
    REPO_ROOT,
    is_unconfigured,
    parse_palette,
    parse_snapshot_header,
    parse_typography,
)

REQUIRED_SECTIONS = {
    "identity",
    "palette",
    "typography",
    "mood adjectives",
    "never list",
    "aspect ratios",
    "color grade direction",
    "motion language",
    "voice rules",
}

REQUIRED_IDENTITY_FIELDS = {
    "brand",
    "one-line description",
    "archetype",
    "voice posture",
}

ISO_DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")


def parse_headings(text: str) -> list[tuple[int, str]]:
    """Return list of (level, heading_text_lower) for every Markdown heading."""
    out = []
    for line in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            out.append((len(m.group(1)), m.group(2).strip().lower()))
    return out


def extract_section(text: str, heading_lower: str) -> str:
    """Extract the body of a section by its heading. Empty string if not found."""
    lines = text.splitlines()
    in_section = False
    section_lines: list[str] = []
    section_level: int | None = None
    for line in lines:
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            level = len(m.group(1))
            heading = m.group(2).strip().lower()
            if not in_section:
                if heading == heading_lower:
                    in_section = True
                    section_level = level
                    continue
            else:
                if section_level is not None and level <= section_level:
                    break
        if in_section:
            section_lines.append(line)
    return "\n".join(section_lines)


def check_structure(text: str) -> list[str]:
    errors: list[str] = []
    heading_set = {h for _, h in parse_headings(text)}

    for missing in sorted(REQUIRED_SECTIONS - heading_set):
        errors.append(f"missing section: ## {missing.title()}")

    if "identity" in heading_set:
        identity_body = extract_section(text, "identity").lower()
        for field in sorted(REQUIRED_IDENTITY_FIELDS):
            if field not in identity_body:
                errors.append(f"identity section missing field: '{field}'")

    if "palette" in heading_set:
        palette_body = extract_section(text, "palette")
        if not re.search(r"#[0-9A-Fa-f]{6}|#_{6}", palette_body):
            errors.append(
                "palette section has no hex color values (or template placeholders)"
            )

    return errors


def check_roles(text: str) -> list[str]:
    """
    The palette role names the HTML preview maps onto CSS variables.

    A brand-lock is free to add rows, but a missing role means the preview silently
    renders that slot in a generic default, so it is worth saying out loud.
    """
    warnings: list[str] = []
    palette = parse_palette(text)
    for role in PALETTE_ROLES:
        if not any(role in name for name in palette):
            warnings.append(
                f"palette has no '{role}' role; the HTML preview will fall back to a "
                f"generic color for it"
            )
    return warnings


def check_typography(text: str) -> list[str]:
    warnings: list[str] = []
    fonts = parse_typography(text)
    for key, label in (("display_font", "Display"), ("body_font", "Body")):
        if not fonts.get(key):
            warnings.append(
                f"typography declares no {key.replace('_', ' ')} in a readable form; "
                f'expected ``**{label} font:** `Font Name Weight` `` with the name '
                f"backticked immediately after the label"
            )
    return warnings


def check_snapshot(text: str) -> tuple[list[str], list[str]]:
    """The provenance header storyboard-architect writes into every snapshot."""
    errors: list[str] = []
    warnings: list[str] = []
    header = parse_snapshot_header(text)

    taken = header["snapshot_taken"]
    if not taken:
        errors.append(
            "snapshot is missing its '<!-- snapshot taken: ... -->' header, so nothing "
            "records when this brand state was frozen"
        )
    elif ISO_INSTANT_RE.match(taken):
        pass
    elif ISO_DATE_RE.match(taken):
        warnings.append(
            f"snapshot taken '{taken}' is a date with no time; a full UTC instant "
            f"(YYYY-MM-DDThh:mm:ssZ) is what makes two runs on one day distinguishable"
        )
    else:
        errors.append(
            f"snapshot taken '{taken}' is not ISO-8601; expected YYYY-MM-DDThh:mm:ssZ"
        )

    if not header["source"]:
        errors.append(
            "snapshot is missing its '<!-- source: ... -->' header, so nothing records "
            "which brand-pack it was copied from"
        )

    return errors, warnings


def validate_brand_lock(
    path: Path, snapshot: bool = False, require_configured: bool = False
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    if not path.exists():
        return ([f"file does not exist: {path}"], [])

    text = path.read_text(encoding="utf-8")
    errors = check_structure(text)
    warnings = check_roles(text) + check_typography(text)

    unconfigured = is_unconfigured(text)
    if unconfigured:
        if require_configured or snapshot:
            errors.append(
                "palette still contains template placeholders (#______), so this is an "
                "unfilled template rather than a real brand-lock"
            )
        else:
            warnings.append(
                "palette contains template placeholders (#______); fine for a template, "
                "not for production work"
            )

    if snapshot:
        snap_errors, snap_warnings = check_snapshot(text)
        errors += snap_errors
        warnings += snap_warnings

    return (errors, warnings)


def selftest() -> int:
    ok = True
    minimal = "\n".join(
        [
            "## Identity",
            "**Brand:** X",
            "**One-line description:** Y",
            "**Archetype:** Operator",
            "**Voice posture:** Calm",
            "## Palette",
            "| Role | Hex | Use |",
            "|---|---|---|",
            "| Background | `#FFFFFF` | canvas |",
            "| Ink | `#000000` | text |",
            "| Accent | `#FF0000` | pop |",
            "| Muted | `#888888` | captions |",
            "| Rule | `#EEEEEE` | borders |",
            "## Typography",
            "**Display font:** `Inter Black 900`, headlines",
            "**Body font:** `Inter Medium 500`, body",
            "## Mood adjectives",
            "## Never list",
            "## Aspect ratios",
            "## Color grade direction",
            "## Motion language",
            "## Voice rules",
        ]
    )

    cases = [
        ("a complete brand-lock passes", minimal, {}, False),
        (
            "a snapshot with no header is rejected",
            minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot with a full instant header passes",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            False,
        ),
        (
            "a snapshot with a malformed date is rejected",
            "<!-- snapshot taken: last Tuesday -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot missing its source header is rejected",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "placeholders pass as a template",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {},
            False,
        ),
        (
            "placeholders fail under --require-configured",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {"require_configured": True},
            True,
        ),
        (
            "a missing section is caught",
            minimal.replace("## Voice rules", ""),
            {},
            True,
        ),
    ]

    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        for i, (label, text, kwargs, should_fail) in enumerate(cases):
            path = Path(tmp) / f"case-{i}.md"
            path.write_text(text, encoding="utf-8")
            errors, _ = validate_brand_lock(path, **kwargs)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        warn_path = Path(tmp) / "warn.md"
        warn_path.write_text(
            minimal.replace("| Muted | `#888888` | captions |", ""), encoding="utf-8"
        )
        _, warnings = validate_brand_lock(warn_path)
        if any("no 'muted' role" in w for w in warnings):
            print("  ok    selftest: a missing palette role warns")
        else:
            print(f"  FAIL  selftest: expected a muted-role warning, got {warnings}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_brand_lock.py <path-to-brand-lock.md> [...]")
        print("       python tools/validate_brand_lock.py --snapshot <snapshot.md>")
        print("       python tools/validate_brand_lock.py --require-configured <file>")
        print("       python tools/validate_brand_lock.py --snapshots")
        print("       python tools/validate_brand_lock.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    snapshot = "--snapshot" in args or "--snapshots" in args
    require_configured = "--require-configured" in args

    if "--snapshots" in args:
        paths = sorted(REPO_ROOT.rglob("brand-lock.snapshot.md"))
        if not paths:
            print("ERROR: no brand-lock.snapshot.md files found in the repo")
            return 1
    else:
        paths = [Path(a) for a in args if not a.startswith("--")]
        if not paths:
            print("ERROR: no brand-lock files given")
            return 2

    label = "snapshot" if snapshot else "brand-lock"
    print(f"Validating {len(paths)} {label} file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_brand_lock(path, snapshot, require_configured)
        try:
            shown = path.relative_to(REPO_ROOT)
        except ValueError:
            shown = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {shown}: {warn}")

    print()
    if total_errors == 0:
        print(f"All {label} files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across {label} files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/validate_brand_lock.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/validate_capabilities.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/validate_capabilities.py`

#!/usr/bin/env python3
"""
Validate the generator capability matrix and the adapter prose that defers to it.

_capabilities.json is declared the single source of truth for per-generator limits,
and every adapter .md repeats that rule at the top. A rule nothing checks is a
suggestion: the matrix and the prose drifted in three places before this file grew
the parity checks below.

Five checks:
  1. _capabilities.json validates against capabilities.schema.json.
  2. File parity: every generator id has an adapter .md and every adapter .md has a
     generator entry. Non-adapter markdown is skipped by name, not treated as an
     adapter with a missing entry.
  3. Prose parity: the word budget an adapter .md advertises must fit inside that
     generator's max_prompt_words, and the .md must mention the aspect_param the
     matrix says to send. A generator whose documented parameter name disagrees with
     the matrix will be called with the wrong one, because the matrix wins.
  4. Self-consistency: a notes field must not cite a word count above its own
     max_prompt_words.
  5. Staleness: warns when the matrix or an entry is past the freshness window.

Run from repo root:
    python tools/validate_capabilities.py
    python tools/validate_capabilities.py --selftest
"""

from __future__ import annotations

import re
import sys
from datetime import date

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, load_json

ADAPTERS_DIR = REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters"
CAPS = ADAPTERS_DIR / "_capabilities.json"
CAPS_SCHEMA = ADAPTERS_DIR / "capabilities.schema.json"

# Re-verify the matrix at least this often. Generator models change monthly.
STALE_AFTER_DAYS = 120

# Markdown in adapters/ that documents the directory rather than a generator.
NON_ADAPTER_STEMS = {"README", "_README"}

# "**80-150 words**", "**40-80 words per prompt**", en dash or hyphen.
WORD_RANGE_RE = re.compile(r"\*\*\s*(\d+)\s*[-–—]\s*(\d+)\s+words[^*]*\*\*")
# "**up to 150 words**" or "**150 words**"
WORD_SINGLE_RE = re.compile(r"\*\*\s*(?:up to\s+)?(\d+)\s+words[^*]*\*\*")
# A bare word count inside a notes string, e.g. "Over 100 words underperforms."
NOTES_WORD_RE = re.compile(r"(\d+)\s+words")


def _parse_date(value: str) -> date | None:
    try:
        y, m, d = (int(p) for p in value.split("-"))
        return date(y, m, d)
    except (ValueError, AttributeError):
        return None


def adapter_word_bound(text: str) -> int | None:
    """Highest word count the adapter prose advertises, or None if it names none."""
    bounds: list[int] = []
    for m in WORD_RANGE_RE.finditer(text):
        bounds.append(max(int(m.group(1)), int(m.group(2))))
    if not bounds:
        for m in WORD_SINGLE_RE.finditer(text):
            bounds.append(int(m.group(1)))
    return max(bounds) if bounds else None


def check_prose_parity(entry: dict, text: str) -> tuple[list[str], list[str]]:
    """Compare one adapter .md against its capability entry."""
    errors: list[str] = []
    warnings: list[str] = []
    gid = entry["id"]

    bound = adapter_word_bound(text)
    if bound is None:
        warnings.append(
            f"prose: '{gid}.md' advertises no word budget, so the matrix value "
            f"({entry['max_prompt_words']}) is the only guidance a reader gets"
        )
    elif bound > entry["max_prompt_words"]:
        errors.append(
            f"prose: '{gid}.md' advertises up to {bound} words but the matrix caps "
            f"max_prompt_words at {entry['max_prompt_words']}"
        )

    aspect = entry["aspect_param"]
    if aspect not in text:
        errors.append(
            f"prose: '{gid}.md' never mentions aspect_param '{aspect}'. The matrix "
            f"wins, so the forge will send a parameter the adapter does not document"
        )

    notes = entry.get("notes") or ""
    for m in NOTES_WORD_RE.finditer(notes):
        cited = int(m.group(1))
        if cited > entry["max_prompt_words"]:
            warnings.append(
                f"self-consistency: '{gid}' notes cite {cited} words but "
                f"max_prompt_words is {entry['max_prompt_words']}"
            )

    return errors, warnings


def validate(today: date | None = None) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    errors: list[str] = []
    warnings: list[str] = []
    today = today or date.today()

    if not CAPS.exists():
        return ([f"missing {CAPS.relative_to(REPO_ROOT)}"], warnings)
    if not CAPS_SCHEMA.exists():
        return ([f"missing {CAPS_SCHEMA.relative_to(REPO_ROOT)}"], warnings)

    caps, caps_err = load_json(CAPS)
    if caps_err:
        return ([f"_capabilities.json: {caps_err}"], warnings)
    schema, schema_err = load_json(CAPS_SCHEMA)
    if schema_err:
        return ([f"capabilities.schema.json: {schema_err}"], warnings)

    # 1. Schema validation
    validator = Draft202012Validator(schema)
    for err in sorted(validator.iter_errors(caps), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # structure-dependent checks need a valid shape

    entries = {g["id"]: g for g in caps["generators"]}
    cap_ids = set(entries)
    md_ids = {
        p.stem
        for p in ADAPTERS_DIR.glob("*.md")
        if p.stem not in NON_ADAPTER_STEMS
    }

    # 2. File parity
    for missing_md in sorted(cap_ids - md_ids):
        errors.append(
            f"parity: capability id '{missing_md}' has no adapter file {missing_md}.md"
        )
    for missing_cap in sorted(md_ids - cap_ids):
        errors.append(
            f"parity: adapter '{missing_cap}.md' has no entry in _capabilities.json"
        )

    # 3 and 4. Prose parity and self-consistency
    for gid in sorted(cap_ids & md_ids):
        text = (ADAPTERS_DIR / f"{gid}.md").read_text(encoding="utf-8")
        prose_errors, prose_warnings = check_prose_parity(entries[gid], text)
        errors.extend(prose_errors)
        warnings.extend(prose_warnings)

    # 5. Staleness
    reviewed = _parse_date(caps.get("matrix_last_reviewed", ""))
    if reviewed is None:
        warnings.append("matrix_last_reviewed is not a parseable date")
    elif (today - reviewed).days > STALE_AFTER_DAYS:
        warnings.append(
            f"matrix_last_reviewed is {(today - reviewed).days} days old "
            f"(> {STALE_AFTER_DAYS}); re-verify the matrix"
        )
    for g in caps["generators"]:
        lv = _parse_date(g.get("last_verified", ""))
        if lv is not None and (today - lv).days > STALE_AFTER_DAYS:
            warnings.append(
                f"'{g['id']}' last_verified is {(today - lv).days} days old "
                f"(> {STALE_AFTER_DAYS}); re-verify this generator"
            )

    return (errors, warnings)


def selftest() -> int:
    ok = True

    cases = [
        (
            "prose advertising more words than the cap is caught",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-300 words** comfortably. Pass `size` alongside.",
            True,
        ),
        (
            "prose inside the cap passes",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-250 words** comfortably. Pass `size` alongside.",
            False,
        ),
        (
            "an undocumented aspect_param is caught",
            {
                "id": "x",
                "max_prompt_words": 120,
                "aspect_param": "aspect_ratio",
                "notes": "",
            },
            "Handles **60-120 words**. Pass `aspectRatio` as a parameter.",
            True,
        ),
        (
            "en dash ranges parse",
            {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": ""},
            "Aim for **40–80 words per prompt** including `--ar`.",
            False,
        ),
    ]
    for label, entry, text, should_error in cases:
        errors, _ = check_prose_parity(entry, text)
        if bool(errors) == should_error:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
            ok = False

    entry = {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": "Over 100 words underperforms."}
    _, warnings = check_prose_parity(entry, "Aim for **40-80 words** with `--ar`.")
    if any("self-consistency" in w for w in warnings):
        print("  ok    selftest: notes citing more words than the cap are flagged")
    else:
        print(f"  FAIL  selftest: expected a self-consistency warning, got {warnings}")
        ok = False

    if adapter_word_bound("no budget stated here") is None:
        print("  ok    selftest: prose with no word budget reports none")
    else:
        print("  FAIL  selftest: found a word budget where there is none")
        ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    if "--selftest" in sys.argv[1:]:
        return selftest()

    print(f"Validating capability matrix: {CAPS.relative_to(REPO_ROOT)}")
    print()

    errors, warnings = validate()

    for w in warnings:
        print(f"  warn  {w}")
    if warnings:
        print()

    if not errors:
        caps, _ = load_json(CAPS)
        count = len((caps or {}).get("generators", []))
        print(f"Capability matrix valid ({count} generators, {len(warnings)} warning(s)).")
        return 0

    for e in errors:
        print(f"  FAIL  {e}")
    print()
    print(f"FAILED: {len(errors)} error(s) in capability matrix.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/validate_capabilities.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/validate_critique.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/validate_critique.py`

#!/usr/bin/env python3
"""
Validate critique.json files against the critique schema AND the gating invariant.

Schema validation alone is not enough: JSON Schema cannot express the cross-field
rules that make a verdict trustworthy. This validator adds them.

Gating invariant (the reason structured output exists):
  - Any 'blocking' issue      => verdict MUST be REJECT.
  - Three or more 'major'     => verdict MUST be REJECT.
  - One or two 'major'        => verdict MUST NOT be ACCEPT (caps at REVISE).
  - Therefore ACCEPT requires zero major/blocking issues.

Provenance invariant (version 1.1 and later):
  - A hash without its path, or a path without its hash, is not a reference.
  - image_ref must be present and non-null: a verdict about no image is not a verdict.
  - HIGH confidence requires the shot spec, the brand-lock, and the prompt to all be
    identified. The critic's own rubric says HIGH means all three were available.
  - generator, when named, must be an id in the capability matrix.

A critique that claims ACCEPT while carrying a blocking issue passes the schema but
FAILS here. So does a 1.1 critique that records an image hash and no image path.

Usage:
    python tools/validate_critique.py path/to/critique.json [...]
    python tools/validate_critique.py path/to/output-dir      # every critique in the tree
    python tools/validate_critique.py --examples              # bundled fixtures
    python tools/validate_critique.py --selftest              # prove the gates fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, capability_ids, critique_paths, load_json

SCHEMA_PATH = (
    REPO_ROOT / "skills" / "visual-asset-critic" / "templates" / "critique.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "visual-asset-critic" / "examples"

MAJOR_REJECT_THRESHOLD = 3

# Pairs that must be present or absent together.
REF_HASH_PAIRS = (
    ("image_ref", "image_sha256"),
    ("brand_lock_ref", "brand_lock_sha256"),
    ("prompt_ref", "prompt_sha256"),
)


def _load_schema() -> dict:
    data, err = load_json(SCHEMA_PATH)
    if err:
        raise RuntimeError(err)
    return data


def check_gating(data: dict) -> list[str]:
    """The severity-to-verdict invariant. Assumes data is schema-valid."""
    errors: list[str] = []
    verdict = data.get("verdict")
    severities = [issue.get("severity") for issue in data.get("issues", [])]
    majors = severities.count("major")

    if "blocking" in severities and verdict != "REJECT":
        errors.append(
            f"gating: a 'blocking' issue requires verdict REJECT, got '{verdict}'"
        )
    if majors >= MAJOR_REJECT_THRESHOLD and verdict != "REJECT":
        errors.append(
            f"gating: {majors} 'major' issues require verdict REJECT "
            f"(threshold {MAJOR_REJECT_THRESHOLD}), got '{verdict}'"
        )
    if majors and verdict == "ACCEPT":
        errors.append(
            "gating: a 'major' issue caps the verdict at REVISE; ACCEPT is not allowed"
        )
    return errors


def check_provenance(data: dict, known_generators: set[str]) -> list[str]:
    """The provenance invariant. Only applies from version 1.1."""
    errors: list[str] = []
    if data.get("version") == "1.0":
        return errors

    for ref_key, hash_key in REF_HASH_PAIRS:
        ref, digest = data.get(ref_key), data.get(hash_key)
        if ref and not digest:
            errors.append(f"provenance: {ref_key} is set but {hash_key} is null")
        if digest and not ref:
            errors.append(f"provenance: {hash_key} is set but {ref_key} is null")

    if not data.get("image_ref"):
        errors.append(
            "provenance: image_ref is null; a verdict that names no image cannot be audited"
        )

    if data.get("confidence") == "HIGH":
        missing = [
            key
            for key in ("shot_id", "brand_lock_ref", "prompt_ref")
            if not data.get(key)
        ]
        if missing:
            errors.append(
                "provenance: confidence HIGH requires "
                + ", ".join(missing)
                + " to be identified"
            )

    generator = data.get("generator")
    if generator and known_generators and generator not in known_generators:
        errors.append(
            f"provenance: generator '{generator}' is not an id in the capability matrix"
        )

    return errors


def validate_doc(
    data: dict,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes every gate."""
    errors: list[str] = []
    warnings: list[str] = []

    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # the gates assume a schema-valid shape

    errors += check_gating(data)
    errors += check_provenance(data, known_generators or set())

    if data.get("version") == "1.0":
        warnings.append(
            "version 1.0 carries no run id, no round, and no content hashes, so the "
            "verdict cannot be tied to the bytes it reviewed; re-emit as 1.1"
        )

    return (errors, warnings)


def validate_path(
    path: Path,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    data, err = load_json(path)
    if err:
        return ([err], [])
    if not isinstance(data, dict):
        return ([f"top level is not an object: {path}"], [])
    return validate_doc(data, validator, known_generators)


def _selftest_cases() -> list[tuple[str, dict, bool]]:
    """(label, document, should_pass)."""
    base_provenance = {
        "run_id": "20260730T142300Z-9f2c1ab4",
        "round": 1,
        "created_at": "2026-07-30T14:31:00Z",
        "shot_id": "shot_03",
        "brand_lock_ref": "brand-lock.snapshot.md",
        "brand_lock_sha256": "a" * 64,
        "image_ref": "frames/round-1/shot_03.png",
        "image_sha256": "b" * 64,
        "prompt_ref": "prompts/round-1/flux.txt",
        "prompt_sha256": "c" * 64,
        "generator": "flux",
        "model_version": "2 Pro",
        "seed": 12345,
    }
    major_issue = {
        "layer": "Series Lock",
        "severity": "major",
        "note": "hair mismatch",
        "fix_type": "prompt-level",
        "fix": "add 'salt-and-pepper hair' to the anchor",
    }
    blocking_issue = {
        "layer": "Brand Lock",
        "severity": "blocking",
        "note": "off-palette",
        "fix_type": "re-roll",
        "fix": "re-roll with palette anchor",
    }

    def doc(**overrides) -> dict:
        out = {
            "version": "1.1",
            **base_provenance,
            "verdict": "REVISE",
            "confidence": "HIGH",
            "issues": [dict(major_issue)],
        }
        out.update(overrides)
        return out

    return [
        ("clean REVISE with full provenance passes", doc(), True),
        (
            "legacy 1.0 document still validates",
            {
                "version": "1.0",
                "verdict": "REVISE",
                "confidence": "HIGH",
                "issues": [dict(major_issue)],
            },
            True,
        ),
        (
            "ACCEPT with a blocking issue is rejected",
            doc(verdict="ACCEPT", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "REVISE with a blocking issue is rejected",
            doc(verdict="REVISE", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "ACCEPT with a major issue is rejected",
            doc(verdict="ACCEPT"),
            False,
        ),
        (
            "three major issues cannot stay at REVISE",
            doc(verdict="REVISE", issues=[dict(major_issue) for _ in range(3)]),
            False,
        ),
        (
            "three major issues at REJECT pass",
            doc(verdict="REJECT", issues=[dict(major_issue) for _ in range(3)]),
            True,
        ),
        (
            "1.1 with a hash and no path is rejected",
            doc(prompt_ref=None),
            False,
        ),
        (
            "1.1 with a path and no hash is rejected",
            doc(prompt_sha256=None),
            False,
        ),
        (
            "1.1 with no image_ref is rejected",
            doc(image_ref=None, image_sha256=None),
            False,
        ),
        (
            "HIGH confidence with no prompt identified is rejected",
            doc(prompt_ref=None, prompt_sha256=None),
            False,
        ),
        (
            "MEDIUM confidence with no prompt identified passes",
            doc(confidence="MEDIUM", prompt_ref=None, prompt_sha256=None),
            True,
        ),
        (
            "unknown generator id is rejected",
            doc(generator="runway-sora"),
            False,
        ),
        (
            "1.1 missing a required provenance field is rejected",
            {
                "version": "1.1",
                "verdict": "ACCEPT",
                "confidence": "LOW",
                "issues": [],
            },
            False,
        ),
    ]


def selftest() -> int:
    validator = Draft202012Validator(_load_schema())
    known = capability_ids() or {"flux"}
    ok = True

    for label, document, should_pass in _selftest_cases():
        errors, _ = validate_doc(document, validator, known)
        passed = not errors
        if passed == should_pass:
            print(f"  ok    selftest: {label}")
        else:
            detail = errors if errors else ["(no errors raised)"]
            print(f"  FAIL  selftest: {label} -> {detail}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def _collect(args: list[str]) -> list[Path] | None:
    if "--examples" in args:
        found = sorted(EXAMPLES_DIR.glob("*.json"))
        found += critique_paths(EXAMPLES_DIR / "worked-run")
        return found or None

    paths: list[Path] = []
    for raw in args:
        path = Path(raw)
        if path.is_dir():
            found = critique_paths(path)
            if not found:
                print(f"  FAIL  {raw}")
                print("        - no critique files found in this output tree")
                return None
            paths.extend(found)
        else:
            paths.append(path)
    return paths


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_critique.py <critique.json|output-dir> [...]")
        print("       python tools/validate_critique.py --examples")
        print("       python tools/validate_critique.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    if not SCHEMA_PATH.exists():
        print(f"ERROR: schema not found at {SCHEMA_PATH}")
        return 1

    paths = _collect(args)
    if paths is None:
        return 1

    validator = Draft202012Validator(_load_schema())
    known = capability_ids()

    print(f"Validating {len(paths)} critique file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_path(path, validator, known)
        try:
            label = path.relative_to(REPO_ROOT)
        except ValueError:
            label = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {label}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {label}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {label}: {warn}")

    print()
    if total_errors == 0:
        print(f"All critiques valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across critiques.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/validate_critique.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/validate_prompts.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/validate_prompts.py`

#!/usr/bin/env python3
"""
Validate the prompt files visual-prompt-forge writes.

The forge documents four hard rules and a quality-bar checklist, and until this file
existed every one of them was enforced by a model remembering to check its own work.
That is not a small gap. Rule 3, series_lock anchors appear verbatim in every prompt,
is the rule that produces visual consistency across a series, and it is also the
easiest one in the kit to break by paraphrasing while writing fluent prose. A careful
pass over a seven-shot storyboard drifted on it seven times out of seven with every
other validator green.

Checks:
  1. The header block names the storyboard, generator, aspect, brand-lock, run, round.
  2. The generator is an id in the capability matrix.
  3. The header aspect matches project.aspect in shots.json.
  4. No shot's prompt exceeds that generator's max_prompt_words ceiling.
  5. Every shot block names a shot that exists. A full pass covers every shot; a
     revision file covers a subset.
  6. Rule 1: no on-screen text content appears in any prompt. Text is composited.
  7. Rule 3: series_lock environment, lighting, and color_grade appear verbatim.
     The character anchor is a warning, because a shot with no person in it can
     legitimately omit it.
  8. No duplicate shot blocks in one file.

Usage:
    python tools/validate_prompts.py <output-dir>
    python tools/validate_prompts.py <output-dir>/prompts/round-1/flux.txt
    python tools/validate_prompts.py --examples
    python tools/validate_prompts.py --selftest
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from _shotkit import REPO_ROOT, capability_map, load_json

WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"

SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT = re.compile(r"^\s*#")

HEADER_FIELDS = ("Storyboard", "Generator", "Aspect", "Brand-lock", "Run", "Round")

# series_lock keys that describe every frame, so every prompt has to carry them.
UNIVERSAL_ANCHORS = ("environment", "lighting", "color_grade")


def parse_blocks(text: str) -> tuple[dict[str, str], list[tuple[str, str]]]:
    """Return (header fields, [(shot_id, prompt body)])."""
    header: dict[str, str] = {}
    blocks: list[tuple[str, list[str]]] = []
    current: list[str] | None = None

    for line in text.splitlines():
        m = SHOT_HEADER.match(line)
        if m:
            current = []
            blocks.append((m.group(1), current))
            continue
        if current is None:
            hm = re.match(r"^#\s*([A-Za-z-]+)\s*:\s*(.+?)\s*$", line)
            if hm:
                header[hm.group(1).strip()] = hm.group(2).strip()
            continue
        if not COMMENT.match(line):
            current.append(line)

    return (header, [(sid, "\n".join(b).strip()) for sid, b in blocks])


def check_file(
    path: Path, shots_data: dict, caps: dict[str, dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    label = path.name

    text = path.read_text(encoding="utf-8")
    header, blocks = parse_blocks(text)

    if not blocks:
        return ([f"{label}: no shot blocks found; expected '# shot_NN, ...' lines"], warnings)

    for field in HEADER_FIELDS:
        if field not in header:
            warnings.append(f"{label}: header is missing '# {field}:'")

    generator = header.get("Generator", "").split()[0] if header.get("Generator") else None
    entry = caps.get(generator) if generator else None
    if generator and entry is None:
        errors.append(
            f"{label}: header names generator '{generator}', which is not an id in "
            f"_capabilities.json"
        )
    if generator is None:
        # Fall back to the filename: flux.txt or revised-flux.txt
        stem = path.stem.replace("revised-", "")
        entry = caps.get(stem)
        if entry:
            warnings.append(
                f"{label}: no '# Generator:' header, inferred '{stem}' from the filename"
            )

    project = shots_data.get("project", {})
    if "Aspect" in header and header["Aspect"] != project.get("aspect"):
        errors.append(
            f"{label}: header aspect '{header['Aspect']}' does not match "
            f"project.aspect '{project.get('aspect')}'"
        )

    shot_ids = [s["id"] for s in shots_data.get("shots", [])]
    by_id = {s["id"]: s for s in shots_data.get("shots", [])}
    series = shots_data.get("series_lock", {})

    seen: set[str] = set()
    for sid, body in blocks:
        if sid in seen:
            errors.append(f"{label}: {sid} appears in more than one block")
        seen.add(sid)
        if sid not in by_id:
            errors.append(f"{label}: names {sid}, which is not in shots.json")
            continue
        if not body:
            errors.append(f"{label}: {sid} has a header but no prompt body")
            continue

        if entry:
            words = len(body.split())
            ceiling = entry["max_prompt_words"]
            if words > ceiling:
                errors.append(
                    f"{label}: {sid} is {words} words, over the "
                    f"{entry['id']} ceiling of {ceiling}"
                )

        low = body.lower()
        for key in UNIVERSAL_ANCHORS:
            value = series.get(key)
            if value and value.lower() not in low:
                errors.append(
                    f"{label}: {sid} does not carry the series_lock {key} verbatim. "
                    f"Paraphrasing an anchor is what makes shots stop matching each other"
                )
        character = series.get("character")
        if character and character.lower() not in low:
            warnings.append(
                f"{label}: {sid} does not carry the series_lock character verbatim; "
                f"correct only if this shot has no person in it"
            )

    # Rule 1: text is composited, never described.
    overlays_path = path.parent.parent.parent / "text-overlays.json"
    overlays_data, ov_err = load_json(overlays_path)
    if not ov_err and isinstance(overlays_data, dict):
        for overlay in overlays_data.get("overlays", []):
            content = overlay.get("content")
            if not isinstance(content, str) or len(content) < 8:
                continue
            needle = content.lower().rstrip(".!?")
            for sid, body in blocks:
                if needle in body.lower():
                    errors.append(
                        f"{label}: {sid} contains the copy of overlay "
                        f"{overlay.get('id')} verbatim. On-screen text is composited, "
                        f"never put in an image prompt"
                    )

    is_revision = path.name.startswith("revised-")
    if not is_revision:
        for missing in [s for s in shot_ids if s not in seen]:
            errors.append(f"{label}: full pass is missing a block for {missing}")

    return (errors, warnings)


def collect_prompt_files(target: Path) -> tuple[Path | None, list[Path]]:
    """Return (output_dir, prompt files). Accepts an output dir or a single file."""
    if target.is_file():
        # prompts/round-N/<file>.txt  ->  output dir is three levels up
        return (target.parent.parent.parent, [target])
    if target.is_dir():
        found = sorted(target.glob("prompts/round-*/*.txt"))
        if not found:
            found = sorted(target.glob("prompts/*.txt"))  # pre-3.0.0 flat layout
        return (target, found)
    return (None, [])


def validate_target(target: Path) -> tuple[list[str], list[str]]:
    out_dir, files = collect_prompt_files(target)
    if out_dir is None:
        return ([f"not a file or directory: {target}"], [])
    if not files:
        return ([f"no prompt files found under {target}"], [])

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        return ([f"cannot read shots.json next to the prompts: {err}"], [])

    caps = capability_map()
    errors: list[str] = []
    warnings: list[str] = []
    for path in files:
        e, w = check_file(path, shots_data, caps)
        errors += e
        warnings += w
    return (errors, warnings)


SHOTS_FIXTURE = {
    "project": {"aspect": "9:16"},
    "series_lock": {
        "character": "founder in a navy crewneck",
        "environment": "minimalist home office, oak desk",
        "lighting": "soft window light from camera-left",
        "color_grade": "warm filmic with muted teal shadows",
    },
    "shots": [{"id": "shot_01"}, {"id": "shot_02"}],
}


def _fixture(body_01: str, body_02: str | None = None, aspect: str = "9:16") -> str:
    out = [
        "# Storyboard: Fixture",
        "# Generator: flux",
        f"# Aspect: {aspect}",
        "# Brand-lock: brand-lock.snapshot.md",
        "# Run: 20260730T180000Z-7c41e0a9",
        "# Round: 1",
        "",
        "# shot_01, hook, 0.0-2.0s, MCU eye-level static",
        body_01,
        "",
    ]
    if body_02 is not None:
        out += ["# shot_02, pain, 2.0-6.0s, MS eye-level push", body_02, ""]
    return "\n".join(out)


def selftest() -> int:
    import tempfile

    ok = True
    sl = SHOTS_FIXTURE["series_lock"]
    good = (
        f"Medium close-up of a {sl['character']}. {sl['environment']}. "
        f"{sl['lighting']}. {sl['color_grade']}. Photorealistic."
    )
    drifted = (
        "Medium close-up of a founder in a navy sweater. A minimal home office with "
        "an oak desk. Soft light from the left. Warm grade with teal shadows."
    )

    cases = [
        ("a compliant full pass passes", _fixture(good, good), False),
        ("a paraphrased anchor is caught", _fixture(drifted, good), True),
        ("a missing shot in a full pass is caught", _fixture(good), True),
        ("an aspect mismatch is caught", _fixture(good, good, aspect="16:9"), True),
        (
            "an over-ceiling prompt is caught",
            _fixture(good + " extra" * 200, good),
            True,
        ),
        (
            "an unknown shot id is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_09,"),
            True,
        ),
        (
            "a duplicate shot block is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_01,"),
            True,
        ),
        (
            "an empty prompt body is caught",
            _fixture(good, ""),
            True,
        ),
    ]

    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "output"
        (out / "prompts" / "round-1").mkdir(parents=True)
        (out / "shots.json").write_text(json.dumps(SHOTS_FIXTURE))
        caps = capability_map()
        for label, text, should_fail in cases:
            p = out / "prompts" / "round-1" / "flux.txt"
            p.write_text(text)
            errors, _ = check_file(p, SHOTS_FIXTURE, caps)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        # Rule 1: overlay copy leaking into a prompt.
        (out / "text-overlays.json").write_text(
            json.dumps(
                {
                    "version": "1.0",
                    "overlays": [
                        {"id": "text_01", "content": "You are the bottleneck."}
                    ],
                }
            )
        )
        p = out / "prompts" / "round-1" / "flux.txt"
        p.write_text(_fixture(good + " The words You are the bottleneck appear.", good))
        errors, _ = check_file(p, SHOTS_FIXTURE, caps)
        if any("composited" in e for e in errors):
            print("  ok    selftest: overlay copy inside a prompt is caught")
        else:
            print(f"  FAIL  selftest: overlay leak not caught -> {errors}")
            ok = False

        # A revision file covers a subset, and that is not an error.
        rev = out / "prompts" / "round-2"
        rev.mkdir()
        rp = rev / "revised-flux.txt"
        rp.write_text(_fixture(good))
        errors, _ = check_file(rp, SHOTS_FIXTURE, caps)
        if not errors:
            print("  ok    selftest: a revision file may cover a subset of shots")
        else:
            print(f"  FAIL  selftest: revision subset flagged -> {errors}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_prompts.py <output-dir|prompt-file> [...]")
        print("       python tools/validate_prompts.py --examples")
        print("       python tools/validate_prompts.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    targets = [WORKED_RUN] if "--examples" in args else [Path(a) for a in args]

    print(f"Validating prompt files for {len(targets)} target(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for target in targets:
        errors, warnings = validate_target(target)
        try:
            shown = target.relative_to(REPO_ROOT)
        except ValueError:
            shown = target
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for e in errors:
                print(f"        - {e}")
        for w in warnings:
            print(f"  warn  {shown}: {w}")

    print()
    if total_errors == 0:
        print(f"All prompt files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across prompt files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/validate_prompts.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/validate_provenance.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/validate_provenance.py`

#!/usr/bin/env python3
"""
Validate the provenance chain of a shotkit output tree.

This is the tool that answers "does this verdict still describe the file it reviewed."
Paths lie: a filename says nothing about the bytes behind it, so a frame regenerated
after its critique leaves every path reference intact and every claim about it wrong.
Content hashes are what make that detectable, and this walks them.

Checks:
  1. run.json validates against run.schema.json, and its run_id agrees with created_at.
  2. Rounds are numbered from 1 with no gaps and no duplicates.
  3. Every input hash in run.json still matches the file on disk. A brand-lock edited
     mid-project fails here instead of silently repointing the project's history.
  4. Every prompt hash recorded in run.json still matches the file on disk.
  5. Every critique validates against the schema and the gating invariant.
  6. Every critique's run_id matches run.json.
  7. Every critique's image, prompt, and brand-lock hashes match the files on disk.
  8. No two critiques cover the same shot in the same round. Two operators writing the
     same verdict path is a real conflict, not a silent overwrite.
  9. Every frame on disk has a critique for its round. An unreviewed frame is the
     failure mode where a re-roll slips past the gate on a stale ACCEPT.
 10. Every shot has at least one critique, and the latest verdict per shot is reported.
 11. Shots recorded as post_only still owe compositing work.

Exit status is 0 when the chain is intact. Add --require-accept to also demand that
every shot's latest verdict is ACCEPT, which is the pipeline stop condition made
executable rather than described.

Usage:
    python tools/validate_provenance.py <output-dir> [...]
    python tools/validate_provenance.py <output-dir> --require-accept
    python tools/validate_provenance.py <output-dir> --json
    python tools/validate_provenance.py --examples
    python tools/validate_provenance.py --selftest
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    IMAGE_EXTS,
    REPO_ROOT,
    critique_paths,
    load_json,
    round_dirs,
    run_id_timestamp,
    sha256_file,
)
from validate_critique import _load_schema as _load_critique_schema
from validate_critique import validate_doc as validate_critique_doc

RUN_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "run.schema.json"
)
WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"


class Report:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.shots: dict[str, dict] = {}
        self.rounds_seen: list[int] = []
        # (path, recorded, actual) -> the labels that referenced it. One edited file is
        # one problem, even when twenty critiques all hash it.
        self.hash_failures: dict[tuple[str, str, str], list[str]] = {}

    def as_dict(self) -> dict:
        return {
            "output_dir": str(self.output_dir),
            "ok": not self.errors,
            "errors": self.errors,
            "warnings": self.warnings,
            "rounds": self.rounds_seen,
            "shots": self.shots,
        }


def _check_hash(
    report: Report, label: str, rel: str | None, expected: str | None
) -> None:
    """Compare a recorded hash against the file currently on disk."""
    if not rel or not expected:
        return
    path = report.output_dir / rel
    if not path.exists():
        report.errors.append(f"{label}: '{rel}' is referenced but missing on disk")
        return
    actual = sha256_file(path)
    if actual == expected:
        return
    report.hash_failures.setdefault((rel, expected, actual), []).append(label)


def _finalize_hash_failures(report: Report) -> None:
    """Turn collected hash mismatches into one error per distinct mismatch."""
    for (rel, expected, actual), labels in report.hash_failures.items():
        # Print both hashes in full. Truncating them meant a single mistyped character
        # at the end produced a message showing two identical-looking strings and
        # asserting they differed, which is the least useful moment to be imprecise: a
        # hand-authored run.json is exactly where typos come from.
        detail = (
            f"'{rel}' does not match the hash recorded for it\n"
            f"          recorded: {expected}\n"
            f"          on disk:  {actual}"
        )
        if len(expected) != 64:
            detail += (
                f"\n          the recorded value is {len(expected)} characters, not 64, "
                f"so it is malformed rather than stale"
            )
        elif sum(a != b for a, b in zip(expected, actual)) <= 2:
            detail += (
                "\n          they differ in one or two characters, which usually means "
                "a typo in the recorded hash rather than a changed file"
            )
        if len(labels) == 1:
            detail += f"\n          referenced by: {labels[0]}"
        else:
            shown = ", ".join(labels[:3])
            more = f", and {len(labels) - 3} more" if len(labels) > 3 else ""
            detail += (
                f"\n          referenced by {len(labels)} places: {shown}{more}"
            )
        report.errors.append(detail)


def check_run_doc(report: Report) -> dict | None:
    run_path = report.output_dir / "run.json"
    if not run_path.exists():
        report.errors.append(
            "run.json is missing, so nothing pins this output to its inputs. A tree "
            "written before 3.0.0 has no provenance to check: write a run.json "
            "(schema at skills/storyboard-architect/templates/run.schema.json) or "
            "re-run storyboard-architect. This is reported as an error rather than a "
            "warning so a pipeline gate cannot pass an unauditable tree"
        )
        return None

    run_doc, err = load_json(run_path)
    if err:
        report.errors.append(f"run.json: {err}")
        return None

    schema, s_err = load_json(RUN_SCHEMA)
    if s_err:
        report.errors.append(f"run.schema.json: {s_err}")
        return None

    validator = Draft202012Validator(schema)
    for e in sorted(validator.iter_errors(run_doc), key=lambda x: list(x.path)):
        loc = "/".join(str(p) for p in e.path) or "(root)"
        report.errors.append(f"run.json schema: {loc}: {e.message}")
    if report.errors:
        return None

    stamp = run_id_timestamp(run_doc["run_id"])
    expected = run_doc["created_at"].replace("-", "").replace(":", "")
    if stamp != expected:
        report.errors.append(
            f"run.json: run_id timestamp '{stamp}' disagrees with "
            f"created_at '{run_doc['created_at']}'"
        )

    if run_doc["inputs"].get("brand_lock_configured") is False:
        report.warnings.append(
            "run.json: brand_lock_configured is false, so this run was built against "
            "an unfilled template rather than a real brand-lock"
        )

    inputs = run_doc["inputs"]
    _check_hash(report, "inputs", inputs.get("shots_ref"), inputs.get("shots_sha256"))
    _check_hash(
        report,
        "inputs",
        inputs.get("text_overlays_ref"),
        inputs.get("text_overlays_sha256"),
    )
    _check_hash(
        report, "inputs", inputs.get("brand_lock_ref"), inputs.get("brand_lock_sha256")
    )

    numbers = [r["round"] for r in run_doc.get("rounds", [])]
    report.rounds_seen = sorted(numbers)
    if len(numbers) != len(set(numbers)):
        report.errors.append("run.json: duplicate round numbers")
    if numbers and sorted(numbers) != list(range(1, max(numbers) + 1)):
        report.errors.append(
            f"run.json: rounds must run 1..N with no gaps, got {sorted(numbers)}"
        )

    for rnd in run_doc.get("rounds", []):
        for prompt in rnd.get("prompts", []):
            _check_hash(
                report,
                f"round {rnd['round']} prompt",
                prompt.get("ref"),
                prompt.get("sha256"),
            )
        for shot_id in rnd.get("post_only_shots", []) or []:
            report.warnings.append(
                f"round {rnd['round']}: {shot_id} is recorded as post-only, so it owes "
                f"compositing work that no prompt or frame will show"
            )

    return run_doc


def _round_of(path: Path, output_dir: Path, data: dict) -> int:
    """
    Which round a critique belongs to.

    The directory name wins, because that is the addressing scheme. A legacy critique
    sitting at the output root has no directory to read, so fall back to its own
    `round` field and then to 1.
    """
    try:
        parent = path.relative_to(output_dir).parent.name
    except ValueError:
        parent = ""
    if parent.startswith("round-") and parent[len("round-"):].isdigit():
        return int(parent[len("round-"):])
    declared = data.get("round")
    return declared if isinstance(declared, int) and declared >= 1 else 1


def check_critiques(report: Report, run_doc: dict | None) -> None:
    critique_validator = Draft202012Validator(_load_critique_schema())
    seen: dict[tuple[str, int], Path] = {}

    # critique_paths() is the one definition of "where critiques live", shared with
    # validate_critique.py and shots-to-html.py. Walking the round directories directly
    # meant this tool ignored a legacy root critique.json that the other two read, so
    # the preview showed a verdict badge for a shot this tool called unreviewed.
    for path in critique_paths(report.output_dir):
        try:
            rel = path.relative_to(report.output_dir)
        except ValueError:
            rel = path
        data, err = load_json(path)
        if err:
            report.errors.append(f"{rel}: {err}")
            continue
        if not isinstance(data, dict):
            report.errors.append(f"{rel}: top level is not an object")
            continue

        errors, warnings = validate_critique_doc(data, critique_validator)
        report.errors.extend(f"{rel}: {e}" for e in errors)
        report.warnings.extend(f"{rel}: {w}" for w in warnings)
        if errors:
            continue

        round_no = _round_of(path, report.output_dir, data)
        in_round_dir = rel.parent.name.startswith("round-")

        if in_round_dir and data.get("round") not in (None, round_no):
            report.errors.append(
                f"{rel}: declares round {data.get('round')} but sits in round-{round_no}/"
            )
        if run_doc and data.get("run_id") not in (None, run_doc["run_id"]):
            report.errors.append(
                f"{rel}: run_id '{data.get('run_id')}' does not match run.json "
                f"'{run_doc['run_id']}'"
            )

        shot_id = data.get("shot_id")
        if shot_id:
            key = (shot_id, round_no)
            if key in seen:
                report.errors.append(
                    f"{rel}: a second critique for {shot_id} in round {round_no} "
                    f"already exists at {seen[key]}; "
                    f"two operators reviewed the same shot in the same round"
                )
            else:
                seen[key] = rel

        _check_hash(report, f"{rel} image", data.get("image_ref"), data.get("image_sha256"))
        _check_hash(report, f"{rel} prompt", data.get("prompt_ref"), data.get("prompt_sha256"))
        _check_hash(
            report,
            f"{rel} brand-lock",
            data.get("brand_lock_ref"),
            data.get("brand_lock_sha256"),
        )

        if shot_id:
            entry = report.shots.setdefault(shot_id, {"rounds": {}})
            entry["rounds"][str(round_no)] = {
                "verdict": data.get("verdict"),
                "confidence": data.get("confidence"),
                "critique_ref": str(rel),
                "issues": len(data.get("issues", [])),
            }


def check_coverage(report: Report, run_doc: dict | None) -> None:
    shots_rel = "shots.json"
    if run_doc:
        shots_rel = run_doc["inputs"].get("shots_ref", "shots.json")
    shots_data, err = load_json(report.output_dir / shots_rel)
    shot_ids: list[str] = []
    if err:
        report.warnings.append(f"coverage: cannot read {shots_rel}, skipped ({err})")
    elif isinstance(shots_data, dict):
        shot_ids = [
            s["id"] for s in shots_data.get("shots", []) if isinstance(s.get("id"), str)
        ]

    reviewed_by_round: dict[int, set[str]] = {}
    for shot_id, entry in report.shots.items():
        for rnd in entry["rounds"]:
            reviewed_by_round.setdefault(int(rnd), set()).add(shot_id)

    for round_no, directory in round_dirs(report.output_dir, "frames"):
        reviewed = reviewed_by_round.get(round_no, set())
        for path in sorted(directory.iterdir()):
            if path.suffix.lstrip(".").lower() not in IMAGE_EXTS:
                continue
            frame_shot = path.stem
            if frame_shot not in reviewed:
                report.errors.append(
                    f"coverage: frames/round-{round_no}/{path.name} has no critique for "
                    f"round {round_no}; it was never reviewed"
                )

    for shot_id in shot_ids:
        entry = report.shots.get(shot_id)
        if not entry:
            report.warnings.append(
                f"coverage: {shot_id} has no critique in any round"
            )
            continue
        latest = max(int(r) for r in entry["rounds"])
        entry["latest_round"] = latest
        entry["latest_verdict"] = entry["rounds"][str(latest)]["verdict"]

    for shot_id in report.shots:
        if shot_ids and shot_id not in shot_ids:
            report.errors.append(
                f"coverage: a critique names {shot_id}, which is not in {shots_rel}"
            )


def validate_tree(output_dir: Path) -> Report:
    report = Report(output_dir)
    if not output_dir.is_dir():
        report.errors.append(f"not a directory: {output_dir}")
        return report
    run_doc = check_run_doc(report)
    check_critiques(report, run_doc)
    check_coverage(report, run_doc)
    _finalize_hash_failures(report)
    return report


def outstanding(report: Report) -> list[str]:
    """Shots whose latest verdict is not ACCEPT."""
    return sorted(
        shot_id
        for shot_id, entry in report.shots.items()
        if entry.get("latest_verdict") not in (None, "ACCEPT")
    )


def selftest() -> int:
    """Run the bundled worked example, then tamper with a copy and prove drift is caught."""
    import shutil
    import tempfile

    ok = True

    clean = validate_tree(WORKED_RUN)
    if clean.errors:
        print(f"  FAIL  selftest: the bundled worked run should be clean, got: {clean.errors}")
        ok = False
    else:
        print("  ok    selftest: the bundled worked run passes")

    if outstanding(clean):
        print(f"  FAIL  selftest: worked run should have no outstanding shots, got {outstanding(clean)}")
        ok = False
    else:
        print("  ok    selftest: every shot in the worked run ends on ACCEPT")

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        frame = scratch / "frames" / "round-2" / "shot_02.png"
        frame.write_bytes(frame.read_bytes() + b"\x00")
        report = validate_tree(scratch)
        if any("does not match the hash recorded" in e for e in report.errors):
            print("  ok    selftest: a frame regenerated after its critique is caught")
        else:
            print(f"  FAIL  selftest: frame tampering was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        lock = scratch / "brand-lock.snapshot.md"
        lock.write_text(lock.read_text() + "\n<!-- edited mid-project -->\n")
        report = validate_tree(scratch)
        if any("brand-lock.snapshot.md' does not match" in e for e in report.errors):
            print("  ok    selftest: a brand-lock edited mid-project is caught")
        else:
            print(f"  FAIL  selftest: brand-lock drift was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        src = scratch / "critiques" / "round-2" / "shot_02.critique.json"
        (scratch / "critiques" / "round-2" / "shot_02.operator-b.json").write_text(
            src.read_text()
        )
        report = validate_tree(scratch)
        if any("two operators reviewed the same shot" in e for e in report.errors):
            print("  ok    selftest: two critiques for one shot in one round is caught")
        else:
            print(f"  FAIL  selftest: duplicate critique was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        source = scratch / "frames" / "round-2" / "shot_02.png"
        (scratch / "frames" / "round-2" / "shot_01.png").write_bytes(source.read_bytes())
        report = validate_tree(scratch)
        if any("was never reviewed" in e for e in report.errors):
            print("  ok    selftest: a frame with no critique for its round is caught")
        else:
            print(f"  FAIL  selftest: unreviewed frame was not caught, got: {report.errors}")
            ok = False

    # A legacy tree keeps its critique at the output root. validate_critique.py and
    # shots-to-html.py both read it, so this tool has to as well: reporting a shot as
    # unreviewed while the preview shows its verdict badge is the exact kind of
    # disagreement between consumers that this release exists to remove.
    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "legacy"
        scratch.mkdir()
        shutil.copy(WORKED_RUN / "shots.json", scratch / "shots.json")
        shutil.copy(
            WORKED_RUN / "critiques" / "round-1" / "shot_01.critique.json",
            scratch / "critique.json",
        )
        report = validate_tree(scratch)
        if "shot_01" in report.shots:
            print("  ok    selftest: a legacy root critique.json is still discovered")
        else:
            print(
                "  FAIL  selftest: legacy root critique.json was ignored; "
                f"shots seen: {sorted(report.shots)}"
            )
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_provenance.py <output-dir> [...]")
        print("       python tools/validate_provenance.py <output-dir> --require-accept")
        print("       python tools/validate_provenance.py --examples")
        print("       python tools/validate_provenance.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    require_accept = "--require-accept" in args
    as_json = "--json" in args
    targets_raw = [a for a in args if not a.startswith("--")]

    if "--examples" in args:
        targets = [WORKED_RUN]
    elif targets_raw:
        targets = [Path(t) for t in targets_raw]
    else:
        print("ERROR: no output directory given")
        return 2

    reports = [validate_tree(t) for t in targets]

    if as_json:
        print(json.dumps([r.as_dict() for r in reports], indent=2))
    else:
        print(f"Validating provenance for {len(reports)} output tree(s)")
        print()
        for report in reports:
            try:
                label = report.output_dir.relative_to(REPO_ROOT)
            except ValueError:
                label = report.output_dir
            if report.errors:
                print(f"  FAIL  {label}")
                for err in report.errors:
                    print(f"        - {err}")
            else:
                print(f"  ok    {label}  ({len(report.shots)} shot(s), rounds {report.rounds_seen or 'none'})")
            for warn in report.warnings:
                print(f"  warn  {label}: {warn}")
            for shot_id in sorted(report.shots):
                entry = report.shots[shot_id]
                verdict = entry.get("latest_verdict", "?")
                print(
                    f"        {shot_id}: {verdict} "
                    f"(round {entry.get('latest_round', '?')})"
                )
        print()

    failed = any(r.errors for r in reports)
    unresolved = {
        str(r.output_dir): outstanding(r) for r in reports if outstanding(r)
    }

    if not as_json:
        if failed:
            total = sum(len(r.errors) for r in reports)
            print(f"FAILED: {total} provenance error(s).")
        elif require_accept and unresolved:
            for path, shots in unresolved.items():
                print(f"NOT DONE: {path} still has non-ACCEPT shots: {', '.join(shots)}")
        else:
            print("Provenance chain intact.")

    if failed:
        return 1
    if require_accept and unresolved:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/validate_provenance.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/validate_schemas.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/validate_schemas.py`

#!/usr/bin/env python3
"""
Validate that every *.schema.json file in the repo is itself valid JSON Schema.

Run from repo root:
    python tools/validate_schemas.py
"""

from __future__ import annotations
import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
    from jsonschema.exceptions import SchemaError
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install jsonschema")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent


def find_schema_files() -> list[Path]:
    """Find every *.schema.json file in the repo."""
    return sorted(REPO_ROOT.rglob("*.schema.json"))


def validate_schema_file(path: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        errors.append(f"invalid JSON: {e}")
        return errors

    try:
        Draft202012Validator.check_schema(data)
    except SchemaError as e:
        errors.append(f"invalid schema: {e.message}")

    if "$id" not in data:
        errors.append("missing '$id' field")
    if "title" not in data:
        errors.append("missing 'title' field")
    if "description" not in data:
        errors.append("missing 'description' field")

    return errors


def main() -> int:
    schemas = find_schema_files()
    if not schemas:
        print("ERROR: no *.schema.json files found in repo")
        return 1

    print(f"Validating {len(schemas)} schema file(s)")
    print()

    total_errors = 0
    for path in schemas:
        rel = path.relative_to(REPO_ROOT)
        errors = validate_schema_file(path)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All schemas valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across schemas.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/validate_schemas.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/validate_shots.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/validate_shots.py`

#!/usr/bin/env python3
"""
Validate a storyboard output set: shots.json and text-overlays.json, as instances.

Schema validation alone was never enough here. Every rule below is documented in
skills/storyboard-architect/SKILL.md as a quality-bar checkbox, which means it was
enforced by a model remembering to check it. These are the same rules, executable.

Checks:
  1. shots.json validates against shots.schema.json.
  2. text-overlays.json validates against text-overlays.schema.json.
  3. Timing: end > start, no duplicate ids, no gaps, no overlaps, and the covered
     span matches project.duration_s within TIMING_TOLERANCE_S.
  4. Reference integrity, both directions: every shot.on_screen_text resolves to an
     overlay, every overlay.shot_id resolves to a shot, and every overlay is
     reachable from at least one shot.
  5. Overlay timing sits inside its shot window and exit is after enter.
  6. Every overlay color appears in the brand-lock palette.
  7. brand_lock_ref resolves on disk.
  8. Every assets.generated[].generator is a real id in the capability matrix.
  9. Warnings for prose leaks: on-screen copy repeated in a shot subject, raw hex in
     a shot subject, shot ids out of chronological order, overlay fonts not named in
     the brand-lock typography section.

Usage:
    python tools/validate_shots.py <output-dir> [...]
    python tools/validate_shots.py path/to/shots.json [...]
    python tools/validate_shots.py --examples          # every bundled example
    python tools/validate_shots.py --selftest          # prove the checks fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    HEX_RE,
    REPO_ROOT,
    as_overlay_ids,
    as_shot_ids,
    capability_ids,
    load_json,
    palette_hexes,
    parse_typography,
)

SHOTS_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "shots.schema.json"
)
OVERLAYS_SCHEMA = (
    REPO_ROOT
    / "skills"
    / "storyboard-architect"
    / "templates"
    / "text-overlays.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "storyboard-architect" / "examples"

TIMING_TOLERANCE_S = 0.1


def _schema_errors(data, validator: Draft202012Validator, label: str) -> list[str]:
    out = []
    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        out.append(f"{label} schema: {loc}: {err.message}")
    return out


def check_timing(shots: list[dict], duration_s: float) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    seen: set[str] = set()
    for shot in shots:
        sid = shot.get("id", "?")
        if sid in seen:
            errors.append(f"timing: duplicate shot id '{sid}'")
        seen.add(sid)
        start, end = shot.get("start"), shot.get("end")
        if isinstance(start, (int, float)) and isinstance(end, (int, float)):
            if end <= start:
                errors.append(
                    f"timing: {sid} has end ({end}) not after start ({start})"
                )

    timed = [
        s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    ]
    if not timed:
        return errors, warnings

    ordered = sorted(timed, key=lambda s: (s["start"], s["end"]))
    for a, b in zip(ordered, ordered[1:]):
        if b["start"] > a["end"] + 1e-9:
            errors.append(
                f"timing: gap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )
        elif b["start"] < a["end"] - 1e-9:
            errors.append(
                f"timing: overlap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )

    span = max(s["end"] for s in timed) - min(s["start"] for s in timed)
    if abs(span - duration_s) > TIMING_TOLERANCE_S:
        errors.append(
            f"timing: covered span {span:g}s does not match project.duration_s "
            f"{duration_s:g}s (tolerance {TIMING_TOLERANCE_S}s)"
        )

    if [s["id"] for s in timed] != [s["id"] for s in ordered]:
        warnings.append(
            "timing: shot ids are not in chronological order; readers assume they are"
        )

    return errors, warnings


def check_version_features(shots: list[dict], version: str) -> list[str]:
    """Features may not be used below the version that introduced them."""
    errors: list[str] = []
    if version in ("1.0", "1.1"):
        for shot in shots:
            if isinstance(shot.get("on_screen_text"), list):
                errors.append(
                    f"version: {shot.get('id')} uses the array form of on_screen_text, "
                    f"which requires version 1.2 (file declares {version})"
                )
    if version == "1.0":
        for shot in shots:
            if shot.get("assets") is not None:
                errors.append(
                    f"version: {shot.get('id')} carries an assets block, which "
                    f"requires version 1.1 or later (file declares 1.0)"
                )
    return errors


def check_references(
    shots: list[dict], overlays: list[dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    shot_ids = {s.get("id") for s in shots}
    overlay_ids: set[str] = set()
    for overlay in overlays:
        oid = overlay.get("id")
        if oid in overlay_ids:
            errors.append(f"reference: duplicate overlay id '{oid}'")
        overlay_ids.add(oid)

    referenced: set[str] = set()
    for shot in shots:
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            referenced.add(oid)
            if oid not in overlay_ids:
                errors.append(
                    f"reference: {shot.get('id')}.on_screen_text '{oid}' has no "
                    f"entry in text-overlays.json"
                )

    for overlay in overlays:
        oid = overlay.get("id")
        for sid in as_shot_ids(overlay.get("shot_id")):
            if sid not in shot_ids:
                errors.append(
                    f"reference: overlay {oid}.shot_id '{sid}' has no entry in shots.json"
                )
        if oid not in referenced:
            errors.append(
                f"reference: overlay {oid} is not reachable from any "
                f"shot.on_screen_text, so no renderer will show it"
            )

    return errors, warnings


def check_overlay_windows(shots: list[dict], overlays: list[dict]) -> list[str]:
    errors: list[str] = []
    by_id = {
        s["id"]: s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    }

    for overlay in overlays:
        oid = overlay.get("id")
        enter = (overlay.get("enter") or {}).get("at")
        exit_at = (overlay.get("exit") or {}).get("at")
        if not isinstance(enter, (int, float)) or not isinstance(exit_at, (int, float)):
            continue
        if exit_at <= enter:
            errors.append(
                f"overlay: {oid} exit ({exit_at}) is not after enter ({enter})"
            )
        windows = [by_id[s] for s in as_shot_ids(overlay.get("shot_id")) if s in by_id]
        if not windows:
            continue
        lo = min(w["start"] for w in windows)
        hi = max(w["end"] for w in windows)
        if enter < lo - 1e-9 or exit_at > hi + 1e-9:
            errors.append(
                f"overlay: {oid} timing {enter}-{exit_at}s falls outside its shot "
                f"window {lo:g}-{hi:g}s"
            )

    return errors


def check_brand_alignment(
    shots: list[dict], overlays: list[dict], brand_lock_text: str | None
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if brand_lock_text is None:
        warnings.append(
            "brand: brand_lock_ref did not resolve, so palette and font checks were skipped"
        )
        return errors, warnings

    allowed = palette_hexes(brand_lock_text)
    for overlay in overlays:
        color = overlay.get("color")
        if isinstance(color, str) and color.lower() not in allowed:
            errors.append(
                f"brand: overlay {overlay.get('id')} color {color} is not in the "
                f"brand-lock palette"
            )

    fonts = {v.lower() for v in parse_typography(brand_lock_text).values() if v}
    if fonts:
        for overlay in overlays:
            font = overlay.get("font")
            if isinstance(font, str) and font.lower() not in fonts:
                warnings.append(
                    f"brand: overlay {overlay.get('id')} font '{font}' is not a font "
                    f"declared in the brand-lock typography section"
                )

    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        for hex_val in HEX_RE.findall(subject):
            warnings.append(
                f"brand: {shot.get('id')}.subject names a raw hex ({hex_val}); "
                f"colors belong in series_lock and the brand-lock"
            )

    return errors, warnings


def check_text_leak(shots: list[dict], overlays: list[dict]) -> list[str]:
    """On-screen copy repeated inside a shot subject. Text is a separate layer."""
    warnings: list[str] = []
    contents = {
        o.get("id"): o.get("content")
        for o in overlays
        if isinstance(o.get("content"), str) and len(o.get("content", "")) >= 8
    }
    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        lowered = subject.lower()
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            content = contents.get(oid)
            if content and content.lower().rstrip(".!?") in lowered:
                warnings.append(
                    f"text: {shot.get('id')}.subject repeats overlay {oid} copy "
                    f"verbatim; on-screen text is composited, never described"
                )
    return warnings


def check_assets(shots: list[dict], known_generators: set[str]) -> list[str]:
    errors: list[str] = []
    if not known_generators:
        return errors
    for shot in shots:
        for entry in (shot.get("assets") or {}).get("generated", []) or []:
            gen = entry.get("generator")
            if isinstance(gen, str) and gen not in known_generators:
                errors.append(
                    f"assets: {shot.get('id')} generated frame names generator "
                    f"'{gen}', which is not in the capability matrix"
                )
            if entry.get("accepted") is True and not entry.get("critique_ref"):
                errors.append(
                    f"assets: {shot.get('id')} has an accepted frame with no "
                    f"critique_ref, which is an unsourced approval"
                )
    return errors


def validate_set(shots_path: Path) -> tuple[list[str], list[str]]:
    """Validate one shots.json plus the siblings it points at."""
    errors: list[str] = []
    warnings: list[str] = []

    shots_data, err = load_json(shots_path)
    if err:
        return ([err], warnings)
    if not isinstance(shots_data, dict):
        return ([f"{shots_path}: top level is not an object"], warnings)

    shots_schema, s_err = load_json(SHOTS_SCHEMA)
    overlays_schema, o_err = load_json(OVERLAYS_SCHEMA)
    if s_err or o_err:
        return ([s_err or o_err], warnings)

    errors += _schema_errors(
        shots_data, Draft202012Validator(shots_schema), "shots.json"
    )

    base = shots_path.parent
    overlays_path = base / "text-overlays.json"
    overlays: list[dict] = []
    if overlays_path.exists():
        overlays_data, ov_err = load_json(overlays_path)
        if ov_err:
            errors.append(f"text-overlays.json: {ov_err}")
        else:
            errors += _schema_errors(
                overlays_data,
                Draft202012Validator(overlays_schema),
                "text-overlays.json",
            )
            overlays = overlays_data.get("overlays", []) or []
    else:
        for shot in shots_data.get("shots", []) or []:
            if as_overlay_ids(shot.get("on_screen_text")):
                errors.append(
                    "reference: shots.json references on-screen text but "
                    "text-overlays.json is missing"
                )
                break

    if errors:
        # Structure-dependent checks assume schema-valid input.
        return (errors, warnings)

    shots = shots_data.get("shots", []) or []
    duration = shots_data.get("project", {}).get("duration_s")

    errors += check_version_features(shots, shots_data.get("version", ""))

    if isinstance(duration, (int, float)):
        t_err, t_warn = check_timing(shots, float(duration))
        errors += t_err
        warnings += t_warn

    r_err, r_warn = check_references(shots, overlays)
    errors += r_err
    warnings += r_warn
    errors += check_overlay_windows(shots, overlays)

    brand_ref = shots_data.get("brand_lock_ref")
    brand_text: str | None = None
    if isinstance(brand_ref, str):
        brand_path = base / brand_ref
        if brand_path.exists():
            brand_text = brand_path.read_text(encoding="utf-8")
        else:
            errors.append(
                f"brand: brand_lock_ref '{brand_ref}' does not resolve from {base}"
            )
    b_err, b_warn = check_brand_alignment(shots, overlays, brand_text)
    errors += b_err
    warnings += b_warn

    warnings += check_text_leak(shots, overlays)
    errors += check_assets(shots, capability_ids())

    return (errors, warnings)


def _resolve_target(raw: str) -> Path | None:
    path = Path(raw)
    if path.is_dir():
        candidate = path / "shots.json"
        return candidate if candidate.exists() else None
    return path if path.exists() else None


def selftest() -> int:
    """Prove the cross-field checks fire. Fixtures are in-memory, no files touched."""
    ok = True
    cases = [
        (
            "end not after start",
            lambda: check_timing(
                [{"id": "shot_01", "start": 5.0, "end": 3.0}], 30.0
            )[0],
        ),
        (
            "gap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 2.0},
                    {"id": "shot_02", "start": 4.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "overlap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 5.0},
                    {"id": "shot_02", "start": 3.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "span disagrees with duration",
            lambda: check_timing(
                [{"id": "shot_01", "start": 0.0, "end": 10.0}], 30.0
            )[0],
        ),
        (
            "dangling on_screen_text",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": "text_09"}], []
            )[0],
        ),
        (
            "unreachable overlay",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": None}],
                [{"id": "text_01", "shot_id": "shot_01"}],
            )[0],
        ),
        (
            "overlay outside its shot window",
            lambda: check_overlay_windows(
                [{"id": "shot_01", "start": 0.0, "end": 2.0}],
                [
                    {
                        "id": "text_01",
                        "shot_id": "shot_01",
                        "enter": {"at": 0.0},
                        "exit": {"at": 9.0},
                    }
                ],
            ),
        ),
        (
            "off-palette overlay color",
            lambda: check_brand_alignment(
                [],
                [{"id": "text_01", "color": "#ABCDEF"}],
                "## Palette\n\n| Role | Hex |\n|---|---|\n| Ink | `#2A2A32` |\n",
            )[0],
        ),
        (
            "accepted frame with no critique_ref",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {"generated": [{"path": "a.png", "accepted": True}]},
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "unknown generator id",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {
                            "generated": [{"path": "a.png", "generator": "runway-sora"}]
                        },
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "1.2 feature used in a 1.0 file",
            lambda: check_version_features(
                [{"id": "shot_01", "on_screen_text": ["text_01", "text_02"]}], "1.0"
            ),
        ),
    ]

    for label, fn in cases:
        produced = fn()
        if produced:
            print(f"  ok    selftest: {label} is caught")
        else:
            print(f"  FAIL  selftest: {label} was not caught")
            ok = False

    clean, clean_warn = check_timing(
        [
            {"id": "shot_01", "start": 0.0, "end": 2.0},
            {"id": "shot_02", "start": 2.0, "end": 30.0},
        ],
        30.0,
    )
    if clean or clean_warn:
        print(f"  FAIL  selftest: a clean shot list should pass, got: {clean + clean_warn}")
        ok = False
    else:
        print("  ok    selftest: a clean shot list passes")

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_shots.py <output-dir|shots.json> [...]")
        print("       python tools/validate_shots.py --examples")
        print("       python tools/validate_shots.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    if "--examples" in args:
        targets = sorted(EXAMPLES_DIR.glob("*/shots.json"))
        if not targets:
            print(f"ERROR: no bundled examples found under {EXAMPLES_DIR}")
            return 1
    else:
        targets = []
        for raw in args:
            resolved = _resolve_target(raw)
            if resolved is None:
                print(f"  FAIL  {raw}")
                print("        - no shots.json found at this path")
                return 1
            targets.append(resolved)

    print(f"Validating {len(targets)} storyboard set(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for shots_path in targets:
        try:
            rel = shots_path.relative_to(REPO_ROOT)
        except ValueError:
            rel = shots_path
        errors, warnings = validate_set(shots_path)
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {rel}: {warn}")

    print()
    if total_errors == 0:
        print(f"All storyboard sets valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across storyboard sets.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/validate_shots.py -->


<!-- SOURCE_FILE_START: skills/storyboard-architect/tools/validate_skills.py -->
# SOURCE FILE: `skills/storyboard-architect/tools/validate_skills.py`

#!/usr/bin/env python3
"""
Validate every SKILL.md in the repo has the required frontmatter.

Required fields:
- name (string, matches the directory name)
- description (string, non-empty)

Run from repo root:
    python tools/validate_skills.py
"""

from __future__ import annotations
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML not installed. Run: pip install pyyaml")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent
SKILLS_DIR = REPO_ROOT / "skills"


def parse_frontmatter(path: Path) -> dict | None:
    """Extract YAML frontmatter from a Markdown file. Returns None if absent."""
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    parts = text.split("---", 2)
    if len(parts) < 3:
        return None
    try:
        return yaml.safe_load(parts[1])
    except yaml.YAMLError as e:
        print(f"  YAML parse error: {e}")
        return None


def validate_skill(skill_dir: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    skill_md = skill_dir / "SKILL.md"

    if not skill_md.exists():
        errors.append(f"missing SKILL.md")
        return errors

    fm = parse_frontmatter(skill_md)
    if fm is None:
        errors.append("missing or invalid YAML frontmatter")
        return errors

    if "name" not in fm:
        errors.append("frontmatter missing 'name'")
    elif not isinstance(fm["name"], str) or not fm["name"].strip():
        errors.append("frontmatter 'name' must be a non-empty string")
    elif fm["name"] != skill_dir.name:
        errors.append(
            f"frontmatter name '{fm['name']}' does not match directory name '{skill_dir.name}'"
        )

    if "description" not in fm:
        errors.append("frontmatter missing 'description'")
    elif not isinstance(fm["description"], str) or not fm["description"].strip():
        errors.append("frontmatter 'description' must be a non-empty string")
    elif len(fm["description"]) < 50:
        errors.append(
            f"frontmatter description is too short ({len(fm['description'])} chars). "
            "Aim for >= 50 chars to support skill triggering."
        )

    return errors


def main() -> int:
    if not SKILLS_DIR.exists():
        print(f"ERROR: skills directory not found at {SKILLS_DIR}")
        return 1

    skill_dirs = sorted([d for d in SKILLS_DIR.iterdir() if d.is_dir()])
    if not skill_dirs:
        print(f"ERROR: no skill directories found in {SKILLS_DIR}")
        return 1

    print(f"Validating {len(skill_dirs)} skill(s) in {SKILLS_DIR.relative_to(REPO_ROOT)}/")
    print()

    total_errors = 0
    for skill_dir in skill_dirs:
        errors = validate_skill(skill_dir)
        rel = skill_dir.relative_to(REPO_ROOT)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All skills valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across skills.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/storyboard-architect/tools/validate_skills.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/LICENSE -->
# SOURCE FILE: `skills/storyboard-html-preview/LICENSE`

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2026 Yuri Strohm / WhyStrohm

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/LICENSE -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/SKILL.md -->
# SOURCE FILE: `skills/storyboard-html-preview/SKILL.md`

---
name: storyboard-html-preview
description: Render a structured storyboard (storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md) into a single-file HTML preview that is shareable, printable, and offline. Use when the user wants to share a storyboard, export for review, hand off to an editor, or print a hard copy. Triggers on "preview the storyboard", "share this", "export to HTML", "print version", or after a storyboard-architect run. Produces one self-contained .html file with no build or server.
---

# Storyboard HTML Preview

You are turning structured storyboard files into a single shareable HTML document. The output is what an editor, stakeholder, or client opens in a browser without thinking about it.

The constraint is non-negotiable: **single file, no build step, no server, works offline.** Any time the output requires "run this build command" or "host this somewhere," the skill has failed.

## When to use

Trigger when the user:

- Asks to preview, share, or export a storyboard
- Wants a printable version
- Says "what's the next step" after a storyboard-architect run
- Hands off `storyboard.md` + `shots.json` + asks for a deliverable for review

## What you produce

One file: `preview.html`. Self-contained. Inline CSS. No JavaScript dependencies (vanilla JS only, embedded). No external font files (uses system stack with brand-font fallbacks). No external images (placeholder slots; if generated images exist, embed as base64 OR reference relative paths).

```
output/
├── run.json                   # input, for the run id and date
├── storyboard.md              # input
├── shots.json                 # input
├── text-overlays.json         # input
├── brand-lock.snapshot.md     # input
├── frames/round-N/            # input, if generation has happened
├── critiques/round-N/         # input, for the verdict badges
└── preview.html               # ← what this skill produces
```

If the user has generated frames, the HTML references them via relative paths so the file
works when the whole `output/` folder is shared. Resolve a shot's frame in this order:

1. An entry in `shot.assets.generated` marked `accepted: true`
2. The newest entry in `shot.assets.generated`
3. `frames/round-{highest}/{shot_id}.{png,jpg,jpeg,webp}`
4. `generated/{shot_id}.{ext}`, the pre-3.0.0 flat layout

Data first, convention second. Reading the path convention first meant the page showed
whatever file happened to sit there, accepted or rejected, first draft or fifth re-roll.

If no frames exist yet, the HTML uses styled placeholder cards with the shot spec, still
useful for review and handoff.

## Workflow

### Step 1. Read inputs

Required:

- `shots.json`
- `text-overlays.json`
- `brand-lock.snapshot.md`

Optional:

- `run.json` (for the run id and date; without it the page says "not recorded")
- `storyboard.md` (for narrative context, surface the brief at the top)
- `frames/round-N/{shot_id}.{png,jpg,jpeg,webp}` (if generation has happened)
- `critiques/round-N/{shot_id}.critique.json` (for verdict badges)

Validate before rendering, and stop if it fails:

```bash
python tools/validate_shots.py output/
```

### Step 2. Extract brand parameters

From `brand-lock.snapshot.md`, extract:

- Palette (hex values), used for HTML accent colors
- Display font and body font names, used as font-family values with system fallbacks
- Brand voice / mood, used in subtle copy choices

The HTML preview should *feel* like the brand without going overboard. Quiet branding, not loud.

### Step 3. Generate the HTML

Use `templates/preview.html.tpl` as the structural template. Read it before generating.

The HTML structure:

```
<!DOCTYPE html>
<html>
<head>
  <meta>
  <title>{project title}</title>
  <style>
    /* All CSS inline. ~200 lines. Brand-aware. */
    /* Print stylesheet included. */
  </style>
</head>
<body>
  <header>
    <!-- Project title, duration, aspect, generated timestamp -->
  </header>

  <section class="brief">
    <!-- Brief summary if storyboard.md provides one -->
  </section>

  <section class="series-lock">
    <!-- Character / environment / lighting / color grade -->
  </section>

  <section class="shots">
    <!-- One card per shot -->
    <article class="shot" id="shot_01">
      <div class="shot-frame">
        <!-- generated image OR styled placeholder -->
      </div>
      <div class="shot-meta">
        <!-- timestamp, framing, angle, motion -->
      </div>
      <div class="shot-subject">
        <!-- subject description -->
      </div>
      <div class="shot-text-overlay">
        <!-- if on_screen_text exists, show overlay content with timing -->
      </div>
      <div class="shot-rationale">
        <!-- rationale text -->
      </div>
    </article>
    <!-- ... -->
  </section>

  <footer>
    <!-- audit trail: brand-lock snapshot reference, timestamp -->
  </footer>

  <script>
    /* Vanilla JS only. Optional: keyboard nav, jump-to-shot, expand/collapse. */
  </script>
</body>
</html>
```

### Step 4. Embed frames if available

Resolve each shot's frame by the order in "What you produce" above, then reference it by a
path relative to the output root:

```html
<img src="frames/round-2/shot_01.png" alt="shot_01: hook" loading="lazy" />
```

This works when the whole output folder is zipped and shared.

For hard-copy print (a single file with no folder structure), the skill can offer to inline
frames as base64. Ask the user which they prefer if frames are present.

If a shot's `assets.generated` entry carries a `sha256` and the file no longer matches it,
render the frame but say so on the page. That mismatch means the frame changed after it was
recorded, which is exactly the case where a preview quietly showing the new file is worse
than one that flags it.

If no frames exist, render styled placeholder cards showing the framing, subject, and shot
spec. These are still useful for stakeholder review at the storyboard stage.

**Template flag convention.** When composing the per-shot context for `preview.html.tpl`, set exactly one of:

- `has_image: true` and `image_path: "frames/round-2/shot_NN.png"`, when a frame exists
- `has_no_image: true`, when none does (renders the placeholder card)

The template uses two parallel `{{#if}}` blocks rather than `{{#if}}/{{else}}` to keep the rendering portable across template engines.

For text overlays, set `has_overlays: true` and an `overlays` array on the shot. Each entry
carries `id`, `content`, `font`, `weight`, `color`, `size`, `position_class`,
`position_label`, `enter_at`, `enter_animation`, `exit_at`, `exit_animation`. The template
iterates that array with `{{#each overlays}}`.

It is an array because `shots.json` lets a shot carry several overlays and
`text-overlays.json` always did. A single set of `overlay_*` fields could hold one, so the
second overlay on a shot rendered nowhere and nothing reported it.

For verdict badges, set `has_verdict`, `verdict`, `verdict_round`, and `verdict_class`
(the lowercased verdict) from the newest critique for that shot under `critiques/`. Omit
them when the shot has no critique.

**Escape everything.** Subjects, rationales, VO lines, and overlay copy are model-generated
prose that lands in both text and attribute contexts. One angle bracket in a rationale, or
one quote in an overlay font name, breaks the page a client is reading.
`tools/shots-to-html.py` escapes every substitution by default and reserves raw output for
the inlined CSS alone.

### Step 5. Render text overlays visually

For every shot with an `on_screen_text` reference, the HTML shows:

- The text content rendered in approximately the brand font (or visible fallback)
- The position indicated visually (lower-third, center, etc.)
- Timing info (enter/exit beats)

This gives the reviewer a sense of what the final composited frame will look like, even before final compositing happens.

### Step 6. Print stylesheet

Include `@media print` rules that:

- Hide nav, footer scripts, expand/collapse UI
- Force one shot per page (or two if compact)
- Ensure text overlays render legibly
- Use black-on-white where brand colors won't print well

The user should be able to hit Cmd-P / Ctrl-P and get a clean PDF.

## Hard rules

### Rule 1. Single file, no exceptions

The output is one `.html` file. If you find yourself wanting a separate stylesheet or JS file, inline it. If you find yourself wanting a build step, you're solving the wrong problem.

### Rule 2. No external dependencies at runtime

No CDN scripts. No Google Fonts. No external CSS frameworks. The file must work with no internet connection.

The exception: if the user explicitly opts in (e.g. "make it pretty, I'm online"), Tailwind via CDN is acceptable. Default is no.

### Rule 3. Print must work

Hit Cmd-P. The result should be a clean PDF. If layout breaks across page boundaries, the print stylesheet is broken.

### Rule 4. Brand-aware but quiet

Use brand colors as accents, not as full backgrounds. The reviewer's job is to read the storyboard, not admire the design. Subtle.

### Rule 5. Mobile-readable

Stakeholders open links on phones. The HTML should be readable on mobile without horizontal scroll. Simple responsive CSS.

## Templates

- `templates/preview.html.tpl`, the structural template
- `templates/styles.css.tpl`, the CSS to inline
- `templates/print.css.tpl`, the print rules

The skill reads all three and assembles them into a single `preview.html`.

## Quality bar

Before declaring done, verify:

- [ ] File opens in any browser (Chrome, Safari, Firefox) with no errors
- [ ] No external network requests fire on load
- [ ] Print preview produces a clean PDF
- [ ] Mobile viewport (375px) renders without horizontal scroll
- [ ] Brand colors and fonts come from the brand-lock, not from a fallback
- [ ] Every shot from `shots.json` is present
- [ ] Every overlay referenced by a shot is rendered, including second and third overlays
- [ ] `brand_lock_ref` from `shots.json` is what the footer links to, not a hardcoded name
- [ ] The run date and the render date are both shown, and labelled differently
- [ ] No `{{` remains anywhere in the output

The CLI renderer checks the mechanical half of that list against itself:

```bash
python tools/shots-to-html.py --selftest
```

## Two timestamps, not one

"Run" is when the storyboard was produced, read from `run.json`. "Rendered" is when the page
was written. They are separate lines in the footer and they must stay separate.

Collapsing them into a single "Generated" date meant re-rendering a preview six months later
restamped the run as today, and the footer went on asserting the page was built against a
brand-lock on a date that had nothing to do with the frames above it.

If the brand-lock on disk no longer hashes to what `run.json` recorded, say so on the page.
The reader is looking at frames built against a brand state they can no longer see.

## Examples

Generated `preview.html` files ship next to the storyboards that produced them:

- `../storyboard-architect/examples/30s-pain-proof-promise/preview.html`
- `../storyboard-architect/examples/60s-founder-explainer/preview.html`
- `../storyboard-architect/examples/shotkit-explainer/preview.html`, including the
  two-overlay shot
- `../visual-asset-critic/examples/worked-run/preview.html`, with frames and verdict badges

Open them in a browser to calibrate quality. All four are re-rendered in CI with pinned
timestamps and the build fails if the output moves, so they are also the regression test for
this skill's output.

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/SKILL.md -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/templates/preview.html.tpl -->
# SOURCE FILE: `skills/storyboard-html-preview/templates/preview.html.tpl`

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="generator" content="storyboard-html-preview / WhyStrohm">
<title>{{PROJECT_TITLE}} · Storyboard</title>
<style>
{{{INLINE_CSS}}}
</style>
</head>
<body>

<header class="sb-header">
  <div class="sb-header-inner">
    <div class="sb-eyebrow">Storyboard · shots {{SHOTS_VERSION}}</div>
    <h1 class="sb-title">{{PROJECT_TITLE}}</h1>
    <dl class="sb-meta">
      <div><dt>Duration</dt><dd>{{DURATION}}s</dd></div>
      <div><dt>Aspect</dt><dd>{{ASPECT}}</dd></div>
      <div><dt>Framework</dt><dd>{{FRAMEWORK}}</dd></div>
      <div><dt>Run</dt><dd>{{RUN_CREATED_AT}}</dd></div>
    </dl>
  </div>
</header>

<nav class="sb-nav" aria-label="Shot navigation">
  <ul>
    {{#each shots}}
    <li><a href="#{{id}}">{{id_short}}</a></li>
    {{/each}}
  </ul>
</nav>

{{#if BRIEF}}
<section class="sb-section sb-brief">
  <h2>Brief</h2>
  <p>{{BRIEF}}</p>
</section>
{{/if}}

<section class="sb-section sb-series-lock">
  <h2>Series lock</h2>
  <dl class="sb-series-grid">
    <div>
      <dt>Character</dt>
      <dd>{{SERIES_CHARACTER}}</dd>
    </div>
    <div>
      <dt>Environment</dt>
      <dd>{{SERIES_ENVIRONMENT}}</dd>
    </div>
    <div>
      <dt>Lighting</dt>
      <dd>{{SERIES_LIGHTING}}</dd>
    </div>
    <div>
      <dt>Color grade</dt>
      <dd>{{SERIES_COLOR_GRADE}}</dd>
    </div>
  </dl>
</section>

<section class="sb-section sb-shots">
  <h2>Shots</h2>
  {{#each shots}}
  <article class="sb-shot" id="{{id}}">
    <div class="sb-shot-frame {{aspect_class}}">
      {{#if has_image}}
      <img src="{{image_path}}" alt="{{id}}: {{beat}}" loading="lazy">
      {{/if}}
      {{#if has_no_image}}
      <div class="sb-placeholder">
        <div class="sb-placeholder-id">{{id_short}}</div>
        <div class="sb-placeholder-meta">{{framing}} · {{angle}} · {{motion}}</div>
      </div>
      {{/if}}

      {{#each overlays}}
      <div class="sb-overlay sb-overlay-{{position_class}}">
        <span class="sb-overlay-text" style="font-family: {{font}}; font-weight: {{weight}}; color: {{color}};">{{content}}</span>
      </div>
      {{/each}}
    </div>

    <div class="sb-shot-body">
      <header class="sb-shot-header">
        <span class="sb-shot-id">{{id_short}}</span>
        <span class="sb-shot-time">{{start}}–{{end}}s</span>
        <span class="sb-shot-beat">{{beat}}</span>
        {{#if has_verdict}}
        <span class="sb-verdict sb-verdict-{{verdict_class}}">{{verdict}}<span class="sb-verdict-round">round {{verdict_round}}</span></span>
        {{/if}}
      </header>

      <dl class="sb-shot-meta">
        <div><dt>Framing</dt><dd>{{framing}}</dd></div>
        <div><dt>Angle</dt><dd>{{angle}}</dd></div>
        <div><dt>Motion</dt><dd>{{motion}}</dd></div>
        {{#if depth_of_field}}
        <div><dt>DOF</dt><dd>{{depth_of_field}}</dd></div>
        {{/if}}
      </dl>

      <div class="sb-shot-subject">
        <h3>Subject</h3>
        <p>{{subject}}</p>
      </div>

      {{#if vo}}
      <div class="sb-shot-vo">
        <h3>VO</h3>
        <p>"{{vo}}"</p>
      </div>
      {{/if}}

      {{#if has_overlays}}
      <div class="sb-shot-text">
        <h3>On-screen text</h3>
        {{#each overlays}}
        <p class="sb-text-content">"{{content}}"</p>
        <p class="sb-text-meta">{{id}} · {{size}} · {{position_label}} · enter {{enter_at}}s ({{enter_animation}}) · exit {{exit_at}}s ({{exit_animation}})</p>
        {{/each}}
      </div>
      {{/if}}

      <div class="sb-shot-rationale">
        <h3>Rationale</h3>
        <p>{{rationale}}</p>
      </div>
    </div>
  </article>
  {{/each}}
</section>

<footer class="sb-footer">
  <div class="sb-footer-inner">
    <div>
      Built against <a href="{{BRAND_LOCK_REF}}"><code>{{BRAND_LOCK_REF}}</code></a>{{#if BRAND_LOCK_SHA_SHORT}} (<code>{{BRAND_LOCK_SHA_SHORT}}</code>){{/if}}.
    </div>
    <div>Built with <a href="https://github.com/whystrohm/shotkit">shotkit</a> · WhyStrohm</div>
  </div>
  <div class="sb-footer-inner sb-provenance">
    <div>
      Run {{RUN_ID}} started {{RUN_CREATED_AT}}. This page rendered {{RENDERED_AT}}.
      {{#if PROVENANCE_NOTE}}{{PROVENANCE_NOTE}}{{/if}}
    </div>
  </div>
</footer>

<script>
// Keyboard navigation: arrow keys move between shots
(function() {
  const shots = Array.from(document.querySelectorAll('.sb-shot'));
  if (!shots.length) return;

  function shotInView() {
    const mid = window.innerHeight / 2;
    let best = 0;
    let bestDist = Infinity;
    shots.forEach((shot, i) => {
      const rect = shot.getBoundingClientRect();
      const dist = Math.abs(rect.top + rect.height / 2 - mid);
      if (dist < bestDist) { bestDist = dist; best = i; }
    });
    return best;
  }

  document.addEventListener('keydown', function(e) {
    if (e.target.matches('input, textarea')) return;
    const i = shotInView();
    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      const next = shots[Math.min(shots.length - 1, i + 1)];
      next.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      const prev = shots[Math.max(0, i - 1)];
      prev.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
})();
</script>

</body>
</html>

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/templates/preview.html.tpl -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/templates/print.css.tpl -->
# SOURCE FILE: `skills/storyboard-html-preview/templates/print.css.tpl`

@media print {
  /* ─── Page setup ─── */
  @page {
    size: letter;
    margin: 0.5in;
  }

  /* ─── Color & background ─── */
  body {
    background: white;
    color: black;
    font-size: 10pt;
    line-height: 1.4;
  }

  a {
    color: black;
    border-bottom: none;
  }

  a[href]::after {
    content: " (" attr(href) ")";
    font-family: var(--sb-font-mono);
    font-size: 8pt;
    color: #555;
  }

  /* Don't print sticky nav, JS controls, or footer scripts */
  .sb-nav { display: none; }

  /* ─── Header ─── */
  .sb-header {
    border-bottom: 2px solid black;
    padding: 0 0 16pt;
    margin-bottom: 24pt;
    page-break-after: avoid;
  }

  .sb-eyebrow {
    color: black;
    font-size: 9pt;
  }

  .sb-title {
    font-size: 24pt;
    margin-bottom: 12pt;
  }

  .sb-meta {
    grid-template-columns: repeat(4, 1fr);
    gap: 12pt;
    font-size: 9pt;
  }

  .sb-meta dt {
    color: #555;
    font-size: 7pt;
  }

  /* ─── Sections ─── */
  .sb-section {
    padding: 16pt 0;
    border-bottom: 1pt solid #999;
    page-break-inside: avoid;
  }

  .sb-section h2 {
    font-size: 9pt;
    margin-bottom: 12pt;
  }

  .sb-brief p {
    font-size: 12pt;
  }

  /* ─── Series lock ─── */
  .sb-series-grid {
    grid-template-columns: 1fr 1fr;
    gap: 12pt;
  }

  .sb-series-grid > div {
    border-left: 2pt solid black;
  }

  .sb-series-grid dt {
    color: #555;
    font-size: 7pt;
  }

  .sb-series-grid dd {
    font-size: 10pt;
  }

  /* ─── Shots, one shot per page ─── */
  .sb-shots h2 {
    page-break-after: avoid;
  }

  .sb-shot {
    page-break-inside: avoid;
    page-break-before: always;
    grid-template-columns: 1fr 1.2fr;
    gap: 18pt;
    padding: 18pt 0;
    border-bottom: none;
  }

  .sb-shot:first-of-type {
    page-break-before: avoid;
  }

  .sb-shot-frame {
    background: #f0f0f0;
    border: 1pt solid #999;
    border-radius: 0;
  }

  .sb-placeholder {
    background: #f5f5f5;
    color: #666;
  }

  .sb-overlay-text {
    text-shadow: none;
    background: rgba(255,255,255,0.85);
    padding: 2pt 6pt;
    color: black;
  }

  .sb-shot-id {
    color: black;
    font-size: 12pt;
  }

  .sb-shot-time, .sb-shot-beat {
    color: #555;
  }

  .sb-shot-rationale {
    background: #f5f5f5;
    border-left: 2pt solid black;
    padding: 8pt 10pt;
    page-break-inside: avoid;
  }

  .sb-shot-rationale p {
    font-size: 9pt;
  }

  .sb-shot-meta dt,
  .sb-shot-subject h3,
  .sb-shot-vo h3,
  .sb-shot-text h3,
  .sb-shot-rationale h3 {
    color: #555;
    font-size: 7pt;
  }

  .sb-shot-subject p,
  .sb-shot-vo p {
    font-size: 9.5pt;
  }

  /* ─── Footer ─── */
  .sb-footer {
    background: white;
    border-top: 1pt solid #999;
    padding: 12pt 0;
    font-size: 8pt;
    page-break-before: always;
  }

  .sb-footer-inner {
    flex-direction: column;
    gap: 4pt;
  }
}

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/templates/print.css.tpl -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/templates/styles.css.tpl -->
# SOURCE FILE: `skills/storyboard-html-preview/templates/styles.css.tpl`

/* ─────────────────────────────────────────────────────────────
   Storyboard HTML Preview · WhyStrohm
   Single-file output. No external deps. Prints clean.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Brand-lock variables, get substituted at compose time */
  --sb-color-bg: {{BG_COLOR}};
  --sb-color-ink: {{INK_COLOR}};
  --sb-color-accent: {{ACCENT_COLOR}};
  --sb-color-muted: {{MUTED_COLOR}};
  --sb-color-rule: {{RULE_COLOR}};

  --sb-font-display: {{DISPLAY_FONT}}, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-body: {{BODY_FONT}}, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --sb-font-mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;

  --sb-radius: 6px;
  --sb-pad: 24px;
  --sb-gap: 32px;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; }

body {
  font-family: var(--sb-font-body);
  font-size: 16px;
  line-height: 1.55;
  color: var(--sb-color-ink);
  background: var(--sb-color-bg);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

a {
  color: var(--sb-color-accent);
  text-decoration: none;
  border-bottom: 1px solid currentColor;
}

code {
  font-family: var(--sb-font-mono);
  font-size: 0.9em;
  background: var(--sb-color-rule);
  padding: 1px 6px;
  border-radius: 3px;
}

h1, h2, h3 {
  font-family: var(--sb-font-display);
  font-weight: 800;
  line-height: 1.15;
  letter-spacing: -0.01em;
}

/* ─── Header ─── */

.sb-header {
  border-bottom: 1px solid var(--sb-color-rule);
  padding: 64px var(--sb-pad) 40px;
}

.sb-header-inner {
  max-width: 960px;
  margin: 0 auto;
}

.sb-eyebrow {
  font-family: var(--sb-font-mono);
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 16px;
}

.sb-title {
  font-size: clamp(32px, 5vw, 56px);
  margin-bottom: 32px;
}

.sb-meta {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 16px;
  font-size: 14px;
}
.sb-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-meta dd { font-weight: 600; }

/* ─── Nav ─── */

.sb-nav {
  position: sticky;
  top: 0;
  background: var(--sb-color-bg);
  border-bottom: 1px solid var(--sb-color-rule);
  z-index: 10;
  overflow-x: auto;
}

.sb-nav ul {
  display: flex;
  gap: 4px;
  list-style: none;
  max-width: 960px;
  margin: 0 auto;
  padding: 12px var(--sb-pad);
}

.sb-nav a {
  display: inline-block;
  padding: 4px 10px;
  font-family: var(--sb-font-mono);
  font-size: 12px;
  border: 1px solid var(--sb-color-rule);
  border-radius: var(--sb-radius);
  color: var(--sb-color-ink);
  white-space: nowrap;
}

.sb-nav a:hover {
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
  border-color: var(--sb-color-accent);
}

/* ─── Sections ─── */

.sb-section {
  max-width: 960px;
  margin: 0 auto;
  padding: 56px var(--sb-pad);
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-section h2 {
  font-size: 14px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: var(--sb-color-muted);
  margin-bottom: 24px;
}

.sb-brief p {
  font-size: clamp(18px, 2.5vw, 24px);
  line-height: 1.45;
  max-width: 700px;
}

/* ─── Series lock ─── */

.sb-series-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 24px;
}

.sb-series-grid > div {
  border-left: 2px solid var(--sb-color-accent);
  padding-left: 14px;
}

.sb-series-grid dt {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 4px;
}

.sb-series-grid dd {
  font-size: 15px;
  line-height: 1.5;
}

/* ─── Shots ─── */

.sb-shots {
  background: var(--sb-color-bg);
}

.sb-shot {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: var(--sb-gap);
  padding: 40px 0;
  border-bottom: 1px solid var(--sb-color-rule);
  scroll-margin-top: 60px;
}

.sb-shot:last-child { border-bottom: none; }

.sb-shot-frame {
  position: relative;
  width: 100%;
  background: var(--sb-color-rule);
  border-radius: var(--sb-radius);
  overflow: hidden;
}

.sb-shot-frame.aspect-9-16 { aspect-ratio: 9 / 16; }
.sb-shot-frame.aspect-16-9 { aspect-ratio: 16 / 9; }
.sb-shot-frame.aspect-1-1  { aspect-ratio: 1 / 1; }
.sb-shot-frame.aspect-4-5  { aspect-ratio: 4 / 5; }
.sb-shot-frame.aspect-21-9 { aspect-ratio: 21 / 9; }

.sb-shot-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.sb-placeholder {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: linear-gradient(135deg, var(--sb-color-rule) 0%, var(--sb-color-bg) 100%);
  color: var(--sb-color-muted);
}

.sb-placeholder-id {
  font-family: var(--sb-font-mono);
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0.05em;
}

.sb-placeholder-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}

/* On-screen text overlay preview (rendered over the frame) */
.sb-overlay {
  position: absolute;
  left: 0; right: 0;
  padding: 0 16px;
  pointer-events: none;
}

.sb-overlay-center        { top: 50%; transform: translateY(-50%); text-align: center; }
.sb-overlay-lower-third   { bottom: 12%; text-align: center; }
.sb-overlay-upper-third   { top: 12%; text-align: center; }
.sb-overlay-left-third    { top: 50%; transform: translateY(-50%); text-align: left; }
.sb-overlay-right-third   { top: 50%; transform: translateY(-50%); text-align: right; }

.sb-overlay-text {
  display: inline-block;
  font-size: clamp(14px, 2.2vw, 22px);
  line-height: 1.1;
  text-shadow: 0 2px 8px rgba(0,0,0,0.4);
}

/* ─── Shot body ─── */

.sb-shot-body { display: flex; flex-direction: column; gap: 20px; }

.sb-shot-header {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: baseline;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--sb-color-rule);
}

.sb-shot-id {
  font-family: var(--sb-font-mono);
  font-size: 16px;
  font-weight: 700;
  color: var(--sb-color-accent);
}

.sb-shot-time {
  font-family: var(--sb-font-mono);
  font-size: 13px;
  color: var(--sb-color-muted);
}

.sb-shot-beat {
  font-size: 13px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-weight: 600;
  color: var(--sb-color-muted);
  margin-left: auto;
}

.sb-shot-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  font-size: 13px;
}

.sb-shot-meta div { display: flex; flex-direction: column; gap: 2px; }
.sb-shot-meta dt {
  font-family: var(--sb-font-mono);
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
}
.sb-shot-meta dd { font-weight: 600; }

.sb-shot-subject h3,
.sb-shot-vo h3,
.sb-shot-text h3,
.sb-shot-rationale h3 {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--sb-color-muted);
  margin-bottom: 6px;
  font-weight: 600;
}

.sb-shot-subject p,
.sb-shot-vo p,
.sb-shot-rationale p {
  font-size: 15px;
  line-height: 1.55;
}

.sb-shot-vo p {
  font-style: italic;
  color: var(--sb-color-muted);
}

.sb-text-content {
  font-family: var(--sb-font-display);
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 4px;
}

.sb-text-meta {
  font-family: var(--sb-font-mono);
  font-size: 11px;
  color: var(--sb-color-muted);
}

.sb-shot-rationale {
  background: var(--sb-color-rule);
  padding: 14px 16px;
  border-radius: var(--sb-radius);
  border-left: 3px solid var(--sb-color-accent);
}

.sb-shot-rationale p {
  font-size: 14px;
  font-style: italic;
}

/* ─── Footer ─── */

.sb-footer {
  padding: 40px var(--sb-pad);
  background: var(--sb-color-rule);
  font-size: 12px;
  color: var(--sb-color-muted);
}

.sb-footer-inner {
  max-width: 960px;
  margin: 0 auto;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 16px;
}

/* ─── QA verdict ─── */

.sb-verdict {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 2px 8px;
  border: 1px solid var(--sb-color-rule);
  border-radius: 2px;
  font-family: var(--sb-font-body);
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--sb-color-muted);
  white-space: nowrap;
}

.sb-verdict-accept { border-color: var(--sb-color-ink); color: var(--sb-color-ink); }
.sb-verdict-revise { border-color: var(--sb-color-accent); color: var(--sb-color-accent); }
.sb-verdict-reject {
  border-color: var(--sb-color-accent);
  background: var(--sb-color-accent);
  color: var(--sb-color-bg);
}

.sb-verdict-round { font-weight: 400; letter-spacing: 0.04em; opacity: 0.75; }

.sb-provenance {
  max-width: 960px;
  margin: 0 auto;
  font-size: 11px;
  line-height: 1.7;
  color: var(--sb-color-muted);
}

.sb-provenance code {
  font-size: 10px;
  word-break: break-all;
}

/* ─── Responsive ─── */

@media (max-width: 720px) {
  .sb-shot {
    grid-template-columns: 1fr;
    gap: 20px;
    padding: 28px 0;
  }
  .sb-section { padding: 40px var(--sb-pad); }
  .sb-header { padding: 48px var(--sb-pad) 28px; }
}

/* ─── Print ─── */
{{INLINE_PRINT_CSS}}

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/templates/styles.css.tpl -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/README.md -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/README.md`

# Tools

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

## Requirements

```bash
pip install pyyaml jsonschema
```

Standard library otherwise. No pandas, no numpy.

## Run everything

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

This is exactly what CI runs, so a green local run means a green PR.

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

## Repo checks

### `validate_skills.py`

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

```bash
python tools/validate_skills.py
```

### `validate_schemas.py`

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

```bash
python tools/validate_schemas.py
```

It validates schemas, not instances. For instances, see `validate_shots.py`.

### `validate_capabilities.py`

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

- every generator id has an adapter `.md` and every adapter `.md` has an entry
- no adapter advertises more words than its own `max_prompt_words` ceiling
- every adapter documents the `aspect_param` the matrix says to send
- no `notes` field cites a word count above its own ceiling
- warns when the matrix or an entry is past its 120-day freshness window

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

### `validate_brand_lock.py`

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

## Project checks

These run against a project's output directory, not the repo.

### `validate_shots.py`

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

### `validate_prompts.py`

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

### `validate_critique.py`

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

### `validate_provenance.py`

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

It catches, with a selftest for each:

- a frame regenerated after its critique (`image_sha256` no longer matches)
- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)
- a frame on disk with no critique for its round, never reviewed at all
- two critiques for the same shot in the same round, two operators colliding
- rounds that skip a number, or a critique whose `run_id` belongs to another run

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

## Rendering

### `shots-to-html.py`

Renders an output folder into a single `preview.html`.

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

### `copy-prompt.py`

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

## Internal modules

Not entry points. Imported by the tools above.

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.
- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

## Adding new tools

- Make it executable (`chmod +x`)
- Add a usage docstring at the top of the file
- Give it a `--selftest` that proves the check fires
- Document it in this README
- Wire it into `tools/check.sh`, which is what CI calls

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/README.md -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/_shotkit.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/_shotkit.py`

#!/usr/bin/env python3
"""
Shared helpers for the shotkit tools. Standard library only.

Everything here exists because more than one tool needs it. Hashing, brand-lock
parsing, and the capability-id list were duplicated or absent before; keeping one
copy is what stops the tools from disagreeing about what a brand-lock palette is
or which generator ids are real.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

CAPABILITIES_PATH = (
    REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters" / "_capabilities.json"
)

# Roles tools/shots-to-html.py maps onto CSS variables. Documented in
# docs/brand-lock-anatomy.md so a brand-lock author knows the names are load-bearing.
PALETTE_ROLES = ("background", "ink", "accent", "muted", "rule")

RUN_ID_RE = re.compile(r"^([0-9]{8}T[0-9]{6}Z)-[0-9a-f]{8}$")
ISO_INSTANT_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SHOT_ID_RE = re.compile(r"^shot_[0-9]{2,3}$")
TEXT_ID_RE = re.compile(r"^text_[0-9]{2,3}$")

HEX_RE = re.compile(r"#[0-9A-Fa-f]{6}")
PLACEHOLDER_HEX_RE = re.compile(r"#_{6}")

# | Role | `#RRGGBB` | Use | rows in a brand-lock Palette table.
PALETTE_ROW_RE = re.compile(
    r"^\|\s*([A-Za-z][A-Za-z0-9\s()/-]*?)\s*\|\s*`?(#(?:[0-9A-Fa-f]{6}|_{6}))`?\s*\|"
)

SNAPSHOT_TAKEN_RE = re.compile(r"<!--\s*snapshot taken:\s*(.+?)\s*-->")
SNAPSHOT_SOURCE_RE = re.compile(r"<!--\s*source:\s*(.+?)\s*-->")

IMAGE_EXTS = ("png", "jpg", "jpeg", "webp")


# --------------------------------------------------------------------------
# Hashing
# --------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    """SHA-256 of a file's bytes, read in chunks so large frames do not load whole."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    """SHA-256 of a string, UTF-8 encoded."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# Run identity
# --------------------------------------------------------------------------

def make_run_id(now: datetime | None = None, nonce: str | None = None) -> str:
    """Build a run_id. Pass `now` and `nonce` to make it reproducible in tests."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    if nonce is None:
        nonce = sha256_text(now.isoformat() + str(id(now)))[:8]
    return f"{stamp}-{nonce}"


def iso_instant(now: datetime | None = None) -> str:
    """UTC ISO-8601 to second precision with a trailing Z."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def run_id_timestamp(run_id: str) -> str | None:
    """Extract the compact timestamp from a run_id, or None if malformed."""
    m = RUN_ID_RE.match(run_id or "")
    return m.group(1) if m else None


# --------------------------------------------------------------------------
# JSON loading
# --------------------------------------------------------------------------

def load_json(path: Path) -> tuple[dict | list | None, str | None]:
    """Return (data, error). Exactly one of the two is None."""
    if not path.exists():
        return (None, f"file does not exist: {path}")
    try:
        return (json.loads(path.read_text(encoding="utf-8")), None)
    except json.JSONDecodeError as e:
        return (None, f"invalid JSON: {e}")
    except OSError as e:
        return (None, f"cannot read: {e}")


# --------------------------------------------------------------------------
# Capability matrix
# --------------------------------------------------------------------------

def capability_ids(caps_path: Path | None = None) -> set[str]:
    """Generator ids from the capability matrix. Empty set if it cannot be read."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return set()
    return {
        g["id"]
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


def capability_map(caps_path: Path | None = None) -> dict[str, dict]:
    """Generator id to its full capability entry."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return {}
    return {
        g["id"]: g
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


# --------------------------------------------------------------------------
# Brand-lock parsing
# --------------------------------------------------------------------------

def parse_palette(text: str) -> dict[str, str]:
    """Role (lowercased) to hex value, from a brand-lock Palette table."""
    palette: dict[str, str] = {}
    for line in text.splitlines():
        m = PALETTE_ROW_RE.match(line)
        if m:
            palette[m.group(1).strip().lower()] = m.group(2).strip()
    return palette


def palette_hexes(text: str) -> set[str]:
    """Every real (non-placeholder) hex in a brand-lock, lowercased."""
    return {h.lower() for h in HEX_RE.findall(text)}


def is_unconfigured(text: str) -> bool:
    """True when the brand-lock still carries template placeholders in its palette."""
    return bool(PLACEHOLDER_HEX_RE.search(text))


def parse_typography(text: str) -> dict[str, str | None]:
    """
    Pull font names out of a brand-lock Typography section.

    Matches the documented format:
        **Display font:** `Inter Black 900`, headline weight, ...
        **Body font:** `Inter Medium 500`, body copy, ...
        **Mono font:** `JetBrains Mono Regular`, code, data, ...

    Mono is optional. A brand-lock that declares one has three legal overlay fonts,
    not two, which is why the font check reads all three rather than assuming a pair.
    """
    out: dict[str, str | None] = {
        "display_font": None,
        "body_font": None,
        "mono_font": None,
    }
    # The value has to be backticked and sit immediately after the label. That is what
    # separates a real declaration from the template's instructional prose
    # ("**Display font:** font name, weights used (e.g. `Inter Black 900`)"), which
    # would otherwise resolve to the example font.
    for key, label in (
        ("display_font", "Display"),
        ("body_font", "Body"),
        ("mono_font", "Mono"),
    ):
        pattern = re.compile(
            r"^\*\*" + label + r"\s+font[^:*]*:?\*\*[ \t]*`([^`\n]+)`",
            re.IGNORECASE | re.MULTILINE,
        )
        m = pattern.search(text)
        if m:
            value = m.group(1).strip()
            if value and not value.startswith("_"):
                out[key] = value
    return out


def parse_snapshot_header(text: str) -> dict[str, str | None]:
    """The two provenance comments storyboard-architect writes at the top of a snapshot."""
    taken = SNAPSHOT_TAKEN_RE.search(text)
    source = SNAPSHOT_SOURCE_RE.search(text)
    return {
        "snapshot_taken": taken.group(1).strip() if taken else None,
        "source": source.group(1).strip() if source else None,
    }


# --------------------------------------------------------------------------
# Output-tree conventions
# --------------------------------------------------------------------------

def round_dirs(output_dir: Path, kind: str) -> list[tuple[int, Path]]:
    """
    Sorted (round_number, path) for output_dir/<kind>/round-N directories.

    `kind` is 'frames', 'critiques', or 'prompts'.
    """
    base = output_dir / kind
    if not base.is_dir():
        return []
    found: list[tuple[int, Path]] = []
    for child in base.iterdir():
        if child.is_dir() and child.name.startswith("round-"):
            suffix = child.name[len("round-"):]
            if suffix.isdigit():
                found.append((int(suffix), child))
    return sorted(found)


def find_frame(output_dir: Path, shot_id: str, round_no: int | None = None) -> Path | None:
    """
    Locate a frame for a shot by the path convention.

    Prefers the highest-numbered round under frames/, then falls back to the
    legacy flat generated/ directory so pre-3.0.0 projects still render.
    """
    candidates = round_dirs(output_dir, "frames")
    if round_no is not None:
        candidates = [(n, p) for n, p in candidates if n == round_no]
    for _, directory in reversed(candidates):
        for ext in IMAGE_EXTS:
            candidate = directory / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    legacy = output_dir / "generated"
    if legacy.is_dir():
        for ext in IMAGE_EXTS:
            candidate = legacy / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    return None


def critique_paths(output_dir: Path) -> list[Path]:
    """
    Every critique file in an output tree, newest layout first.

    New layout: critiques/round-N/shot_NN.critique.json
    Legacy:     critique.json at the output root
    """
    found: list[Path] = []
    for _, directory in round_dirs(output_dir, "critiques"):
        found.extend(sorted(directory.glob("*.critique.json")))
        found.extend(sorted(directory.glob("*.json")))
    legacy = output_dir / "critique.json"
    if legacy.exists():
        found.append(legacy)
    # Preserve order, drop duplicates from the two globs above.
    seen: set[Path] = set()
    unique: list[Path] = []
    for path in found:
        resolved = path.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(path)
    return unique


def as_overlay_ids(value) -> list[str]:
    """Normalise shots.json on_screen_text (null, string, or array) to a list."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []


def as_shot_ids(value) -> list[str]:
    """Normalise text-overlays.json shot_id (string or array) to a list."""
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/_shotkit.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/_template.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/_template.py`

#!/usr/bin/env python3
"""
The small template engine tools/shots-to-html.py renders preview.html.tpl with.

Only the subset the template actually uses is implemented, deliberately: variable
substitution, a loop, and a truthiness block. It exists so the CLI and the
storyboard-html-preview skill render the same structural template instead of two
hand-maintained copies that drift apart.

Supported syntax:
    {{name}}            HTML-escaped substitution
    {{{name}}}          raw substitution, for pre-built markup such as inlined CSS
    {{#each items}}     iterate a list of dicts; inside the block, keys resolve
    {{/each}}           against the item first, then the enclosing context
    {{#if name}}        render when the value is truthy
    {{/if}}

Unknown names render empty rather than raising, which keeps a partially populated
context from producing a traceback in front of a client.
"""

from __future__ import annotations

import html
import re

BLOCK_RE = re.compile(r"\{\{#(each|if)\s+([A-Za-z0-9_]+)\s*\}\}")
RAW_VAR_RE = re.compile(r"\{\{\{\s*([A-Za-z0-9_]+)\s*\}\}\}")
VAR_RE = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")


def escape(value) -> str:
    """HTML-escape a value for text and attribute contexts, including quotes."""
    if value is None or value is False:
        return ""
    if value is True:
        return "true"
    return html.escape(str(value), quote=True)


def _find_block_end(text: str, kind: str, start: int) -> int:
    """Index of the closing tag matching the block opened before `start`."""
    open_re = re.compile(r"\{\{#" + kind + r"\s+[A-Za-z0-9_]+\s*\}\}")
    close_tag = "{{/" + kind + "}}"
    depth = 1
    pos = start
    while depth:
        next_close = text.find(close_tag, pos)
        if next_close == -1:
            raise ValueError(f"unclosed {{{{#{kind}}}}} block")
        next_open = open_re.search(text, pos, next_close)
        if next_open:
            depth += 1
            pos = next_open.end()
            continue
        depth -= 1
        pos = next_close + len(close_tag)
    return pos


def render(template: str, context: dict) -> str:
    """Render `template` against `context`."""
    out: list[str] = []
    pos = 0

    while pos < len(template):
        block = BLOCK_RE.search(template, pos)
        if not block:
            out.append(_render_leaf(template[pos:], context))
            break

        out.append(_render_leaf(template[pos : block.start()], context))
        kind, name = block.group(1), block.group(2)
        body_start = block.end()
        block_end = _find_block_end(template, kind, body_start)
        close_len = len("{{/" + kind + "}}")
        body = template[body_start : block_end - close_len]

        value = context.get(name)
        if kind == "each":
            for item in value or []:
                scoped = dict(context)
                if isinstance(item, dict):
                    scoped.update(item)
                else:
                    scoped["this"] = item
                out.append(render(body, scoped))
        else:
            if value:
                out.append(render(body, context))

        pos = block_end

    return "".join(out)


def _render_leaf(text: str, context: dict) -> str:
    """Substitute variables in a chunk with no block tags left in it."""
    text = RAW_VAR_RE.sub(lambda m: str(context.get(m.group(1), "") or ""), text)
    return VAR_RE.sub(lambda m: escape(context.get(m.group(1))), text)

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/_template.py -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/check.sh -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/check.sh`

#!/usr/bin/env bash
# Run every shotkit check. This is what CI calls, so a green local run means a green PR.
#
# Usage:
#   ./tools/check.sh            # run everything, report a summary
#   ./tools/check.sh --quiet    # only print failures and the summary
#
# Requires: pip install pyyaml jsonschema

set -uo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.." || exit 1

PYTHON="${PYTHON:-python3}"
QUIET=0
[[ "${1:-}" == "--quiet" ]] && QUIET=1

PASSED=0
FAILED=0
FAILED_NAMES=()

run() {
  local label="$1"
  shift
  local output
  if output=$("$PYTHON" "$@" 2>&1); then
    PASSED=$((PASSED + 1))
    if [[ "$QUIET" == "0" ]]; then
      echo "PASS  ${label}"
      sed 's/^/      /' <<<"$output"
      echo
    else
      echo "PASS  ${label}"
    fi
  else
    FAILED=$((FAILED + 1))
    FAILED_NAMES+=("$label")
    echo "FAIL  ${label}"
    sed 's/^/      /' <<<"$output"
    echo
  fi
}

echo "shotkit checks, using $("$PYTHON" --version 2>&1)"
echo

# Preflight the two dependencies. Without this, a missing package turns one actionable
# line into fourteen identical failures and you have to read all of them to find out.
missing=""
"$PYTHON" -c 'import yaml' 2>/dev/null || missing="pyyaml"
"$PYTHON" -c 'import jsonschema' 2>/dev/null || missing="${missing:+$missing }jsonschema"
if [[ -n "$missing" ]]; then
  echo "Missing Python package(s): ${missing}" >&2
  echo >&2
  echo "  ${PYTHON} -m pip install ${missing}" >&2
  echo >&2
  echo "Then re-run ./tools/check.sh" >&2
  exit 1
fi

# Structure and schemas
run "skills: frontmatter"            tools/validate_skills.py
run "schemas: are valid schemas"     tools/validate_schemas.py

# Capability matrix, including prose parity with the adapter files
run "capabilities: selftest"         tools/validate_capabilities.py --selftest
run "capabilities: matrix"           tools/validate_capabilities.py

# Brand-locks: packs allow templates, snapshots do not
run "brand-lock: selftest"           tools/validate_brand_lock.py --selftest
run "brand-lock: packs"              tools/validate_brand_lock.py \
  brand-packs/_template.md \
  brand-packs/whystrohm.md \
  brand-packs/examples/saas-clean.md \
  skills/brand-lock-extractor/examples/brand-lock.md
run "brand-lock: snapshots"          tools/validate_brand_lock.py --snapshots

# Storyboard instances, the rules JSON Schema cannot express
run "shots: selftest"                tools/validate_shots.py --selftest
run "shots: bundled examples"        tools/validate_shots.py --examples
run "shots: worked run"              tools/validate_shots.py \
  skills/visual-asset-critic/examples/worked-run

# Prompt files: the forge's hard rules, including verbatim series_lock anchors
run "prompts: selftest"              tools/validate_prompts.py --selftest
run "prompts: worked run"            tools/validate_prompts.py --examples

# Critique gate
run "critique: selftest"             tools/validate_critique.py --selftest
run "critique: fixtures"             tools/validate_critique.py --examples

# Provenance chain
run "provenance: selftest"           tools/validate_provenance.py --selftest
run "provenance: worked run"         tools/validate_provenance.py --examples --require-accept

# Tools that ship as part of the workflow
run "preview renderer: selftest"     tools/shots-to-html.py --selftest
run "prompt helper: selftest"        tools/copy-prompt.py --selftest

echo "─────────────────────────────────────────"
echo "${PASSED} passed, ${FAILED} failed"
if ((FAILED)); then
  printf 'failed: %s\n' "${FAILED_NAMES[@]}"
  exit 1
fi
exit 0

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/check.sh -->


<!-- SOURCE_FILE_START: skills/storyboard-html-preview/tools/copy-prompt.py -->
# SOURCE FILE: `skills/storyboard-html-preview/tools/copy-prompt.py`

#!/usr/bin/env python3
"""Copy a shot prompt from a shotkit prompts file to the system clipboard.

Handles both file shapes the forge writes: a full pass, and a revision file where each
shot block carries `# fix [...]` annotations above the prompt. Comment lines inside a
block are treated as annotations and never land in the clipboard, so what you paste
into a generator is the prompt and nothing else.

Usage:
  python tools/copy-prompt.py output/prompts/round-1/flux.txt
  python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
  python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
  python tools/copy-prompt.py --selftest
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

# A shot block opens with the shot id near the start of a comment line. The forge's
# revision format prefixes it, so both of these are headers:
#   # shot_03, reframe, 11.0-16.0s, MCU eye-level push
#   # shot_03, promise, 3.0-8.0s, MCU eye-level push, revision (was REVISE)
#   # Revision of shot_03 (was REVISE)
SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT_LINE = re.compile(r"^\s*#")


class Block:
    __slots__ = ("shot_id", "header", "annotations", "body")

    def __init__(self, shot_id: str, header: str) -> None:
        self.shot_id = shot_id
        self.header = header
        self.annotations: list[str] = []
        self.body: list[str] = []

    def prompt(self) -> str:
        return "\n".join(self.body).strip()

    def label(self) -> str:
        note = f"  [{len(self.annotations)} fix note(s)]" if self.annotations else ""
        return f"{self.header}{note}  ({len(self.prompt())} chars)"


def get_clipboard_command() -> list[str] | None:
    """Return the platform-appropriate clipboard command, or None if unavailable."""
    if sys.platform == "darwin":
        return ["pbcopy"]
    if sys.platform.startswith("linux"):
        if shutil.which("xclip"):
            return ["xclip", "-selection", "clipboard"]
        if shutil.which("xsel"):
            return ["xsel", "--clipboard", "--input"]
        return None
    if sys.platform == "win32":
        return ["clip"]
    return None


def parse_prompt_text(text: str) -> list[Block]:
    """Split a prompt file into shot blocks, separating annotations from prompt body."""
    blocks: list[Block] = []
    current: Block | None = None

    for line in text.splitlines():
        match = SHOT_HEADER.match(line)
        if match:
            current = Block(match.group(1), line.strip())
            blocks.append(current)
            continue
        if current is None:
            continue  # file-level header comments, before the first shot block
        if COMMENT_LINE.match(line):
            current.annotations.append(line.strip())
        else:
            current.body.append(line)

    return [b for b in blocks if b.prompt()]


def parse_prompt_file(path: Path) -> list[Block]:
    return parse_prompt_text(path.read_text(encoding="utf-8"))


def copy_to_clipboard(text: str) -> bool:
    cmd = get_clipboard_command()
    if not cmd:
        return False
    proc = subprocess.run(cmd, input=text.encode("utf-8"))
    return proc.returncode == 0


def print_clipboard_help() -> None:
    if sys.platform.startswith("linux"):
        print("No clipboard utility found. Install xclip or xsel.", file=sys.stderr)
    else:
        print("No clipboard utility found on this platform.", file=sys.stderr)


def list_blocks(blocks: list[Block]) -> None:
    for i, block in enumerate(blocks, 1):
        print(f"{i}. {block.label()}")
        for note in block.annotations:
            print(f"     {note}")


def select_interactively(blocks: list[Block]) -> Block | None:
    list_blocks(blocks)
    try:
        raw = input(f"\nWhich shot? (1-{len(blocks)}): ").strip()
        idx = int(raw) - 1
    except (ValueError, EOFError):
        print("Invalid selection.", file=sys.stderr)
        return None
    if not (0 <= idx < len(blocks)):
        print("Selection out of range.", file=sys.stderr)
        return None
    return blocks[idx]


STANDARD_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Aspect: 9:16

# shot_01, hook, 0.0-2.0s, MCU eye-level static
first prompt body

# shot_02, pain, 2.0-6.0s, MS eye-level push
second prompt body
"""

REVISION_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Round: 2
# Revision of round 1. Shots not listed here already passed.

# shot_02, pain, 2.0-6.0s, MCU eye-level push, revision (was REVISE)
# fix [Shot Spec, major]: framing MS -> MCU
# fix [Technical, re-roll]: hand was malformed
revised prompt body
"""

LEGACY_REVISION_FIXTURE = """\
# Revision of shot_03 (was REVISE)
# fix [Series Lock, major]: added 'salt-and-pepper hair' to the character anchor
legacy revised prompt body
"""


def selftest() -> int:
    ok = True

    cases = [
        ("standard file yields both shots", STANDARD_FIXTURE, ["shot_01", "shot_02"]),
        ("revision file yields its shot", REVISION_FIXTURE, ["shot_02"]),
        ("legacy revision header is tolerated", LEGACY_REVISION_FIXTURE, ["shot_03"]),
    ]
    for label, fixture, expected in cases:
        got = [b.shot_id for b in parse_prompt_text(fixture)]
        if got == expected:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> expected {expected}, got {got}")
            ok = False

    blocks = parse_prompt_text(REVISION_FIXTURE)
    body = blocks[0].prompt()
    if body == "revised prompt body":
        print("  ok    selftest: fix annotations stay out of the copied prompt")
    else:
        print(f"  FAIL  selftest: prompt body was {body!r}")
        ok = False
    if len(blocks[0].annotations) == 2:
        print("  ok    selftest: fix annotations are captured for display")
    else:
        print(f"  FAIL  selftest: expected 2 annotations, got {blocks[0].annotations}")
        ok = False

    header_only = parse_prompt_text("# Storyboard: x\n# Generator: flux\n")
    if header_only == []:
        print("  ok    selftest: a file with no shot blocks yields nothing")
    else:
        print(f"  FAIL  selftest: expected no blocks, got {header_only}")
        ok = False

    # The shipped worked run must be readable by this tool, both rounds.
    repo_root = Path(__file__).resolve().parent.parent
    worked = repo_root / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    for rel, expected in (
        ("prompts/round-1/flux.txt", ["shot_01", "shot_02"]),
        ("prompts/round-2/revised-flux.txt", ["shot_02"]),
    ):
        path = worked / rel
        if not path.exists():
            print(f"  FAIL  selftest: bundled fixture missing: {rel}")
            ok = False
            continue
        got = [b.shot_id for b in parse_prompt_file(path)]
        if got == expected:
            print(f"  ok    selftest: bundled {rel} parses")
        else:
            print(f"  FAIL  selftest: bundled {rel} -> expected {expected}, got {got}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Copy a shot prompt from a shotkit prompts file to the clipboard."
    )
    parser.add_argument(
        "file",
        nargs="?",
        type=Path,
        help="Path to a prompt file (e.g. output/prompts/round-1/flux.txt)",
    )
    parser.add_argument(
        "--shot", help="Shot ID to copy (e.g. shot_03). If omitted, prompts interactively."
    )
    parser.add_argument(
        "--list", action="store_true", help="List shots and exit. Does not copy."
    )
    parser.add_argument(
        "--selftest", action="store_true", help="Prove both file shapes parse"
    )
    args = parser.parse_args()

    if args.selftest:
        return selftest()
    if args.file is None:
        parser.error("file is required unless --selftest is given")

    if not args.file.exists():
        print(f"File not found: {args.file}", file=sys.stderr)
        return 1

    blocks = parse_prompt_file(args.file)
    if not blocks:
        print(f"No shot blocks found in {args.file}.", file=sys.stderr)
        print(
            "Expected a comment line naming a shot, e.g. "
            "'# shot_03, beat, timing, framing'.",
            file=sys.stderr,
        )
        return 1

    if args.list:
        list_blocks(blocks)
        return 0

    if args.shot:
        matches = [b for b in blocks if b.shot_id == args.shot]
        if not matches:
            print(f'Shot "{args.shot}" not found in {args.file}.', file=sys.stderr)
            print("Available shots:", file=sys.stderr)
            for block in blocks:
                print(f"  {block.shot_id}", file=sys.stderr)
            return 1
        if len(matches) > 1:
            print(
                f'Shot "{args.shot}" appears {len(matches)} times in {args.file}; '
                f"copying the last block.",
                file=sys.stderr,
            )
        selection = matches[-1]
    else:
        result = select_interactively(blocks)
        if result is None:
            return 1
        selection = result

    body = selection.prompt()
    if copy_to_clipboard(body):
        print(f"Copied {selection.shot_id} prompt to clipboard ({len(body)} chars).")
        for note in selection.annotations:
            print(f"  {note}")
        return 0

    print_clipboard_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

<!-- SOURCE_FILE_END: skills/storyboard-html-preview/tools/copy-prompt.py -->
