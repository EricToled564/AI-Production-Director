# AI Production Director — Knowledge Pack 7/7

Generated from `aiproductiondirectorcompleto.zip`.
Each source file is preserved with its original relative path.


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/midjourney.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/midjourney.md`

# Adapter: Midjourney (v7)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Midjourney rewards short, high-signal prompts with strong adjective stacking and cinematic vocabulary. Long descriptive paragraphs underperform, the model interprets them as competing weights and produces muddled output.

## Syntax pattern

```
{subject}, {action}, {composition}, {environment}, {lighting}, {color/mood}, {style modifiers} --ar {ratio} --style {style} --s {stylize} {extras}
```

Comma-separated phrases. No full sentences. No connective words ("the", "with", "and") unless they're load-bearing.

## Parameter reference (current as of Q2 2026)

| Param | Values | Default to use | Notes |
|---|---|---|---|
| `--ar` | aspect ratio | from `project.aspect` | `--ar 9:16`, `--ar 16:9`, `--ar 1:1` |
| `--style` | `raw` / `4a` / `4b` / `4c` | `raw` | `raw` for photorealistic, omit for default Midjourney aesthetic |
| `--s` | 0–1000 | `50` for branded, `250` for artistic | Stylization weight. Lower = closer to prompt, higher = more MJ aesthetic |
| `--c` | 0–100 | omit | Chaos. Use only when exploring variations |
| `--seed` | integer | omit unless reproducing | For series consistency, set per-storyboard |
| `--cref` | image URL | use when character anchor exists | Character reference. Pair with `--cw` |
| `--cw` | 0–100 | `50` | Character weight. 100 = strict character match, 0 = clothing only |
| `--sref` | image URL | use when style anchor exists | Style reference |

## Length

Aim for **40–80 words per prompt** including parameters. Anything over 100 words underperforms.

## Composition mapping

Translate shot grammar into Midjourney-friendly phrases:

| shot_grammar | Midjourney phrase |
|---|---|
| `MCU eye-level` | `medium close-up, eye level` |
| `WS overhead` | `wide shot, overhead view, top-down` |
| `static` | (omit, static is default) |
| `push` | `dolly in, pushing forward` |
| `handheld` | `handheld documentary feel, slight motion blur` |
| `shallow DOF` | `shallow depth of field, f/1.8, bokeh background` |
| `deep DOF` | `deep focus, everything sharp, f/8` |

## Lighting language

Midjourney rewards specific lighting vocabulary:

- `soft natural light, large window left, warm afternoon golden hour`
- `hard top-light, single key, deep shadows, studio black backdrop`
- `practical mixed sources, neon accents, urban night, atmospheric haze`
- `volumetric backlight, rim light separating subject, cinematic haze`
- `chiaroscuro, dramatic side-light, painterly`

Pull verbatim from `series_lock.lighting`.

## Composition pattern

```
{framing} of {subject character_anchor}, {action}, {compositional note}, {environment from series_lock}, {lighting from series_lock}, {color_grade}, cinematic photography, {brand mood adjectives} --ar {aspect} --style raw --s 50
```

## Example

**Shot data:**
```json
{
  "id": "shot_03",
  "framing": "MS",
  "angle": "eye-level",
  "motion": "static",
  "subject": "Founder mid-thirties, leaning forward at laptop, face partially turned to window",
  "rationale": "MS framing leaves negative space right for text overlay"
}
```

**Series lock:**
```
character: founder, mid-thirties, salt-and-pepper hair, navy crewneck
environment: minimalist home office, white walls, oak desk
lighting: soft natural side-light, large window left, warm afternoon
color_grade: warm filmic, muted teal shadows
```

**Brand lock palette:** `#0F1F3A navy`, `#F5F0E8 cream`, `#D94F3A coral`

**Brand mood:** `calm, considered, operator, not creator`

**Output prompt:**
```
medium shot of founder mid-thirties, salt-and-pepper hair, navy crewneck, leaning forward at laptop, face partially turned to window light, negative space right of frame, minimalist home office, white walls, oak desk, soft natural side-light large window left, warm afternoon golden hour, warm filmic color grade, muted teal shadows, cinematic photography, calm considered operator mood --ar 9:16 --style raw --s 50
```

## Pitfalls to avoid

- **Don't use "AI" or "rendered"**, produces stylized outputs that look generated
- **Don't over-stack adjectives**, three adjectives per noun phrase max
- **Don't include text content**, even if the shot has `on_screen_text`, leave it out. Composited separately.
- **Don't use `--c` for series work**, chaos kills consistency
- **Don't change `--seed` mid-storyboard**, set once at series_lock level

## API access note

Midjourney still has limited API access as of Q2 2026. For programmatic workflows, the prompts in `midjourney.txt` are designed to be pasted into Discord or the web UI. Some teams use third-party wrappers (PiAPI, Useapi.net), those generally accept the same prompt syntax.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/midjourney.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/nano-banana.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/nano-banana.md`

# Adapter: Nano Banana (Gemini 2.5 Flash Image)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Google's Nano Banana model (`gemini-2.5-flash-image`) is the edit-and-iterate champion. Where other generators are best for first-frame creation, Nano Banana excels at variations, inpainting, and reference-based modification. The 2026 production pattern is to generate hero frames in Midjourney or Flux, then use Nano Banana for variants.

For storyboard work, Nano Banana is the right choice when you need **many variations of a single concept** or you're feeding generated images back through for refinement.

## Syntax pattern

Nano Banana takes natural-language prompts plus optional reference images. For text-to-image:

```
{Subject and action}. {Environment and lighting}. {Photographic specs and mood}.
```

For image-to-image (the strength), the prompt describes the modification:

```
{Modification description}. Keep {what to preserve}. Change {what to vary}.
```

## Parameters

Nano Banana goes through the Gemini API:

| Parameter | Default | Notes |
|---|---|---|
| `model` | `gemini-2.5-flash-image` | |
| `aspectRatio` | from `project.aspect` | Native support for `9:16`, `16:9`, `1:1`, `4:5`, `3:4`, `21:9` |
| `numberOfImages` | `1` for series, `4` for variant exploration | |
| `referenceImages` | array of base64 images | Optional |

Document:
```
# shot_01, params: ar=9:16, n=1, ref=none (or list of refs)
{prompt}
```

## Length

Nano Banana handles **60–120 words** efficiently. Shorter than GPT Image, longer than Midjourney.

## Composition pattern (text-to-image)

```
{Framing and subject sentence with character anchor}. {Environment and lighting from series_lock}. {Photographic spec, lens, depth of field, mood}. {Brand color grade closing}.
```

## Composition pattern (image-to-image, the strength)

When refining a hero shot generated elsewhere:

```
Reference: {description of input image}. Modify the image to {specific change}. Preserve the character's {face/clothing/pose}, the {environment elements}, and the lighting direction. Change {specific element} to {target state}.
```

## Example (text-to-image)

**Same shot data as previous examples.**

**Output prompt:**
```
Medium shot of a founder, mid-thirties, salt-and-pepper hair, navy crewneck sweater, leaning forward at his laptop with face turned partially toward window light. Composition leaves negative space on the right side. Minimalist home office, white walls, oak desk. Soft natural side-light from large window left, warm afternoon golden hour. Shot on 50mm prime, f/2.0, shallow depth of field, warm filmic color grade with muted teal shadows. Calm, considered, operator mood.
```

## Example (image-to-image variant)

**Use case:** generated `shot_03` in Flux, want a variant where the founder is looking directly at camera

**Output prompt:**
```
Reference: medium shot of founder at laptop in home office, leaning forward, face partially turned to window. Modify the image so the founder looks directly into the camera lens with a calm, neutral expression. Preserve the character's face, salt-and-pepper hair, navy crewneck, body posture, the home office environment, the desk and laptop, and the warm afternoon side-lighting. Change only the head angle and gaze direction.
```

## Variant-generation workflow

The pattern Nano Banana enables, and the reason it's worth including in storyboard work:

1. Generate hero shot in Midjourney or Flux (one prompt → one image)
2. Feed that image to Nano Banana with variation prompts
3. Get 4–8 variants of the same shot for editorial selection
4. Composite text on the chosen variant

When generating prompts for Nano Banana in `nano-banana.txt`, include both:

- The text-to-image prompt (for first-pass generation)
- A modification template comment showing how to use the result for variants:

```
# shot_01, text-to-image prompt:
{prompt}

# shot_01, variant template (after generating once):
# Reference: [the generated image]. Modify the image to {your change}.
# Preserve {anchors}. Change {target}.
```

## Pitfalls to avoid

- **Don't use Midjourney-style flag syntax**. Nano Banana ignores `--ar`, expects `aspectRatio` parameter
- **Don't expect Midjourney-level aesthetic by default**. Nano Banana is a workhorse, not a stylist. Stack mood adjectives explicitly
- **Don't pile multiple modifications in one image-to-image prompt**, one change per pass produces cleaner results
- **Don't forget the "preserve" clause in image-to-image**, without it, Nano Banana treats the reference as loose inspiration and drifts
- **Don't include text content in image prompts**, composite separately; text rendering is mediocre

## API access

Through Google Gemini API (`gemini-2.5-flash-image` model endpoint). Available via:

- Gemini API direct
- Vertex AI
- Replicate
- fal.ai (under "google/nano-banana")

Same prompt syntax across all four.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/nano-banana.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/seedance.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/seedance.md`

# Adapter: Seedance 2.0 (motion-aware video, multi-shot)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Seedance 2.0 is the multi-shot model. It can generate a **short sequence of cuts in a single generation** while holding subject and environment consistency across them. Reach for it when several consecutive storyboard beats share one subject and you want them to feel like one continuous take, it beats stitching four independent Kling clips that drift apart. For a single isolated shot, Kling is the simpler default.

With video the **camera motion is load-bearing**, and with Seedance the **cut structure is also load-bearing**, you describe the sequence of shots, not just one frame.

## Syntax pattern

Single shot:
```
{Camera motion sentence, leading.} {Subject and action.} {Environment and lighting from series_lock.} {Color grade and mood from brand_lock.}
```

Multi-shot sequence (Seedance's strength):
```
Shot 1: {camera + action}. Shot 2: {camera + action}. Shot 3: {camera + action}. Consistent subject throughout: {series_lock character anchor, verbatim}. {Environment and lighting from series_lock.} {Color grade and mood from brand_lock.}
```

## Parameters

| Parameter | Default | Notes |
|---|---|---|
| `duration` | `5s` per shot block | Multi-shot sequences run longer; check the current fal.ai ceiling |
| `aspect_ratio` | from `project.aspect` | |
| `start_image` | optional | Image-to-video reference for the opening frame |
| `shots` | 1 | Number of cuts in the sequence when using multi-shot mode |

```
# shot_02-shot_04. Seedance 2.0: ar=9:16, shots=3, multi-shot sequence
{prompt}
```

## Length

Seedance handles **80–150 words**. In multi-shot mode, keep each shot clause short, one camera move and one action per cut.

## When to use multi-shot vs single

| Situation | Mode |
|---|---|
| One beat, one frame | Single shot (or use Kling) |
| 2–4 consecutive beats, same subject, want continuity | Multi-shot sequence |
| Beats with different subjects/locations | Separate generations, assemble in edit |

Map consecutive `shots.json` entries that share a subject into one Seedance multi-shot prompt; reference them by id range in the comment.

## Motion vocabulary

The shot grammar `motion` field maps directly. One move per cut.

| `motion` | Video prompt phrase |
|---|---|
| `static` | "Static camera, locked off." |
| `push` / `pull` | "Camera dollies forward / backward slowly." |
| `pan-left` / `pan-right` | "Camera pans smoothly left / right." |
| `tilt-up` / `tilt-down` | "Camera tilts up / down." |
| `handheld` | "Handheld camera, subtle organic movement." |
| `orbit` | "Camera orbits the subject slowly." |
| `whip` | "Fast whip pan with motion blur." |
| `rack` | "Rack focus from foreground to background." |

## Example

**Three consecutive beats of the same founder, mapped to one sequence.**

```
Shot 1: static eye-level, the founder closes his laptop and exhales. Shot 2: slow push toward his face as he looks toward the window. Shot 3: handheld over-the-shoulder as he stands and crosses the room. Consistent subject throughout: a founder in his mid-thirties with salt-and-pepper hair, navy crewneck. Minimalist home office, white walls, oak desk, soft natural side-light from a large window on the left, warm afternoon golden hour. Warm filmic color grade with muted teal shadows. Calm, considered, operator mood.
```

## Pitfalls to avoid

- **Don't force unrelated beats into one sequence.** Multi-shot is for shots that genuinely belong to one take.
- **Don't write more than ~4 cuts per generation.** Consistency degrades past that; split and assemble in edit.
- **Don't vary the character anchor between cuts.** Restate it once for the whole sequence, verbatim.
- **Don't include text content.** Composite captions from `text-overlays.json` in post.
- **Don't stack two camera moves inside one cut.** One move per cut.

## Output handoff

Seedance returns a sequence as a single clip (or a small set). It still needs: editorial trimming to exact storyboard timing, text-overlay compositing, a color-grade pass, and audio. Multi-shot output usually needs *less* assembly than stitched single clips, which is the point. Say so in handoff.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/seedance.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/seedream.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/seedream.md`

# Adapter: Seedream (4.5 / 4.0)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

ByteDance's Seedream models are the high-volume cost-efficient choice. Quality is below Flux 2 Pro and Midjourney v7 but above older mid-tier models, and the cost-per-image is roughly 5–10× lower. Choose Seedream when you're producing **many variations or doing rapid concept iteration**, not for hero/final assets.

For storyboard work, Seedream is useful for the storyboard preview pass: render every shot quickly to validate composition before committing to higher-cost generation for finals.

## Syntax pattern

Seedream rewards **short, precise prompts**. Long descriptive prompts underperform, the model interprets them as competing weights and produces mush. Closer to Midjourney's style than Flux's.

```
{Subject phrase}, {action}, {environment}, {lighting}, {mood/style}, {aspect note}
```

Comma-separated, no full sentences.

## Parameters

Seedream is API-driven through fal.ai, Replicate, or BytePlus direct:

| Parameter | Default | Notes |
|---|---|---|
| `aspect_ratio` | from `project.aspect` | |
| `seed` | per-storyboard | Critical for series consistency |
| `guidance_scale` | `4.5` | Lower = more creative, higher = more literal |
| `steps` | `28` | Default. Increase to 50 for higher quality at cost |

Document:
```
# shot_01, params: ar=9:16, seed=2840193, guidance=4.5, steps=28
{prompt}
```

## Length

**40–70 words per prompt**. Shorter than most. Don't pad.

## Composition pattern

```
{Framing} of {character anchor}, {action}, {environment from series_lock}, {lighting from series_lock}, {color grade from brand_lock}, {one mood adjective}, photorealistic
```

## Example

**Same shot data as previous examples.**

**Output prompt:**
```
Medium shot of founder mid-thirties, salt-and-pepper hair, navy crewneck, leaning forward at laptop, face turned to window light, minimalist home office, oak desk, soft natural side-light from large window, warm afternoon, warm filmic color grade, muted teal shadows, calm operator mood, photorealistic
```

## When Seedream is the right choice

- **Storyboard preview pass**, render all shots quickly at low cost to validate composition before final pass
- **High-volume social content**, when you need 50+ images per day and the quality bar allows it
- **Concept exploration**, quick iteration on shot ideas before committing to a final generator
- **Placeholder content**, assets that will be replaced once the brand-lock is finalized

## When Seedream is the wrong choice

- **Hero shots / final deliverables**. Flux 2 Pro or Midjourney v7 produce noticeably better output
- **Photorealistic product shots**. Flux is meaningfully better for product fidelity
- **Text-heavy designs**. Ideogram or GPT Image
- **Cinematic mood pieces**. Midjourney is the move

## Series consistency

Seedream's character consistency is weaker than Midjourney `--cref` or Ideogram omni-reference. To compensate:

- **Lock the seed** at the storyboard level (same seed across all shots in a series)
- **Verbatim repeat** the character anchor string from series_lock in every prompt
- **Don't vary** the lighting language between shots, series_lock string in, no paraphrasing
- **Accept** that some shots will need re-rolls; budget for it

## Pitfalls to avoid

- **Don't write paragraphs**. Seedream wants comma-separated phrases
- **Don't use `--ar` syntax**, pass aspect_ratio as a parameter
- **Don't include text content**, text rendering is poor; composite separately
- **Don't expect Midjourney aesthetic**. Seedream produces clean but less art-directed output
- **Don't skip the seed lock for series work**, without it, character consistency breaks

## API access

- **fal.ai**, `bytedance/seedream-4.5` and `bytedance/seedream-4.0`
- **Replicate**, `bytedance/seedream-4.5`
- **BytePlus**, direct API, requires their account

Same prompt syntax across surfaces.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/seedream.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/adapters/veo.md -->
# SOURCE FILE: `skills/visual-prompt-forge/adapters/veo.md`

# Adapter: Veo 3 (motion-aware video, native audio)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Veo 3 is the dialogue and lipsync model. It is the only adapter that generates **synchronised native audio**, speech, ambience, and sound effects, in the same pass as the video. It also has the strongest prompt adherence and physical realism of the four motion models. It is the most expensive, so reserve it for shots that actually need spoken dialogue, lipsync, or audio baked in. For silent B-roll and camera moves, Kling is the cheaper default.

With video the **camera motion is load-bearing**. When the shot has dialogue, the **spoken line is also load-bearing** and is written into the prompt (this is the one place where text belongs in a prompt, it is audio, not on-screen text).

## Syntax pattern

```
{Camera motion sentence, leading.} {Subject and action over the duration.} {Dialogue line, in quotes, if any.} {Environment and lighting from series_lock.} {Audio direction.} {Color grade and mood from brand_lock.}
```

## Parameters

| Parameter | Default | Notes |
|---|---|---|
| `duration` | `8s` | Veo's native clip length |
| `aspect_ratio` | from `project.aspect` | |
| `generate_audio` | `true` | The reason to choose Veo. Set `false` only for silent shots |
| `start_image` | optional | Image-to-video from an accepted still |

```
# shot_04. Veo 3: duration=8s, ar=9:16, generate_audio=true
{prompt}
```

## Length

Veo handles **80–150 words**. Spend the headroom on action timing and audio direction, not adjective stacks.

## Dialogue and lipsync

When the shot calls for the subject to speak, put the exact line in quotes:

> The founder looks directly into the lens and says, "I built the system once, and it runs without me."

Keep spoken lines to what fits the duration, roughly 12–18 words for an 8s clip. Direct the delivery ("calm, unhurried"). Veo lipsyncs the quoted line.

## Motion vocabulary

The shot grammar `motion` field maps directly. One move per shot.

| `motion` | Video prompt phrase |
|---|---|
| `static` | "Static camera, locked off." |
| `push` / `pull` | "Camera dollies forward / backward slowly." |
| `pan-left` / `pan-right` | "Camera pans smoothly left / right." |
| `tilt-up` / `tilt-down` | "Camera tilts up / down." |
| `handheld` | "Handheld camera, subtle organic movement." |
| `orbit` | "Camera orbits the subject slowly." |
| `whip` | "Fast whip pan with motion blur." |
| `rack` | "Rack focus from foreground to background." |

## Audio direction

Even on silent shots Veo can place ambience. Be explicit and brief:

- "Audio: quiet room tone, faint keyboard, no music."
- "Audio: soft afternoon ambience, distant street."

If the brand-lock or storyboard owns the audio bed (VO recorded separately, music added in post), set `generate_audio=false` and skip this section so Veo does not invent a competing track.

## Example

**Shot with `motion = "static"` and a spoken line.**

```
Static camera, locked off, eye level. A founder in his mid-thirties with salt-and-pepper hair in a navy crewneck sits at his laptop in a minimalist home office and looks directly into the lens. He says, "I built the system once, and it runs without me," calm and unhurried. Soft natural side-light from a large window on the left, warm afternoon golden hour. Audio: quiet room tone, faint keyboard, no music. Warm filmic color grade with muted teal shadows. Calm, considered, operator mood.
```

## Pitfalls to avoid

- **Don't use Veo for silent B-roll.** You are paying for an audio engine you turned off; use Kling.
- **Don't overrun the duration with dialogue.** A line that needs 12s of speech will clip or rush at 8s.
- **Don't put on-screen text in the prompt.** Spoken lines are fine; rendered captions still come from `text-overlays.json` in post.
- **Don't stack two camera moves.** One move per shot.
- **Don't let Veo's auto-audio fight a post audio bed.** Pick one owner of sound per shot.

## Output handoff

Veo clips arrive with audio attached. They still need: editorial assembly to timing, on-screen text compositing from `text-overlays.json`, a color-grade pass, and an audio decision, keep Veo's native track, or mute it and use the storyboard's recorded VO and music. State which in handoff.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/adapters/veo.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/examples/one-shot-all-adapters/README.md -->
# SOURCE FILE: `skills/visual-prompt-forge/examples/one-shot-all-adapters/README.md`

# One Shot, All Adapters

This example takes a single shot from the WhyStrohm 30-second pitch and renders it through the generator adapters in the pack. Use it as a calibration reference: same intent, same data, different prompt syntaxes. Six stills adapters are shown, plus the default motion adapter (Kling) standing in for the motion video lane.

## The source shot

From `examples/30s-pain-proof-promise/shots.json`:

```json
{
  "id": "shot_04",
  "beat": "reframe",
  "start": 11.0,
  "end": 16.0,
  "framing": "MCU",
  "angle": "eye-level",
  "motion": "push",
  "depth_of_field": "shallow",
  "subject": "founder, same posture, looking at camera, expression shifts from tired to clear, small almost-smile",
  "rationale": "Slow push as the reframe lands. Same character, same environment, only the expression changes. The change is the point."
}
```

## Series lock context (constant across all adapters)

```
character: founder, mid-thirties, salt-and-pepper hair, navy crewneck, calm posture
environment: minimalist home office, white walls, oak desk, single houseplant
lighting: soft natural side-light, large window camera-left, warm afternoon golden hour
color_grade: warm filmic, muted teal shadows, slight grain
```

## Brand mood

`calm, considered, operator (not creator), confident without volume`

## Outputs

Each `.txt` file in this directory is the prompt for one adapter:

- `midjourney.txt`. Midjourney v7
- `flux.txt`. Flux 2 Pro
- `ideogram.txt`. Ideogram v3 (composited mode)
- `gpt-image.txt`. GPT Image 1.5
- `nano-banana.txt`. Gemini 2.5 Flash Image
- `seedream.txt`. Seedream 4.5
- `kling.txt`. Kling 3.0 (motion video, the default motion adapter)

The other three motion adapters (`veo` for dialogue/lipsync, `seedance` for multi-shot sequences, `hailuo` for budget iteration) follow the same five-layer anatomy as Kling and are chosen by need; see their files in `adapters/`. This single silent push shot doesn't exercise dialogue or a sequence, so Kling is the representative motion example here.

Note the differences:

- **Midjourney** is a comma-separated stack with `--ar`, `--style raw`, `--s 50` flags
- **Flux** is natural-language paragraphs with no flags, parameters live in the API call
- **GPT Image** uses paragraph breaks and explicit spatial language
- **Seedream** is the shortest, comma stack like Midjourney but no flags
- **Kling** (and every motion adapter) leads with camera motion (the stills adapters let it be implicit)

Same intent. Different syntax. Same brand-lock and series-lock anchors flowing through all of them.

## What's not in any prompt

The on-screen text content. Even though shot_04 has an on-screen text overlay (`text_03`, "You don't have a content problem. You have an infrastructure problem."), none of the prompts contain that text. It's composited separately per the five-layer model.

This is the discipline: the image generator handles the image, the compositor handles the text, neither tries to do the other's job.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/examples/one-shot-all-adapters/README.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/examples/one-shot-all-adapters/flux.txt -->
# SOURCE FILE: `skills/visual-prompt-forge/examples/one-shot-all-adapters/flux.txt`

# Storyboard: WhyStrohm, The Content Infrastructure Pitch
# Generator: flux (Flux 2 Pro)
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Generated: 2026-05-07

# shot_04, reframe, 11.0-16.0s, MCU eye-level push
# params: aspect_ratio=9:16, output_format=png, prompt_upsampling=false, seed=2840193
Medium close-up of a founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck, looking directly at the camera. His expression is shifting from tired to clear, a small almost-smile beginning to form. The camera is dollying slowly forward into the scene. The setting is a minimalist home office: white walls, an oak desk, a single houseplant in the background, no decorative clutter. Soft natural side-light from a large window camera-left, warm afternoon golden hour temperature. Shot on a 50mm prime at f/2.0, shallow depth of field. Warm filmic color grade with muted teal shadows and slight grain. Calm, considered, operator mood, confident without volume. Photorealistic, natural skin texture, no AI rendering artifacts.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/examples/one-shot-all-adapters/flux.txt -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/examples/one-shot-all-adapters/gpt-image.txt -->
# SOURCE FILE: `skills/visual-prompt-forge/examples/one-shot-all-adapters/gpt-image.txt`

# Storyboard: WhyStrohm, The Content Infrastructure Pitch
# Generator: gpt-image (1.5)
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Generated: 2026-05-07

# shot_04, reframe, 11.0-16.0s, MCU eye-level push
# params: size=1024x1792, quality=high, style=natural, model=gpt-image-1.5
A founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck sweater, looks directly at the camera. He is positioned in the center of the frame, with his shoulders square and his head tilted slightly toward the camera-left light source. His expression captures a transition: the tiredness in his eyes is giving way to clarity, and a small, almost-smile is just beginning to form at the corners of his mouth. The camera is dollying slowly forward into the scene over the duration of the shot.

The setting is a minimalist home office. White walls, an oak desk in the lower portion of the frame, and a single houseplant visible in the soft-focus background. There are no decorative objects or clutter, the environment is deliberately spare.

Soft natural side-light enters from a large window camera-left, casting a warm afternoon golden-hour temperature across the subject's face. Shot on a 50mm prime lens at f/2.0, with shallow depth of field that softens the background while keeping the subject's eyes razor-sharp. Warm filmic color grade with muted teal shadows and a slight grain. The mood is calm and considered, operator energy, not creator energy. Natural skin texture, no AI rendering artifacts.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/examples/one-shot-all-adapters/gpt-image.txt -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/examples/one-shot-all-adapters/ideogram.txt -->
# SOURCE FILE: `skills/visual-prompt-forge/examples/one-shot-all-adapters/ideogram.txt`

# Storyboard: WhyStrohm, The Content Infrastructure Pitch
# Generator: ideogram (v3, Mode 1 composited)
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Generated: 2026-05-07

# shot_04, reframe, 11.0-16.0s, MCU eye-level push
# params: aspect_ratio=9:16, model=V_3, magic_prompt=OFF, style_type=REALISTIC, seed=2840193
Medium close-up of a founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck, looking directly at the camera. His expression is shifting from tired to clear, a small almost-smile beginning. The camera is dollying slowly forward. Minimalist home office, white walls, oak desk, single houseplant. Soft natural side-light from a large window camera-left, warm afternoon golden hour. Shot on a 50mm prime at f/2.0, shallow depth of field. Warm filmic color grade, muted teal shadows, slight grain. Calm, considered, operator mood. Clean composition with negative space for text overlay placement.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/examples/one-shot-all-adapters/ideogram.txt -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/examples/one-shot-all-adapters/kling.txt -->
# SOURCE FILE: `skills/visual-prompt-forge/examples/one-shot-all-adapters/kling.txt`

# Storyboard: WhyStrohm, The Content Infrastructure Pitch
# Generator: kling (Kling 3.0, motion-aware video, default)
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Generated: 2026-06-18

# shot_04, reframe, 11.0-16.0s, MCU eye-level push (5s clip)
# Kling 3.0: duration=5s, ar=9:16, cfg=0.5, seed=2840193
Camera dollies slowly forward into the scene at a steady pace over the 5-second duration. A founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck, looks directly into the camera. Over the course of the shot his expression shifts subtly from tired to clear, a small almost-smile forming at the corners of his mouth. Minimalist home office, white walls, oak desk, single houseplant in the soft-focus background. Soft natural side-light from a large window camera-left, warm afternoon golden hour. Shot on a 50mm equivalent, shallow depth of field with the background softly out of focus. Warm filmic color grade with muted teal shadows and slight grain. Calm, considered, operator mood.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/examples/one-shot-all-adapters/kling.txt -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/examples/one-shot-all-adapters/midjourney.txt -->
# SOURCE FILE: `skills/visual-prompt-forge/examples/one-shot-all-adapters/midjourney.txt`

# Storyboard: WhyStrohm, The Content Infrastructure Pitch
# Generator: midjourney (v7)
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Generated: 2026-05-07

# shot_04, reframe, 11.0-16.0s, MCU eye-level push
medium close-up of founder mid-thirties, salt-and-pepper hair, navy crewneck, looking at camera, expression shifting from tired to clear, small almost-smile, dolly in pushing forward, minimalist home office, white walls, oak desk, single houseplant, soft natural side-light large window camera-left, warm afternoon golden hour, warm filmic color grade, muted teal shadows, slight grain, cinematic photography, calm considered operator mood --ar 9:16 --style raw --s 50

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/examples/one-shot-all-adapters/midjourney.txt -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/examples/one-shot-all-adapters/nano-banana.txt -->
# SOURCE FILE: `skills/visual-prompt-forge/examples/one-shot-all-adapters/nano-banana.txt`

# Storyboard: WhyStrohm, The Content Infrastructure Pitch
# Generator: nano-banana (Gemini 2.5 Flash Image)
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Generated: 2026-05-07

# shot_04, reframe, 11.0-16.0s, MCU eye-level push
# Text-to-image prompt:
# params: aspectRatio=9:16, numberOfImages=1
Medium close-up of a founder, mid-thirties, salt-and-pepper hair, navy crewneck, looking directly at camera with expression shifting from tired to clear, a small almost-smile beginning. Camera dollying slowly forward. Minimalist home office, white walls, oak desk, single houseplant. Soft natural side-light from large window camera-left, warm afternoon golden hour. Shot on 50mm prime, f/2.0, shallow depth of field. Warm filmic color grade with muted teal shadows, slight grain. Calm, considered, operator mood.

# shot_04, variant template (run after text-to-image to get variants):
# Reference: [the generated image from above]
# Prompt: Modify the image to vary the founder's expression. Preserve the character's face, salt-and-pepper hair, navy crewneck, the home office environment, the camera-left lighting, the 50mm shallow depth-of-field framing, and the warm filmic grade. Change only the expression: produce one variant with the smile fully formed, one with a more neutral pre-smile state, one with eyes slightly closed mid-blink for a candid feel.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/examples/one-shot-all-adapters/nano-banana.txt -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/examples/one-shot-all-adapters/seedream.txt -->
# SOURCE FILE: `skills/visual-prompt-forge/examples/one-shot-all-adapters/seedream.txt`

# Storyboard: WhyStrohm, The Content Infrastructure Pitch
# Generator: seedream (4.5)
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Generated: 2026-05-07

# shot_04, reframe, 11.0-16.0s, MCU eye-level push
# params: aspect_ratio=9:16, seed=2840193, guidance_scale=4.5, steps=28
Medium close-up of founder mid-thirties, salt-and-pepper hair, navy crewneck, looking at camera, expression shifting from tired to clear, small almost-smile beginning, minimalist home office, white walls, oak desk, single houseplant, soft natural side-light from large window camera-left, warm afternoon golden hour, warm filmic color grade, muted teal shadows, slight grain, calm operator mood, photorealistic

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/examples/one-shot-all-adapters/seedream.txt -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/references/consistency-locks.md -->
# SOURCE FILE: `skills/visual-prompt-forge/references/consistency-locks.md`

# Consistency Locks

Visual consistency across a storyboard is the hardest problem in AI image generation. Generators are stateless, every prompt is interpreted fresh. Without consistency locks, shot 1 and shot 7 will look like different productions.

This document covers the techniques that actually work in 2026.

## Lock 1. Verbatim character anchors

The most effective single technique. The character is described in `series_lock.character` once, and that exact string appears in every shot's prompt verbatim. No paraphrasing, no synonyms, no "improvement."

**Good (consistent):**
```
shot_01: "founder, mid-thirties, salt-and-pepper hair, navy crewneck, stubble"
shot_02: "founder, mid-thirties, salt-and-pepper hair, navy crewneck, stubble"
shot_07: "founder, mid-thirties, salt-and-pepper hair, navy crewneck, stubble"
```

**Bad (inconsistent):**
```
shot_01: "a thoughtful entrepreneur in his thirties, dark hair, casual sweater"
shot_02: "founder, 35 years old, salt-pepper hair, blue knit top"
shot_07: "the man in the home office, navy shirt"
```

Even small variations compound. Lock the string. Repeat verbatim.

## Lock 2. Verbatim environment anchors

Same principle for `series_lock.environment`. The environment string is identical in every shot prompt. The shot's individual subject describes what changes within the environment, not the environment itself.

## Lock 3. Verbatim lighting anchors

Same principle for `series_lock.lighting`. Lighting direction in particular is critical, flipping window-left to window-right between shots produces obvious cuts where there shouldn't be any.

## Lock 4. Seed locking

For generators that support seeds (Flux, Seedream, Ideogram, Stable Diffusion), set the seed at the storyboard level. Same seed across every shot. This anchors the generator's randomness so character features carry.

In `shots.json`, you can document the seed at the project level:

```json
{
  "project": {
    "title": "...",
    "seed": 2840193
  }
}
```

The adapter reads this and applies to every prompt.

**Caveat:** Midjourney and some motion models (Veo, Seedance) handle seeds differently, or not at all. Document seed-locking as best-effort, not guaranteed.

## Lock 5. Reference images (`--cref`, omni-reference, image-to-image)

For Midjourney v7, Ideogram v3, and Nano Banana, you can pass a reference image alongside the prompt to anchor character or style.

**Workflow:**

1. Generate the hero shot first (any shot, usually `shot_01` or whichever is most defining)
2. Use that image as the reference for every subsequent shot
3. Each subsequent prompt has the verbatim character anchor PLUS the reference image link

For Midjourney: `--cref {url} --cw 50` (character weight 50 = features only, not clothing).

For Ideogram: `omni-reference` parameter with the image.

For Nano Banana: `referenceImages` array.

**This is the most effective lock for character consistency** in 2026. Use it whenever the storyboard features the same person across multiple shots.

## Lock 6. Style references

When the storyboard has a distinctive visual style (specific film stock, specific lighting school, specific color theory), use a style reference image:

- Midjourney: `--sref {url}`
- Ideogram: style reference parameter
- Flux: not directly supported; bake style language into prompt instead

A consistent style reference across all shots produces aesthetic continuity even when characters or environments shift.

## Lock 7. Lighting direction continuity

A subtle one that breaks scenes when violated. If `series_lock.lighting` says "soft natural side-light, large window LEFT", then every shot's lighting must respect that direction.

When a shot reverses character orientation (e.g., over-the-shoulder reverse), update the rationale to acknowledge the lighting flip:

```
"rationale": "OTS reverse, light source now camera-right (matching scene continuity from window-left in master)"
```

If you find yourself flipping light direction without rationale, you're producing visual jump cuts.

## Lock 8. Color grade flow-through

The `series_lock.color_grade` string flows into every prompt verbatim. Same as character/environment/lighting. If shot 1 is "warm filmic, muted teal shadows" and shot 7 is "cinematic teal and orange", the audience will read it as different scenes.

## Failure modes when locks are missing

| Missing lock | Failure mode |
|---|---|
| Character | Different person every shot |
| Environment | Scene jumps |
| Lighting | Time-of-day jumps, eye-line breaks |
| Seed | Random feature drift |
| Reference image | Loose character interpretation |
| Color grade | Tonal whiplash |

Every one of these is a production problem editorial cannot fully fix. Lock at the prompt level. Save the editor's time.

## What doesn't work

A few things people try that don't actually fix consistency:

- **Adding "consistent character" or "same person" to the prompt**, generators don't read meta-instructions
- **Numbering shots in the prompt** ("shot 3 of 7, same as before"), generators don't have memory across calls
- **Long descriptive paragraphs of the character**, past 4–5 features, the generator starts dropping details randomly
- **Asking for "exactly the same"**, there is no such thing in stateless image gen; you reduce drift, you don't eliminate it

Accept that some shots will need re-rolls. Budget for it. The locks reduce the failure rate; they don't eliminate it.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/references/consistency-locks.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/references/failure-modes.md -->
# SOURCE FILE: `skills/visual-prompt-forge/references/failure-modes.md`

# Failure Modes

What goes wrong when generated images don't match the storyboard, and what to fix at the prompt level vs. accept as editorial work.

## Failure 1. The "AI look"

**Symptoms:** plastic skin, oversaturated colors, eyes too symmetrical, hands wrong, generic stock-photo composition, lighting that's too even, "rendered" feel.

**Causes:**
- Generic mood adjectives ("beautiful", "stunning", "amazing")
- Stable Diffusion crutches ("4k", "highly detailed", "masterpiece") in non-SD generators
- Missing photographic specifics
- No "never" list applied from brand-lock

**Prompt-level fixes:**
- Add specific lens and aperture ("50mm prime, f/2.0")
- Add film stock or camera reference ("Sony FX6", "Kodak Portra 400 film stock")
- Add "natural skin texture, no AI rendering artifacts" closing line (Flux, GPT Image)
- Verify brand-lock "never" list is being applied, if it includes "no AI uncanny", surface that into the prompt
- Use Flux 2 Pro or Midjourney v7 instead of cheaper models for hero shots

**Accept editorially when:** the brief is for stylized content where realism isn't the goal.

## Failure 2. Character drift across shots

**Symptoms:** same person looks different in shot 1 vs shot 5; clothing changes; hair color shifts; age perceived differently.

**Causes:**
- Series_lock character string paraphrased rather than verbatim
- No reference image passed (`--cref`, omni-reference)
- Seed not locked
- Too few features described in character anchor (gives generator too much room)

**Prompt-level fixes:**
- Verify character string is verbatim across every prompt
- Add 1–2 more specific features ("small scar above left eyebrow", "black wireframe glasses")
- Use reference image after the first successful shot
- Lock seed at storyboard level
- For Midjourney, use `--cref` with `--cw 50`

**Accept editorially when:** character consistency is genuinely impossible to lock. Budget re-rolls, typically 2–3× per problematic shot.

## Failure 3. Text in image looks bad

**Symptoms:** text is misspelled, kerning is off, font is wrong, multiple text elements compete.

**Causes:**
- Text was put in the image prompt instead of being composited
- Wrong generator chosen (using Midjourney for text-heavy work)
- Multiple text elements in one prompt

**Prompt-level fixes:**
- The right answer is almost always: **don't put text in the prompt**. Composite separately from `text-overlays.json`.
- If text must be in-image (poster work), use Ideogram v3 with explicit override flag
- Limit to one text element per prompt
- Use simple fonts (sans-serif, clean serif), cursive and decorative fonts fail even on Ideogram

**Accept editorially when:** the deliverable genuinely requires baked-in text and Ideogram's output is close enough to retouch.

## Failure 4. Lighting direction inconsistency

**Symptoms:** shot 3 has light from window-left, shot 4 has light from window-right, they cut together as a continuity error.

**Causes:**
- Lighting language paraphrased rather than verbatim from series_lock
- Reverse-angle shots not flagged in rationale
- Generator interpreting lighting ambiguously

**Prompt-level fixes:**
- Verify lighting string is verbatim across prompts
- Be explicit about direction: "from camera-left" not "from one side"
- For reverse-angle shots, flag in rationale and update lighting language for that shot only
- For Flux and GPT Image, add the photographic spec ("key light camera-left at 45 degrees")

**Accept editorially when:** lighting drift is subtle enough that color grading will fix it.

## Failure 5. Composition doesn't reserve space for text overlay

**Symptoms:** the storyboard says text goes in the right third, but the generated image has the subject filling the right third.

**Causes:**
- Shot subject didn't include negative-space note
- Generator interpreting "centered subject" by default

**Prompt-level fixes:**
- Add explicit composition note: "subject framed in left third, right two-thirds open for text overlay"
- For GPT Image (best at spatial reasoning), use percentage references: "subject at left 30% of frame"
- Re-roll with explicit composition prompt, this often fixes on second try

**Accept editorially when:** image is otherwise great. Reposition text overlay to fit the actual composition.

## Failure 6. Series feels "different" even with locks applied

**Symptoms:** all locks are in place, prompts look right, but the storyboard feels disjointed when viewed end-to-end.

**Causes:**
- Color grade language drifting between shots (one says "warm filmic", another says "cinematic")
- Aspect ratio drift (some 9:16 generations are taller than others)
- Mood adjectives shifting ("calm" in shot 1 vs "energetic" in shot 5 even though brief was uniform)

**Prompt-level fixes:**
- Audit every prompt against series_lock and brand-lock, verbatim check
- Verify aspect ratio is identical across all prompts
- Lock the brand mood adjectives, same set in every prompt

**Accept editorially when:** the disjoint feel is below the noise floor for the medium (e.g. fast-cut social where each shot is on screen <2s).

## Failure 7, "Looks fine but doesn't match the brief"

**Symptoms:** image is technically good but doesn't capture what the brief was actually about.

**Causes:**
- The shot subject in `shots.json` was vague
- The brief context wasn't surfaced into the prompt
- The generator is producing competent generic output rather than specific intent

**Prompt-level fixes:**
- Tighten the shot's subject field, what specifically is the audience meant to feel or notice
- Include a one-phrase intent at the end ("the moment of recognition", "the calm before the decision")
- For complex scenes, add a "what this shot conveys" line

**Accept editorially when:** generation is close enough that retouching gets there. Don't burn API credits chasing perfect on-prompt.

## When to stop iterating prompts

Three signs:

1. You've re-rolled the same shot 5+ times with no improvement → the prompt is fine; the model can't render this concept; pick a different shot or different generator
2. You're tweaking single words and hoping → you've hit prompt-level diminishing returns; move to image-to-image refinement (Nano Banana) or post-production
3. The image is 80% right and the gap is editorial → ship to post and let the editor finish

Generation is one stage in a pipeline. Don't try to make it the whole pipeline.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/references/failure-modes.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/references/prompt-anatomy.md -->
# SOURCE FILE: `skills/visual-prompt-forge/references/prompt-anatomy.md`

# Prompt Anatomy: The Five Layers

Every image prompt this skill produces is composed from five layers. Four are inputs, one is applied at compose-time. Understanding the layers is the difference between bulletproof prompts and lottery tickets.

## Layer 1. Brand Lock

**What:** the locked brand parameters for the entire project.
**Source:** `brand-lock.snapshot.md` referenced in `shots.json`.
**Constant across:** every storyboard, every shot.

Contains:

- Palette (hex values)
- Typography (font names, weights)
- Mood descriptors (3–5 adjectives that describe the brand's emotional posture)
- "Never" list (things this brand never does, e.g. "no stock photo aesthetic", "no AI uncanny", "no over-saturated", "no shouting copy")
- Aspect ratios used
- Color grade direction

This layer answers: **what does the brand always look and feel like?**

## Layer 2. Series Lock

**What:** the locked anchors for this specific storyboard.
**Source:** `shots.json` → `series_lock`.
**Constant across:** every shot in this one storyboard.

Contains:

- Character anchor (who's in frame, described identically every shot)
- Environment description (where the action takes place, identical every shot)
- Lighting setup (direction, source, color temperature, identical every shot)
- Color grade (filmic look, identical every shot)

This layer answers: **what stays the same across this storyboard?**

The series_lock is what makes shot 1 and shot 7 feel like the same piece. Without it, every generated frame looks like a different production.

## Layer 3. Shot Spec

**What:** the per-shot variables.
**Source:** `shots.json` → `shots[i]`.
**Variable across:** every shot.

Contains:

- Framing (ECU, CU, MS, etc.)
- Angle (eye-level, high, low, etc.)
- Motion (static, push, pull, etc.)
- Subject (what's happening in this specific shot)
- Depth of field
- Rationale (audit trail, why this shot, this beat, this moment)

This layer answers: **what's different about this specific shot?**

## Layer 4. Text Layer

**What:** on-screen text composited after generation.
**Source:** `text-overlays.json`.
**Never appears in image prompts** (except Ideogram Mode 2 with explicit override).

Why text is a separate layer:

1. **Editability.** Composited text can be revised without re-generating images.
2. **Quality.** Even Ideogram and GPT Image (the best at text) produce typography that lags professional design tools.
3. **Animation.** Animated text needs After Effects / Remotion / CapCut. Static rendered text is dead-on-arrival for motion content.
4. **Brand control.** Composited text uses exact brand fonts and exact brand colors. Generated text approximates.

## Layer 5. Generator Adapter

**What:** model-specific syntax wrapper.
**Source:** the relevant `adapters/{generator}.md` file.
**Variable across:** every target generator.

This is the only layer the skill *applies* (vs. reads). Layers 1–4 are inputs; Layer 5 is the renderer that turns inputs into a generator-specific string.

The adapter handles:

- Word order (Midjourney leads with subject; motion adapters like Kling lead with camera motion)
- Length conventions (Seedream short, GPT Image long)
- Parameter syntax (`--ar 9:16` vs `aspect_ratio: "9:16"`)
- Idiosyncratic strengths (Ideogram for text, Flux for photoreal, etc.)

## How layers compose

For a single shot's prompt:

```
Layer 1 (brand) ───┐
                   │
Layer 2 (series) ──┼──> Layer 5 (adapter) ──> {generator-specific prompt}
                   │
Layer 3 (shot) ────┘

Layer 4 (text) ────> separate compositing pipeline
```

The adapter pulls from Layers 1–3 and produces a string. Layer 4 lives parallel and never enters the prompt.

## Why this matters operationally

**Change the brand color** → edit brand-lock.md. Every prompt across every storyboard updates. No find-and-replace across files.

**Change the character** → edit series_lock in shots.json. Every shot in this storyboard updates. Other storyboards untouched.

**Change one shot** → edit just that shot's spec. Other shots unaffected.

**Change the generator** → swap adapters. Same shot data, different output file. Zero edits to brand-lock or series_lock.

**Audit a render** → check brand-lock.snapshot.md to see what version the storyboard was built against.

This is why guardrails-in-code beat guardrails-in-vibes. Each layer has one job. Changes are surgical. Outputs are reproducible.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/references/prompt-anatomy.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/README.md -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/README.md`

# Tools

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

## Requirements

```bash
pip install pyyaml jsonschema
```

Standard library otherwise. No pandas, no numpy.

## Run everything

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

This is exactly what CI runs, so a green local run means a green PR.

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

## Repo checks

### `validate_skills.py`

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

```bash
python tools/validate_skills.py
```

### `validate_schemas.py`

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

```bash
python tools/validate_schemas.py
```

It validates schemas, not instances. For instances, see `validate_shots.py`.

### `validate_capabilities.py`

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

- every generator id has an adapter `.md` and every adapter `.md` has an entry
- no adapter advertises more words than its own `max_prompt_words` ceiling
- every adapter documents the `aspect_param` the matrix says to send
- no `notes` field cites a word count above its own ceiling
- warns when the matrix or an entry is past its 120-day freshness window

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

### `validate_brand_lock.py`

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

## Project checks

These run against a project's output directory, not the repo.

### `validate_shots.py`

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

### `validate_prompts.py`

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

### `validate_critique.py`

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

### `validate_provenance.py`

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

It catches, with a selftest for each:

- a frame regenerated after its critique (`image_sha256` no longer matches)
- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)
- a frame on disk with no critique for its round, never reviewed at all
- two critiques for the same shot in the same round, two operators colliding
- rounds that skip a number, or a critique whose `run_id` belongs to another run

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

## Rendering

### `shots-to-html.py`

Renders an output folder into a single `preview.html`.

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

### `copy-prompt.py`

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

## Internal modules

Not entry points. Imported by the tools above.

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.
- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

## Adding new tools

- Make it executable (`chmod +x`)
- Add a usage docstring at the top of the file
- Give it a `--selftest` that proves the check fires
- Document it in this README
- Wire it into `tools/check.sh`, which is what CI calls

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/README.md -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/_shotkit.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/_shotkit.py`

#!/usr/bin/env python3
"""
Shared helpers for the shotkit tools. Standard library only.

Everything here exists because more than one tool needs it. Hashing, brand-lock
parsing, and the capability-id list were duplicated or absent before; keeping one
copy is what stops the tools from disagreeing about what a brand-lock palette is
or which generator ids are real.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

CAPABILITIES_PATH = (
    REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters" / "_capabilities.json"
)

# Roles tools/shots-to-html.py maps onto CSS variables. Documented in
# docs/brand-lock-anatomy.md so a brand-lock author knows the names are load-bearing.
PALETTE_ROLES = ("background", "ink", "accent", "muted", "rule")

RUN_ID_RE = re.compile(r"^([0-9]{8}T[0-9]{6}Z)-[0-9a-f]{8}$")
ISO_INSTANT_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SHOT_ID_RE = re.compile(r"^shot_[0-9]{2,3}$")
TEXT_ID_RE = re.compile(r"^text_[0-9]{2,3}$")

HEX_RE = re.compile(r"#[0-9A-Fa-f]{6}")
PLACEHOLDER_HEX_RE = re.compile(r"#_{6}")

# | Role | `#RRGGBB` | Use | rows in a brand-lock Palette table.
PALETTE_ROW_RE = re.compile(
    r"^\|\s*([A-Za-z][A-Za-z0-9\s()/-]*?)\s*\|\s*`?(#(?:[0-9A-Fa-f]{6}|_{6}))`?\s*\|"
)

SNAPSHOT_TAKEN_RE = re.compile(r"<!--\s*snapshot taken:\s*(.+?)\s*-->")
SNAPSHOT_SOURCE_RE = re.compile(r"<!--\s*source:\s*(.+?)\s*-->")

IMAGE_EXTS = ("png", "jpg", "jpeg", "webp")


# --------------------------------------------------------------------------
# Hashing
# --------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    """SHA-256 of a file's bytes, read in chunks so large frames do not load whole."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    """SHA-256 of a string, UTF-8 encoded."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# Run identity
# --------------------------------------------------------------------------

def make_run_id(now: datetime | None = None, nonce: str | None = None) -> str:
    """Build a run_id. Pass `now` and `nonce` to make it reproducible in tests."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    if nonce is None:
        nonce = sha256_text(now.isoformat() + str(id(now)))[:8]
    return f"{stamp}-{nonce}"


def iso_instant(now: datetime | None = None) -> str:
    """UTC ISO-8601 to second precision with a trailing Z."""
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def run_id_timestamp(run_id: str) -> str | None:
    """Extract the compact timestamp from a run_id, or None if malformed."""
    m = RUN_ID_RE.match(run_id or "")
    return m.group(1) if m else None


# --------------------------------------------------------------------------
# JSON loading
# --------------------------------------------------------------------------

def load_json(path: Path) -> tuple[dict | list | None, str | None]:
    """Return (data, error). Exactly one of the two is None."""
    if not path.exists():
        return (None, f"file does not exist: {path}")
    try:
        return (json.loads(path.read_text(encoding="utf-8")), None)
    except json.JSONDecodeError as e:
        return (None, f"invalid JSON: {e}")
    except OSError as e:
        return (None, f"cannot read: {e}")


# --------------------------------------------------------------------------
# Capability matrix
# --------------------------------------------------------------------------

def capability_ids(caps_path: Path | None = None) -> set[str]:
    """Generator ids from the capability matrix. Empty set if it cannot be read."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return set()
    return {
        g["id"]
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


def capability_map(caps_path: Path | None = None) -> dict[str, dict]:
    """Generator id to its full capability entry."""
    data, err = load_json(caps_path or CAPABILITIES_PATH)
    if err or not isinstance(data, dict):
        return {}
    return {
        g["id"]: g
        for g in data.get("generators", [])
        if isinstance(g, dict) and isinstance(g.get("id"), str)
    }


# --------------------------------------------------------------------------
# Brand-lock parsing
# --------------------------------------------------------------------------

def parse_palette(text: str) -> dict[str, str]:
    """Role (lowercased) to hex value, from a brand-lock Palette table."""
    palette: dict[str, str] = {}
    for line in text.splitlines():
        m = PALETTE_ROW_RE.match(line)
        if m:
            palette[m.group(1).strip().lower()] = m.group(2).strip()
    return palette


def palette_hexes(text: str) -> set[str]:
    """Every real (non-placeholder) hex in a brand-lock, lowercased."""
    return {h.lower() for h in HEX_RE.findall(text)}


def is_unconfigured(text: str) -> bool:
    """True when the brand-lock still carries template placeholders in its palette."""
    return bool(PLACEHOLDER_HEX_RE.search(text))


def parse_typography(text: str) -> dict[str, str | None]:
    """
    Pull font names out of a brand-lock Typography section.

    Matches the documented format:
        **Display font:** `Inter Black 900`, headline weight, ...
        **Body font:** `Inter Medium 500`, body copy, ...
        **Mono font:** `JetBrains Mono Regular`, code, data, ...

    Mono is optional. A brand-lock that declares one has three legal overlay fonts,
    not two, which is why the font check reads all three rather than assuming a pair.
    """
    out: dict[str, str | None] = {
        "display_font": None,
        "body_font": None,
        "mono_font": None,
    }
    # The value has to be backticked and sit immediately after the label. That is what
    # separates a real declaration from the template's instructional prose
    # ("**Display font:** font name, weights used (e.g. `Inter Black 900`)"), which
    # would otherwise resolve to the example font.
    for key, label in (
        ("display_font", "Display"),
        ("body_font", "Body"),
        ("mono_font", "Mono"),
    ):
        pattern = re.compile(
            r"^\*\*" + label + r"\s+font[^:*]*:?\*\*[ \t]*`([^`\n]+)`",
            re.IGNORECASE | re.MULTILINE,
        )
        m = pattern.search(text)
        if m:
            value = m.group(1).strip()
            if value and not value.startswith("_"):
                out[key] = value
    return out


def parse_snapshot_header(text: str) -> dict[str, str | None]:
    """The two provenance comments storyboard-architect writes at the top of a snapshot."""
    taken = SNAPSHOT_TAKEN_RE.search(text)
    source = SNAPSHOT_SOURCE_RE.search(text)
    return {
        "snapshot_taken": taken.group(1).strip() if taken else None,
        "source": source.group(1).strip() if source else None,
    }


# --------------------------------------------------------------------------
# Output-tree conventions
# --------------------------------------------------------------------------

def round_dirs(output_dir: Path, kind: str) -> list[tuple[int, Path]]:
    """
    Sorted (round_number, path) for output_dir/<kind>/round-N directories.

    `kind` is 'frames', 'critiques', or 'prompts'.
    """
    base = output_dir / kind
    if not base.is_dir():
        return []
    found: list[tuple[int, Path]] = []
    for child in base.iterdir():
        if child.is_dir() and child.name.startswith("round-"):
            suffix = child.name[len("round-"):]
            if suffix.isdigit():
                found.append((int(suffix), child))
    return sorted(found)


def find_frame(output_dir: Path, shot_id: str, round_no: int | None = None) -> Path | None:
    """
    Locate a frame for a shot by the path convention.

    Prefers the highest-numbered round under frames/, then falls back to the
    legacy flat generated/ directory so pre-3.0.0 projects still render.
    """
    candidates = round_dirs(output_dir, "frames")
    if round_no is not None:
        candidates = [(n, p) for n, p in candidates if n == round_no]
    for _, directory in reversed(candidates):
        for ext in IMAGE_EXTS:
            candidate = directory / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    legacy = output_dir / "generated"
    if legacy.is_dir():
        for ext in IMAGE_EXTS:
            candidate = legacy / f"{shot_id}.{ext}"
            if candidate.exists():
                return candidate
    return None


def critique_paths(output_dir: Path) -> list[Path]:
    """
    Every critique file in an output tree, newest layout first.

    New layout: critiques/round-N/shot_NN.critique.json
    Legacy:     critique.json at the output root
    """
    found: list[Path] = []
    for _, directory in round_dirs(output_dir, "critiques"):
        found.extend(sorted(directory.glob("*.critique.json")))
        found.extend(sorted(directory.glob("*.json")))
    legacy = output_dir / "critique.json"
    if legacy.exists():
        found.append(legacy)
    # Preserve order, drop duplicates from the two globs above.
    seen: set[Path] = set()
    unique: list[Path] = []
    for path in found:
        resolved = path.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(path)
    return unique


def as_overlay_ids(value) -> list[str]:
    """Normalise shots.json on_screen_text (null, string, or array) to a list."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []


def as_shot_ids(value) -> list[str]:
    """Normalise text-overlays.json shot_id (string or array) to a list."""
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/_shotkit.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/_template.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/_template.py`

#!/usr/bin/env python3
"""
The small template engine tools/shots-to-html.py renders preview.html.tpl with.

Only the subset the template actually uses is implemented, deliberately: variable
substitution, a loop, and a truthiness block. It exists so the CLI and the
storyboard-html-preview skill render the same structural template instead of two
hand-maintained copies that drift apart.

Supported syntax:
    {{name}}            HTML-escaped substitution
    {{{name}}}          raw substitution, for pre-built markup such as inlined CSS
    {{#each items}}     iterate a list of dicts; inside the block, keys resolve
    {{/each}}           against the item first, then the enclosing context
    {{#if name}}        render when the value is truthy
    {{/if}}

Unknown names render empty rather than raising, which keeps a partially populated
context from producing a traceback in front of a client.
"""

from __future__ import annotations

import html
import re

BLOCK_RE = re.compile(r"\{\{#(each|if)\s+([A-Za-z0-9_]+)\s*\}\}")
RAW_VAR_RE = re.compile(r"\{\{\{\s*([A-Za-z0-9_]+)\s*\}\}\}")
VAR_RE = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")


def escape(value) -> str:
    """HTML-escape a value for text and attribute contexts, including quotes."""
    if value is None or value is False:
        return ""
    if value is True:
        return "true"
    return html.escape(str(value), quote=True)


def _find_block_end(text: str, kind: str, start: int) -> int:
    """Index of the closing tag matching the block opened before `start`."""
    open_re = re.compile(r"\{\{#" + kind + r"\s+[A-Za-z0-9_]+\s*\}\}")
    close_tag = "{{/" + kind + "}}"
    depth = 1
    pos = start
    while depth:
        next_close = text.find(close_tag, pos)
        if next_close == -1:
            raise ValueError(f"unclosed {{{{#{kind}}}}} block")
        next_open = open_re.search(text, pos, next_close)
        if next_open:
            depth += 1
            pos = next_open.end()
            continue
        depth -= 1
        pos = next_close + len(close_tag)
    return pos


def render(template: str, context: dict) -> str:
    """Render `template` against `context`."""
    out: list[str] = []
    pos = 0

    while pos < len(template):
        block = BLOCK_RE.search(template, pos)
        if not block:
            out.append(_render_leaf(template[pos:], context))
            break

        out.append(_render_leaf(template[pos : block.start()], context))
        kind, name = block.group(1), block.group(2)
        body_start = block.end()
        block_end = _find_block_end(template, kind, body_start)
        close_len = len("{{/" + kind + "}}")
        body = template[body_start : block_end - close_len]

        value = context.get(name)
        if kind == "each":
            for item in value or []:
                scoped = dict(context)
                if isinstance(item, dict):
                    scoped.update(item)
                else:
                    scoped["this"] = item
                out.append(render(body, scoped))
        else:
            if value:
                out.append(render(body, context))

        pos = block_end

    return "".join(out)


def _render_leaf(text: str, context: dict) -> str:
    """Substitute variables in a chunk with no block tags left in it."""
    text = RAW_VAR_RE.sub(lambda m: str(context.get(m.group(1), "") or ""), text)
    return VAR_RE.sub(lambda m: escape(context.get(m.group(1))), text)

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/_template.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/check.sh -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/check.sh`

#!/usr/bin/env bash
# Run every shotkit check. This is what CI calls, so a green local run means a green PR.
#
# Usage:
#   ./tools/check.sh            # run everything, report a summary
#   ./tools/check.sh --quiet    # only print failures and the summary
#
# Requires: pip install pyyaml jsonschema

set -uo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.." || exit 1

PYTHON="${PYTHON:-python3}"
QUIET=0
[[ "${1:-}" == "--quiet" ]] && QUIET=1

PASSED=0
FAILED=0
FAILED_NAMES=()

run() {
  local label="$1"
  shift
  local output
  if output=$("$PYTHON" "$@" 2>&1); then
    PASSED=$((PASSED + 1))
    if [[ "$QUIET" == "0" ]]; then
      echo "PASS  ${label}"
      sed 's/^/      /' <<<"$output"
      echo
    else
      echo "PASS  ${label}"
    fi
  else
    FAILED=$((FAILED + 1))
    FAILED_NAMES+=("$label")
    echo "FAIL  ${label}"
    sed 's/^/      /' <<<"$output"
    echo
  fi
}

echo "shotkit checks, using $("$PYTHON" --version 2>&1)"
echo

# Preflight the two dependencies. Without this, a missing package turns one actionable
# line into fourteen identical failures and you have to read all of them to find out.
missing=""
"$PYTHON" -c 'import yaml' 2>/dev/null || missing="pyyaml"
"$PYTHON" -c 'import jsonschema' 2>/dev/null || missing="${missing:+$missing }jsonschema"
if [[ -n "$missing" ]]; then
  echo "Missing Python package(s): ${missing}" >&2
  echo >&2
  echo "  ${PYTHON} -m pip install ${missing}" >&2
  echo >&2
  echo "Then re-run ./tools/check.sh" >&2
  exit 1
fi

# Structure and schemas
run "skills: frontmatter"            tools/validate_skills.py
run "schemas: are valid schemas"     tools/validate_schemas.py

# Capability matrix, including prose parity with the adapter files
run "capabilities: selftest"         tools/validate_capabilities.py --selftest
run "capabilities: matrix"           tools/validate_capabilities.py

# Brand-locks: packs allow templates, snapshots do not
run "brand-lock: selftest"           tools/validate_brand_lock.py --selftest
run "brand-lock: packs"              tools/validate_brand_lock.py \
  brand-packs/_template.md \
  brand-packs/whystrohm.md \
  brand-packs/examples/saas-clean.md \
  skills/brand-lock-extractor/examples/brand-lock.md
run "brand-lock: snapshots"          tools/validate_brand_lock.py --snapshots

# Storyboard instances, the rules JSON Schema cannot express
run "shots: selftest"                tools/validate_shots.py --selftest
run "shots: bundled examples"        tools/validate_shots.py --examples
run "shots: worked run"              tools/validate_shots.py \
  skills/visual-asset-critic/examples/worked-run

# Prompt files: the forge's hard rules, including verbatim series_lock anchors
run "prompts: selftest"              tools/validate_prompts.py --selftest
run "prompts: worked run"            tools/validate_prompts.py --examples

# Critique gate
run "critique: selftest"             tools/validate_critique.py --selftest
run "critique: fixtures"             tools/validate_critique.py --examples

# Provenance chain
run "provenance: selftest"           tools/validate_provenance.py --selftest
run "provenance: worked run"         tools/validate_provenance.py --examples --require-accept

# Tools that ship as part of the workflow
run "preview renderer: selftest"     tools/shots-to-html.py --selftest
run "prompt helper: selftest"        tools/copy-prompt.py --selftest

echo "─────────────────────────────────────────"
echo "${PASSED} passed, ${FAILED} failed"
if ((FAILED)); then
  printf 'failed: %s\n' "${FAILED_NAMES[@]}"
  exit 1
fi
exit 0

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/check.sh -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/copy-prompt.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/copy-prompt.py`

#!/usr/bin/env python3
"""Copy a shot prompt from a shotkit prompts file to the system clipboard.

Handles both file shapes the forge writes: a full pass, and a revision file where each
shot block carries `# fix [...]` annotations above the prompt. Comment lines inside a
block are treated as annotations and never land in the clipboard, so what you paste
into a generator is the prompt and nothing else.

Usage:
  python tools/copy-prompt.py output/prompts/round-1/flux.txt
  python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
  python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
  python tools/copy-prompt.py --selftest
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

# A shot block opens with the shot id near the start of a comment line. The forge's
# revision format prefixes it, so both of these are headers:
#   # shot_03, reframe, 11.0-16.0s, MCU eye-level push
#   # shot_03, promise, 3.0-8.0s, MCU eye-level push, revision (was REVISE)
#   # Revision of shot_03 (was REVISE)
SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT_LINE = re.compile(r"^\s*#")


class Block:
    __slots__ = ("shot_id", "header", "annotations", "body")

    def __init__(self, shot_id: str, header: str) -> None:
        self.shot_id = shot_id
        self.header = header
        self.annotations: list[str] = []
        self.body: list[str] = []

    def prompt(self) -> str:
        return "\n".join(self.body).strip()

    def label(self) -> str:
        note = f"  [{len(self.annotations)} fix note(s)]" if self.annotations else ""
        return f"{self.header}{note}  ({len(self.prompt())} chars)"


def get_clipboard_command() -> list[str] | None:
    """Return the platform-appropriate clipboard command, or None if unavailable."""
    if sys.platform == "darwin":
        return ["pbcopy"]
    if sys.platform.startswith("linux"):
        if shutil.which("xclip"):
            return ["xclip", "-selection", "clipboard"]
        if shutil.which("xsel"):
            return ["xsel", "--clipboard", "--input"]
        return None
    if sys.platform == "win32":
        return ["clip"]
    return None


def parse_prompt_text(text: str) -> list[Block]:
    """Split a prompt file into shot blocks, separating annotations from prompt body."""
    blocks: list[Block] = []
    current: Block | None = None

    for line in text.splitlines():
        match = SHOT_HEADER.match(line)
        if match:
            current = Block(match.group(1), line.strip())
            blocks.append(current)
            continue
        if current is None:
            continue  # file-level header comments, before the first shot block
        if COMMENT_LINE.match(line):
            current.annotations.append(line.strip())
        else:
            current.body.append(line)

    return [b for b in blocks if b.prompt()]


def parse_prompt_file(path: Path) -> list[Block]:
    return parse_prompt_text(path.read_text(encoding="utf-8"))


def copy_to_clipboard(text: str) -> bool:
    cmd = get_clipboard_command()
    if not cmd:
        return False
    proc = subprocess.run(cmd, input=text.encode("utf-8"))
    return proc.returncode == 0


def print_clipboard_help() -> None:
    if sys.platform.startswith("linux"):
        print("No clipboard utility found. Install xclip or xsel.", file=sys.stderr)
    else:
        print("No clipboard utility found on this platform.", file=sys.stderr)


def list_blocks(blocks: list[Block]) -> None:
    for i, block in enumerate(blocks, 1):
        print(f"{i}. {block.label()}")
        for note in block.annotations:
            print(f"     {note}")


def select_interactively(blocks: list[Block]) -> Block | None:
    list_blocks(blocks)
    try:
        raw = input(f"\nWhich shot? (1-{len(blocks)}): ").strip()
        idx = int(raw) - 1
    except (ValueError, EOFError):
        print("Invalid selection.", file=sys.stderr)
        return None
    if not (0 <= idx < len(blocks)):
        print("Selection out of range.", file=sys.stderr)
        return None
    return blocks[idx]


STANDARD_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Aspect: 9:16

# shot_01, hook, 0.0-2.0s, MCU eye-level static
first prompt body

# shot_02, pain, 2.0-6.0s, MS eye-level push
second prompt body
"""

REVISION_FIXTURE = """\
# Storyboard: Fixture
# Generator: flux
# Round: 2
# Revision of round 1. Shots not listed here already passed.

# shot_02, pain, 2.0-6.0s, MCU eye-level push, revision (was REVISE)
# fix [Shot Spec, major]: framing MS -> MCU
# fix [Technical, re-roll]: hand was malformed
revised prompt body
"""

LEGACY_REVISION_FIXTURE = """\
# Revision of shot_03 (was REVISE)
# fix [Series Lock, major]: added 'salt-and-pepper hair' to the character anchor
legacy revised prompt body
"""


def selftest() -> int:
    ok = True

    cases = [
        ("standard file yields both shots", STANDARD_FIXTURE, ["shot_01", "shot_02"]),
        ("revision file yields its shot", REVISION_FIXTURE, ["shot_02"]),
        ("legacy revision header is tolerated", LEGACY_REVISION_FIXTURE, ["shot_03"]),
    ]
    for label, fixture, expected in cases:
        got = [b.shot_id for b in parse_prompt_text(fixture)]
        if got == expected:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> expected {expected}, got {got}")
            ok = False

    blocks = parse_prompt_text(REVISION_FIXTURE)
    body = blocks[0].prompt()
    if body == "revised prompt body":
        print("  ok    selftest: fix annotations stay out of the copied prompt")
    else:
        print(f"  FAIL  selftest: prompt body was {body!r}")
        ok = False
    if len(blocks[0].annotations) == 2:
        print("  ok    selftest: fix annotations are captured for display")
    else:
        print(f"  FAIL  selftest: expected 2 annotations, got {blocks[0].annotations}")
        ok = False

    header_only = parse_prompt_text("# Storyboard: x\n# Generator: flux\n")
    if header_only == []:
        print("  ok    selftest: a file with no shot blocks yields nothing")
    else:
        print(f"  FAIL  selftest: expected no blocks, got {header_only}")
        ok = False

    # The shipped worked run must be readable by this tool, both rounds.
    repo_root = Path(__file__).resolve().parent.parent
    worked = repo_root / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    for rel, expected in (
        ("prompts/round-1/flux.txt", ["shot_01", "shot_02"]),
        ("prompts/round-2/revised-flux.txt", ["shot_02"]),
    ):
        path = worked / rel
        if not path.exists():
            print(f"  FAIL  selftest: bundled fixture missing: {rel}")
            ok = False
            continue
        got = [b.shot_id for b in parse_prompt_file(path)]
        if got == expected:
            print(f"  ok    selftest: bundled {rel} parses")
        else:
            print(f"  FAIL  selftest: bundled {rel} -> expected {expected}, got {got}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Copy a shot prompt from a shotkit prompts file to the clipboard."
    )
    parser.add_argument(
        "file",
        nargs="?",
        type=Path,
        help="Path to a prompt file (e.g. output/prompts/round-1/flux.txt)",
    )
    parser.add_argument(
        "--shot", help="Shot ID to copy (e.g. shot_03). If omitted, prompts interactively."
    )
    parser.add_argument(
        "--list", action="store_true", help="List shots and exit. Does not copy."
    )
    parser.add_argument(
        "--selftest", action="store_true", help="Prove both file shapes parse"
    )
    args = parser.parse_args()

    if args.selftest:
        return selftest()
    if args.file is None:
        parser.error("file is required unless --selftest is given")

    if not args.file.exists():
        print(f"File not found: {args.file}", file=sys.stderr)
        return 1

    blocks = parse_prompt_file(args.file)
    if not blocks:
        print(f"No shot blocks found in {args.file}.", file=sys.stderr)
        print(
            "Expected a comment line naming a shot, e.g. "
            "'# shot_03, beat, timing, framing'.",
            file=sys.stderr,
        )
        return 1

    if args.list:
        list_blocks(blocks)
        return 0

    if args.shot:
        matches = [b for b in blocks if b.shot_id == args.shot]
        if not matches:
            print(f'Shot "{args.shot}" not found in {args.file}.', file=sys.stderr)
            print("Available shots:", file=sys.stderr)
            for block in blocks:
                print(f"  {block.shot_id}", file=sys.stderr)
            return 1
        if len(matches) > 1:
            print(
                f'Shot "{args.shot}" appears {len(matches)} times in {args.file}; '
                f"copying the last block.",
                file=sys.stderr,
            )
        selection = matches[-1]
    else:
        result = select_interactively(blocks)
        if result is None:
            return 1
        selection = result

    body = selection.prompt()
    if copy_to_clipboard(body):
        print(f"Copied {selection.shot_id} prompt to clipboard ({len(body)} chars).")
        for note in selection.annotations:
            print(f"  {note}")
        return 0

    print_clipboard_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/copy-prompt.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/shots-to-html.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/shots-to-html.py`

#!/usr/bin/env python3
"""
Standalone helper: render an output folder into a single preview.html.

Renders skills/storyboard-html-preview/templates/preview.html.tpl, the same
structural template the storyboard-html-preview skill uses, so the two cannot drift.
All interpolated content is HTML-escaped: subjects, rationales, and VO lines are
model-generated prose, and one angle bracket in a rationale used to break the page a
client was looking at.

Two timestamps, deliberately distinct. "Run" is when the storyboard was produced, read
from run.json. "Rendered" is when this page was written. Collapsing them into one
"Generated" date meant re-rendering a preview six months later silently restamped the
run as today.

Usage:
    python tools/shots-to-html.py path/to/output-folder
    python tools/shots-to-html.py path/to/output-folder --out preview.html
    python tools/shots-to-html.py path/to/output-folder --inline-images
    python tools/shots-to-html.py path/to/output-folder --rendered-at 2026-07-30T00:00:00Z
    python tools/shots-to-html.py --selftest
"""

from __future__ import annotations

import argparse
import base64
import sys
from pathlib import Path

from _shotkit import (
    IMAGE_EXTS,
    PALETTE_ROLES,
    REPO_ROOT,
    as_overlay_ids,
    find_frame,
    iso_instant,
    load_json,
    parse_palette,
    parse_typography,
    round_dirs,
    sha256_file,
)
from _template import escape, render

TEMPLATE_DIR = REPO_ROOT / "skills" / "storyboard-html-preview" / "templates"

FALLBACK_BRAND = {
    "bg": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
    "display_font": "Inter",
    "body_font": "Inter",
}

FALLBACK_HEX = {
    "background": "#FFFFFF",
    "ink": "#0F172A",
    "accent": "#3B82F6",
    "muted": "#64748B",
    "rule": "#E2E8F0",
}


def read_template(name: str) -> str:
    return (TEMPLATE_DIR / name).read_text(encoding="utf-8")


def parse_brand_lock(path: Path) -> tuple[dict, list[str]]:
    """
    Pull palette and typography out of a brand-lock.

    Returns (values, warnings). Warnings name every role that fell back to a generic
    default, because a preview that quietly renders in someone else's blue is worse
    than one that tells you the palette did not parse.
    """
    if not path.exists():
        return (dict(FALLBACK_BRAND), [f"brand-lock not found at {path.name}"])

    text = path.read_text(encoding="utf-8")
    palette = parse_palette(text)
    warnings: list[str] = []

    def pick(role: str) -> str:
        # Exact role first, then any role containing it, e.g. "accent (warm)".
        if role in palette and not palette[role].startswith("#_"):
            return palette[role]
        for name, hex_val in palette.items():
            if role in name and not hex_val.startswith("#_"):
                return hex_val
        warnings.append(
            f"palette role '{role}' not found in the brand-lock, using a generic default"
        )
        return FALLBACK_HEX[role]

    values = {
        "bg": pick("background"),
        "ink": pick("ink"),
        "accent": pick("accent"),
        "muted": pick("muted"),
        "rule": pick("rule"),
    }

    fonts = parse_typography(text)
    values["display_font"] = fonts.get("display_font") or FALLBACK_BRAND["display_font"]
    values["body_font"] = fonts.get("body_font") or FALLBACK_BRAND["body_font"]
    for key in ("display_font", "body_font"):
        if not fonts.get(key):
            warnings.append(
                f"brand-lock declares no {key.replace('_', ' ')}, using "
                f"{FALLBACK_BRAND[key]}"
            )

    return (values, warnings)


def aspect_class(aspect: str) -> str:
    return "aspect-" + str(aspect).replace(":", "-")


def encode_image_b64(path: Path) -> str:
    ext = path.suffix.lstrip(".").lower()
    mime = {
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
    }.get(ext, "image/png")
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def frame_for_shot(out_dir: Path, shot: dict) -> tuple[Path | None, str | None]:
    """
    Resolve a shot's frame, preferring what the data says over what the tree implies.

    Order: an accepted entry in shot.assets.generated, then the newest entry there,
    then the frames/round-N path convention, then the legacy generated/ directory.
    Returns (path, note) where note explains a non-obvious pick.
    """
    generated = (shot.get("assets") or {}).get("generated") or []
    accepted = [g for g in generated if g.get("accepted") is True and g.get("path")]
    pool = accepted or [g for g in generated if g.get("path")]
    if pool:
        chosen = max(pool, key=lambda g: g.get("round") or 0)
        path = out_dir / chosen["path"]
        if path.exists():
            note = None
            if chosen.get("sha256"):
                actual = sha256_file(path)
                if actual != chosen["sha256"]:
                    note = "frame has changed since it was recorded in shots.json"
            elif not accepted:
                note = "frame is not marked accepted"
            return (path, note)
        return (None, f"assets names {chosen['path']}, which is missing on disk")

    found = find_frame(out_dir, shot["id"])
    if found is None:
        return (None, None)
    return (found, None)


def latest_verdicts(out_dir: Path) -> dict[str, dict]:
    """Newest verdict per shot, read from the critique tree. Empty when there is none."""
    verdicts: dict[str, dict] = {}
    for round_no, directory in round_dirs(out_dir, "critiques"):
        for path in sorted(directory.glob("*.json")):
            data, err = load_json(path)
            if err or not isinstance(data, dict):
                continue
            shot_id = data.get("shot_id")
            if not shot_id:
                continue
            current = verdicts.get(shot_id)
            if current is None or round_no >= current["round"]:
                verdicts[shot_id] = {
                    "round": round_no,
                    "verdict": data.get("verdict"),
                }
    legacy, err = load_json(out_dir / "critique.json")
    if not err and isinstance(legacy, dict) and legacy.get("shot_id"):
        verdicts.setdefault(
            legacy["shot_id"],
            {"round": legacy.get("round") or 1, "verdict": legacy.get("verdict")},
        )
    return verdicts


def position_class(position) -> str:
    """Named positions map to a CSS class; explicit coordinates fall back to center."""
    if isinstance(position, str):
        return position
    return "center"


def position_label(position) -> str:
    if isinstance(position, dict):
        return f"x{position.get('x')}% y{position.get('y')}%"
    return str(position)


def build_context(out_dir: Path, args) -> tuple[dict, list[str]]:
    warnings: list[str] = []

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        raise SystemExit(f"ERROR: {err}")

    overlays_data, ov_err = load_json(out_dir / "text-overlays.json")
    if ov_err:
        overlays_data = {"overlays": []}
    overlays_by_id = {
        o["id"]: o for o in (overlays_data or {}).get("overlays", []) if o.get("id")
    }

    project = shots_data["project"]
    series = shots_data["series_lock"]
    shots = shots_data["shots"]
    aspect = project["aspect"]

    brand_ref = shots_data.get("brand_lock_ref") or "brand-lock.snapshot.md"
    brand_path = out_dir / brand_ref
    brand, brand_warnings = parse_brand_lock(brand_path)
    warnings.extend(brand_warnings)

    run_doc, run_err = load_json(out_dir / "run.json")
    if run_err or not isinstance(run_doc, dict):
        run_doc = {}
        warnings.append(
            "no run.json in this output tree, so the page cannot state when the run "
            "happened or which inputs it used"
        )

    verdicts = latest_verdicts(out_dir)
    provenance_notes: list[str] = []

    shot_contexts = []
    for shot in shots:
        frame_path, frame_note = frame_for_shot(out_dir, shot)
        if frame_note:
            provenance_notes.append(f"{shot['id']}: {frame_note}")
            warnings.append(f"{shot['id']}: {frame_note}")

        image_path = None
        if frame_path is not None:
            if args.inline_images:
                image_path = encode_image_b64(frame_path)
            else:
                try:
                    image_path = str(frame_path.relative_to(out_dir))
                except ValueError:
                    image_path = frame_path.name

        overlays = []
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            overlay = overlays_by_id.get(oid)
            if overlay is None:
                warnings.append(
                    f"{shot['id']} references overlay {oid}, which is not in "
                    f"text-overlays.json"
                )
                continue
            overlays.append(
                {
                    "id": overlay["id"],
                    "content": overlay.get("content"),
                    "font": overlay.get("font"),
                    "weight": overlay.get("weight"),
                    "color": overlay.get("color"),
                    "size": overlay.get("size"),
                    "position_class": position_class(overlay.get("position")),
                    "position_label": position_label(overlay.get("position")),
                    "enter_at": (overlay.get("enter") or {}).get("at"),
                    "enter_animation": (overlay.get("enter") or {}).get("animation"),
                    "exit_at": (overlay.get("exit") or {}).get("at"),
                    "exit_animation": (overlay.get("exit") or {}).get("animation"),
                }
            )

        verdict = verdicts.get(shot["id"])
        shot_contexts.append(
            {
                "id": shot["id"],
                "id_short": shot["id"].replace("shot_", ""),
                "beat": shot.get("beat"),
                "start": shot.get("start"),
                "end": shot.get("end"),
                "framing": shot.get("framing"),
                "angle": shot.get("angle"),
                "motion": shot.get("motion"),
                "depth_of_field": shot.get("depth_of_field"),
                "subject": shot.get("subject"),
                "vo": shot.get("vo"),
                "rationale": shot.get("rationale"),
                "aspect_class": aspect_class(aspect),
                "has_image": image_path is not None,
                "has_no_image": image_path is None,
                "image_path": image_path,
                "overlays": overlays,
                "has_overlays": bool(overlays),
                "has_verdict": verdict is not None,
                "verdict": (verdict or {}).get("verdict"),
                "verdict_round": (verdict or {}).get("round"),
                "verdict_class": str((verdict or {}).get("verdict", "")).lower(),
            }
        )

    css = (
        read_template("styles.css.tpl")
        .replace("{{BG_COLOR}}", brand["bg"])
        .replace("{{INK_COLOR}}", brand["ink"])
        .replace("{{ACCENT_COLOR}}", brand["accent"])
        .replace("{{MUTED_COLOR}}", brand["muted"])
        .replace("{{RULE_COLOR}}", brand["rule"])
        .replace("{{DISPLAY_FONT}}", brand["display_font"])
        .replace("{{BODY_FONT}}", brand["body_font"])
        .replace("{{INLINE_PRINT_CSS}}", read_template("print.css.tpl"))
    )

    brand_sha = sha256_file(brand_path) if brand_path.exists() else None
    recorded_sha = (run_doc.get("inputs") or {}).get("brand_lock_sha256")
    if brand_sha and recorded_sha and brand_sha != recorded_sha:
        provenance_notes.append(
            "the brand-lock on disk no longer matches the one recorded in run.json"
        )
        warnings.append(
            "brand-lock has changed since the run; this preview does not show the "
            "brand state the frames were produced against"
        )

    context = {
        "PROJECT_TITLE": project["title"],
        "DURATION": project["duration_s"],
        "ASPECT": aspect,
        "FRAMEWORK": project.get("framework") or "not specified",
        "SHOTS_VERSION": shots_data.get("version", "unknown"),
        "BRIEF": None,
        "SERIES_CHARACTER": series["character"],
        "SERIES_ENVIRONMENT": series["environment"],
        "SERIES_LIGHTING": series["lighting"],
        "SERIES_COLOR_GRADE": series["color_grade"],
        "BRAND_LOCK_REF": brand_ref,
        "BRAND_LOCK_SHA_SHORT": brand_sha[:12] if brand_sha else None,
        "RUN_ID": run_doc.get("run_id") or "not recorded",
        "RUN_CREATED_AT": run_doc.get("created_at") or "not recorded",
        "RENDERED_AT": args.rendered_at or iso_instant(),
        "PROVENANCE_NOTE": " ".join(provenance_notes) or None,
        "INLINE_CSS": css,
        "shots": shot_contexts,
    }
    return (context, warnings)


def selftest() -> int:
    """Render the bundled worked run twice and prove the output is byte-identical."""
    worked = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"
    ok = True

    class Args:
        inline_images = False
        rendered_at = "2026-07-30T00:00:00Z"

    first, _ = build_context(worked, Args())
    second, _ = build_context(worked, Args())
    html_a = render(read_template("preview.html.tpl"), first)
    html_b = render(read_template("preview.html.tpl"), second)

    if html_a == html_b:
        print("  ok    selftest: two renders with a pinned timestamp are identical")
    else:
        print("  FAIL  selftest: two renders differed")
        ok = False

    # shot_06 of the shotkit-explainer example carries two overlays. A renderer that
    # resolves only the first drops the second silently, which is what used to happen.
    explainer = (
        REPO_ROOT
        / "skills"
        / "storyboard-architect"
        / "examples"
        / "shotkit-explainer"
    )
    multi_ctx, _ = build_context(explainer, Args())
    shot_06 = next(s for s in multi_ctx["shots"] if s["id"] == "shot_06")
    multi_html = render(read_template("preview.html.tpl"), multi_ctx)

    checks = [
        ("escapes angle brackets", "<script>alert(1)</script>" not in render(
            "{{subject}}", {"subject": "<script>alert(1)</script>"}
        )),
        ("escapes quotes inside a style attribute", "&quot;" in render(
            '<span style="font-family: {{font}};">x</span>', {"font": '"><script>'}
        )),
        ("resolves every overlay on a multi-overlay shot", len(shot_06["overlays"]) == 2),
        (
            "renders every overlay on a multi-overlay shot",
            all(
                escape(overlay["content"]) in multi_html
                for overlay in shot_06["overlays"]
            ),
        ),
        ("states the run date, not the render date, in the header", "2026-07-30T14:23:00Z" in html_a),
        ("labels the render separately", "rendered 2026-07-30T00:00:00Z" in html_a),
        ("shows a verdict badge", "sb-verdict-accept" in html_a),
        ("uses the brand-lock ref from shots.json", 'href="brand-lock.snapshot.md"' in html_a),
        ("carries no unrendered template tags", "{{" not in html_a),
    ]
    for label, passed in checks:
        if passed:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    p = argparse.ArgumentParser(
        description="Render a shotkit output folder into a single preview.html."
    )
    p.add_argument(
        "output_dir",
        nargs="?",
        type=Path,
        help="Directory containing shots.json, text-overlays.json, run.json",
    )
    p.add_argument("--out", default="preview.html", help="Output filename, relative to output_dir")
    p.add_argument(
        "--inline-images",
        action="store_true",
        help="Embed frames as base64 so the file is portable on its own",
    )
    p.add_argument(
        "--rendered-at",
        help="Pin the render timestamp (UTC ISO-8601). Makes output reproducible.",
    )
    p.add_argument("--selftest", action="store_true", help="Prove the renderer's guarantees")
    args = p.parse_args()

    if args.selftest:
        return selftest()
    if args.output_dir is None:
        p.error("output_dir is required unless --selftest is given")

    out_dir: Path = args.output_dir
    if not out_dir.is_dir():
        print(f"ERROR: output directory not found: {out_dir}")
        return 1
    if not (out_dir / "shots.json").exists():
        print(f"ERROR: shots.json not found in {out_dir}")
        return 1

    context, warnings = build_context(out_dir, args)
    html_out = render(read_template("preview.html.tpl"), context)

    out_path = out_dir / args.out
    out_path.write_text(html_out, encoding="utf-8")
    print(f"  wrote {out_path}")
    for warn in warnings:
        print(f"  warn  {warn}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/shots-to-html.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/validate_brand_lock.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/validate_brand_lock.py`

#!/usr/bin/env python3
"""
Validate a brand-lock Markdown file.

Two modes, because a brand-pack and a snapshot are not the same artifact.

A brand-pack (brand-packs/*.md) is a source document. An unfilled template is a legal
brand-pack: that is what a template is for.

A snapshot (brand-lock.snapshot.md, written into an output tree) is a provenance
record. It has to carry the header storyboard-architect promises to write, and if it
still contains template placeholders then the run it governs was built against nothing.
Pass --snapshot to check those extra rules, and --require-configured to reject
placeholders outright.

Required headings (case-insensitive, in any order):
- Identity, Palette, Typography, Mood adjectives, Never list,
  Aspect ratios, Color grade direction, Motion language, Voice rules

Required identity fields (under ## Identity):
- Brand, One-line description, Archetype, Voice posture

Usage:
    python tools/validate_brand_lock.py path/to/brand-lock.md [...]
    python tools/validate_brand_lock.py --snapshot path/to/brand-lock.snapshot.md
    python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
    python tools/validate_brand_lock.py --snapshots            # every bundled snapshot
    python tools/validate_brand_lock.py --selftest
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from _shotkit import (
    ISO_INSTANT_RE,
    PALETTE_ROLES,
    REPO_ROOT,
    is_unconfigured,
    parse_palette,
    parse_snapshot_header,
    parse_typography,
)

REQUIRED_SECTIONS = {
    "identity",
    "palette",
    "typography",
    "mood adjectives",
    "never list",
    "aspect ratios",
    "color grade direction",
    "motion language",
    "voice rules",
}

REQUIRED_IDENTITY_FIELDS = {
    "brand",
    "one-line description",
    "archetype",
    "voice posture",
}

ISO_DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")


def parse_headings(text: str) -> list[tuple[int, str]]:
    """Return list of (level, heading_text_lower) for every Markdown heading."""
    out = []
    for line in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            out.append((len(m.group(1)), m.group(2).strip().lower()))
    return out


def extract_section(text: str, heading_lower: str) -> str:
    """Extract the body of a section by its heading. Empty string if not found."""
    lines = text.splitlines()
    in_section = False
    section_lines: list[str] = []
    section_level: int | None = None
    for line in lines:
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            level = len(m.group(1))
            heading = m.group(2).strip().lower()
            if not in_section:
                if heading == heading_lower:
                    in_section = True
                    section_level = level
                    continue
            else:
                if section_level is not None and level <= section_level:
                    break
        if in_section:
            section_lines.append(line)
    return "\n".join(section_lines)


def check_structure(text: str) -> list[str]:
    errors: list[str] = []
    heading_set = {h for _, h in parse_headings(text)}

    for missing in sorted(REQUIRED_SECTIONS - heading_set):
        errors.append(f"missing section: ## {missing.title()}")

    if "identity" in heading_set:
        identity_body = extract_section(text, "identity").lower()
        for field in sorted(REQUIRED_IDENTITY_FIELDS):
            if field not in identity_body:
                errors.append(f"identity section missing field: '{field}'")

    if "palette" in heading_set:
        palette_body = extract_section(text, "palette")
        if not re.search(r"#[0-9A-Fa-f]{6}|#_{6}", palette_body):
            errors.append(
                "palette section has no hex color values (or template placeholders)"
            )

    return errors


def check_roles(text: str) -> list[str]:
    """
    The palette role names the HTML preview maps onto CSS variables.

    A brand-lock is free to add rows, but a missing role means the preview silently
    renders that slot in a generic default, so it is worth saying out loud.
    """
    warnings: list[str] = []
    palette = parse_palette(text)
    for role in PALETTE_ROLES:
        if not any(role in name for name in palette):
            warnings.append(
                f"palette has no '{role}' role; the HTML preview will fall back to a "
                f"generic color for it"
            )
    return warnings


def check_typography(text: str) -> list[str]:
    warnings: list[str] = []
    fonts = parse_typography(text)
    for key, label in (("display_font", "Display"), ("body_font", "Body")):
        if not fonts.get(key):
            warnings.append(
                f"typography declares no {key.replace('_', ' ')} in a readable form; "
                f'expected ``**{label} font:** `Font Name Weight` `` with the name '
                f"backticked immediately after the label"
            )
    return warnings


def check_snapshot(text: str) -> tuple[list[str], list[str]]:
    """The provenance header storyboard-architect writes into every snapshot."""
    errors: list[str] = []
    warnings: list[str] = []
    header = parse_snapshot_header(text)

    taken = header["snapshot_taken"]
    if not taken:
        errors.append(
            "snapshot is missing its '<!-- snapshot taken: ... -->' header, so nothing "
            "records when this brand state was frozen"
        )
    elif ISO_INSTANT_RE.match(taken):
        pass
    elif ISO_DATE_RE.match(taken):
        warnings.append(
            f"snapshot taken '{taken}' is a date with no time; a full UTC instant "
            f"(YYYY-MM-DDThh:mm:ssZ) is what makes two runs on one day distinguishable"
        )
    else:
        errors.append(
            f"snapshot taken '{taken}' is not ISO-8601; expected YYYY-MM-DDThh:mm:ssZ"
        )

    if not header["source"]:
        errors.append(
            "snapshot is missing its '<!-- source: ... -->' header, so nothing records "
            "which brand-pack it was copied from"
        )

    return errors, warnings


def validate_brand_lock(
    path: Path, snapshot: bool = False, require_configured: bool = False
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    if not path.exists():
        return ([f"file does not exist: {path}"], [])

    text = path.read_text(encoding="utf-8")
    errors = check_structure(text)
    warnings = check_roles(text) + check_typography(text)

    unconfigured = is_unconfigured(text)
    if unconfigured:
        if require_configured or snapshot:
            errors.append(
                "palette still contains template placeholders (#______), so this is an "
                "unfilled template rather than a real brand-lock"
            )
        else:
            warnings.append(
                "palette contains template placeholders (#______); fine for a template, "
                "not for production work"
            )

    if snapshot:
        snap_errors, snap_warnings = check_snapshot(text)
        errors += snap_errors
        warnings += snap_warnings

    return (errors, warnings)


def selftest() -> int:
    ok = True
    minimal = "\n".join(
        [
            "## Identity",
            "**Brand:** X",
            "**One-line description:** Y",
            "**Archetype:** Operator",
            "**Voice posture:** Calm",
            "## Palette",
            "| Role | Hex | Use |",
            "|---|---|---|",
            "| Background | `#FFFFFF` | canvas |",
            "| Ink | `#000000` | text |",
            "| Accent | `#FF0000` | pop |",
            "| Muted | `#888888` | captions |",
            "| Rule | `#EEEEEE` | borders |",
            "## Typography",
            "**Display font:** `Inter Black 900`, headlines",
            "**Body font:** `Inter Medium 500`, body",
            "## Mood adjectives",
            "## Never list",
            "## Aspect ratios",
            "## Color grade direction",
            "## Motion language",
            "## Voice rules",
        ]
    )

    cases = [
        ("a complete brand-lock passes", minimal, {}, False),
        (
            "a snapshot with no header is rejected",
            minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot with a full instant header passes",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            False,
        ),
        (
            "a snapshot with a malformed date is rejected",
            "<!-- snapshot taken: last Tuesday -->\n"
            "<!-- source: brand-packs/x.md -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "a snapshot missing its source header is rejected",
            "<!-- snapshot taken: 2026-05-07T14:23:00Z -->\n" + minimal,
            {"snapshot": True},
            True,
        ),
        (
            "placeholders pass as a template",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {},
            False,
        ),
        (
            "placeholders fail under --require-configured",
            minimal.replace("`#FFFFFF`", "`#______`"),
            {"require_configured": True},
            True,
        ),
        (
            "a missing section is caught",
            minimal.replace("## Voice rules", ""),
            {},
            True,
        ),
    ]

    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        for i, (label, text, kwargs, should_fail) in enumerate(cases):
            path = Path(tmp) / f"case-{i}.md"
            path.write_text(text, encoding="utf-8")
            errors, _ = validate_brand_lock(path, **kwargs)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        warn_path = Path(tmp) / "warn.md"
        warn_path.write_text(
            minimal.replace("| Muted | `#888888` | captions |", ""), encoding="utf-8"
        )
        _, warnings = validate_brand_lock(warn_path)
        if any("no 'muted' role" in w for w in warnings):
            print("  ok    selftest: a missing palette role warns")
        else:
            print(f"  FAIL  selftest: expected a muted-role warning, got {warnings}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_brand_lock.py <path-to-brand-lock.md> [...]")
        print("       python tools/validate_brand_lock.py --snapshot <snapshot.md>")
        print("       python tools/validate_brand_lock.py --require-configured <file>")
        print("       python tools/validate_brand_lock.py --snapshots")
        print("       python tools/validate_brand_lock.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    snapshot = "--snapshot" in args or "--snapshots" in args
    require_configured = "--require-configured" in args

    if "--snapshots" in args:
        paths = sorted(REPO_ROOT.rglob("brand-lock.snapshot.md"))
        if not paths:
            print("ERROR: no brand-lock.snapshot.md files found in the repo")
            return 1
    else:
        paths = [Path(a) for a in args if not a.startswith("--")]
        if not paths:
            print("ERROR: no brand-lock files given")
            return 2

    label = "snapshot" if snapshot else "brand-lock"
    print(f"Validating {len(paths)} {label} file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_brand_lock(path, snapshot, require_configured)
        try:
            shown = path.relative_to(REPO_ROOT)
        except ValueError:
            shown = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {shown}: {warn}")

    print()
    if total_errors == 0:
        print(f"All {label} files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across {label} files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/validate_brand_lock.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/validate_capabilities.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/validate_capabilities.py`

#!/usr/bin/env python3
"""
Validate the generator capability matrix and the adapter prose that defers to it.

_capabilities.json is declared the single source of truth for per-generator limits,
and every adapter .md repeats that rule at the top. A rule nothing checks is a
suggestion: the matrix and the prose drifted in three places before this file grew
the parity checks below.

Five checks:
  1. _capabilities.json validates against capabilities.schema.json.
  2. File parity: every generator id has an adapter .md and every adapter .md has a
     generator entry. Non-adapter markdown is skipped by name, not treated as an
     adapter with a missing entry.
  3. Prose parity: the word budget an adapter .md advertises must fit inside that
     generator's max_prompt_words, and the .md must mention the aspect_param the
     matrix says to send. A generator whose documented parameter name disagrees with
     the matrix will be called with the wrong one, because the matrix wins.
  4. Self-consistency: a notes field must not cite a word count above its own
     max_prompt_words.
  5. Staleness: warns when the matrix or an entry is past the freshness window.

Run from repo root:
    python tools/validate_capabilities.py
    python tools/validate_capabilities.py --selftest
"""

from __future__ import annotations

import re
import sys
from datetime import date

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, load_json

ADAPTERS_DIR = REPO_ROOT / "skills" / "visual-prompt-forge" / "adapters"
CAPS = ADAPTERS_DIR / "_capabilities.json"
CAPS_SCHEMA = ADAPTERS_DIR / "capabilities.schema.json"

# Re-verify the matrix at least this often. Generator models change monthly.
STALE_AFTER_DAYS = 120

# Markdown in adapters/ that documents the directory rather than a generator.
NON_ADAPTER_STEMS = {"README", "_README"}

# "**80-150 words**", "**40-80 words per prompt**", en dash or hyphen.
WORD_RANGE_RE = re.compile(r"\*\*\s*(\d+)\s*[-–—]\s*(\d+)\s+words[^*]*\*\*")
# "**up to 150 words**" or "**150 words**"
WORD_SINGLE_RE = re.compile(r"\*\*\s*(?:up to\s+)?(\d+)\s+words[^*]*\*\*")
# A bare word count inside a notes string, e.g. "Over 100 words underperforms."
NOTES_WORD_RE = re.compile(r"(\d+)\s+words")


def _parse_date(value: str) -> date | None:
    try:
        y, m, d = (int(p) for p in value.split("-"))
        return date(y, m, d)
    except (ValueError, AttributeError):
        return None


def adapter_word_bound(text: str) -> int | None:
    """Highest word count the adapter prose advertises, or None if it names none."""
    bounds: list[int] = []
    for m in WORD_RANGE_RE.finditer(text):
        bounds.append(max(int(m.group(1)), int(m.group(2))))
    if not bounds:
        for m in WORD_SINGLE_RE.finditer(text):
            bounds.append(int(m.group(1)))
    return max(bounds) if bounds else None


def check_prose_parity(entry: dict, text: str) -> tuple[list[str], list[str]]:
    """Compare one adapter .md against its capability entry."""
    errors: list[str] = []
    warnings: list[str] = []
    gid = entry["id"]

    bound = adapter_word_bound(text)
    if bound is None:
        warnings.append(
            f"prose: '{gid}.md' advertises no word budget, so the matrix value "
            f"({entry['max_prompt_words']}) is the only guidance a reader gets"
        )
    elif bound > entry["max_prompt_words"]:
        errors.append(
            f"prose: '{gid}.md' advertises up to {bound} words but the matrix caps "
            f"max_prompt_words at {entry['max_prompt_words']}"
        )

    aspect = entry["aspect_param"]
    if aspect not in text:
        errors.append(
            f"prose: '{gid}.md' never mentions aspect_param '{aspect}'. The matrix "
            f"wins, so the forge will send a parameter the adapter does not document"
        )

    notes = entry.get("notes") or ""
    for m in NOTES_WORD_RE.finditer(notes):
        cited = int(m.group(1))
        if cited > entry["max_prompt_words"]:
            warnings.append(
                f"self-consistency: '{gid}' notes cite {cited} words but "
                f"max_prompt_words is {entry['max_prompt_words']}"
            )

    return errors, warnings


def validate(today: date | None = None) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes."""
    errors: list[str] = []
    warnings: list[str] = []
    today = today or date.today()

    if not CAPS.exists():
        return ([f"missing {CAPS.relative_to(REPO_ROOT)}"], warnings)
    if not CAPS_SCHEMA.exists():
        return ([f"missing {CAPS_SCHEMA.relative_to(REPO_ROOT)}"], warnings)

    caps, caps_err = load_json(CAPS)
    if caps_err:
        return ([f"_capabilities.json: {caps_err}"], warnings)
    schema, schema_err = load_json(CAPS_SCHEMA)
    if schema_err:
        return ([f"capabilities.schema.json: {schema_err}"], warnings)

    # 1. Schema validation
    validator = Draft202012Validator(schema)
    for err in sorted(validator.iter_errors(caps), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # structure-dependent checks need a valid shape

    entries = {g["id"]: g for g in caps["generators"]}
    cap_ids = set(entries)
    md_ids = {
        p.stem
        for p in ADAPTERS_DIR.glob("*.md")
        if p.stem not in NON_ADAPTER_STEMS
    }

    # 2. File parity
    for missing_md in sorted(cap_ids - md_ids):
        errors.append(
            f"parity: capability id '{missing_md}' has no adapter file {missing_md}.md"
        )
    for missing_cap in sorted(md_ids - cap_ids):
        errors.append(
            f"parity: adapter '{missing_cap}.md' has no entry in _capabilities.json"
        )

    # 3 and 4. Prose parity and self-consistency
    for gid in sorted(cap_ids & md_ids):
        text = (ADAPTERS_DIR / f"{gid}.md").read_text(encoding="utf-8")
        prose_errors, prose_warnings = check_prose_parity(entries[gid], text)
        errors.extend(prose_errors)
        warnings.extend(prose_warnings)

    # 5. Staleness
    reviewed = _parse_date(caps.get("matrix_last_reviewed", ""))
    if reviewed is None:
        warnings.append("matrix_last_reviewed is not a parseable date")
    elif (today - reviewed).days > STALE_AFTER_DAYS:
        warnings.append(
            f"matrix_last_reviewed is {(today - reviewed).days} days old "
            f"(> {STALE_AFTER_DAYS}); re-verify the matrix"
        )
    for g in caps["generators"]:
        lv = _parse_date(g.get("last_verified", ""))
        if lv is not None and (today - lv).days > STALE_AFTER_DAYS:
            warnings.append(
                f"'{g['id']}' last_verified is {(today - lv).days} days old "
                f"(> {STALE_AFTER_DAYS}); re-verify this generator"
            )

    return (errors, warnings)


def selftest() -> int:
    ok = True

    cases = [
        (
            "prose advertising more words than the cap is caught",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-300 words** comfortably. Pass `size` alongside.",
            True,
        ),
        (
            "prose inside the cap passes",
            {"id": "x", "max_prompt_words": 250, "aspect_param": "size", "notes": ""},
            "Handles **150-250 words** comfortably. Pass `size` alongside.",
            False,
        ),
        (
            "an undocumented aspect_param is caught",
            {
                "id": "x",
                "max_prompt_words": 120,
                "aspect_param": "aspect_ratio",
                "notes": "",
            },
            "Handles **60-120 words**. Pass `aspectRatio` as a parameter.",
            True,
        ),
        (
            "en dash ranges parse",
            {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": ""},
            "Aim for **40–80 words per prompt** including `--ar`.",
            False,
        ),
    ]
    for label, entry, text, should_error in cases:
        errors, _ = check_prose_parity(entry, text)
        if bool(errors) == should_error:
            print(f"  ok    selftest: {label}")
        else:
            print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
            ok = False

    entry = {"id": "x", "max_prompt_words": 80, "aspect_param": "--ar", "notes": "Over 100 words underperforms."}
    _, warnings = check_prose_parity(entry, "Aim for **40-80 words** with `--ar`.")
    if any("self-consistency" in w for w in warnings):
        print("  ok    selftest: notes citing more words than the cap are flagged")
    else:
        print(f"  FAIL  selftest: expected a self-consistency warning, got {warnings}")
        ok = False

    if adapter_word_bound("no budget stated here") is None:
        print("  ok    selftest: prose with no word budget reports none")
    else:
        print("  FAIL  selftest: found a word budget where there is none")
        ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    if "--selftest" in sys.argv[1:]:
        return selftest()

    print(f"Validating capability matrix: {CAPS.relative_to(REPO_ROOT)}")
    print()

    errors, warnings = validate()

    for w in warnings:
        print(f"  warn  {w}")
    if warnings:
        print()

    if not errors:
        caps, _ = load_json(CAPS)
        count = len((caps or {}).get("generators", []))
        print(f"Capability matrix valid ({count} generators, {len(warnings)} warning(s)).")
        return 0

    for e in errors:
        print(f"  FAIL  {e}")
    print()
    print(f"FAILED: {len(errors)} error(s) in capability matrix.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/validate_capabilities.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/validate_critique.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/validate_critique.py`

#!/usr/bin/env python3
"""
Validate critique.json files against the critique schema AND the gating invariant.

Schema validation alone is not enough: JSON Schema cannot express the cross-field
rules that make a verdict trustworthy. This validator adds them.

Gating invariant (the reason structured output exists):
  - Any 'blocking' issue      => verdict MUST be REJECT.
  - Three or more 'major'     => verdict MUST be REJECT.
  - One or two 'major'        => verdict MUST NOT be ACCEPT (caps at REVISE).
  - Therefore ACCEPT requires zero major/blocking issues.

Provenance invariant (version 1.1 and later):
  - A hash without its path, or a path without its hash, is not a reference.
  - image_ref must be present and non-null: a verdict about no image is not a verdict.
  - HIGH confidence requires the shot spec, the brand-lock, and the prompt to all be
    identified. The critic's own rubric says HIGH means all three were available.
  - generator, when named, must be an id in the capability matrix.

A critique that claims ACCEPT while carrying a blocking issue passes the schema but
FAILS here. So does a 1.1 critique that records an image hash and no image path.

Usage:
    python tools/validate_critique.py path/to/critique.json [...]
    python tools/validate_critique.py path/to/output-dir      # every critique in the tree
    python tools/validate_critique.py --examples              # bundled fixtures
    python tools/validate_critique.py --selftest              # prove the gates fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import REPO_ROOT, capability_ids, critique_paths, load_json

SCHEMA_PATH = (
    REPO_ROOT / "skills" / "visual-asset-critic" / "templates" / "critique.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "visual-asset-critic" / "examples"

MAJOR_REJECT_THRESHOLD = 3

# Pairs that must be present or absent together.
REF_HASH_PAIRS = (
    ("image_ref", "image_sha256"),
    ("brand_lock_ref", "brand_lock_sha256"),
    ("prompt_ref", "prompt_sha256"),
)


def _load_schema() -> dict:
    data, err = load_json(SCHEMA_PATH)
    if err:
        raise RuntimeError(err)
    return data


def check_gating(data: dict) -> list[str]:
    """The severity-to-verdict invariant. Assumes data is schema-valid."""
    errors: list[str] = []
    verdict = data.get("verdict")
    severities = [issue.get("severity") for issue in data.get("issues", [])]
    majors = severities.count("major")

    if "blocking" in severities and verdict != "REJECT":
        errors.append(
            f"gating: a 'blocking' issue requires verdict REJECT, got '{verdict}'"
        )
    if majors >= MAJOR_REJECT_THRESHOLD and verdict != "REJECT":
        errors.append(
            f"gating: {majors} 'major' issues require verdict REJECT "
            f"(threshold {MAJOR_REJECT_THRESHOLD}), got '{verdict}'"
        )
    if majors and verdict == "ACCEPT":
        errors.append(
            "gating: a 'major' issue caps the verdict at REVISE; ACCEPT is not allowed"
        )
    return errors


def check_provenance(data: dict, known_generators: set[str]) -> list[str]:
    """The provenance invariant. Only applies from version 1.1."""
    errors: list[str] = []
    if data.get("version") == "1.0":
        return errors

    for ref_key, hash_key in REF_HASH_PAIRS:
        ref, digest = data.get(ref_key), data.get(hash_key)
        if ref and not digest:
            errors.append(f"provenance: {ref_key} is set but {hash_key} is null")
        if digest and not ref:
            errors.append(f"provenance: {hash_key} is set but {ref_key} is null")

    if not data.get("image_ref"):
        errors.append(
            "provenance: image_ref is null; a verdict that names no image cannot be audited"
        )

    if data.get("confidence") == "HIGH":
        missing = [
            key
            for key in ("shot_id", "brand_lock_ref", "prompt_ref")
            if not data.get(key)
        ]
        if missing:
            errors.append(
                "provenance: confidence HIGH requires "
                + ", ".join(missing)
                + " to be identified"
            )

    generator = data.get("generator")
    if generator and known_generators and generator not in known_generators:
        errors.append(
            f"provenance: generator '{generator}' is not an id in the capability matrix"
        )

    return errors


def validate_doc(
    data: dict,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Empty errors means it passes every gate."""
    errors: list[str] = []
    warnings: list[str] = []

    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        errors.append(f"schema: {loc}: {err.message}")
    if errors:
        return (errors, warnings)  # the gates assume a schema-valid shape

    errors += check_gating(data)
    errors += check_provenance(data, known_generators or set())

    if data.get("version") == "1.0":
        warnings.append(
            "version 1.0 carries no run id, no round, and no content hashes, so the "
            "verdict cannot be tied to the bytes it reviewed; re-emit as 1.1"
        )

    return (errors, warnings)


def validate_path(
    path: Path,
    validator: Draft202012Validator,
    known_generators: set[str] | None = None,
) -> tuple[list[str], list[str]]:
    data, err = load_json(path)
    if err:
        return ([err], [])
    if not isinstance(data, dict):
        return ([f"top level is not an object: {path}"], [])
    return validate_doc(data, validator, known_generators)


def _selftest_cases() -> list[tuple[str, dict, bool]]:
    """(label, document, should_pass)."""
    base_provenance = {
        "run_id": "20260730T142300Z-9f2c1ab4",
        "round": 1,
        "created_at": "2026-07-30T14:31:00Z",
        "shot_id": "shot_03",
        "brand_lock_ref": "brand-lock.snapshot.md",
        "brand_lock_sha256": "a" * 64,
        "image_ref": "frames/round-1/shot_03.png",
        "image_sha256": "b" * 64,
        "prompt_ref": "prompts/round-1/flux.txt",
        "prompt_sha256": "c" * 64,
        "generator": "flux",
        "model_version": "2 Pro",
        "seed": 12345,
    }
    major_issue = {
        "layer": "Series Lock",
        "severity": "major",
        "note": "hair mismatch",
        "fix_type": "prompt-level",
        "fix": "add 'salt-and-pepper hair' to the anchor",
    }
    blocking_issue = {
        "layer": "Brand Lock",
        "severity": "blocking",
        "note": "off-palette",
        "fix_type": "re-roll",
        "fix": "re-roll with palette anchor",
    }

    def doc(**overrides) -> dict:
        out = {
            "version": "1.1",
            **base_provenance,
            "verdict": "REVISE",
            "confidence": "HIGH",
            "issues": [dict(major_issue)],
        }
        out.update(overrides)
        return out

    return [
        ("clean REVISE with full provenance passes", doc(), True),
        (
            "legacy 1.0 document still validates",
            {
                "version": "1.0",
                "verdict": "REVISE",
                "confidence": "HIGH",
                "issues": [dict(major_issue)],
            },
            True,
        ),
        (
            "ACCEPT with a blocking issue is rejected",
            doc(verdict="ACCEPT", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "REVISE with a blocking issue is rejected",
            doc(verdict="REVISE", issues=[dict(blocking_issue)]),
            False,
        ),
        (
            "ACCEPT with a major issue is rejected",
            doc(verdict="ACCEPT"),
            False,
        ),
        (
            "three major issues cannot stay at REVISE",
            doc(verdict="REVISE", issues=[dict(major_issue) for _ in range(3)]),
            False,
        ),
        (
            "three major issues at REJECT pass",
            doc(verdict="REJECT", issues=[dict(major_issue) for _ in range(3)]),
            True,
        ),
        (
            "1.1 with a hash and no path is rejected",
            doc(prompt_ref=None),
            False,
        ),
        (
            "1.1 with a path and no hash is rejected",
            doc(prompt_sha256=None),
            False,
        ),
        (
            "1.1 with no image_ref is rejected",
            doc(image_ref=None, image_sha256=None),
            False,
        ),
        (
            "HIGH confidence with no prompt identified is rejected",
            doc(prompt_ref=None, prompt_sha256=None),
            False,
        ),
        (
            "MEDIUM confidence with no prompt identified passes",
            doc(confidence="MEDIUM", prompt_ref=None, prompt_sha256=None),
            True,
        ),
        (
            "unknown generator id is rejected",
            doc(generator="runway-sora"),
            False,
        ),
        (
            "1.1 missing a required provenance field is rejected",
            {
                "version": "1.1",
                "verdict": "ACCEPT",
                "confidence": "LOW",
                "issues": [],
            },
            False,
        ),
    ]


def selftest() -> int:
    validator = Draft202012Validator(_load_schema())
    known = capability_ids() or {"flux"}
    ok = True

    for label, document, should_pass in _selftest_cases():
        errors, _ = validate_doc(document, validator, known)
        passed = not errors
        if passed == should_pass:
            print(f"  ok    selftest: {label}")
        else:
            detail = errors if errors else ["(no errors raised)"]
            print(f"  FAIL  selftest: {label} -> {detail}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def _collect(args: list[str]) -> list[Path] | None:
    if "--examples" in args:
        found = sorted(EXAMPLES_DIR.glob("*.json"))
        found += critique_paths(EXAMPLES_DIR / "worked-run")
        return found or None

    paths: list[Path] = []
    for raw in args:
        path = Path(raw)
        if path.is_dir():
            found = critique_paths(path)
            if not found:
                print(f"  FAIL  {raw}")
                print("        - no critique files found in this output tree")
                return None
            paths.extend(found)
        else:
            paths.append(path)
    return paths


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_critique.py <critique.json|output-dir> [...]")
        print("       python tools/validate_critique.py --examples")
        print("       python tools/validate_critique.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    if not SCHEMA_PATH.exists():
        print(f"ERROR: schema not found at {SCHEMA_PATH}")
        return 1

    paths = _collect(args)
    if paths is None:
        return 1

    validator = Draft202012Validator(_load_schema())
    known = capability_ids()

    print(f"Validating {len(paths)} critique file(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for path in paths:
        errors, warnings = validate_path(path, validator, known)
        try:
            label = path.relative_to(REPO_ROOT)
        except ValueError:
            label = path
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {label}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {label}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {label}: {warn}")

    print()
    if total_errors == 0:
        print(f"All critiques valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across critiques.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/validate_critique.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/validate_prompts.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/validate_prompts.py`

#!/usr/bin/env python3
"""
Validate the prompt files visual-prompt-forge writes.

The forge documents four hard rules and a quality-bar checklist, and until this file
existed every one of them was enforced by a model remembering to check its own work.
That is not a small gap. Rule 3, series_lock anchors appear verbatim in every prompt,
is the rule that produces visual consistency across a series, and it is also the
easiest one in the kit to break by paraphrasing while writing fluent prose. A careful
pass over a seven-shot storyboard drifted on it seven times out of seven with every
other validator green.

Checks:
  1. The header block names the storyboard, generator, aspect, brand-lock, run, round.
  2. The generator is an id in the capability matrix.
  3. The header aspect matches project.aspect in shots.json.
  4. No shot's prompt exceeds that generator's max_prompt_words ceiling.
  5. Every shot block names a shot that exists. A full pass covers every shot; a
     revision file covers a subset.
  6. Rule 1: no on-screen text content appears in any prompt. Text is composited.
  7. Rule 3: series_lock environment, lighting, and color_grade appear verbatim.
     The character anchor is a warning, because a shot with no person in it can
     legitimately omit it.
  8. No duplicate shot blocks in one file.
  9. Shot logic: point of view, direction of travel, scale contradictions, two people at
     one frame edge, handedness in two-handed interactions, brand marks in frame, and a
     clear frame centre on crossing shots.

Usage:
    python tools/validate_prompts.py <output-dir>
    python tools/validate_prompts.py <output-dir>/prompts/round-1/flux.txt
    python tools/validate_prompts.py --examples
    python tools/validate_prompts.py --selftest
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from _shotkit import REPO_ROOT, capability_map, load_json

WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"

SHOT_HEADER = re.compile(
    r"^#\s*(?:revision\s+of\s+)?(shot_\d{2,3})\b(.*)$", re.IGNORECASE
)
COMMENT = re.compile(r"^\s*#")

HEADER_FIELDS = ("Storyboard", "Generator", "Aspect", "Brand-lock", "Run", "Round")

# series_lock keys that describe every frame, so every prompt has to carry them.
UNIVERSAL_ANCHORS = ("environment", "lighting", "color_grade")


def parse_blocks(text: str) -> tuple[dict[str, str], list[tuple[str, str]]]:
    """Return (header fields, [(shot_id, prompt body)])."""
    header: dict[str, str] = {}
    blocks: list[tuple[str, list[str]]] = []
    current: list[str] | None = None

    for line in text.splitlines():
        m = SHOT_HEADER.match(line)
        if m:
            current = []
            blocks.append((m.group(1), current))
            continue
        if current is None:
            hm = re.match(r"^#\s*([A-Za-z-]+)\s*:\s*(.+?)\s*$", line)
            if hm:
                header[hm.group(1).strip()] = hm.group(2).strip()
            continue
        if not COMMENT.match(line):
            current.append(line)

    return (header, [(sid, "\n".join(b).strip()) for sid, b in blocks])


def _is_fixture(body: str) -> bool:
    """A stub body is too short to carry real shot direction; logic checks warn, not fail."""
    return len(body.split()) < 60


def check_file(
    path: Path, shots_data: dict, caps: dict[str, dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    label = path.name

    text = path.read_text(encoding="utf-8")
    header, blocks = parse_blocks(text)

    if not blocks:
        return ([f"{label}: no shot blocks found; expected '# shot_NN, ...' lines"], warnings)

    for field in HEADER_FIELDS:
        if field not in header:
            warnings.append(f"{label}: header is missing '# {field}:'")

    generator = header.get("Generator", "").split()[0] if header.get("Generator") else None
    entry = caps.get(generator) if generator else None
    if generator and entry is None:
        errors.append(
            f"{label}: header names generator '{generator}', which is not an id in "
            f"_capabilities.json"
        )
    if generator is None:
        # Fall back to the filename: flux.txt or revised-flux.txt
        stem = path.stem.replace("revised-", "")
        entry = caps.get(stem)
        if entry:
            warnings.append(
                f"{label}: no '# Generator:' header, inferred '{stem}' from the filename"
            )

    project = shots_data.get("project", {})
    if "Aspect" in header and header["Aspect"] != project.get("aspect"):
        errors.append(
            f"{label}: header aspect '{header['Aspect']}' does not match "
            f"project.aspect '{project.get('aspect')}'"
        )

    shot_ids = [s["id"] for s in shots_data.get("shots", [])]
    by_id = {s["id"]: s for s in shots_data.get("shots", [])}
    series = shots_data.get("series_lock", {})

    seen: set[str] = set()
    for sid, body in blocks:
        if sid in seen:
            errors.append(f"{label}: {sid} appears in more than one block")
        seen.add(sid)
        if sid not in by_id:
            errors.append(f"{label}: names {sid}, which is not in shots.json")
            continue
        if not body:
            errors.append(f"{label}: {sid} has a header but no prompt body")
            continue

        if entry:
            words = len(body.split())
            ceiling = entry["max_prompt_words"]
            if words > ceiling:
                errors.append(
                    f"{label}: {sid} is {words} words, over the "
                    f"{entry['id']} ceiling of {ceiling}"
                )

        low = body.lower()
        for key in UNIVERSAL_ANCHORS:
            value = series.get(key)
            if value and value.lower() not in low:
                errors.append(
                    f"{label}: {sid} does not carry the series_lock {key} verbatim. "
                    f"Paraphrasing an anchor is what makes shots stop matching each other"
                )
        character = series.get("character")
        if character and character.lower() not in low:
            warnings.append(
                f"{label}: {sid} does not carry the series_lock character verbatim; "
                f"correct only if this shot has no person in it"
            )

    # Rule 1: text is composited, never described.
    overlays_path = path.parent.parent.parent / "text-overlays.json"
    overlays_data, ov_err = load_json(overlays_path)
    if not ov_err and isinstance(overlays_data, dict):
        for overlay in overlays_data.get("overlays", []):
            content = overlay.get("content")
            if not isinstance(content, str) or len(content) < 8:
                continue
            needle = content.lower().rstrip(".!?")
            for sid, body in blocks:
                if needle in body.lower():
                    errors.append(
                        f"{label}: {sid} contains the copy of overlay "
                        f"{overlay.get('id')} verbatim. On-screen text is composited, "
                        f"never put in an image prompt"
                    )

    # Rule 9: shot logic. Each check here is a failure a director had to catch by hand.
    for sid, body in blocks:
        low_b = body.lower()
        logic = [
            (not any(k in low_b for k in ["profile", "facing camera", "facing frame",
                                          "from the side", "rear", "three quarter",
                                          "seen from", "overhead", "top down"]),
             "does not declare a point of view (profile / frontal / side)"),
            (not any(k in low_b for k in ["left to right", "right to left", "frame right",
                                          "frame left", "towards the camera", "toward the camera",
                                          "away from the camera", "no person", "empty", "still",
                                          "static camera", "locked off"]),
             "does not declare a direction of travel"),
            (any(k in low_b for k in ["deeper into", "walks away", "further into",
                                      "towards the back", "receding"])
             and any(k in low_b for k in ["same size", "same height", "two thirds of frame"]),
             "is impossible: the subject moves away from camera and keeps the same size in frame"),
            ((low_b.count("right edge") >= 2 or low_b.count("left edge") >= 2)
             and "second man" in low_b,
             "puts two people at the same frame edge"),
            (any(k in low_b for k in ["high five", "palm", "slap hands", "hands meet"])
             and not ("left hand" in low_b and "right hand" in low_b),
             "describes a two-handed interaction without naming which hand each person raises"),
            (any(k in low_b for k in ["logo", "lettering", "brand wall"])
             and not any(k in low_b for k in ["no logo", "no lettering", "bare", "plain wall"]),
             "puts brand marks in frame; logos are composited in post, never generated"),
            ((("crossing" in low_b or "crosses the" in low_b)
              or "anchor" in low_b or True)
             and not any(k in low_b for k in ["left third", "right third", "centre third",
                                              "no person", "empty", "black frame"]),
             "does not state which third of the frame the body occupies; a body on the centre "
             "line is split in half by the mask"),
            (("crossing" in low_b or "crosses the" in low_b)
             and not any(k in low_b for k in ["centre stays", "centre strip", "clear of any object",
                                              "away from the centre", "far from the centre"]),
             "is a crossing shot but does not declare the centre of frame clear for the mask"),
        ]
        for failed, reason in logic:
            if failed:
                if _is_fixture(body):
                    warnings.append(f"{label}: {sid} {reason}")
                else:
                    errors.append(f"{label}: {sid} {reason}")

    is_revision = path.name.startswith("revised-")
    if not is_revision:
        for missing in [s for s in shot_ids if s not in seen]:
            errors.append(f"{label}: full pass is missing a block for {missing}")

    return (errors, warnings)


def collect_prompt_files(target: Path) -> tuple[Path | None, list[Path]]:
    """Return (output_dir, prompt files). Accepts an output dir or a single file."""
    if target.is_file():
        # prompts/round-N/<file>.txt  ->  output dir is three levels up
        return (target.parent.parent.parent, [target])
    if target.is_dir():
        found = sorted(target.glob("prompts/round-*/*.txt"))
        if not found:
            found = sorted(target.glob("prompts/*.txt"))  # pre-3.0.0 flat layout
        return (target, found)
    return (None, [])


def validate_target(target: Path) -> tuple[list[str], list[str]]:
    out_dir, files = collect_prompt_files(target)
    if out_dir is None:
        return ([f"not a file or directory: {target}"], [])
    if not files:
        return ([f"no prompt files found under {target}"], [])

    shots_data, err = load_json(out_dir / "shots.json")
    if err:
        return ([f"cannot read shots.json next to the prompts: {err}"], [])

    caps = capability_map()
    errors: list[str] = []
    warnings: list[str] = []
    for path in files:
        e, w = check_file(path, shots_data, caps)
        errors += e
        warnings += w
    return (errors, warnings)


SHOTS_FIXTURE = {
    "project": {"aspect": "9:16"},
    "series_lock": {
        "character": "founder in a navy crewneck",
        "environment": "minimalist home office, oak desk",
        "lighting": "soft window light from camera-left",
        "color_grade": "warm filmic with muted teal shadows",
    },
    "shots": [{"id": "shot_01"}, {"id": "shot_02"}],
}


def _fixture(body_01: str, body_02: str | None = None, aspect: str = "9:16") -> str:
    out = [
        "# Storyboard: Fixture",
        "# Generator: flux",
        f"# Aspect: {aspect}",
        "# Brand-lock: brand-lock.snapshot.md",
        "# Run: 20260730T180000Z-7c41e0a9",
        "# Round: 1",
        "",
        "# shot_01, hook, 0.0-2.0s, MCU eye-level static",
        body_01,
        "",
    ]
    if body_02 is not None:
        out += ["# shot_02, pain, 2.0-6.0s, MS eye-level push", body_02, ""]
    return "\n".join(out)


def selftest() -> int:
    import tempfile

    ok = True
    sl = SHOTS_FIXTURE["series_lock"]
    good = (
        f"Medium close-up of a {sl['character']}. {sl['environment']}. "
        f"{sl['lighting']}. {sl['color_grade']}. Photorealistic."
    )
    drifted = (
        "Medium close-up of a founder in a navy sweater. A minimal home office with "
        "an oak desk. Soft light from the left. Warm grade with teal shadows."
    )

    cases = [
        ("a compliant full pass passes", _fixture(good, good), False),
        ("a paraphrased anchor is caught", _fixture(drifted, good), True),
        ("a missing shot in a full pass is caught", _fixture(good), True),
        ("an aspect mismatch is caught", _fixture(good, good, aspect="16:9"), True),
        (
            "an over-ceiling prompt is caught",
            _fixture(good + " extra" * 200, good),
            True,
        ),
        (
            "an unknown shot id is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_09,"),
            True,
        ),
        (
            "a duplicate shot block is caught",
            _fixture(good, good).replace("# shot_02,", "# shot_01,"),
            True,
        ),
        (
            "an empty prompt body is caught",
            _fixture(good, ""),
            True,
        ),
    ]

    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "output"
        (out / "prompts" / "round-1").mkdir(parents=True)
        (out / "shots.json").write_text(json.dumps(SHOTS_FIXTURE))
        caps = capability_map()
        for label, text, should_fail in cases:
            p = out / "prompts" / "round-1" / "flux.txt"
            p.write_text(text)
            errors, _ = check_file(p, SHOTS_FIXTURE, caps)
            if bool(errors) == should_fail:
                print(f"  ok    selftest: {label}")
            else:
                print(f"  FAIL  selftest: {label} -> {errors or '(no errors)'}")
                ok = False

        # Rule 1: overlay copy leaking into a prompt.
        (out / "text-overlays.json").write_text(
            json.dumps(
                {
                    "version": "1.0",
                    "overlays": [
                        {"id": "text_01", "content": "You are the bottleneck."}
                    ],
                }
            )
        )
        p = out / "prompts" / "round-1" / "flux.txt"
        p.write_text(_fixture(good + " The words You are the bottleneck appear.", good))
        errors, _ = check_file(p, SHOTS_FIXTURE, caps)
        if any("composited" in e for e in errors):
            print("  ok    selftest: overlay copy inside a prompt is caught")
        else:
            print(f"  FAIL  selftest: overlay leak not caught -> {errors}")
            ok = False

        # A revision file covers a subset, and that is not an error.
        rev = out / "prompts" / "round-2"
        rev.mkdir()
        rp = rev / "revised-flux.txt"
        rp.write_text(_fixture(good))
        errors, _ = check_file(rp, SHOTS_FIXTURE, caps)
        if not errors:
            print("  ok    selftest: a revision file may cover a subset of shots")
        else:
            print(f"  FAIL  selftest: revision subset flagged -> {errors}")
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_prompts.py <output-dir|prompt-file> [...]")
        print("       python tools/validate_prompts.py --examples")
        print("       python tools/validate_prompts.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    targets = [WORKED_RUN] if "--examples" in args else [Path(a) for a in args]

    print(f"Validating prompt files for {len(targets)} target(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for target in targets:
        errors, warnings = validate_target(target)
        try:
            shown = target.relative_to(REPO_ROOT)
        except ValueError:
            shown = target
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {shown}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {shown}")
            for e in errors:
                print(f"        - {e}")
        for w in warnings:
            print(f"  warn  {shown}: {w}")

    print()
    if total_errors == 0:
        print(f"All prompt files valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across prompt files.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/validate_prompts.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/validate_provenance.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/validate_provenance.py`

#!/usr/bin/env python3
"""
Validate the provenance chain of a shotkit output tree.

This is the tool that answers "does this verdict still describe the file it reviewed."
Paths lie: a filename says nothing about the bytes behind it, so a frame regenerated
after its critique leaves every path reference intact and every claim about it wrong.
Content hashes are what make that detectable, and this walks them.

Checks:
  1. run.json validates against run.schema.json, and its run_id agrees with created_at.
  2. Rounds are numbered from 1 with no gaps and no duplicates.
  3. Every input hash in run.json still matches the file on disk. A brand-lock edited
     mid-project fails here instead of silently repointing the project's history.
  4. Every prompt hash recorded in run.json still matches the file on disk.
  5. Every critique validates against the schema and the gating invariant.
  6. Every critique's run_id matches run.json.
  7. Every critique's image, prompt, and brand-lock hashes match the files on disk.
  8. No two critiques cover the same shot in the same round. Two operators writing the
     same verdict path is a real conflict, not a silent overwrite.
  9. Every frame on disk has a critique for its round. An unreviewed frame is the
     failure mode where a re-roll slips past the gate on a stale ACCEPT.
 10. Every shot has at least one critique, and the latest verdict per shot is reported.
 11. Shots recorded as post_only still owe compositing work.

Exit status is 0 when the chain is intact. Add --require-accept to also demand that
every shot's latest verdict is ACCEPT, which is the pipeline stop condition made
executable rather than described.

Usage:
    python tools/validate_provenance.py <output-dir> [...]
    python tools/validate_provenance.py <output-dir> --require-accept
    python tools/validate_provenance.py <output-dir> --json
    python tools/validate_provenance.py --examples
    python tools/validate_provenance.py --selftest
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    IMAGE_EXTS,
    REPO_ROOT,
    critique_paths,
    load_json,
    round_dirs,
    run_id_timestamp,
    sha256_file,
)
from validate_critique import _load_schema as _load_critique_schema
from validate_critique import validate_doc as validate_critique_doc

RUN_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "run.schema.json"
)
WORKED_RUN = REPO_ROOT / "skills" / "visual-asset-critic" / "examples" / "worked-run"


class Report:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.shots: dict[str, dict] = {}
        self.rounds_seen: list[int] = []
        # (path, recorded, actual) -> the labels that referenced it. One edited file is
        # one problem, even when twenty critiques all hash it.
        self.hash_failures: dict[tuple[str, str, str], list[str]] = {}

    def as_dict(self) -> dict:
        return {
            "output_dir": str(self.output_dir),
            "ok": not self.errors,
            "errors": self.errors,
            "warnings": self.warnings,
            "rounds": self.rounds_seen,
            "shots": self.shots,
        }


def _check_hash(
    report: Report, label: str, rel: str | None, expected: str | None
) -> None:
    """Compare a recorded hash against the file currently on disk."""
    if not rel or not expected:
        return
    path = report.output_dir / rel
    if not path.exists():
        report.errors.append(f"{label}: '{rel}' is referenced but missing on disk")
        return
    actual = sha256_file(path)
    if actual == expected:
        return
    report.hash_failures.setdefault((rel, expected, actual), []).append(label)


def _finalize_hash_failures(report: Report) -> None:
    """Turn collected hash mismatches into one error per distinct mismatch."""
    for (rel, expected, actual), labels in report.hash_failures.items():
        # Print both hashes in full. Truncating them meant a single mistyped character
        # at the end produced a message showing two identical-looking strings and
        # asserting they differed, which is the least useful moment to be imprecise: a
        # hand-authored run.json is exactly where typos come from.
        detail = (
            f"'{rel}' does not match the hash recorded for it\n"
            f"          recorded: {expected}\n"
            f"          on disk:  {actual}"
        )
        if len(expected) != 64:
            detail += (
                f"\n          the recorded value is {len(expected)} characters, not 64, "
                f"so it is malformed rather than stale"
            )
        elif sum(a != b for a, b in zip(expected, actual)) <= 2:
            detail += (
                "\n          they differ in one or two characters, which usually means "
                "a typo in the recorded hash rather than a changed file"
            )
        if len(labels) == 1:
            detail += f"\n          referenced by: {labels[0]}"
        else:
            shown = ", ".join(labels[:3])
            more = f", and {len(labels) - 3} more" if len(labels) > 3 else ""
            detail += (
                f"\n          referenced by {len(labels)} places: {shown}{more}"
            )
        report.errors.append(detail)


def check_run_doc(report: Report) -> dict | None:
    run_path = report.output_dir / "run.json"
    if not run_path.exists():
        report.errors.append(
            "run.json is missing, so nothing pins this output to its inputs. A tree "
            "written before 3.0.0 has no provenance to check: write a run.json "
            "(schema at skills/storyboard-architect/templates/run.schema.json) or "
            "re-run storyboard-architect. This is reported as an error rather than a "
            "warning so a pipeline gate cannot pass an unauditable tree"
        )
        return None

    run_doc, err = load_json(run_path)
    if err:
        report.errors.append(f"run.json: {err}")
        return None

    schema, s_err = load_json(RUN_SCHEMA)
    if s_err:
        report.errors.append(f"run.schema.json: {s_err}")
        return None

    validator = Draft202012Validator(schema)
    for e in sorted(validator.iter_errors(run_doc), key=lambda x: list(x.path)):
        loc = "/".join(str(p) for p in e.path) or "(root)"
        report.errors.append(f"run.json schema: {loc}: {e.message}")
    if report.errors:
        return None

    stamp = run_id_timestamp(run_doc["run_id"])
    expected = run_doc["created_at"].replace("-", "").replace(":", "")
    if stamp != expected:
        report.errors.append(
            f"run.json: run_id timestamp '{stamp}' disagrees with "
            f"created_at '{run_doc['created_at']}'"
        )

    if run_doc["inputs"].get("brand_lock_configured") is False:
        report.warnings.append(
            "run.json: brand_lock_configured is false, so this run was built against "
            "an unfilled template rather than a real brand-lock"
        )

    inputs = run_doc["inputs"]
    _check_hash(report, "inputs", inputs.get("shots_ref"), inputs.get("shots_sha256"))
    _check_hash(
        report,
        "inputs",
        inputs.get("text_overlays_ref"),
        inputs.get("text_overlays_sha256"),
    )
    _check_hash(
        report, "inputs", inputs.get("brand_lock_ref"), inputs.get("brand_lock_sha256")
    )

    numbers = [r["round"] for r in run_doc.get("rounds", [])]
    report.rounds_seen = sorted(numbers)
    if len(numbers) != len(set(numbers)):
        report.errors.append("run.json: duplicate round numbers")
    if numbers and sorted(numbers) != list(range(1, max(numbers) + 1)):
        report.errors.append(
            f"run.json: rounds must run 1..N with no gaps, got {sorted(numbers)}"
        )

    for rnd in run_doc.get("rounds", []):
        for prompt in rnd.get("prompts", []):
            _check_hash(
                report,
                f"round {rnd['round']} prompt",
                prompt.get("ref"),
                prompt.get("sha256"),
            )
        for shot_id in rnd.get("post_only_shots", []) or []:
            report.warnings.append(
                f"round {rnd['round']}: {shot_id} is recorded as post-only, so it owes "
                f"compositing work that no prompt or frame will show"
            )

    return run_doc


def _round_of(path: Path, output_dir: Path, data: dict) -> int:
    """
    Which round a critique belongs to.

    The directory name wins, because that is the addressing scheme. A legacy critique
    sitting at the output root has no directory to read, so fall back to its own
    `round` field and then to 1.
    """
    try:
        parent = path.relative_to(output_dir).parent.name
    except ValueError:
        parent = ""
    if parent.startswith("round-") and parent[len("round-"):].isdigit():
        return int(parent[len("round-"):])
    declared = data.get("round")
    return declared if isinstance(declared, int) and declared >= 1 else 1


def check_critiques(report: Report, run_doc: dict | None) -> None:
    critique_validator = Draft202012Validator(_load_critique_schema())
    seen: dict[tuple[str, int], Path] = {}

    # critique_paths() is the one definition of "where critiques live", shared with
    # validate_critique.py and shots-to-html.py. Walking the round directories directly
    # meant this tool ignored a legacy root critique.json that the other two read, so
    # the preview showed a verdict badge for a shot this tool called unreviewed.
    for path in critique_paths(report.output_dir):
        try:
            rel = path.relative_to(report.output_dir)
        except ValueError:
            rel = path
        data, err = load_json(path)
        if err:
            report.errors.append(f"{rel}: {err}")
            continue
        if not isinstance(data, dict):
            report.errors.append(f"{rel}: top level is not an object")
            continue

        errors, warnings = validate_critique_doc(data, critique_validator)
        report.errors.extend(f"{rel}: {e}" for e in errors)
        report.warnings.extend(f"{rel}: {w}" for w in warnings)
        if errors:
            continue

        round_no = _round_of(path, report.output_dir, data)
        in_round_dir = rel.parent.name.startswith("round-")

        if in_round_dir and data.get("round") not in (None, round_no):
            report.errors.append(
                f"{rel}: declares round {data.get('round')} but sits in round-{round_no}/"
            )
        if run_doc and data.get("run_id") not in (None, run_doc["run_id"]):
            report.errors.append(
                f"{rel}: run_id '{data.get('run_id')}' does not match run.json "
                f"'{run_doc['run_id']}'"
            )

        shot_id = data.get("shot_id")
        if shot_id:
            key = (shot_id, round_no)
            if key in seen:
                report.errors.append(
                    f"{rel}: a second critique for {shot_id} in round {round_no} "
                    f"already exists at {seen[key]}; "
                    f"two operators reviewed the same shot in the same round"
                )
            else:
                seen[key] = rel

        _check_hash(report, f"{rel} image", data.get("image_ref"), data.get("image_sha256"))
        _check_hash(report, f"{rel} prompt", data.get("prompt_ref"), data.get("prompt_sha256"))
        _check_hash(
            report,
            f"{rel} brand-lock",
            data.get("brand_lock_ref"),
            data.get("brand_lock_sha256"),
        )

        if shot_id:
            entry = report.shots.setdefault(shot_id, {"rounds": {}})
            entry["rounds"][str(round_no)] = {
                "verdict": data.get("verdict"),
                "confidence": data.get("confidence"),
                "critique_ref": str(rel),
                "issues": len(data.get("issues", [])),
            }


def check_coverage(report: Report, run_doc: dict | None) -> None:
    shots_rel = "shots.json"
    if run_doc:
        shots_rel = run_doc["inputs"].get("shots_ref", "shots.json")
    shots_data, err = load_json(report.output_dir / shots_rel)
    shot_ids: list[str] = []
    if err:
        report.warnings.append(f"coverage: cannot read {shots_rel}, skipped ({err})")
    elif isinstance(shots_data, dict):
        shot_ids = [
            s["id"] for s in shots_data.get("shots", []) if isinstance(s.get("id"), str)
        ]

    reviewed_by_round: dict[int, set[str]] = {}
    for shot_id, entry in report.shots.items():
        for rnd in entry["rounds"]:
            reviewed_by_round.setdefault(int(rnd), set()).add(shot_id)

    for round_no, directory in round_dirs(report.output_dir, "frames"):
        reviewed = reviewed_by_round.get(round_no, set())
        for path in sorted(directory.iterdir()):
            if path.suffix.lstrip(".").lower() not in IMAGE_EXTS:
                continue
            frame_shot = path.stem
            if frame_shot not in reviewed:
                report.errors.append(
                    f"coverage: frames/round-{round_no}/{path.name} has no critique for "
                    f"round {round_no}; it was never reviewed"
                )

    for shot_id in shot_ids:
        entry = report.shots.get(shot_id)
        if not entry:
            report.warnings.append(
                f"coverage: {shot_id} has no critique in any round"
            )
            continue
        latest = max(int(r) for r in entry["rounds"])
        entry["latest_round"] = latest
        entry["latest_verdict"] = entry["rounds"][str(latest)]["verdict"]

    for shot_id in report.shots:
        if shot_ids and shot_id not in shot_ids:
            report.errors.append(
                f"coverage: a critique names {shot_id}, which is not in {shots_rel}"
            )


def validate_tree(output_dir: Path) -> Report:
    report = Report(output_dir)
    if not output_dir.is_dir():
        report.errors.append(f"not a directory: {output_dir}")
        return report
    run_doc = check_run_doc(report)
    check_critiques(report, run_doc)
    check_coverage(report, run_doc)
    _finalize_hash_failures(report)
    return report


def outstanding(report: Report) -> list[str]:
    """Shots whose latest verdict is not ACCEPT."""
    return sorted(
        shot_id
        for shot_id, entry in report.shots.items()
        if entry.get("latest_verdict") not in (None, "ACCEPT")
    )


def selftest() -> int:
    """Run the bundled worked example, then tamper with a copy and prove drift is caught."""
    import shutil
    import tempfile

    ok = True

    clean = validate_tree(WORKED_RUN)
    if clean.errors:
        print(f"  FAIL  selftest: the bundled worked run should be clean, got: {clean.errors}")
        ok = False
    else:
        print("  ok    selftest: the bundled worked run passes")

    if outstanding(clean):
        print(f"  FAIL  selftest: worked run should have no outstanding shots, got {outstanding(clean)}")
        ok = False
    else:
        print("  ok    selftest: every shot in the worked run ends on ACCEPT")

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        frame = scratch / "frames" / "round-2" / "shot_02.png"
        frame.write_bytes(frame.read_bytes() + b"\x00")
        report = validate_tree(scratch)
        if any("does not match the hash recorded" in e for e in report.errors):
            print("  ok    selftest: a frame regenerated after its critique is caught")
        else:
            print(f"  FAIL  selftest: frame tampering was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        lock = scratch / "brand-lock.snapshot.md"
        lock.write_text(lock.read_text() + "\n<!-- edited mid-project -->\n")
        report = validate_tree(scratch)
        if any("brand-lock.snapshot.md' does not match" in e for e in report.errors):
            print("  ok    selftest: a brand-lock edited mid-project is caught")
        else:
            print(f"  FAIL  selftest: brand-lock drift was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        src = scratch / "critiques" / "round-2" / "shot_02.critique.json"
        (scratch / "critiques" / "round-2" / "shot_02.operator-b.json").write_text(
            src.read_text()
        )
        report = validate_tree(scratch)
        if any("two operators reviewed the same shot" in e for e in report.errors):
            print("  ok    selftest: two critiques for one shot in one round is caught")
        else:
            print(f"  FAIL  selftest: duplicate critique was not caught, got: {report.errors}")
            ok = False

    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "run"
        shutil.copytree(WORKED_RUN, scratch)
        source = scratch / "frames" / "round-2" / "shot_02.png"
        (scratch / "frames" / "round-2" / "shot_01.png").write_bytes(source.read_bytes())
        report = validate_tree(scratch)
        if any("was never reviewed" in e for e in report.errors):
            print("  ok    selftest: a frame with no critique for its round is caught")
        else:
            print(f"  FAIL  selftest: unreviewed frame was not caught, got: {report.errors}")
            ok = False

    # A legacy tree keeps its critique at the output root. validate_critique.py and
    # shots-to-html.py both read it, so this tool has to as well: reporting a shot as
    # unreviewed while the preview shows its verdict badge is the exact kind of
    # disagreement between consumers that this release exists to remove.
    with tempfile.TemporaryDirectory() as tmp:
        scratch = Path(tmp) / "legacy"
        scratch.mkdir()
        shutil.copy(WORKED_RUN / "shots.json", scratch / "shots.json")
        shutil.copy(
            WORKED_RUN / "critiques" / "round-1" / "shot_01.critique.json",
            scratch / "critique.json",
        )
        report = validate_tree(scratch)
        if "shot_01" in report.shots:
            print("  ok    selftest: a legacy root critique.json is still discovered")
        else:
            print(
                "  FAIL  selftest: legacy root critique.json was ignored; "
                f"shots seen: {sorted(report.shots)}"
            )
            ok = False

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_provenance.py <output-dir> [...]")
        print("       python tools/validate_provenance.py <output-dir> --require-accept")
        print("       python tools/validate_provenance.py --examples")
        print("       python tools/validate_provenance.py --selftest")
        return 2
    if "--selftest" in args:
        return selftest()

    require_accept = "--require-accept" in args
    as_json = "--json" in args
    targets_raw = [a for a in args if not a.startswith("--")]

    if "--examples" in args:
        targets = [WORKED_RUN]
    elif targets_raw:
        targets = [Path(t) for t in targets_raw]
    else:
        print("ERROR: no output directory given")
        return 2

    reports = [validate_tree(t) for t in targets]

    if as_json:
        print(json.dumps([r.as_dict() for r in reports], indent=2))
    else:
        print(f"Validating provenance for {len(reports)} output tree(s)")
        print()
        for report in reports:
            try:
                label = report.output_dir.relative_to(REPO_ROOT)
            except ValueError:
                label = report.output_dir
            if report.errors:
                print(f"  FAIL  {label}")
                for err in report.errors:
                    print(f"        - {err}")
            else:
                print(f"  ok    {label}  ({len(report.shots)} shot(s), rounds {report.rounds_seen or 'none'})")
            for warn in report.warnings:
                print(f"  warn  {label}: {warn}")
            for shot_id in sorted(report.shots):
                entry = report.shots[shot_id]
                verdict = entry.get("latest_verdict", "?")
                print(
                    f"        {shot_id}: {verdict} "
                    f"(round {entry.get('latest_round', '?')})"
                )
        print()

    failed = any(r.errors for r in reports)
    unresolved = {
        str(r.output_dir): outstanding(r) for r in reports if outstanding(r)
    }

    if not as_json:
        if failed:
            total = sum(len(r.errors) for r in reports)
            print(f"FAILED: {total} provenance error(s).")
        elif require_accept and unresolved:
            for path, shots in unresolved.items():
                print(f"NOT DONE: {path} still has non-ACCEPT shots: {', '.join(shots)}")
        else:
            print("Provenance chain intact.")

    if failed:
        return 1
    if require_accept and unresolved:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/validate_provenance.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/validate_schemas.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/validate_schemas.py`

#!/usr/bin/env python3
"""
Validate that every *.schema.json file in the repo is itself valid JSON Schema.

Run from repo root:
    python tools/validate_schemas.py
"""

from __future__ import annotations
import json
import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
    from jsonschema.exceptions import SchemaError
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install jsonschema")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent


def find_schema_files() -> list[Path]:
    """Find every *.schema.json file in the repo."""
    return sorted(REPO_ROOT.rglob("*.schema.json"))


def validate_schema_file(path: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        errors.append(f"invalid JSON: {e}")
        return errors

    try:
        Draft202012Validator.check_schema(data)
    except SchemaError as e:
        errors.append(f"invalid schema: {e.message}")

    if "$id" not in data:
        errors.append("missing '$id' field")
    if "title" not in data:
        errors.append("missing 'title' field")
    if "description" not in data:
        errors.append("missing 'description' field")

    return errors


def main() -> int:
    schemas = find_schema_files()
    if not schemas:
        print("ERROR: no *.schema.json files found in repo")
        return 1

    print(f"Validating {len(schemas)} schema file(s)")
    print()

    total_errors = 0
    for path in schemas:
        rel = path.relative_to(REPO_ROOT)
        errors = validate_schema_file(path)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All schemas valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across schemas.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/validate_schemas.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/validate_shots.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/validate_shots.py`

#!/usr/bin/env python3
"""
Validate a storyboard output set: shots.json and text-overlays.json, as instances.

Schema validation alone was never enough here. Every rule below is documented in
skills/storyboard-architect/SKILL.md as a quality-bar checkbox, which means it was
enforced by a model remembering to check it. These are the same rules, executable.

Checks:
  1. shots.json validates against shots.schema.json.
  2. text-overlays.json validates against text-overlays.schema.json.
  3. Timing: end > start, no duplicate ids, no gaps, no overlaps, and the covered
     span matches project.duration_s within TIMING_TOLERANCE_S.
  4. Reference integrity, both directions: every shot.on_screen_text resolves to an
     overlay, every overlay.shot_id resolves to a shot, and every overlay is
     reachable from at least one shot.
  5. Overlay timing sits inside its shot window and exit is after enter.
  6. Every overlay color appears in the brand-lock palette.
  7. brand_lock_ref resolves on disk.
  8. Every assets.generated[].generator is a real id in the capability matrix.
  9. Warnings for prose leaks: on-screen copy repeated in a shot subject, raw hex in
     a shot subject, shot ids out of chronological order, overlay fonts not named in
     the brand-lock typography section.

Usage:
    python tools/validate_shots.py <output-dir> [...]
    python tools/validate_shots.py path/to/shots.json [...]
    python tools/validate_shots.py --examples          # every bundled example
    python tools/validate_shots.py --selftest          # prove the checks fire
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("ERROR: jsonschema not installed. Run: pip install pyyaml jsonschema")
    sys.exit(1)

from _shotkit import (
    HEX_RE,
    REPO_ROOT,
    as_overlay_ids,
    as_shot_ids,
    capability_ids,
    load_json,
    palette_hexes,
    parse_typography,
)

SHOTS_SCHEMA = (
    REPO_ROOT / "skills" / "storyboard-architect" / "templates" / "shots.schema.json"
)
OVERLAYS_SCHEMA = (
    REPO_ROOT
    / "skills"
    / "storyboard-architect"
    / "templates"
    / "text-overlays.schema.json"
)
EXAMPLES_DIR = REPO_ROOT / "skills" / "storyboard-architect" / "examples"

TIMING_TOLERANCE_S = 0.1


def _schema_errors(data, validator: Draft202012Validator, label: str) -> list[str]:
    out = []
    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        out.append(f"{label} schema: {loc}: {err.message}")
    return out


def check_timing(shots: list[dict], duration_s: float) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    seen: set[str] = set()
    for shot in shots:
        sid = shot.get("id", "?")
        if sid in seen:
            errors.append(f"timing: duplicate shot id '{sid}'")
        seen.add(sid)
        start, end = shot.get("start"), shot.get("end")
        if isinstance(start, (int, float)) and isinstance(end, (int, float)):
            if end <= start:
                errors.append(
                    f"timing: {sid} has end ({end}) not after start ({start})"
                )

    timed = [
        s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    ]
    if not timed:
        return errors, warnings

    ordered = sorted(timed, key=lambda s: (s["start"], s["end"]))
    for a, b in zip(ordered, ordered[1:]):
        if b["start"] > a["end"] + 1e-9:
            errors.append(
                f"timing: gap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )
        elif b["start"] < a["end"] - 1e-9:
            errors.append(
                f"timing: overlap between {a['id']} (ends {a['end']}) and "
                f"{b['id']} (starts {b['start']})"
            )

    span = max(s["end"] for s in timed) - min(s["start"] for s in timed)
    if abs(span - duration_s) > TIMING_TOLERANCE_S:
        errors.append(
            f"timing: covered span {span:g}s does not match project.duration_s "
            f"{duration_s:g}s (tolerance {TIMING_TOLERANCE_S}s)"
        )

    if [s["id"] for s in timed] != [s["id"] for s in ordered]:
        warnings.append(
            "timing: shot ids are not in chronological order; readers assume they are"
        )

    return errors, warnings


def check_version_features(shots: list[dict], version: str) -> list[str]:
    """Features may not be used below the version that introduced them."""
    errors: list[str] = []
    if version in ("1.0", "1.1"):
        for shot in shots:
            if isinstance(shot.get("on_screen_text"), list):
                errors.append(
                    f"version: {shot.get('id')} uses the array form of on_screen_text, "
                    f"which requires version 1.2 (file declares {version})"
                )
    if version == "1.0":
        for shot in shots:
            if shot.get("assets") is not None:
                errors.append(
                    f"version: {shot.get('id')} carries an assets block, which "
                    f"requires version 1.1 or later (file declares 1.0)"
                )
    return errors


def check_references(
    shots: list[dict], overlays: list[dict]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    shot_ids = {s.get("id") for s in shots}
    overlay_ids: set[str] = set()
    for overlay in overlays:
        oid = overlay.get("id")
        if oid in overlay_ids:
            errors.append(f"reference: duplicate overlay id '{oid}'")
        overlay_ids.add(oid)

    referenced: set[str] = set()
    for shot in shots:
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            referenced.add(oid)
            if oid not in overlay_ids:
                errors.append(
                    f"reference: {shot.get('id')}.on_screen_text '{oid}' has no "
                    f"entry in text-overlays.json"
                )

    for overlay in overlays:
        oid = overlay.get("id")
        for sid in as_shot_ids(overlay.get("shot_id")):
            if sid not in shot_ids:
                errors.append(
                    f"reference: overlay {oid}.shot_id '{sid}' has no entry in shots.json"
                )
        if oid not in referenced:
            errors.append(
                f"reference: overlay {oid} is not reachable from any "
                f"shot.on_screen_text, so no renderer will show it"
            )

    return errors, warnings


def check_overlay_windows(shots: list[dict], overlays: list[dict]) -> list[str]:
    errors: list[str] = []
    by_id = {
        s["id"]: s
        for s in shots
        if isinstance(s.get("start"), (int, float))
        and isinstance(s.get("end"), (int, float))
    }

    for overlay in overlays:
        oid = overlay.get("id")
        enter = (overlay.get("enter") or {}).get("at")
        exit_at = (overlay.get("exit") or {}).get("at")
        if not isinstance(enter, (int, float)) or not isinstance(exit_at, (int, float)):
            continue
        if exit_at <= enter:
            errors.append(
                f"overlay: {oid} exit ({exit_at}) is not after enter ({enter})"
            )
        windows = [by_id[s] for s in as_shot_ids(overlay.get("shot_id")) if s in by_id]
        if not windows:
            continue
        lo = min(w["start"] for w in windows)
        hi = max(w["end"] for w in windows)
        if enter < lo - 1e-9 or exit_at > hi + 1e-9:
            errors.append(
                f"overlay: {oid} timing {enter}-{exit_at}s falls outside its shot "
                f"window {lo:g}-{hi:g}s"
            )

    return errors


def check_brand_alignment(
    shots: list[dict], overlays: list[dict], brand_lock_text: str | None
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if brand_lock_text is None:
        warnings.append(
            "brand: brand_lock_ref did not resolve, so palette and font checks were skipped"
        )
        return errors, warnings

    allowed = palette_hexes(brand_lock_text)
    for overlay in overlays:
        color = overlay.get("color")
        if isinstance(color, str) and color.lower() not in allowed:
            errors.append(
                f"brand: overlay {overlay.get('id')} color {color} is not in the "
                f"brand-lock palette"
            )

    fonts = {v.lower() for v in parse_typography(brand_lock_text).values() if v}
    if fonts:
        for overlay in overlays:
            font = overlay.get("font")
            if isinstance(font, str) and font.lower() not in fonts:
                warnings.append(
                    f"brand: overlay {overlay.get('id')} font '{font}' is not a font "
                    f"declared in the brand-lock typography section"
                )

    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        for hex_val in HEX_RE.findall(subject):
            warnings.append(
                f"brand: {shot.get('id')}.subject names a raw hex ({hex_val}); "
                f"colors belong in series_lock and the brand-lock"
            )

    return errors, warnings


def check_text_leak(shots: list[dict], overlays: list[dict]) -> list[str]:
    """On-screen copy repeated inside a shot subject. Text is a separate layer."""
    warnings: list[str] = []
    contents = {
        o.get("id"): o.get("content")
        for o in overlays
        if isinstance(o.get("content"), str) and len(o.get("content", "")) >= 8
    }
    for shot in shots:
        subject = shot.get("subject")
        if not isinstance(subject, str):
            continue
        lowered = subject.lower()
        for oid in as_overlay_ids(shot.get("on_screen_text")):
            content = contents.get(oid)
            if content and content.lower().rstrip(".!?") in lowered:
                warnings.append(
                    f"text: {shot.get('id')}.subject repeats overlay {oid} copy "
                    f"verbatim; on-screen text is composited, never described"
                )
    return warnings


def check_assets(shots: list[dict], known_generators: set[str]) -> list[str]:
    errors: list[str] = []
    if not known_generators:
        return errors
    for shot in shots:
        for entry in (shot.get("assets") or {}).get("generated", []) or []:
            gen = entry.get("generator")
            if isinstance(gen, str) and gen not in known_generators:
                errors.append(
                    f"assets: {shot.get('id')} generated frame names generator "
                    f"'{gen}', which is not in the capability matrix"
                )
            if entry.get("accepted") is True and not entry.get("critique_ref"):
                errors.append(
                    f"assets: {shot.get('id')} has an accepted frame with no "
                    f"critique_ref, which is an unsourced approval"
                )
    return errors


def validate_set(shots_path: Path) -> tuple[list[str], list[str]]:
    """Validate one shots.json plus the siblings it points at."""
    errors: list[str] = []
    warnings: list[str] = []

    shots_data, err = load_json(shots_path)
    if err:
        return ([err], warnings)
    if not isinstance(shots_data, dict):
        return ([f"{shots_path}: top level is not an object"], warnings)

    shots_schema, s_err = load_json(SHOTS_SCHEMA)
    overlays_schema, o_err = load_json(OVERLAYS_SCHEMA)
    if s_err or o_err:
        return ([s_err or o_err], warnings)

    errors += _schema_errors(
        shots_data, Draft202012Validator(shots_schema), "shots.json"
    )

    base = shots_path.parent
    overlays_path = base / "text-overlays.json"
    overlays: list[dict] = []
    if overlays_path.exists():
        overlays_data, ov_err = load_json(overlays_path)
        if ov_err:
            errors.append(f"text-overlays.json: {ov_err}")
        else:
            errors += _schema_errors(
                overlays_data,
                Draft202012Validator(overlays_schema),
                "text-overlays.json",
            )
            overlays = overlays_data.get("overlays", []) or []
    else:
        for shot in shots_data.get("shots", []) or []:
            if as_overlay_ids(shot.get("on_screen_text")):
                errors.append(
                    "reference: shots.json references on-screen text but "
                    "text-overlays.json is missing"
                )
                break

    if errors:
        # Structure-dependent checks assume schema-valid input.
        return (errors, warnings)

    shots = shots_data.get("shots", []) or []
    duration = shots_data.get("project", {}).get("duration_s")

    errors += check_version_features(shots, shots_data.get("version", ""))

    if isinstance(duration, (int, float)):
        t_err, t_warn = check_timing(shots, float(duration))
        errors += t_err
        warnings += t_warn

    r_err, r_warn = check_references(shots, overlays)
    errors += r_err
    warnings += r_warn
    errors += check_overlay_windows(shots, overlays)

    brand_ref = shots_data.get("brand_lock_ref")
    brand_text: str | None = None
    if isinstance(brand_ref, str):
        brand_path = base / brand_ref
        if brand_path.exists():
            brand_text = brand_path.read_text(encoding="utf-8")
        else:
            errors.append(
                f"brand: brand_lock_ref '{brand_ref}' does not resolve from {base}"
            )
    b_err, b_warn = check_brand_alignment(shots, overlays, brand_text)
    errors += b_err
    warnings += b_warn

    warnings += check_text_leak(shots, overlays)
    errors += check_assets(shots, capability_ids())

    return (errors, warnings)


def _resolve_target(raw: str) -> Path | None:
    path = Path(raw)
    if path.is_dir():
        candidate = path / "shots.json"
        return candidate if candidate.exists() else None
    return path if path.exists() else None


def selftest() -> int:
    """Prove the cross-field checks fire. Fixtures are in-memory, no files touched."""
    ok = True
    cases = [
        (
            "end not after start",
            lambda: check_timing(
                [{"id": "shot_01", "start": 5.0, "end": 3.0}], 30.0
            )[0],
        ),
        (
            "gap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 2.0},
                    {"id": "shot_02", "start": 4.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "overlap between shots",
            lambda: check_timing(
                [
                    {"id": "shot_01", "start": 0.0, "end": 5.0},
                    {"id": "shot_02", "start": 3.0, "end": 30.0},
                ],
                30.0,
            )[0],
        ),
        (
            "span disagrees with duration",
            lambda: check_timing(
                [{"id": "shot_01", "start": 0.0, "end": 10.0}], 30.0
            )[0],
        ),
        (
            "dangling on_screen_text",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": "text_09"}], []
            )[0],
        ),
        (
            "unreachable overlay",
            lambda: check_references(
                [{"id": "shot_01", "on_screen_text": None}],
                [{"id": "text_01", "shot_id": "shot_01"}],
            )[0],
        ),
        (
            "overlay outside its shot window",
            lambda: check_overlay_windows(
                [{"id": "shot_01", "start": 0.0, "end": 2.0}],
                [
                    {
                        "id": "text_01",
                        "shot_id": "shot_01",
                        "enter": {"at": 0.0},
                        "exit": {"at": 9.0},
                    }
                ],
            ),
        ),
        (
            "off-palette overlay color",
            lambda: check_brand_alignment(
                [],
                [{"id": "text_01", "color": "#ABCDEF"}],
                "## Palette\n\n| Role | Hex |\n|---|---|\n| Ink | `#2A2A32` |\n",
            )[0],
        ),
        (
            "accepted frame with no critique_ref",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {"generated": [{"path": "a.png", "accepted": True}]},
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "unknown generator id",
            lambda: check_assets(
                [
                    {
                        "id": "shot_01",
                        "assets": {
                            "generated": [{"path": "a.png", "generator": "runway-sora"}]
                        },
                    }
                ],
                {"flux"},
            ),
        ),
        (
            "1.2 feature used in a 1.0 file",
            lambda: check_version_features(
                [{"id": "shot_01", "on_screen_text": ["text_01", "text_02"]}], "1.0"
            ),
        ),
    ]

    for label, fn in cases:
        produced = fn()
        if produced:
            print(f"  ok    selftest: {label} is caught")
        else:
            print(f"  FAIL  selftest: {label} was not caught")
            ok = False

    clean, clean_warn = check_timing(
        [
            {"id": "shot_01", "start": 0.0, "end": 2.0},
            {"id": "shot_02", "start": 2.0, "end": 30.0},
        ],
        30.0,
    )
    if clean or clean_warn:
        print(f"  FAIL  selftest: a clean shot list should pass, got: {clean + clean_warn}")
        ok = False
    else:
        print("  ok    selftest: a clean shot list passes")

    print()
    print("Selftest passed." if ok else "Selftest FAILED.")
    return 0 if ok else 1


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: python tools/validate_shots.py <output-dir|shots.json> [...]")
        print("       python tools/validate_shots.py --examples")
        print("       python tools/validate_shots.py --selftest")
        return 2

    if "--selftest" in args:
        return selftest()

    if "--examples" in args:
        targets = sorted(EXAMPLES_DIR.glob("*/shots.json"))
        if not targets:
            print(f"ERROR: no bundled examples found under {EXAMPLES_DIR}")
            return 1
    else:
        targets = []
        for raw in args:
            resolved = _resolve_target(raw)
            if resolved is None:
                print(f"  FAIL  {raw}")
                print("        - no shots.json found at this path")
                return 1
            targets.append(resolved)

    print(f"Validating {len(targets)} storyboard set(s)")
    print()

    total_errors = 0
    total_warnings = 0
    for shots_path in targets:
        try:
            rel = shots_path.relative_to(REPO_ROOT)
        except ValueError:
            rel = shots_path
        errors, warnings = validate_set(shots_path)
        total_warnings += len(warnings)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")
        for warn in warnings:
            print(f"  warn  {rel}: {warn}")

    print()
    if total_errors == 0:
        print(f"All storyboard sets valid ({total_warnings} warning(s)).")
        return 0
    print(f"FAILED: {total_errors} error(s) across storyboard sets.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/validate_shots.py -->


<!-- SOURCE_FILE_START: skills/visual-prompt-forge/tools/validate_skills.py -->
# SOURCE FILE: `skills/visual-prompt-forge/tools/validate_skills.py`

#!/usr/bin/env python3
"""
Validate every SKILL.md in the repo has the required frontmatter.

Required fields:
- name (string, matches the directory name)
- description (string, non-empty)

Run from repo root:
    python tools/validate_skills.py
"""

from __future__ import annotations
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML not installed. Run: pip install pyyaml")
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent
SKILLS_DIR = REPO_ROOT / "skills"


def parse_frontmatter(path: Path) -> dict | None:
    """Extract YAML frontmatter from a Markdown file. Returns None if absent."""
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    parts = text.split("---", 2)
    if len(parts) < 3:
        return None
    try:
        return yaml.safe_load(parts[1])
    except yaml.YAMLError as e:
        print(f"  YAML parse error: {e}")
        return None


def validate_skill(skill_dir: Path) -> list[str]:
    """Return a list of errors. Empty list = passes."""
    errors: list[str] = []
    skill_md = skill_dir / "SKILL.md"

    if not skill_md.exists():
        errors.append(f"missing SKILL.md")
        return errors

    fm = parse_frontmatter(skill_md)
    if fm is None:
        errors.append("missing or invalid YAML frontmatter")
        return errors

    if "name" not in fm:
        errors.append("frontmatter missing 'name'")
    elif not isinstance(fm["name"], str) or not fm["name"].strip():
        errors.append("frontmatter 'name' must be a non-empty string")
    elif fm["name"] != skill_dir.name:
        errors.append(
            f"frontmatter name '{fm['name']}' does not match directory name '{skill_dir.name}'"
        )

    if "description" not in fm:
        errors.append("frontmatter missing 'description'")
    elif not isinstance(fm["description"], str) or not fm["description"].strip():
        errors.append("frontmatter 'description' must be a non-empty string")
    elif len(fm["description"]) < 50:
        errors.append(
            f"frontmatter description is too short ({len(fm['description'])} chars). "
            "Aim for >= 50 chars to support skill triggering."
        )

    return errors


def main() -> int:
    if not SKILLS_DIR.exists():
        print(f"ERROR: skills directory not found at {SKILLS_DIR}")
        return 1

    skill_dirs = sorted([d for d in SKILLS_DIR.iterdir() if d.is_dir()])
    if not skill_dirs:
        print(f"ERROR: no skill directories found in {SKILLS_DIR}")
        return 1

    print(f"Validating {len(skill_dirs)} skill(s) in {SKILLS_DIR.relative_to(REPO_ROOT)}/")
    print()

    total_errors = 0
    for skill_dir in skill_dirs:
        errors = validate_skill(skill_dir)
        rel = skill_dir.relative_to(REPO_ROOT)
        if not errors:
            print(f"  ok    {rel}")
        else:
            total_errors += len(errors)
            print(f"  FAIL  {rel}")
            for err in errors:
                print(f"        - {err}")

    print()
    if total_errors == 0:
        print("All skills valid.")
        return 0
    print(f"FAILED: {total_errors} error(s) across skills.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: skills/visual-prompt-forge/tools/validate_skills.py -->


<!-- SOURCE_FILE_START: skills-manifest.json -->
# SOURCE FILE: `skills-manifest.json`

{
  "lastUpdated": 1789078167073,
  "skills": [
    {
      "skillId": "skill_016QeAR1RgTgKXtxX7VGm53A",
      "name": "produccion-visual-sw30",
      "description": "Reglas criticas y micro-gate de produccion visual AI para Final Upgrade (proyecto SW30 y cualquier generacion de imagen/video). USA ESTE SKILL SIEMPRE que se escriba o entregue un prompt visual (imagen o video), se genere con Nano Banana, Kling, Veo, GPT Image o el conector Higgsfield, se gasten creditos de generacion, se trabaje cualquier shot, ancla, clip o asset del proyecto SW30/Sports World, o Eric escriba \"gate\", \"micro-gate\" o \"reglas de produccion\". APLICAR ANTES de producir - el micro-gate de 3 lineas es obligatorio antes de gastar creditos o entregar prompts; entrega sin cabecera es invalida.",
      "source": "custom",
      "updatedAt": "2026-08-29T03:37:41.287133Z"
    },
    {
      "skillId": "skill_016qiiCh6Be2SK2BFNnk37Yk",
      "name": "ai-production-director",
      "description": "Skill maestra que orquesta el pipeline completo de producción audiovisual con AI — de creative brief a Final AI Video Production Package. Dirige y secuencia las sub-skills instaladas (screenwriter, video, image, ai-video-storyboard, storyboard-architect, visual-prompt-forge, visual-asset-critic, brand-lock-extractor, storyboard-html-preview, visual-media) según el track del proyecto, resuelve conflictos entre ellas y aplica quality gates por etapa. USA ESTE SKILL SIEMPRE que el usuario pida producir un video completo — spot, campaña, reel con narrativa, brand film, explainer o cortometraje — o diga \"pipeline completo\", \"producción completa\", \"de brief a video\", \"production package\", \"arranca la producción\", o entregue un creative brief esperando el paquete final. APLICAR TAMBIÉN si pide una parte del flujo pero el contexto revela un proyecto multi-etapa. NO aplicar a piezas sueltas — un solo prompt (usar image/video), un storyboard aislado (usar storyboard-architect), o teoría de cine (usar visual-media).",
      "source": "custom",
      "updatedAt": "2026-08-14T04:40:09.957217Z"
    },
    {
      "skillId": "skill_01BDTRHa57VyghUUsgErfKmP",
      "name": "screenwriter",
      "description": "Transform creative ideas into professional, production-ready screenplays optimized for AI video generation pipelines. Converts raw concepts into structured scene-by-scene narratives with rich visual descriptions, proper screenplay formatting, and XML-tagged output for seamless integration with image/video generation tools (imagine, arch-v).\nUSE WHEN: Converting story ideas into screenplay format, preparing content for AI video pipelines, structuring narratives for 5-10 minute short films, generating visual-rich scene descriptions for image generation. Use this even when the user doesn't say \"screenplay\" explicitly — e.g. \"break this idea into scenes\" or \"write the script for this short film.\"\nWORKFLOW: Raw idea → Scene breakdown → Visual enhancement → Professional formatting → XML-tagged markdown output\nOUTPUT: Markdown document with XML-wrapped scenes, rich visual descriptions, proper screenplay elements (sluglines, action, dialogue), and metadata for pipeline processing.",
      "source": "custom",
      "updatedAt": "2026-08-19T02:24:55.898862Z"
    },
    {
      "skillId": "skill_01TskvgrABHjsVV8VynsGaML",
      "name": "visual-media",
      "description": "Creación visual — fotografía, producción de video, animación, cine, contenido de formato corto (Reels/TikTok/Shorts) y postproducción. Cubre triángulo de exposición, reglas de composición, tipos de plano, movimientos de cámara, los 12 principios de animación de Disney, ritmo de edición, J-cut/L-cut, regla de los 180 grados y color grading. Usa este skill siempre que el usuario mencione fotografía, video, animación, cine, edición, postproducción, storyboard, guion técnico, encuadre, iluminación, plano, movimiento de cámara, colorización, Reels, TikTok, Shorts, photography, filmmaking, editing, color grading, 攝影, 影片, 動畫, 剪輯 o 短影音 — y también cuando pida un plan de rodaje, feedback sobre material grabado, storytelling visual, un flujo de producción audiovisual o decisiones de encuadre e iluminación, aunque nunca diga la palabra \"skill\". No aplicar a tareas de código, API o backend.",
      "source": "custom",
      "updatedAt": "2026-08-14T03:39:02.749547Z"
    },
    {
      "skillId": "skill_01UWW7vsLLcPcSG5nbwWWbTn",
      "name": "ai-video-storyboard",
      "description": "Use when planning a multi-shot AI video (TikTok Reel, Instagram Ad, YouTube Shorts, product explainer) where the target duration exceeds what a single AI generation can produce (over 15 seconds), and you need a coordinated shot list with visually consistent prompts for each segment",
      "source": "custom",
      "updatedAt": "2026-08-14T04:29:32.106438Z"
    },
    {
      "skillId": "skill_018L9eLeuJ2nULq42yFQZHWC",
      "name": "video",
      "description": "Use this skill whenever the user asks to create, improve, audit, or split prompts for AI video generators (Seedance, Kling, Veo, Runway, Luma, Pika, Sora, any image-to-video system). The skill also covers storyboards, shot lists, director treatments, dynamic montage, multi-clip story structure, camera direction, lighting, blocking, pacing, character continuity, dialogue, and sound design. Trigger even when the user says things like \"придумай сцену для видео\", \"разбей на склейки\", \"сделай раскадровку\", \"улучши промпт для Kling\", \"переведи сценарий в промпты\", \"как снять X в AI-видео\", or shares a prompt and asks to fix it.",
      "source": "custom",
      "updatedAt": "2026-08-14T04:26:32.403941Z"
    },
    {
      "skillId": "skill_01BEvnCrCzAhbk6CM4LL8v5x",
      "name": "storyboard-html-preview",
      "description": "Render a structured storyboard (storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md) into a single-file HTML preview that is shareable, printable, and offline. Use when the user wants to share a storyboard, export for review, hand off to an editor, or print a hard copy. Triggers on \"preview the storyboard\", \"share this\", \"export to HTML\", \"print version\", or after a storyboard-architect run. Produces one self-contained .html file with no build or server.",
      "source": "custom",
      "updatedAt": "2026-08-14T04:31:37.578521Z"
    },
    {
      "skillId": "skill_01E1MA7LAQC4PGQws14WXp3k",
      "name": "visual-asset-critic",
      "description": "Critique a generated image against its source storyboard shot and prompt, producing revision notes. Use when the user has generated an image and wants feedback before committing. Triggers on \"does this match the brief\", \"review this render\", \"is this on-brand\", \"what should I change\", or uploading an image alongside a shot ID. The QA loop for AI visuals. Works even without a storyboard-architect run. Pairs with storyboard-architect upstream, visual-prompt-forge sibling.",
      "source": "custom",
      "updatedAt": "2026-08-14T04:31:37.071180Z"
    },
    {
      "skillId": "skill_017KdAwmBNCRic6ctCRksvAX",
      "name": "image",
      "description": "Image prompting skill for Nano Banana (NBP/NB2) and GPT Image 2. Writes ready-to-use prompts with model/quality/size recommendations. Use when: \"нарисуй\", \"сгенерируй картинку\", \"image prompt\", \"промпт для картинки\", blog covers, slides, posters, product shots, UI mockups, storyboards, character sheets, edit/colorize, style transfer, vision analysis, image-to-prompt, nb, NBP, NB2, gpt-image-2, multi-panel grids, ecommerce product photography, fashion editorial, food/beverage ads, cinematic portraits. Do NOT use for: video (use video skill), 3D models, audio, non-image tasks.",
      "source": "custom",
      "updatedAt": "2026-08-14T04:26:35.702425Z"
    },
    {
      "skillId": "skill_01Lvnf4bnzKKL9dkFj1Vd4MS",
      "name": "brand-lock-extractor",
      "description": "Extract a production-ready brand-lock.md from a brand's existing assets. Point it at a website URL, a brand book PDF, screenshots, or a written description and it produces the nine-section brand-lock the rest of shotkit consumes, with a confidence and source noted for every value. Use when the user wants to onboard a brand, says \"build a brand lock\", \"extract my brand\", \"make a brand pack from my site\", or hands over brand assets. The cold-start killer that turns a blank brand-pack template into a filled, validate-ready file. Pairs with storyboard-architect downstream.",
      "source": "custom",
      "updatedAt": "2026-08-14T04:31:37.219624Z"
    },
    {
      "skillId": "skill_016CWCmNDUFufDBMRBhirTAY",
      "name": "visual-prompt-forge",
      "description": "Generate model-specific prompts from shots.json. Outputs copy-paste-ready prompts for stills (Midjourney, Flux, Ideogram, GPT Image, Nano Banana, Seedream) and motion video (Kling, Veo, Seedance, Hailuo). Also runs a revision mode that reads a critique.json and re-emits prompts for only the failed shots, closing the QA loop. Use when the user asks for image or video prompts, mentions any of those generators, wants AI-generated frames for a storyboard, or hands over shots.json. The prompt half of the pipeline. Composes with storyboard-architect upstream, visual-asset-critic downstream.",
      "source": "custom",
      "updatedAt": "2026-08-17T08:47:04.736766Z"
    },
    {
      "skillId": "skill_01WFmYU85EFfzZ3obWyPZygy",
      "name": "storyboard-architect",
      "description": "Turn a creative brief into a production-grade storyboard with shot specs, timing, on-screen text, and per-shot rationale. Use when the user describes a video brief, plans a video, references shots or beats, scripts a social video, or hands over a creative concept to break into scenes. Produces run.json, storyboard.md, shots.json, text-overlays.json, and brand-lock.snapshot.md. Pairs with visual-prompt-forge, visual-asset-critic, storyboard-html-preview.",
      "source": "custom",
      "updatedAt": "2026-08-14T04:31:34.992722Z"
    },
    {
      "skillId": "skill_01G7yadJB6RMqNMvZcMQQcjJ",
      "name": "aurora-prompt-linter",
      "description": "Gate determinista que valida prompts de generación visual AI (imagen/video) antes de entregar. Detecta 3 capas: redundancia con refs por categoría P/O/L/PR/S, secciones requeridas por plataforma+caso (Kling 3.0/Veo 3.1/Sora 2/GPT Image 2/Nano Banana Pro/Midjourney), y estructura (word count, negative prompt, vocab baneado). USA ESTE SKILL antes de entregar cualquier prompt visual al usuario — gate obligatorio del skill prompt-production-protocol Step 5b. Override solo con sintaxis expresa OVERRIDE: término-o-categoría - razón, válido únicamente en turno actual.",
      "source": "custom",
      "updatedAt": "2026-05-28T07:09:24.709660Z"
    }
  ]
}
<!-- SOURCE_FILE_END: skills-manifest.json -->
