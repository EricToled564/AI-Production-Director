# AI Production Director — Knowledge Pack 1/7

Generated from `aiproductiondirectorcompleto.zip`.
Each source file is preserved with its original relative path.


<!-- SOURCE_FILE_START: INDEX.md -->
# SOURCE FILE: `INDEX.md`

# AI Production Director — paquete completo

Generado: 2026-09-10T22:11:22Z
Origen skills: /root/.claude/skills/synced/66f050bc-…-7864280b-…/ (skills sincronizadas de la cuenta)
Origen repo:   github.com/EricToled564/AI-Production-Director @ 8b204f7 (rama claude/peaceful-fermi-l31c96)

## Contenido

```
skills/   13 skills — la maestra + las 12 que su SKILL.md declara en el mapa de sub-skills
repo/     el repositorio de control de reglas (hooks, registro, corpus NotebookLM, app Vercel)
skills-manifest.json   entradas de manifest.json de la cuenta, filtradas a estas 13 skills
```

## Skills incluidas

| skill | capa en el pipeline | archivos | tamaño |
|---|---|---:|---:|
| `ai-production-director` | maestra·orquestador | 3 | 40K |
| `brand-lock-extractor` | 0·marca | 23 | 256K |
| `screenwriter` | 2·guion | 3 | 36K |
| `video` | 3·dirección·+·6·prompts-video | 15 | 256K |
| `storyboard-architect` | 4·shot-planning | 44 | 472K |
| `ai-video-storyboard` | 4·shot-planning·EXPRESS | 2 | 28K |
| `image` | 5·anchors | 25 | 280K |
| `visual-prompt-forge` | 5–6·prompts | 39 | 380K |
| `visual-asset-critic` | 5·QA | 33 | 356K |
| `storyboard-html-preview` | 7·entrega | 19 | 236K |
| `visual-media` | transversal·animación/ES | 1 | 20K |
| `aurora-prompt-linter` | gate·final | 6 | 72K |
| `produccion-visual-sw30` | micro-gate·producción | 1 | 16K |

## Inventario completo de archivos

```
repo/.claude/hooks/README.md
repo/.claude/hooks/export_xlsx.py
repo/.claude/hooks/gate_dramaturgy.py
repo/.claude/hooks/gate_image.py
repo/.claude/hooks/gate_microgate.py
repo/.claude/hooks/gate_shots.py
repo/.claude/hooks/inject_rules.py
repo/.claude/hooks/nblm_client.py
repo/.claude/hooks/nblm_import_auth.py
repo/.claude/hooks/nblm_load.py
repo/.claude/hooks/prompt_detect.py
repo/.claude/hooks/rule_answer_check.py
repo/.claude/hooks/rule_db.py
repo/.claude/hooks/rule_export.py
repo/.claude/hooks/rule_ledger.py
repo/.claude/hooks/rule_registry.py
repo/.claude/hooks/rule_scope.py
repo/.claude/hooks/rules_sqlite.py
repo/.claude/hooks/schema_v2.sql
repo/.claude/hooks/verify.sh
repo/.claude/rules/METODO.md
repo/.claude/rules/scope.yaml
repo/.claude/settings.json
repo/.gitignore
repo/.mcp.json
repo/VERCEL.md
repo/api/config.js
repo/api/sample.js
repo/app/build_app.py
repo/app/ejecutor.html
repo/nblm-ids/PREGUNTA.txt
repo/nblm-ids/ai-production-director.md
repo/nblm-ids/ai-video-storyboard.md
repo/nblm-ids/brand-lock-extractor.md
repo/nblm-ids/image.md
repo/nblm-ids/produccion-visual-sw30.md
repo/nblm-ids/screenwriter.md
repo/nblm-ids/storyboard-architect.md
repo/nblm-ids/storyboard-html-preview.md
repo/nblm-ids/video.md
repo/nblm-ids/visual-asset-critic.md
repo/nblm-ids/visual-prompt-forge.md
repo/notebooklm-corpus/PREGUNTA.txt
repo/notebooklm-corpus/ai-production-director.md
repo/notebooklm-corpus/ai-video-storyboard.md
repo/notebooklm-corpus/brand-lock-extractor.md
repo/notebooklm-corpus/image.md
repo/notebooklm-corpus/produccion-visual-sw30.md
repo/notebooklm-corpus/screenwriter.md
repo/notebooklm-corpus/storyboard-architect.md
repo/notebooklm-corpus/storyboard-html-preview.md
repo/notebooklm-corpus/video.md
repo/notebooklm-corpus/visual-asset-critic.md
repo/notebooklm-corpus/visual-media.md
repo/notebooklm-corpus/visual-prompt-forge.md
repo/package-lock.json
repo/package.json
repo/public/index.html
repo/vercel.json
skills-manifest.json
skills/ai-production-director/SKILL.md
skills/ai-production-director/references/creative-strategy.md
skills/ai-production-director/references/production-package.md
skills/ai-video-storyboard/SKILL.md
skills/ai-video-storyboard/examples/tiktok-reel-30s-coffee.md
skills/aurora-prompt-linter/SKILL.md
skills/aurora-prompt-linter/references/README.md
skills/aurora-prompt-linter/references/skill_update_step5.md
skills/aurora-prompt-linter/references/system_prompt_v6_1_rule28.md
skills/aurora-prompt-linter/scripts/prompt_linter.py
skills/aurora-prompt-linter/scripts/vocabularies.yaml
skills/brand-lock-extractor/LICENSE
skills/brand-lock-extractor/SKILL.md
skills/brand-lock-extractor/brand-packs/README.md
skills/brand-lock-extractor/brand-packs/_template.md
skills/brand-lock-extractor/brand-packs/examples/saas-clean.md
skills/brand-lock-extractor/examples/brand-lock.md
skills/brand-lock-extractor/examples/input-brief.md
skills/brand-lock-extractor/references/extraction-rubric.md
skills/brand-lock-extractor/templates/brand-lock.md.tpl
skills/brand-lock-extractor/tools/README.md
skills/brand-lock-extractor/tools/_shotkit.py
skills/brand-lock-extractor/tools/_template.py
skills/brand-lock-extractor/tools/check.sh
skills/brand-lock-extractor/tools/copy-prompt.py
skills/brand-lock-extractor/tools/shots-to-html.py
skills/brand-lock-extractor/tools/validate_brand_lock.py
skills/brand-lock-extractor/tools/validate_capabilities.py
skills/brand-lock-extractor/tools/validate_critique.py
skills/brand-lock-extractor/tools/validate_prompts.py
skills/brand-lock-extractor/tools/validate_provenance.py
skills/brand-lock-extractor/tools/validate_schemas.py
skills/brand-lock-extractor/tools/validate_shots.py
skills/brand-lock-extractor/tools/validate_skills.py
skills/image/LICENSE
skills/image/NOTICE
skills/image/SKILL.md
skills/image/references/characters.md
skills/image/references/creative-direction.md
skills/image/references/dimensional.md
skills/image/references/editing.md
skills/image/references/golden-rules.md
skills/image/references/gpt-image.md
skills/image/references/models.md
skills/image/references/multi-panel.md
skills/image/references/nano-banana.md
skills/image/references/patterns/character-design.md
skills/image/references/patterns/ecommerce.md
skills/image/references/patterns/fashion-editorial.md
skills/image/references/patterns/food-beverage.md
skills/image/references/patterns/portrait-cinema.md
skills/image/references/patterns/poster-illustration.md
skills/image/references/patterns/ui-social.md
skills/image/references/prompt-framework.md
skills/image/references/slides.md
skills/image/references/storyboards.md
skills/image/references/structural.md
skills/image/references/text-rendering.md
skills/image/references/vision-decomposer.md
skills/produccion-visual-sw30/SKILL.md
skills/screenwriter/SKILL.md
skills/screenwriter/references/advanced-techniques.md
skills/screenwriter/references/pipeline-integration.md
skills/storyboard-architect/LICENSE
skills/storyboard-architect/SKILL.md
skills/storyboard-architect/brand-packs/README.md
skills/storyboard-architect/brand-packs/_template.md
skills/storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md
skills/storyboard-architect/examples/30s-pain-proof-promise/preview.html
skills/storyboard-architect/examples/30s-pain-proof-promise/run.json
skills/storyboard-architect/examples/30s-pain-proof-promise/shots.json
skills/storyboard-architect/examples/30s-pain-proof-promise/storyboard.md
skills/storyboard-architect/examples/30s-pain-proof-promise/text-overlays.json
skills/storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md
skills/storyboard-architect/examples/60s-founder-explainer/preview.html
skills/storyboard-architect/examples/60s-founder-explainer/run.json
skills/storyboard-architect/examples/60s-founder-explainer/shots.json
skills/storyboard-architect/examples/60s-founder-explainer/storyboard.md
skills/storyboard-architect/examples/60s-founder-explainer/text-overlays.json
skills/storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md
skills/storyboard-architect/examples/shotkit-explainer/preview.html
skills/storyboard-architect/examples/shotkit-explainer/run.json
skills/storyboard-architect/examples/shotkit-explainer/shots.json
skills/storyboard-architect/examples/shotkit-explainer/storyboard.md
skills/storyboard-architect/examples/shotkit-explainer/text-overlays.json
skills/storyboard-architect/references/beat-frameworks.md
skills/storyboard-architect/references/on-screen-text.md
skills/storyboard-architect/references/shot-grammar.md
skills/storyboard-architect/references/timing-rules.md
skills/storyboard-architect/templates/run.schema.json
skills/storyboard-architect/templates/shots.schema.json
skills/storyboard-architect/templates/storyboard.md.tpl
skills/storyboard-architect/templates/text-overlays.schema.json
skills/storyboard-architect/tools/README.md
skills/storyboard-architect/tools/_shotkit.py
skills/storyboard-architect/tools/_template.py
skills/storyboard-architect/tools/check.sh
skills/storyboard-architect/tools/copy-prompt.py
skills/storyboard-architect/tools/shots-to-html.py
skills/storyboard-architect/tools/validate_brand_lock.py
skills/storyboard-architect/tools/validate_capabilities.py
skills/storyboard-architect/tools/validate_critique.py
skills/storyboard-architect/tools/validate_prompts.py
skills/storyboard-architect/tools/validate_provenance.py
skills/storyboard-architect/tools/validate_schemas.py
skills/storyboard-architect/tools/validate_shots.py
skills/storyboard-architect/tools/validate_skills.py
skills/storyboard-html-preview/LICENSE
skills/storyboard-html-preview/SKILL.md
skills/storyboard-html-preview/templates/preview.html.tpl
skills/storyboard-html-preview/templates/print.css.tpl
skills/storyboard-html-preview/templates/styles.css.tpl
skills/storyboard-html-preview/tools/README.md
skills/storyboard-html-preview/tools/_shotkit.py
skills/storyboard-html-preview/tools/_template.py
skills/storyboard-html-preview/tools/check.sh
skills/storyboard-html-preview/tools/copy-prompt.py
skills/storyboard-html-preview/tools/shots-to-html.py
skills/storyboard-html-preview/tools/validate_brand_lock.py
skills/storyboard-html-preview/tools/validate_capabilities.py
skills/storyboard-html-preview/tools/validate_critique.py
skills/storyboard-html-preview/tools/validate_prompts.py
skills/storyboard-html-preview/tools/validate_provenance.py
skills/storyboard-html-preview/tools/validate_schemas.py
skills/storyboard-html-preview/tools/validate_shots.py
skills/storyboard-html-preview/tools/validate_skills.py
skills/video/LICENSE
skills/video/NOTICE
skills/video/SKILL.md
skills/video/references/animatic-keyframes.md
skills/video/references/camera-lighting-vocabulary.md
skills/video/references/dramaturgy.md
skills/video/references/fixes-and-skeletons.md
skills/video/references/kling.md
skills/video/references/patterns-and-genres.md
skills/video/references/race-and-speed.md
skills/video/references/role-modes.md
skills/video/references/seedance-25.md
skills/video/references/seedance.md
skills/video/references/universal-rules.md
skills/video/references/veo.md
skills/visual-asset-critic/LICENSE
skills/visual-asset-critic/SKILL.md
skills/visual-asset-critic/examples/critique.accept.json
skills/visual-asset-critic/examples/critique.revise.json
skills/visual-asset-critic/examples/worked-run/brand-lock.snapshot.md
skills/visual-asset-critic/examples/worked-run/critiques/round-1/shot_01.critique.json
skills/visual-asset-critic/examples/worked-run/critiques/round-1/shot_02.critique.json
skills/visual-asset-critic/examples/worked-run/critiques/round-2/shot_02.critique.json
skills/visual-asset-critic/examples/worked-run/frames/round-1/shot_01.png
skills/visual-asset-critic/examples/worked-run/frames/round-1/shot_02.png
skills/visual-asset-critic/examples/worked-run/frames/round-2/shot_02.png
skills/visual-asset-critic/examples/worked-run/preview.html
skills/visual-asset-critic/examples/worked-run/prompts/round-1/flux.txt
skills/visual-asset-critic/examples/worked-run/prompts/round-2/revised-flux.txt
skills/visual-asset-critic/examples/worked-run/run.json
skills/visual-asset-critic/examples/worked-run/shots.json
skills/visual-asset-critic/examples/worked-run/text-overlays.json
skills/visual-asset-critic/references/critique-rubric.md
skills/visual-asset-critic/templates/critique.schema.json
skills/visual-asset-critic/tools/README.md
skills/visual-asset-critic/tools/_shotkit.py
skills/visual-asset-critic/tools/_template.py
skills/visual-asset-critic/tools/check.sh
skills/visual-asset-critic/tools/copy-prompt.py
skills/visual-asset-critic/tools/shots-to-html.py
skills/visual-asset-critic/tools/validate_brand_lock.py
skills/visual-asset-critic/tools/validate_capabilities.py
skills/visual-asset-critic/tools/validate_critique.py
skills/visual-asset-critic/tools/validate_prompts.py
skills/visual-asset-critic/tools/validate_provenance.py
skills/visual-asset-critic/tools/validate_schemas.py
skills/visual-asset-critic/tools/validate_shots.py
skills/visual-asset-critic/tools/validate_skills.py
skills/visual-media/SKILL.md
skills/visual-prompt-forge/LICENSE
skills/visual-prompt-forge/SKILL.md
skills/visual-prompt-forge/adapters/_capabilities.json
skills/visual-prompt-forge/adapters/capabilities.schema.json
skills/visual-prompt-forge/adapters/flux.md
skills/visual-prompt-forge/adapters/gpt-image.md
skills/visual-prompt-forge/adapters/hailuo.md
skills/visual-prompt-forge/adapters/ideogram.md
skills/visual-prompt-forge/adapters/kling.md
skills/visual-prompt-forge/adapters/midjourney.md
skills/visual-prompt-forge/adapters/nano-banana.md
skills/visual-prompt-forge/adapters/seedance.md
skills/visual-prompt-forge/adapters/seedream.md
skills/visual-prompt-forge/adapters/veo.md
skills/visual-prompt-forge/examples/one-shot-all-adapters/README.md
skills/visual-prompt-forge/examples/one-shot-all-adapters/flux.txt
skills/visual-prompt-forge/examples/one-shot-all-adapters/gpt-image.txt
skills/visual-prompt-forge/examples/one-shot-all-adapters/ideogram.txt
skills/visual-prompt-forge/examples/one-shot-all-adapters/kling.txt
skills/visual-prompt-forge/examples/one-shot-all-adapters/midjourney.txt
skills/visual-prompt-forge/examples/one-shot-all-adapters/nano-banana.txt
skills/visual-prompt-forge/examples/one-shot-all-adapters/seedream.txt
skills/visual-prompt-forge/references/consistency-locks.md
skills/visual-prompt-forge/references/failure-modes.md
skills/visual-prompt-forge/references/prompt-anatomy.md
skills/visual-prompt-forge/tools/README.md
skills/visual-prompt-forge/tools/_shotkit.py
skills/visual-prompt-forge/tools/_template.py
skills/visual-prompt-forge/tools/check.sh
skills/visual-prompt-forge/tools/copy-prompt.py
skills/visual-prompt-forge/tools/shots-to-html.py
skills/visual-prompt-forge/tools/validate_brand_lock.py
skills/visual-prompt-forge/tools/validate_capabilities.py
skills/visual-prompt-forge/tools/validate_critique.py
skills/visual-prompt-forge/tools/validate_prompts.py
skills/visual-prompt-forge/tools/validate_provenance.py
skills/visual-prompt-forge/tools/validate_schemas.py
skills/visual-prompt-forge/tools/validate_shots.py
skills/visual-prompt-forge/tools/validate_skills.py
```

Total: 274 archivos.

## Licencias

- `video` e `image` (smixs) son CC BY 4.0 — atribución obligatoria a **Serge Shima — github.com/smixs/visual-skills**, incluida en derivados generados por agentes. Ver `LICENSE` y `NOTICE` dentro de cada uno.
- Las skills shotkit (`storyboard-architect`, `visual-prompt-forge`, `visual-asset-critic`, `brand-lock-extractor`, `storyboard-html-preview`) traen su propio `LICENSE`.
- `ai-production-director` es Apache-2.0, autoría Final Upgrade AI.

<!-- SOURCE_FILE_END: INDEX.md -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/README.md -->
# SOURCE FILE: `repo/.claude/hooks/README.md`

# Gates de producción — enforcement fuera del modelo

Seis hooks que hacen ejecutables reglas que los skills ya declaraban obligatorias.
La diferencia no es de redacción: una regla escrita en un SKILL.md es una decisión
que el modelo vuelve a tomar en cada turno; en un hook corre fuera del modelo y
devuelve `exit 2`, y el turno no cierra.

No se agrega ninguna herramienta externa. Todos delegan en material que ya vive
dentro del pipeline instalado.

## Qué hace cada gate

| Gate | Evento | Autoridad | Delega en |
|---|---|---|---|
| `gate_dramaturgy.py` | `Stop` | `ai-production-director` §6.1 | `video/references/dramaturgy.md`, sección *"What is banned"* |
| `gate_image.py` | `Stop` | `ai-production-director` Etapa 5 y §6.2 | `image/references/golden-rules.md` |
| `gate_shots.py` | `PostToolUse` (Write/Edit) | `ai-production-director` Etapa 4 | `storyboard-architect/tools/validate_shots.py` |
| `gate_microgate.py` | `Stop` | `produccion-visual-sw30` §MICRO-GATE | la cabecera de 3 líneas |
| `inject_rules.py` | `UserPromptSubmit` | `produccion-visual-sw30` §PREGUNTA DE AVANCE | inyecta las fuentes completas |

## El gate que importa más que los demás

Los otros cinco inspeccionan la salida. Ninguno toca la falla real: **qué se lee**.
Mientras leer sea una elección, se puede seguir eligiendo saltarse la parte que
importa — que es exactamente lo que pasó en la sesión donde se construyó esto:
`produccion-visual-sw30` estaba instalado desde el primer minuto, su descripción
dice "APLICAR ANTES de producir" y dispara con la palabra "gate", y no se abrió
hasta que el usuario lo señaló dos veces.

`inject_rules.py` quita la elección. En cualquier prompt que toque producción
visual inyecta las fuentes que gobiernan, **completas y verbatim** — el criterio
que el propio skill exige: *"leídos COMPLETOS todos los archivos del skill
aplicables al caso, no fragmentos ni grep"*. Hoy son 41,226 caracteres para un
caso de imagen: `produccion-visual-sw30`, `ai-production-director`, `image/SKILL.md`
y `golden-rules.md`. Lo que no quepa en presupuesto se nombra explícitamente en
la cabecera de la inyección, para que una omisión no pueda pasar en silencio.

`gate_microgate.py` hace efectiva la línea *"Entrega sin cabecera = inválida"*:
sin las 3 líneas `SKILL:` / `RIESGOS:` / `TÉCNICA:` el turno no cierra. Y `SKILL:`
tiene que nombrar un archivo `.md` que exista de verdad en los skills instalados,
así que una cabecera de relleno se rechaza igual que la ausencia de cabecera.

**`gate_image.py`** aplica las golden rules del skill `image` a prompts de imagen,
con los verbos parseados del archivo en tiempo de ejecución:

| Check | Regla | Efecto |
|---|---|---|
| R1 | *Start with a Verb* | bloquea |
| R4 | *Natural Language* (keyword soup) | bloquea |
| §6.2 | modelo destino declarado | bloquea |
| R2 | *Positive Framing* | **advierte** |

R2 no bloquea a propósito: el ejemplo aprobado del propio skill dice `no makeup`,
así que una detección estricta de negaciones rechazaría prompts que el skill
bendice. Se reporta como contexto, no como veto.

Si el mensaje nombra un modelo de video (Kling, Veo, Sora, Seedance…) y ninguno de
imagen, este gate no opina — ese prompt es de `gate_dramaturgy.py`.

**`gate_dramaturgy.py`** lee la lista prohibida del skill `video` **en tiempo de
ejecución**. No hay copia. Si editas `dramaturgy.md`, el gate cambia contigo.
Hoy extrae 11 términos: `cinematic`, `professional`, `high quality`, `masterpiece`,
`stunning`, `epic`, `amazing`, `beautiful lighting`, `dynamic camera`,
`intense moment`, `powerful scene`.

Sólo escanea **bloques de código cercados** del mensaje final. Explicar la regla en
prosa no dispara nada; entregar un prompt sí. Escape auditable, con la misma
sintaxis que el pipeline ya usa:

```
OVERRIDE: cinematic - el tagline on-screen del cliente lo exige
```

**`gate_shots.py`** corre `validate_shots.py` cada vez que se escribe un
`shots.json` o `text-overlays.json`, y repara antes dos defectos de empaquetado que
impedían que ese gate corriera **jamás** en una instalación synced:

1. `jsonschema` ausente — el validador salía `1` por la razón equivocada.
2. `_shotkit.py` fija `REPO_ROOT` al directorio del skill y luego le concatena
   `skills/storyboard-architect/…`, un layout que sólo existe si shotkit está
   instalado como repo. El hook recrea ese layout con symlinks aditivos en cada
   corrida, así que un re-sync del skill no deja el gate roto de forma permanente.

Ninguno de los dos modifica el contenido de tus skills.

## Verificación

No hace falta creerle a nadie:

```bash
bash .claude/hooks/verify.sh
```

34 casos, cada uno afirmando un exit code concreto — bloqueo, paso limpio,
override, anti-deadlock, auto-reparación del shim y supervivencia a payloads
corruptos. Si un gate deja de funcionar, esto falla en voz alta en vez de dejar
pasar prompts en silencio.

## Cobertura real — el número que ningún gate verde reemplaza

`produccion-visual-sw30/SKILL.md` §"Sistema de cobertura de reglas" documenta la
causa raíz: *"el catálogo de reglas salía de la memoria y cubría 26 de 209
enunciados de la fuente (12%)"*, y especifica la cadena que lo rompe
(`rule_registry.py`, `rule_ledger.py`, `audit_gi2.py`).

**Ninguno de esos scripts existía.** Ni `production-package/`, ni `RULES_MATRIX.md`.
El skill que dice *"la fuente manda, no la memoria"* era, él mismo, sólo memoria —
incluyendo su línea de estado *"124 reglas aplicables · 0 pendientes · 100%
dispuesto"*, que no podía ser cierta sin un ledger que la calculara.

`rule_registry.py` y `rule_ledger.py` se construyen aquí, según esa especificación.

### Medición

```
$ python3 .claude/hooks/rule_registry.py --skill image --stats
enunciados: 194          # el skill medía 209 con su propio extractor
```

Pipeline completo: **1,263 enunciados normativos** (1,213 únicos tras deduplicar
los repetidos entre skills), repartidos así:

| skill | reglas | | skill | reglas |
|---|---:|---|---|---:|
| `video` | 363 | | `brand-lock-extractor` | 90 |
| `image` | 194 | | `visual-asset-critic` | 64 |
| `visual-prompt-forge` | 181 | | `screenwriter` | 58 |
| `storyboard-architect` | 178 | | `produccion-visual-sw30` | 46 |
| `ai-video-storyboard` | 36 | | `ai-production-director` | 27 |
| `storyboard-html-preview` | 25 | | `visual-media` | 1 |

**Los gates de este repo verifican 26 controles = 2.1% de esa superficie.** Una
suite en 27/27 verde no cambia ese número, y presentarla sin él induce a error.

### Cómo se usa el ledger

```bash
python3 .claude/hooks/rule_registry.py --skill image --out reg.json --stats
python3 .claude/hooks/rule_ledger.py --registry reg.json --dispositions disp.json
```

Cada regla necesita disposición explícita o queda `PENDING`, y una sola `PENDING`
cierra el gate con `exit 1`. `CHECK` exige el campo `by` (qué la verifica), `NA`
exige `reason` escrita. Una disposición cuyo id ya no está en el registro se
reporta `STALE`: el texto de origen cambió y la afirmación dejó de cubrir algo.

Los ids son `sha1(ruta + texto normalizado)`, así que sobreviven a que se muevan
líneas y cambian cuando cambia la redacción. Esa es justo la propiedad que impide
heredar una cobertura vieja sobre un skill nuevo.

## Dos contradicciones encontradas en los skills

Salieron al calibrar el gate de imagen contra los ejemplos que el propio skill
marca con ✅. No las resuelve el gate — son cosas a decidir en los skills.

1. **El ejemplo ✅ de la Regla 4 de `image` viola la Regla 1 y §6.1.**
   `"A cinematic wide shot of a futuristic sports car…"` empieza con `A` en vez de
   un verbo, y usa `cinematic`, que §6.1 declara prohibido y que "gana siempre".
   El gate lo bloquea. Es coherente con el director; el ejemplo es el que está mal.

2. **CORRECCIÓN.** En esta sesión se afirmó que el skill `image` no tenía lista de
   vocabulario prohibido propia. **Es falso.** Está en
   `image/references/gpt-image.md:36` — *stunning, incredible, epic, gorgeous,
   masterpiece* — y `models.md:49` añade que en GPT Image 2 esas palabras empeoran
   el resultado mientras que Nano Banana las ignora. El error vino de buscar
   encabezados con grep en vez de leer los archivos, que es justo lo que
   `image/SKILL.md:18` advierte. `gate_dramaturgy.py` ahora lee ambas fuentes.

## Estado de verificación — honesto

**Probado en ejecución:**

- Los 34 casos de `verify.sh` pasan, y la suite es idempotente en corridas seguidas.
- `gate_dramaturgy.py` bloquea con `exit 2` un prompt con vocabulario prohibido y
  deja pasar uno limpio, prosa y overrides. Probado con prompts de imagen
  (Nano Banana Pro, GPT Image 2) además de video.
- `gate_image.py` bloquea keyword soup, falta de verbo inicial y prompts sin modelo
  destino; deja pasar los ejemplos aprobados del skill e ignora prompts de video.
- `gate_shots.py` bloquea con `exit 2` un `shots.json` con solape de timing y con
  hueco de timing, señalando el shot exacto.
- `validate_shots.py --selftest` pasa sus 12 checks, y los 3 ejemplos incluidos en
  el skill validan una vez aplicado el shim (antes fallaban los 3).

**NO probado:**

- Que Claude Code dispare los hooks automáticamente. En la sesión donde se
  construyeron, `.claude/` no existía al arrancar y los hooks de proyecto se cargan
  al inicio de sesión, así que el harness no los invocó. Los scripts se probaron
  alimentándoles el payload documentado por stdin, que es el mismo contrato.

Cómo cerrar ese hueco tú mismo, en una sesión **nueva** de Claude Code sobre este
repo: pide un prompt de video que incluya la palabra `cinematic`. Si el gate está
cargado, el turno no cierra y ves el reporte de bloqueo. Si cierra normalmente, los
hooks no se cargaron y no hay enforcement — mejor saberlo con una prueba de diez
segundos que en medio de una producción.

## Requisito

```bash
pip install pyyaml jsonschema --break-system-packages
```

Sin `jsonschema`, `gate_shots.py` lo dice y sale `1` (error visible, no bloqueo
silencioso). Nunca finge haber validado.

## Límites reales

- El gate de vocabulario es léxico. Atrapa `cinematic`; no atrapa un shot sin los
  tres detalles que exige `dramaturgy.md` §2 — eso es semántico y ningún gate
  determinista lo resuelve. Cubre el modo de fallo más frecuente, no todos.
- Un prompt entregado fuera de un bloque de código no se escanea. Es el precio de
  no tener falsos positivos sobre prosa.
- Los hooks son de Claude Code. En el chat de claude.ai no existen, y ahí estos
  gates no aplican.

<!-- SOURCE_FILE_END: repo/.claude/hooks/README.md -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/export_xlsx.py -->
# SOURCE FILE: `repo/.claude/hooks/export_xlsx.py`

#!/usr/bin/env python3
"""Exporta rules.sqlite a un .xlsx con una hoja por caso de produccion.

Las hojas por caso son las que se usan a diario: abres T1 y ves las reglas de
un maestro de rostro. La columna ORIGEN dice de donde salio cada clasificacion,
que es lo que permite no tener que creerle a nadie.

Uso:
    python3 export_xlsx.py --db rules.sqlite --out reglas-produccion.xlsx
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

FUENTE = "Arial"
AZUL = "1F3864"      # cabeceras
GRIS = "F2F2F2"      # bandas
AMBAR = "FFF2CC"     # clasificacion gruesa, menos confiable
VERDE = "E2EFDA"     # corregida por auditoria externa

CASOS_ORDEN = ["T1", "T2", "T3", "T4", "T5", "PROD", "GRAF", "MULTI", "REF",
               "CLIP", "SHOT", "GUION", "MARCA", "QA", "ENTREGA", "NINGUNO"]

BORDE = Border(*[Side(style="thin", color="D0D0D0")] * 4)


def cabecera(ws, titulos, ancho):
    for i, t in enumerate(titulos, 1):
        c = ws.cell(row=1, column=i, value=t)
        c.font = Font(name=FUENTE, bold=True, color="FFFFFF", size=10)
        c.fill = PatternFill("solid", fgColor=AZUL)
        c.alignment = Alignment(vertical="center", horizontal="left")
        c.border = BORDE
        ws.column_dimensions[get_column_letter(i)].width = ancho[i - 1]
    ws.row_dimensions[1].height = 22
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(titulos))}1"


def escribir(ws, filas, resaltar_origen=True):
    for r, fila in enumerate(filas, start=2):
        for c, val in enumerate(fila, start=1):
            cel = ws.cell(row=r, column=c, value=val)
            cel.font = Font(name=FUENTE, size=10)
            cel.alignment = Alignment(vertical="top")
            cel.border = BORDE
        if resaltar_origen:
            origen = fila[-1]
            if origen == "archivo":
                relleno = PatternFill("solid", fgColor=AMBAR)
            elif origen == "auditoria":
                relleno = PatternFill("solid", fgColor=VERDE)
            else:
                relleno = PatternFill("solid", fgColor=GRIS) if r % 2 == 0 else None
            if relleno:
                for c in range(1, len(fila) + 1):
                    ws.cell(row=r, column=c).fill = relleno


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="rules.sqlite")
    ap.add_argument("--out", default="reglas-produccion.xlsx")
    a = ap.parse_args()

    con = sqlite3.connect(a.db)
    wb = Workbook()

    # ---------------------------------------------------------- RESUMEN
    ws = wb.active
    ws.title = "RESUMEN"
    ws["A1"] = "Base de reglas del pipeline de produccion visual"
    ws["A1"].font = Font(name=FUENTE, bold=True, size=14, color=AZUL)
    ws["A2"] = "Una hoja por caso. Abre T1 para un maestro de rostro, CLIP para un prompt de video."
    ws["A2"].font = Font(name=FUENTE, size=10, italic=True)

    ws["A4"] = "COMO LEER LA COLUMNA ORIGEN"
    ws["A4"].font = Font(name=FUENTE, bold=True, size=11)
    leyenda = [
        ("regla", "Clasificada una por una. Mas confiable.", GRIS),
        ("auditoria", "Corregida por un criterio externo. Manda sobre las otras dos.", VERDE),
        ("archivo", "Clasificacion gruesa por defecto del archivo. Revisar antes de confiar.", AMBAR),
    ]
    for i, (cod, desc, color) in enumerate(leyenda, start=5):
        ws.cell(row=i, column=1, value=cod).font = Font(name=FUENTE, bold=True, size=10)
        ws.cell(row=i, column=1).fill = PatternFill("solid", fgColor=color)
        ws.cell(row=i, column=2, value=desc).font = Font(name=FUENTE, size=10)

    fila = 10
    ws.cell(row=fila, column=1, value="CASO").font = Font(name=FUENTE, bold=True, color="FFFFFF")
    ws.cell(row=fila, column=1).fill = PatternFill("solid", fgColor=AZUL)
    for j, t in enumerate(["REGLAS", "DESCRIPCION"], start=2):
        ws.cell(row=fila, column=j, value=t).font = Font(name=FUENTE, bold=True, color="FFFFFF")
        ws.cell(row=fila, column=j).fill = PatternFill("solid", fgColor=AZUL)

    primera = fila + 1
    for cod in CASOS_ORDEN:
        r = con.execute(
            "SELECT (SELECT descripcion FROM casos WHERE codigo=?),"
            " (SELECT COUNT(*) FROM regla_caso WHERE caso=?)", (cod, cod)).fetchone()
        if not r[1]:
            continue
        fila += 1
        ws.cell(row=fila, column=1, value=cod).font = Font(name=FUENTE, bold=True, size=10)
        ws.cell(row=fila, column=2, value=r[1]).font = Font(name=FUENTE, size=10)
        ws.cell(row=fila, column=3, value=r[0]).font = Font(name=FUENTE, size=10)
    ws.cell(row=fila + 1, column=1, value="Suma de asignaciones").font = Font(name=FUENTE, bold=True)
    ws.cell(row=fila + 1, column=2, value=f"=SUM(B{primera}:B{fila})").font = Font(name=FUENTE, bold=True)

    fila += 3
    tot = con.execute("SELECT COUNT(*) FROM reglas").fetchone()[0]
    aud = con.execute("SELECT COUNT(*) FROM auditorias").fetchone()[0]
    for etiqueta, valor in [
        ("Reglas unicas en la base", tot),
        ("Correcciones de auditoria registradas", aud),
        ("Skills de origen", con.execute("SELECT COUNT(*) FROM skills").fetchone()[0]),
        ("Archivos .md con sha256", con.execute("SELECT COUNT(*) FROM archivos").fetchone()[0]),
        ("Conflictos entre reglas registrados", con.execute("SELECT COUNT(*) FROM conflictos").fetchone()[0]),
    ]:
        ws.cell(row=fila, column=1, value=etiqueta).font = Font(name=FUENTE, size=10)
        ws.cell(row=fila, column=2, value=valor).font = Font(name=FUENTE, bold=True, size=10)
        fila += 1

    ws.column_dimensions["A"].width = 40
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 62

    # ------------------------------------------------- UNA HOJA POR CASO
    for cod in CASOS_ORDEN:
        filas = con.execute(
            """SELECT r.skill, r.archivo, r.linea, r.texto, rc.origen
               FROM regla_caso rc JOIN reglas r ON r.id = rc.regla_id
               WHERE rc.caso = ? ORDER BY r.skill, r.archivo, r.linea""", (cod,)).fetchall()
        if not filas:
            continue
        ws = wb.create_sheet(cod)
        cabecera(ws, ["SKILL", "ARCHIVO", "LINEA", "REGLA", "ORIGEN"],
                 [24, 38, 8, 105, 12])
        escribir(ws, filas)

    # ------------------------------------------------------ TODAS LAS REGLAS
    ws = wb.create_sheet("TODAS")
    cabecera(ws, ["ID", "SKILL", "ARCHIVO", "LINEA", "REGLA", "CASOS", "ORIGEN"],
             [15, 24, 38, 8, 95, 34, 12])
    escribir(ws, con.execute(
        """SELECT r.id, r.skill, r.archivo, r.linea, r.texto,
                  GROUP_CONCAT(rc.caso), MIN(rc.origen)
           FROM reglas r LEFT JOIN regla_caso rc ON rc.regla_id = r.id
           GROUP BY r.id ORDER BY r.skill, r.archivo, r.linea""").fetchall())

    # ------------------------------------------------------------ AUDITORIAS
    ws = wb.create_sheet("AUDITORIAS")
    cabecera(ws, ["ID", "ANTES", "DESPUES", "AUDITOR", "RAZON", "REGLA"],
             [15, 30, 30, 14, 60, 85])
    escribir(ws, con.execute(
        """SELECT a.regla_id, a.antes, a.despues, a.auditor, a.razon, g.texto
           FROM auditorias a JOIN reglas g ON g.id = a.regla_id ORDER BY a.rowid"""
        ).fetchall(), resaltar_origen=False)

    # ------------------------------------------------------------ CONFLICTOS
    filas = con.execute(
        """SELECT ra.texto, rb.texto, c.tipo, c.autoridad
           FROM conflictos c JOIN reglas ra ON ra.id = c.regla_a
           JOIN reglas rb ON rb.id = c.regla_b""").fetchall()
    if filas:
        ws = wb.create_sheet("CONFLICTOS")
        cabecera(ws, ["REGLA A (gana)", "REGLA B", "TIPO", "AUTORIDAD"], [70, 70, 16, 70])
        escribir(ws, filas, resaltar_origen=False)

    # --------------------------------------------------------------- FUENTES
    ws = wb.create_sheet("FUENTES")
    cabecera(ws, ["SKILL", "ARCHIVO", "REGLAS", "SHA256"], [26, 46, 10, 68])
    escribir(ws, con.execute(
        "SELECT skill, ruta, reglas, sha256 FROM archivos ORDER BY skill, ruta").fetchall(),
        resaltar_origen=False)

    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    wb.save(a.out)
    print(f"{a.out}: {len(wb.sheetnames)} hojas -> {', '.join(wb.sheetnames)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/export_xlsx.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/gate_dramaturgy.py -->
# SOURCE FILE: `repo/.claude/hooks/gate_dramaturgy.py`

#!/usr/bin/env python3
"""Stop hook: blocks delivery of visual prompts that carry banned vocabulary.

Authority chain (ai-production-director SKILL.md section 6.1):
    "El vocabulario prohibido de `video`/dramaturgy ... gana siempre"

The banned list is read at runtime from the `video` skill itself
(references/dramaturgy.md, section "What is banned"), so editing the skill
updates the gate. Nothing is hardcoded and nothing is copied.

Scope rule: only fenced code blocks in the final assistant message are
scanned. Prose that merely discusses a banned word is not a delivery.

Escape hatch: a line matching `OVERRIDE: <term> - <reason>` anywhere in the
message clears that term for the current turn, and stays visible in the
transcript for audit.
"""

import json
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prompt_detect import visual_blocks  # noqa: E402

SKILLS_ROOT = Path(
    os.environ.get("FUPAI_SKILLS_ROOT", Path.home() / ".claude" / "skills" / "synced")
)
MAX_CONSECUTIVE_BLOCKS = 3

FENCE_RE = re.compile(r"```[^\n]*\n(.*?)```", re.DOTALL)
OVERRIDE_RE = re.compile(r"^\s*OVERRIDE:\s*(.+?)\s+-\s+(.+?)\s*$", re.MULTILINE)
# Terms inside the "What is banned" section are quoted: - "cinematic", "epic"
QUOTED_RE = re.compile(r'"([^"]{2,40})"')


def find_antislop() -> Path | None:
    """image/references/gpt-image.md carries its own '## Anti-Slop Rules' table."""
    for pattern in ("*/image/references/gpt-image.md", "*/*/image/references/gpt-image.md"):
        for candidate in SKILLS_ROOT.glob(pattern):
            return candidate
    return None


def load_antislop(path: Path) -> list[str]:
    """Read the left (❌) column of the Anti-Slop table. Mechanical, not copied."""
    text = path.read_text(encoding="utf-8")
    start = text.find("## Anti-Slop Rules")
    if start == -1:
        return []
    rest = text[start:]
    end = rest.find("\n## ", 3)
    section = rest if end == -1 else rest[:end]

    terms: list[str] = []
    for line in section.splitlines():
        if not line.strip().startswith("|") or "---" in line:
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 2 or "❌" in cells[0]:
            continue  # header row
        # Only plain comma-separated word lists; prose examples are not terms.
        if any(ch in cells[0] for ch in "«»\"'"):
            continue
        for part in cells[0].split(","):
            part = part.strip().lower()
            if part and 2 < len(part) < 30 and " " not in part.strip():
                terms.append(part)
    return terms


def find_dramaturgy() -> Path | None:
    """Locate video/references/dramaturgy.md under any synced skill root."""
    for candidate in SKILLS_ROOT.glob("*/video/references/dramaturgy.md"):
        return candidate
    for candidate in SKILLS_ROOT.glob("*/*/video/references/dramaturgy.md"):
        return candidate
    return None


def load_banned(path: Path) -> list[str]:
    """Extract the quoted terms under the '### What is banned' heading."""
    text = path.read_text(encoding="utf-8")
    start = text.find("### What is banned")
    if start == -1:
        return []
    rest = text[start + len("### What is banned"):]
    end = rest.find("\n### ")
    section = rest if end == -1 else rest[:end]

    terms: list[str] = []
    for raw in QUOTED_RE.findall(section):
        term = raw.strip().lower()
        # Split compound entries such as "cinematic, professional, high quality"
        for part in term.split(","):
            part = part.strip()
            # Drop the illustrative emotion examples, which are patterns not terms
            if part and not part.startswith(("he is", "she is")):
                terms.append(part)
    return sorted(set(terms), key=len, reverse=True)


def state_path(session_id: str) -> Path:
    d = Path(os.environ.get("TMPDIR", "/tmp")) / "fupai-gate"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{re.sub(r'[^A-Za-z0-9_-]', '_', session_id)}.count"


STATE_TTL_S = 3600


def read_count(p: Path) -> int:
    """Consecutive blocks, ignoring state left over from an older session."""
    try:
        count, stamp = p.read_text().split(":")
        if time.time() - float(stamp) > STATE_TTL_S:
            return 0
        return int(count)
    except Exception:
        return 0


def write_count(p: Path, n: int) -> None:
    try:
        p.write_text(f"{n}:{time.time()}")
    except OSError:
        pass


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception as exc:
        print(f"gate_dramaturgy: unreadable hook payload: {exc}", file=sys.stderr)
        return 1  # non-blocking error, visible in transcript

    message = payload.get("last_assistant_message") or ""
    session_id = payload.get("session_id") or "nosession"
    counter = state_path(session_id)

    blocks = visual_blocks(message)
    if not blocks:
        write_count(counter, 0)
        return 0

    dramaturgy = find_dramaturgy()
    if dramaturgy is None:
        print(
            "gate_dramaturgy: video/references/dramaturgy.md not found under "
            f"{SKILLS_ROOT}. Gate could not run — vocabulary was NOT checked.",
            file=sys.stderr,
        )
        return 1  # fail loud, never silently pass as if checked

    banned = load_banned(dramaturgy)
    sources = [str(dramaturgy)]

    # Segunda autoridad: la lista Anti-Slop del propio skill image. Se lee de la
    # fuente igual que la anterior; no se transcribe aqui.
    antislop_path = find_antislop()
    if antislop_path is not None:
        extra = [t for t in load_antislop(antislop_path) if t not in banned]
        if extra:
            banned = sorted(set(banned + extra), key=len, reverse=True)
            sources.append(str(antislop_path))

    if not banned:
        print(
            f"gate_dramaturgy: no banned terms parsed from {dramaturgy}. "
            "Gate could not run — vocabulary was NOT checked.",
            file=sys.stderr,
        )
        return 1

    overridden = {m.group(1).strip().lower() for m in OVERRIDE_RE.finditer(message)}

    violations: list[tuple[int, str, str]] = []
    for idx, block in blocks:
        low = block.lower()
        for term in banned:
            if term in overridden:
                continue
            if re.search(rf"(?<![a-z]){re.escape(term)}(?![a-z])", low):
                line = next(
                    (l.strip() for l in block.splitlines() if term in l.lower()), ""
                )
                violations.append((idx, term, line[:110]))

    if not violations:
        write_count(counter, 0)
        return 0

    seen = read_count(counter)
    if seen >= MAX_CONSECUTIVE_BLOCKS:
        write_count(counter, 0)
        print(
            f"gate_dramaturgy: {len(violations)} violation(s) still present after "
            f"{seen} blocked attempts. Releasing the turn so the session does not "
            "deadlock. THE PROMPT BELOW IS NOT CLEARED — do not spend credits on it.",
            file=sys.stderr,
        )
        return 1

    write_count(counter, seen + 1)

    report = [
        "DELIVERY BLOCKED — banned vocabulary (ai-production-director 6.1).",
        "Authority: " + " + ".join(sources),
        "",
    ]
    for idx, term, line in violations:
        report.append(f'  FAIL  block #{idx}  "{term}"')
        if line:
            report.append(f"        -> {line}")
    report += [
        "",
        "Each banned word is a placeholder for absent detail. Replace it with the",
        "three details dramaturgy.md requires: environmental pressure, physical",
        "micro-action, sound/visual anchor. Then deliver again.",
        "",
        "If a term is deliberate, add a line: OVERRIDE: <term> - <reason>",
        f"(attempt {seen + 1} of {MAX_CONSECUTIVE_BLOCKS})",
    ]
    print("\n".join(report), file=sys.stderr)
    return 2  # blocking: Claude does not stop, sees stderr, must fix


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/gate_dramaturgy.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/gate_image.py -->
# SOURCE FILE: `repo/.claude/hooks/gate_image.py`

#!/usr/bin/env python3
"""Stop hook: enforces the image skill's own golden rules on delivered prompts.

Authority chain:
  ai-production-director, Etapa 5 -> "`image` (smixs) es la autoridad de sintaxis
  final por modelo", and section 6.2 -> "Todo prompt FINAL se escribe en la
  sintaxis del modelo destino segun el archivo smixs correspondiente."

Checks, each one traced to a rule in image/references/golden-rules.md:

  R1  Start with a Verb   blocking   verbs parsed from the file at runtime
  R4  Natural Language    blocking   keyword soup ("Cool car, neon, city, 8k")
  6.2 Target model named  blocking   a final prompt with no declared model
  R2  Positive Framing    warning    see the note below

R2 is deliberately non-blocking. The skill's own approved example carries
"no makeup", so a strict negation check would reject prompts the skill blesses.
It is reported as context instead of a veto.

Runs alongside gate_dramaturgy.py, which owns the section 6.1 vocabulary.
"""

import json
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prompt_detect import visual_blocks, IMAGE_MODELS, VIDEO_MODELS  # noqa: E402

SKILLS_ROOT = Path(
    os.environ.get("FUPAI_SKILLS_ROOT", Path.home() / ".claude" / "skills" / "synced")
)
MAX_CONSECUTIVE_BLOCKS = 3

FENCE_RE = re.compile(r"```[^\n]*\n(.*?)```", re.DOTALL)
QUOTED_RE = re.compile(r'"([A-Za-z][A-Za-z ]{1,20})"')
OVERRIDE_RE = re.compile(r"^\s*OVERRIDE:\s*(.+?)\s+-\s+(.+?)\s*$", re.MULTILINE)

# Model ids the pipeline knows. Sources: image/SKILL.md (Nano Banana, GPT Image 2)
# and ai-production-director 6.2 (Flux, Midjourney, Ideogram via forge adapters).
IMAGE_MODELS = (
    "nano banana", "nano-banana", "nanobanana", "nbp", "nb2",
    "gpt image", "gpt-image", "seedream", "midjourney", "flux", "ideogram",
)
# Naming any of these means the block is a motion prompt; the image rules do not apply.
VIDEO_MODELS = ("kling", "veo", "sora", "seedance", "hailuo", "runway", "luma", "pika")

NEGATION_RE = re.compile(r"\b(?:no|without|not)\s+[a-z]", re.IGNORECASE)


def find_golden_rules() -> Path | None:
    for pattern in ("*/image/references/golden-rules.md",
                    "*/*/image/references/golden-rules.md"):
        for candidate in SKILLS_ROOT.glob(pattern):
            return candidate
    return None


def load_verbs(path: Path) -> list[str]:
    """Parse the approved opening verbs from the '## 1. Start with a Verb' rule."""
    text = path.read_text(encoding="utf-8")
    start = text.find("## 1. Start with a Verb")
    if start == -1:
        return []
    rest = text[start:]
    end = rest.find("\n## ")
    section = rest if end == -1 else rest[:end]
    verbs = {v.strip().lower() for v in QUOTED_RE.findall(section) if v.strip()}
    return sorted(verbs)


def is_keyword_soup(line: str) -> bool:
    """Rule 4: 'Cool car, neon, city, night, 8k' — fragments, no sentence."""
    parts = [p.strip() for p in line.split(",") if p.strip()]
    if len(parts) < 4:
        return False
    if line.rstrip().endswith("."):
        return False
    # A real sentence carries a finite verb; fragments are 1-3 bare words.
    return all(len(p.split()) <= 3 for p in parts)


def state_path(session_id: str) -> Path:
    d = Path(os.environ.get("TMPDIR", "/tmp")) / "fupai-gate"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"img-{re.sub(r'[^A-Za-z0-9_-]', '_', session_id)}.count"


STATE_TTL_S = 3600


def read_count(p: Path) -> int:
    """Consecutive blocks, ignoring state left over from an older session."""
    try:
        count, stamp = p.read_text().split(":")
        if time.time() - float(stamp) > STATE_TTL_S:
            return 0
        return int(count)
    except Exception:
        return 0


def write_count(p: Path, n: int) -> None:
    try:
        p.write_text(f"{n}:{time.time()}")
    except OSError:
        pass


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception as exc:
        print(f"gate_image: unreadable hook payload: {exc}", file=sys.stderr)
        return 1

    message = payload.get("last_assistant_message") or ""
    counter = state_path(payload.get("session_id") or "nosession")

    low_msg = message.lower()
    blocks = visual_blocks(message)
    if not blocks:
        write_count(counter, 0)
        return 0  # nada que sea entrega de prompt visual

    if any(m in low_msg for m in VIDEO_MODELS) and not any(m in low_msg for m in IMAGE_MODELS):
        write_count(counter, 0)
        return 0  # motion prompt; gate_dramaturgy still applies

    rules = find_golden_rules()
    if rules is None:
        print(
            f"gate_image: image/references/golden-rules.md not found under "
            f"{SKILLS_ROOT}. Gate could not run — image rules were NOT checked.",
            file=sys.stderr,
        )
        return 1

    verbs = load_verbs(rules)
    if not verbs:
        print(
            f"gate_image: no opening verbs parsed from {rules}. "
            "Gate could not run — image rules were NOT checked.",
            file=sys.stderr,
        )
        return 1

    overridden = {m.group(1).strip().lower() for m in OVERRIDE_RE.finditer(message)}
    model_named = any(m in low_msg for m in IMAGE_MODELS)

    def waived(rule: str) -> bool:
        return rule.lower() in overridden

    fails: list[str] = []
    warns: list[str] = []

    for idx, block in blocks:
        lines = [l for l in block.splitlines() if l.strip()]
        if not lines:
            continue

        first = lines[0].strip()
        if not waived("R1") and not any(
            first.lower().startswith(v) for v in verbs
        ):
            fails.append(
                f'  FAIL  block #{idx}  R1 Start with a Verb\n'
                f'        first line: "{first[:80]}"\n'
                f"        expected one of: {', '.join(verbs)}"
            )

        if not waived("R4"):
            for line in lines:
                if is_keyword_soup(line):
                    fails.append(
                        f"  FAIL  block #{idx}  R4 Natural Language (keyword soup)\n"
                        f'        -> "{line.strip()[:80]}"'
                    )
                    break

        if not waived("6.2") and not model_named:
            fails.append(
                f"  FAIL  block #{idx}  6.2 no target model declared\n"
                f"        name one of: {', '.join(IMAGE_MODELS[:6])}…"
            )

        for line in lines:
            if NEGATION_RE.search(line):
                warns.append(f'  WARN  block #{idx}  R2 Positive Framing -> "{line.strip()[:70]}"')
                break

    if not fails:
        write_count(counter, 0)
        if warns:
            # Non-blocking: exit 0 stdout is added as context Claude can see.
            print(
                "gate_image — advertencias (no bloquean):\n"
                + "\n".join(warns)
                + "\n  R2 pide describir lo que SI quieres. Revisa si aplica."
            )
        return 0

    seen = read_count(counter)
    if seen >= MAX_CONSECUTIVE_BLOCKS:
        write_count(counter, 0)
        print(
            f"gate_image: {len(fails)} violation(s) still present after {seen} blocked "
            "attempts. Releasing the turn so the session does not deadlock. "
            "THE PROMPT IS NOT CLEARED — do not spend credits on it.",
            file=sys.stderr,
        )
        return 1

    write_count(counter, seen + 1)
    report = [
        "DELIVERY BLOCKED — image golden rules.",
        f"Authority: {rules}",
        "",
        *fails,
    ]
    if warns:
        report += ["", *warns]
    report += [
        "",
        "Override with a line: OVERRIDE: R1 - <reason>  (R1 | R4 | 6.2)",
        f"(attempt {seen + 1} of {MAX_CONSECUTIVE_BLOCKS})",
    ]
    print("\n".join(report), file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/gate_image.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/gate_microgate.py -->
# SOURCE FILE: `repo/.claude/hooks/gate_microgate.py`

#!/usr/bin/env python3
"""Stop hook: enforce the 3-line micro-gate header on any visual delivery.

produccion-visual-sw30/SKILL.md:

    Antes de (a) cualquier generación que gaste créditos y (b) entregar cualquier
    prompt visual, la respuesta abre con exactamente 3 líneas:
      SKILL: <archivo y sección leídos EN ESTE turno>
      RIESGOS: <qué puede fallar y qué línea del prompt lo mitiga>
      TÉCNICA: <técnica probada encontrada y fuente, o "no encontrada">
    Entrega sin cabecera = inválida; Eric la rechaza sin leerla.

That rule is already unambiguous and already has a stated consequence. It was
still being skipped, because "invalid" was enforced by the reader noticing.
Here the turn does not close without the header.

Placeholder headers do not count: SKILL must name a real file that exists in the
installed skills, since the field asserts what was read this turn.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prompt_detect import visual_blocks  # noqa: E402

SKILLS_ROOT = Path(
    os.environ.get("FUPAI_SKILLS_ROOT", Path.home() / ".claude" / "skills" / "synced")
)
MAX_CONSECUTIVE_BLOCKS = 3
STATE_TTL_S = 3600

FENCE_RE = re.compile(r"```[^\n]*\n(.*?)```", re.DOTALL)
# A fenced block counts as a visual prompt when it names a target model or reads
# like a generation brief. Prose about prompts is not a delivery.
VISUAL_RE = re.compile(
    r"\b(nano ?banana|nb2|nbp|gpt ?image|midjourney|flux|ideogram|seedream|"
    r"kling|veo|sora|seedance|hailuo|runway|luma|pika)\b",
    re.IGNORECASE,
)
PROMPTISH_RE = re.compile(
    r"^\s*(create|generate|design|transform|convert|edit|wide shot|close-?up|"
    r"medium shot|mcu|ecu)\b|^\s*(format|aspect ratio|negative prompt)\s*:",
    re.IGNORECASE | re.MULTILINE,
)

HEADER_RE = re.compile(
    r"^\s*SKILL\s*:\s*(?P<skill>.+?)\s*\n"
    r"\s*RIESGOS\s*:\s*(?P<riesgos>.+?)\s*\n"
    r"\s*T[EÉ]CNICA\s*:\s*(?P<tecnica>.+?)\s*$",
    re.IGNORECASE | re.MULTILINE,
)

FILE_TOKEN_RE = re.compile(r"[\w./-]+\.md")


def state_path(session_id: str) -> Path:
    d = Path(os.environ.get("TMPDIR", "/tmp")) / "fupai-gate"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"mg-{re.sub(r'[^A-Za-z0-9_-]', '_', session_id)}.count"


def read_count(p: Path) -> int:
    try:
        count, stamp = p.read_text().split(":")
        if time.time() - float(stamp) > STATE_TTL_S:
            return 0
        return int(count)
    except Exception:
        return 0


def write_count(p: Path, n: int) -> None:
    try:
        p.write_text(f"{n}:{time.time()}")
    except OSError:
        pass


def skill_file_exists(token: str) -> bool:
    name = token.strip().lstrip("`").rstrip("`,.;")
    for pattern in (f"*/**/{name}", f"*/{name}"):
        for _ in SKILLS_ROOT.glob(pattern):
            return True
    return any(SKILLS_ROOT.glob(f"*/*/{Path(name).name}")) or any(
        SKILLS_ROOT.glob(f"*/*/*/{Path(name).name}")
    )


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception as exc:
        print(f"gate_microgate: unreadable hook payload: {exc}", file=sys.stderr)
        return 1

    message = payload.get("last_assistant_message") or ""
    counter = state_path(payload.get("session_id") or "nosession")

    delivers = visual_blocks(message)
    if not delivers:
        write_count(counter, 0)
        return 0

    match = HEADER_RE.search(message)
    problems: list[str] = []

    if match is None:
        problems.append(
            "  FAIL  falta la cabecera de 3 lineas. La respuesta debe ABRIR con:\n"
            "          SKILL: <archivo y seccion leidos EN ESTE turno>\n"
            "          RIESGOS: <que puede fallar y que linea del prompt lo mitiga>\n"
            "          TECNICA: <tecnica probada y fuente, o \"no encontrada\">"
        )
    else:
        skill_field = match.group("skill")
        tokens = FILE_TOKEN_RE.findall(skill_field)
        if not tokens:
            problems.append(
                f'  FAIL  SKILL: no nombra ningun archivo .md -> "{skill_field[:70]}"'
            )
        else:
            unknown = [t for t in tokens if not skill_file_exists(t)]
            if unknown:
                problems.append(
                    "  FAIL  SKILL: nombra archivos que no existen en los skills "
                    f"instalados: {', '.join(unknown)}"
                )
        for field in ("riesgos", "tecnica"):
            if len(match.group(field).strip()) < 12:
                problems.append(f"  FAIL  {field.upper()}: vacio o de relleno")

    if not problems:
        write_count(counter, 0)
        return 0

    seen = read_count(counter)
    if seen >= MAX_CONSECUTIVE_BLOCKS:
        write_count(counter, 0)
        print(
            f"gate_microgate: cabecera aun invalida tras {seen} bloqueos. Se libera el "
            "turno para no trabar la sesion. LA ENTREGA SIGUE SIENDO INVALIDA segun "
            "produccion-visual-sw30 — no gastes creditos con ella.",
            file=sys.stderr,
        )
        return 1

    write_count(counter, seen + 1)
    print(
        "\n".join(
            [
                "DELIVERY BLOCKED — micro-gate ausente o invalido.",
                "Autoridad: produccion-visual-sw30/SKILL.md, seccion MICRO-GATE",
                '"Entrega sin cabecera = invalida; Eric la rechaza sin leerla."',
                "",
                *problems,
                "",
                f"(intento {seen + 1} de {MAX_CONSECUTIVE_BLOCKS})",
            ]
        ),
        file=sys.stderr,
    )
    return 2


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/gate_microgate.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/gate_shots.py -->
# SOURCE FILE: `repo/.claude/hooks/gate_shots.py`

#!/usr/bin/env python3
"""PostToolUse hook: runs the shotkit validator whenever shots.json is written.

Authority chain (ai-production-director SKILL.md, Etapa 4):
    "Gate: `tools/validate_shots.py` limpio"

Two packaging defects stop that gate from ever running in a synced-skill
install, and this hook repairs both before delegating:

  1. `jsonschema` missing -> the validator exits 1 for the wrong reason.
     Detected and reported, never silently swallowed.
  2. `_shotkit.py` sets REPO_ROOT to the skill directory and then appends
     `skills/storyboard-architect/...`, a repo layout that a synced install
     does not have. An additive symlink shim is recreated on every run, so a
     skill re-sync cannot leave the gate permanently broken.

Nothing in the skill's own content is modified.
"""

import json
import os
import subprocess
import sys
from pathlib import Path

SKILLS_ROOT = Path(
    os.environ.get("FUPAI_SKILLS_ROOT", Path.home() / ".claude" / "skills" / "synced")
)
WATCHED = {"shots.json", "text-overlays.json"}


def find_architect() -> Path | None:
    for pattern in ("*/storyboard-architect", "*/*/storyboard-architect"):
        for candidate in SKILLS_ROOT.glob(pattern):
            if (candidate / "tools" / "validate_shots.py").is_file():
                return candidate
    return None


def heal_shim(architect: Path) -> None:
    """Recreate the layout _shotkit.py expects. Idempotent and additive."""
    shim = architect / "skills"
    shim.mkdir(exist_ok=True)
    links = {
        shim / "storyboard-architect": Path(".."),
        shim / "visual-prompt-forge": Path("../../visual-prompt-forge"),
    }
    for link, target in links.items():
        if link.is_symlink() and os.readlink(link) == str(target):
            continue
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(target)


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception as exc:
        print(f"gate_shots: unreadable hook payload: {exc}", file=sys.stderr)
        return 1

    tool_input = payload.get("tool_input") or {}
    written = tool_input.get("file_path") or tool_input.get("path") or ""
    if Path(written).name not in WATCHED:
        return 0

    target_dir = Path(written).parent
    if not (target_dir / "shots.json").is_file():
        return 0  # the set is not complete yet; nothing to validate

    architect = find_architect()
    if architect is None:
        print(
            f"gate_shots: storyboard-architect not found under {SKILLS_ROOT}. "
            "Etapa 4 gate did NOT run — shots.json is unvalidated.",
            file=sys.stderr,
        )
        return 1

    try:
        import jsonschema  # noqa: F401
    except ImportError:
        print(
            "gate_shots: jsonschema is not installed, so validate_shots.py cannot "
            "run and the Etapa 4 gate did NOT execute. Fix with:\n"
            "  pip install pyyaml jsonschema --break-system-packages",
            file=sys.stderr,
        )
        return 1

    try:
        heal_shim(architect)
    except OSError as exc:
        print(f"gate_shots: could not repair the shotkit path shim: {exc}", file=sys.stderr)
        return 1

    proc = subprocess.run(
        [sys.executable, str(architect / "tools" / "validate_shots.py"), str(target_dir)],
        capture_output=True,
        text=True,
        cwd=str(architect),
    )
    if proc.returncode == 0:
        return 0

    print(
        "ETAPA 4 GATE FAILED — shots.json is not the source of truth yet.\n"
        "ai-production-director: 'El gate se verifica ANTES de avanzar. Si falla, "
        "se corrige en la etapa actual — nunca se \"arregla despues\".'\n"
        "Do not write prompts against this shot list.\n\n"
        + (proc.stdout or "")
        + (proc.stderr or ""),
        file=sys.stderr,
    )
    return 2  # blocking: Claude sees stderr and must fix before continuing


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/gate_shots.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/inject_rules.py -->
# SOURCE FILE: `repo/.claude/hooks/inject_rules.py`

#!/usr/bin/env python3
"""UserPromptSubmit hook: put the mandatory rules in context before Claude chooses.

Every other gate in this directory inspects output. None of them touch the real
failure: which files get read. While reading is a choice the model makes, it can
keep choosing to skip the part that matters.

This hook removes the choice. On any prompt that touches visual production it
injects the governing files verbatim — not a summary, not a grep, which is what
produccion-visual-sw30/SKILL.md demands:

    "Exhaustiva" significa: leídos COMPLETOS todos los archivos del skill
    aplicables al caso (SKILL.md indica el orden obligatorio), no fragmentos ni grep.

The text is in context whether or not the model decided to look it up.

Injection is capped: MANDATORY files always go in whole; CONDITIONAL ones go in
whole only while the budget lasts, and anything dropped is named explicitly so a
silent omission is impossible.
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

SKILLS_ROOT = Path(
    os.environ.get("FUPAI_SKILLS_ROOT", Path.home() / ".claude" / "skills" / "synced")
)
BUDGET_CHARS = int(os.environ.get("FUPAI_INJECT_BUDGET", "60000"))

TRIGGERS = re.compile(
    r"\b(prompt|imagen|image|video|v[ií]deo|shot|storyboard|anchor|ancla|clip|"
    r"render|generar|genera|nano ?banana|nb2|nbp|gpt ?image|kling|veo|sora|"
    r"seedance|midjourney|flux|ideogram|higgsfield|cr[ée]dito|gate|micro-?gate|"
    r"producci[óo]n visual|spot|reel|campa[ñn]a)\b",
    re.IGNORECASE,
)

# Always injected: the rules that govern every visual delivery.
MANDATORY = [
    ("produccion-visual-sw30", "SKILL.md"),
    ("ai-production-director", "SKILL.md"),
]

# Injected when the prompt points at that medium.
CONDITIONAL = {
    re.compile(r"\b(imagen|image|nano ?banana|nb2|nbp|gpt ?image|midjourney|flux|ideogram|still|ancla|anchor)\b", re.I): [
        ("image", "SKILL.md"),
        ("image", "references/golden-rules.md"),
    ],
    re.compile(r"\b(video|v[ií]deo|kling|veo|sora|seedance|hailuo|clip|movimiento|motion)\b", re.I): [
        ("video", "references/dramaturgy.md"),
        ("video", "references/universal-rules.md"),
    ],
    re.compile(r"\b(shot|storyboard|shots\.json|escaleta)\b", re.I): [
        ("storyboard-architect", "SKILL.md"),
    ],
}


def resolve(skill: str, rel: str) -> Path | None:
    for pattern in (f"*/{skill}/{rel}", f"*/*/{skill}/{rel}"):
        for candidate in SKILLS_ROOT.glob(pattern):
            if candidate.is_file():
                return candidate
    return None


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception as exc:
        print(f"inject_rules: unreadable hook payload: {exc}", file=sys.stderr)
        return 1

    prompt = payload.get("prompt") or ""
    if not TRIGGERS.search(prompt):
        return 0

    wanted: list[tuple[str, str]] = list(MANDATORY)
    for pattern, files in CONDITIONAL.items():
        if pattern.search(prompt):
            for f in files:
                if f not in wanted:
                    wanted.append(f)

    parts: list[str] = []
    injected: list[str] = []
    missing: list[str] = []
    dropped: list[str] = []
    used = 0

    for i, (skill, rel) in enumerate(wanted):
        path = resolve(skill, rel)
        label = f"{skill}/{rel}"
        if path is None:
            missing.append(label)
            continue
        text = path.read_text(encoding="utf-8")
        is_mandatory = i < len(MANDATORY)
        if not is_mandatory and used + len(text) > BUDGET_CHARS:
            dropped.append(f"{label} ({len(text)} chars)")
            continue
        used += len(text)
        injected.append(label)
        parts.append(f"\n===== FUENTE OBLIGATORIA: {label} =====\n{text}")

    if not parts and not missing:
        return 0

    header = [
        "REGLAS INYECTADAS POR HOOK — no son opcionales y no dependen de que alguien",
        "decidiera leerlas. Texto completo, verbatim, de la fuente instalada.",
        "",
        f"Inyectadas ({len(injected)}): " + ", ".join(injected),
    ]
    if missing:
        header += ["", f"NO ENCONTRADAS ({len(missing)}): " + ", ".join(missing),
                   "  Estas reglas NO estan en contexto. No afirmes haberlas aplicado."]
    if dropped:
        header += ["", f"OMITIDAS POR PRESUPUESTO ({len(dropped)}): " + ", ".join(dropped),
                   "  Leelas con Read antes de entregar, o declara que no aplican."]

    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": "\n".join(header) + "\n" + "\n".join(parts),
        }
    }))
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/inject_rules.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/nblm_client.py -->
# SOURCE FILE: `repo/.claude/hooks/nblm_client.py`

#!/usr/bin/env python3
"""Cliente MCP mínimo por stdio para hablar con notebooklm-mcp sin registrarlo.

Sirve para probar el servidor y para cargar el corpus desde la línea de comandos.

Uso:
    python3 nblm_client.py --list
    python3 nblm_client.py --call get_health
    python3 nblm_client.py --call add_source --args '{"content":"...","title":"x"}'
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import threading
import time

CMD = ["npx", "-y", "notebooklm-mcp@latest"]


class Client:
    def __init__(self, timeout: float = 180.0):
        self.timeout = timeout
        self.proc = subprocess.Popen(
            CMD, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, bufsize=1,
        )
        self._id = 0
        self._lock = threading.Lock()

    def _send(self, method: str, params: dict | None = None, notify: bool = False):
        with self._lock:
            msg: dict = {"jsonrpc": "2.0", "method": method}
            if params is not None:
                msg["params"] = params
            if not notify:
                self._id += 1
                msg["id"] = self._id
                want = self._id
            self.proc.stdin.write(json.dumps(msg) + "\n")
            self.proc.stdin.flush()
            if notify:
                return None

        deadline = time.time() + self.timeout
        while time.time() < deadline:
            line = self.proc.stdout.readline()
            if not line:
                raise RuntimeError("el servidor cerró la salida")
            line = line.strip()
            if not line.startswith("{"):
                continue  # banner / logs
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            if data.get("id") == want:
                return data
        raise TimeoutError(f"sin respuesta a {method} en {self.timeout}s")

    def initialize(self):
        r = self._send("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "fupai-nblm-client", "version": "1.0"},
        })
        self._send("notifications/initialized", {}, notify=True)
        return r

    def list_tools(self):
        return self._send("tools/list", {})

    def call(self, name: str, args: dict):
        return self._send("tools/call", {"name": name, "arguments": args})

    def close(self):
        try:
            self.proc.terminate()
            self.proc.wait(timeout=10)
        except Exception:
            self.proc.kill()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--call")
    ap.add_argument("--args", default="{}")
    ap.add_argument("--timeout", type=float, default=180.0)
    a = ap.parse_args()

    c = Client(timeout=a.timeout)
    try:
        init = c.initialize()
        info = (init.get("result") or {}).get("serverInfo", {})
        print(f"servidor: {info.get('name')} {info.get('version')}", file=sys.stderr)

        if a.list:
            tools = (c.list_tools().get("result") or {}).get("tools", [])
            print(f"{len(tools)} tools:")
            for t in tools:
                print(f"  {t['name']:22} {(t.get('description') or '')[:88]}")
            return 0

        if a.call:
            r = c.call(a.call, json.loads(a.args))
            if "error" in r:
                print(json.dumps(r["error"], ensure_ascii=False, indent=2))
                return 1
            for block in (r.get("result") or {}).get("content", []):
                print(block.get("text", json.dumps(block, ensure_ascii=False)))
            return 1 if (r.get("result") or {}).get("isError") else 0

        ap.print_help()
        return 2
    finally:
        c.close()


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/nblm_client.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/nblm_import_auth.py -->
# SOURCE FILE: `repo/.claude/hooks/nblm_import_auth.py`

#!/usr/bin/env python3
"""Instala un state.json exportado y deja el servidor autenticado.

NotebookLM no tiene API publica. El servidor guarda la sesion de Google como un
storageState de Playwright (cookies + localStorage) en:

    <dataDir>/browser_state/state.json

Ese archivo es portable: se genera con un login hecho una sola vez en cualquier
maquina y el servidor lo recarga al arrancar. Con el, este entorno queda
autenticado sin que la contrasena pase por ningun lado.

Rutas donde lo genera el login, segun sistema:
    Linux    ~/.local/share/notebooklm-mcp/browser_state/state.json
    macOS    ~/Library/Application Support/notebooklm-mcp/browser_state/state.json
    Windows  %APPDATA%\\notebooklm-mcp\\browser_state\\state.json

Uso:
    python3 nblm_import_auth.py --state /ruta/al/state.json
    python3 nblm_import_auth.py --state state.json --verificar
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

# Cookies que el servidor considera indispensables (dist/auth/auth-manager.js).
REQUIRED = ("__Secure-1PSID", "__Secure-3PSID")


def data_dir() -> Path:
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "notebooklm-mcp"
    if os.name == "nt":
        return Path(os.environ.get("APPDATA", Path.home())) / "notebooklm-mcp"
    return Path(
        os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")
    ) / "notebooklm-mcp"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--state", required=True, help="state.json exportado")
    ap.add_argument("--verificar", action="store_true", help="correr get_health despues")
    a = ap.parse_args()

    src = Path(a.state)
    if not src.is_file():
        print(f"no existe: {src}", file=sys.stderr)
        return 2

    try:
        data = json.loads(src.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"no es JSON valido: {exc}", file=sys.stderr)
        return 2

    cookies = data.get("cookies")
    if not isinstance(cookies, list) or not cookies:
        print("el archivo no trae cookies. ¿Es el state.json correcto?", file=sys.stderr)
        return 2

    google = [c for c in cookies if "google.com" in (c.get("domain") or "")]
    nombres = {c.get("name") for c in cookies}
    faltan = [n for n in REQUIRED if n not in nombres]

    print(f"cookies totales:        {len(cookies)}")
    print(f"cookies de google.com:  {len(google)}")
    if faltan:
        print(f"FALTAN cookies clave:   {', '.join(faltan)}")
        print("  El login no quedo completo, o se exporto antes de terminar.")
        return 1
    print(f"cookies clave:          presentes ({', '.join(REQUIRED)})")

    dest_dir = data_dir() / "browser_state"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / "state.json"
    if dest.exists():
        shutil.copy2(dest, dest.with_suffix(".json.bak"))
    shutil.copy2(src, dest)
    os.chmod(dest, 0o600)
    print(f"instalado en:           {dest}")

    if not a.verificar:
        return 0

    print("\nverificando…")
    client = Path(__file__).resolve().parent / "nblm_client.py"
    r = subprocess.run(
        [sys.executable, str(client), "--call", "get_health"],
        capture_output=True, text=True, timeout=300,
    )
    salida = r.stdout
    print(salida.strip()[:600])
    if '"authenticated": true' in salida:
        print("\nAUTENTICADO. Ya se puede correr nblm_load.py")
        return 0
    print("\nSigue sin autenticar. Las cookies pueden haber expirado; "
          "rehaz el login y exporta de nuevo.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/nblm_import_auth.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/nblm_load.py -->
# SOURCE FILE: `repo/.claude/hooks/nblm_load.py`

#!/usr/bin/env python3
"""Carga toda la documentación de los skills a NotebookLM y corre la prueba.

Un comando. Hace, en orden:

  1. get_health          — si no hay auth, dice exactamente qué falta y para.
  2. add_notebook        — registra el notebook destino.
  3. add_source × N      — sube las 12 fuentes de notebooklm-corpus/.
  4. ask_question        — hace la pregunta de clasificación del caso.
  5. rule_answer_check   — mide si la respuesta cubrió TODAS las reglas.

El paso 5 es lo que convierte "fue exhaustivo" en un número.

Uso:
    python3 nblm_load.py --corpus notebooklm-corpus --url <URL del notebook>
    python3 nblm_load.py --corpus notebooklm-corpus --url <URL> --caso "T1 rostro, Nano Banana Pro"
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from nblm_client import Client  # noqa: E402


def unwrap(resp: dict) -> dict:
    if "error" in resp:
        return {"success": False, "error": resp["error"]}
    blocks = (resp.get("result") or {}).get("content", [])
    for b in blocks:
        text = b.get("text", "")
        try:
            return json.loads(text)
        except Exception:
            continue
    return {"success": True, "raw": blocks}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default="notebooklm-corpus")
    ap.add_argument("--url", help="URL del notebook de NotebookLM")
    ap.add_argument("--notebook-id", default="fupai-pipeline")
    ap.add_argument("--caso", default="maestro de rostro T1, Nano Banana Pro")
    ap.add_argument("--pregunta", help="archivo con la pregunta; si no, se arma sola")
    ap.add_argument("--respuesta", default="respuesta.txt")
    ap.add_argument("--timeout", type=float, default=600.0)
    a = ap.parse_args()

    corpus = sorted(Path(a.corpus).glob("*.md"))
    if not corpus:
        print(f"nblm_load: no hay .md en {a.corpus}/. Corre primero el generador de corpus.",
              file=sys.stderr)
        return 2

    total_words = sum(len(p.read_text(encoding="utf-8").split()) for p in corpus)
    print(f"corpus: {len(corpus)} fuentes · {total_words:,} palabras")

    c = Client(timeout=a.timeout)
    try:
        c.initialize()

        health = unwrap(c.call("get_health", {}))
        if not (health.get("data") or {}).get("authenticated"):
            print()
            print("=" * 66)
            print("  FALTA AUTENTICACION DE GOOGLE — no se puede continuar.")
            print("=" * 66)
            print("  El servidor corre y las 20 tools responden, pero NotebookLM no")
            print("  tiene API publica: el login abre una ventana de Chrome y pide")
            print("  las credenciales de tu cuenta de Google. Eso lo tienes que")
            print("  hacer tu una vez; despues el perfil de Chrome queda guardado y")
            print("  este comando ya no lo vuelve a pedir.")
            print()
            print("  En tu maquina, una sola vez:")
            print("     npx -y notebooklm-mcp@latest   # y completa el login")
            print()
            print("  Despues vuelve a correr este comando.")
            print("=" * 66)
            return 1

        if a.url:
            r = unwrap(c.call("add_notebook", {
                "id": a.notebook_id,
                "name": "FUPAI — pipeline de produccion visual",
                "url": a.url,
                "description": "Documentacion completa de los 12 skills del pipeline.",
            }))
            print(f"notebook: {'ok' if r.get('success') else r.get('error')}")
            c.call("select_notebook", {"id": a.notebook_id})

        subidas, fallidas = 0, []
        for p in corpus:
            r = unwrap(c.call("add_source", {
                "type": "text",
                "content": p.read_text(encoding="utf-8"),
                "title": p.stem,
            }))
            if r.get("success"):
                subidas += 1
                print(f"  + {p.stem}")
            else:
                fallidas.append((p.stem, r.get("error")))
                print(f"  ! {p.stem}: {r.get('error')}")
        print(f"fuentes subidas: {subidas}/{len(corpus)}")
        if fallidas:
            print("  no se subieron:", ", ".join(n for n, _ in fallidas))

        if a.pregunta:
            pregunta = Path(a.pregunta).read_text(encoding="utf-8")
        else:
            pregunta = (
                f"CASO: {a.caso}\n\n"
                "De TODAS las reglas contenidas en las fuentes de este notebook, "
                "dime cuales aplican a este caso y cuales no.\n"
                "Una linea por regla, citando el archivo y la regla textual.\n"
                "No resumas ni agrupes: necesito la lista completa, no una seleccion "
                "de las mas relevantes."
            )

        print("\npreguntando…")
        r = unwrap(c.call("ask_question", {"question": pregunta}))
        answer = (r.get("data") or {}).get("answer") or r.get("answer") or ""
        if not answer:
            print(f"sin respuesta: {r.get('error') or r}", file=sys.stderr)
            return 1
        Path(a.respuesta).write_text(answer, encoding="utf-8")
        print(f"respuesta escrita en {a.respuesta} ({len(answer)} chars)")
        print("\nMide la cobertura con:")
        print(f"  python3 .claude/hooks/rule_answer_check.py --registry reg_*.json "
              f"--respuesta {a.respuesta}")
        return 0
    finally:
        c.close()


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/nblm_load.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/prompt_detect.py -->
# SOURCE FILE: `repo/.claude/hooks/prompt_detect.py`

#!/usr/bin/env python3
"""Decide si un bloque cercado es la entrega de un prompt visual.

Los tres gates de `Stop` necesitan la misma decision, y tenerla en un solo lugar
evita que se separen. La primera version de gate_image.py no la tenia: trataba
cualquier bloque como prompt de imagen, y bloqueaba mensajes que solo contenian
comandos de shell.

Regla: un bloque cuenta como entrega si tiene una senal POSITIVA de prompt y no
es evidentemente codigo. El default es NO bloquear — un gate que bloquea texto
que no es un prompt se desactiva a la semana, y entonces no protege nada.
"""

from __future__ import annotations

import re

IMAGE_MODELS = (
    "nano banana", "nano-banana", "nanobanana", "nbp", "nb2",
    "gpt image", "gpt-image", "seedream", "midjourney", "flux", "ideogram",
)
VIDEO_MODELS = (
    "kling", "veo", "sora", "seedance", "hailuo", "runway", "luma", "pika",
)

# Señal positiva: abre con un verbo de generación, o trae los campos de un brief.
PROMPTISH = re.compile(
    r"^\s*(create|generate|design|transform|convert|edit)\b"
    r"|^\s*(subject|lighting|background|mood|format|aspect[ _]ratio|negative[ _]prompt"
    r"|typography|camera|framing|scene|use ?case|constraints|preserve|change)\s*:"
    r"|^\s*(wide shot|close-?up|medium shot|mcu|ecu|extreme close-?up)\b",
    re.IGNORECASE | re.MULTILINE,
)

# Señal de que es código, salida de terminal o datos: nunca es un prompt.
CODEISH = re.compile(
    r"^\s*(\$|#!|//|#\s|npx |npm |pnpm |yarn |pip |pip3 |python3? |node |bash |sh |zsh "
    r"|git |cd |ls |cat |mkdir |rm |cp |mv |chmod |curl |wget |sudo |apt |brew "
    r"|export |source |echo |grep |sed |awk |find |for |while |if |fi\b|done\b)"
    r"|^\s*(from|import|def|class|return|const|let|var|function|package|module)\s"
    r"|^\s*[{\[<]"
    r"|^\s*[\w./%-]+\s*(→|->|=>)\s"
    r"|^\s*[A-Za-z_][A-Za-z0-9_]*\s*[:=]\s*(true|false|null|none|\d)"
    r"|^\s*(EXIT|exit|PASS|FAIL|WARN|ERROR|OK)\b",
    re.MULTILINE,
)

FENCE_INFO = re.compile(r"```([^\n]*)\n")
# Lenguajes que jamas son un prompt visual.
CODE_LANGS = {
    "bash", "sh", "shell", "zsh", "console", "terminal", "python", "py", "js",
    "javascript", "ts", "typescript", "json", "yaml", "yml", "toml", "xml",
    "html", "css", "sql", "diff", "patch", "go", "rust", "java", "c", "cpp",
}


def fenced_blocks(message: str) -> list[tuple[str, str]]:
    """Devuelve (lenguaje, contenido) por cada bloque cercado."""
    out: list[tuple[str, str]] = []
    pos = 0
    while True:
        m = FENCE_INFO.search(message, pos)
        if not m:
            return out
        end = message.find("```", m.end())
        if end == -1:
            return out
        out.append((m.group(1).strip().lower(), message[m.end():end]))
        pos = end + 3


def is_visual_prompt(block: str, lang: str = "", message: str = "") -> bool:
    """True si el bloque es la entrega de un prompt visual."""
    if lang in CODE_LANGS:
        return False

    # La señal positiva gana sobre la de código: campos como "Format: 4:5" son
    # del template de imagen y también se parecen a una asignación.
    if PROMPTISH.search(block):
        return True
    low_block = block.lower()
    if any(m in low_block for m in IMAGE_MODELS + VIDEO_MODELS):
        return True

    if CODEISH.search(block):
        return False
    # El modelo destino casi siempre se nombra en la prosa que introduce el
    # bloque ("Prompt para Nano Banana:"), no dentro del bloque. Si el mensaje
    # nombra un modelo y el bloque no es codigo, es la entrega.
    low_msg = (message or "").lower()
    return any(m in low_msg for m in IMAGE_MODELS + VIDEO_MODELS)


def visual_blocks(message: str) -> list[tuple[int, str]]:
    """(indice base 1, contenido) de los bloques que son entrega de prompt."""
    return [
        (i, body)
        for i, (lang, body) in enumerate(fenced_blocks(message), start=1)
        if is_visual_prompt(body, lang, message)
    ]


def names_image_model(text: str) -> bool:
    return any(m in text.lower() for m in IMAGE_MODELS)


def names_video_model(text: str) -> bool:
    return any(m in text.lower() for m in VIDEO_MODELS)

<!-- SOURCE_FILE_END: repo/.claude/hooks/prompt_detect.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/rule_answer_check.py -->
# SOURCE FILE: `repo/.claude/hooks/rule_answer_check.py`

#!/usr/bin/env python3
"""Paso 3: medir si la selección externa cubrió TODAS las reglas.

No juzga si la selección fue acertada — eso es criterio, y el criterio ya no es mío.
Sólo mide cobertura: de las N reglas del registro, cuántas fueron clasificadas y
cuáles quedaron sin mencionar.

Es la pieza que convierte "confío en que es exhaustivo" en un número. Si sale
0 sin mencionar, la exhaustividad queda demostrada y deja de ser una opinión.
Si sale distinto de 0, las que faltan se listan por id y se vuelven a preguntar.

Uso:
    python3 rule_answer_check.py --registry reg_*.json --respuesta respuesta.txt
    python3 rule_answer_check.py --registry reg_*.json --respuesta r.txt --faltantes f.txt
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

LINE_RE = re.compile(
    r"\[?(?P<id>[0-9a-f]{12})\]?\s*[-—:]?\s*(?P<verdict>NO\s+APLICA|APLICA)\s*(?:[-—:]\s*(?P<reason>.*))?",
    re.IGNORECASE,
)


def load(paths: list[str]) -> dict[str, dict]:
    rules: dict[str, dict] = {}
    for p in paths:
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        skill = data.get("skill", "?")
        for r in data.get("rules", []):
            r["skill"] = skill
            rules.setdefault(r["id"], r)
    return rules


def main() -> int:
    ap = argparse.ArgumentParser(description="Cobertura de una clasificación externa")
    ap.add_argument("--registry", nargs="+", required=True)
    ap.add_argument("--respuesta", required=True)
    ap.add_argument("--faltantes", help="archivo donde escribir los ids no mencionados")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    rules = load(args.registry)
    text = Path(args.respuesta).read_text(encoding="utf-8")

    aplica: set[str] = set()
    no_aplica: set[str] = set()
    for m in LINE_RE.finditer(text):
        rid = m.group("id").lower()
        if m.group("verdict").upper().startswith("NO"):
            no_aplica.add(rid)
        else:
            aplica.add(rid)

    clasificadas = aplica | no_aplica
    faltantes = [r for rid, r in rules.items() if rid not in clasificadas]
    inventadas = sorted(clasificadas - set(rules))
    duplicadas = sorted(aplica & no_aplica)

    total = len(rules)
    cubiertas = total - len(faltantes)
    pct = (cubiertas / total * 100) if total else 0.0

    if args.json:
        print(json.dumps({
            "total": total, "aplica": len(aplica), "no_aplica": len(no_aplica),
            "sin_mencionar": len(faltantes), "ids_inexistentes": len(inventadas),
            "contradictorias": len(duplicadas), "cobertura_pct": round(pct, 1),
        }, indent=2))
    else:
        print("=" * 68)
        print("COBERTURA DE LA CLASIFICACION EXTERNA")
        print("=" * 68)
        print(f"  reglas en el registro       {total}")
        print(f"  clasificadas APLICA         {len(aplica)}")
        print(f"  clasificadas NO APLICA      {len(no_aplica)}")
        print(f"  SIN MENCIONAR               {len(faltantes)}")
        print(f"  ids que no existen          {len(inventadas)}")
        print(f"  clasificadas dos veces      {len(duplicadas)}")
        print(f"  cobertura                   {pct:.1f}%")
        print()
        if inventadas:
            print(f"  Ids inexistentes: {', '.join(inventadas[:8])}")
            print("    Vinieron en la respuesta pero no estan en el registro.")
            print()
        if duplicadas:
            print(f"  Contradictorias: {', '.join(duplicadas[:8])}")
            print("    Clasificadas como APLICA y NO APLICA a la vez.")
            print()
        if faltantes:
            print(f"  {len(faltantes)} reglas quedaron sin clasificar. Vuelve a preguntar")
            print("  por estos ids explicitamente:")
            for r in faltantes[:10]:
                print(f"    [{r['id']}] {r['skill']}/{r['file']}:{r['line']}")
                print(f"      {r['text'][:110]}")
            if len(faltantes) > 10:
                print(f"    … y {len(faltantes) - 10} mas")
        else:
            print("  100% clasificado. Exhaustividad demostrada, no supuesta.")
        print("=" * 68)

    if args.faltantes:
        Path(args.faltantes).write_text(
            "\n".join(f"[{r['id']}] {r['skill']}/{r['file']}:{r['line']} — {r['text']}"
                      for r in faltantes),
            encoding="utf-8",
        )
        print(f"\nfaltantes escritos en {args.faltantes}")

    return 1 if (faltantes or inventadas or duplicadas) else 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/rule_answer_check.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/rule_db.py -->
# SOURCE FILE: `repo/.claude/hooks/rule_db.py`

#!/usr/bin/env python3
"""Base de datos de reglas por caso. Se construye una vez, se consulta siempre.

El problema de preguntar "qué reglas aplican a este caso" en cada prompt es que
la respuesta cabe mal en un solo output y hay que confiar en que fue completa.
Esto lo invierte: se clasifica en tandas chicas, una vez, y queda una tabla.
Después seleccionar reglas es una consulta, no una pregunta a un modelo.

    --chunks    parte el registro en tandas del tamaño que aguante el output,
                cada una con su pregunta lista para pegar.
    --ingest    lee la respuesta de una tanda y la mete en la base. Reporta qué
                ids de esa tanda no vinieron, para volver a pedirlos.
    --status    cuántas reglas ya tienen casos y cuántas faltan.
    --caso      consulta: qué reglas aplican a un caso dado.

La base es un JSON legible: cada regla con su texto, su archivo y sus casos.
Se puede leer, discutir y corregir a mano.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# Taxonomía de casos. T1..T5 son de produccion-visual-sw30/SKILL.md; los demás
# cubren el resto del pipeline. Es una lista cerrada a propósito: un caso nuevo
# se agrega aquí y se reclasifica, no se inventa al vuelo.
CASOS = {
    "T1": "maestro de rostro (still, persona, identidad)",
    "T2": "maestro de cuerpo (still, persona completa)",
    "T3": "cuadro con 1 persona (still de escena)",
    "T4": "cuadro con 2 personas (still, contacto/interaccion)",
    "T5": "edicion quirurgica sobre imagen existente",
    "CLIP": "prompt de video / movimiento",
    "SHOT": "planeacion de shots, storyboard, shots.json",
    "GUION": "escritura de guion o tratamiento",
    "MARCA": "extraccion o uso de brand-lock",
    "QA": "critica de render, revision de asset generado",
    "ENTREGA": "empaquetado, preview, entrega a cliente",
    "PROD": "still de producto, comida u objeto (sin persona)",
    "GRAF": "pieza grafica: poster, slide, UI, social, tipografia dominante",
    "MULTI": "multi-panel o grid dentro de una sola imagen",
    "REF": "analisis de imagen de referencia, image-to-prompt",
    "NINGUNO": "no aplica a ningun caso de produccion (meta, ejemplos, docs)",
}

LINE_RE = re.compile(
    r"\[?(?P<id>[0-9a-f]{12})\]?\s*[-—:]?\s*(?P<casos>[A-Z0-9,\s]+?)\s*$",
    re.MULTILINE,
)


def load_registry(paths: list[str]) -> dict[str, dict]:
    rules: dict[str, dict] = {}
    for p in paths:
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        skill = data.get("skill", "?")
        for r in data.get("rules", []):
            r["skill"] = skill
            rules.setdefault(r["id"], r)
    return rules


def load_db(path: Path) -> dict:
    if path.is_file():
        return json.loads(path.read_text(encoding="utf-8"))
    return {"casos": CASOS, "reglas": {}}


def save_db(path: Path, db: dict) -> None:
    path.write_text(json.dumps(db, ensure_ascii=False, indent=2), encoding="utf-8")


def preamble(n: int, chunk: int, total: int) -> str:
    casos = "\n".join(f"  {k:8} {v}" for k, v in CASOS.items())
    return f"""TANDA {chunk} de {total} — {n} reglas.

Abajo hay {n} reglas de mi pipeline de produccion visual. Cada una tiene un id
de 12 caracteres entre corchetes.

Para CADA regla, dime a que casos de produccion es relevante. Los casos son
estos y solo estos:

{casos}

Formato exacto, una linea por regla, sin texto adicional:

  [id] T1,T3,T4
  [id] CLIP
  [id] NINGUNO

Reglas del formato:
- Deben aparecer los {n} ids de esta tanda. Ninguno puede faltar.
- Una regla puede tener varios casos separados por coma, sin espacios.
- Si una regla es general y aplica a todo still, marca T1,T2,T3,T4,T5.
- NINGUNO es solo para lineas que no son reglas de produccion (ejemplos,
  indices, notas de licencia, descripciones de archivos).
- No expliques. Solo la lista.
"""


def cmd_chunks(args) -> int:
    rules = load_registry(args.registry)
    db = load_db(Path(args.db))
    pendientes = [r for rid, r in rules.items() if rid not in db["reglas"]]
    pendientes.sort(key=lambda r: (r["skill"], r["file"], r["line"]))

    if not pendientes:
        print("no quedan reglas sin clasificar")
        return 0

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    for f in out.glob("tanda-*.txt"):
        f.unlink()

    total = (len(pendientes) + args.size - 1) // args.size
    for i in range(total):
        grupo = pendientes[i * args.size : (i + 1) * args.size]
        cuerpo = [preamble(len(grupo), i + 1, total), ""]
        actual = None
        for r in grupo:
            ruta = f"{r['skill']}/{r['file']}"
            if ruta != actual:
                actual = ruta
                cuerpo.append(f"\n--- {ruta} ---")
            cuerpo.append(f"[{r['id']}] {r['text']}")
        (out / f"tanda-{i + 1:02d}.txt").write_text("\n".join(cuerpo), encoding="utf-8")

    print(f"{len(pendientes)} reglas sin clasificar -> {total} tandas de {args.size} en {out}/")
    return 0


def cmd_ingest(args) -> int:
    rules = load_registry(args.registry)
    db_path = Path(args.db)
    db = load_db(db_path)

    texto = Path(args.respuesta).read_text(encoding="utf-8")
    esperados = set()
    if args.tanda:
        for m in re.finditer(r"\[([0-9a-f]{12})\]", Path(args.tanda).read_text(encoding="utf-8")):
            esperados.add(m.group(1))

    nuevos, invalidos, desconocidos = 0, [], []
    vistos = set()
    for m in LINE_RE.finditer(texto):
        rid = m.group("id")
        casos = [c.strip().upper() for c in m.group("casos").split(",") if c.strip()]
        casos = [c for c in casos if c]
        if rid not in rules:
            desconocidos.append(rid)
            continue
        malos = [c for c in casos if c not in CASOS]
        if malos or not casos:
            invalidos.append((rid, ",".join(casos) or "(vacio)"))
            continue
        vistos.add(rid)
        r = rules[rid]
        db["reglas"][rid] = {
            "skill": r["skill"], "file": r["file"], "line": r["line"],
            "texto": r["text"], "casos": sorted(set(casos)),
        }
        nuevos += 1

    save_db(db_path, db)

    faltantes = sorted(esperados - vistos) if esperados else []
    print(f"clasificadas en esta tanda : {nuevos}")
    print(f"ids que no existen         : {len(desconocidos)}")
    print(f"lineas con caso invalido   : {len(invalidos)}")
    if esperados:
        print(f"ids de la tanda que faltan : {len(faltantes)}")
    print(f"total en la base           : {len(db['reglas'])} / {len(rules)}")
    for rid, casos in invalidos[:5]:
        print(f"   invalido {rid}: {casos}")
    if faltantes:
        print("\n  Vuelve a pedir estos ids:")
        for rid in faltantes[:20]:
            print(f"    [{rid}] {rules[rid]['skill']}/{rules[rid]['file']}:{rules[rid]['line']}")
        if len(faltantes) > 20:
            print(f"    … y {len(faltantes) - 20} mas")
    return 1 if (faltantes or invalidos or desconocidos) else 0


def cmd_status(args) -> int:
    rules = load_registry(args.registry)
    db = load_db(Path(args.db))
    hechas = set(db["reglas"])
    print(f"reglas en el registro : {len(rules)}")
    print(f"clasificadas          : {len(hechas)}  ({len(hechas)/max(len(rules),1)*100:.1f}%)")
    print(f"pendientes            : {len(rules) - len(hechas)}")
    print()
    por_skill: dict[str, list[int]] = {}
    for rid, r in rules.items():
        s = por_skill.setdefault(r["skill"], [0, 0])
        s[1] += 1
        if rid in hechas:
            s[0] += 1
    for skill, (hecho, tot) in sorted(por_skill.items(), key=lambda kv: kv[1][1] - kv[1][0], reverse=True):
        barra = "#" * int(hecho / max(tot, 1) * 20)
        print(f"  {skill:26} {hecho:>4}/{tot:<4} {barra}")
    if hechas:
        print("\n  reglas por caso:")
        conteo: dict[str, int] = {}
        for r in db["reglas"].values():
            for c in r["casos"]:
                conteo[c] = conteo.get(c, 0) + 1
        for c in CASOS:
            if conteo.get(c):
                print(f"    {c:8} {conteo[c]:>4}   {CASOS[c]}")
    return 0


def cmd_caso(args) -> int:
    db = load_db(Path(args.db))
    if args.caso not in CASOS:
        print(f"caso desconocido. Hay: {', '.join(CASOS)}", file=sys.stderr)
        return 2
    sel = [r for r in db["reglas"].values() if args.caso in r["casos"]]
    sel.sort(key=lambda r: (r["skill"], r["file"], r["line"]))
    print(f"# Reglas para el caso {args.caso} — {CASOS[args.caso]}")
    print(f"# {len(sel)} reglas, de {len(db['reglas'])} clasificadas\n")
    actual = None
    for r in sel:
        ruta = f"{r['skill']}/{r['file']}"
        if ruta != actual:
            actual = ruta
            print(f"\n## {ruta}")
        print(f"- {r['texto']}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Base de datos de reglas por caso")
    ap.add_argument("--registry", nargs="+", required=True)
    ap.add_argument("--db", default="rules.db.json")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("chunks", help="genera las tandas pendientes")
    c.add_argument("--size", type=int, default=50)
    c.add_argument("--out", default="tandas")
    c.set_defaults(fn=cmd_chunks)

    i = sub.add_parser("ingest", help="mete la respuesta de una tanda a la base")
    i.add_argument("--respuesta", required=True)
    i.add_argument("--tanda", help="archivo de la tanda, para detectar ids faltantes")
    i.set_defaults(fn=cmd_ingest)

    s = sub.add_parser("status", help="avance de la clasificacion")
    s.set_defaults(fn=cmd_status)

    q = sub.add_parser("caso", help="consulta las reglas de un caso")
    q.add_argument("caso")
    q.set_defaults(fn=cmd_caso)

    args = ap.parse_args()
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/rule_db.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/rule_export.py -->
# SOURCE FILE: `repo/.claude/hooks/rule_export.py`

#!/usr/bin/env python3
"""Exporta el registro de reglas como fuente para NotebookLM, y la pregunta canónica.

Método acordado:

    Paso 1  rule_registry.py  — tener TODAS. Extracción mecánica, nadie elige.
    Paso 2  NotebookLM        — decidir cuáles aplican al caso. Criterio externo.
    Paso 3  rule_answer_check.py — medir si la respuesta cubrió las TODAS.

Este script hace el 1->2: convierte el registro en un documento subible, con un id
estable por regla, y emite la pregunta a hacerle. Los ids son lo que permite el
paso 3: sin ellos la respuesta no es verificable, sólo creíble.

Uso:
    python3 rule_export.py --registry reg_*.json --out fuente.md --caso "maestro de rostro, Nano Banana Pro"
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def load(paths: list[str]) -> list[dict]:
    rules: list[dict] = []
    seen: set[str] = set()
    for p in paths:
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        skill = data.get("skill", "?")
        for r in data.get("rules", []):
            if r["id"] in seen:
                continue
            seen.add(r["id"])
            r["skill"] = skill
            rules.append(r)
    return rules


QUESTION = """Tengo abajo el catálogo completo y numerado de reglas de producción visual.
Cada regla tiene un id de 12 caracteres entre corchetes.

CASO: {caso}

Devuélveme, para ESTE caso, la clasificación de CADA UNA de las {n} reglas.
Formato exacto, una línea por regla, sin texto adicional:

    [id] APLICA
    [id] NO APLICA — <razón breve>

Requisitos:
- Deben aparecer las {n} reglas. Ninguna puede quedar fuera de la lista.
- No resumas ni agrupes. Una línea por id.
- Si una regla es ambigua para este caso, clasifícala APLICA y anota la duda.
"""


def main() -> int:
    ap = argparse.ArgumentParser(description="Exporta el registro como fuente para NotebookLM")
    ap.add_argument("--registry", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--caso", required=True)
    ap.add_argument("--pregunta", help="archivo donde escribir la pregunta canónica")
    args = ap.parse_args()

    rules = load(args.registry)
    if not rules:
        print("rule_export: el registro está vacío", file=sys.stderr)
        return 1

    lines = [
        "# Catálogo de reglas de producción visual",
        "",
        f"{len(rules)} reglas extraídas mecánicamente de los skills instalados.",
        "El id entre corchetes es estable y es la referencia para clasificar.",
        "",
    ]
    por_archivo: dict[str, list[dict]] = {}
    for r in rules:
        por_archivo.setdefault(f"{r['skill']}/{r['file']}", []).append(r)

    for path, rs in sorted(por_archivo.items()):
        lines += [f"## {path}", ""]
        for r in rs:
            lines.append(f"- [{r['id']}] (línea {r['line']}) {r['text']}")
        lines.append("")

    Path(args.out).write_text("\n".join(lines), encoding="utf-8")

    pregunta = QUESTION.format(caso=args.caso, n=len(rules))
    if args.pregunta:
        Path(args.pregunta).write_text(pregunta, encoding="utf-8")

    print(f"fuente:   {args.out}  ({len(rules)} reglas, {len(por_archivo)} archivos)")
    print(f"pregunta: {args.pregunta or '(abajo)'}")
    if not args.pregunta:
        print()
        print(pregunta)
    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/rule_export.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/rule_ledger.py -->
# SOURCE FILE: `repo/.claude/hooks/rule_ledger.py`

#!/usr/bin/env python3
"""Force an explicit disposition for every extracted rule. Fail on any PENDING.

Specified in produccion-visual-sw30/SKILL.md:

    `rule_ledger.py` — obliga a que CADA regla aplicable tenga disposición
    explícita: CHECK (existe verificación) o NA (con razón escrita y auditable).
    Sale con código 1 si queda una sola PENDING.

    GATE DE COBERTURA: el builder corre `rule_ledger.py` antes de emitir; si no
    cierra en 100% dispuesto, no hay archivo de prompts.

A rule is PENDING until somebody writes down what happens to it. Silence is not
a disposition. That is the whole mechanism: a number nobody can round up.

Dispositions live in a JSON file keyed by rule id:

    {
      "a1b2c3d4e5f6": {"status": "CHECK", "by": "gate_image.py::R1"},
      "0f1e2d3c4b5a": {"status": "NA", "reason": "aplica solo a slides, no a spots"}
    }

CHECK requires `by` (what verifies it). NA requires `reason`. Both are audited.
A disposition whose id is no longer in the registry is reported as STALE: the
source text changed underneath it, so the claim no longer covers anything.

Usage:
    python3 rule_ledger.py --registry reg.json [reg2.json ...] --dispositions d.json
    python3 rule_ledger.py --registry reg.json --dispositions d.json --pending 20
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

VALID = ("CHECK", "NA")


def load_registry(paths: list[str]) -> dict[str, dict]:
    rules: dict[str, dict] = {}
    for p in paths:
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        for rule in data.get("rules", []):
            rule.setdefault("skill", data.get("skill", "?"))
            rules[rule["id"]] = rule
    return rules


def main() -> int:
    ap = argparse.ArgumentParser(description="Coverage gate over an extracted rule registry")
    ap.add_argument("--registry", nargs="+", required=True)
    ap.add_argument("--dispositions", required=True)
    ap.add_argument("--pending", type=int, default=10, help="cuantas PENDING listar")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    rules = load_registry(args.registry)

    disp_path = Path(args.dispositions)
    dispositions: dict[str, dict] = {}
    if disp_path.is_file():
        dispositions = json.loads(disp_path.read_text(encoding="utf-8"))

    checked: list[str] = []
    na: list[str] = []
    malformed: list[tuple[str, str]] = []
    pending: list[str] = []

    for rid in rules:
        d = dispositions.get(rid)
        if d is None:
            pending.append(rid)
            continue
        status = (d.get("status") or "").upper()
        if status not in VALID:
            malformed.append((rid, f"status invalido: {d.get('status')!r}"))
        elif status == "CHECK" and not d.get("by"):
            malformed.append((rid, "CHECK sin campo 'by' (que lo verifica)"))
        elif status == "NA" and not (d.get("reason") or "").strip():
            malformed.append((rid, "NA sin razon escrita"))
        elif status == "CHECK":
            checked.append(rid)
        else:
            na.append(rid)

    stale = [rid for rid in dispositions if rid not in rules]

    total = len(rules)
    disposed = len(checked) + len(na)
    pct = (disposed / total * 100) if total else 0.0

    if args.json:
        print(json.dumps({
            "total": total, "check": len(checked), "na": len(na),
            "pending": len(pending), "malformed": len(malformed),
            "stale": len(stale), "disposed_pct": round(pct, 1),
        }, indent=2))
    else:
        print("=" * 63)
        print("RULE LEDGER — gate de cobertura")
        print("=" * 63)
        print(f"  reglas en el registro    {total}")
        print(f"  CHECK  (verificadas)     {len(checked)}")
        print(f"  NA     (excluidas)       {len(na)}")
        print(f"  PENDING (sin disponer)   {len(pending)}")
        print(f"  MALFORMED                {len(malformed)}")
        print(f"  STALE (id ya no existe)  {len(stale)}")
        print(f"  dispuesto                {pct:.1f}%")
        print()

        for rid, why in malformed[: args.pending]:
            r = rules[rid]
            print(f"  MALFORMED {rid}  {why}")
            print(f"            {r['skill']}/{r['file']}:{r['line']}")

        if stale:
            print(f"  STALE: {', '.join(stale[:8])}"
                  + (" …" if len(stale) > 8 else ""))
            print("         el texto de origen cambio; la disposicion ya no cubre nada.")
            print()

        if pending:
            print(f"  Primeras {min(args.pending, len(pending))} PENDING:")
            for rid in pending[: args.pending]:
                r = rules[rid]
                print(f"    {rid}  [{','.join(r['markers'])}]")
                print(f"      {r['skill']}/{r['file']}:{r['line']}")
                print(f"      {r['text'][:150]}")
            if len(pending) > args.pending:
                print(f"    … y {len(pending) - args.pending} mas")
            print()

        if pending or malformed:
            print("  GATE CERRADO. No se emite mientras quede una sola PENDING.")
            print(f"  Dispon cada una en {disp_path} con CHECK+by o NA+reason.")
        else:
            print("  GATE ABIERTO. 100% dispuesto.")
        print("=" * 63)

    return 1 if (pending or malformed) else 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/rule_ledger.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/rule_registry.py -->
# SOURCE FILE: `repo/.claude/hooks/rule_registry.py`

#!/usr/bin/env python3
"""Extract every normative statement from a skill, mechanically.

Specified in produccion-visual-sw30/SKILL.md:

    `rule_registry.py` — relee los N archivos del skill y EXTRAE mecánicamente
    cada enunciado normativo. Si el skill cambia, el registro cambia solo.
    Mi interpretación deja de ser etapa.

The point is that no model decides what counts as a rule. A line is normative
because it carries a deontic marker, not because someone remembered it. The
markers are declared below and are auditable.

Ids are sha1(relative path + normalised text), so a rule keeps its id when
lines move around it, and changes id when its wording changes — which is the
behaviour a ledger needs.

Usage:
    python3 rule_registry.py --skill image --out registry.json
    python3 rule_registry.py --skill image --stats
    python3 rule_registry.py --list-skills
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path

SKILLS_ROOT = Path(
    os.environ.get("FUPAI_SKILLS_ROOT", Path.home() / ".claude" / "skills" / "synced")
)

# Deontic markers. Each one is a reason a line is normative; the marker is
# recorded on the rule so a reviewer can argue with the classification.
MARKERS: dict[str, re.Pattern] = {
    "prohibition": re.compile(
        r"\b(never|do not|don't|avoid|prohibit(?:ed|s)?|banned|forbidden|"
        r"no se|prohibido|nunca|jam[áa]s|"
        r"нельзя|не используй|никогда|запрещ)\w*\b",
        re.IGNORECASE,
    ),
    "obligation": re.compile(
        r"\b(must|shall|always|required|mandatory|ensure|has to|need to|"
        r"siempre|obligatorio|se debe|hay que|"
        r"должен|обязательн|всегда)\w*\b",
        re.IGNORECASE,
    ),
    "recommendation": re.compile(
        r"\b(should|prefer|recommend(?:ed)?|better to|use\b|"
        r"conviene|se recomienda|"
        r"лучше|используй|рекомендуется)\w*",
        re.IGNORECASE,
    ),
    "good_example": re.compile(r"✅"),
    "bad_example": re.compile(r"❌"),
    "numbered_rule": re.compile(r"^\s{0,3}\d{1,2}[.)]\s+\S"),
}

# Lines that are structure, not rules.
SKIP = (
    re.compile(r"^\s*$"),
    re.compile(r"^\s*(#{1,6})\s"),          # headings
    re.compile(r"^\s*[-*_]{3,}\s*$"),       # rules/hr
    re.compile(r"^\s*\|[\s:|-]+\|\s*$"),    # table separators
    re.compile(r"^\s*>\s*\*?Author"),       # attribution footers
    re.compile(r"^\s*\[!\["),               # badges
)

FENCE = re.compile(r"^\s*```")
LIST_START = re.compile(r"^\s*(?:[-*+]\s|\d{1,2}[.)]\s)")
FRONTMATTER = re.compile(r"^---\s*$")
# Metadatos del paquete, no enunciados normativos.
META = re.compile(
    r"^\s*(license|name|description|version|author|metadata|pipeline|allowed-tools|"
    r"compatibility)\s*:",
    re.IGNORECASE,
)
ATTRIBUTION = re.compile(r"(CC[ -]BY|attribution required|Serge Shima|t\.me/|©)", re.IGNORECASE)


def normalise(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"^[-*+]\s+", "", text)
    text = re.sub(r"^\s*\d{1,2}[.)]\s+", "", text)
    return text.strip(" |")


def rule_id(rel: str, text: str) -> str:
    return hashlib.sha1(f"{rel}\x00{normalise(text).lower()}".encode()).hexdigest()[:12]


def extract_file(path: Path, root: Path) -> list[dict]:
    rel = str(path.relative_to(root))
    rules: list[dict] = []
    in_fence = False
    in_frontmatter = False

    raw_lines = path.read_text(encoding="utf-8").splitlines()

    # Una regla envuelta en varias lineas es UNA regla. Sin esto, la segunda
    # mitad ("de colocacion probada; nunca 'a ver si sale'") queda como entrada
    # propia e inclasificable, e infla el conteo.
    lines: list[tuple[int, str]] = []
    for lineno, raw in enumerate(raw_lines, 1):
        continuacion = (
            lines
            and raw.strip()
            and not FENCE.match(raw)
            and not raw.lstrip().startswith(("-", "*", "+", "|", "#", ">"))
            and not re.match(r"^\s*\d{1,2}[.)]\s", raw)
            and (raw.startswith((" ", "\t")) or LIST_START.match(lines[-1][1]))
            and lines[-1][1].strip()
        )
        if continuacion:
            prev_no, prev = lines[-1]
            lines[-1] = (prev_no, prev.rstrip() + " " + raw.strip())
        else:
            lines.append((lineno, raw))

    for lineno, raw in lines:
        # YAML frontmatter: metadata about the skill, not rules inside it.
        if lineno == 1 and FRONTMATTER.match(raw):
            in_frontmatter = True
            continue
        if in_frontmatter:
            if FRONTMATTER.match(raw):
                in_frontmatter = False
            continue

        if FENCE.match(raw):
            in_fence = not in_fence
            continue
        if in_fence:
            continue  # prompt templates are examples, not statements about rules
        if any(p.match(raw) for p in SKIP):
            continue
        if META.match(raw) or ATTRIBUTION.search(raw):
            continue

        text = normalise(raw)
        if len(text) < 12:
            continue

        hits = [name for name, pat in MARKERS.items() if pat.search(raw)]
        if not hits:
            continue

        rules.append(
            {
                "id": rule_id(rel, text),
                "file": rel,
                "line": lineno,
                "markers": hits,
                "text": text[:400],
            }
        )
    return rules


def build(skill: str) -> tuple[Path, list[dict]]:
    roots = sorted(SKILLS_ROOT.glob(f"*/{skill}")) + sorted(
        SKILLS_ROOT.glob(f"*/*/{skill}")
    )
    roots = [r for r in roots if r.is_dir()]
    if not roots:
        raise SystemExit(f"rule_registry: skill '{skill}' not found under {SKILLS_ROOT}")
    root = roots[0]

    rules: list[dict] = []
    seen: set[str] = set()
    for md in sorted(root.rglob("*.md")):
        for rule in extract_file(md, root):
            if rule["id"] in seen:
                continue
            seen.add(rule["id"])
            rules.append(rule)
    return root, rules


def main() -> int:
    ap = argparse.ArgumentParser(description="Mechanical extraction of normative statements")
    ap.add_argument("--skill", default="image")
    ap.add_argument("--out")
    ap.add_argument("--stats", action="store_true")
    ap.add_argument("--list-skills", action="store_true")
    args = ap.parse_args()

    if args.list_skills:
        for d in sorted(SKILLS_ROOT.glob("*/*")):
            if d.is_dir() and (d / "SKILL.md").is_file():
                print(d.name)
        return 0

    root, rules = build(args.skill)

    if args.out:
        Path(args.out).write_text(
            json.dumps(
                {"skill": args.skill, "root": str(root), "count": len(rules), "rules": rules},
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    if args.stats or not args.out:
        files = sorted({r["file"] for r in rules})
        by_marker: dict[str, int] = {}
        for r in rules:
            for m in r["markers"]:
                by_marker[m] = by_marker.get(m, 0) + 1
        print(f"skill:      {args.skill}")
        print(f"root:       {root}")
        print(f"archivos:   {len(list(root.rglob('*.md')))} .md leidos, {len(files)} con reglas")
        print(f"enunciados: {len(rules)}")
        print("por marcador:")
        for m, n in sorted(by_marker.items(), key=lambda kv: -kv[1]):
            print(f"  {m:16} {n}")
        if args.out:
            print(f"\nescrito en {args.out}")

    return 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/rule_registry.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/rule_scope.py -->
# SOURCE FILE: `repo/.claude/hooks/rule_scope.py`

#!/usr/bin/env python3
"""Paso 2 del método: decidir qué reglas aplican a ESTE caso.

    Paso 1  rule_registry.py  — tener TODAS. Extracción mecánica, nadie elige.
    Paso 2  rule_scope.py     — filtrar por caso. Escrito y auditable.
    Paso 3  auditoría externa — pedir a un segundo criterio qué se excluyó mal.

La propiedad que hace útil al paso 2 no es que acierte: es que **no puede callar**.
Una regla que ninguna línea de scope.yaml toca queda SIN DECIDIR, y una sola sin
decidir cierra el gate. El filtro no puede omitir por descuido, solo por escrito.

Eso es también lo que separa este paso de preguntarle a un modelo cuáles aplican:
un modelo devuelve una selección y no sabe decirte qué se le olvidó.

Uso:
    python3 rule_scope.py --caso imagen --registry reg_*.json
    python3 rule_scope.py --caso imagen --tipo T1 --registry reg_*.json --exclusiones out.md
"""

from __future__ import annotations

import argparse
import fnmatch
import json
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: falta pyyaml. pip install pyyaml --break-system-packages", file=sys.stderr)
    sys.exit(2)

DEFAULT_SCOPE = Path(__file__).resolve().parent.parent / "rules" / "scope.yaml"


def load_registry(paths: list[str]) -> list[dict]:
    rules: list[dict] = []
    seen: set[str] = set()
    for p in paths:
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        skill = data.get("skill", "?")
        for r in data.get("rules", []):
            if r["id"] in seen:
                continue
            seen.add(r["id"])
            r["skill"] = skill
            r["path"] = f"{skill}/{r['file']}"
            rules.append(r)
    return rules


def matches(rule: dict, m: dict) -> bool:
    if "file" in m and not fnmatch.fnmatch(rule["path"], m["file"]):
        return False
    if "text" in m and not re.search(m["text"], rule["text"]):
        return False
    if "marker" in m and m["marker"] not in rule["markers"]:
        return False
    return bool(m)


def main() -> int:
    ap = argparse.ArgumentParser(description="Filtro de alcance por caso")
    ap.add_argument("--caso", required=True)
    ap.add_argument("--tipo")
    ap.add_argument("--registry", nargs="+", required=True)
    ap.add_argument("--scope", default=str(DEFAULT_SCOPE))
    ap.add_argument("--exclusiones", help="escribe el informe de exclusiones para auditar")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.scope).read_text(encoding="utf-8"))
    caso = args.caso

    if args.tipo:
        tipo = (cfg.get("tipos") or {}).get(args.tipo)
        if not tipo:
            print(f"rule_scope: tipo desconocido {args.tipo!r}", file=sys.stderr)
            return 2
        caso = tipo["caso"]

    spec = (cfg.get("casos") or {}).get(caso)
    if not spec:
        disponibles = ", ".join((cfg.get("casos") or {}).keys())
        print(f"rule_scope: caso {caso!r} no definido. Hay: {disponibles}", file=sys.stderr)
        return 2

    rules = load_registry(args.registry)
    entries = spec.get("reglas") or []

    aplican: list[dict] = []
    na: list[tuple[dict, str]] = []
    sin_decidir: list[dict] = []

    for rule in rules:
        hit = next((e for e in entries if matches(rule, e.get("match") or {})), None)
        if hit is None:
            sin_decidir.append(rule)
        elif (hit.get("status") or "").upper() == "APLICA":
            aplican.append(rule)
        else:
            na.append((rule, " ".join((hit.get("reason") or "sin razon").split())))

    por_razon: dict[str, int] = {}
    for _, reason in na:
        por_razon[reason] = por_razon.get(reason, 0) + 1

    if args.json:
        print(json.dumps({
            "caso": caso, "tipo": args.tipo, "total": len(rules),
            "aplican": len(aplican), "na": len(na), "sin_decidir": len(sin_decidir),
        }, ensure_ascii=False, indent=2))
    else:
        print("=" * 70)
        print(f"ALCANCE DEL CASO: {caso}" + (f" / {args.tipo}" if args.tipo else ""))
        print(f"  {spec.get('descripcion', '')}")
        print("=" * 70)
        print(f"  Paso 1 · reglas extraidas de la fuente   {len(rules)}")
        print(f"  Paso 2 · APLICAN a este caso             {len(aplican)}")
        print(f"           NO APLICAN (con razon escrita)  {len(na)}")
        print(f"           SIN DECIDIR                     {len(sin_decidir)}")
        print()
        print("  APLICAN, por archivo:")
        por_archivo: dict[str, int] = {}
        for r in aplican:
            por_archivo[r["path"]] = por_archivo.get(r["path"], 0) + 1
        for path, n in sorted(por_archivo.items(), key=lambda kv: -kv[1])[:12]:
            print(f"    {n:>4}  {path}")
        if len(por_archivo) > 12:
            print(f"          … y {len(por_archivo) - 12} archivos mas")
        print()
        print("  EXCLUIDAS, por razon (esto es lo que se audita):")
        for reason, n in sorted(por_razon.items(), key=lambda kv: -kv[1]):
            print(f"    {n:>4}  {reason[:110]}")
        print()
        if sin_decidir:
            print(f"  GATE CERRADO — {len(sin_decidir)} reglas sin decidir.")
            print("  Ninguna linea de scope.yaml las toca. Agrega la linea que")
            print("  las incluya o las excluya con razon. No se entrega asi.")
            for r in sin_decidir[:6]:
                print(f"    {r['id']}  {r['path']}:{r['line']}")
                print(f"      {r['text'][:110]}")
            if len(sin_decidir) > 6:
                print(f"    … y {len(sin_decidir) - 6} mas")
        else:
            print("  GATE ABIERTO — 0 sin decidir. Cada regla tiene disposicion escrita.")
        print("=" * 70)

    if args.exclusiones:
        out = [
            f"# Exclusiones del caso `{caso}`" + (f" / `{args.tipo}`" if args.tipo else ""),
            "",
            "Lista para auditar con un segundo criterio (paso 3). La pregunta es:",
            "**de estas reglas excluidas, ¿cuál debería aplicar a este caso?**",
            "",
            f"- Reglas totales en la fuente: {len(rules)}",
            f"- Aplican: {len(aplican)} · Excluidas: {len(na)} · Sin decidir: {len(sin_decidir)}",
            "",
        ]
        for reason, n in sorted(por_razon.items(), key=lambda kv: -kv[1]):
            out += [f"## Excluidas por: {reason}", f"", f"{n} reglas.", ""]
            for rule, rsn in na:
                if rsn == reason:
                    out.append(f"- `{rule['path']}:{rule['line']}` — {rule['text'][:180]}")
            out.append("")
        Path(args.exclusiones).write_text("\n".join(out), encoding="utf-8")
        print(f"\ninforme de exclusiones escrito en {args.exclusiones}")

    return 1 if sin_decidir else 0


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/rule_scope.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/rules_sqlite.py -->
# SOURCE FILE: `repo/.claude/hooks/rules_sqlite.py`

#!/usr/bin/env python3
"""Base de datos SQLite de reglas del pipeline visual.

Esquema:

  reglas        una fila por enunciado normativo extraido de los skills
  casos         la taxonomia cerrada de casos de produccion
  regla_caso    que reglas aplican a que casos, con quien lo dijo y que tan fino
  auditorias    correcciones de un criterio externo, con fecha

`origen` en regla_caso distingue como se clasifico:
  archivo   por defecto del archivo completo — grueso, es lo que hay que auditar
  regla     decidido regla por regla — mas fino
  auditoria corregido por un criterio externo — manda sobre los otros dos

Asi la auditoria puede priorizar lo grueso, y siempre se sabe de donde salio
cada dato en vez de tener que creerle a alguien.

Uso:
    python3 rules_sqlite.py init   --registry r_*.json --db rules.sqlite
    python3 rules_sqlite.py load   --db rules.sqlite --clasificacion c.txt --origen regla
    python3 rules_sqlite.py caso   --db rules.sqlite T1
    python3 rules_sqlite.py stats  --db rules.sqlite
    python3 rules_sqlite.py export --db rules.sqlite --csv reglas.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

CASOS = {
    "T1": "maestro de rostro (still, persona, identidad)",
    "T2": "maestro de cuerpo (still, persona completa)",
    "T3": "cuadro con 1 persona (still de escena)",
    "T4": "cuadro con 2 personas (still, contacto/interaccion)",
    "T5": "edicion quirurgica sobre imagen existente",
    "CLIP": "prompt de video / movimiento",
    "SHOT": "planeacion de shots, storyboard, shots.json",
    "GUION": "escritura de guion o tratamiento",
    "MARCA": "extraccion o uso de brand-lock",
    "QA": "critica de render, revision de asset generado",
    "ENTREGA": "empaquetado, preview, entrega a cliente",
    "PROD": "still de producto, comida u objeto (sin persona)",
    "GRAF": "pieza grafica: poster, slide, UI, social, tipografia dominante",
    "MULTI": "multi-panel o grid dentro de una sola imagen",
    "REF": "analisis de imagen de referencia, image-to-prompt",
    "NINGUNO": "no aplica a ningun caso de produccion (meta, ejemplos, docs)",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS reglas (
    id        TEXT PRIMARY KEY,
    skill     TEXT NOT NULL,
    archivo   TEXT NOT NULL,
    linea     INTEGER NOT NULL,
    texto     TEXT NOT NULL,
    marcadores TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS casos (
    codigo      TEXT PRIMARY KEY,
    descripcion TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS regla_caso (
    regla_id TEXT NOT NULL REFERENCES reglas(id),
    caso     TEXT NOT NULL REFERENCES casos(codigo),
    origen   TEXT NOT NULL CHECK (origen IN ('archivo','regla','auditoria')),
    fecha    TEXT NOT NULL,
    PRIMARY KEY (regla_id, caso)
);
CREATE TABLE IF NOT EXISTS auditorias (
    regla_id  TEXT NOT NULL REFERENCES reglas(id),
    antes     TEXT NOT NULL,
    despues   TEXT NOT NULL,
    razon     TEXT,
    auditor   TEXT NOT NULL,
    fecha     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_rc_caso  ON regla_caso(caso);
CREATE INDEX IF NOT EXISTS ix_reglas_sk ON reglas(skill, archivo);

CREATE VIEW IF NOT EXISTS v_sin_clasificar AS
  SELECT r.* FROM reglas r
  LEFT JOIN regla_caso rc ON rc.regla_id = r.id
  WHERE rc.regla_id IS NULL;

CREATE VIEW IF NOT EXISTS v_por_caso AS
  SELECT c.codigo, c.descripcion, COUNT(rc.regla_id) AS reglas
  FROM casos c LEFT JOIN regla_caso rc ON rc.caso = c.codigo
  GROUP BY c.codigo ORDER BY reglas DESC;
"""

LINE_RE = re.compile(r"\[?([0-9a-f]{12})\]?\s*[-—:]?\s*([A-Z0-9,\s]+?)\s*$", re.MULTILINE)


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def connect(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(path)
    con.execute("PRAGMA foreign_keys = ON")
    return con


def cmd_init(args) -> int:
    con = connect(args.db)
    con.executescript(SCHEMA)
    con.executemany(
        "INSERT OR REPLACE INTO casos (codigo, descripcion) VALUES (?,?)", CASOS.items()
    )
    n = 0
    for p in args.registry:
        data = json.loads(Path(p).read_text(encoding="utf-8"))
        skill = data.get("skill", "?")
        for r in data.get("rules", []):
            con.execute(
                "INSERT OR REPLACE INTO reglas VALUES (?,?,?,?,?,?)",
                (r["id"], skill, r["file"], r["line"], r["text"], ",".join(r["markers"])),
            )
            n += 1
    con.commit()
    total = con.execute("SELECT COUNT(*) FROM reglas").fetchone()[0]
    print(f"{n} reglas insertadas · {total} en la base · {len(CASOS)} casos")
    return 0


def cmd_load(args) -> int:
    con = connect(args.db)
    texto = Path(args.clasificacion).read_text(encoding="utf-8")
    ok = mal = desc = 0
    for m in LINE_RE.finditer(texto):
        rid, crudo = m.group(1), m.group(2)
        if not con.execute("SELECT 1 FROM reglas WHERE id=?", (rid,)).fetchone():
            desc += 1
            continue
        casos = [c.strip().upper() for c in crudo.split(",") if c.strip()]
        if not casos or any(c not in CASOS for c in casos):
            mal += 1
            continue
        if args.origen == "auditoria":
            antes = ",".join(
                r[0] for r in con.execute(
                    "SELECT caso FROM regla_caso WHERE regla_id=? ORDER BY caso", (rid,))
            )
            con.execute(
                "INSERT INTO auditorias VALUES (?,?,?,?,?,?)",
                (rid, antes, ",".join(sorted(casos)), args.razon, args.auditor, now()),
            )
            con.execute("DELETE FROM regla_caso WHERE regla_id=?", (rid,))
        for c in casos:
            con.execute(
                "INSERT OR REPLACE INTO regla_caso VALUES (?,?,?,?)", (rid, c, args.origen, now())
            )
        ok += 1
    con.commit()
    pend = con.execute("SELECT COUNT(*) FROM v_sin_clasificar").fetchone()[0]
    print(f"clasificadas: {ok} · invalidas: {mal} · ids inexistentes: {desc}")
    print(f"sin clasificar en la base: {pend}")
    return 1 if (mal or desc) else 0


def cmd_caso(args) -> int:
    con = connect(args.db)
    filas = con.execute(
        """SELECT r.skill, r.archivo, r.linea, r.texto, rc.origen
           FROM regla_caso rc JOIN reglas r ON r.id = rc.regla_id
           WHERE rc.caso = ? ORDER BY r.skill, r.archivo, r.linea""",
        (args.codigo,),
    ).fetchall()
    if not filas:
        print(f"sin reglas para el caso {args.codigo}", file=sys.stderr)
        return 1
    print(f"# {args.codigo} — {CASOS.get(args.codigo,'?')}")
    print(f"# {len(filas)} reglas\n")
    actual = None
    for skill, arch, _ln, texto, origen in filas:
        ruta = f"{skill}/{arch}"
        if ruta != actual:
            actual = ruta
            print(f"\n## {ruta}")
        marca = "" if origen != "archivo" else "  [clasificacion gruesa]"
        print(f"- {texto}{marca}")
    return 0


def cmd_stats(args) -> int:
    con = connect(args.db)
    tot = con.execute("SELECT COUNT(*) FROM reglas").fetchone()[0]
    cls = con.execute("SELECT COUNT(DISTINCT regla_id) FROM regla_caso").fetchone()[0]
    print(f"reglas          {tot}")
    print(f"clasificadas    {cls}  ({cls/max(tot,1)*100:.1f}%)")
    print(f"sin clasificar  {tot-cls}")
    print()
    print("por origen de la clasificacion:")
    for origen, n in con.execute(
        "SELECT origen, COUNT(DISTINCT regla_id) FROM regla_caso GROUP BY origen ORDER BY 2 DESC"
    ):
        print(f"  {origen:10} {n:>5}")
    print()
    print("reglas por caso:")
    for cod, desc, n in con.execute("SELECT * FROM v_por_caso"):
        if n:
            print(f"  {cod:8} {n:>5}   {desc}")
    print()
    print("por skill:")
    for skill, n in con.execute(
        "SELECT skill, COUNT(*) FROM reglas GROUP BY skill ORDER BY 2 DESC"
    ):
        print(f"  {skill:26} {n:>5}")
    aud = con.execute("SELECT COUNT(*) FROM auditorias").fetchone()[0]
    print(f"\ncorrecciones de auditoria: {aud}")
    return 0


def cmd_export(args) -> int:
    con = connect(args.db)
    filas = con.execute(
        """SELECT r.id, r.skill, r.archivo, r.linea, r.texto,
                  GROUP_CONCAT(rc.caso), MIN(rc.origen)
           FROM reglas r LEFT JOIN regla_caso rc ON rc.regla_id = r.id
           GROUP BY r.id ORDER BY r.skill, r.archivo, r.linea"""
    ).fetchall()
    with open(args.csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "skill", "archivo", "linea", "regla", "casos", "origen"])
        w.writerows(filas)
    print(f"{len(filas)} filas -> {args.csv}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Base SQLite de reglas por caso")
    ap.add_argument("--db", default="rules.sqlite")
    sub = ap.add_subparsers(dest="cmd", required=True)

    i = sub.add_parser("init"); i.add_argument("--registry", nargs="+", required=True)
    i.set_defaults(fn=cmd_init)

    l = sub.add_parser("load")
    l.add_argument("--clasificacion", required=True)
    l.add_argument("--origen", choices=("archivo", "regla", "auditoria"), required=True)
    l.add_argument("--auditor", default="notebooklm")
    l.add_argument("--razon", default="")
    l.set_defaults(fn=cmd_load)

    c = sub.add_parser("caso"); c.add_argument("codigo"); c.set_defaults(fn=cmd_caso)
    s = sub.add_parser("stats"); s.set_defaults(fn=cmd_stats)
    e = sub.add_parser("export"); e.add_argument("--csv", default="reglas.csv")
    e.set_defaults(fn=cmd_export)

    args = ap.parse_args()
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())

<!-- SOURCE_FILE_END: repo/.claude/hooks/rules_sqlite.py -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/schema_v2.sql -->
# SOURCE FILE: `repo/.claude/hooks/schema_v2.sql`

-- Esquema v2 — cierra el ciclo de produccion.
--
-- v1 tenia 4 tablas y solo respondia "que reglas aplican a este caso".
-- Faltaba lo que hace auditable la produccion real:
--
--   1. La base se queda vieja en silencio cuando editas un skill.
--      -> tablas skills y archivos, con hash. Un hash distinto marca las
--         reglas de ese archivo como obsoletas en vez de servirlas igual.
--
--   2. No hay forma de probar que una regla se aplico a un prompt.
--      -> tablas prompts y prompt_regla. La pregunta de avance de
--         produccion-visual-sw30 ("¿usaste TODAS las reglas aplicables?")
--         pasa de ser una respuesta de honor a un JOIN.
--
--   3. Los gates bloquean y no queda registro de que se bloqueo ni por que.
--      -> tabla violaciones.
--
--   4. Dos skills pueden contradecirse y nadie lo sabe hasta que duele
--      (§6.1 prohibe "cinematic"; el ejemplo aprobado de image/golden-rules
--      lo usa). -> tabla conflictos.
--
--   5. El objetivo declarado es maxima calidad al menor costo de creditos,
--      y no habia donde medir el costo. -> tabla generaciones.

CREATE TABLE IF NOT EXISTS skills (
    nombre     TEXT PRIMARY KEY,
    ruta       TEXT NOT NULL,
    archivos   INTEGER NOT NULL DEFAULT 0,
    reglas     INTEGER NOT NULL DEFAULT 0,
    extraido   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS archivos (
    skill      TEXT NOT NULL REFERENCES skills(nombre),
    ruta       TEXT NOT NULL,
    sha256     TEXT NOT NULL,
    reglas     INTEGER NOT NULL DEFAULT 0,
    extraido   TEXT NOT NULL,
    PRIMARY KEY (skill, ruta)
);

-- Un prompt entregado. Es la unidad que el usuario paga.
CREATE TABLE IF NOT EXISTS prompts (
    id         TEXT PRIMARY KEY,
    caso       TEXT NOT NULL REFERENCES casos(codigo),
    modelo     TEXT NOT NULL,
    shot_id    TEXT,
    texto      TEXT NOT NULL,
    palabras   INTEGER NOT NULL,
    entregado  TEXT NOT NULL,
    micro_gate INTEGER NOT NULL DEFAULT 0   -- 1 si llevaba cabecera valida
);

-- La traza que convierte "usé todas las reglas" en algo verificable.
CREATE TABLE IF NOT EXISTS prompt_regla (
    prompt_id TEXT NOT NULL REFERENCES prompts(id),
    regla_id  TEXT NOT NULL REFERENCES reglas(id),
    estado    TEXT NOT NULL CHECK (estado IN ('APLICADA','NA','OMITIDA')),
    nota      TEXT,
    PRIMARY KEY (prompt_id, regla_id)
);

-- Que bloqueo cada gate y por que. Sin esto los gates no dejan historia.
CREATE TABLE IF NOT EXISTS violaciones (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    prompt_id TEXT REFERENCES prompts(id),
    gate      TEXT NOT NULL,
    regla_id  TEXT REFERENCES reglas(id),
    detalle   TEXT NOT NULL,
    resuelta  INTEGER NOT NULL DEFAULT 0,
    fecha     TEXT NOT NULL
);

-- Reglas que se contradicen entre si. Se registran, no se resuelven solas.
CREATE TABLE IF NOT EXISTS conflictos (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    regla_a   TEXT NOT NULL REFERENCES reglas(id),
    regla_b   TEXT NOT NULL REFERENCES reglas(id),
    tipo      TEXT NOT NULL,
    gana      TEXT REFERENCES reglas(id),
    autoridad TEXT,
    fecha     TEXT NOT NULL
);

-- El costo. El objetivo del skill es maxima calidad al menor costo de creditos.
CREATE TABLE IF NOT EXISTS generaciones (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    prompt_id TEXT NOT NULL REFERENCES prompts(id),
    modelo    TEXT NOT NULL,
    creditos  REAL,
    veredicto TEXT CHECK (veredicto IN ('ACCEPT','REVISE','REJECT')),
    ronda     INTEGER NOT NULL DEFAULT 1,
    fecha     TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS ix_pr_regla   ON prompt_regla(regla_id);
CREATE INDEX IF NOT EXISTS ix_viol_gate  ON violaciones(gate);
CREATE INDEX IF NOT EXISTS ix_gen_prompt ON generaciones(prompt_id);
CREATE INDEX IF NOT EXISTS ix_arch_sha   ON archivos(sha256);

-- Reglas cuyo archivo de origen cambio desde que se extrajeron.
-- Servir una de estas es servir una regla que ya no dice lo mismo.
CREATE VIEW IF NOT EXISTS v_reglas_obsoletas AS
  SELECT r.id, r.skill, r.archivo, r.texto, a.sha256 AS sha_registrado
  FROM reglas r JOIN archivos a ON a.skill = r.skill AND a.ruta = r.archivo
  WHERE a.extraido < (SELECT MAX(extraido) FROM archivos);

-- Cobertura real por prompt: de las reglas de su caso, cuantas se dispusieron.
CREATE VIEW IF NOT EXISTS v_cobertura_prompt AS
  SELECT p.id, p.caso, p.modelo,
         (SELECT COUNT(*) FROM regla_caso rc WHERE rc.caso = p.caso)      AS aplicables,
         (SELECT COUNT(*) FROM prompt_regla pr WHERE pr.prompt_id = p.id) AS dispuestas,
         (SELECT COUNT(*) FROM prompt_regla pr
           WHERE pr.prompt_id = p.id AND pr.estado = 'OMITIDA')           AS omitidas
  FROM prompts p;

-- Costo por caso: cuantos creditos cuesta llegar a un ACCEPT.
CREATE VIEW IF NOT EXISTS v_costo_por_caso AS
  SELECT p.caso,
         COUNT(DISTINCT p.id)                                  AS prompts,
         COUNT(g.id)                                           AS generaciones,
         ROUND(SUM(COALESCE(g.creditos, 0)), 2)                AS creditos,
         SUM(CASE WHEN g.veredicto = 'ACCEPT' THEN 1 ELSE 0 END) AS aceptadas,
         ROUND(1.0 * COUNT(g.id) /
               NULLIF(SUM(CASE WHEN g.veredicto = 'ACCEPT' THEN 1 ELSE 0 END), 0), 2)
                                                               AS intentos_por_accept
  FROM prompts p LEFT JOIN generaciones g ON g.prompt_id = p.id
  GROUP BY p.caso;

<!-- SOURCE_FILE_END: repo/.claude/hooks/schema_v2.sql -->


<!-- SOURCE_FILE_START: repo/.claude/hooks/verify.sh -->
# SOURCE FILE: `repo/.claude/hooks/verify.sh`

#!/usr/bin/env bash
# Self-verification for the production gates. Run it yourself; trust the output,
# not a claim in a chat message.
#
#   bash .claude/hooks/verify.sh
#
# Every case below asserts an exit code. A gate that stops working fails loudly
# here instead of passing prompts through in silence.

set -uo pipefail
# El propio verify.sh se valida antes de correr: un error de sintaxis aqui hace
# que la suite reporte verde sin haber corrido los ultimos casos.
bash -n "${BASH_SOURCE[0]}" || { echo "verify.sh tiene un error de sintaxis"; exit 2; }

HOOKS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export HOOKS
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
# El breaker cuenta bloqueos consecutivos por sesion. Sin esto, el estado de una
# corrida anterior hace que la suite se comporte distinto la segunda vez.
rm -rf "${TMPDIR:-/tmp}/fupai-gate"
PASS=0
FAIL=0

fire() { # fire <script> <json-payload> -> echoes exit code, captures stderr
  printf '%s' "$2" | python3 "$HOOKS/$1" 2>"$TMP/err" >/dev/null
  echo $?
}

check() { # check <name> <expected> <actual>
  if [[ "$2" == "$3" ]]; then
    printf '  \033[32mPASS\033[0m  %-52s exit=%s\n' "$1" "$3"
    PASS=$((PASS + 1))
  else
    printf '  \033[31mFAIL\033[0m  %-52s exit=%s (esperado %s)\n' "$1" "$3" "$2"
    sed 's/^/          /' "$TMP/err" | head -6
    FAIL=$((FAIL + 1))
  fi
}

msg() { python3 -c 'import json,sys;print(json.dumps({"session_id":sys.argv[1],"hook_event_name":"Stop","last_assistant_message":sys.argv[2]}))' "$1" "$2"; }
wrote() { python3 -c 'import json,sys;print(json.dumps({"session_id":"v","hook_event_name":"PostToolUse","tool_name":"Write","tool_input":{"file_path":sys.argv[1]}}))' "$1"; }

echo
echo "=== GATE 6.1 — vocabulario prohibido (fuente: video/references/dramaturgy.md) ==="

TERMS=$(python3 - <<'PY'
import importlib.util, os, sys
spec = importlib.util.spec_from_file_location("g", os.path.join(os.environ["HOOKS"], "gate_dramaturgy.py"))
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
p = g.find_dramaturgy()
if p is None:
    print("0"); sys.exit()
print(len(g.load_banned(p)))
PY
)
if [[ "${TERMS:-0}" -gt 0 ]]; then
  printf '  \033[32mPASS\033[0m  %-52s %s terminos\n' "lee la lista prohibida del skill video" "$TERMS"
  PASS=$((PASS + 1))
else
  printf '  \033[31mFAIL\033[0m  %-52s\n' "NO encuentra video/references/dramaturgy.md"
  FAIL=$((FAIL + 1))
fi

check "bloquea prompt con vocabulario prohibido" 2 \
  "$(fire gate_dramaturgy.py "$(msg v1 'Prompt:

```
Wide shot, cinematic lighting, epic and stunning, masterpiece.
```')")"

check "deja pasar prompt limpio" 0 \
  "$(fire gate_dramaturgy.py "$(msg v2 'Prompt:

```
Wide shot, 35mm. Wet asphalt throws a sodium-lamp streak. Knuckles whiten.
```')")"

check "no confunde prosa con entrega de prompt" 0 \
  "$(fire gate_dramaturgy.py "$(msg v3 'La palabra cinematic esta prohibida, igual que epic y masterpiece.')")"

check "respeta OVERRIDE explicito" 0 \
  "$(fire gate_dramaturgy.py "$(msg v4 'OVERRIDE: cinematic - el tagline on-screen lo exige

```
Wet asphalt, sodium lamp. On-screen text reads "cinematic".
```')")"

BAD="$(msg brk 'Prompt para Nano Banana Pro:

```
Create a shot with cinematic epic masterpiece lighting.
Format: 4:5
```')"
for _ in 1 2 3; do fire gate_dramaturgy.py "$BAD" >/dev/null; done
check "libera el turno tras 3 bloqueos (anti-deadlock)" 1 \
  "$(fire gate_dramaturgy.py "$BAD")"

check "avisa fuerte si no encuentra el skill video" 1 \
  "$(FUPAI_SKILLS_ROOT=/no/existe fire gate_dramaturgy.py "$(msg v6 'Prompt para Nano Banana:

```
Create a cinematic shot.
Format: 4:5
```')")"

echo
echo "=== INYECCION — la lectura deja de ser eleccion del modelo ==="

inj() { python3 -c 'import json,sys;print(json.dumps({"hook_event_name":"UserPromptSubmit","prompt":sys.argv[1]}))' "$1" \
  | python3 "$HOOKS/inject_rules.py" 2>/dev/null; }

CHARS=$(inj "dame un prompt de imagen para Nano Banana del ancla" \
  | python3 -c 'import json,sys;d=sys.stdin.read();print(len(json.loads(d)["hookSpecificOutput"]["additionalContext"]) if d.strip() else 0)')
if [[ "${CHARS:-0}" -gt 20000 ]]; then
  printf '  \033[32mPASS\033[0m  %-52s %s chars\n' "inyecta las fuentes obligatorias verbatim" "$CHARS"
  PASS=$((PASS + 1))
else
  printf '  \033[31mFAIL\033[0m  %-52s %s chars\n' "inyecta las fuentes obligatorias verbatim" "${CHARS:-0}"
  FAIL=$((FAIL + 1))
fi

NAMES=$(inj "dame un prompt de imagen para Nano Banana" \
  | python3 -c 'import json,sys;d=sys.stdin.read();print(json.loads(d)["hookSpecificOutput"]["additionalContext"].splitlines()[3] if d.strip() else "")')
if [[ "$NAMES" == *"produccion-visual-sw30"* && "$NAMES" == *"golden-rules"* ]]; then
  printf '  \033[32mPASS\033[0m  %-52s\n' "incluye sw30 + golden-rules en un caso de imagen"
  PASS=$((PASS + 1))
else
  printf '  \033[31mFAIL\033[0m  %-52s %s\n' "incluye sw30 + golden-rules" "$NAMES"
  FAIL=$((FAIL + 1))
fi

if [[ -z "$(inj 'que hora es')" ]]; then
  printf '  \033[32mPASS\033[0m  %-52s\n' "no inyecta en prompts ajenos a produccion"
  PASS=$((PASS + 1))
else
  printf '  \033[31mFAIL\033[0m  %-52s\n' "inyecta donde no debe"
  FAIL=$((FAIL + 1))
fi

echo
echo "=== MICRO-GATE — cabecera de 3 lineas (produccion-visual-sw30) ==="

check "bloquea entrega de prompt sin cabecera" 2 \
  "$(fire gate_microgate.py "$(msg m1 'Prompt para Nano Banana:

```
Create an editorial portrait of a runner. Format: 4:5
```')")"

check "acepta cabecera con archivo real y campos llenos" 0 \
  "$(fire gate_microgate.py "$(msg m2 'SKILL: image/references/golden-rules.md secciones 1-7
RIESGOS: look plastico por luz suave; lo mitiga la linea de luz dura rasante
TECNICA: template T1 de rostro, fuente produccion-visual-sw30/SKILL.md

Prompt para Nano Banana:

```
Create an editorial portrait of a runner. Format: 4:5
```')")"

check "rechaza cabecera de relleno (archivo inexistente)" 2 \
  "$(fire gate_microgate.py "$(msg m3 'SKILL: mis notas internas
RIESGOS: varios
TECNICA: ninguna

```
Create a portrait for Nano Banana. Format: 4:5
```')")"

check "no exige cabecera si no hay entrega visual" 0 \
  "$(fire gate_microgate.py "$(msg m4 'Te explico como funciona el micro-gate, sin entregar prompts.')")"

echo
echo "=== GATE IMAGEN — golden rules (fuente: image/references/golden-rules.md) ==="

VERBS=$(python3 - <<'PY'
import importlib.util, os, sys
spec = importlib.util.spec_from_file_location("g", os.path.join(os.environ["HOOKS"], "gate_image.py"))
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
p = g.find_golden_rules()
print(len(g.load_verbs(p)) if p else 0)
PY
)
if [[ "${VERBS:-0}" -gt 0 ]]; then
  printf '  \033[32mPASS\033[0m  %-52s %s verbos\n' "lee las golden rules del skill image" "$VERBS"
  PASS=$((PASS + 1))
else
  printf '  \033[31mFAIL\033[0m  %-52s\n' "NO encuentra image/references/golden-rules.md"
  FAIL=$((FAIL + 1))
fi

check "bloquea keyword soup (R4) y falta de verbo (R1)" 2 \
  "$(fire gate_image.py "$(msg i1 'Prompt para Nano Banana:

```
Cool shoe, neon, city, night, 8k
```')")"

check "bloquea prompt sin modelo destino declarado (6.2)" 2 \
  "$(fire gate_image.py "$(msg i2 'Anchor:

```
Create an editorial portrait of a runner in a stadium tunnel.
Format: 4:5
```')")"

check "deja pasar el ejemplo aprobado del skill (Havana)" 0 \
  "$(fire gate_image.py "$(msg i3 'Prompt para GPT Image 2:

```
Create an editorial portrait set in Havana, 1957.
Subject: jazz musician against a pastel colonial building, trumpet at his side.
Format: 3:4
```')")"

check "no bloquea por R2 (el skill aprueba \"no makeup\")" 0 \
  "$(fire gate_image.py "$(msg i4 'Prompt para Nano Banana Pro:

```
Create a fashion editorial portrait with Peter Lindbergh influence.
Subject: model in oversized blazer, no makeup, wind-tousled hair.
Format: 2:3
```')")"

check "no opina sobre un prompt de video (Kling)" 0 \
  "$(fire gate_image.py "$(msg i5 'Prompt para Kling 3.0:

```
Wide shot, 35mm. Wet asphalt throws a sodium-lamp streak. Knuckles whiten.
```')")"

check "respeta OVERRIDE de regla" 0 \
  "$(fire gate_image.py "$(msg i6 'OVERRIDE: R1 - el cliente entrega el prompt ya redactado

Prompt para Nano Banana:

```
A wide shot of wet asphalt under a sodium lamp.
```')")"

echo
echo "=== GATE ETAPA 4 — validate_shots.py (shotkit) ==="

ARCH=$(python3 - <<'PY'
import importlib.util, os
spec = importlib.util.spec_from_file_location("g", os.path.join(os.environ["HOOKS"], "gate_shots.py"))
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
print(g.find_architect() or "")
PY
)

if [[ -z "$ARCH" ]]; then
  printf '  \033[31mFAIL\033[0m  %-52s\n' "storyboard-architect no encontrado"
  FAIL=$((FAIL + 1))
elif ! python3 -c "import jsonschema" 2>/dev/null; then
  printf '  \033[31mFAIL\033[0m  %-52s\n' "falta jsonschema (pip install jsonschema)"
  FAIL=$((FAIL + 1))
else
  EX="$ARCH/examples/30s-pain-proof-promise"
  cp "$EX"/* "$TMP/" 2>/dev/null

  check "deja pasar un shot list valido" 0 "$(fire gate_shots.py "$(wrote "$TMP/shots.json")")"

  python3 - "$TMP/shots.json" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p))
d["shots"][1]["start"] = 0.8          # solape con shot_01
json.dump(d, open(p, "w"), indent=2)
PY
  check "bloquea solape de timing entre shots" 2 "$(fire gate_shots.py "$(wrote "$TMP/shots.json")")"

  check "ignora archivos que no son del pipeline" 0 "$(fire gate_shots.py "$(wrote "$TMP/README.md")")"

  rm -rf "$ARCH/skills"
  check "repara solo el shim de rutas de shotkit" 2 "$(fire gate_shots.py "$(wrote "$TMP/shots.json")")"
  [[ -L "$ARCH/skills/storyboard-architect" ]] \
    && { printf '  \033[32mPASS\033[0m  %-52s\n' "shim recreado tras borrarlo"; PASS=$((PASS + 1)); } \
    || { printf '  \033[31mFAIL\033[0m  %-52s\n' "shim NO recreado"; FAIL=$((FAIL + 1)); }
fi

echo
echo "=== REGISTRY + LEDGER — cobertura sobre la fuente, no sobre la memoria ==="

python3 "$HOOKS/rule_registry.py" --skill image --out "$TMP/reg.json" --stats >"$TMP/reg.log" 2>&1
N=$(grep -oE 'enunciados:[[:space:]]+[0-9]+' "$TMP/reg.log" | grep -oE '[0-9]+')
if [[ "${N:-0}" -gt 100 ]]; then
  printf '  \033[32mPASS\033[0m  %-52s %s enunciados\n' "extrae reglas del skill image" "$N"
  PASS=$((PASS + 1))
else
  printf '  \033[31mFAIL\033[0m  %-52s %s\n' "extrae reglas del skill image" "${N:-0}"
  FAIL=$((FAIL + 1))
fi

echo '{}' > "$TMP/disp.json"
python3 "$HOOKS/rule_ledger.py" --registry "$TMP/reg.json" --dispositions "$TMP/disp.json" >/dev/null 2>&1
check "ledger cierra el gate con reglas sin disponer" 1 "$?"

FIRST=$(python3 -c "import json,sys;print(json.load(open(sys.argv[1]))['rules'][0]['id'])" "$TMP/reg.json")
python3 -c "
import json,sys
rid=sys.argv[1]
json.dump({rid:{'status':'CHECK'}}, open(sys.argv[2],'w'))
" "$FIRST" "$TMP/disp.json"
python3 "$HOOKS/rule_ledger.py" --registry "$TMP/reg.json" --dispositions "$TMP/disp.json" >/dev/null 2>&1
check "rechaza CHECK sin decir quien lo verifica" 1 "$?"

python3 -c "
import json,sys
reg=json.load(open(sys.argv[1]))
json.dump({r['id']:{'status':'NA','reason':'prueba'} for r in reg['rules']}, open(sys.argv[2],'w'))
" "$TMP/reg.json" "$TMP/disp.json"
python3 "$HOOKS/rule_ledger.py" --registry "$TMP/reg.json" --dispositions "$TMP/disp.json" >/dev/null 2>&1
check "abre el gate solo al 100% dispuesto" 0 "$?"

python3 -c "
import json,sys
d=json.load(open(sys.argv[1])); d['000000000000']={'status':'NA','reason':'huerfana'}
json.dump(d, open(sys.argv[1],'w'))
" "$TMP/disp.json"
STALE=$(python3 "$HOOKS/rule_ledger.py" --registry "$TMP/reg.json" --dispositions "$TMP/disp.json" --json 2>/dev/null | python3 -c 'import json,sys;print(json.load(sys.stdin)["stale"])')
check "detecta disposiciones huerfanas (STALE)" 1 "$STALE"

echo
echo "=== FALSOS POSITIVOS — un gate que bloquea texto tecnico se desactiva ==="

TECNICO='Donde para:

```
get_health  -> authenticated: false
```

```bash
python3 nblm_load.py --corpus notebooklm-corpus
```'
for g in gate_image gate_dramaturgy gate_microgate; do
  check "$g deja pasar salida de terminal y shell" 0 "$(fire $g.py "$(msg fp-$g "$TECNICO")")"
done

check "no bloquea shell aunque la prosa nombre el modelo" 0 \
  "$(fire gate_image.py "$(msg fp2 'Para generar con Nano Banana corre:

```bash
python3 gen.py --model nano-banana
```')")"

check "no bloquea terminal con palabras prohibidas dentro" 0 \
  "$(fire gate_dramaturgy.py "$(msg fp3 'Resultado:

```
  PASS  professional check   exit=0
  FAIL  high quality assert  exit=1
```')")"

check "no bloquea un bloque json etiquetado" 0 \
  "$(fire gate_dramaturgy.py "$(msg fp4 '```json
{"style": "cinematic", "q": "high quality"}
```')")"

echo
echo "=== payload corrupto (ningun gate debe morir en silencio) ==="
check "gate_dramaturgy sobrevive a JSON invalido" 1 "$(fire gate_dramaturgy.py 'no soy json')"
check "gate_image sobrevive a JSON invalido"      1 "$(fire gate_image.py 'no soy json')"
check "gate_shots sobrevive a JSON invalido"      1 "$(fire gate_shots.py 'no soy json')"

echo
echo "-------------------------------------------------------------------"
printf '  %s pasaron · %s fallaron\n' "$PASS" "$FAIL"
echo "-------------------------------------------------------------------"
echo
[[ "$FAIL" -eq 0 ]] || exit 1

<!-- SOURCE_FILE_END: repo/.claude/hooks/verify.sh -->


<!-- SOURCE_FILE_START: repo/.claude/rules/METODO.md -->
# SOURCE FILE: `repo/.claude/rules/METODO.md`

# El método: seleccionar todas, después aplicar las que corresponden

El problema nunca fue no tener las reglas. Fue que la **selección** de qué reglas
aplican salía de la memoria del agente, y ahí siempre faltaban las mismas.

Son dos pasos y no se pueden fusionar.

## Paso 1 — Tenerlas TODAS

```bash
python3 .claude/hooks/rule_registry.py --skill image --out reg_image.json --stats
```

Extracción mecánica de cada enunciado normativo de los archivos del skill. Nadie
elige: una línea entra porque lleva un marcador deóntico (`never`, `must`,
`always`, `❌`, `✅`, regla numerada…), no porque alguien la recordara. Cada regla
recibe un id estable `sha1(ruta + texto)`, que sobrevive a que se muevan líneas y
cambia cuando cambia la redacción.

Estado medido hoy: **1,210 enunciados** en el pipeline visual completo.

| skill | reglas | | skill | reglas |
|---|---:|---|---|---:|
| `video` | 348 | | `brand-lock-extractor` | 89 |
| `visual-prompt-forge` | 180 | | `visual-asset-critic` | 63 |
| `storyboard-architect` | 177 | | `screenwriter` | 57 |
| `image` | 167 | | `produccion-visual-sw30` | 45 |
| `ai-video-storyboard` | 35 | | `ai-production-director` | 25 |
| `storyboard-html-preview` | 24 | | `visual-media` | 0 |

Reproducible: `for s in ...; do rule_registry.py --skill $s --stats; done`.

## Paso 2 — Decidir cuáles aplican a ESTE caso

**Lo hace NotebookLM, no el agente.** Decisión de dirección, y el razonamiento es
correcto: hay evidencia directa de que la selección del agente falla — en la sesión
donde se construyó esto se saltó dos veces un skill que estaba instalado desde el
primer minuto — y evidencia directa de que NotebookLM funciona.

```bash
python3 .claude/hooks/rule_export.py \
  --registry reg_image.json --out fuente.md --pregunta pregunta.txt \
  --caso "maestro de rostro T1, Nano Banana Pro"
```

Produce el documento a subir al notebook (todas las reglas, una por línea, con su
id) y la pregunta canónica: clasificar **cada** id como `APLICA` o `NO APLICA` con
razón. El servidor MCP está declarado en `.mcp.json`; requiere Chrome y una
autenticación inicial con pantalla.

`.claude/rules/scope.yaml` queda como respaldo determinista para cuando NotebookLM
no esté disponible. **No es la autoridad** — es el plan B, y su criterio es del
agente, por eso está escrito para poder discutirse línea por línea.

## Paso 3 — Medir que la selección fue exhaustiva

```bash
python3 .claude/hooks/rule_answer_check.py \
  --registry reg_image.json --respuesta respuesta.txt --faltantes faltan.txt
```

No juzga si la selección fue acertada — eso es criterio, y el criterio ya no es del
agente. Mide cobertura y detecta tres cosas:

- **SIN MENCIONAR** — reglas del registro que la respuesta no clasificó.
- **Ids inexistentes** — ids citados que no están en el registro.
- **Contradictorias** — la misma regla clasificada `APLICA` y `NO APLICA`.

Sale con código 1 si aparece cualquiera de las tres. Con `0 sin mencionar`, la
exhaustividad queda **demostrada** en vez de supuesta, y ya nadie tiene que
creerle a nadie.

## Por qué el paso 3 existe

No es desconfianza hacia NotebookLM. Es que sin él, "fue exhaustivo" es una
opinión, y este repo existe justamente porque las opiniones sobre cumplimiento no
resultaron confiables. El paso 3 cuesta un comando y convierte la afirmación en un
número. Si el número sale 100%, la objeción se muere con datos.

## Un caso real de por qué el paso 1 no lo puede hacer el agente

Durante esta sesión el agente afirmó que el skill `image` **no tenía lista de
vocabulario prohibido propia**. Sí la tiene:
`image/references/gpt-image.md:36` — *stunning, incredible, epic, gorgeous,
masterpiece*. Y `models.md:49` añade que en GPT Image 2 esas palabras **empeoran**
el resultado, mientras que Nano Banana simplemente las ignora.

La afirmación falsa salió de buscar encabezados con grep en vez de leer los
archivos. Es exactamente lo que el propio `image/SKILL.md:18` advierte:

> *"The body of this SKILL.md is intentionally thin so you cannot fake a result by
> reading it alone. The actual rules live only in the reference files."*

El paso 1 existe para que ese error sea imposible: la extracción no busca, lee todo.

<!-- SOURCE_FILE_END: repo/.claude/rules/METODO.md -->


<!-- SOURCE_FILE_START: repo/.claude/rules/scope.yaml -->
# SOURCE FILE: `repo/.claude/rules/scope.yaml`

# Filtro de alcance por caso — paso 2 del metodo.
#
# Paso 1 lo hace rule_registry.py: extrae TODAS las reglas, mecanicamente.
# Paso 2 es este archivo: decide cuales aplican a cada caso.
#
# La unica forma de excluir una regla es escribir aqui por que no aplica.
# Lo que ninguna linea toque queda SIN DECIDIR, y sin decidir no se entrega.
#
# Cada entrada:
#   match:  file (glob sobre skill/ruta) | text (regex) | marker
#   status: APLICA | NA
#   reason: obligatorio en NA. Es lo que Eric audita y discute.
#
# El orden importa: gana la primera entrada que haga match.

casos:
  # ---------------------------------------------------------------- IMAGEN
  imagen:
    descripcion: "Cualquier still: maestro, cuadro, ancla, keyframe, edicion."
    reglas:
      - match: {file: "video/**"}
        status: NA
        reason: "Medio distinto. Son reglas de movimiento, camara en el tiempo y
                 protocolo de dialogo; un still no tiene ninguno de los tres.
                 EXCEPCION abajo: el vocabulario prohibido si aplica."
      - match: {file: "video/references/dramaturgy.md", text: "(?i)banned|prohib"}
        status: APLICA
        reason: "ai-production-director 6.1 dice que este vocabulario gana siempre,
                 sobre imagen tambien."
      - match: {file: "screenwriter/**"}
        status: NA
        reason: "Etapa 2 del pipeline. Un prompt de imagen no escribe guion."
      - match: {file: "storyboard-html-preview/**"}
        status: NA
        reason: "Etapa 7, formato de entrega al cliente. No toca la redaccion del prompt."
      - match: {file: "ai-video-storyboard/**"}
        status: NA
        reason: "Solo track EXPRESS de video, segun la tabla de sub-skills del director."
      - match: {file: "visual-media/**"}
        status: NA
        reason: "El director seccion 7 la limita a animacion y material didactico ES."
      - match: {file: "brand-lock-extractor/**"}
        status: NA
        reason: "Etapa 0. Se corre una vez por marca, no por prompt. Si el brand-lock
                 no existe todavia, este caso no es imagen: es Etapa 0."
      - match: {file: "storyboard-architect/**"}
        status: NA
        reason: "Etapa 4. Define el shot; el prompt lo ejecuta. El shot ya esta cerrado
                 cuando se escribe el prompt."
      - match: {file: "visual-asset-critic/**"}
        status: NA
        reason: "Corre DESPUES del render, sobre la imagen. No sobre el texto del prompt."
      - match: {file: "image/**"}
        status: APLICA
        reason: "Autoridad de sintaxis final de imagen, Etapa 5."
      - match: {file: "produccion-visual-sw30/**"}
        status: APLICA
        reason: "Reglas criticas y micro-gate. Su descripcion dice APLICAR ANTES de producir."
      - match: {file: "ai-production-director/**"}
        status: APLICA
        reason: "Orquestador. Gates, resolucion de conflictos y trazabilidad."
      - match: {file: "visual-prompt-forge/**"}
        status: APLICA
        reason: "Dueno del flujo shots.json -> borrador de prompt, Etapa 5."

  # ----------------------------------------------------------------- VIDEO
  video:
    descripcion: "Prompt de movimiento para Kling, Veo, Sora, Seedance, Hailuo."
    reglas:
      - match: {file: "image/references/patterns/**"}
        status: NA
        reason: "Patrones de composicion de still (ecommerce, moda, comida). El anchor
                 ya fija la composicion; el prompt de video no la re-describe."
      - match: {file: "screenwriter/**"}
        status: NA
        reason: "Etapa 2. El guion ya esta cerrado cuando se escribe el prompt de clip."
      - match: {file: "storyboard-html-preview/**"}
        status: NA
        reason: "Etapa 7, entrega. No toca la redaccion del prompt."
      - match: {file: "brand-lock-extractor/**"}
        status: NA
        reason: "Etapa 0, una vez por marca."
      - match: {file: "visual-asset-critic/**"}
        status: NA
        reason: "Corre sobre el render, no sobre el texto."
      - match: {file: "visual-media/**"}
        status: NA
        reason: "Director seccion 7: solo animacion y material didactico ES."
      - match: {file: "video/**"}
        status: APLICA
        reason: "Autoridad de sintaxis final de video, Etapa 6."
      - match: {file: "image/**"}
        status: APLICA
        reason: "El anchor de partida es una imagen; su sintaxis condiciona el clip."
      - match: {file: "produccion-visual-sw30/**"}
        status: APLICA
        reason: "Reglas criticas y micro-gate, aplican a imagen y video."
      - match: {file: "ai-production-director/**"}
        status: APLICA
        reason: "Orquestador."
      - match: {file: "storyboard-architect/**"}
        status: APLICA
        reason: "shots.json es la fuente de verdad de la Etapa 4 en adelante."
      - match: {file: "visual-prompt-forge/**"}
        status: APLICA
        reason: "Estructura el prompt de movimiento desde shots.json, Etapa 6."
      - match: {file: "ai-video-storyboard/**"}
        status: NA
        reason: "Solo track EXPRESS. Si el proyecto es EXPRESS, usar el caso 'video-express'."

# Tipos de la matriz de produccion-visual-sw30. Estrechan el caso, no lo sustituyen.
tipos:
  T1: {caso: imagen, descripcion: "maestro de rostro"}
  T2: {caso: imagen, descripcion: "maestro de cuerpo"}
  T3: {caso: imagen, descripcion: "cuadro 1 persona"}
  T4: {caso: imagen, descripcion: "cuadro 2 personas"}
  T5: {caso: imagen, descripcion: "edicion quirurgica"}

<!-- SOURCE_FILE_END: repo/.claude/rules/scope.yaml -->


<!-- SOURCE_FILE_START: repo/.claude/settings.json -->
# SOURCE FILE: `repo/.claude/settings.json`

{
  "hooks": {
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$CLAUDE_PROJECT_DIR/.claude/hooks/inject_rules.py\"",
            "timeout": 30,
            "statusMessage": "Inyectando reglas obligatorias..."
          }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$CLAUDE_PROJECT_DIR/.claude/hooks/gate_microgate.py\"",
            "timeout": 30,
            "statusMessage": "Micro-gate: cabecera de 3 lineas..."
          },
          {
            "type": "command",
            "command": "python3 \"$CLAUDE_PROJECT_DIR/.claude/hooks/gate_dramaturgy.py\"",
            "timeout": 30,
            "statusMessage": "Gate 6.1: vocabulario prohibido..."
          },
          {
            "type": "command",
            "command": "python3 \"$CLAUDE_PROJECT_DIR/.claude/hooks/gate_image.py\"",
            "timeout": 30,
            "statusMessage": "Gate imagen: golden rules..."
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$CLAUDE_PROJECT_DIR/.claude/hooks/gate_shots.py\"",
            "timeout": 60,
            "statusMessage": "Gate Etapa 4: validate_shots.py..."
          }
        ]
      }
    ]
  }
}

<!-- SOURCE_FILE_END: repo/.claude/settings.json -->


<!-- SOURCE_FILE_START: repo/.gitignore -->
# SOURCE FILE: `repo/.gitignore`

__pycache__/
*.pyc
respuesta.txt
reg_*.json
rules.db.json
tandas/
nblm-ids/
notebooklm-corpus/
rules.sqlite
reglas.csv
auditorias.csv
export-casos/
reglas-produccion.xlsx
node_modules/
.vercel/

<!-- SOURCE_FILE_END: repo/.gitignore -->


<!-- SOURCE_FILE_START: repo/.mcp.json -->
# SOURCE FILE: `repo/.mcp.json`

{
  "mcpServers": {
    "notebooklm": {
      "command": "npx",
      "args": ["-y", "notebooklm-mcp@latest"]
    }
  }
}

<!-- SOURCE_FILE_END: repo/.mcp.json -->


<!-- SOURCE_FILE_START: repo/VERCEL.md -->
# SOURCE FILE: `repo/VERCEL.md`

# Desplegar el ejecutor en Vercel

La misma página corre en dos lugares y se adapta sola:

| | Dentro de claude.ai (artifact) | Servida desde Vercel |
|---|---|---|
| Modelo | Claude, capacidad `sample` del visor | OpenAI (`OPENAI_MODEL`, por defecto `gpt-6-astra`) vía `POST /api/sample` |
| Quién paga | la cuenta de quien abre la página | la cuenta del `OPENAI_API_KEY` |
| Guardado | capacidad `db` | `localStorage` del navegador |
| Evaluador de video | análisis escena por escena de Higgsfield | cuadros extraídos en el navegador |

La detección es automática: si no hay `window.claude`, la página consulta
`/api/config` y usa el servidor.

## Variables de entorno del proyecto

| Variable | Obligatoria | Para qué |
|---|---|---|
| `OPENAI_API_KEY` | sí | Sin ella la app carga pero no puede generar ni auditar nada. Se crea en platform.openai.com → API keys. |
| `APP_PASSWORD` | recomendada | Sin ella, cualquiera con la URL gasta la cuenta del API key. La página la pide una vez y la guarda en el navegador. |
| `OPENAI_MODEL` | no | Id del modelo. Si falta se usa `gpt-6-astra`. Debe ser uno al que la cuenta tenga acceso (platform.openai.com → Limits). |

Se ponen en Vercel → Project → Settings → Environment Variables, y después
hay que volver a desplegar para que las tome.

## Qué sirve cada ruta

- `/` → `public/index.html`, la app completa con las 852 reglas embebidas.
- `/api/config` → `{servidor, ia, modelo, clave, claveOk}`. La página la consulta al abrir.
- `/api/sample` → puente con la Responses API de OpenAI. Responde SSE. El
  ajuste de esfuerzo de la app (alto/medio/bajo) se traduce a
  `reasoning.effort` (`xhigh`/`high`/`low`); el resumen del razonamiento se
  transmite como "pensando" mientras el modelo no ha escrito la primera letra.
- El bloque de reglas va primero en cada petición y con `prompt_cache_key`
  fijo, para que el cache de prompt de OpenAI lo reutilice entre rondas.

`maxDuration` de `/api/sample` está en 300 segundos porque una etapa con
esfuerzo alto puede tardar varios minutos.

## Regenerar la página

`public/index.html` y `app/ejecutor.html` se generan de la base de reglas:

```bash
python3 app/build_app.py --db rules.sqlite --out app/ejecutor.html --public public/index.html
```

No se editan a mano: el contenido vive en `app/build_app.py` y en
`rules.sqlite`.

<!-- SOURCE_FILE_END: repo/VERCEL.md -->


<!-- SOURCE_FILE_START: repo/api/config.js -->
# SOURCE FILE: `repo/api/config.js`

// Lo que la pagina necesita saber del servidor antes de pedir nada:
// si hay API key configurada, si hay que pedir contrasena, y si la que trae
// es la correcta. Verificar aqui cuesta cero: no toca el modelo.

export default function handler(req, res) {
  const clave = process.env.APP_PASSWORD;
  const dada = req.headers["x-app-password"];
  res.setHeader("Cache-Control", "no-store");
  res.status(200).json({
    servidor: true,
    ia: Boolean(process.env.OPENAI_API_KEY),
    modelo: process.env.OPENAI_MODEL || "gpt-6-astra",
    clave: Boolean(clave),
    claveOk: clave ? dada === clave : true,
  });
}

<!-- SOURCE_FILE_END: repo/api/config.js -->


<!-- SOURCE_FILE_START: repo/api/sample.js -->
# SOURCE FILE: `repo/api/sample.js`

// Puente entre el ejecutor y el modelo de OpenAI, para el despliegue en Vercel.
//
// Dentro de claude.ai la pagina usa la capacidad `sample` del visor y esta
// funcion nunca se llama. Servida desde Vercel no hay visor, asi que la pagina
// habla con esta ruta y la cuenta que paga es la del OPENAI_API_KEY del
// proyecto. Por eso existe APP_PASSWORD: sin ella, cualquiera con la URL gasta
// esa cuenta.
//
// Responde SSE para que la pagina pinte el texto mientras se escribe.

import OpenAI from "openai";

export const config = { maxDuration: 300 };

// El modelo se puede cambiar desde Vercel sin tocar codigo. El default es el
// que la documentacion de OpenAI marca hoy como su modelo mas capaz.
const MODELO = process.env.OPENAI_MODEL || "gpt-6-astra";
// Esfuerzo de razonamiento. xhigh es el punto donde la calidad deja de subir
// de forma util para este trabajo; max cuesta el doble de tiempo por muy poco.
const ESFUERZO = { quick: "low", default: "high", complex: "xhigh" };
const MAX_OUTPUT_TOKENS = 64000;

// El bloque de reglas es identico entre rondas y entre etapas del mismo caso, y
// pesa entre 9K y 15K tokens. Va primero para que el cache de prompt de OpenAI
// (automatico a partir de 1,024 tokens de prefijo) lo reutilice. Todo lo que
// cambia va despues: un solo byte distinto delante tiraria el cache entero.
function entrada(input, images, cachePrefix) {
  let msgs;
  if (typeof input === "string") {
    msgs = [{ role: "user", content: [] }];
  } else if (Array.isArray(input) && input.length) {
    msgs = input.map((m) =>
      m.role === "assistant"
        ? { role: "assistant", content: [{ type: "output_text", text: String(m.content ?? "") }] }
        : { role: "user", content: [{ type: "input_text", text: String(m.content ?? "") }] },
    );
  } else {
    return null;
  }
  const ultimo = msgs[msgs.length - 1];
  if (ultimo.role !== "user") return null;

  const cabeza = [];
  if (typeof cachePrefix === "string" && cachePrefix.trim()) {
    cabeza.push({ type: "input_text", text: cachePrefix });
  }
  for (const im of images || []) {
    if (!im || !im.data || !im.media_type) continue;
    cabeza.push({
      type: "input_image",
      image_url: `data:${im.media_type};base64,${im.data}`,
      detail: "high",
    });
  }
  if (typeof input === "string") {
    ultimo.content = [...cabeza, { type: "input_text", text: input }];
  } else {
    ultimo.content = [...cabeza, ...ultimo.content];
  }
  return msgs;
}

// La pagina lee `cache_read_input_tokens`; se traduce el uso de OpenAI a ese
// nombre para no tocar el cliente.
function uso(u) {
  if (!u) return undefined;
  return {
    input_tokens: u.input_tokens,
    output_tokens: u.output_tokens,
    cache_read_input_tokens: (u.input_tokens_details && u.input_tokens_details.cached_tokens) || 0,
    reasoning_tokens: (u.output_tokens_details && u.output_tokens_details.reasoning_tokens) || 0,
  };
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ code: "invalid_request", message: "Usa POST." });
    return;
  }
  const clave = process.env.APP_PASSWORD;
  if (clave && req.headers["x-app-password"] !== clave) {
    res.status(401).json({ code: "not_granted", message: "Contraseña incorrecta." });
    return;
  }
  if (!process.env.OPENAI_API_KEY) {
    res.status(500).json({
      code: "sampling_disabled",
      message: "Falta la variable OPENAI_API_KEY en el proyecto de Vercel.",
    });
    return;
  }

  const cuerpo = req.body || {};
  const msgs = entrada(cuerpo.input, cuerpo.images, cuerpo.cachePrefix);
  if (!msgs) {
    res.status(400).json({
      code: "invalid_request",
      message: "El input debe ser texto, o turnos que terminen en uno del usuario.",
    });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  const enviar = (o) => res.write("data: " + JSON.stringify(o) + "\n\n");

  const client = new OpenAI();
  const cancelar = new AbortController();
  req.on("close", () => cancelar.abort());

  try {
    const stream = await client.responses.create(
      {
        model: MODELO,
        input: msgs,
        max_output_tokens: MAX_OUTPUT_TOKENS,
        // Sin el resumen el modelo piensa en silencio y la pagina parece
        // colgada durante el minuto largo que tarda antes de la primera letra.
        reasoning: { effort: ESFUERZO[cuerpo.modelTier] || "high", summary: "auto" },
        prompt_cache_key: "ejecutor-reglas",
        stream: true,
      },
      { signal: cancelar.signal },
    );

    let final = null;
    let rechazo = "";
    for await (const ev of stream) {
      if (ev.type === "response.output_text.delta") {
        enviar({ t: "text", d: ev.delta });
      } else if (ev.type === "response.reasoning_summary_text.delta") {
        enviar({ t: "think", d: ev.delta });
      } else if (ev.type === "response.refusal.delta") {
        rechazo += ev.delta;
      } else if (ev.type === "response.completed" || ev.type === "response.incomplete") {
        final = ev.response;
      } else if (ev.type === "response.failed") {
        const m = (ev.response && ev.response.error && ev.response.error.message) || "El modelo falló.";
        throw Object.assign(new Error(m), { status: 502 });
      } else if (ev.type === "error") {
        throw Object.assign(new Error(ev.message || "Error del stream."), { status: 502 });
      }
    }

    if (rechazo) {
      enviar({ t: "error", code: "refused", message: "El modelo rechazó esta entrada. Cambia lo que pide el brief." });
    } else {
      const inc = final && final.incomplete_details && final.incomplete_details.reason;
      enviar({ t: "done", truncated: inc === "max_output_tokens", usage: uso(final && final.usage) });
    }
  } catch (e) {
    const status = e && e.status;
    const bruto = (e && e.message) || "";
    const code =
      status === 429
        ? "rate_limited"
        : status === 401 || status === 403
          ? "not_granted"
          : status === 400
            ? "invalid_request"
            : "upstream_error";
    const message = /insufficient_quota|billing|exceeded your current quota/i.test(bruto)
      ? "La cuenta de OpenAI no tiene saldo. Carga crédito en platform.openai.com, Billing."
      : /model_not_found|does not exist|not have access/i.test(bruto)
        ? `El modelo ${MODELO} no está disponible para esta cuenta. Cambia la variable OPENAI_MODEL en Vercel por uno que aparezca en platform.openai.com, Limits.`
        : /Incorrect API key|invalid_api_key/i.test(bruto)
          ? "La OPENAI_API_KEY de Vercel no es válida. Revísala y vuelve a desplegar."
          : bruto || "Error al llamar al modelo.";
    enviar({ t: "error", code, message });
  }
  res.end();
}

<!-- SOURCE_FILE_END: repo/api/sample.js -->


<!-- SOURCE_FILE_START: repo/app/build_app.py -->
# SOURCE FILE: `repo/app/build_app.py`

#!/usr/bin/env python3
"""Genera app/ejecutor.html: el ejecutor de produccion.

Flujo: brief -> plan de etapas (lo decide el modelo a partir del catalogo del
skill) -> por cada etapa, instruccion especifica + reglas del caso -> el modelo
entrega -> un auditor verifica contra criterios y reglas -> si falla, se
rechaza y se vuelve a pedir con correcciones -> el director aprueba o itera.
Modulo aparte: evaluar imagenes y videos contra el brief o la estrategia.

Las reglas salen de rules.sqlite. Si la base cambia, se regenera:

    python3 app/build_app.py --db rules.sqlite --out app/ejecutor.html
"""

from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

# Etapas 0-7, verbatim de ai-production-director/SKILL.md §3.
# 'ok' marca las que exigen OK explicito del usuario (§4).
ETAPAS = [
    {"clave": "E0", "nombre": "Brand Lock", "cond": "solo si hay marca o cliente",
     "casos": ["MARCA"], "tracks": ["STANDARD", "FILM"], "ok": True,
     "entra": "Sitio web, brand book, screenshots o descripción",
     "sale": "brand-lock.md — 9 secciones, cada valor con fuente y confianza",
     "gate": "El usuario confirma los valores flagged como estimados. Sin marca formal, "
             "usa el Visual Theme de la Etapa 3 como sustituto ligero."},
    {"clave": "E1", "nombre": "Creative Strategy", "cond": "",
     "casos": ["GUION"], "tracks": ["STANDARD", "FILM"], "ok": True,
     "entra": "Brand lock + brief",
     "sale": "Territorios explorados, 3–5 concept cards, matriz de selección y dirección "
             "narrativa del concepto ganador",
     "gate": "El usuario selecciona UN concepto. No se escribe una línea de guion con "
             "concepto abierto."},
    {"clave": "E2", "nombre": "Screenwriting", "cond": "",
     "casos": ["GUION"], "tracks": ["STANDARD", "FILM"], "ok": True,
     "entra": "Concept card ganadora + dirección narrativa",
     "sale": "Treatment (solo FILM) → script con escenas XML-tagged, sluglines, acción y diálogo",
     "gate": "Cada escena pasa la fórmula de escena (deseo + obstáculo + geometría + mirada + "
             "ritmo) y la three-jobs rule: cambia emoción, avanza acción o sube presión. "
             "La que no hace ninguna se corta aquí, no en el shot list."},
    {"clave": "E3", "nombre": "Cinematic Direction", "cond": "",
     "casos": ["CLIP", "SHOT"], "tracks": ["STANDARD", "FILM"], "ok": False,
     "entra": "Script",
     "sale": "Documento de dirección por escena: blocking, composición, cámara motivada, lente, "
             "luz, evolución de color, lenguaje de edición y los 5 anclas de la pieza",
     "gate": "Cero palabras del vocabulario prohibido. Cada decisión de cámara tiene "
             "razón dramática escrita."},
    {"clave": "E4", "nombre": "Shot Planning", "cond": "punto de entrada del track EXPRESS",
     "casos": ["SHOT"], "tracks": ["EXPRESS", "STANDARD", "FILM"], "ok": True,
     "entra": "Script + documento de dirección (EXPRESS: solo el brief)",
     "sale": "storyboard.md · shots.json · text-overlays.json — shots.json es la fuente de "
             "verdad; ningún prompt existe sin shot ID",
     "gate": "Six-point dramaturgy check + auditoría de 3 detalles por shot (presión "
             "ambiental, micro-acción física, ancla de sonido). Un shot con cero detalles "
             "es filler y se elimina."},
    {"clave": "E5", "nombre": "Anchor Images", "cond": "",
     "casos": ["T1", "T2", "T3", "T4", "T5", "PROD", "GRAF", "MULTI", "REF", "QA"],
     "tracks": ["EXPRESS", "STANDARD", "FILM"], "ok": False,
     "entra": "shots.json + brand-lock",
     "sale": "Plan de anchors (character refs, environment refs, keyframes por shot clave) "
             "y prompts finales de imagen por anchor",
     "gate": "Cada anchor crítico pasa la crítica. Máximo 2 rondas de revisión; a la tercera "
             "falla se replantea el shot, no el prompt."},
    {"clave": "E6", "nombre": "Video Prompts", "cond": "",
     "casos": ["CLIP"], "tracks": ["EXPRESS", "STANDARD", "FILM"], "ok": False,
     "entra": "shots.json + anchor aprobado",
     "sale": "Prompts de video finales por shot, con continuity blocks entre clips",
     "gate": "Dramaturgy check de 6 puntos + auditoría de 3 detalles. Un prompt que falla "
             "cualquiera NO se entrega."},
    {"clave": "E7", "nombre": "Package & Delivery", "cond": "",
     "casos": ["ENTREGA"], "tracks": ["STANDARD", "FILM"], "ok": False,
     "entra": "Todos los artefactos de las etapas anteriores",
     "sale": "Final AI Video Production Package + checklist de postproducción",
     "gate": "Checklist maestro completo y trazabilidad verificada: 3 prompts al azar trazan "
             "hasta su concepto. Si un eslabón falta, no se entrega."},
    # Etapas sueltas: briefs que no son un video completo.
    {"clave": "PROMPT_IMAGEN", "nombre": "Prompt de imagen", "cond": "brief de una sola imagen",
     "casos": ["T1", "T2", "T3", "T4", "T5", "PROD", "GRAF", "MULTI"], "tracks": [], "ok": False,
     "entra": "El brief (y referencias, si hay)",
     "sale": "Cabecera de 3 líneas SKILL:/RIESGOS:/TÉCNICA:, modelo recomendado y el prompt "
             "final en inglés en un bloque de código",
     "gate": "Cumple todas las reglas del caso elegido. Sin vocabulario prohibido."},
    {"clave": "PROMPT_VIDEO", "nombre": "Prompt de video", "cond": "brief de un solo clip",
     "casos": ["CLIP"], "tracks": [], "ok": False,
     "entra": "El brief (y referencias, si hay)",
     "sale": "Cabecera de 3 líneas, modelo recomendado y el prompt final en inglés en un "
             "bloque de código",
     "gate": "Dramaturgy check de 6 puntos + 3 detalles. Sin vocabulario prohibido."},
    {"clave": "REF", "nombre": "Referencia a prompt", "cond": "hay imagen de referencia y se "
     "pide recrearla", "casos": ["REF"], "tracks": [], "ok": False,
     "entra": "Imagen de referencia adjunta",
     "sale": "Descomposición de la referencia (sujeto, luz, lente, color, composición) y el "
             "prompt para recrearla en inglés en un bloque de código",
     "gate": "Cada elemento visible de la referencia está en el prompt; nada inventado."},
    {"clave": "ESTRATEGIA", "nombre": "Estrategia", "cond": "el brief pide una estrategia o "
     "plan, no una pieza visual", "casos": [], "tracks": [], "ok": True,
     "entra": "El brief",
     "sale": "Documento estratégico: diagnóstico, opciones, recomendación y plan de acción "
             "con siguientes pasos",
     "gate": "Responde exactamente lo que pide el brief. Cada recomendación tiene razón y "
             "siguiente paso concreto."},
    {"clave": "DOC", "nombre": "Documento", "cond": "cualquier otro entregable de texto",
     "casos": [], "tracks": [], "ok": False,
     "entra": "El brief y lo aprobado antes",
     "sale": "El documento que pide el brief",
     "gate": "Cumple cada criterio del plan."},
]

TRACKS = {
    "EXPRESS": "≤30s, un beat (hook→payoff). Entra en E4 y salta E0–E3 y E7.",
    "STANDARD": "30–90s, arco simple. E0–E7 con E1 comprimida (2–3 conceptos) y E2 sin treatment.",
    "FILM": "90s–10min, multi-escena. E0–E7 completas, todos los gates.",
}

PLANTILLA = r"""<title>Ejecutor de Producción</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Condensed:wght@500;600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap">
<style>
:root{
  --bg:#F2F4F7;--surf:#FFFFFF;--ink:#161A20;--mute:#5C6674;--line:#D6DBE3;--soft:#E9EDF2;
  --acc:#D9541E;--acc-ink:#FFFFFF;--ok:#1F8A4C;--warn:#B7791F;--bad:#C0392B;--info:#2F6FBF;
  --ok-bg:#E4F3EA;--warn-bg:#FBF1DC;--bad-bg:#F9E3E0;--info-bg:#E3ECF9;
  --disp:"IBM Plex Sans Condensed","Arial Narrow",sans-serif;
  --body:"IBM Plex Sans",system-ui,sans-serif;
  --mono:"IBM Plex Mono",ui-monospace,Menlo,monospace;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --bg:#121519;--surf:#1A1E24;--ink:#E8EAED;--mute:#9AA3AF;--line:#2B313A;--soft:#232930;
  --acc:#F0703A;--acc-ink:#15100D;--ok:#4CC37A;--warn:#E0A83C;--bad:#EF6B5E;--info:#6FA3F0;
  --ok-bg:#16301F;--warn-bg:#352A12;--bad-bg:#3A1C19;--info-bg:#16263D;}}
:root[data-theme="dark"]{
  --bg:#121519;--surf:#1A1E24;--ink:#E8EAED;--mute:#9AA3AF;--line:#2B313A;--soft:#232930;
  --acc:#F0703A;--acc-ink:#15100D;--ok:#4CC37A;--warn:#E0A83C;--bad:#EF6B5E;--info:#6FA3F0;
  --ok-bg:#16301F;--warn-bg:#352A12;--bad-bg:#3A1C19;--info-bg:#16263D;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 var(--body)}
h1,h2,h3{font-family:var(--disp);font-weight:600;letter-spacing:.01em;margin:0;text-wrap:balance}
h1{font-size:20px}h2{font-size:17px}h3{font-size:15px}
p{margin:0}
a{color:var(--info)}
button{font:inherit;cursor:pointer;border:1px solid var(--line);background:var(--surf);color:var(--ink);border-radius:6px;padding:7px 12px}
button:hover{border-color:var(--mute)}
button:focus-visible,textarea:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
button:disabled{opacity:.5;cursor:default}
button.prim{background:var(--acc);color:var(--acc-ink);border-color:var(--acc);font-weight:600}
button.sm{padding:4px 9px;font-size:12.5px}
button.link{border:0;background:none;color:var(--info);padding:0}
textarea,input[type=text],input[type=url],select{font:inherit;color:var(--ink);background:var(--surf);border:1px solid var(--line);border-radius:6px;padding:8px 10px;width:100%}
textarea{min-height:120px;resize:vertical;line-height:1.5}
input[type=file]{font:inherit;color:var(--mute)}
.lbl{font-family:var(--disp);font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--mute);font-weight:600}
.mono{font-family:var(--mono);font-size:12.5px}
.mute{color:var(--mute)}
.app{display:grid;grid-template-columns:250px 1fr;min-height:100vh}
.rail{border-right:1px solid var(--line);background:var(--surf);padding:16px 14px;display:flex;flex-direction:column;gap:14px}
.rail .brand{display:flex;align-items:baseline;gap:8px}
.rail .brand small{color:var(--mute);font-family:var(--mono);font-size:11px}
.plist{display:flex;flex-direction:column;gap:2px;overflow:auto;max-height:50vh}
.plist button{text-align:left;border:0;padding:7px 9px;border-radius:5px;display:flex;flex-direction:column;gap:2px}
.plist button.act{background:var(--soft)}
.plist button small{color:var(--mute);font-size:11.5px;font-family:var(--mono)}
.plist button b{font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:210px}
.tabs{display:flex;flex-direction:column;gap:2px}
.tabs button{text-align:left;border:0;padding:7px 9px;border-radius:5px;display:flex;justify-content:space-between;align-items:center}
.tabs button.act{background:var(--ink);color:var(--bg)}
.tabs button span.n{font-family:var(--mono);font-size:11px;opacity:.75}
.main{padding:22px 28px 60px;max-width:980px;width:100%}
.hd{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;margin-bottom:16px;flex-wrap:wrap}
.hd .sub{color:var(--mute);margin-top:2px}
.card{background:var(--surf);border:1px solid var(--line);border-radius:8px;padding:16px 18px;display:flex;flex-direction:column;gap:12px}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.stack{display:flex;flex-direction:column;gap:12px}
.pill{display:inline-flex;align-items:center;gap:6px;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:500;border:1px solid var(--line);background:var(--soft)}
.pill.ok{background:var(--ok-bg);color:var(--ok);border-color:transparent}
.pill.warn{background:var(--warn-bg);color:var(--warn);border-color:transparent}
.pill.bad{background:var(--bad-bg);color:var(--bad);border-color:transparent}
.pill.info{background:var(--info-bg);color:var(--info);border-color:transparent}
.pill.acc{background:var(--acc);color:var(--acc-ink);border-color:transparent}
.etapa{display:grid;grid-template-columns:6px 1fr;border:1px solid var(--line);border-radius:8px;background:var(--surf);overflow:hidden}
.etapa .stripe{background:var(--line)}
.etapa.gen .stripe,.etapa.aud .stripe{background:var(--info)}
.etapa.rech .stripe,.etapa.agot .stripe{background:var(--bad)}
.etapa.espera .stripe{background:var(--warn)}
.etapa.aprob .stripe{background:var(--ok)}
.etapa .body{padding:14px 18px;display:flex;flex-direction:column;gap:10px}
.etapa .top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap}
.etapa .meta{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.crit{margin:0;padding-left:18px;color:var(--mute)}
.crit li{margin:2px 0}
.out{border-top:1px solid var(--line);padding-top:10px}
.md{line-height:1.55;max-width:72ch}
.md h1,.md h2,.md h3{margin:12px 0 6px}
.md h1{font-size:17px}.md h2{font-size:15.5px}.md h3{font-size:14px}
.md p{margin:6px 0}
.md ul,.md ol{margin:6px 0;padding-left:22px}
.md pre{background:var(--soft);border:1px solid var(--line);border-radius:6px;padding:10px 12px;overflow-x:auto;font-family:var(--mono);font-size:12.5px;line-height:1.5;white-space:pre-wrap;margin:8px 0}
.md code{font-family:var(--mono);font-size:12.5px;background:var(--soft);padding:1px 4px;border-radius:3px}
.md pre code{background:none;padding:0}
.md table{border-collapse:collapse;margin:6px 0;font-size:13px}
.md th,.md td{border:1px solid var(--line);padding:4px 8px;vertical-align:top}
.log{border:1px solid var(--line);border-radius:6px;overflow:hidden;font-size:13px}
.log .r{display:grid;grid-template-columns:82px 1fr;border-top:1px solid var(--line)}
.log .r:first-child{border-top:0}
.log .r>div{padding:6px 10px}
.log .r>div:first-child{background:var(--soft);font-family:var(--mono);font-size:12px;color:var(--mute)}
.falla{padding:6px 0;border-top:1px dashed var(--line)}
.falla:first-child{border-top:0}
.falla b{font-family:var(--mono);font-weight:500;font-size:12px}
.falla .ev{color:var(--mute);font-style:italic}
.status{display:flex;align-items:center;gap:8px;color:var(--mute);font-size:13px}
.spin{width:12px;height:12px;border:2px solid var(--line);border-top-color:var(--acc);border-radius:50%;animation:sp .8s linear infinite;flex:none}
@keyframes sp{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){.spin{animation:none}}
.thumbs{display:flex;gap:8px;flex-wrap:wrap}
.thumbs img{height:72px;border-radius:4px;border:1px solid var(--line)}
.gens{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}
.gens button{padding:0;overflow:hidden;text-align:left;display:flex;flex-direction:column}
.gens img{width:100%;aspect-ratio:16/9;object-fit:cover;display:block}
.gens small{padding:4px 7px;color:var(--mute);font-family:var(--mono);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.gens button.act{outline:2px solid var(--acc)}
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;font-family:var(--disp);font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--mute);padding:6px 8px;border-bottom:1px solid var(--line)}
.tbl td{padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
.score{font-family:var(--disp);font-size:34px;font-weight:600;line-height:1;font-variant-numeric:tabular-nums}
.empty{color:var(--mute);padding:30px 0;text-align:center}
.warnbox{background:var(--warn-bg);color:var(--warn);border-radius:6px;padding:8px 12px;font-size:13px}
.badbox{background:var(--bad-bg);color:var(--bad);border-radius:6px;padding:8px 12px;font-size:13px}
.infobox{background:var(--info-bg);color:var(--info);border-radius:6px;padding:8px 12px;font-size:13px}
details>summary{cursor:pointer;color:var(--mute);font-size:13px}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:6px;overflow:hidden}
.seg button{border:0;border-radius:0;border-right:1px solid var(--line)}
.seg button:last-child{border-right:0}
.seg button.act{background:var(--ink);color:var(--bg)}
.chk{display:flex;gap:8px;align-items:center}
.plan-et{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:start;padding:10px 0;border-top:1px solid var(--line)}
.plan-et:first-child{border-top:0}
.plan-et .k{font-family:var(--mono);font-size:12px;color:var(--mute);padding-top:2px;min-width:110px}
@media (max-width:820px){.app{grid-template-columns:1fr}.rail{border-right:0;border-bottom:1px solid var(--line)}.grid2{grid-template-columns:1fr}.main{padding:16px}}
</style>

<div class="app">
  <aside class="rail">
    <div class="brand"><h1>Ejecutor</h1><small id="ver"></small></div>
    <button class="prim" id="btnNuevo">Nuevo brief</button>
    <div class="lbl">Proyectos</div>
    <div class="plist" id="plist"></div>
    <div class="lbl">Módulos</div>
    <nav class="tabs" id="tabs">
      <button data-v="brief">Brief</button>
      <button data-v="plan">Plan <span class="n" id="nPlan"></span></button>
      <button data-v="run">Ejecución <span class="n" id="nRun"></span></button>
      <button data-v="eval">Evaluador</button>
      <button data-v="ajustes">Ajustes</button>
    </nav>
    <div class="mute" style="font-size:12px;margin-top:auto" id="capline">Conectando…</div>
  </aside>
  <main class="main" id="main"></main>
</div>

<script>
const D = __DATOS__;
const ETAPAS = D.etapas, CAT = Object.fromEntries(ETAPAS.map(e=>[e.clave,e]));
const $ = (s,r=document)=>r.querySelector(s);
const esc = s => String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const bytes = s => new TextEncoder().encode(s).length;
const uid = () => Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const nowIso = () => new Date().toISOString();
const MAX_BYTES = 62000;

// ------------------------------------------------------------ estado
let sample=null, db=null, mcp=null, caps={images:false};
let S = {proyectos:[], pid:null, view:'brief', imgs:[], busy:false, error:'', bloqueo:false, ajustes:{rondas:3, tierGen:'complex', tierAud:'default', rondasEval:1}};
// Nada de alert/confirm/prompt: dentro del visor de artifacts esos dialogos
// pueden estar bloqueados, y entonces el error no se ve por ningun lado.
function fallo(msg){ S.error=msg; render(); }
const P = () => S.proyectos.find(p=>p.id===S.pid);
const ajustesLS = 'ejecutor.ajustes';
try{ Object.assign(S.ajustes, JSON.parse(localStorage.getItem(ajustesLS)||'{}')); }catch(e){}

// ------------------------------------------------------------ persistencia
async function guardar(p){
  p.actualizado = nowIso();
  if(db){ try{ await db.doc('proyectos/'+p.id).set(p); return; }catch(e){ console.warn('db set',e); } }
  try{ localStorage.setItem('ejecutor.p.'+p.id, JSON.stringify(p)); }catch(e){}
}
async function cargarLista(){
  let lista=[];
  if(db){
    try{ const q = await db.collection('proyectos').orderBy('creado','desc').limit(100).get(); lista = q.docs.map(d=>d.data()); }
    catch(e){ console.warn('db list',e); }
  }
  if(!lista.length){
    for(let i=0;i<localStorage.length;i++){ const k=localStorage.key(i); if(k&&k.startsWith('ejecutor.p.')){ try{ lista.push(JSON.parse(localStorage.getItem(k))); }catch(e){} } }
    lista.sort((a,b)=>(b.creado||'').localeCompare(a.creado||''));
  }
  S.proyectos = lista;
}
function nuevoProyecto(){
  const p = {id:uid(), nombre:'Sin título', brief:'', creado:nowIso(), plan:null, etapas:{}, orden:[], evaluaciones:[]};
  S.proyectos.unshift(p); S.pid=p.id; S.imgs=[]; S.view='brief'; render();
}

// ------------------------------------------------------------ reglas
function reglasDe(casos){
  const ids = new Set();
  for(const c of casos||[]) for(const id of (D.porCaso[c]||[])) ids.add(id);
  const pri = {auditoria:0, regla:1, archivo:2};
  return [...ids].map(id=>({id, ...D.idx[id]})).sort((a,b)=>(pri[a.o]-pri[b.o])||a.s.localeCompare(b.s)||a.a.localeCompare(b.a)||a.l-b.l);
}
const lineaRegla = r => `- [${r.id}] (${r.s}) ${r.t}`;
function empacarReglas(reglas, presupuesto){
  const out=[]; let usado=0, n=0;
  for(const r of reglas){ const l=lineaRegla(r)+'\n'; const b=bytes(l); if(usado+b>presupuesto) break; out.push(l); usado+=b; n++; }
  return {texto:out.join(''), incluidas:n, total:reglas.length};
}
function tandasReglas(reglas, presupuesto){
  const tandas=[]; let cur=[], usado=0;
  for(const r of reglas){ const l=lineaRegla(r)+'\n'; const b=bytes(l); if(usado+b>presupuesto && cur.length){ tandas.push(cur.join('')); cur=[]; usado=0; } cur.push(l); usado+=b; }
  if(cur.length) tandas.push(cur.join(''));
  return tandas;
}
const corta = (s,n) => (s||'').length>n ? s.slice(0,n)+`\n[… recortado a ${n} caracteres]` : (s||'');

// ------------------------------------------------------------ prompts
function catalogoTexto(){
  return ETAPAS.map(e=>`- ${e.clave} · ${e.nombre}${e.cond?' — cuándo: '+e.cond:''}\n    entra: ${e.entra}\n    sale: ${e.sale}\n    gate: ${e.gate}\n    casos de reglas permitidos: ${e.casos.length?e.casos.join(', '):'ninguno (sin reglas de skill)'}${e.tracks.length?'\n    tracks: '+e.tracks.join(', '):''}${e.ok?'\n    requiere OK explícito del director antes de continuar':''}`).join('\n');
}
function casosTexto(){ return Object.entries(D.casos).filter(([k])=>k!=='NINGUNO').map(([k,v])=>`  ${k}: ${v} (${(D.porCaso[k]||[]).length} reglas)`).join('\n'); }

function promptPlan(p){
  return `Eres el director de producción de Final Upgrade AI. Recibes un BRIEF y decides qué etapas de trabajo hacen falta para entregarlo. No ejecutes ninguna etapa: solo planifica.

CATÁLOGO DE ETAPAS (usa solo estas claves, en el orden en que deben ejecutarse):
${catalogoTexto()}

TRACKS DE VIDEO:
${Object.entries(D.tracks).map(([k,v])=>`  ${k}: ${v}`).join('\n')}

CASOS DE PRODUCCIÓN (cada etapa toma las reglas de sus casos):
${casosTexto()}

REGLAS DE PLANIFICACIÓN:
- Un brief de una sola imagen → una sola etapa PROMPT_IMAGEN con el caso exacto (T1 rostro, T2 cuerpo, T3 escena con 1 persona, T4 con 2 personas, T5 edición, PROD producto sin persona, GRAF pieza gráfica, MULTI grid).
- Un brief que pide el prompt para recrear una imagen adjunta → REF (hay ${S.imgs.length} imagen(es) adjunta(s)).
- Un brief de un solo clip de video → PROMPT_VIDEO.
- Un brief de video completo (spot, campaña, reel con narrativa, brand film) → etapas E0–E7 según el track. E0 solo si hay marca o cliente. E5 lleva solo los casos de imagen que el proyecto necesita.
- Un brief que pide estrategia o plan de algo que no es una pieza visual → ESTRATEGIA, y DOC por cada entregable adicional que pida.
- Cada etapa lleva: objetivo específico para ESTE brief (no genérico), el entregable exacto, y de 3 a 6 criterios de aceptación verificables, escritos para que un auditor pueda marcarlos cumplido / no cumplido con evidencia textual.
- "formato" es el formato de entrega de la pieza y manda sobre todos los prompts. Dedúcelo del brief: 9:16 para TikTok, Reels y Shorts; 16:9 para YouTube y spot apaisado; 1:1 para post de feed; 4:5 para feed vertical de Instagram. Si el brief no lo dice, elige el que corresponde al medio que menciona y anótalo en "supuestos". "duracion" solo para video.
- "usaImagenes": true solo en etapas que necesitan ver las imágenes adjuntas.
- Si el brief es ambiguo, no preguntes: decide y anota el supuesto en "supuestos".
- Responde en español.

BRIEF:
<<<
${corta(p.brief, 30000)}
>>>

Responde SOLO con JSON con esta forma exacta:
{"nombre":"título corto del proyecto","tipo":"qué se va a producir","track":"EXPRESS|STANDARD|FILM|null","resumen":"2 líneas","formato":{"aspect":"9:16","resolucion":"1080x1920","duracion":"30s o null"},"supuestos":["..."],"etapas":[{"clave":"E5","nombre":"nombre para este proyecto","objetivo":"...","entregable":"...","casos":["T3"],"criterios":["..."],"usaImagenes":false}]}`;
}

const PARAMS = `
PARÁMETROS DE GENERACIÓN — obligatorios junto a CADA prompt de imagen o video.
Un prompt sin aspect ratio está incompleto y se rechaza. Debajo de cada bloque
de código va una línea rotulada "Parámetros de generación:" con modelo, aspect
ratio, resolución o tamaño en píxeles, y duración si es video.
Dónde se escribe cada parámetro depende del modelo, y equivocarse es un error:
- Midjourney los lee DENTRO del prompt, como \`--ar 9:16\`.
- Nano Banana ignora \`--ar\` dentro del prompt: espera el parámetro \`aspectRatio\`.
- Seedream ignora \`--ar\`: aspect_ratio va como parámetro.
- GPT Image ignora \`--ar\` y las banderas de peso: el tamaño va como parámetro
  (1024x1024, 1536x1024 apaisado, 1024x1536 vertical).
- Seedance 2.5: duración, aspect ratio y resolución se fijan en la página de
  generación o por API y NO van en el texto del prompt.
Cuando el parámetro no va dentro del prompt, se entrega igual en esa línea
aparte, diciendo que se fija en la página de generación.`;

function fmtTexto(p){
  const f = (p.plan&&p.plan.formato)||null;
  if(!f || !f.aspect) return 'sin definir — dedúcelo del brief y dilo explícitamente';
  return [f.aspect, f.resolucion, f.duracion].filter(Boolean).join(' · ');
}

function contextoAprobado(p, hastaKey, limite){
  const partes=[]; let usado=0;
  for(const k of p.orden){ if(k===hastaKey) break; const e=p.etapas[k]; if(!e||!e.output||!['aprobada','espera_ok'].includes(e.estado)) continue;
    const t = `## ${e.nombre} (${e.clave})\n${e.output}\n`; partes.push(t); usado+=t.length; }
  let s = partes.join('\n');
  if(s.length>limite){ s = s.slice(s.length-limite); s = '[… contexto anterior recortado]\n'+s; }
  return s;
}

function promptEtapa(p, e, correcciones, feedback){
  const cat = CAT[e.clave]||{};
  const fijo = `Eres el ejecutor de la etapa "${e.nombre}" (${e.clave}: ${cat.nombre||''}) de un pipeline de producción visual con IA. Tu objetivo es maximizar la calidad del entregable, nunca ahorrar esfuerzo. Este entregable será auditado contra cada criterio y cada regla listada abajo; lo que no cumpla se rechaza y se vuelve a pedir.

BRIEF DEL PROYECTO:
<<<
${corta(p.brief, 20000)}
>>>

OBJETIVO DE ESTA ETAPA: ${e.objetivo}
ENTREGABLE EXACTO: ${e.entregable}
FORMATO DE ENTREGA DEL PROYECTO: ${fmtTexto(p)}
QUÉ SALE SEGÚN EL SKILL: ${cat.sale||''}
GATE DE LA ETAPA: ${cat.gate||''}
CRITERIOS DE ACEPTACIÓN:
${(e.criterios||[]).map((c,i)=>`${i+1}. ${c}`).join('\n')}
${feedback?`\nINSTRUCCIONES DEL DIRECTOR PARA ESTA ITERACIÓN (obligatorias):\n${feedback}\n`:''}${correcciones&&correcciones.length?`\nCORRECCIONES OBLIGATORIAS — el auditor rechazó la versión anterior por esto; cada punto debe quedar resuelto:\n${correcciones.map(f=>`- [${f.ref}] ${f.correccion}${f.evidencia?' (evidencia: '+f.evidencia+')':''}`).join('\n')}\n`:''}
FORMATO DE SALIDA: Markdown en español. Los prompts finales para modelos de imagen o video van en inglés, cada uno dentro de un bloque de código, precedido de su cabecera de 3 líneas SKILL: / RIESGOS: / TÉCNICA: y del modelo recomendado. Sin disculpas, sin preámbulos, sin resumen final: solo el entregable completo.
${PARAMS}
`;
  const ctx = contextoAprobado(p, e.key, 14000);
  const ctxTxt = ctx ? `\nCONTEXTO APROBADO DE ETAPAS ANTERIORES (es la fuente de verdad; no lo contradigas):\n${ctx}\n` : '';
  const reglas = reglasDe(e.casos);
  const cabecera = `REGLAS OBLIGATORIAS DE LOS SKILLS (casos ${(e.casos||[]).join(', ')||'ninguno'}):\n`;
  const presupuesto = MAX_BYTES - bytes(fijo) - bytes(ctxTxt) - bytes(cabecera) - 800;
  const pack = empacarReglas(reglas, Math.max(presupuesto, 0));
  const nota = pack.incluidas<pack.total ? `(caben ${pack.incluidas} de ${pack.total}; el resto se verifica en la auditoría)\n` : '';
  return {prefijo: reglas.length ? cabecera+nota+pack.texto : '', texto: fijo + ctxTxt,
          incluidas:pack.incluidas, total:pack.total};
}

function promptAuditoria(p, e, output, tanda, i, n){
  const prefijo = tanda ? `REGLAS A VERIFICAR (tanda ${i} de ${n}):\n${tanda}` : '';
  const texto = `Eres el auditor de calidad de la etapa "${e.nombre}" (${e.clave}). Tu única tarea es verificar si el ENTREGABLE cumple los CRITERIOS y las REGLAS. No lo reescribas ni lo mejores. Está prohibido aprobar para complacer: si una regla aplicable a este entregable no se cumple, es una falla. Una regla que no aplica a este tipo de entregable no es falla. Cada falla lleva la referencia (id de regla o número de criterio), evidencia textual (cita del entregable, o "ausente" si falta algo obligatorio) y una corrección concreta que el ejecutor pueda aplicar sin adivinar.

BRIEF (resumen): ${corta(p.brief, 3000)}
OBJETIVO DE LA ETAPA: ${e.objetivo}
ENTREGABLE ESPERADO: ${e.entregable}
GATE: ${(CAT[e.clave]||{}).gate||''}
CRITERIOS:
${(e.criterios||[]).map((c,k)=>`${k+1}. ${c}`).join('\n')}

CHEQUEO OBLIGATORIO, ADEMÁS DE LOS CRITERIOS: si el entregable contiene uno o más
prompts de imagen o video, cada uno debe traer su línea de "Parámetros de
generación" con modelo, aspect ratio, resolución o tamaño, y duración si es
video, coherentes con el formato de entrega del proyecto (${fmtTexto(p)}).
Un prompt sin aspect ratio es una falla con ref "FORMATO". Además es falla usar
\`--ar\` con Nano Banana, Seedream o GPT Image, que lo ignoran, o meter duración,
aspect ratio o resolución dentro del texto del prompt en Seedance 2.5, donde se
fijan en la página de generación.

${tanda?'Las reglas a verificar están listadas arriba.':'(esta etapa no tiene reglas de skill; audita solo los criterios)'}

ENTREGABLE A AUDITAR:
<<<
${corta(output, 24000)}
>>>

Responde SOLO con JSON: {"veredicto":"APRUEBA"|"RECHAZA","fallas":[{"ref":"id de regla o C1..C6","evidencia":"...","correccion":"..."}],"nota":"una línea"}`;
  return {prefijo, texto};
}

// Dentro del visor de artifacts no hay cache de prefijo: ahi el bloque de
// reglas se concatena, que es lo que ya se hacia. Con servidor propio va
// aparte y marcado, y la API lo lee de cache.
function conPrefijo(pr, o){
  return SRV ? [pr.texto, Object.assign({}, o||{}, {cachePrefix:pr.prefijo})]
             : [(pr.prefijo? pr.prefijo+'\n\n':'') + pr.texto, o];
}

function promptEvalImagen(p, refTexto, nImgs){
  return `Eres el evaluador de assets de Final Upgrade AI. Se adjuntan ${nImgs} imagen(es) generadas con IA. Evalúa si cumplen con el BRIEF y con lo APROBADO. Sé específico y visual: describe lo que ves antes de juzgar. Prohibido aprobar para complacer.

BRIEF:
<<<
${corta(p.brief, 12000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
RÚBRICA: fidelidad al brief · identidad y consistencia de personajes/marca · composición y lente · luz y color · legibilidad de texto si lo hay · artefactos de IA (manos, ojos, texto roto, geometría imposible, superficies plásticas) · lo que un cliente notaría primero.

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"descripcion":"qué se ve, 2-3 líneas","criterios":[{"criterio":"...","cumple":true|false,"evidencia":"..."}],"correcciones":["instrucción concreta para el siguiente intento"],"prompt_ajustado":"si aplica, el cambio de prompt sugerido en inglés"}`;
}

function promptEvalVideo(p, refTexto, escenas){
  const esc = escenas.map(s=>`Escena ${s.scene_number} [${s.timestamp_start}–${s.timestamp_end}] ${s.label||''} · ${s.shot_type||''}\n  visual: ${s.visual}\n  audio: ${s.audio||'—'}`).join('\n');
  return `Eres el evaluador de video de Final Upgrade AI. Un analizador externo describió el video escena por escena (abajo). Con esa descripción, evalúa si el video cumple con el BRIEF y con lo APROBADO. Prohibido aprobar para complacer. Si la descripción no permite verificar un criterio, dilo como "no verificable" en vez de suponer.

BRIEF:
<<<
${corta(p.brief, 10000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
ANÁLISIS ESCENA POR ESCENA:
${corta(esc, 20000)}

RÚBRICA: fidelidad al brief y a los shots aprobados · continuidad de personajes, vestuario y entorno entre escenas · cámara y ritmo · dramaturgia (¿hay cambio de emoción, avance o presión?) · texto en pantalla y audio · artefactos de IA (morphing, manos, física imposible).

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"criterios":[{"criterio":"...","cumple":true|false|null,"evidencia":"..."}],"por_escena":[{"escena":1,"nota":"..."}],"correcciones":["..."]}`;
}

function promptEvalCuadros(p, refTexto, tiempos){
  return `Eres el evaluador de video de Final Upgrade AI. Se adjuntan ${tiempos.length} cuadros extraídos del mismo video, en orden, en estos segundos: ${tiempos.map(t=>t.toFixed(1)+'s').join(', ')}. Son muestras, no el video completo: no puedes juzgar movimiento continuo ni audio, y lo que no puedas verificar con los cuadros dilo como "no verificable" en vez de suponerlo.

BRIEF:
<<<
${corta(p.brief, 10000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
RÚBRICA: fidelidad al brief y a los shots aprobados · continuidad de personaje, vestuario y entorno entre cuadros · encuadre y composición · luz y color · texto en pantalla · artefactos de IA (manos, ojos, texto roto, morphing entre cuadros).

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"descripcion":"qué se ve, 2-3 líneas","criterios":[{"criterio":"...","cumple":true|false|null,"evidencia":"..."}],"por_escena":[{"escena":"0.0s","nota":"..."}],"correcciones":["..."]}`;
}

function referenciaAprobada(p){
  const partes=[];
  for(const k of p.orden){ const e=p.etapas[k]; if(e&&e.output&&e.estado==='aprobada') partes.push(`## ${e.nombre}\n${e.output}`); }
  return corta(partes.join('\n\n'), 18000);
}

// ------------------------------------------------------------ servidor propio (Vercel)
// Dentro de claude.ai la pagina usa las capacidades del visor. Servida desde
// un dominio propio no hay visor: se habla con /api/sample, que corre en el
// servidor con la API key del proyecto.
let SRV=null;
const claveLS='ejecutor.clave';
async function detectarServidor(){
  if(!/^https?:$/.test(location.protocol)) return null;
  try{ const r=await fetch('/api/config',{cache:'no-store',headers:cabeceras()}); if(!r.ok) return null; const j=await r.json(); return j&&j.servidor?j:null; }catch(e){ return null; }
}
function claveGuardada(){ try{ return localStorage.getItem(claveLS)||''; }catch(e){ return ''; } }
function cabeceras(){ const h={'Content-Type':'application/json'}; const k=claveGuardada(); if(k) h['x-app-password']=k; return h; }
async function probarClave(k){
  try{ const r=await fetch('/api/config',{cache:'no-store',headers:{'x-app-password':k}}); if(!r.ok) return null; return await r.json(); }catch(e){ return null; }
}
// El cuerpo de una peticion a Vercel no puede pasar de 4.5 MB — medido: hasta
// 4.0 MB pasa, 4.4 MB devuelve FUNCTION_PAYLOAD_TOO_LARGE. Base64 infla un
// tercio. Asi que las imagenes se reducen aqui hasta que el total quepa, y si
// no cabe no se manda: rebotar con 413 no le sirve a nadie.
const PRESUPUESTO = 3200000;                                   // base64, total
const PASOS = [[1568, 0.85], [1100, 0.8], [800, 0.72], [560, 0.6]];

async function aBitmap(blob){
  try{ return await createImageBitmap(blob, {imageOrientation:'from-image'}); }
  catch(e){ try{ return await createImageBitmap(blob); }catch(e2){ return null; } }
}
function b64de(buf){
  let bin=''; const b=new Uint8Array(buf);
  for(let i=0;i<b.length;i+=0x8000) bin+=String.fromCharCode.apply(null,b.subarray(i,i+0x8000));
  return btoa(bin);
}
async function codificar(bmp, lado, calidad){
  const k=Math.min(1, lado/Math.max(bmp.width,bmp.height));
  const w=Math.max(1,Math.round(bmp.width*k)), h=Math.max(1,Math.round(bmp.height*k));
  const c=document.createElement('canvas'); c.width=w; c.height=h;
  c.getContext('2d').drawImage(bmp,0,0,w,h);
  return await new Promise(r=>c.toBlob(r,'image/jpeg',calidad));
}
// Devuelve { imagenes, avisos }. Nunca devuelve algo que no quepa.
async function prepararImagenes(archivos){
  const avisos=[], bmps=[];
  for(const f of archivos||[]){
    const bm = await aBitmap(f);
    if(!bm){ avisos.push(`"${f.name}": el navegador no puede leer este formato. Si es HEIC (el de iPhone y Mac por defecto), ábrela y expórtala como JPG.`); continue; }
    bmps.push({bm, nombre:f.name});
  }
  if(!bmps.length) return {imagenes:[], avisos};
  let blobs=null;
  for(const [lado,cal] of PASOS){
    blobs = [];
    for(const x of bmps) blobs.push(await codificar(x.bm, lado, cal));
    if(blobs.reduce((t,b)=>t+b.size,0)*4/3 <= PRESUPUESTO) break;
  }
  // Ni en el paso mas chico caben todas: se mandan las que quepan y se avisa.
  const usados=[]; let total=0;
  for(let i=0;i<blobs.length;i++){
    const peso = blobs[i].size*4/3;
    if(total+peso > PRESUPUESTO){
      avisos.push(`"${bmps[i].nombre}" no se envió: entre todas superan el límite de 4.5 MB del servidor. Manda menos imágenes por vez.`);
      continue;
    }
    total+=peso; usados.push(blobs[i]);
  }
  const imagenes=[];
  for(const b of usados) imagenes.push({media_type:'image/jpeg', data:b64de(await b.arrayBuffer())});
  for(const x of bmps) if(x.bm.close) x.bm.close();
  return {imagenes, avisos};
}

function parseJSONsuelto(txt){
  const t=(txt||'').trim();
  try{ return JSON.parse(t); }catch(e){}
  const f=/```(?:json)?\s*([\s\S]*?)```/.exec(t); if(f){ try{ return JSON.parse(f[1]); }catch(e){} }
  const i=Math.min(...[t.indexOf('{'),t.indexOf('[')].filter(x=>x>=0)), j=Math.max(t.lastIndexOf('}'),t.lastIndexOf(']'));
  if(isFinite(i)&&j>i){ try{ return JSON.parse(t.slice(i,j+1)); }catch(e){} }
  throw {code:'invalid_json', message:'La respuesta no traía JSON.', text:txt};
}
function sampleDeServidor(){
  const f = async (input, o={}) => {
    const cuerpo = {input, modelTier:o.modelTier||'default'};
    if(o.cachePrefix) cuerpo.cachePrefix=o.cachePrefix;
    if(o.images && o.images.length){
      const prep = await prepararImagenes([...o.images]);
      if(prep.imagenes.length) cuerpo.images = prep.imagenes;
      if(prep.avisos.length){
        if(!prep.imagenes.length) throw {code:'image_rejected', message:prep.avisos.join(' ')};
        S.error = prep.avisos.join(' ');
      }
    }
    const crudo = JSON.stringify(cuerpo);
    if(crudo.length > 4000000) throw {code:'prompt_too_large', message:'La petición pesa '+(crudo.length/1048576).toFixed(1)+' MB y el servidor acepta 4.5 MB. Quita alguna imagen o acorta el brief.'};
    let r;
    try{ r = await fetch('/api/sample',{method:'POST',headers:cabeceras(),body:crudo,signal:o.signal}); }
    catch(e){ throw (o.signal&&o.signal.aborted) ? {code:'cancelled',message:'Detenido.'} : {code:'upstream_error', message:'No se pudo llegar al servidor.'}; }
    if(r.status===401){ S.bloqueo=true; render(); throw {code:'not_granted', message:'La contraseña de la app cambió. Vuelve a escribirla.'}; }
    if(r.status===413) throw {code:'prompt_too_large', message:'Las imágenes pesan demasiado para el servidor. Recarga la página y vuelve a adjuntarlas: la versión nueva las reduce automáticamente.'};
    if(!r.ok){ let j={}; try{ j=await r.json(); }catch(e){} throw {code:j.code||'upstream_error', message:j.message||('El servidor respondió '+r.status)}; }
    const rd=r.body.getReader(), dec=new TextDecoder(); let buf='', texto='', pensando='', trunc=false, err=null;
    for(;;){
      let chunk; try{ chunk=await rd.read(); }catch(e){ throw {code:'cancelled', message:'Detenido.', text:texto}; }
      if(chunk.done) break;
      buf+=dec.decode(chunk.value,{stream:true});
      let k;
      while((k=buf.indexOf('\n\n'))>=0){
        const linea=buf.slice(0,k).replace(/^data:\s?/,''); buf=buf.slice(k+2);
        if(!linea) continue;
        let ev; try{ ev=JSON.parse(linea); }catch(e){ continue; }
        if(ev.t==='text'){ texto+=ev.d; if(o.onText) o.onText({text:texto, delta:ev.d}); }
        else if(ev.t==='think'){ pensando+=ev.d; if(o.onThink) o.onThink({text:pensando}); }
        else if(ev.t==='done'){ trunc=!!ev.truncated; if(ev.usage&&o.onUso) o.onUso(ev.usage); }
        else if(ev.t==='error'){ err={code:ev.code, message:ev.message, text:texto||undefined}; }
      }
    }
    if(err) throw err;
    if(!texto.trim()) throw {code:'empty_completion', message:'El modelo no escribió nada.'};
    return {text:texto, truncated:trunc};
  };
  f.json = async (input,o) => parseJSONsuelto((await f(input,o)).text);
  f.limits = async () => ({maxPromptBytes:65536, images:{maxCount:8, maxInputBytes:20000000, mediaTypes:['image/jpeg','image/png','image/webp','image/gif']}});
  return f;
}

function motivoSinClaude(){
  if(SRV && !SRV.ia) return 'El servidor no tiene OPENAI_API_KEY configurada. Ponla en las variables de entorno del proyecto de Vercel y vuelve a desplegar.';
  if(SRV) return 'El servidor no respondió. Recarga la página.';
  if(window.claude && window.claude.use) return 'Esta página no tiene permiso para usar Claude. Vuelve a abrir el artifact desde el enlace original; si sigue igual, hay que volver a publicarlo declarando la capacidad sample.';
  return 'Esta copia de la página no está conectada a Claude. Ábrela desde el artifact en claude.ai o desde el dominio donde está desplegada.';
}

// ------------------------------------------------------------ llamadas
function errMsg(e){
  const m = {not_granted:'No autorizaste el uso del modelo en esta página.', rate_limited:'Límite de uso alcanzado. Espera un momento y vuelve a intentar.', prompt_too_large:'El brief o el contexto es demasiado grande para una llamada.', invalid_json:'La respuesta no vino en el formato esperado. Vuelve a intentar.', refused:'El modelo rechazó esta entrada. Cambia el brief.', cancelled:'Detenido.', images_unavailable:'Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en https://ai-production-director.vercel.app', image_rejected:'Imagen rechazada: tipo o tamaño no válido.', sampling_disabled:'El modelo no está disponible en esta cuenta.'};
  // Cuando el mensaje lo escribio esta pagina (nombra el archivo, el peso, el
  // formato), gana sobre el texto generico del codigo.
  if(e && e.message && ['image_rejected','prompt_too_large','upstream_error','not_granted'].includes(e.code) && e.message.length>40) return e.message;
  return m[e&&e.code] || ((e&&e.message)||'Error inesperado.');
}
let ctl=null; const VOZ={rec:null};
// Una llamada con esfuerzo alto tarda minutos y pasa el primer tramo pensando
// en silencio. Sin un contador corriendo, eso se lee como una app trabada.
let RELOJ=null, T0=0;
function relojOn(){ T0=Date.now(); clearInterval(RELOJ); RELOJ=setInterval(()=>{
  const t=Math.round((Date.now()-T0)/1000);
  const txt = t<60 ? t+'s' : Math.floor(t/60)+'m '+String(t%60).padStart(2,'0')+'s';
  document.querySelectorAll('.reloj').forEach(el=>el.textContent=txt);
},1000); }
function relojOff(){ clearInterval(RELOJ); RELOJ=null; }
function opts(tier, extra){ ctl = new AbortController(); return Object.assign({modelTier:tier, cache:false, signal:ctl.signal}, extra||{}); }

async function planificar(){
  const p=P(); if(!p) return;
  if(!p.brief.trim()) return fallo('Escribe el brief primero.');
  if(!sample) return fallo(motivoSinClaude());
  S.error=''; S.busy='Leyendo el brief…'; render();
  try{
    relojOn();
    const paso = m => { S.busy=m; const el=$('#busyN'); if(el) el.textContent=m; };
    const o = opts(S.ajustes.tierGen, {
      onThink:({text})=>paso('Pensando el plan… '+text.length+' caracteres'),
      onText:({text})=>paso('Escribiendo el plan… '+text.length+' caracteres'),
    });
    if(S.imgs.length) o.images = S.imgs.slice(0, (caps.images&&caps.images.maxCount)||S.imgs.length);
    const plan = await sample.json(promptPlan(p), o);
    if(!plan||!Array.isArray(plan.etapas)||!plan.etapas.length) throw {code:'invalid_json', message:'sin etapas'};
    p.plan = plan; if(plan.nombre) p.nombre = plan.nombre;
    p.orden=[]; p.etapas={};
    plan.etapas.forEach((e,i)=>{ const key=`${e.clave}_${i}`; const cat=CAT[e.clave]||{}; const casos=(e.casos||[]).filter(c=>(cat.casos||[]).includes(c)); p.orden.push(key);
      p.etapas[key]={key, clave:e.clave, nombre:e.nombre||cat.nombre||e.clave, objetivo:e.objetivo||'', entregable:e.entregable||cat.sale||'', casos: casos.length?casos:(cat.casos||[]).slice(0, cat.clave==='E5'?0:99), criterios:e.criterios||[], usaImagenes:!!e.usaImagenes, ok:!!cat.ok, estado:'pendiente', output:'', rondas:[], feedback:''}; });
    S.view='plan'; await guardar(p);
  }catch(e){ S.error=errMsg(e); }
  relojOff(); S.busy=false; render();
}

async function ejecutarEtapa(key){
  const p=P(); const e=p.etapas[key]; if(!e||!sample) return;
  const max = Number(S.ajustes.rondas)||3;
  let correcciones = e.rondas.length && e.estado==='agotada' ? (e.rondas[e.rondas.length-1].fallas||[]) : [];
  let ronda = e.estado==='agotada' ? e.rondas.length : 0;
  if(e.estado!=='agotada'){ e.rondas=[]; }
  const feedback = e.feedback||'';
  const limite = ronda+max;
  while(ronda<limite){
    ronda++;
    e.estado='generando'; e.progreso=`ronda ${ronda} · generando`; e.parcial=''; relojOn(); render(); await guardar(p);
    const tRonda = Date.now();
    const pr = promptEtapa(p, e, correcciones, feedback);
    e.reglasIncluidas=pr.incluidas; e.reglasTotal=pr.total;
    let out, uso=null;
    try{
      const pinta = t => { e.parcial=t; const el=$(`#parcial-${key}`); if(el) el.textContent=t; };
      const o = opts(S.ajustes.tierGen, {
        onThink:({text})=>{ e.progreso=`ronda ${ronda} · pensando`; pinta(text); },
        onText:({text})=>{ e.progreso=`ronda ${ronda} · escribiendo`; pinta(text); },
        onUso:u=>{ uso=u; },
      });
      if(e.usaImagenes && S.imgs.length) o.images = S.imgs.slice(0, (caps.images&&caps.images.maxCount)||S.imgs.length);
      const r = await sample(...conPrefijo(pr, o)); out = r.text; if(r.truncated) out += '\n\n[SALIDA TRUNCADA por el límite del modelo]';
    }catch(err){ relojOff(); e.estado = e.output?'rechazada':'pendiente'; e.error=errMsg(err); e.parcial=''; render(); await guardar(p); return; }
    e.parcial='';
    // auditoría en tandas: cubre el 100% de las reglas del caso
    e.estado='auditando'; render();
    const reglas = reglasDe(e.casos);
    const tandas = reglas.length ? tandasReglas(reglas, 22000) : [''];
    let fallas=[], veredicto='APRUEBA', notas=[];
    // Las tandas son independientes: en serie multiplican la espera por nada.
    e.progreso=`ronda ${ronda} · auditando ${tandas.length} tanda(s) de reglas`; render();
    const ctlAud=new AbortController(); ctl=ctlAud;
    const res = await Promise.all(tandas.map((t,i)=>
      sample.json(...conPrefijo(promptAuditoria(p, e, out, t, i+1, tandas.length),
                  {modelTier:S.ajustes.tierAud, cache:false, signal:ctlAud.signal}))
        .then(a=>({a})).catch(err=>({err, i}))));
    for(const r of res){
      if(r.err){ notas.push('auditoría '+(r.i+1)+' falló: '+errMsg(r.err)); continue; }
      const a=r.a;
      if(a && a.veredicto==='RECHAZA') veredicto='RECHAZA';
      if(a && Array.isArray(a.fallas)) fallas.push(...a.fallas.filter(f=>f&&(f.correccion||f.ref)));
      if(a && a.nota) notas.push(a.nota);
    }
    if(veredicto==='APRUEBA' && fallas.length) veredicto='RECHAZA';
    e.rondas.push({n:ronda, veredicto, fallas, notas, fecha:nowIso(), palabras:out.split(/\s+/).length,
                   cache: (uso&&uso.cache_read_input_tokens)||0,
                   seg: Math.round((Date.now()-tRonda)/1000)});
    e.output = out;
    if(veredicto==='APRUEBA'){ relojOff(); e.estado = e.ok?'espera_ok':'aprobada'; e.progreso=''; e.feedback=''; render(); await guardar(p); if(!e.ok) continuar(); return; }
    correcciones = fallas; e.estado='rechazada'; render(); await guardar(p);
  }
  relojOff(); e.estado='agotada'; e.progreso=''; render(); await guardar(p);
}

function siguientePendiente(p){
  for(const k of p.orden){ const e=p.etapas[k]; if(e.estado==='pendiente') return k; if(!['aprobada'].includes(e.estado)) return null; }
  return null;
}
async function continuar(){ const p=P(); if(!p) return; const k=siguientePendiente(p); if(k) await ejecutarEtapa(k); else render(); }
async function iniciar(){ const p=P(); if(!p||!p.orden.length) return; S.view='run'; render(); await continuar(); }
async function aprobar(key){ const p=P(); p.etapas[key].estado='aprobada'; render(); await guardar(p); await continuar(); }
async function iterar(key){
  const p=P(); const e=p.etapas[key]; const fb=($(`#fb-${key}`)||{}).value||'';
  if(!fb.trim()) return fallo('Escribe qué quieres cambiar en esa etapa.');
  const idx=p.orden.indexOf(key); const abajo=p.orden.slice(idx+1).filter(k=>p.etapas[k].estado!=='pendiente');
  if(abajo.length && !e.confirmado){ e.confirmado=true; return fallo(`Iterar "${e.nombre}" reinicia ${abajo.length} etapa(s) posteriores. Vuelve a darle a Iterar para confirmar.`); }
  e.confirmado=false; S.error='';
  for(const k of abajo){ Object.assign(p.etapas[k], {estado:'pendiente', output:'', rondas:[], feedback:''}); }
  e.feedback=fb; e.estado='pendiente'; e.rondas=[]; await guardar(p); await ejecutarEtapa(key);
}
async function otraRonda(key){ await ejecutarEtapa(key); }
async function aprobarAsi(key){ const p=P(); const e=p.etapas[key];
  if(!e.confirmado){ e.confirmado=true; return fallo('El auditor no aprobó esta versión. Vuelve a darle a "Aprobar así" para confirmar.'); }
  e.confirmado=false; S.error=''; e.estado='aprobada'; await guardar(p); render(); await continuar(); }
function detener(){ if(ctl) ctl.abort(); }

// ------------------------------------------------------------ evaluador
let EV = {modo:'imagen', imgs:[], fuente:'cuadros', url:'', gens:null, genSel:null, file:null, n:6, miniaturas:[], estado:'', res:null, escenas:null, analisisId:null, err:''};
async function evaluarImagen(){
  const p=P(); if(!p||!sample||!EV.imgs.length) return;
  EV.estado='Evaluando…'; EV.res=null; EV.err=''; render();
  try{
    const r = await sample.json(promptEvalImagen(p, referenciaAprobada(p), EV.imgs.length), opts(S.ajustes.tierGen, {images:EV.imgs.slice(0, (caps.images&&caps.images.maxCount)||EV.imgs.length)}));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'imagen', fecha:nowIso(), n:EV.imgs.length, veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err=errMsg(e); }
  EV.estado=''; render();
}
function mcpErr(e){
  const m={server_not_connected:'Higgsfield no está conectado en esta cuenta. Agrégalo en claude.ai → Settings → Connectors.', needs_reauth:'Higgsfield pide volver a autorizar. Reconéctalo en claude.ai → Settings → Connectors.', not_in_manifest:'Esta herramienta no está en el manifiesto de la página.', tool_error:'Higgsfield reportó un error: '+((e&&e.message)||''), not_granted:'No autorizaste el conector para esta página.', selection_required:'Tienes más de un conector Higgsfield: elige uno cuando la página lo pida.'};
  return m[e&&e.code] || ((e&&e.message)||'Error del conector.');
}
async function cargarGeneraciones(){
  if(!mcp) return; EV.estado='Cargando tus generaciones de video…'; EV.err=''; render();
  try{ const r = await mcp.callTool('Higgsfield','show_generations',{type:'video', size:24}); const pl = r.payload||{}; EV.gens = (pl.items||[]).filter(g=>g.status==='completed' && g.results && g.results.rawUrl); }
  catch(e){ EV.err=mcpErr(e); }
  EV.estado=''; render();
}
async function extraerCuadros(file, n){
  const v=document.createElement('video'); v.muted=true; v.playsInline=true; v.preload='auto';
  const url=URL.createObjectURL(file); v.src=url;
  try{
    await new Promise((res,rej)=>{ v.onloadedmetadata=()=>res(); v.onerror=()=>rej(new Error('el navegador no pudo leer este video')); });
    const dur = isFinite(v.duration)&&v.duration>0 ? v.duration : 0;
    const cuadros=[], tiempos=[];
    for(let i=0;i<n;i++){
      const t = dur ? dur*(i+0.5)/n : 0;
      await new Promise((res,rej)=>{ v.onseeked=()=>res(); v.onerror=()=>rej(new Error('no se pudo avanzar el video')); v.currentTime=Math.min(t, Math.max(0,dur-0.05)); });
      const w=Math.min(v.videoWidth||640, 1024), h=Math.round((v.videoHeight||360)*(w/(v.videoWidth||640)));
      const c=document.createElement('canvas'); c.width=w; c.height=h;
      c.getContext('2d').drawImage(v,0,0,w,h);
      const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',0.85));
      if(!blob) throw new Error('no se pudo capturar el cuadro');
      cuadros.push(blob); tiempos.push(t);
      if(!dur) break;
    }
    return {cuadros, tiempos};
  } finally { URL.revokeObjectURL(url); }
}
async function evaluarCuadros(){
  const p=P(); if(!p||!sample||!EV.file) return;
  EV.res=null; EV.escenas=null; EV.err=''; EV.estado='Extrayendo cuadros…'; render();
  try{
    const {cuadros, tiempos} = await extraerCuadros(EV.file, Number(EV.n)||6);
    EV.miniaturas = cuadros.map(b=>URL.createObjectURL(b));
    EV.estado=`Evaluando ${cuadros.length} cuadros…`; render();
    const r = await sample.json(promptEvalCuadros(p, referenciaAprobada(p), tiempos), opts(S.ajustes.tierGen, {images:cuadros}));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'video (cuadros)', fecha:nowIso(), veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err = (e&&e.code)?errMsg(e):('No se pudo procesar el video: '+((e&&e.message)||e)); }
  EV.estado=''; render();
}
const esYouTube = u => /^https:\/\/((www\.|m\.)?youtube\.com\/|youtu\.be\/)/.test(u);
async function evaluarVideo(){
  const p=P(); if(!p||!sample||!mcp) return;
  let url = EV.fuente==='gens' ? (EV.genSel&&EV.genSel.results.rawUrl) : EV.url.trim();
  if(!url){ EV.err='Falta el video.'; render(); return; }
  EV.res=null; EV.escenas=null; EV.err='';
  try{
    let input;
    if(esYouTube(url)) input={youtube_url:url};
    else { EV.estado='Importando el video a Higgsfield…'; render(); const im = await mcp.callTool('Higgsfield','media_import_url',{url, type:'video'}); const id=(im.payload||{}).media_id; if(!id) throw {code:'tool_error', message:'la importación no devolvió media_id'}; input={video_input_id:id}; }
    EV.estado='Pidiendo el análisis escena por escena (10 créditos de Higgsfield)…'; render();
    const cr = await mcp.callTool('Higgsfield','video_analysis_create', input);
    const aid = ((cr.payload||{}).result||{}).id; if(!aid) throw {code:'tool_error', message:'no llegó el id del análisis'};
    EV.analisisId=aid;
    const t0=Date.now(); let res=null;
    while(Date.now()-t0 < 12*60*1000){
      await new Promise(r=>setTimeout(r,6000));
      EV.estado=`Analizando el video… ${Math.round((Date.now()-t0)/1000)}s`; render();
      const st = await mcp.callTool('Higgsfield','video_analysis_status',{video_analyze_id:aid},{cache:false});
      res = (st.payload||{}).result||{};
      if(res.status==='completed') break;
      if(res.status==='failed') throw {code:'tool_error', message:res.fail_reason||'el análisis falló'};
    }
    if(!res||res.status!=='completed') throw {code:'tool_error', message:'el análisis no terminó en 12 minutos'};
    EV.escenas = res.scenes||[];
    EV.estado='Evaluando contra el brief…'; render();
    const r = await sample.json(promptEvalVideo(p, referenciaAprobada(p), EV.escenas), opts(S.ajustes.tierGen));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'video', fecha:nowIso(), url, veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err = e&&e.code&&['not_granted','rate_limited','invalid_json','refused','cancelled','prompt_too_large'].includes(e.code) ? errMsg(e) : mcpErr(e); }
  EV.estado=''; render();
}

// ------------------------------------------------------------ markdown mínimo
function md(src){
  const lines=(src||'').split('\n'); let out=[], i=0, inCode=false, buf=[], list=null;
  const flush=()=>{ if(list){ out.push(`</${list}>`); list=null; } };
  const inline = s => esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>').replace(/(^|\W)\*([^*\n]+)\*(?=\W|$)/g,'$1<i>$2</i>');
  for(;i<lines.length;i++){ const l=lines[i];
    if(/^```/.test(l)){ if(inCode){ out.push('<pre><code>'+esc(buf.join('\n'))+'</code></pre>'); buf=[]; inCode=false; } else { flush(); inCode=true; } continue; }
    if(inCode){ buf.push(l); continue; }
    let m;
    if((m=/^(#{1,3})\s+(.*)/.exec(l))){ flush(); out.push(`<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`); continue; }
    if((m=/^\s*[-*•]\s+(.*)/.exec(l))){ if(list!=='ul'){ flush(); out.push('<ul>'); list='ul'; } out.push('<li>'+inline(m[1])+'</li>'); continue; }
    if((m=/^\s*\d+[.)]\s+(.*)/.exec(l))){ if(list!=='ol'){ flush(); out.push('<ol>'); list='ol'; } out.push('<li>'+inline(m[1])+'</li>'); continue; }
    if(/^\s*\|.*\|\s*$/.test(l)){ flush(); const rows=[]; while(i<lines.length && /^\s*\|.*\|\s*$/.test(lines[i])){ rows.push(lines[i]); i++; } i--; const cells=r=>r.trim().slice(1,-1).split('|').map(c=>inline(c.trim())); const body=rows.filter(r=>!/^\s*\|[\s:|-]+\|\s*$/.test(r)); out.push('<table>'+body.map((r,k)=>'<tr>'+cells(r).map(c=>k===0?`<th>${c}</th>`:`<td>${c}</td>`).join('')+'</tr>').join('')+'</table>'); continue; }
    if(!l.trim()){ flush(); continue; }
    flush(); out.push('<p>'+inline(l)+'</p>');
  }
  if(inCode) out.push('<pre><code>'+esc(buf.join('\n'))+'</code></pre>');
  flush(); return out.join('');
}

// ------------------------------------------------------------ render
const ESTADO = {pendiente:['','Pendiente'], generando:['gen','Generando'], auditando:['aud','Auditando'], rechazada:['rech','Rechazada por el auditor'], agotada:['agot','No pasó la auditoría'], espera_ok:['espera','Espera tu OK'], aprobada:['aprob','Aprobada']};
const pillEstado = e => { const [cls,txt]=ESTADO[e.estado]||['',e.estado]; const c = {gen:'info',aud:'info',rech:'bad',agot:'bad',espera:'warn',aprob:'ok'}[cls]||''; return `<span class="pill ${c}">${txt}</span>`; };

function render(){
  const p=P();
  $('#ver').textContent = `${D.meta.reglas} reglas · ${D.meta.auditorias} auditorías`;
  $('#plist').innerHTML = S.proyectos.map(x=>`<button class="${x.id===S.pid?'act':''}" data-p="${x.id}"><b>${esc(x.nombre)}</b><small>${(x.creado||'').slice(0,10)} · ${x.orden?x.orden.length:0} etapas</small></button>`).join('') || '<div class="mute" style="padding:6px 9px">Ningún proyecto todavía.</div>';
  $('#plist').querySelectorAll('button').forEach(b=>b.onclick=()=>{ S.pid=b.dataset.p; S.imgs=[]; EV.res=null; EV.escenas=null; S.view = P().orden.length?'run':'brief'; render(); });
  $('#tabs').querySelectorAll('button').forEach(b=>{ b.classList.toggle('act', b.dataset.v===S.view); b.onclick=()=>{ S.view=b.dataset.v; render(); }; });
  $('#nPlan').textContent = p&&p.orden.length ? p.orden.length : '';
  $('#nRun').textContent = p&&p.orden.length ? `${p.orden.filter(k=>p.etapas[k].estado==='aprobada').length}/${p.orden.length}` : '';
  $('#btnNuevo').onclick = nuevoProyecto;
  const m=$('#main');
  if(S.bloqueo){ vBloqueo(m); return; }
  if(!p){ m.innerHTML = `<div class="hd"><div><h2>Brief</h2></div></div><div class="empty">Sin proyectos. Usa <b>Nuevo brief</b>.</div>`; return; }
  ({brief:vBrief, plan:vPlan, run:vRun, eval:vEval, ajustes:vAjustes})[S.view](m,p);
  banner(m);
}

function banner(m){
  if(!S.error) return;
  const d=document.createElement('div');
  d.className='badbox'; d.style.marginBottom='12px'; d.style.cursor='pointer';
  d.title='Clic para cerrar';
  d.textContent=S.error;
  d.onclick=()=>{ S.error=''; render(); };
  m.insertBefore(d, m.firstChild);
}

function vBloqueo(m){
  m.innerHTML = `<div class="hd"><div><h2>Contraseña</h2><p class="sub">Esta app usa la cuenta de OpenAI del servidor. La contraseña evita que la gaste alguien más.</p></div></div>
  <div class="card" style="max-width:440px">
    <div><div class="lbl">Contraseña</div><input type="password" id="pw" autocomplete="current-password"></div>
    <div class="row"><button class="prim" id="btnPw">Entrar</button><span class="mute" id="pwMsg"></span></div>
  </div>`;
  const inp=$('#pw'), msg=$('#pwMsg'), btn=$('#btnPw');
  const entrar=async()=>{
    const k=inp.value.trim();
    if(!k){ msg.textContent='Escribe la contraseña.'; return; }
    btn.disabled=true; msg.textContent='Verificando…';
    const j=await probarClave(k);
    btn.disabled=false;
    if(!j){ msg.textContent='No se pudo hablar con el servidor.'; return; }
    if(!j.claveOk){ msg.textContent='Contraseña incorrecta.'; inp.select(); return; }
    try{ localStorage.setItem(claveLS,k); }catch(e){}
    SRV=j; S.bloqueo=false; S.error=''; render();
  };
  btn.onclick=entrar;
  inp.onkeydown=e=>{ if(e.key==='Enter') entrar(); };
  inp.focus();
}

function vBrief(m,p){
  m.innerHTML = `<div class="hd"><div><h2>Brief</h2></div></div>
  <div class="card">
    <div><div class="lbl">Nombre del proyecto</div><input type="text" id="nombre" value="${esc(p.nombre)}"></div>
    <div><div class="row" style="justify-content:space-between"><div class="lbl">Brief</div><div class="row"><button class="sm" id="btnVoz">Dictar</button><span class="mute" style="font-size:12px" id="vozN"></span></div></div><textarea id="brief" style="min-height:260px">${esc(p.brief)}</textarea><div class="mute" style="font-size:12px;margin-top:4px" id="briefN"></div></div>
    <div class="grid2">
      <div><div class="lbl">Documentos</div><div class="row"><input type="file" id="docs" hidden accept=".txt,.md,.pdf,.docx,text/plain,text/markdown,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" multiple><button id="btnDocs">Subir txt, md, pdf o docx</button><span class="mute" style="font-size:12px" id="docsN">El texto se agrega al brief.</span></div></div>
      <div><div class="lbl">Imágenes de referencia</div><div class="row"><input type="file" id="imgs" hidden accept="image/*" multiple><button id="btnImgs" ${caps.images?'':'disabled'}>Subir imágenes</button><span class="mute" style="font-size:12px" id="imgsN">${caps.images?(S.imgs.length?`${S.imgs.length} adjunta(s). Se pierden al recargar.`:''):'No disponible aquí.'}</span></div><div class="thumbs" id="thumbs"></div>${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}</div>
    </div>
    ${sample?'':`<div class="badbox">${esc(motivoSinClaude())}</div>`}
    <div class="row"><button class="prim" id="btnPlan" ${S.busy?'disabled':''}>Analizar brief y proponer etapas</button>${p.orden.length?`<span class="mute">Ya hay un plan de ${p.orden.length} etapas. Volver a analizar lo reemplaza.</span>`:''}${S.busy?`<span class="status"><span class="spin"></span><span id="busyN">${esc(S.busy)}</span> · <span class="reloj">0s</span></span>`:''}</div>
  </div>`;
  const ta=$('#brief'), nm=$('#nombre'), cnt=$('#briefN');
  const upd=()=>{ cnt.textContent = `${ta.value.length.toLocaleString('es-MX')} caracteres`; };
  upd();
  ta.oninput=()=>{ p.brief=ta.value; upd(); }; ta.onchange=()=>guardar(p);
  nm.onchange=()=>{ p.nombre=nm.value||'Sin título'; guardar(p); render(); };
  const th=$('#thumbs'); const pintar=()=>{ th.innerHTML=''; S.imgs.forEach(f=>{ const im=document.createElement('img'); im.src=URL.createObjectURL(f); im.alt=f.name; th.appendChild(im); }); };
  pintar();
  $('#btnImgs').onclick=()=>$('#imgs').click(); $('#btnDocs').onclick=()=>$('#docs').click();
  const bv=$('#btnVoz'), vn=$('#vozN'); const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){ bv.disabled=true; vn.textContent='Este navegador no tiene reconocimiento de voz.'; }
  else bv.onclick=()=>{ if(VOZ.rec){ VOZ.rec.stop(); return; } const r=new SR(); VOZ.rec=r; r.lang='es-MX'; r.continuous=true; r.interimResults=true; let base=ta.value, fin='';
    r.onstart=()=>{ bv.textContent='Detener'; bv.classList.add('prim'); vn.textContent='Escuchando…'; };
    r.onresult=ev=>{ let inter=''; for(let i=ev.resultIndex;i<ev.results.length;i++){ const t=ev.results[i][0].transcript; if(ev.results[i].isFinal) fin+=t+' '; else inter+=t; } ta.value=(base.trim()?base.replace(/\s+$/,'')+' ':'')+fin+inter; p.brief=ta.value; upd(); };
    r.onerror=ev=>{ vn.textContent = ev.error==='not-allowed'||ev.error==='service-not-allowed' ? 'Micrófono bloqueado: permite el micrófono en el navegador o dicta con el teclado del sistema.' : 'Error de voz: '+ev.error; };
    r.onend=()=>{ VOZ.rec=null; bv.textContent='Dictar'; bv.classList.remove('prim'); if(vn.textContent==='Escuchando…') vn.textContent=''; guardar(p); };
    try{ r.start(); }catch(e){ vn.textContent='No se pudo iniciar el dictado.'; VOZ.rec=null; } };
  $('#imgs').onchange=ev=>{ S.imgs=[...S.imgs, ...ev.target.files]; ev.target.value=''; pintar(); $('#imgsN').textContent=`${S.imgs.length} adjunta(s). Se pierden al recargar.`; };
  $('#docs').onchange=async ev=>{ const files=[...ev.target.files]; const dn=$('#docsN'); for(const f of files){ dn.textContent=`Leyendo ${f.name}…`; try{ const t=(await textoDe(f)).trim(); if(!t) throw new Error('sin texto legible'); ta.value = (ta.value.trim()? ta.value.replace(/\s+$/,'')+'\n\n':'') + `--- ${f.name} ---\n${t}`; p.brief=ta.value; upd(); dn.textContent=`${f.name}: ${t.length.toLocaleString('es-MX')} caracteres agregados.`; }catch(e){ dn.textContent=`${f.name}: no se pudo leer (${e.message||e}).`; } } ev.target.value=''; await guardar(p); };
  $('#btnPlan').onclick=()=>{ p.brief=ta.value; planificar(); };
}

// ------------------------------------------------------------ documentos
const PDFJS='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', PDFW='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', MAMMOTH='https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.8.0/mammoth.browser.min.js';
function loadScript(src){ return new Promise((res,rej)=>{ if(document.querySelector(`script[src="${src}"]`)) return res(); const s=document.createElement('script'); s.src=src; s.onload=res; s.onerror=()=>rej(new Error('no se pudo cargar la librería')); document.head.appendChild(s); }); }
async function textoDe(f){
  const n=f.name.toLowerCase();
  if(n.endsWith('.pdf')){ await loadScript(PDFJS); pdfjsLib.GlobalWorkerOptions.workerSrc=PDFW; const doc=await pdfjsLib.getDocument({data:new Uint8Array(await f.arrayBuffer())}).promise; const out=[]; for(let i=1;i<=doc.numPages;i++){ const tc=await (await doc.getPage(i)).getTextContent(); out.push(tc.items.map(it=>it.str+(it.hasEOL?'\n':' ')).join('').replace(/[ \t]+\n/g,'\n')); } return out.join('\n\n'); }
  if(n.endsWith('.docx')){ await loadScript(MAMMOTH); return (await mammoth.extractRawText({arrayBuffer:await f.arrayBuffer()})).value; }
  return await f.text();
}

function vPlan(m,p){
  if(!p.plan){ m.innerHTML=`<div class="hd"><div><h2>Plan</h2></div></div><div class="empty">Todavía no hay plan. Analiza el brief primero.</div>`; return; }
  const pl=p.plan; const corriendo = p.orden.some(k=>['generando','auditando'].includes(p.etapas[k].estado));
  m.innerHTML = `<div class="hd"><div><h2>${esc(p.nombre)}</h2><p class="sub">${esc(pl.tipo||'')}${pl.track?` · track ${esc(pl.track)}`:''}</p></div>
    <div class="row"><button class="prim" id="btnRun" ${corriendo?'disabled':''}>${p.orden.some(k=>p.etapas[k].estado!=='pendiente')?'Ir a la ejecución':'Aprobar plan y ejecutar'}</button></div></div>
  <div class="stack">
    <div class="card"><p>${esc(pl.resumen||'')}</p>
      <div class="row"><div><div class="lbl">Aspect ratio</div><input type="text" id="fAspect" style="width:110px" value="${esc((pl.formato||{}).aspect||'')}"></div>
        <div><div class="lbl">Resolución</div><input type="text" id="fRes" style="width:150px" value="${esc((pl.formato||{}).resolucion||'')}"></div>
        <div><div class="lbl">Duración</div><input type="text" id="fDur" style="width:110px" value="${esc((pl.formato||{}).duracion||'')}"></div>
        <span class="mute" style="font-size:12.5px;align-self:flex-end">Manda sobre todos los prompts. Corrígelo aquí antes de ejecutar.</span></div>
      ${(pl.supuestos||[]).length?`<div><div class="lbl">Supuestos que tomó el planificador</div><ul class="crit">${pl.supuestos.map(s=>`<li>${esc(s)}</li>`).join('')}</ul></div>`:''}</div>
    <div class="card"><h3>Etapas (${p.orden.length})</h3>
    <div>${p.orden.map((k,i)=>{ const e=p.etapas[k]; const n=reglasDe(e.casos).length; return `<div class="plan-et"><div class="k">${i+1} · ${esc(e.clave)}</div><div><b>${esc(e.nombre)}</b>${e.ok?' <span class="pill warn">pide tu OK</span>':''}<div class="mute" style="margin:2px 0 4px">${esc(e.objetivo)}</div><div style="font-size:13px"><span class="lbl">Entrega</span> ${esc(e.entregable)}</div><ol class="crit" style="margin-top:4px">${(e.criterios||[]).map(c=>`<li>${esc(c)}</li>`).join('')}</ol><div class="meta" style="margin-top:6px"><span class="pill">${n} reglas</span>${(e.casos||[]).map(c=>`<span class="pill">${c}</span>`).join('')}${e.usaImagenes?'<span class="pill info">ve las imágenes</span>':''}</div></div><div><button class="sm" data-quitar="${k}" ${corriendo?'disabled':''}>Quitar</button></div></div>`; }).join('')}</div>
    <div class="row"><select id="addEt" style="width:auto"><option value="">Agregar etapa…</option>${ETAPAS.map(e=>`<option value="${e.clave}">${e.clave} · ${esc(e.nombre)}</option>`).join('')}</select></div></div>
  </div>`;
  $('#btnRun').onclick=iniciar;
  const guardaFmt=()=>{ pl.formato={aspect:$('#fAspect').value.trim(), resolucion:$('#fRes').value.trim(), duracion:$('#fDur').value.trim()}; guardar(p); };
  ['#fAspect','#fRes','#fDur'].forEach(sel=>$(sel).onchange=guardaFmt);
  m.querySelectorAll('[data-quitar]').forEach(b=>b.onclick=async()=>{ const k=b.dataset.quitar; p.orden=p.orden.filter(x=>x!==k); delete p.etapas[k]; await guardar(p); render(); });
  $('#addEt').onchange=async ev=>{ const c=ev.target.value; if(!c) return; const cat=CAT[c]; const key=`${c}_${uid()}`; p.orden.push(key); p.etapas[key]={key, clave:c, nombre:cat.nombre, objetivo:cat.sale, entregable:cat.sale, casos:cat.casos.slice(0, c==='E5'||c==='PROMPT_IMAGEN'?1:99), criterios:[cat.gate], usaImagenes:c==='REF', ok:cat.ok, estado:'pendiente', output:'', rondas:[], feedback:''}; await guardar(p); render(); };
}

function vRun(m,p){
  if(!p.orden.length){ m.innerHTML=`<div class="hd"><div><h2>Ejecución</h2></div></div><div class="empty">Sin plan. Analiza el brief y aprueba el plan.</div>`; return; }
  const corriendo = p.orden.some(k=>['generando','auditando'].includes(p.etapas[k].estado));
  const listas = p.orden.filter(k=>p.etapas[k].estado==='aprobada').length;
  m.innerHTML = `<div class="hd"><div><h2>${esc(p.nombre)}</h2><p class="sub">${listas} de ${p.orden.length} etapas aprobadas${p.plan&&p.plan.track?` · track ${esc(p.plan.track)}`:''}</p></div>
    <div class="row">${corriendo?`<button id="btnStop">Detener</button>`:`<button class="prim" id="btnCont" ${siguientePendiente(p)?'':'disabled'}>Continuar</button>`}</div></div>
  <div class="stack">${p.orden.map((k,i)=>etapaHTML(p.etapas[k],i)).join('')}</div>`;
  if($('#btnStop')) $('#btnStop').onclick=detener;
  if($('#btnCont')) $('#btnCont').onclick=continuar;
  m.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>({aprobar, iterar, otraRonda, aprobarAsi, ejecutar:ejecutarEtapa, copiar:k=>{ navigator.clipboard.writeText(p.etapas[k].output||''); b.textContent='Copiado'; }})[b.dataset.act](b.dataset.k));
}

function etapaHTML(e,i){
  const cls=(ESTADO[e.estado]||[''])[0]; const activa=['generando','auditando'].includes(e.estado);
  const ult = e.rondas[e.rondas.length-1];
  return `<section class="etapa ${cls}"><div class="stripe"></div><div class="body">
    <div class="top"><div><div class="lbl">${i+1} · ${esc(e.clave)}</div><h3>${esc(e.nombre)}</h3></div><div class="meta">${pillEstado(e)}${e.rondas.length?`<span class="pill">${e.rondas.length} ronda${e.rondas.length>1?'s':''}</span>`:''}${e.reglasTotal?`<span class="pill" title="reglas que cupieron en la instrucción / reglas auditadas">${e.reglasIncluidas}/${e.reglasTotal} reglas</span>`:''}</div></div>
    <p class="mute">${esc(e.objetivo)}</p>
    ${activa?`<div class="status"><span class="spin"></span>${esc(e.progreso||'')} · <span class="reloj">0s</span></div>${activa?`<pre class="mono" id="parcial-${e.key}" style="white-space:pre-wrap;max-height:220px;overflow:auto;margin:0;color:var(--mute)">${esc(e.parcial||'')}</pre>`:''}`:''}
    ${e.error?`<div class="badbox">${esc(e.error)}</div>`:''}
    ${e.rondas.length?`<details ${['rechazada','agotada'].includes(e.estado)?'open':''}><summary>Auditoría · ${e.rondas.map(r=>`R${r.n} ${r.veredicto==='APRUEBA'?'✓':'✗'+r.fallas.length}`).join(' · ')}</summary><div class="log" style="margin-top:8px">${e.rondas.map(r=>`<div class="r"><div>ronda ${r.n}<br>${r.veredicto==='APRUEBA'?'aprueba':'rechaza'}${r.seg?`<br>${r.seg<60?r.seg+'s':Math.floor(r.seg/60)+'m '+String(r.seg%60).padStart(2,'0')+'s'}`:''}<br>${r.palabras} pal.${r.cache?`<br>${Math.round(r.cache/1000)}K de caché`:''}</div><div>${r.fallas.length?r.fallas.map(f=>`<div class="falla"><b>${esc(f.ref)}</b> ${esc(f.correccion)}${f.evidencia?`<div class="ev">${esc(f.evidencia)}</div>`:''}</div>`).join(''):'<span class="mute">Sin fallas.</span>'}${r.notas&&r.notas.length?`<div class="mute" style="margin-top:4px;font-size:12px">${r.notas.map(esc).join(' · ')}</div>`:''}</div></div>`).join('')}</div></details>`:''}
    ${e.output&&!activa?`<div class="out"><div class="row" style="justify-content:space-between"><span class="lbl">Entregable${e.estado==='agotada'?' (última versión, no aprobada)':''}</span><button class="sm" data-act="copiar" data-k="${e.key}">Copiar</button></div><div class="md">${md(e.output)}</div></div>`:''}
    ${!activa?`<div class="row" style="border-top:1px solid var(--line);padding-top:10px">
      ${e.estado==='espera_ok'?`<button class="prim" data-act="aprobar" data-k="${e.key}">Aprobar y continuar</button>`:''}
      ${e.estado==='agotada'?`<button class="prim" data-act="otraRonda" data-k="${e.key}">Otras ${S.ajustes.rondas} rondas</button><button data-act="aprobarAsi" data-k="${e.key}">Aprobar así</button>`:''}
      ${e.estado==='rechazada'?`<button class="prim" data-act="otraRonda" data-k="${e.key}">Reintentar</button>`:''}
      ${e.estado==='pendiente'&&!e.output?`<button class="sm" data-act="ejecutar" data-k="${e.key}">Ejecutar solo esta</button>`:''}
      ${e.output||e.estado==='rechazada'?`<div style="flex:1;min-width:260px"><textarea id="fb-${e.key}" style="min-height:56px" placeholder="Qué cambiar en esta etapa (iteración)">${esc(e.feedback||'')}</textarea></div><button data-act="iterar" data-k="${e.key}">Iterar</button>`:''}
    </div>`:''}
  </div></section>`;
}

function vEval(m,p){
  const ref = p.orden.filter(k=>p.etapas[k].estado==='aprobada').length;
  m.innerHTML = `<div class="hd"><div><h2>Evaluador</h2><p class="sub">Referencia: brief${ref?` + ${ref} etapas aprobadas`:''} de <b>${esc(p.nombre)}</b></p></div>
    <div class="seg"><button data-m="imagen" class="${EV.modo==='imagen'?'act':''}">Imagen</button><button data-m="video" class="${EV.modo==='video'?'act':''}">Video</button></div></div>
  <div class="stack">
  ${EV.modo==='imagen'?`<div class="card">
      <div><div class="lbl">Imágenes generadas</div><div class="row"><input type="file" id="evImgs" hidden accept="image/*" multiple><button id="btnEvPick" ${caps.images?'':'disabled'}>Subir imágenes</button><span class="mute" style="font-size:12px">${caps.images?(EV.imgs.length?`${EV.imgs.length} adjunta(s)`:''):'No disponible aquí.'}</span></div><div class="thumbs" id="evThumbs"></div>${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}</div>
      <div class="row"><button class="prim" id="btnEvImg" ${!sample||!EV.imgs.length||EV.estado?'disabled':''}>Evaluar</button>${EV.estado?`<span class="status"><span class="spin"></span>${esc(EV.estado)}</span>`:''}</div>
    </div>`
  :`<div class="card">
      ${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}
      <div class="seg"><button data-f="cuadros" class="${EV.fuente==='cuadros'?'act':''}">Archivo de video</button>${mcp?`<button data-f="url" class="${EV.fuente==='url'?'act':''}">URL</button><button data-f="gens" class="${EV.fuente==='gens'?'act':''}">Higgsfield</button>`:''}</div>
      ${EV.fuente==='cuadros'?`<div class="row"><input type="file" id="evVid" hidden accept="video/*"><button id="btnVidPick">Elegir video</button><span class="mute" style="font-size:12.5px">${EV.file?esc(EV.file.name):'mp4, mov o webm del disco'}</span><select id="evN" style="width:auto">${[4,6,8,12].map(n=>`<option ${EV.n==n?'selected':''}>${n}</option>`).join('')}</select><span class="mute" style="font-size:12.5px">cuadros</span></div>${EV.miniaturas.length?`<div class="thumbs">${EV.miniaturas.map(u=>`<img src="${u}" alt="">`).join('')}</div>`:''}<div class="row"><button class="prim" id="btnEvCuadros" ${!sample||!caps.images||!EV.file||EV.estado?'disabled':''}>Evaluar</button><span class="mute" style="font-size:12.5px">Sin audio ni movimiento continuo: se evalúan cuadros.</span></div>`
      :EV.fuente==='url'?`<input type="url" id="evUrl" placeholder="https://youtu.be/… o https://….cloudfront.net/….mp4" value="${esc(EV.url)}">`
      :`<div class="row"><button class="sm" id="btnGens" ${!mcp||EV.estado?'disabled':''}>${EV.gens?'Recargar':'Cargar mis videos'}</button><span class="mute" style="font-size:12.5px">${EV.gens?`${EV.gens.length} videos completados`:''}</span></div>${EV.gens?`<div class="gens">${EV.gens.map(g=>`<button data-g="${g.id}" class="${EV.genSel&&EV.genSel.id===g.id?'act':''}"><img src="${esc(g.results.thumbnailUrl||'')}" alt=""><small>${esc((g.params&&g.params.prompt||g.model||g.id).slice(0,60))}</small></button>`).join('')}</div>`:''}`}
      ${EV.fuente!=='cuadros'?`<div class="row"><button class="prim" id="btnEvVid" ${!sample||!mcp||EV.estado?'disabled':''}>Analizar y evaluar</button><span class="mute" style="font-size:12.5px">10 créditos de Higgsfield por análisis.</span></div>`:''}
      ${EV.estado?`<div class="status"><span class="spin"></span>${esc(EV.estado)}</div>`:''}
    </div>`}
  ${EV.err?`<div class="badbox">${esc(EV.err)}</div>`:''}
  ${EV.res?resultadoHTML(EV.res):''}
  ${EV.escenas?`<div class="card"><h3>Escenas detectadas (${EV.escenas.length})</h3><table class="tbl"><tr><th>#</th><th>Tiempo</th><th>Plano</th><th>Visual</th><th>Audio</th></tr>${EV.escenas.map(s=>`<tr><td>${s.scene_number}</td><td class="mono">${esc(s.timestamp_start)}–${esc(s.timestamp_end)}</td><td>${esc(s.shot_type||'')}</td><td>${esc(s.visual||'')}</td><td class="mute">${esc(s.audio||'')}</td></tr>`).join('')}</table></div>`:''}
  ${(p.evaluaciones||[]).length?`<details><summary>Historial · ${p.evaluaciones.length} evaluaciones</summary><table class="tbl" style="margin-top:8px"><tr><th>Fecha</th><th>Tipo</th><th>Veredicto</th><th>Puntaje</th></tr>${p.evaluaciones.slice().reverse().map(x=>`<tr><td class="mono">${esc(x.fecha.slice(0,16).replace('T',' '))}</td><td>${esc(x.tipo)}</td><td>${esc(x.veredicto||'')}</td><td class="mono">${x.puntaje??''}</td></tr>`).join('')}</table></details>`:''}
  </div>`;
  m.querySelectorAll('[data-m]').forEach(b=>b.onclick=()=>{ EV.modo=b.dataset.m; EV.res=null; EV.escenas=null; EV.err=''; render(); });
  m.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{ EV.fuente=b.dataset.f; render(); });
  m.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{ EV.genSel=EV.gens.find(g=>g.id===b.dataset.g); render(); });
  if($('#evImgs')){ const th=$('#evThumbs'); const pintar=()=>{ th.innerHTML=''; EV.imgs.forEach(f=>{ const im=document.createElement('img'); im.src=URL.createObjectURL(f); im.alt=f.name; th.appendChild(im); }); }; pintar(); $('#btnEvPick').onclick=()=>$('#evImgs').click(); $('#evImgs').onchange=ev=>{ EV.imgs=[...ev.target.files]; render(); }; $('#btnEvImg').onclick=evaluarImagen; }
  if($('#btnVidPick')){ $('#btnVidPick').onclick=()=>$('#evVid').click(); $('#evVid').onchange=ev=>{ EV.file=ev.target.files[0]||null; EV.miniaturas=[]; EV.res=null; render(); }; $('#evN').onchange=ev=>{ EV.n=Number(ev.target.value); }; $('#btnEvCuadros').onclick=evaluarCuadros; }
  if($('#evUrl')) $('#evUrl').oninput=ev=>{ EV.url=ev.target.value; };
  if($('#btnGens')) $('#btnGens').onclick=cargarGeneraciones;
  if($('#btnEvVid')) $('#btnEvVid').onclick=evaluarVideo;
}

function resultadoHTML(r){
  const v=r.veredicto||''; const c = v==='CUMPLE'?'ok':v==='PARCIAL'?'warn':'bad';
  return `<div class="card"><div class="row" style="justify-content:space-between"><div class="row"><span class="score">${r.puntaje??'–'}</span><span class="pill ${c}">${esc(v)}</span></div></div>
    ${r.descripcion?`<p>${esc(r.descripcion)}</p>`:''}
    ${Array.isArray(r.criterios)?`<table class="tbl"><tr><th>Criterio</th><th>Cumple</th><th>Evidencia</th></tr>${r.criterios.map(x=>`<tr><td>${esc(x.criterio)}</td><td>${x.cumple===true?'<span class="pill ok">sí</span>':x.cumple===false?'<span class="pill bad">no</span>':'<span class="pill">n/v</span>'}</td><td class="mute">${esc(x.evidencia||'')}</td></tr>`).join('')}</table>`:''}
    ${Array.isArray(r.por_escena)&&r.por_escena.length?`<div><div class="lbl">Por escena</div><ul class="crit">${r.por_escena.map(x=>`<li><b>${esc(x.escena)}</b> ${esc(x.nota)}</li>`).join('')}</ul></div>`:''}
    ${Array.isArray(r.correcciones)&&r.correcciones.length?`<div><div class="lbl">Correcciones para el siguiente intento</div><ol class="crit" style="color:var(--ink)">${r.correcciones.map(x=>`<li>${esc(x)}</li>`).join('')}</ol></div>`:''}
    ${r.prompt_ajustado?`<div><div class="lbl">Ajuste de prompt sugerido</div><div class="md"><pre><code>${esc(r.prompt_ajustado)}</code></pre></div></div>`:''}
  </div>`;
}

const ESF=[['complex','alto'],['default','medio'],['quick','bajo']];
function vAjustes(m,p){
  const a=S.ajustes;
  m.innerHTML=`<div class="hd"><div><h2>Ajustes</h2></div></div>
  <div class="card"><div class="grid2">
    <div><div class="lbl">Rondas máximas de auditoría por etapa</div><select id="aR">${[1,2,3,4,5].map(n=>`<option ${a.rondas==n?'selected':''}>${n}</option>`).join('')}</select></div>
    <div></div>
    <div><div class="lbl">Esfuerzo al generar</div><select id="aG">${ESF.map(([v,n])=>`<option value="${v}" ${a.tierGen===v?'selected':''}>${n}</option>`).join('')}</select></div>
    <div><div class="lbl">Esfuerzo al auditar</div><select id="aA">${ESF.map(([v,n])=>`<option value="${v}" ${a.tierAud===v?'selected':''}>${n}</option>`).join('')}</select></div>
  </div>
    <div><div class="lbl">Base de reglas</div><div class="mute" style="font-size:13px">${D.meta.reglas} reglas de ${D.meta.skills} skills · ${D.meta.auditorias} correcciones de auditoría externa · casos: ${Object.keys(D.porCaso).map(c=>`${c} ${D.porCaso[c].length}`).join(' · ')}</div></div>
  </div>`;
  const save=()=>{ a.rondas=Number($('#aR').value); a.tierGen=$('#aG').value; a.tierAud=$('#aA').value; try{ localStorage.setItem(ajustesLS, JSON.stringify(a)); }catch(e){} };
  ['#aR','#aG','#aA'].forEach(s=>$(s).onchange=save);
}

// ------------------------------------------------------------ arranque
(async()=>{
  render();
  const cl=$('#capline');
  const use = n => (window.claude&&window.claude.use) ? window.claude.use(n).catch(()=>null) : Promise.resolve(null);
  [sample, db, mcp] = await Promise.all([use('sample'), use('db'), use('mcp')]);
  if(!sample){
    SRV = await detectarServidor();
    if(SRV && SRV.ia){ sample = sampleDeServidor(); if(SRV.clave && !SRV.claveOk) S.bloqueo=true; }
  }
  if(sample){ try{ const l=await sample.limits(); caps.images=l.images||false; }catch(e){} }
  await cargarLista();
  if(S.proyectos.length && !S.pid){ S.pid=S.proyectos[0].id; S.view = P().orden.length?'run':'brief'; }
  if(!S.proyectos.length){ const p={id:uid(), nombre:'Sin título', brief:'', creado:nowIso(), plan:null, etapas:{}, orden:[], evaluaciones:[]}; S.proyectos.push(p); S.pid=p.id; S.view='brief'; }
  const parts=[ sample?(SRV?('ChatGPT '+(SRV.modelo||'')+' vía servidor propio'):'Claude listo'):(SRV&&!SRV.ia?'Falta OPENAI_API_KEY en el servidor':'Modelo no disponible'), db?'guardado en la nube':'guardado local', mcp?'Higgsfield listo':'video por cuadros' ];
  cl.textContent = parts.join(' · ');
  render();
})();
</script>
"""


ENVOLTURA = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{color-scheme:light dark}
html,body{margin:0}
body{font:14px/1.5 system-ui,sans-serif;background:#F2F4F7}
img{max-width:100%}
[hidden]{display:none!important}
</style>
</head>
<body>
__CUERPO__
</body>
</html>
"""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="rules.sqlite")
    ap.add_argument("--out", default="app/ejecutor.html")
    ap.add_argument("--public", default="public/index.html",
                    help="copia servible desde Vercel; '' para no generarla")
    a = ap.parse_args()

    con = sqlite3.connect(a.db)
    casos = dict(con.execute("SELECT codigo, descripcion FROM casos"))

    idx, por_caso = {}, {}
    for rid, sk, ar, ln, tx in con.execute("SELECT id,skill,archivo,linea,texto FROM reglas"):
        idx[rid] = {"s": sk, "a": ar, "l": ln, "t": tx, "o": "regla"}
    for rid, caso, origen in con.execute("SELECT regla_id,caso,origen FROM regla_caso"):
        if rid not in idx or caso == "NINGUNO":
            continue
        idx[rid]["o"] = origen
        por_caso.setdefault(caso, []).append(rid)
    usados = {r for ids in por_caso.values() for r in ids}
    idx = {k: v for k, v in idx.items() if k in usados}

    datos = {
        "etapas": ETAPAS, "tracks": TRACKS, "casos": casos, "porCaso": por_caso, "idx": idx,
        "meta": {"reglas": len(idx),
                 "skills": con.execute("SELECT COUNT(DISTINCT skill) FROM reglas").fetchone()[0],
                 "auditorias": con.execute("SELECT COUNT(*) FROM auditorias").fetchone()[0]},
    }
    blob = json.dumps(datos, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    cuerpo = PLANTILLA.replace("__DATOS__", blob)
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(cuerpo, encoding="utf-8")
    print(f"{out}: {out.stat().st_size / 1024:.0f} KB · {len(idx)} reglas en {len(por_caso)} casos")

    # La misma pagina, servida desde un dominio propio. El visor de artifacts
    # envuelve el HTML y aplica un reset minimo; aqui hay que escribirlo.
    if a.public:
        pub = Path(a.public)
        pub.parent.mkdir(parents=True, exist_ok=True)
        pub.write_text(ENVOLTURA.replace("__CUERPO__", cuerpo), encoding="utf-8")
        print(f"{pub}: {pub.stat().st_size / 1024:.0f} KB")
    for c, ids in sorted(por_caso.items(), key=lambda kv: -len(kv[1])):
        print(f"  {c:8} {len(ids):>4}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

<!-- SOURCE_FILE_END: repo/app/build_app.py -->


<!-- SOURCE_FILE_START: repo/app/ejecutor.html -->
# SOURCE FILE: `repo/app/ejecutor.html`

<title>Ejecutor de Producción</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Condensed:wght@500;600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap">
<style>
:root{
  --bg:#F2F4F7;--surf:#FFFFFF;--ink:#161A20;--mute:#5C6674;--line:#D6DBE3;--soft:#E9EDF2;
  --acc:#D9541E;--acc-ink:#FFFFFF;--ok:#1F8A4C;--warn:#B7791F;--bad:#C0392B;--info:#2F6FBF;
  --ok-bg:#E4F3EA;--warn-bg:#FBF1DC;--bad-bg:#F9E3E0;--info-bg:#E3ECF9;
  --disp:"IBM Plex Sans Condensed","Arial Narrow",sans-serif;
  --body:"IBM Plex Sans",system-ui,sans-serif;
  --mono:"IBM Plex Mono",ui-monospace,Menlo,monospace;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --bg:#121519;--surf:#1A1E24;--ink:#E8EAED;--mute:#9AA3AF;--line:#2B313A;--soft:#232930;
  --acc:#F0703A;--acc-ink:#15100D;--ok:#4CC37A;--warn:#E0A83C;--bad:#EF6B5E;--info:#6FA3F0;
  --ok-bg:#16301F;--warn-bg:#352A12;--bad-bg:#3A1C19;--info-bg:#16263D;}}
:root[data-theme="dark"]{
  --bg:#121519;--surf:#1A1E24;--ink:#E8EAED;--mute:#9AA3AF;--line:#2B313A;--soft:#232930;
  --acc:#F0703A;--acc-ink:#15100D;--ok:#4CC37A;--warn:#E0A83C;--bad:#EF6B5E;--info:#6FA3F0;
  --ok-bg:#16301F;--warn-bg:#352A12;--bad-bg:#3A1C19;--info-bg:#16263D;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 var(--body)}
h1,h2,h3{font-family:var(--disp);font-weight:600;letter-spacing:.01em;margin:0;text-wrap:balance}
h1{font-size:20px}h2{font-size:17px}h3{font-size:15px}
p{margin:0}
a{color:var(--info)}
button{font:inherit;cursor:pointer;border:1px solid var(--line);background:var(--surf);color:var(--ink);border-radius:6px;padding:7px 12px}
button:hover{border-color:var(--mute)}
button:focus-visible,textarea:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
button:disabled{opacity:.5;cursor:default}
button.prim{background:var(--acc);color:var(--acc-ink);border-color:var(--acc);font-weight:600}
button.sm{padding:4px 9px;font-size:12.5px}
button.link{border:0;background:none;color:var(--info);padding:0}
textarea,input[type=text],input[type=url],select{font:inherit;color:var(--ink);background:var(--surf);border:1px solid var(--line);border-radius:6px;padding:8px 10px;width:100%}
textarea{min-height:120px;resize:vertical;line-height:1.5}
input[type=file]{font:inherit;color:var(--mute)}
.lbl{font-family:var(--disp);font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--mute);font-weight:600}
.mono{font-family:var(--mono);font-size:12.5px}
.mute{color:var(--mute)}
.app{display:grid;grid-template-columns:250px 1fr;min-height:100vh}
.rail{border-right:1px solid var(--line);background:var(--surf);padding:16px 14px;display:flex;flex-direction:column;gap:14px}
.rail .brand{display:flex;align-items:baseline;gap:8px}
.rail .brand small{color:var(--mute);font-family:var(--mono);font-size:11px}
.plist{display:flex;flex-direction:column;gap:2px;overflow:auto;max-height:50vh}
.plist button{text-align:left;border:0;padding:7px 9px;border-radius:5px;display:flex;flex-direction:column;gap:2px}
.plist button.act{background:var(--soft)}
.plist button small{color:var(--mute);font-size:11.5px;font-family:var(--mono)}
.plist button b{font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:210px}
.tabs{display:flex;flex-direction:column;gap:2px}
.tabs button{text-align:left;border:0;padding:7px 9px;border-radius:5px;display:flex;justify-content:space-between;align-items:center}
.tabs button.act{background:var(--ink);color:var(--bg)}
.tabs button span.n{font-family:var(--mono);font-size:11px;opacity:.75}
.main{padding:22px 28px 60px;max-width:980px;width:100%}
.hd{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;margin-bottom:16px;flex-wrap:wrap}
.hd .sub{color:var(--mute);margin-top:2px}
.card{background:var(--surf);border:1px solid var(--line);border-radius:8px;padding:16px 18px;display:flex;flex-direction:column;gap:12px}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.stack{display:flex;flex-direction:column;gap:12px}
.pill{display:inline-flex;align-items:center;gap:6px;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:500;border:1px solid var(--line);background:var(--soft)}
.pill.ok{background:var(--ok-bg);color:var(--ok);border-color:transparent}
.pill.warn{background:var(--warn-bg);color:var(--warn);border-color:transparent}
.pill.bad{background:var(--bad-bg);color:var(--bad);border-color:transparent}
.pill.info{background:var(--info-bg);color:var(--info);border-color:transparent}
.pill.acc{background:var(--acc);color:var(--acc-ink);border-color:transparent}
.etapa{display:grid;grid-template-columns:6px 1fr;border:1px solid var(--line);border-radius:8px;background:var(--surf);overflow:hidden}
.etapa .stripe{background:var(--line)}
.etapa.gen .stripe,.etapa.aud .stripe{background:var(--info)}
.etapa.rech .stripe,.etapa.agot .stripe{background:var(--bad)}
.etapa.espera .stripe{background:var(--warn)}
.etapa.aprob .stripe{background:var(--ok)}
.etapa .body{padding:14px 18px;display:flex;flex-direction:column;gap:10px}
.etapa .top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap}
.etapa .meta{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.crit{margin:0;padding-left:18px;color:var(--mute)}
.crit li{margin:2px 0}
.out{border-top:1px solid var(--line);padding-top:10px}
.md{line-height:1.55;max-width:72ch}
.md h1,.md h2,.md h3{margin:12px 0 6px}
.md h1{font-size:17px}.md h2{font-size:15.5px}.md h3{font-size:14px}
.md p{margin:6px 0}
.md ul,.md ol{margin:6px 0;padding-left:22px}
.md pre{background:var(--soft);border:1px solid var(--line);border-radius:6px;padding:10px 12px;overflow-x:auto;font-family:var(--mono);font-size:12.5px;line-height:1.5;white-space:pre-wrap;margin:8px 0}
.md code{font-family:var(--mono);font-size:12.5px;background:var(--soft);padding:1px 4px;border-radius:3px}
.md pre code{background:none;padding:0}
.md table{border-collapse:collapse;margin:6px 0;font-size:13px}
.md th,.md td{border:1px solid var(--line);padding:4px 8px;vertical-align:top}
.log{border:1px solid var(--line);border-radius:6px;overflow:hidden;font-size:13px}
.log .r{display:grid;grid-template-columns:82px 1fr;border-top:1px solid var(--line)}
.log .r:first-child{border-top:0}
.log .r>div{padding:6px 10px}
.log .r>div:first-child{background:var(--soft);font-family:var(--mono);font-size:12px;color:var(--mute)}
.falla{padding:6px 0;border-top:1px dashed var(--line)}
.falla:first-child{border-top:0}
.falla b{font-family:var(--mono);font-weight:500;font-size:12px}
.falla .ev{color:var(--mute);font-style:italic}
.status{display:flex;align-items:center;gap:8px;color:var(--mute);font-size:13px}
.spin{width:12px;height:12px;border:2px solid var(--line);border-top-color:var(--acc);border-radius:50%;animation:sp .8s linear infinite;flex:none}
@keyframes sp{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){.spin{animation:none}}
.thumbs{display:flex;gap:8px;flex-wrap:wrap}
.thumbs img{height:72px;border-radius:4px;border:1px solid var(--line)}
.gens{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}
.gens button{padding:0;overflow:hidden;text-align:left;display:flex;flex-direction:column}
.gens img{width:100%;aspect-ratio:16/9;object-fit:cover;display:block}
.gens small{padding:4px 7px;color:var(--mute);font-family:var(--mono);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.gens button.act{outline:2px solid var(--acc)}
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;font-family:var(--disp);font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--mute);padding:6px 8px;border-bottom:1px solid var(--line)}
.tbl td{padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
.score{font-family:var(--disp);font-size:34px;font-weight:600;line-height:1;font-variant-numeric:tabular-nums}
.empty{color:var(--mute);padding:30px 0;text-align:center}
.warnbox{background:var(--warn-bg);color:var(--warn);border-radius:6px;padding:8px 12px;font-size:13px}
.badbox{background:var(--bad-bg);color:var(--bad);border-radius:6px;padding:8px 12px;font-size:13px}
.infobox{background:var(--info-bg);color:var(--info);border-radius:6px;padding:8px 12px;font-size:13px}
details>summary{cursor:pointer;color:var(--mute);font-size:13px}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:6px;overflow:hidden}
.seg button{border:0;border-radius:0;border-right:1px solid var(--line)}
.seg button:last-child{border-right:0}
.seg button.act{background:var(--ink);color:var(--bg)}
.chk{display:flex;gap:8px;align-items:center}
.plan-et{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:start;padding:10px 0;border-top:1px solid var(--line)}
.plan-et:first-child{border-top:0}
.plan-et .k{font-family:var(--mono);font-size:12px;color:var(--mute);padding-top:2px;min-width:110px}
@media (max-width:820px){.app{grid-template-columns:1fr}.rail{border-right:0;border-bottom:1px solid var(--line)}.grid2{grid-template-columns:1fr}.main{padding:16px}}
</style>

<div class="app">
  <aside class="rail">
    <div class="brand"><h1>Ejecutor</h1><small id="ver"></small></div>
    <button class="prim" id="btnNuevo">Nuevo brief</button>
    <div class="lbl">Proyectos</div>
    <div class="plist" id="plist"></div>
    <div class="lbl">Módulos</div>
    <nav class="tabs" id="tabs">
      <button data-v="brief">Brief</button>
      <button data-v="plan">Plan <span class="n" id="nPlan"></span></button>
      <button data-v="run">Ejecución <span class="n" id="nRun"></span></button>
      <button data-v="eval">Evaluador</button>
      <button data-v="ajustes">Ajustes</button>
    </nav>
    <div class="mute" style="font-size:12px;margin-top:auto" id="capline">Conectando…</div>
  </aside>
  <main class="main" id="main"></main>
</div>

<script>
const D = {"etapas":[{"clave":"E0","nombre":"Brand Lock","cond":"solo si hay marca o cliente","casos":["MARCA"],"tracks":["STANDARD","FILM"],"ok":true,"entra":"Sitio web, brand book, screenshots o descripción","sale":"brand-lock.md — 9 secciones, cada valor con fuente y confianza","gate":"El usuario confirma los valores flagged como estimados. Sin marca formal, usa el Visual Theme de la Etapa 3 como sustituto ligero."},{"clave":"E1","nombre":"Creative Strategy","cond":"","casos":["GUION"],"tracks":["STANDARD","FILM"],"ok":true,"entra":"Brand lock + brief","sale":"Territorios explorados, 3–5 concept cards, matriz de selección y dirección narrativa del concepto ganador","gate":"El usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto."},{"clave":"E2","nombre":"Screenwriting","cond":"","casos":["GUION"],"tracks":["STANDARD","FILM"],"ok":true,"entra":"Concept card ganadora + dirección narrativa","sale":"Treatment (solo FILM) → script con escenas XML-tagged, sluglines, acción y diálogo","gate":"Cada escena pasa la fórmula de escena (deseo + obstáculo + geometría + mirada + ritmo) y la three-jobs rule: cambia emoción, avanza acción o sube presión. La que no hace ninguna se corta aquí, no en el shot list."},{"clave":"E3","nombre":"Cinematic Direction","cond":"","casos":["CLIP","SHOT"],"tracks":["STANDARD","FILM"],"ok":false,"entra":"Script","sale":"Documento de dirección por escena: blocking, composición, cámara motivada, lente, luz, evolución de color, lenguaje de edición y los 5 anclas de la pieza","gate":"Cero palabras del vocabulario prohibido. Cada decisión de cámara tiene razón dramática escrita."},{"clave":"E4","nombre":"Shot Planning","cond":"punto de entrada del track EXPRESS","casos":["SHOT"],"tracks":["EXPRESS","STANDARD","FILM"],"ok":true,"entra":"Script + documento de dirección (EXPRESS: solo el brief)","sale":"storyboard.md · shots.json · text-overlays.json — shots.json es la fuente de verdad; ningún prompt existe sin shot ID","gate":"Six-point dramaturgy check + auditoría de 3 detalles por shot (presión ambiental, micro-acción física, ancla de sonido). Un shot con cero detalles es filler y se elimina."},{"clave":"E5","nombre":"Anchor Images","cond":"","casos":["T1","T2","T3","T4","T5","PROD","GRAF","MULTI","REF","QA"],"tracks":["EXPRESS","STANDARD","FILM"],"ok":false,"entra":"shots.json + brand-lock","sale":"Plan de anchors (character refs, environment refs, keyframes por shot clave) y prompts finales de imagen por anchor","gate":"Cada anchor crítico pasa la crítica. Máximo 2 rondas de revisión; a la tercera falla se replantea el shot, no el prompt."},{"clave":"E6","nombre":"Video Prompts","cond":"","casos":["CLIP"],"tracks":["EXPRESS","STANDARD","FILM"],"ok":false,"entra":"shots.json + anchor aprobado","sale":"Prompts de video finales por shot, con continuity blocks entre clips","gate":"Dramaturgy check de 6 puntos + auditoría de 3 detalles. Un prompt que falla cualquiera NO se entrega."},{"clave":"E7","nombre":"Package & Delivery","cond":"","casos":["ENTREGA"],"tracks":["STANDARD","FILM"],"ok":false,"entra":"Todos los artefactos de las etapas anteriores","sale":"Final AI Video Production Package + checklist de postproducción","gate":"Checklist maestro completo y trazabilidad verificada: 3 prompts al azar trazan hasta su concepto. Si un eslabón falta, no se entrega."},{"clave":"PROMPT_IMAGEN","nombre":"Prompt de imagen","cond":"brief de una sola imagen","casos":["T1","T2","T3","T4","T5","PROD","GRAF","MULTI"],"tracks":[],"ok":false,"entra":"El brief (y referencias, si hay)","sale":"Cabecera de 3 líneas SKILL:/RIESGOS:/TÉCNICA:, modelo recomendado y el prompt final en inglés en un bloque de código","gate":"Cumple todas las reglas del caso elegido. Sin vocabulario prohibido."},{"clave":"PROMPT_VIDEO","nombre":"Prompt de video","cond":"brief de un solo clip","casos":["CLIP"],"tracks":[],"ok":false,"entra":"El brief (y referencias, si hay)","sale":"Cabecera de 3 líneas, modelo recomendado y el prompt final en inglés en un bloque de código","gate":"Dramaturgy check de 6 puntos + 3 detalles. Sin vocabulario prohibido."},{"clave":"REF","nombre":"Referencia a prompt","cond":"hay imagen de referencia y se pide recrearla","casos":["REF"],"tracks":[],"ok":false,"entra":"Imagen de referencia adjunta","sale":"Descomposición de la referencia (sujeto, luz, lente, color, composición) y el prompt para recrearla en inglés en un bloque de código","gate":"Cada elemento visible de la referencia está en el prompt; nada inventado."},{"clave":"ESTRATEGIA","nombre":"Estrategia","cond":"el brief pide una estrategia o plan, no una pieza visual","casos":[],"tracks":[],"ok":true,"entra":"El brief","sale":"Documento estratégico: diagnóstico, opciones, recomendación y plan de acción con siguientes pasos","gate":"Responde exactamente lo que pide el brief. Cada recomendación tiene razón y siguiente paso concreto."},{"clave":"DOC","nombre":"Documento","cond":"cualquier otro entregable de texto","casos":[],"tracks":[],"ok":false,"entra":"El brief y lo aprobado antes","sale":"El documento que pide el brief","gate":"Cumple cada criterio del plan."}],"tracks":{"EXPRESS":"≤30s, un beat (hook→payoff). Entra en E4 y salta E0–E3 y E7.","STANDARD":"30–90s, arco simple. E0–E7 con E1 comprimida (2–3 conceptos) y E2 sin treatment.","FILM":"90s–10min, multi-escena. E0–E7 completas, todos los gates."},"casos":{"T1":"maestro de rostro (still, persona, identidad)","T2":"maestro de cuerpo (still, persona completa)","T3":"cuadro con 1 persona (still de escena)","T4":"cuadro con 2 personas (still, contacto/interaccion)","T5":"edicion quirurgica sobre imagen existente","CLIP":"prompt de video / movimiento","SHOT":"planeacion de shots, storyboard, shots.json","GUION":"escritura de guion o tratamiento","MARCA":"extraccion o uso de brand-lock","QA":"critica de render, revision de asset generado","ENTREGA":"empaquetado, preview, entrega a cliente","PROD":"still de producto, comida u objeto (sin persona)","GRAF":"pieza grafica: poster, slide, UI, social, tipografia dominante","MULTI":"multi-panel o grid dentro de una sola imagen","REF":"analisis de imagen de referencia, image-to-prompt","NINGUNO":"no aplica a ningun caso de produccion (meta, ejemplos, docs)"},"porCaso":{"T1":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","f5bdd52eae18","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","09ec7d23fe12","b921448eda9a","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","f7781b9ee5c2","31a9f9f11aa7","a8c47d2e697e","b5749680d5b1","e849bbafb08a","608c66f4b15a","639574d396e1","be07ac1a9f48","bc5138b583ba","ee853dd503fd","ce04a04c45aa","97ef5791058f","e85f3a2c01a5","e200695107d8","bdc7c98423b2","e80f84e82cd7","2260c15e96b4","36bbbe701ad0","5b0ec72c5a49","9a20603f7d87","29940f3cd9ae","f708635c6957","b8ecc6c820c5","25c7ab649b75","b6f22ea21acd","be5a2e46231a","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5a5348b20c81","5cf46d07bcac","b6df20344be1","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","bbcf9882e50b","05f30ccb87c3","c1d814f8c059","d0476aaa14d5","edb34335baee","24d0e917035e","4e37b6108b10","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"T2":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","f5bdd52eae18","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","09ec7d23fe12","b921448eda9a","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","f7781b9ee5c2","31a9f9f11aa7","a8c47d2e697e","b5749680d5b1","e849bbafb08a","608c66f4b15a","639574d396e1","be07ac1a9f48","bc5138b583ba","ee853dd503fd","ce04a04c45aa","97ef5791058f","e85f3a2c01a5","e200695107d8","9b5c3232e804","348b0b1ed027","1bf69ac8c5e3","eb03e137df6e","c5971eabbb4b","6dfcd0919723","ce24e75d12a1","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5cf46d07bcac","b6df20344be1","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","bbcf9882e50b","05f30ccb87c3","c1d814f8c059","d0476aaa14d5","24d0e917035e","4e37b6108b10","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"T3":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","f5bdd52eae18","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","09ec7d23fe12","b921448eda9a","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","ce04a04c45aa","97ef5791058f","e85f3a2c01a5","e200695107d8","9b5c3232e804","348b0b1ed027","1bf69ac8c5e3","eb03e137df6e","c5971eabbb4b","6dfcd0919723","ce24e75d12a1","bdc7c98423b2","e80f84e82cd7","2260c15e96b4","36bbbe701ad0","5b0ec72c5a49","9a20603f7d87","29940f3cd9ae","f708635c6957","b8ecc6c820c5","25c7ab649b75","b6f22ea21acd","be5a2e46231a","44c898225d80","4c1d2cabad77","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5cf46d07bcac","613774db48c2","204113433c22","4d4ea0758b3f","b6df20344be1","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","bbcf9882e50b","05f30ccb87c3","c1d814f8c059","d0476aaa14d5","36f326b4fa1b","b1bf8c0bd438","24d0e917035e","4e37b6108b10","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"T4":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","09ec7d23fe12","b921448eda9a","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5cf46d07bcac","613774db48c2","204113433c22","4d4ea0758b3f","b6df20344be1","7dc14c265b1a","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","bbcf9882e50b","05f30ccb87c3","c1d814f8c059","d0476aaa14d5","24d0e917035e","4e37b6108b10","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"T5":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","67a7dd9329dc","26e0c5fc6ab4","762ce60bec5e","cb50b580f819","ff510d7ca127","4fcb4afa54c3","3f9822c97a3a","a509f495c750","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","87eadbf796d1","d48021c639e6","4a2eeac6c89d","6658223ecd3e","3348210ad98e","b37aa531231e","7ba769efe2d7","c0bc3ce2b122","ca17e7d8bf24","0895bf9c3c72","5cf46d07bcac","4d4ea0758b3f","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","c1d814f8c059","24d0e917035e","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"CLIP":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","2c2da899a44d","eee77c7d576a","3fb8782f57b8","b2a93a3b39b9","2dddf6f48ba3","3f921ee68519","82d4b1aa2d36","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","2d5d435df3ef","f21bcfe2dfbc","99b3186877c9","54b8e873fa4e","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","4ddd5b7aae62","1df0239fdbc2","87d2484dd6cf","1863ac937570","d98803cf48d0","8f83dc97e5ba","8ea66f62d954","13635ca633f1","508966ae84b9","7dabe8b7b479","b755a79d8702","2d6cacf87d0d","c485717d92a0","f1cf3ccb4d13","a7febb0fdf00","61f2696d823a","179286c8c088","c16f3957c655","a82de4fa4979","d85e439effb2","0809eafc4ffb","bb25b6a212a2","71e86bdfe510","a4313d46162b","9e30b0899784","7d81fcd5ccc0","21472873e0ca","c9b8d9532823","4286109b9522","8b8795ac59fd","eeae0374284b","5c7946d7fd9f","15b3f8595289","7a47e689454a","d94be792c74d","0db6e0a2de52","1e5d66901508","36686df1386d","7d3ab7f4ba2a","cf73cec68544","85c33c12c479","4b9361768f1a","f876e8f2e5cb","5a27254127bb","5465eb46d054","240a672f7a78","5eaea7d005f0","4c683ca1e1ef","fae5c2bff912","de49559afcec","94114b6c3c86","dc069aea561b","3c3a35bd5003","fe2010e7cd1e","5090be9f2dcb","f4e68628a21b","1a73cf483aab","8acb235535b4","9d8033a7fcbb","58c03455aad2","7e710b7de286","2976ffd881f1","83694d17ac4b","4340f22ac789","b93895a69273","e56653bec670","809f55027421","8870a91220dc","5e9381b1532d","8dd832a85896","324bcf02f62b","3cc2915d07c9","f0315e2411a6","ed4fbf774ee8","7887bf99374c","dbf4503191cb","884b4b40911e","877300b2ba56","3b48069bb705","6eafd4ebaa95","0395ddb6bd06","73905921cedf","a78b8143dfae","809fb4ebddce","659a2eb38201","ae09790a4e9b","e30cec365a82","2d5229cb5344","c6a20928bc70","d629ec5811b5","e57740e558ac","80e69a894fcc","a75221469baa","71fec8821328","6b50e2278180","f1f0fcdff995","27ee9fc25b00","f4c2c207fbb8","e7caec8627aa","dd071e4f1adc","1eff4afae0c5","90c9d01c7da9","3da18291f908","01e778de1f4c","d9efc3ad4bfb","a4cd347f4b1e","e24b10c311e9","9373adbe6c11","adbe90385564","75ec08f6c7e0","6f2d9a2fd7ba","e2b9c51c5ef7","f7ff7d98a4a9","51c07299485c","2e0a56484152","21023b368ec1","d1794addd647","0196c3f7220c","da70b123efd4","e21763705dd8","dfcbb6dd0684","a45ee38936f8","01a57763de37","1c400db686fb","402a936cf3fe","1a0831f5ce00","eb02f32299e5","fe59b8611a5b","4a161f379427","53a3fb486be4","0a4395028757","375413fbe1a3","658b20f679d9","ce8831e8984c","68f234798bd5","87680002b885","097929817bc7","79369bcf16d4","3dde58c707c6","60f13533c38e","c04789da6e17","f136c00c3d59","f44cf9ff7226","5598ee94689f","ab3cc98cbe7f","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","a5926981e848","c52dc68d0daf","34c9774072b9","a96d5275630a","c05a37e6c694","dd11b5da1036","1e43dbde9ec3","5996725c4119","28b092664be0","9d51ba168710","07771e486a77","cee8c4cd6183","e84b5c0448b9","750cf06a6b5c","c962c96606da","0acb882ac4aa","561e4601866e","00ad95b7807d","926508430703","a0d393395e3a","4140ed69949c","20b3434a9a5d","3b984b2349a3","0f136ad02a4a","985e93f22844","dd6e04a7a56e","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","22f6035ce704","32344b412ad5","e67edc98e31f","5e8113658ff6","7e40e9d57114","5acc0a53e64b","8499e1ad407c","8a7cde5fbf44","1740a84f47a3","6c398f45603b","6c97051eb055","e7f6806c93e3","35389a2e7e9a","993e2cd1eec5","40867e840a40","e620d729b974","0678f6cbf749","5d267e42e94d","18b6449fb38c","bbcf9882e50b","05f30ccb87c3","00552d374a9c","47dd1d977a21","a2680889ec7c","5e64b7c7d357","1f3f073247b7","11ae3ea96fb0","611f323d3615","ca87c9bb0cd3","be25e9cc99a1","fc4a79f80ec2","7a8e1fc6b5e6","9bf2cbf9c271","0e9bacb2e8ad","98ee930c9f7c","2be4bcd05090","8a862f876fa8","f79825c8bfa6","784a21fb3fba","c50591694f2a","5f835d0eb35a","a433636c2657","2d91bbc13caa","f5ef9ac105ef","19ef2dbc9666","de0ddf9ca295","54d1d74f3df8","1948fb0cd2ea","cedacf95ce49","5c79b70fbb5a","e47d5852520a","d92564e28fe4","9570d85c5b8a","85f471342e23","a84829cef94a","c8f9182dab48","b9c780304835","c3c3d1047037","31550b84c066","c1d814f8c059","8cb896ae3ca7","24d0e917035e","4755505de7d6","3d67beea0470","98d91e461feb","1087e186fed5","199cfb9ab91d","b2e806d6105a","14c534d5e7f2","bfb6f1d9e6b2"],"SHOT":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","1f8ed1aa2f82","976919fb7afd","2c2da899a44d","eee77c7d576a","4c5ba2b2ce9e","1cf2b2af3609","ed8f12484923","aeb5f5e9292c","f999ef3808aa","c9068adfe734","3244bb3011e7","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","1abf520d87fe","24fe340cb58e","43a9c422d34f","b9cd34ffcb70","b04a79b44100","6d32d7171722","0fb332eaeff4","84e4c557c5f1","9116b6b7205f","22aed852b261","5bea8ddfb87c","c241a02cc037","921f5446334f","d5feae1b60b8","4594046fc713","f2664fed4b35","fe8ae4c731e8","291a35a705ad","adc3e3d51477","435fff89e7d5","dbb9069efcc9","5d494f11d5ec","09ecf6f81ee5","94cb46e0cdd8","0cf6378a2c57","dd109f775c6c","5b4e8d3dcda1","2be8adc698a8","c7fa86763233","f88d89dd2268","6be9ddc67dea","c2e0a3b45412","01d9db058ef3","75eee4c9c72b","c52b9a2cbc96","cd71da05d199","e51237770b8c","eba7494935d3","f876e8f2e5cb","5a27254127bb","5465eb46d054","240a672f7a78","5eaea7d005f0","4c683ca1e1ef","fae5c2bff912","de49559afcec","94114b6c3c86","1eff4afae0c5","90c9d01c7da9","3da18291f908","01e778de1f4c","d9efc3ad4bfb","a4cd347f4b1e","e24b10c311e9","9373adbe6c11","adbe90385564","75ec08f6c7e0","6f2d9a2fd7ba","e2b9c51c5ef7","f7ff7d98a4a9","51c07299485c","2e0a56484152","21023b368ec1","d1794addd647","0196c3f7220c","da70b123efd4","e21763705dd8","dcba7967bb86","34d356cca129","06f7cfabe30d","f02d8dcae6c2","9a04fd13f520","d58376dbc7f5","33379bbc4b87","8a33756b8cb8","3172bdb34a71","47f320764950","eb02f32299e5","fe59b8611a5b","4a161f379427","53a3fb486be4","0a4395028757","375413fbe1a3","658b20f679d9","ce8831e8984c","68f234798bd5","87680002b885","097929817bc7","79369bcf16d4","3dde58c707c6","60f13533c38e","c04789da6e17","f136c00c3d59","f44cf9ff7226","5598ee94689f","ab3cc98cbe7f","73fe57cd2392","30bbbcefca75","3a6fba22ac13","ea1a9a227c90","d584b5f6dd31","2ad7d2bd5837","409086978069","a8d68a296084","364c86aacbd6","7696a03e6c31","8f9cad0e2224","0a6768420027","0b4182e7f0fc","37204f4e9d9d","abc02ebdb6a8","38de07452a46","16f6bf46f67c","4c1f6d0ef267","7e5f2e473cd3","f32c786bfbff","d329c7d38124","b55cf418fc3a","e5235864c6bb","0206d6df0cc3","9b3fba335e1b","e4b20db35b44","cfaecb7f5fa7","39b17554140c","ec4f8b7428c7","3bdf77c5a1e7","6154ed831bf3","6be1e3549be6","ca19a04f7f16","e707043ad741","61117f1e1435","bcd48bb1ab67","409a346f14c6","e4456cb5dc55","86733dae8e0e","4b795000d239","a68a06f84fe6","0357fe063806","08af446ba369","428f5eebff7b","a268ba75d0b5","efdeec778e0f","90221fe5fe0f","48c59084ee78","9f529931cccc","c1fb4192e05a","84655e935767","84f1791a022e","67f2beaeb3ef","4ff066eab26b","7a7cb7a4a5e8","9f4f78bc99a2","717463d29f8f","7268a7328d89","74926ea5bff7","6b3fa7bb2923","5528555145f9","e4e41d7c48e9","03a00602482e","22f6035ce704","32344b412ad5","e67edc98e31f","5e8113658ff6","7e40e9d57114","5acc0a53e64b","8499e1ad407c","8a7cde5fbf44","1740a84f47a3","6c398f45603b","6c97051eb055","e7f6806c93e3","35389a2e7e9a","993e2cd1eec5","40867e840a40","e620d729b974","0678f6cbf749","5d267e42e94d","18b6449fb38c","8d21f65f4329","c7861b2bb543","8b27a216f395","5b7b1c8fb6ae","bbcf9882e50b","5942ba44f22f","1cec4673e7f2","85e3ed23b8ae","05f30ccb87c3","4cbacbc0b8fa","d7940c08b552","00552d374a9c","47dd1d977a21","a2680889ec7c","5e64b7c7d357","1f3f073247b7","11ae3ea96fb0","611f323d3615","ca87c9bb0cd3","be25e9cc99a1","fc4a79f80ec2","7a8e1fc6b5e6","9bf2cbf9c271","0e9bacb2e8ad","98ee930c9f7c","2be4bcd05090","8a862f876fa8","f79825c8bfa6","784a21fb3fba","c50591694f2a","5f835d0eb35a","a433636c2657","2d91bbc13caa","f5ef9ac105ef","19ef2dbc9666","de0ddf9ca295","54d1d74f3df8","1948fb0cd2ea","cedacf95ce49","5c79b70fbb5a","e47d5852520a","d92564e28fe4","9570d85c5b8a","85f471342e23","a84829cef94a","c8f9182dab48","b9c780304835","c3c3d1047037","31550b84c066","c1d814f8c059","79f9fd6178a0","024638f7f93d","2306baa11deb","8cb896ae3ca7","24d0e917035e"],"GUION":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","1f8ed1aa2f82","976919fb7afd","36dd5696e226","201666abd399","476511682f20","240748ade236","8c97f2430a2a","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","fb3896038afa","4d9355018ad2","57e9c487ac74","fa0199539554","e10b5f7be709","45f2e43f67e0","a93dbeef8737","10e5da2fcf9a","59d398f4c454","671c49de0056","27e302d3a37e","5645bf344589","68d5f2185557","c775d8acd13e","8cc0ef448f33","bff5030b3380","35abb8abc912","df9b899dbc91","de28e225dfa5","aa1edc03619b","0cf150e839a8","b6cf18f1ea26","f1221744d7a1","42187af933ee","38b4028efe2f","5ea772208440","3697579b1689","dcba7967bb86","34d356cca129","06f7cfabe30d","f02d8dcae6c2","9a04fd13f520","d58376dbc7f5","33379bbc4b87","8a33756b8cb8","3172bdb34a71","47f320764950","7e5f2e473cd3","f32c786bfbff","d329c7d38124","b55cf418fc3a","e5235864c6bb","0206d6df0cc3","9b3fba335e1b","e4b20db35b44","cfaecb7f5fa7","39b17554140c","ec4f8b7428c7","3bdf77c5a1e7","6154ed831bf3","6be1e3549be6","ca19a04f7f16","e707043ad741","61117f1e1435","bcd48bb1ab67","409a346f14c6","e4456cb5dc55","86733dae8e0e","4b795000d239","a68a06f84fe6","0357fe063806","08af446ba369"],"MARCA":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","ebc1422e5d22","fcc9a56efa31","96e709999be1","5fe217339055","0dae3fdc0ace","39e68cb30388","c183542f6090","6257a4f1fd42","89c96fc0932b","ddd43db015c9","4075284680a4","086086b8d7f3","c9c3a9312a4c","cd4c7a7c3646","49fd83a4b509","afdb75007c72","6eb4f8ba4dbc","03ede5f175d7","3d50d9dc8cee","2b77fe0ab77d","528f3aca58d3","34f304b45ae2","70f50258fc9f","a61acb519eac","39f21f0bd621","bdeeca395947","21f3127a222e","289646ec1639","5108ce119398","98944bc5d597","5e5cfb4ec221","cc15db8a3ce1","f861a19be4ca","42b960dda0f5","e320951a2f69","deff6acf6ba6","995266039bd6","9c0afb7d325a","00c5d773e8d3","a9ed618bb40b","2d715d9073e7","b5797c1841f0","fb243b53c635","daf6cf4dbcb9","d446778cd38a","b4fbf43a4a92","04363c882bf7","a69c36bdec51","a1ad2f291171","775e72423ee9","3f18cfa9b5e8","a86e2eb18131","451be222e3f4","f419380942de","dd519aa232b4","5a0a397f54c1","f3fad8754516","147b5d10f118","e3d69437c2f6","ff2826465af1","bd1590a213fe","2ef7c79850da","5d8f1227d198","c2fbf1d46956","a3fa0f352d46","c1ee0d0b5a80","650d25a8d091","5cff35ce456c","e49a82b5336a","3e5b03db5bd2","ab8ee2cc3cfb","3f9aad2c4e2c","db7addc154a9","df43eb92b1b2","c5e62839e1ee","2f545717c91e","e03457ae7069","25f0ecf00da8","1acd5803bd0f","3214012dc24d","250eda4c5849","5ada3d9e3057","25d9cd499896","e815875bfd9e","dd6e8d6008ac","333c20110ff3","5aecc4ca21d4","dac6a52ee58c","c95b248c14c2","c906d8795790","ba0238372a4c","03c4f6662db6","91020f8aff04","26257934361a","65805ba83e7e","19abf8cb5067","d81969febc9e","e1559d443197","f380cff82f61","e10409cde634","5c3ec0c8cf75","fef9fe44ef96","4590b5aee804","d40b84764301","478143da99e2","1bbba41d8f5e","1249aae4215a","621b3df6eb6a","d9e264405291","64c7eedde7cc","38c7b73cec5b","4b55ac47f0e7","ff35cc7d69fd","995296a29fb4","db692e54505e","5e4a95ec4d8c","929d3e62f0b7","c5761942f155","f28e4507d045","3751f321730f","9132e55fcf5d","0f628683c6b8","eff9c8392083","b700cf8f4dcb","45e257d77c42","ddb048e79808","eb006504840c","783ff683393c","8cea74bc14b1","f6abdd226436","d8a47abf50ca","e9560a0de1ac","cc0c55fe6755","c1a8c5479b88","8d21f65f4329","c7861b2bb543","8b27a216f395","5b7b1c8fb6ae","1cec4673e7f2","05f30ccb87c3","4cbacbc0b8fa","d7940c08b552","0aebfb67e4fd","edb34335baee","36f326b4fa1b","6fcfbe5ad699","cf3ce4e1adaf","b1bf8c0bd438","2306baa11deb","8cb896ae3ca7","24d0e917035e"],"QA":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","1dc7c87def16","c8195d96aaff","3236a31aecea","4254cbeb01a9","4dabd7bdc618","7eac9caa0ac8","c24705b39ede","fd33b1fe4a83","583d5f400a46","0cde22e1a93c","5b837820df26","a221a716e952","65ab63f3291c","c7b95c733b7f","1e898f2c0308","31afcb61a699","788f1a8f5595","8014a721e61b","9b616f961fba","b1bf47b129ef","0aebfb67e4fd","79f9fd6178a0","024638f7f93d","d0476aaa14d5"],"ENTREGA":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","1f8ed1aa2f82","976919fb7afd","2c2da899a44d","eee77c7d576a","0574ba956e73","69545d03256e","9848dbda5e26","f999ef3808aa","8c97f2430a2a","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","44283e478fd4","090ccfb96455","629bb2d205d3","b9f0e777f95a","09e4367e3b97","8a2c11a5fc35","410599a6e6d1","e3ddb1d823f5","32701372f5d1","6975e2ff7171","77570da551dd","d86f1629a7f6","90b1a187484f","9f76efb872f5"],"PROD":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","8901152207fe","b8fa85d560e3","5ad1340da288","862a4c0ea3bc","dabc108ffb16","58817d380494","42a42a73fa09","4bc498edcc17","bc6d5c9aff5f","318b118d917d","92eeb4747a7e","51b0bfedb210","329aa0a4fa84","11ec80431f42","5856058c8a75","84828d3c69a2","a90636943228","8005da81a345","c3d4dd460549","19234ef99d6a","6a46a42327af","9a00a07b257d","09817e522cce","d1f50fd09fa8","6fc560223ecb","bf758f621b50","46ce53039819","a9c702b552f4","d4f497bb93d1","4c926ca35845","df532917ca8c","a30c3b235f2e","de44302b8294","d62c529d34db","afdcc8f7bc89","4f23b10353c9","20bb122f18fb","1ba1ff7577c8","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","5cf46d07bcac","613774db48c2","204113433c22","6f5a79ae61af","617b9596ef1d","a3c2614e6e5e","84e552ce62b9","0278247a92b4","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","00552d374a9c","47dd1d977a21","a2680889ec7c","5e64b7c7d357","1f3f073247b7","11ae3ea96fb0","611f323d3615","ca87c9bb0cd3","be25e9cc99a1","fc4a79f80ec2","7a8e1fc6b5e6","9bf2cbf9c271","0e9bacb2e8ad","98ee930c9f7c","2be4bcd05090","8a862f876fa8","f79825c8bfa6","784a21fb3fba","c50591694f2a","5f835d0eb35a","a433636c2657","2d91bbc13caa","f5ef9ac105ef","19ef2dbc9666","de0ddf9ca295","54d1d74f3df8","1948fb0cd2ea"],"GRAF":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","04c28ccbddf9","3db8f42e251f","16ec02525ce7","47652229b5ab","822ae545689f","20e10fa23ffc","3de5ceee5c4e","5856058c8a75","84828d3c69a2","a90636943228","8005da81a345","9b5c3232e804","348b0b1ed027","1bf69ac8c5e3","eb03e137df6e","c5971eabbb4b","6dfcd0919723","ce24e75d12a1","5c934f24e5bd","535d74d81a91","7b6acbb90a0a","57fca5220269","c755ff2903b8","cd1fa75558c5","803245de38c4","b6a40416c21b","44c898225d80","4c1d2cabad77","7a21ad4f3c7d","be784fefef07","f5f07232cc75","ac9f15b7d326","76fa850073b5","d4e8f76bb757","b1a90c3a0a1d","8f24d3e22d84","6b8e9a41cbf9","5bb61a5742b2","e3ff88ae7b6f","796d88912233","2f0619f0ec28","8e32b234137b","7447d548b9f0","0db1539c575d","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","613774db48c2","204113433c22","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","428f5eebff7b","a268ba75d0b5","efdeec778e0f","90221fe5fe0f","48c59084ee78","9f529931cccc","c1fb4192e05a","84655e935767","84f1791a022e","67f2beaeb3ef","4ff066eab26b","7a7cb7a4a5e8","9f4f78bc99a2","717463d29f8f","5942ba44f22f","1cec4673e7f2","85e3ed23b8ae","4cbacbc0b8fa","d7940c08b552","024638f7f93d","6fcfbe5ad699","cf3ce4e1adaf","2306baa11deb","226a236b4dcc","4755505de7d6","88ac8d8506e0","73aaed94b890","83c574fc9ce5","e0e022e50a9e","3d67beea0470","98d91e461feb","1087e186fed5"],"MULTI":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","c83679230b88","043b9dc0b02e","f556f97c9939","11ea00e863de","0358891ec685","c5eb6fd7f6f8","485206c1697b","890a0b28f120","0e7900ffe2af","d9bcca3cf113","1dd54b582a02","7fff008d0b4a","cc4167f1d432","8d02f99b51e9","c10c7e21ff29","1848820351ae","c8d4fff1dabe","85e2a5dc4aa8","26da6aecb6fb","0aad9d5a3dfa","0456a3106233","20e10fa23ffc","5856058c8a75","84828d3c69a2","a90636943228","8005da81a345","f7781b9ee5c2","31a9f9f11aa7","a8c47d2e697e","b5749680d5b1","e849bbafb08a","608c66f4b15a","639574d396e1","be07ac1a9f48","bc5138b583ba","ee853dd503fd","afdcc8f7bc89","4f23b10353c9","20bb122f18fb","1ba1ff7577c8","ce04a04c45aa","97ef5791058f","e85f3a2c01a5","e200695107d8","44c898225d80","4c1d2cabad77","c842524ed79f","a127cca4810d","e01904554508","3d26f71cccce","52c7e13d4185","796a278bda86","3a5fb89a88b1","7421490e82fa","576f2ecf7dd2","5eca40f8b2dc","e25ece2ca897","0237812f9545","79ad480edaab","921aa8a23672","d9727650ad44","90d4b17bba47","910dd4553129","d8c349628ad4","1e4fc13d2d29","a0be4760c51c","1062c830e923","eb71e5086205","bf6161618f55","f6982091002c","c9068adfe734","3244bb3011e7","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad","4a9a9f1d1b5a","cf6ea7ae4157","90c1b290af77","c55494cbbad4","0447e389826e","d070363f06ff","bc7cb8df5ee2","3e22b4c62b1b","20ebea9d8a54","fd93590ae5d9","b5fa2fb924bd","e1f3ed8e587b","a6bec722c41f","d4f119799fc1","8ad2673a7cf6","22d09b130cbd","35ad63b182a1","c51e98883ae8","e6bae7347048","f85b78ac44b0","8452bcb3abe4","3ac7c1186c62","43331142e7ea","c169c881a0e6","03aa46d144b5","c4812cc96bc2","5fc1cc954fb0","5c181b49f9d4","b58550816f3f","735b1edeccc3","8c221aa40298","679f8c322dba","3de5ebeb511c","14306fa1f1c7","2757ce63d7e2","8f8dc623566a","b826ad9667a2","717c03da642d","6447bec15b56","359736f73561","5945d25c9b90","ecb6a8e221f1","982752f60d62","1f983ff0ee18","12009aa60167","4be94337bb02","33fc833724e0","bcaac139f9b7","67037c4b307e","e177c4f10a04","4c22b71ebf0a","5f5e6ee4ad91","c8f9182dab48"],"REF":["8a2a24e72003","5673820bc473","4ca2dc8c76f1","7e22722f52fa","442a75c51f58","a712726b25c7","04cb7f3e5408","7d2338d1b298","3d2a2115477d","7cf887e9d7c2","526a0bad384e","a4a34906e54d","ab216a6c933f","5c17fa63163e","241ea833ab9d","f9fee85351f3","84846df151fa","6da8440e93ad"]},"idx":{"1f8ed1aa2f82":{"s":"ai-production-director","a":"SKILL.md","l":16,"t":"**Clasificar** el proyecto y elegir el track correcto.","o":"regla"},"976919fb7afd":{"s":"ai-production-director","a":"SKILL.md","l":17,"t":"**Secuenciar** las etapas y cargar la sub-skill correcta en cada una.","o":"regla"},"8a2a24e72003":{"s":"ai-production-director","a":"SKILL.md","l":18,"t":"**Custodiar los gates**: ninguna etapa arranca sin que la anterior pase su quality gate.","o":"regla"},"c83679230b88":{"s":"ai-production-director","a":"SKILL.md","l":19,"t":"**Resolver conflictos** entre sub-skills con las reglas de la sección 6 — las decidiste una vez, no se renegocian por proyecto.","o":"regla"},"2c2da899a44d":{"s":"ai-production-director","a":"SKILL.md","l":20,"t":"**Mantener trazabilidad**: todo artefacto downstream traza a un shot ID, todo shot traza a una escena, toda escena al concepto aprobado.","o":"regla"},"4ca2dc8c76f1":{"s":"ai-production-director","a":"SKILL.md","l":65,"t":"Cada etapa declara: sub-skill, entradas, salidas, y gate. El gate se verifica ANTES de avanzar. Si falla, se corrige en la etapa actual — nunca se \"arregla después\".","o":"regla"},"36dd5696e226":{"s":"ai-production-director","a":"SKILL.md","l":75,"t":"**Gate:** el usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto.","o":"regla"},"043b9dc0b02e":{"s":"ai-production-director","a":"SKILL.md","l":85,"t":"**Gate:** cero palabras del vocabulario prohibido (sección 6.1). Cada decisión de cámara tiene razón dramática escrita.","o":"regla"},"3fb8782f57b8":{"s":"ai-production-director","a":"SKILL.md","l":101,"t":"**Gate obligatorio:** los dos checks de `video` (dramaturgy check de 6 puntos + auditoría de 3 detalles) Y, si `aurora-prompt-linter` está instalada, el linter pasa limpio. Un prompt que falla cualquiera de los dos NO se entrega.","o":"regla"},"5673820bc473":{"s":"ai-production-director","a":"SKILL.md","l":112,"t":"Nunca preguntes lo que el brief o los artefactos previos ya responden.","o":"regla"},"f556f97c9939":{"s":"ai-production-director","a":"SKILL.md","l":123,"t":"El vocabulario prohibido de `video`/dramaturgy (+ `aurora-prompt-linter` si está) **gana siempre**: \"cinematic\", \"epic\", \"stunning\", \"masterpiece\", \"beautiful lighting\", \"professional\", \"high quality\", emociones nombradas sin cuerpo. Esto **anula explícitamente** la regla de `ai-video-storyboard` de cerrar cada prompt con \"cinematic 1080p, synchronized audio\". En su lugar: la resolución, aspect ra","o":"regla"},"4c5ba2b2ce9e":{"s":"ai-production-director","a":"SKILL.md","l":129,"t":"De la Etapa 4 en adelante: `shots.json`. Un cambio creativo se hace primero en shots.json y se propaga hacia abajo; nunca se parcha un prompt de forma que contradiga su shot.","o":"regla"},"1cf2b2af3609":{"s":"ai-production-director","a":"SKILL.md","l":132,"t":"`visual-prompt-forge` es dueño del **flujo de datos** (shots.json → borrador, critique.json → revisión selectiva). `video`/`image` smixs son dueños del **texto final** del prompt. El borrador del forge se reescribe a sintaxis smixs; nunca al revés.","o":"regla"},"b2a93a3b39b9":{"s":"ai-production-director","a":"SKILL.md","l":141,"t":"**Proyectos de animación** (2D/3D/motion graphics): es la única skill instalada con los 12 principios de Disney y el flujo de producción de animación. En un proyecto animado, su sección de animación se suma a la Etapa 3 como referencia de performance y timing.","o":"regla"},"201666abd399":{"s":"ai-production-director","a":"SKILL.md","l":150,"t":"`references/creative-strategy.md` — Protocolo completo de la Etapa 1: territorios, big ideas, concept cards, matriz de selección, dirección narrativa. Léelo SIEMPRE al ejecutar la Etapa 1.","o":"regla"},"0574ba956e73":{"s":"ai-production-director","a":"SKILL.md","l":151,"t":"`references/production-package.md` — Spec del Final AI Video Production Package, reglas de trazabilidad y checklist maestro. Léelo SIEMPRE al ejecutar la Etapa 7.","o":"regla"},"476511682f20":{"s":"ai-production-director","a":"references/creative-strategy.md","l":17,"t":"Si el single-minded proposition no se puede escribir en una frase, la Etapa 1 no puede continuar. Resuélvelo con el usuario primero.","o":"regla"},"240748ade236":{"s":"ai-production-director","a":"references/creative-strategy.md","l":37,"t":"De los territorios más fuertes, baja 3–5 conceptos (FILM) o 2–3 (STANDARD). Cada concepto es UNA película posible, no una variación de la anterior. Formato obligatorio:","o":"regla"},"eee77c7d576a":{"s":"ai-production-director","a":"references/production-package.md","l":44,"t":"Todo prompt (imagen o video) lleva en comentario su `shot_id`.","o":"regla"},"f999ef3808aa":{"s":"ai-production-director","a":"references/production-package.md","l":45,"t":"Todo shot en shots.json referencia su escena del script (`scene` field o nota).","o":"regla"},"8c97f2430a2a":{"s":"ai-production-director","a":"references/production-package.md","l":46,"t":"El script referencia la concept card ganadora en su encabezado.","o":"regla"},"ed8f12484923":{"s":"ai-production-director","a":"references/production-package.md","l":47,"t":"Cambios: si un prompt necesita cambiar algo que su shot fija (encuadre, acción, luz), el cambio se hace en shots.json y se regenera hacia abajo. El paquete nunca contiene un prompt que contradiga su shot.","o":"regla"},"69545d03256e":{"s":"ai-production-director","a":"references/production-package.md","l":48,"t":"Verificación de cierre: muestrea 3 prompts al azar y traza la cadena prompt → shot → escena → concepto. Si un eslabón falta, el paquete no se entrega.","o":"regla"},"9848dbda5e26":{"s":"ai-production-director","a":"references/production-package.md","l":70,"t":"[ ] Dirección cinematográfica sin vocabulario prohibido","o":"regla"},"eb02f32299e5":{"s":"ai-video-storyboard","a":"SKILL.md","l":12,"t":"**Core insight:** Visual consistency across shots matters more than any single shot being perfect. A mediocre but consistent set of shots edits together; six gorgeous but mismatched shots do not.","o":"archivo"},"fe59b8611a5b":{"s":"ai-video-storyboard","a":"SKILL.md","l":32,"t":"**Goal platform and duration?** (TikTok 30s / Reel 15-60s / YouTube Short / Instagram Ad / explainer)","o":"archivo"},"4a161f379427":{"s":"ai-video-storyboard","a":"SKILL.md","l":33,"t":"**What is the video about?** (subject, story, product)","o":"archivo"},"53a3fb486be4":{"s":"ai-video-storyboard","a":"SKILL.md","l":34,"t":"**Brand vibe / tone?** (cozy, energetic, premium, minimalist, playful, cinematic, etc.)","o":"archivo"},"0a4395028757":{"s":"ai-video-storyboard","a":"SKILL.md","l":35,"t":"**Call to action at the end?** (visit website, buy product, follow channel, etc.)","o":"archivo"},"375413fbe1a3":{"s":"ai-video-storyboard","a":"SKILL.md","l":36,"t":"**Any hard constraints?** (must include logo, specific colors, locations, etc.)","o":"archivo"},"658b20f679d9":{"s":"ai-video-storyboard","a":"SKILL.md","l":62,"t":"**Lens character** (shallow DOF / deep focus / wide angle distortion / macro)","o":"archivo"},"ce8831e8984c":{"s":"ai-video-storyboard","a":"SKILL.md","l":66,"t":"Write these as a **Visual Theme** block at the top of the output. Every shot's prompt must respect this block.","o":"archivo"},"68f234798bd5":{"s":"ai-video-storyboard","a":"SKILL.md","l":89,"t":"**Always specify the shared visual language** in every prompt (color palette, lighting, lens character, film look). This is how you enforce consistency.","o":"archivo"},"87680002b885":{"s":"ai-video-storyboard","a":"SKILL.md","l":90,"t":"**Specify exact duration** (4s / 5s / 8s) and **aspect ratio** (9:16 for TikTok/Reels, 16:9 for YouTube landscape, 1:1 for feed posts).","o":"archivo"},"097929817bc7":{"s":"ai-video-storyboard","a":"SKILL.md","l":91,"t":"**Always end with \"cinematic 1080p, synchronized audio\"** — this signals professional-grade quality and works with modern video models that support both.","o":"archivo"},"79369bcf16d4":{"s":"ai-video-storyboard","a":"SKILL.md","l":92,"t":"**Use cinematography vocabulary**: ECU (extreme close-up), CU, MS (medium shot), WS (wide shot), OTS (over-the-shoulder), POV, Dutch angle, low angle, high angle, bird's eye, dolly in, dolly out, tracking, handheld, rack focus, etc.","o":"archivo"},"3dde58c707c6":{"s":"ai-video-storyboard","a":"SKILL.md","l":93,"t":"**Don't write abstract prompts** — be concrete. \"A woman\" → \"A barista in her late 20s with wavy auburn hair, wearing a denim apron\".","o":"archivo"},"60f13533c38e":{"s":"ai-video-storyboard","a":"SKILL.md","l":94,"t":"**No model-specific hacks** — don't write prompts tuned to specific model quirks. Write model-agnostic cinematic prompts that work anywhere.","o":"archivo"},"c04789da6e17":{"s":"ai-video-storyboard","a":"SKILL.md","l":98,"t":"The sequence of shots must have a **story arc**, not a random list. Use one of these patterns:","o":"archivo"},"f136c00c3d59":{"s":"ai-video-storyboard","a":"SKILL.md","l":146,"t":"**Header** — Title, duration, shot count, aspect ratio","o":"archivo"},"f44cf9ff7226":{"s":"ai-video-storyboard","a":"SKILL.md","l":147,"t":"**Visual Theme** — Shared palette, lighting, lens, film look, motion","o":"archivo"},"5598ee94689f":{"s":"ai-video-storyboard","a":"SKILL.md","l":148,"t":"**Shot List** — N shots, each following the structure in Step 4","o":"archivo"},"ab3cc98cbe7f":{"s":"ai-video-storyboard","a":"SKILL.md","l":150,"t":"**Why This Works** — creative rationale","o":"archivo"},"ebc1422e5d22":{"s":"brand-lock-extractor","a":"SKILL.md","l":12,"t":"This skill extracts. It does not invent. Every value is sampled from a real asset or flagged as an estimate the user must confirm. A confident-sounding wrong hex is worse than a flagged guess.","o":"archivo"},"fcc9a56efa31":{"s":"brand-lock-extractor","a":"SKILL.md","l":34,"t":"Written description | Use directly | Identity, archetype, voice posture","o":"archivo"},"96e709999be1":{"s":"brand-lock-extractor","a":"SKILL.md","l":46,"t":"Tell the user what you are pulling. Do not ask follow-ups yet, extract first, confirm gaps at the end.","o":"archivo"},"5fe217339055":{"s":"brand-lock-extractor","a":"SKILL.md","l":52,"t":"**Identity** (brand, one-line description, archetype, voice posture)","o":"archivo"},"0dae3fdc0ace":{"s":"brand-lock-extractor","a":"SKILL.md","l":53,"t":"**Palette** (sampled hex, by role)","o":"archivo"},"39e68cb30388":{"s":"brand-lock-extractor","a":"SKILL.md","l":54,"t":"**Typography** (display, body, optional mono, with weights)","o":"archivo"},"c183542f6090":{"s":"brand-lock-extractor","a":"SKILL.md","l":55,"t":"**Mood adjectives** (3-5, specific, contrast clauses preferred)","o":"archivo"},"6257a4f1fd42":{"s":"brand-lock-extractor","a":"SKILL.md","l":56,"t":"**Never list** (what the brand avoids, inferred from consistency)","o":"archivo"},"89c96fc0932b":{"s":"brand-lock-extractor","a":"SKILL.md","l":57,"t":"**Aspect ratios**","o":"archivo"},"ddd43db015c9":{"s":"brand-lock-extractor","a":"SKILL.md","l":58,"t":"**Color grade direction** (one sentence)","o":"archivo"},"4075284680a4":{"s":"brand-lock-extractor","a":"SKILL.md","l":59,"t":"**Motion language** (one paragraph)","o":"archivo"},"086086b8d7f3":{"s":"brand-lock-extractor","a":"SKILL.md","l":60,"t":"**Voice rules** (copy-level constraints)","o":"archivo"},"c9c3a9312a4c":{"s":"brand-lock-extractor","a":"SKILL.md","l":69,"t":"**inferred**, reasoned from evidence but not stated (archetype from positioning, never-list from consistency). Reasonable to ship, worth noting.","o":"archivo"},"cd4c7a7c3646":{"s":"brand-lock-extractor","a":"SKILL.md","l":74,"t":"Use `templates/brand-lock.md.tpl`. Fill **every** required section, no placeholders left behind. Then append an `## Extraction notes` section that lists every `inferred` and `needs confirmation` value with its source and your reasoning. This section is the audit trail; it does not break validation (the validator checks the nine required sections are present, extra sections are fine).","o":"archivo"},"49fd83a4b509":{"s":"brand-lock-extractor","a":"SKILL.md","l":82,"t":"All nine required sections present: Identity, Palette, Typography, Mood adjectives, Never list, Aspect ratios, Color grade direction, Motion language, Voice rules.","o":"archivo"},"afdb75007c72":{"s":"brand-lock-extractor","a":"SKILL.md","l":94,"t":"Colors are sampled, never guessed. Read them from a brand book, from CSS, or by sampling pixels in a screenshot. If you genuinely cannot determine a color, fill your closest estimate and mark it `needs confirmation` in Extraction notes. \"Navy\" is not a palette entry. `#0F1F3A` is. A wrong hex stated confidently corrupts every downstream prompt.","o":"archivo"},"6eb4f8ba4dbc":{"s":"brand-lock-extractor","a":"SKILL.md","l":98,"t":"Identify fonts from the brand book, the site's CSS/font files, or clear visual match. If you cannot identify one, say so and flag it, do not name a plausible-sounding font you did not verify.","o":"archivo"},"03ede5f175d7":{"s":"brand-lock-extractor","a":"SKILL.md","l":106,"t":"It is also the hardest to extract, because brands document what they do, not what they avoid. Infer it from consistency: if every image avoids stock-photo gloss, that is a never. If copy never uses exclamation points, that is a never. Read `references/extraction-rubric.md` for the method. Do not ship an empty never-list.","o":"archivo"},"3d50d9dc8cee":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":40,"t":"never use stock photo aesthetic","o":"archivo"},"2b77fe0ab77d":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":41,"t":"never use AI uncanny faces","o":"archivo"},"528f3aca58d3":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":42,"t":"never use illustrations of people (real photography or abstract data viz only)","o":"archivo"},"34f304b45ae2":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":43,"t":"never use gradients (flat color only)","o":"archivo"},"70f50258fc9f":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":44,"t":"never use rounded corners larger than 8px","o":"archivo"},"a61acb519eac":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":45,"t":"never use exclamation points","o":"archivo"},"39f21f0bd621":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":46,"t":"never use vague claims (\"the best\", \"industry-leading\", \"cutting-edge\")","o":"archivo"},"bdeeca395947":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":47,"t":"never use AI/ML buzzwords without specifics","o":"archivo"},"21f3127a222e":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":48,"t":"never default to dark mode in primary marketing","o":"archivo"},"289646ec1639":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":49,"t":"never use animated icons or lottie illustrations","o":"archivo"},"5108ce119398":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":70,"t":"prefer specific numbers (\"40% reduction in 90 days\" not \"significant improvement\")","o":"archivo"},"98944bc5d597":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":71,"t":"prefer \"we\" and \"you\" over \"the company\" and \"the user\"","o":"archivo"},"5e5cfb4ec221":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":72,"t":"prefer present-tense","o":"archivo"},"cc15db8a3ce1":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":73,"t":"never start a sentence with \"Just\" or \"Simply\"","o":"archivo"},"f861a19be4ca":{"s":"brand-lock-extractor","a":"brand-packs/examples/saas-clean.md","l":74,"t":"avoid corporate hedge language (\"seek to\", \"look to\", \"aim to\")","o":"archivo"},"42b960dda0f5":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":36,"t":"never use stock smiles or posed lifestyle photography","o":"archivo"},"e320951a2f69":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":37,"t":"never use latte art as decoration","o":"archivo"},"deff6acf6ba6":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":38,"t":"never use the word \"artisanal\"","o":"archivo"},"995266039bd6":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":39,"t":"never use exclamation points","o":"archivo"},"9c0afb7d325a":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":40,"t":"never shoot glossy product-on-white; matte and natural-light only","o":"archivo"},"00c5d773e8d3":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":41,"t":"never lean on burnt, dark-roast cliche imagery","o":"archivo"},"a9ed618bb40b":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":49,"t":"> Matte, low contrast, natural window light, warm but restrained. Reminiscent of Kinfolk editorial photography. Never glossy commercial product lighting.","o":"archivo"},"2d715d9073e7":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":58,"t":"never the word \"artisanal\" (or \"curated\", \"elevated\")","o":"archivo"},"b5797c1841f0":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":59,"t":"short declarative sentences; cut adjectives before nouns that do not need them","o":"archivo"},"fb243b53c635":{"s":"brand-lock-extractor","a":"examples/brand-lock.md","l":60,"t":"prefer specific origin claims (farm, region, roast date) over vague quality words","o":"archivo"},"daf6cf4dbcb9":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":10,"t":"**inferred**, reasoned from evidence, not stated. Archetype from how the brand frames problems. Never-list from what the assets consistently avoid. Ship it, note the reasoning.","o":"archivo"},"d446778cd38a":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":17,"t":"**One-line description:** what the brand does and who for. This is the load-bearing sentence; a generator implicitly references it on every prompt. Pull it from the hero headline plus the about page. Prefer concrete over abstract: \"Managed bookkeeping for solo law firms\" beats \"Financial services for professionals.\" If the site only offers a vague tagline, sharpen it from the services/about copy a","o":"archivo"},"b4fbf43a4a92":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":19,"t":"**Archetype:** one word, Operator, Sage, Caregiver, Rebel, Creator, Jester, Ruler, Everyman, etc. Almost always `inferred`. Read it from how the brand frames the customer's problem:","o":"archivo"},"04363c882bf7":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":36,"t":"**Never guess a hex.** If you cannot read or sample one, estimate, label it `needs confirmation`, and tell the user exactly which role to verify. (See SKILL.md Rule 1.)","o":"archivo"},"a69c36bdec51":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":44,"t":"**Screenshots:** identify by eye only if confident; otherwise flag `needs confirmation`. Do not invent a plausible name (Rule 2).","o":"archivo"},"a1ad2f291171":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":50,"t":"3-5 adjectives, specific, contrast clauses preferred. Read tone from the body copy and the imagery together.","o":"archivo"},"775e72423ee9":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":56,"t":"The hardest and most valuable section. Brands document what they do; you infer what they avoid from consistency across the assets.","o":"archivo"},"3f18cfa9b5e8":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":59,"t":"Imagery: no stock-photo gloss? no people? no gradients? no clip-art icons? Each absence is a never.","o":"archivo"},"a86e2eb18131":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":60,"t":"Copy: no exclamation points? no hype words (\"revolutionary\", \"game-changing\")? no emojis? no questions in headlines? Each pattern is a never.","o":"archivo"},"451be222e3f4":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":61,"t":"Color/layout: never full-bleed photography? never more than one accent? never centered body text?","o":"archivo"},"f419380942de":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":63,"t":"Turn each observed constraint into a `never` line. Be specific: \"never use stock-photo aesthetic\" beats \"keep it authentic\". Aim for 5+. Never ship an empty list (Rule 4).","o":"archivo"},"dd519aa232b4":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":71,"t":"One sentence on how footage and generated images should be graded, with a reference point where possible (Kodak Portra 400, Apple keynote photography, A24 film grade). Infer from the existing photography's warmth, contrast, and saturation. If there is no photography to read, base it on the palette and flag `needs confirmation`.","o":"archivo"},"5a0a397f54c1":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":75,"t":"One paragraph: camera moves, cut style, text animation, pacing. Read from any existing video or motion on the site; if there is none, infer a conservative default consistent with the voice posture (a Quiet/Authoritative brand -> minimal, slow, deliberate) and flag `needs confirmation`. Keep it to one coherent motion language, do not blend \"minimal and deliberate\" with \"energetic whip pans\".","o":"archivo"},"f3fad8754516":{"s":"brand-lock-extractor","a":"references/extraction-rubric.md","l":79,"t":"Copy-level constraints for VO and on-screen text. Many overlap the never-list but are phrased as authoring rules: \"no em dashes\", \"sentences under 14 words\", \"prefer specific numbers over vague claims\", \"no exclamation points in headlines\". Extract from observed copy patterns. These become prompt constraints downstream, so make them enforceable, not aspirational.","o":"archivo"},"11ea00e863de":{"s":"image","a":"SKILL.md","l":18,"t":"The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone. The actual rules — what the models reward, what they punish, how to phrase a 5-slot template, when to add `quality: high`, when to use image grounding — live only in the reference files.","o":"regla"},"3f921ee68519":{"s":"image","a":"SKILL.md","l":22,"t":"**Motion, clips, montage** (Seedance, Kling, Veo, any image-to-video): use the sibling `video` skill. This skill's storyboard and keyframe outputs feed it.","o":"regla"},"0358891ec685":{"s":"image","a":"SKILL.md","l":40,"t":"**Nano Banana** → [nano-banana.md](references/nano-banana.md) Image grounding for real locations. Extreme aspect ratios (1:8, 8:1, 4:1). Thinking mode. JSON for 5+ elements. Up to 14 reference images. Why you must NOT write `50mm / f-stop / ISO` numbers.","o":"regla"},"c5eb6fd7f6f8":{"s":"image","a":"SKILL.md","l":43,"t":"**GPT Image 2** → [gpt-image.md](references/gpt-image.md) 5-slot template (Scene / Subject / Important Details / Use Case / Constraints). Anti-slop banned-words list. `quality: low / medium / high` as a deliberate fidelity lever. Size constraints (multiples of 16, max 3:1, up to 2560×1440). Two-column edit logic (Change / Preserve / Constraints). Up to 16 reference images with explicit roles.","o":"regla"},"485206c1697b":{"s":"image","a":"SKILL.md","l":50,"t":"Universal rules that apply to both models: start with a verb, positive framing, hex colors, quote text, edit don't re-roll, one change per iteration, reference images.","o":"regla"},"67a7dd9329dc":{"s":"image","a":"SKILL.md","l":100,"t":"For edits, also include an explicit preserve-list (mandatory for gpt-image-2, recommended for nano-banana):","o":"regla"},"890a0b28f120":{"s":"image","a":"SKILL.md","l":112,"t":"Prefer: ready-to-copy prompts, hex colors, concrete materials, named compositions, model-specific syntax (5-slot for GPT Image, natural prose for Nano Banana).","o":"regla"},"0e7900ffe2af":{"s":"image","a":"SKILL.md","l":114,"t":"Avoid: tag soup (\"cool, modern, 4k\"), vague praise (\"stunning, epic, masterpiece\" — actively hurts GPT Image 2), negative framing (\"no people, no cars\" — invert to positive), external comparisons (\"like Apple ad\" — describe the visual properties instead), numerical lens parameters in Nano Banana prompts (it ignores them).","o":"regla"},"09ec7d23fe12":{"s":"image","a":"references/creative-direction.md","l":34,"t":"Hasselblad — medium format, shallow DOF, fashion/portrait","o":"regla"},"b921448eda9a":{"s":"image","a":"references/creative-direction.md","l":47,"t":"\"Waist-up portrait\", \"full body\", \"over-the-shoulder\"","o":"regla"},"b8fa85d560e3":{"s":"image","a":"references/creative-direction.md","l":50,"t":"\"Shallow depth of field\" — blurred background","o":"regla"},"5ad1340da288":{"s":"image","a":"references/creative-direction.md","l":56,"t":"> descriptive terms. Prefer \"shallow depth of field\" over \"f/1.8\".","o":"regla"},"862a4c0ea3bc":{"s":"image","a":"references/creative-direction.md","l":78,"t":"Define physical makeup of subjects. Don't just say the thing — describe what it's MADE of.","o":"regla"},"d9bcca3cf113":{"s":"image","a":"references/golden-rules.md","l":12,"t":"Describe what you WANT, not what you don't want. The model understands presence better than absence.","o":"regla"},"1dd54b582a02":{"s":"image","a":"references/golden-rules.md","l":14,"t":"✅ \"empty street\" → ❌ \"street with no cars\"","o":"regla"},"7fff008d0b4a":{"s":"image","a":"references/golden-rules.md","l":15,"t":"✅ \"clean background\" → ❌ \"no clutter\"","o":"regla"},"f5bdd52eae18":{"s":"image","a":"references/golden-rules.md","l":16,"t":"✅ \"solo portrait\" → ❌ \"no other people\"","o":"regla"},"cc4167f1d432":{"s":"image","a":"references/golden-rules.md","l":27,"t":"❌ Bad: \"Cool car, neon, city, night, 8k\"","o":"regla"},"8d02f99b51e9":{"s":"image","a":"references/golden-rules.md","l":28,"t":"✅ Good: \"A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. Neon signs reflect off wet pavement and metallic chassis.\"","o":"regla"},"8901152207fe":{"s":"image","a":"references/golden-rules.md","l":42,"t":"\"for Brazilian gourmet cookbook\" → infers professional plating, shallow DOF","o":"regla"},"04c28ccbddf9":{"s":"image","a":"references/golden-rules.md","l":158,"t":"**Используй как HIGH-LEVEL steering** — якорь задаёт настроение и эстетику, а не заменяет весь промпт","o":"regla"},"3db8f42e251f":{"s":"image","a":"references/golden-rules.md","l":159,"t":"**Комбинируй с конкретными визуальными деталями** — якорь устанавливает мир, детали устанавливают специфику","o":"regla"},"16ec02525ce7":{"s":"image","a":"references/golden-rules.md","l":160,"t":"**Не стакай несколько genre anchors** — выбери один. \"Peter Lindbergh + Wes Anderson\" = каша","o":"regla"},"47652229b5ab":{"s":"image","a":"references/golden-rules.md","l":161,"t":"**Era/cultural anchors работают лучше с GPT Image 2** (world knowledge). С Nano Banana результат менее предсказуем — NB больше опирается на явные описания","o":"regla"},"1848820351ae":{"s":"image","a":"references/gpt-image.md","l":39,"t":"мудовый язык, в котором тонут функциональные требования | прямое заявление: «image must contain a transit kiosk»","o":"regla"},"20e10fa23ffc":{"s":"image","a":"references/gpt-image.md","l":74,"t":"Маленький/плотный/multi-font → `quality: high` обязательно.","o":"regla"},"26e0c5fc6ab4":{"s":"image","a":"references/gpt-image.md","l":96,"t":"**Object removal:** «Remove [X]. Do not change anything else. Use `input_fidelity: high` to maintain surrounding context» (только gpt-image-1.5/1, в gpt-image-2 high-fidelity по умолчанию).","o":"regla"},"822ae545689f":{"s":"image","a":"references/gpt-image.md","l":117,"t":"GPT Image 2 умеет домысливать контекст: «Bethel, NY, August 1969» → выведет Woodstock-эстетику. Используй: дай исторический/культурный анкер, не расписывай каждую деталь.","o":"regla"},"c10c7e21ff29":{"s":"image","a":"references/models.md","l":34,"t":"**Структурированный 5-slot промпт.** Чёткое разделение Scene/Subject/Details/Use case/Constraints даёт предсказуемость.","o":"regla"},"c842524ed79f":{"s":"image","a":"references/multi-panel.md","l":13,"t":"**When to use:** TVC or commercial shot breakdown — one image = 9 panels with scene titles and timestamps.","o":"regla"},"a127cca4810d":{"s":"image","a":"references/multi-panel.md","l":46,"t":"**Recommended size:** 1536x1024 (landscape)","o":"regla"},"e01904554508":{"s":"image","a":"references/multi-panel.md","l":50,"t":"Vague scene descriptions produce near-identical panels — each must have a distinct action, angle, or subject","o":"regla"},"3d26f71cccce":{"s":"image","a":"references/multi-panel.md","l":57,"t":"**When to use:** Same person shown from 4 angles/crops in one image for an editorial or casting look.","o":"regla"},"52c7e13d4185":{"s":"image","a":"references/multi-panel.md","l":83,"t":"**Recommended size:** 1024x1024 (square) or 1024x1536 (vertical for portrait emphasis)","o":"regla"},"796a278bda86":{"s":"image","a":"references/multi-panel.md","l":94,"t":"**When to use:** Hero shot + close-up + action for a campaign visual — horizontal or vertical triptych.","o":"regla"},"3a5fb89a88b1":{"s":"image","a":"references/multi-panel.md","l":122,"t":"**Recommended size:** 1536x1024 (horizontal triptych) or 1024x1536 (vertical triptych)","o":"regla"},"7421490e82fa":{"s":"image","a":"references/multi-panel.md","l":123,"t":"**Model:** GPT Image 2 `quality: medium` — if text overlay needed, use `quality: high`","o":"regla"},"576f2ecf7dd2":{"s":"image","a":"references/multi-panel.md","l":133,"t":"**When to use:** 12 panels telling a story or showing moods — no gaps between panels, seamless mosaic feel.","o":"regla"},"5eca40f8b2dc":{"s":"image","a":"references/multi-panel.md","l":162,"t":"**Recommended size:** 1536x1024 (landscape) — gives each cell enough resolution","o":"regla"},"e25ece2ca897":{"s":"image","a":"references/multi-panel.md","l":173,"t":"**When to use:** Fashion editorial or film-style sequence — multiple camera angles of the same scene in one image.","o":"regla"},"0237812f9545":{"s":"image","a":"references/multi-panel.md","l":205,"t":"**Recommended size:** 1536x1024 (landscape, 3x2 grid)","o":"regla"},"79ad480edaab":{"s":"image","a":"references/multi-panel.md","l":209,"t":"Top-down and low-angle in the same grid confuse the model if you don't anchor each frame to a grid position","o":"regla"},"921aa8a23672":{"s":"image","a":"references/multi-panel.md","l":210,"t":"Motion blur instruction must be specific (\"blur on hands and feet\") or the model applies blur everywhere","o":"regla"},"d9727650ad44":{"s":"image","a":"references/multi-panel.md","l":216,"t":"**When to use:** Product transformation, makeover, time comparison, renovation — two states side by side.","o":"regla"},"90d4b17bba47":{"s":"image","a":"references/multi-panel.md","l":243,"t":"**Recommended size:** 1536x1024 (landscape — gives each half a portrait-like proportion)","o":"regla"},"910dd4553129":{"s":"image","a":"references/multi-panel.md","l":244,"t":"**Model:** GPT Image 2 `quality: medium` — for text labels (\"BEFORE\" / \"AFTER\"), use `quality: high`","o":"regla"},"d8c349628ad4":{"s":"image","a":"references/multi-panel.md","l":248,"t":"Left/right assignment matters — always state which side is before and which is after","o":"regla"},"1e4fc13d2d29":{"s":"image","a":"references/multi-panel.md","l":254,"t":"**When to use:** Full narrative in one image — 3x4 grid (3 columns, 4 rows) for animation or video pre-production.","o":"regla"},"a0be4760c51c":{"s":"image","a":"references/multi-panel.md","l":294,"t":"**Recommended size:** 1024x1536 (portrait — 3 columns x 4 rows needs vertical space)","o":"regla"},"1062c830e923":{"s":"image","a":"references/multi-panel.md","l":295,"t":"**Model:** GPT Image 2 `quality: high` (text-heavy — scene numbers and captions must be readable)","o":"regla"},"eb71e5086205":{"s":"image","a":"references/multi-panel.md","l":300,"t":"Art style must be stated once and applied uniformly; mixing styles across panels produces visual chaos","o":"regla"},"bf6161618f55":{"s":"image","a":"references/multi-panel.md","l":308,"t":"**Subject consistency:** Always include an explicit instruction: \"same person / same character / same product across all panels.\" Repeat key identity markers (hair color, clothing, distinguishing features) rather than saying \"same as before.\"","o":"regla"},"f6982091002c":{"s":"image","a":"references/multi-panel.md","l":310,"t":"**Grid specification:** Always state the grid dimensions (e.g., \"3x2 grid, 3 columns 2 rows\"). Saying \"6 panels\" without layout instruction lets the model choose an unpredictable arrangement.","o":"regla"},"dabc108ffb16":{"s":"image","a":"references/nano-banana.md","l":24,"t":"Числовые параметры объектива: **50mm, 85mm, f/2.8, ISO 400** — NB игнорит. Используй описание: «shallow depth of field», «wide-angle distortion».","o":"regla"},"0456a3106233":{"s":"image","a":"references/nano-banana.md","l":55,"t":"Включён по умолчанию; у NBP отключить нельзя (модель рисует до 2 «thought images» в бэкенде, они не тарифицируются как картинки, но thinking-токены платные). У NB2 есть рычаг `thinking_level: minimal | high` (default `minimal`) — поднимай до `high` для:","o":"regla"},"a509f495c750":{"s":"image","a":"references/nano-banana.md","l":102,"t":"Interactions API держит контекст сессии — до 3 последовательных правок стэкаются без потери исходника. Правило «Edit, don't re-roll»: картинка верна на 80% — проси точечное изменение, а не новую генерацию.","o":"regla"},"82d4b1aa2d36":{"s":"image","a":"references/nano-banana.md","l":130,"t":"**Хэндофф в видеомодель — motion brief, не пересказ.** Движение камеры, движение субъекта, движение фона, длительность, framing lock, запрещённые изменения. Видео-промпт не переописывает то, что уже есть в кадре.","o":"regla"},"3de5ceee5c4e":{"s":"image","a":"references/nano-banana.md","l":137,"t":"Инфографика может содержать фактически неверные данные — цифры проверять всегда, grounding помогает, но не гарантирует.","o":"regla"},"f7781b9ee5c2":{"s":"image","a":"references/patterns/character-design.md","l":9,"t":"Use for game or animation pre-production — front, side, and back views of a character on a single white canvas with color callouts and height reference lines.","o":"regla"},"31a9f9f11aa7":{"s":"image","a":"references/patterns/character-design.md","l":23,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — height reference lines and color callout text require precise rendering","o":"regla"},"a8c47d2e697e":{"s":"image","a":"references/patterns/character-design.md","l":29,"t":"Use to produce a grid of 6–9 facial expressions for the same character — consistent head angle and art style, with emotion labels under each face.","o":"regla"},"b5749680d5b1":{"s":"image","a":"references/patterns/character-design.md","l":52,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text labels and consistent facial identity across 9 cells need precise control","o":"regla"},"e849bbafb08a":{"s":"image","a":"references/patterns/character-design.md","l":58,"t":"Use to show one character in multiple outfits or costumes — for fashion exploration, game skin concepts, or wardrobe design.","o":"regla"},"608c66f4b15a":{"s":"image","a":"references/patterns/character-design.md","l":80,"t":"**Recommended model:** GPT Image 2 (`quality: medium`) — character consistency is the priority; `high` only if outfit labels need fine legibility","o":"regla"},"639574d396e1":{"s":"image","a":"references/patterns/character-design.md","l":86,"t":"Use to transform a realistic character into a cute 3D collectible figurine — oversized head, compact body, multiple poses performing different activities.","o":"regla"},"be07ac1a9f48":{"s":"image","a":"references/patterns/character-design.md","l":108,"t":"**Recommended model:** GPT Image 2 (`quality: medium`) — smooth 3D vinyl surfaces render well at medium; `high` for marketing-ready close-ups","o":"regla"},"bc5138b583ba":{"s":"image","a":"references/patterns/character-design.md","l":120,"t":"Use for a full character reference card with portrait, full body, key items, and color palette — organized on a white background in a professional concept art layout.","o":"regla"},"ee853dd503fd":{"s":"image","a":"references/patterns/character-design.md","l":140,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout with hex codes, labels, and stat block requires precise rendering","o":"regla"},"c3d4dd460549":{"s":"image","a":"references/patterns/ecommerce.md","l":9,"t":"Use when you need a playful, attention-grabbing product visual where tiny workers interact with an oversized product — ideal for social media ads and launch campaigns.","o":"regla"},"19234ef99d6a":{"s":"image","a":"references/patterns/ecommerce.md","l":23,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — precise figurine detail and product label legibility","o":"regla"},"6a46a42327af":{"s":"image","a":"references/patterns/ecommerce.md","l":29,"t":"Use for premium beauty or fragrance product photography — dark, moody, tactile surfaces with atmospheric effects.","o":"regla"},"9a00a07b257d":{"s":"image","a":"references/patterns/ecommerce.md","l":43,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — surface materials and condensation detail","o":"regla"},"afdcc8f7bc89":{"s":"image","a":"references/patterns/ecommerce.md","l":51,"t":"Use to present a product commercial shot breakdown in a single image — pitch decks, creative presentations, client approvals.","o":"regla"},"4f23b10353c9":{"s":"image","a":"references/patterns/ecommerce.md","l":74,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — grid precision and text in panel 9","o":"regla"},"09817e522cce":{"s":"image","a":"references/patterns/ecommerce.md","l":80,"t":"Use for food, beverage, or supplement products where suspended ingredients communicate freshness, flavor, or composition.","o":"regla"},"d1f50fd09fa8":{"s":"image","a":"references/patterns/ecommerce.md","l":94,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — frozen detail precision and label legibility","o":"regla"},"6fc560223ecb":{"s":"image","a":"references/patterns/ecommerce.md","l":100,"t":"Use for disruptive, scroll-stopping social ads where the product packaging appears squeezed, inflated, or physically distorted as if made of soft rubber or vinyl.","o":"regla"},"bf758f621b50":{"s":"image","a":"references/patterns/ecommerce.md","l":114,"t":"**Recommended model:** NBP — complex spatial reasoning for believable physical distortion","o":"regla"},"e85f3a2c01a5":{"s":"image","a":"references/patterns/fashion-editorial.md","l":9,"t":"Use for fashion brand campaign hero images — one wide shot combining hero pose, close-up detail, and action/movement in a triptych layout.","o":"regla"},"e200695107d8":{"s":"image","a":"references/patterns/fashion-editorial.md","l":27,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency across panels and fabric texture detail","o":"regla"},"ce04a04c45aa":{"s":"image","a":"references/patterns/fashion-editorial.md","l":33,"t":"Use for model tests, casting cards, or editorial portfolio pages — four angles of the same person in a clean grid.","o":"regla"},"97ef5791058f":{"s":"image","a":"references/patterns/fashion-editorial.md","l":52,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency critical across four frames","o":"regla"},"9b5c3232e804":{"s":"image","a":"references/patterns/fashion-editorial.md","l":58,"t":"Use for streetwear drops, limited edition launches, or urban fashion brand campaigns where bold type dominates the composition.","o":"regla"},"348b0b1ed027":{"s":"image","a":"references/patterns/fashion-editorial.md","l":73,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text rendering and model-type depth interplay","o":"regla"},"1bf69ac8c5e3":{"s":"image","a":"references/patterns/fashion-editorial.md","l":79,"t":"Use for playful, nostalgic sportswear or athleisure campaigns with 70s-80s visual language.","o":"regla"},"eb03e137df6e":{"s":"image","a":"references/patterns/fashion-editorial.md","l":85,"t":"**Key levers:** `{model_description}`, `{outfit_description}` (high-waisted terry shorts in coral, cropped zip-up in cream, tube socks with racing stripes), `{location_description}` (Venice Beach boardwalk, empty suburban tennis court, coastal promenade), `{film_stock}` (Kodak Gold 200, Fuji Superia 400), `{palette_description}` (terracotta #CC5533, cream #FFF5E1, sky blue #87CEEB, mustard #D4A017","o":"regla"},"c5971eabbb4b":{"s":"image","a":"references/patterns/fashion-editorial.md","l":87,"t":"**Recommended model:** NB2 — natural movement, analog film grain, atmospheric grounding","o":"regla"},"6dfcd0919723":{"s":"image","a":"references/patterns/fashion-editorial.md","l":93,"t":"Use for forward-looking athletic or techwear editorials where abstract 3D forms create a surreal spatial environment around the model.","o":"regla"},"ce24e75d12a1":{"s":"image","a":"references/patterns/fashion-editorial.md","l":107,"t":"**Recommended model:** NBP — complex spatial reasoning for blob placement and reflections","o":"regla"},"46ce53039819":{"s":"image","a":"references/patterns/food-beverage.md","l":9,"t":"Use for premium chocolate or confectionery brand visuals — moody, textural, with controlled color and atmosphere. Adaptable across mood variants (dark indulgence, bright artisan, earthy origin-story).","o":"regla"},"a9c702b552f4":{"s":"image","a":"references/patterns/food-beverage.md","l":35,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — fracture detail and cocoa powder precision","o":"regla"},"20bb122f18fb":{"s":"image","a":"references/patterns/food-beverage.md","l":41,"t":"Use for premium beverage brand campaigns that combine lifestyle and product in a structured board layout — model shot + hero product + product lineup.","o":"regla"},"1ba1ff7577c8":{"s":"image","a":"references/patterns/food-beverage.md","l":59,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — label legibility and panel consistency","o":"regla"},"d4f497bb93d1":{"s":"image","a":"references/patterns/food-beverage.md","l":65,"t":"Use for hero food posters — restaurants, delivery apps, menu boards — where the food is the entire composition with fillable content slots.","o":"regla"},"4c926ca35845":{"s":"image","a":"references/patterns/food-beverage.md","l":96,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — steam, condensation, and ingredient texture fidelity","o":"regla"},"df532917ca8c":{"s":"image","a":"references/patterns/food-beverage.md","l":102,"t":"Use for educational food content, ingredient features, or artisanal brand storytelling — the food item rendered as a scientific illustration in the style of 19th-century naturalist prints.","o":"regla"},"a30c3b235f2e":{"s":"image","a":"references/patterns/food-beverage.md","l":110,"t":"**Recommended model:** NB2 — naturalist illustration style, grounding on botanical plate aesthetics","o":"regla"},"de44302b8294":{"s":"image","a":"references/patterns/food-beverage.md","l":116,"t":"Use for restaurant guides, food festival materials, travel content, or local cuisine features — a bird's-eye illustrated map showing food specialties across a city.","o":"regla"},"d62c529d34db":{"s":"image","a":"references/patterns/food-beverage.md","l":124,"t":"**Recommended model:** NB2 — image grounding for real city landmarks + illustration style","o":"regla"},"bdc7c98423b2":{"s":"image","a":"references/patterns/portrait-cinema.md","l":9,"t":"Use for warm, emotive street portraits with strong backlight flare — editorial, personal branding, album covers.","o":"regla"},"e80f84e82cd7":{"s":"image","a":"references/patterns/portrait-cinema.md","l":21,"t":"**Key levers:** `{street_description}` (narrow European alley with stone walls, wide boulevard with linden trees, industrial backstreet with brick), `{person_description}`, `{expression}` (quiet confidence, mid-smile with closed lips, contemplative gaze), `{bounce_surface}` (cream-painted wall, parked white van, sand-colored buildings), `{clothing_detail}` (linen shirt collar, leather jacket shoul","o":"regla"},"2260c15e96b4":{"s":"image","a":"references/patterns/portrait-cinema.md","l":23,"t":"**Recommended model:** GPT Image 2 — backlight exposure control and skin rendering","o":"regla"},"36bbbe701ad0":{"s":"image","a":"references/patterns/portrait-cinema.md","l":29,"t":"Use for urban night portraits with mixed artificial lighting — fluorescent overhead + colored neon signage creating a chromatic push-pull on the subject's face.","o":"regla"},"5b0ec72c5a49":{"s":"image","a":"references/patterns/portrait-cinema.md","l":43,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — precise dual-light color rendering on skin","o":"regla"},"9a20603f7d87":{"s":"image","a":"references/patterns/portrait-cinema.md","l":49,"t":"Use for edgy, tech-forward portraits — artist profiles, electronic music press, tech brand campaigns. High contrast black-and-white with selective red digital artifacts.","o":"regla"},"29940f3cd9ae":{"s":"image","a":"references/patterns/portrait-cinema.md","l":61,"t":"**Key levers:** `{person_description}`, `{direction}` (left, right), `{hair_detail}` (tight buzz cut showing skull contour, shoulder-length hair with flyaway strands catching backlight, pulled-back bun), `{glitch_positions}` (across the eye, across the mouth, across the forehead — specify 2-3 positions), `{accent_color}` (#FF0000 red, #00FF41 terminal green, #FF00FF magenta), `{max_glitch_lines}` ","o":"regla"},"f708635c6957":{"s":"image","a":"references/patterns/portrait-cinema.md","l":63,"t":"**Recommended model:** GPT Image 2 — high-contrast mono rendering and controlled glitch placement","o":"regla"},"b8ecc6c820c5":{"s":"image","a":"references/patterns/portrait-cinema.md","l":69,"t":"Use for moody, atmospheric portraits with overexposed analog film qualities — muted colors, lifted shadows, and a feeling of faded memory. Ideal for editorial, zine, or personal project work.","o":"regla"},"25c7ab649b75":{"s":"image","a":"references/patterns/portrait-cinema.md","l":77,"t":"**Recommended model:** NB2 — analog film grain emulation and atmospheric mood","o":"regla"},"b6f22ea21acd":{"s":"image","a":"references/patterns/portrait-cinema.md","l":83,"t":"Use for beauty campaigns, conceptual art, or album visuals — a portrait where the subject floats in clear water surrounded by translucent aquatic elements.","o":"regla"},"be5a2e46231a":{"s":"image","a":"references/patterns/portrait-cinema.md","l":97,"t":"**Recommended model:** NBP — complex physics (floating hair, fabric, fish transparency, caustic light)","o":"regla"},"5c934f24e5bd":{"s":"image","a":"references/patterns/poster-illustration.md","l":9,"t":"Use for urban development campaigns, anniversary materials, cultural exhibitions, or editorial features — a single city view divided down the middle, one half historical and one half modern.","o":"regla"},"535d74d81a91":{"s":"image","a":"references/patterns/poster-illustration.md","l":28,"t":"**Recommended model:** NBP — spatial reasoning for architectural morphing and perspective consistency","o":"regla"},"44c898225d80":{"s":"image","a":"references/patterns/poster-illustration.md","l":40,"t":"Use for sport and fitness brand campaigns — a dynamic 3-panel collage combining action, detail, and atmosphere around a boxing/combat sport theme.","o":"regla"},"4c1d2cabad77":{"s":"image","a":"references/patterns/poster-illustration.md","l":59,"t":"**Recommended model:** GPT Image 2 — identity consistency across panels and sweat/texture detail","o":"regla"},"7b6acbb90a0a":{"s":"image","a":"references/patterns/poster-illustration.md","l":65,"t":"Use for tech product launch visuals — clean, color-dominant hero shots where a smartphone (or similar device) floats against a monochromatic gradient with soft 3D accent elements.","o":"regla"},"57fca5220269":{"s":"image","a":"references/patterns/poster-illustration.md","l":82,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text rendering, screen content legibility, device accuracy","o":"regla"},"c755ff2903b8":{"s":"image","a":"references/patterns/poster-illustration.md","l":88,"t":"Use for fashion drops, event announcements, or editorial magazine covers where bold typography and a street fashion figure share equal visual weight on a saturated color field.","o":"regla"},"cd1fa75558c5":{"s":"image","a":"references/patterns/poster-illustration.md","l":103,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — typography rendering and figure-type layering","o":"regla"},"803245de38c4":{"s":"image","a":"references/patterns/poster-illustration.md","l":109,"t":"Use for decorative prints, packaging illustration, wallpaper design, or editorial art — a symmetrical composition combining a peacock with botanical elements in a vintage printmaking style.","o":"regla"},"b6a40416c21b":{"s":"image","a":"references/patterns/poster-illustration.md","l":117,"t":"**Recommended model:** NB2 — image grounding for accurate peacock anatomy and botanical species","o":"regla"},"7a21ad4f3c7d":{"s":"image","a":"references/patterns/ui-social.md","l":9,"t":"Use for vertical product or brand ads targeting Instagram Stories — hero product, bold headline, and swipe-up CTA zone at the bottom.","o":"regla"},"be784fefef07":{"s":"image","a":"references/patterns/ui-social.md","l":23,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — headline text legibility and glassmorphism transparency effects need precision","o":"regla"},"f5f07232cc75":{"s":"image","a":"references/patterns/ui-social.md","l":29,"t":"Use for square-format posts on Instagram or Facebook — quote cards, feature announcements, or product highlights with centered layout.","o":"regla"},"ac9f15b7d326":{"s":"image","a":"references/patterns/ui-social.md","l":49,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout; legibility at small sizes is critical","o":"regla"},"76fa850073b5":{"s":"image","a":"references/patterns/ui-social.md","l":55,"t":"Use to create a polished App Store or Google Play listing screenshot — device frame with app UI inside, feature headline, and clean gradient background.","o":"regla"},"d4e8f76bb757":{"s":"image","a":"references/patterns/ui-social.md","l":75,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — device bezel precision, small UI text, and headline legibility all demand high quality","o":"regla"},"b1a90c3a0a1d":{"s":"image","a":"references/patterns/ui-social.md","l":81,"t":"Use for realistic analytics dashboard mockups — dark or light theme with data visualizations, KPI cards, and sidebar navigation.","o":"regla"},"8f24d3e22d84":{"s":"image","a":"references/patterns/ui-social.md","l":104,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — dense text (labels, numbers, navigation), precise chart rendering, and small UI elements require high fidelity","o":"regla"},"6b8e9a41cbf9":{"s":"image","a":"references/patterns/ui-social.md","l":116,"t":"Use to create a visual color analysis graphic from a portrait — seasonal palette classification, clothing color comparisons, and accessory recommendations in an organized layout.","o":"regla"},"5bb61a5742b2":{"s":"image","a":"references/patterns/ui-social.md","l":133,"t":"**Key levers:** `{subject_description}` (age, skin tone, hair color, eye color — needed for accurate seasonal analysis), `{season_type}` (Warm Spring, Cool Summer, Warm Autumn, Cool Winter — or sub-seasons like Soft Autumn, Bright Winter), `{palette_colors}` (12 hex values matching the season, e.g. Warm Autumn: rust #B7410E, olive #708238, mustard #E1AD01, burgundy #722F37...), `{num_palette}` (12","o":"regla"},"e3ff88ae7b6f":{"s":"image","a":"references/patterns/ui-social.md","l":135,"t":"**Recommended model:** GPT Image 2 (`quality: high`) — color accuracy of palette swatches is critical, plus small text labels throughout","o":"regla"},"c8d4fff1dabe":{"s":"image","a":"references/prompt-framework.md","l":39,"t":"**Палитра** - цвета (лучше hex)","o":"regla"},"58817d380494":{"s":"image","a":"references/prompt-framework.md","l":43,"t":"> - **Nano Banana** — игнорит числа, пиши описательно («shallow depth of field»)","o":"regla"},"85e2a5dc4aa8":{"s":"image","a":"references/prompt-framework.md","l":88,"t":"> Формулируй позитивно! NBP лучше понимает \"clean background\" чем \"no clutter\"","o":"regla"},"5856058c8a75":{"s":"image","a":"references/prompt-framework.md","l":159,"t":"Переменные записываются как `{name, default=\"value\"}`. Если значение не указано — используется дефолт. Если дефолта нет — переменная обязательна.","o":"regla"},"84828d3c69a2":{"s":"image","a":"references/prompt-framework.md","l":173,"t":"**Заменяй только то, что меняется** — остальное берётся из дефолтов","o":"regla"},"a90636943228":{"s":"image","a":"references/prompt-framework.md","l":174,"t":"**Структура стабильна** — порядок слотов одинаковый для всех вариаций, модель получает консистентный формат","o":"regla"},"8005da81a345":{"s":"image","a":"references/prompt-framework.md","l":175,"t":"**Batch-генерация** — идеально для серий: продуктовые ракурсы, позы персонажа, локации в одном стиле","o":"regla"},"42a42a73fa09":{"s":"image","a":"references/prompt-framework.md","l":212,"t":"**Surface wear & aging** — \"chipped paint on window frame, hairline scratches on metal surface, green patina on copper fittings, oxidation marks on iron hinges\"","o":"regla"},"4bc498edcc17":{"s":"image","a":"references/prompt-framework.md","l":213,"t":"**Micro-textures** — \"visible pores on skin, individual hair strands catching backlight, fabric weave pattern on linen shirt, grain of weathered wood\"","o":"regla"},"bc6d5c9aff5f":{"s":"image","a":"references/prompt-framework.md","l":214,"t":"**Atmospheric particles** — \"dust motes suspended in light beam, steam wisps rising from coffee cup, pollen floating in golden hour air, fine rain droplets on glass surface\"","o":"regla"},"318b118d917d":{"s":"image","a":"references/prompt-framework.md","l":215,"t":"**Specular behavior** — \"specular highlights on metal edges of watch, caustic reflections dancing inside glass bottle, wet surface sheen on cobblestones after rain\"","o":"regla"},"92eeb4747a7e":{"s":"image","a":"references/prompt-framework.md","l":216,"t":"**Fabric & material drape** — \"natural fabric folds at elbow crease, gravity pull on loose linen garment, weight distribution visible in heavy wool coat\"","o":"regla"},"51b0bfedb210":{"s":"image","a":"references/prompt-framework.md","l":217,"t":"**Contact shadows** — \"soft contact shadow where cup meets saucer, ambient occlusion in crevices of stone wall, dark line where book spine meets table\"","o":"regla"},"329aa0a4fa84":{"s":"image","a":"references/prompt-framework.md","l":218,"t":"**Environmental reflections** — \"building reflections in wet pavement, sky gradient in chrome bumper surface, warm neon glow on skin from nearby sign\"","o":"regla"},"11ec80431f42":{"s":"image","a":"references/prompt-framework.md","l":219,"t":"**Motion cues** — \"slight motion blur on trailing hair strand, frozen splash droplet from espresso pour, wind-displaced fabric edge of scarf\"","o":"regla"},"796d88912233":{"s":"image","a":"references/slides.md","l":29,"t":"Избегай pure white #fff на чёрном - используй #f5f5f5","o":"regla"},"2f0619f0ec28":{"s":"image","a":"references/slides.md","l":32,"t":"Контент должен дышать","o":"regla"},"c9068adfe734":{"s":"image","a":"references/storyboards.md","l":78,"t":"\"Identity must stay consistent throughout\"","o":"regla"},"3244bb3011e7":{"s":"image","a":"references/storyboards.md","l":81,"t":"\"Expressions and poses should vary\"","o":"regla"},"8e32b234137b":{"s":"image","a":"references/text-rendering.md","l":126,"t":"Ask the model to write/refine the text content","o":"regla"},"7447d548b9f0":{"s":"image","a":"references/text-rendering.md","l":127,"t":"Then ask for an image with that exact text","o":"regla"},"0db1539c575d":{"s":"image","a":"references/text-rendering.md","l":167,"t":"Upload with prompt: \"Use layout from attached image\"","o":"regla"},"7e22722f52fa":{"s":"image","a":"references/vision-decomposer.md","l":3,"t":"Use this reference when the user asks to analyze an image and convert it to a generation prompt: **style transfer**, **mood reference**, **\"сделай промпт по этой картинке\"**, **\"перенеси стиль/образ\"**, **\"проанализируй кадр\"**, **\"image to prompt\"**, **\"reverse-engineer this look\"**.","o":"regla"},"442a75c51f58":{"s":"image","a":"references/vision-decomposer.md","l":7,"t":"The process has two strict steps. Do not skip Step 1. Do not freestyle Step 2.","o":"regla"},"a712726b25c7":{"s":"image","a":"references/vision-decomposer.md","l":36,"t":"**Figure & ground (Arnheim):** degree of subject isolation, overlapping of forms, mass relationships. Use of reflections (mirrors, windows) to expand context.","o":"regla"},"04cb7f3e5408":{"s":"image","a":"references/vision-decomposer.md","l":44,"t":"**Broken light & reflexes (Zheleznyakov):** use of shadow masks (gobos), light through blinds / foliage, color reflexes from neighboring objects onto skin / clothing.","o":"regla"},"7d2338d1b298":{"s":"image","a":"references/vision-decomposer.md","l":49,"t":"**Camera (angles & viewpoint):** Angle (High angle, Low angle, Eye-level, Dutch tilt). Objective camera, Subjective, POV, Over-the-shoulder (OTS). Movement imitation (Push-in, Tracking shot).","o":"regla"},"3d2a2115477d":{"s":"image","a":"references/vision-decomposer.md","l":62,"t":"Describe **strictly what you see**. Do not invent new objects.","o":"regla"},"7cf887e9d7c2":{"s":"image","a":"references/vision-decomposer.md","l":63,"t":"**No filler.** Never write \"The image shows...\", \"A picture of...\", \"I can see...\".","o":"regla"},"526a0bad384e":{"s":"image","a":"references/vision-decomposer.md","l":109,"t":"Do NOT load this for: pure generation requests where no reference image is given. For those, use the standard model files.","o":"regla"},"a4a34906e54d":{"s":"produccion-visual-sw30","a":"SKILL.md","l":20,"t":"Si la respuesta es NO: no se entrega. Se leen los archivos faltantes, se aplica lo que falte y se vuelve a preguntar. Se repite cuantas veces sea necesario.","o":"regla"},"ab216a6c933f":{"s":"produccion-visual-sw30","a":"SKILL.md","l":22,"t":"Prohibido responder SÍ para complacer. Un SÍ falso es una mentira y cuesta más que el NO.","o":"regla"},"5c17fa63163e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":23,"t":"Prohibido responder SÍ con matices, condiciones o notas al pie disfrazadas de honestidad.","o":"regla"},"241ea833ab9d":{"s":"produccion-visual-sw30","a":"SKILL.md","l":24,"t":"\"Exhaustiva\" significa: leídos COMPLETOS todos los archivos del skill aplicables al caso (SKILL.md indica el orden obligatorio), no fragmentos ni grep.","o":"regla"},"26da6aecb6fb":{"s":"produccion-visual-sw30","a":"SKILL.md","l":33,"t":"Orden de dirección: nunca se escribe un prompt de corrido ni se parchea texto. Tres pasos, en este orden:","o":"regla"},"87eadbf796d1":{"s":"produccion-visual-sw30","a":"SKILL.md","l":35,"t":"**CATALOGAR** — identificar el TIPO de prompt y leer qué reglas aplican a ese tipo en la matriz (production-package/RULES_MATRIX.md: 26 reglas × 5 tipos, con fuente y bloque de cada una). Tipos: T1 maestro rostro · T2 maestro cuerpo · T3 cuadro 1 persona · T4 cuadro 2 personas · T5 edición quirúrgica.","o":"regla"},"d48021c639e6":{"s":"produccion-visual-sw30","a":"SKILL.md","l":39,"t":"**DEFINIR SECCIONES** — antes de redactar, listar las secciones que ese tipo exige. Cada regla vive en UN bloque nombrado y compartido (optics_*, skin_*, anatomy, idlock, text_lock, contact_*, unique, colour, hair, fabric, clean_*, autocontain_*), nunca en texto suelto dentro del brief.","o":"regla"},"4a2eeac6c89d":{"s":"produccion-visual-sw30","a":"SKILL.md","l":42,"t":"**ENSAMBLAR POR SECCIÓN** — el prompt se construye llamando P(scene, subject, [details], mood, usecase, [constraints]) para creación o E(change, preserve, [constraints]) para edición, pasando bloques. Salida en el formato de SKILL.md del skill image: cabecera Model/Quality/Size + References","o":"regla"},"6658223ecd3e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":52,"t":"`rule_registry.py` — relee los 23 archivos del skill image y EXTRAE mecánicamente cada enunciado normativo (209). Si el skill cambia, el registro cambia solo. Mi interpretación deja de ser etapa.","o":"regla"},"3348210ad98e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":54,"t":"`rule_ledger.py` — obliga a que CADA regla aplicable tenga disposición explícita: CHECK (existe verificación) o NA (con razón escrita y auditable). Sale con código 1 si queda una sola PENDING.","o":"regla"},"b37aa531231e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":56,"t":"`audit_gi2.py` — verifica los prompts columna por columna.","o":"regla"},"5a5348b20c81":{"s":"produccion-visual-sw30","a":"SKILL.md","l":73,"t":"usecase | `usecase_doc` | fotografía documental Kodak Tri-X de reportaje. Kodak Portra suaviza la piel por diseño y contradice los poros — PROHIBIDO en rostros","o":"regla"},"7ba769efe2d7":{"s":"produccion-visual-sw30","a":"SKILL.md","l":83,"t":"`production-package/template_engine.py` es OBLIGATORIO para construir cualquier prompt visual.","o":"regla"},"c0bc3ce2b122":{"s":"produccion-visual-sw30","a":"SKILL.md","l":84,"t":"Un prompt no se escribe: se INSTANCIA con `build(tipo, ..., notes=...)`. El motor lanza","o":"regla"},"ca17e7d8bf24":{"s":"produccion-visual-sw30","a":"SKILL.md","l":97,"t":"**PROHIBIDO editar el texto de un brief individual.** Eso es parchar: arregla una cosa y rompe otra, y es la causa raíz de los ciclos de tres reescrituras.","o":"regla"},"5cf46d07bcac":{"s":"produccion-visual-sw30","a":"SKILL.md","l":116,"t":"Un solo trabajo por generación. Con dos personajes: un sujeto por generación, o técnica de colocación probada; nunca \"a ver si sale\".","o":"regla"},"613774db48c2":{"s":"produccion-visual-sw30","a":"SKILL.md","l":118,"t":"Posición SIEMPRE por ancla legible de la propia imagen (letterforms del mundo: \"his back level with the letter L of WORLD\"). Prohibido \"left half\", \"centre\", \"just left of X\".","o":"regla"},"762ce60bec5e":{"s":"produccion-visual-sw30","a":"SKILL.md","l":120,"t":"El editor no tiene memoria: solo verbos operativos (Move/Replace/Add/Remove/Swap), cero narrativa (\"has become\", \"again\").","o":"regla"},"cb50b580f819":{"s":"produccion-visual-sw30","a":"SKILL.md","l":122,"t":"Autocontención: toda comparación (\"same X\") exige ambos referentes adjuntos en ESE prompt.","o":"regla"},"ff510d7ca127":{"s":"produccion-visual-sw30","a":"SKILL.md","l":123,"t":"Herencia mínima: \"same face and clothes\" + solo los deltas. Cero re-descripción de lo que la referencia ya muestra.","o":"regla"},"4fcb4afa54c3":{"s":"produccion-visual-sw30","a":"SKILL.md","l":125,"t":"Swap de identidad = última operación, sola: \"Replace X with Y — same position, same pose, same scale\".","o":"regla"},"4d4ea0758b3f":{"s":"produccion-visual-sw30","a":"SKILL.md","l":127,"t":"Mundos por dos pasos: placa vacía primero; insert con \"use only the person from image N, ignore its setting\" + \"keep the world of image 1 untouched\".","o":"regla"},"b6df20344be1":{"s":"produccion-visual-sw30","a":"SKILL.md","l":129,"t":"Stills en instante congelado (\"frozen mid-stride\"); nada de movimiento en imagen fija.","o":"regla"},"7dc14c265b1a":{"s":"produccion-visual-sw30","a":"SKILL.md","l":130,"t":"Contactos entre personas: \"a natural high five\" — la anatomía la fija el keyframe aprobado, nunca la asignación de manos por texto.","o":"regla"},"204113433c22":{"s":"produccion-visual-sw30","a":"SKILL.md","l":132,"t":"Logos solo heredados de asset aprobado o descripción canónica del brand-lock; los cuerpos nunca tapan logo ni lettering en frames congelados.","o":"regla"},"0895bf9c3c72":{"s":"produccion-visual-sw30","a":"SKILL.md","l":134,"t":"Lo aprobado se canoniza con hash y se EDITA desde ahí; lo caro nunca se regenera.","o":"regla"},"3f9822c97a3a":{"s":"produccion-visual-sw30","a":"SKILL.md","l":135,"t":"\"Edit, don't re-roll\": resultado ≥80% correcto → cambio puntual (hasta 3 ediciones apiladas), nunca re-tirar.","o":"regla"},"f9fee85351f3":{"s":"produccion-visual-sw30","a":"SKILL.md","l":137,"t":"Máximo 2 intentos por método. A la 2ª falla: cambio de método con causa declarada, o alto y consulta. Nunca tercera vuelta de lo mismo.","o":"regla"},"0aad9d5a3dfa":{"s":"produccion-visual-sw30","a":"SKILL.md","l":139,"t":"Validadores del paquete y techos de palabras en verde antes de entregar; inspección visual propia (zooms 100% de rostros y manos) antes de presentar. Si algo falla: no se entrega, se repite — y se dice qué falló en una línea.","o":"regla"},"aeb5f5e9292c":{"s":"produccion-visual-sw30","a":"SKILL.md","l":142,"t":"shots.json es la fuente de verdad: todo cambio entra ahí primero y se propaga.","o":"regla"},"2dddf6f48ba3":{"s":"produccion-visual-sw30","a":"SKILL.md","l":143,"t":"Clips: solo Preserve-cues, roles de start/tail (\"The tail image defines X — inherit exactly\"), movimiento puro, imagen final nombrada; negativos sin \"no X\", ≤8 ítems.","o":"regla"},"44283e478fd4":{"s":"produccion-visual-sw30","a":"SKILL.md","l":145,"t":"Entregas en unidades chicas con OK de dirección; se entrega el delta, no el paquete. Una regla nueva de dirección se aplica a TODOS los prompts, no a la mitad.","o":"regla"},"84846df151fa":{"s":"produccion-visual-sw30","a":"SKILL.md","l":147,"t":"Respuestas: el dato o entregable en la primera línea. Cero adulación y cero evaluación de las acciones de Eric salvo que la pida. Error = una línea de corrección, sin disculpas.","o":"regla"},"6da8440e93ad":{"s":"produccion-visual-sw30","a":"SKILL.md","l":149,"t":"Prohibido afirmar capacidades, límites o hechos de plataforma sin verificarlos en este turno (leer la fuente o buscar); lo no verificado se etiqueta como inferencia.","o":"regla"},"fb3896038afa":{"s":"screenwriter","a":"SKILL.md","l":77,"t":"Always use ALL CAPS for sluglines","o":"archivo"},"4d9355018ad2":{"s":"screenwriter","a":"SKILL.md","l":78,"t":"Use hyphens to separate elements","o":"archivo"},"57e9c487ac74":{"s":"screenwriter","a":"SKILL.md","l":80,"t":"Time should suggest lighting/mood","o":"archivo"},"fa0199539554":{"s":"screenwriter","a":"SKILL.md","l":87,"t":"**Show, Don't Tell:** Write what's visible, not internal thoughts","o":"archivo"},"e10b5f7be709":{"s":"screenwriter","a":"SKILL.md","l":88,"t":"**Sensory Details:** Include lighting, atmosphere, textures, colors","o":"archivo"},"45f2e43f67e0":{"s":"screenwriter","a":"SKILL.md","l":89,"t":"**Present Tense:** Always write in present tense","o":"archivo"},"a93dbeef8737":{"s":"screenwriter","a":"SKILL.md","l":90,"t":"**Active Voice:** Use strong, active verbs","o":"archivo"},"10e5da2fcf9a":{"s":"screenwriter","a":"SKILL.md","l":91,"t":"**Specific Props:** Name objects that matter visually","o":"archivo"},"59d398f4c454":{"s":"screenwriter","a":"SKILL.md","l":92,"t":"**Atmosphere:** Set mood through environmental details","o":"archivo"},"671c49de0056":{"s":"screenwriter","a":"SKILL.md","l":128,"t":"Avoid excessive detail—just enough for visual consistency","o":"archivo"},"27e302d3a37e":{"s":"screenwriter","a":"SKILL.md","l":140,"t":"Use dialogue ONLY when essential to story","o":"archivo"},"5645bf344589":{"s":"screenwriter","a":"SKILL.md","l":157,"t":"`CUT TO:` - Scene change (usually implied, use for emphasis)","o":"archivo"},"68d5f2185557":{"s":"screenwriter","a":"SKILL.md","l":162,"t":"**Modern Best Practice:** Most transitions are IMPLIED. Use sparingly, only for specific narrative effect.","o":"archivo"},"c775d8acd13e":{"s":"screenwriter","a":"SKILL.md","l":235,"t":"**Emotional beats:** Each scene should shift emotional state","o":"archivo"},"8cc0ef448f33":{"s":"screenwriter","a":"SKILL.md","l":244,"t":"**Consistent naming:** Use same character names throughout","o":"archivo"},"bff5030b3380":{"s":"screenwriter","a":"SKILL.md","l":253,"t":"**Lean prose:** Each word should serve the image","o":"archivo"},"35abb8abc912":{"s":"screenwriter","a":"SKILL.md","l":256,"t":"❌ **Vague descriptions:** \"A person walks\" → ✅ \"A weathered woman in her 50s trudges through snow\"","o":"archivo"},"df9b899dbc91":{"s":"screenwriter","a":"SKILL.md","l":257,"t":"❌ **Telling emotions:** \"She feels sad\" → ✅ \"Tears streak her dusty cheeks\"","o":"archivo"},"de28e225dfa5":{"s":"screenwriter","a":"SKILL.md","l":258,"t":"❌ **Camera directions:** \"CLOSE UP ON\" → ✅ \"The crack in the glass spreads\"","o":"archivo"},"aa1edc03619b":{"s":"screenwriter","a":"SKILL.md","l":259,"t":"❌ **Over-dialogue:** Short films need visual storytelling","o":"archivo"},"0cf150e839a8":{"s":"screenwriter","a":"SKILL.md","l":260,"t":"❌ **Inconsistent character names:** Stick to ONE name per character","o":"archivo"},"b6cf18f1ea26":{"s":"screenwriter","a":"references/advanced-techniques.md","l":16,"t":"While avoiding technical camera directions in action lines, you can *suggest* camera movement through visual description and scene structure.","o":"archivo"},"f1221744d7a1":{"s":"screenwriter","a":"references/advanced-techniques.md","l":85,"t":"Each character should have distinct speech patterns:","o":"archivo"},"42187af933ee":{"s":"screenwriter","a":"references/advanced-techniques.md","l":127,"t":"Each scene should raise stakes or tension incrementally:","o":"archivo"},"38b4028efe2f":{"s":"screenwriter","a":"references/advanced-techniques.md","l":172,"t":"Use color to track emotional/narrative arc:","o":"archivo"},"5ea772208440":{"s":"screenwriter","a":"references/advanced-techniques.md","l":184,"t":"Every scene must serve multiple purposes:","o":"archivo"},"3697579b1689":{"s":"screenwriter","a":"references/advanced-techniques.md","l":202,"t":"First 10-15 seconds must grip audience:","o":"archivo"},"dcba7967bb86":{"s":"screenwriter","a":"references/pipeline-integration.md","l":20,"t":"Every scene MUST include all required metadata fields for reliable pipeline processing:","o":"archivo"},"34d356cca129":{"s":"screenwriter","a":"references/pipeline-integration.md","l":48,"t":"Use 1-3 adjectives that guide visual tone:","o":"archivo"},"06f7cfabe30d":{"s":"screenwriter","a":"references/pipeline-integration.md","l":51,"t":"Avoid: \"the character feels anxious\" (this describes internal state, not mood)","o":"archivo"},"f02d8dcae6c2":{"s":"screenwriter","a":"references/pipeline-integration.md","l":68,"t":"The `key_visuals` array should contain discrete, image-generation-friendly descriptions:","o":"archivo"},"9a04fd13f520":{"s":"screenwriter","a":"references/pipeline-integration.md","l":137,"t":"After first appearance, use consistent identifiers:","o":"archivo"},"d58376dbc7f5":{"s":"screenwriter","a":"references/pipeline-integration.md","l":140,"t":"Use character name only: \"Maya checks her phone\"","o":"archivo"},"33379bbc4b87":{"s":"screenwriter","a":"references/pipeline-integration.md","l":175,"t":"Option B: Use fractional numbering (1, 2, 2A, 3...)","o":"archivo"},"8a33756b8cb8":{"s":"screenwriter","a":"references/pipeline-integration.md","l":177,"t":"For pipeline simplicity, prefer Option A (complete renumbering).","o":"archivo"},"3172bdb34a71":{"s":"screenwriter","a":"references/pipeline-integration.md","l":222,"t":"Ensure valid XML structure:","o":"archivo"},"47f320764950":{"s":"screenwriter","a":"references/pipeline-integration.md","l":266,"t":"[ ] No technical camera directions (use visual descriptions instead)","o":"archivo"},"364c86aacbd6":{"s":"storyboard-architect","a":"SKILL.md","l":22,"t":"If the user only wants prompts for an image generator (no narrative structure), use `visual-prompt-forge` directly instead.","o":"archivo"},"7696a03e6c31":{"s":"storyboard-architect","a":"SKILL.md","l":40,"t":"Write it once, at the end of the run, and never edit it.","o":"archivo"},"8f9cad0e2224":{"s":"storyboard-architect","a":"SKILL.md","l":42,"t":"If the user asks for image prompts or HTML preview, hand off to `visual-prompt-forge` or `storyboard-html-preview`, those skills consume `shots.json` directly. Don't try to do their job here.","o":"archivo"},"8d21f65f4329":{"s":"storyboard-architect","a":"SKILL.md","l":54,"t":"Brand-lock file path | No | Use `brand-packs/_template.md` and flag the gap","o":"auditoria"},"0a6768420027":{"s":"storyboard-architect","a":"SKILL.md","l":60,"t":"Follow this sequence. Don't skip steps even if the brief seems simple.","o":"archivo"},"c7861b2bb543":{"s":"storyboard-architect","a":"SKILL.md","l":69,"t":"\"Never\" list (what this brand will never do visually)","o":"auditoria"},"8b27a216f395":{"s":"storyboard-architect","a":"SKILL.md","l":72,"t":"Aspect-ratio preferences","o":"auditoria"},"5b7b1c8fb6ae":{"s":"storyboard-architect","a":"SKILL.md","l":74,"t":"If no brand-lock is provided, copy `brand-packs/_template.md` into the output as `brand-lock.snapshot.md` with a note: `# UNCONFIGURED, using template defaults. Recommend providing a real brand-lock for production work.`","o":"auditoria"},"0b4182e7f0fc":{"s":"storyboard-architect","a":"SKILL.md","l":96,"t":"Don't fight the framework. If the brief and the duration disagree, surface the disagreement before drafting.","o":"archivo"},"37204f4e9d9d":{"s":"storyboard-architect","a":"SKILL.md","l":107,"t":"`start` / `end`, timestamps in seconds, decimal allowed. `end` must be after `start`","o":"archivo"},"bbcf9882e50b":{"s":"storyboard-architect","a":"SKILL.md","l":113,"t":"`depth_of_field`, optional, shallow / deep / rack","o":"auditoria"},"5942ba44f22f":{"s":"storyboard-architect","a":"SKILL.md","l":128,"t":"Every piece of on-screen text becomes an entry in `text-overlays.json`. Never bake text into the visual description. Each overlay has:","o":"auditoria"},"1cec4673e7f2":{"s":"storyboard-architect","a":"SKILL.md","l":137,"t":"`color`, hex (must come from brand-lock palette)","o":"auditoria"},"abc02ebdb6a8":{"s":"storyboard-architect","a":"SKILL.md","l":151,"t":"Every shot has a one-sentence rationale. Why this beat. Why this framing. Why this on-screen text. This is the audit trail. Do not skip it.","o":"archivo"},"38de07452a46":{"s":"storyboard-architect","a":"SKILL.md","l":192,"t":"Use the template at `templates/storyboard.md.tpl`. Read it before writing.","o":"archivo"},"16f6bf46f67c":{"s":"storyboard-architect","a":"SKILL.md","l":196,"t":"Must validate against `templates/shots.schema.json`. Read it before writing. The structure is:","o":"archivo"},"85e3ed23b8ae":{"s":"storyboard-architect","a":"SKILL.md","l":235,"t":"Must validate against `templates/text-overlays.schema.json`. Read it before writing.","o":"auditoria"},"4c1f6d0ef267":{"s":"storyboard-architect","a":"SKILL.md","l":305,"t":"Don't run those automatically. The user picks.","o":"archivo"},"5cff35ce456c":{"s":"storyboard-architect","a":"brand-packs/README.md","l":7,"t":"Copy `_template.md` to a new file (e.g. `acme.md`)","o":"archivo"},"e49a82b5336a":{"s":"storyboard-architect","a":"brand-packs/README.md","l":8,"t":"Fill in every field. No placeholders left behind.","o":"archivo"},"3e5b03db5bd2":{"s":"storyboard-architect","a":"brand-packs/README.md","l":9,"t":"Reference it from your storyboard requests:","o":"archivo"},"ab8ee2cc3cfb":{"s":"storyboard-architect","a":"brand-packs/README.md","l":13,"t":"The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.","o":"archivo"},"3f9aad2c4e2c":{"s":"storyboard-architect","a":"brand-packs/README.md","l":21,"t":"**Be exclusive.** The \"never\" list is more valuable than the \"always\" list. Listing what the brand will not do narrows the generator's space and produces tighter output.","o":"archivo"},"db7addc154a9":{"s":"storyboard-architect","a":"brand-packs/README.md","l":29,"t":"**`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real \"never\" list. Use this as the reference for the level of specificity production work requires.","o":"archivo"},"df43eb92b1b2":{"s":"storyboard-architect","a":"brand-packs/README.md","l":36,"t":"Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:","o":"archivo"},"c5e62839e1ee":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":25,"t":"Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.","o":"archivo"},"2f545717c91e":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":49,"t":"What this brand never does, visually or tonally. Be specific.","o":"archivo"},"e03457ae7069":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":51,"t":"never use stock photo aesthetic","o":"archivo"},"25f0ecf00da8":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":52,"t":"never use AI uncanny faces","o":"archivo"},"1acd5803bd0f":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":53,"t":"never over-saturate","o":"archivo"},"3214012dc24d":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":54,"t":"never shout in copy","o":"archivo"},"250eda4c5849":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":55,"t":"never use clip-art icons","o":"archivo"},"5ada3d9e3057":{"s":"storyboard-architect","a":"brand-packs/_template.md","l":64,"t":"How footage and generated images should be graded. One sentence.","o":"archivo"},"25d9cd499896":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":40,"t":"never use stock photo aesthetic","o":"archivo"},"e815875bfd9e":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":41,"t":"never use AI uncanny faces","o":"archivo"},"dd6e8d6008ac":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":42,"t":"never over-saturate the cream background","o":"archivo"},"333c20110ff3":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":43,"t":"never use coral as a flood color (only as accent or signature periods)","o":"archivo"},"5aecc4ca21d4":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":44,"t":"never use em dashes in copy","o":"archivo"},"dac6a52ee58c":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":45,"t":"never use emojis in body copy","o":"archivo"},"c95b248c14c2":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":46,"t":"never use bullet points in narrative copy","o":"archivo"},"c906d8795790":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":47,"t":"never use clip-art or generic icon sets","o":"archivo"},"ba0238372a4c":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":48,"t":"never use hype words (\"game-changing\", \"revolutionary\", \"next-level\", \"comprehensive\")","o":"archivo"},"03c4f6662db6":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":49,"t":"never use exclamation points in headlines","o":"archivo"},"91020f8aff04":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":50,"t":"never default to dark mode, light mode hybrid is the brand","o":"archivo"},"26257934361a":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":51,"t":"never animate text with bouncing or wobbling, type-on, fade, or hard cut only","o":"archivo"},"65805ba83e7e":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":62,"t":"Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.","o":"archivo"},"19abf8cb5067":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":66,"t":"Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.","o":"archivo"},"d81969febc9e":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":74,"t":"prefer specific numbers over vague claims","o":"archivo"},"e1559d443197":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":75,"t":"prefer present-tense over future-tense","o":"archivo"},"f380cff82f61":{"s":"storyboard-architect","a":"examples/30s-pain-proof-promise/brand-lock.snapshot.md","l":76,"t":"prefer \"operator\" over \"creator\", \"infrastructure\" over \"agency\"","o":"archivo"},"e10409cde634":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":40,"t":"never use stock photo aesthetic","o":"archivo"},"5c3ec0c8cf75":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":41,"t":"never use AI uncanny faces","o":"archivo"},"fef9fe44ef96":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":42,"t":"never over-saturate the cream background","o":"archivo"},"4590b5aee804":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":43,"t":"never use coral as a flood color (only as accent or signature periods)","o":"archivo"},"d40b84764301":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":44,"t":"never use em dashes in copy","o":"archivo"},"478143da99e2":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":45,"t":"never use emojis in body copy","o":"archivo"},"1bbba41d8f5e":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":46,"t":"never use bullet points in narrative copy","o":"archivo"},"1249aae4215a":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":47,"t":"never use clip-art or generic icon sets","o":"archivo"},"621b3df6eb6a":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":48,"t":"never use hype words (\"game-changing\", \"revolutionary\", \"next-level\", \"comprehensive\")","o":"archivo"},"d9e264405291":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":49,"t":"never use exclamation points in headlines","o":"archivo"},"64c7eedde7cc":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":50,"t":"never default to dark mode, light mode hybrid is the brand","o":"archivo"},"38c7b73cec5b":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":51,"t":"never animate text with bouncing or wobbling, type-on, fade, or hard cut only","o":"archivo"},"4b55ac47f0e7":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":62,"t":"Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.","o":"archivo"},"ff35cc7d69fd":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":66,"t":"Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.","o":"archivo"},"995296a29fb4":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":74,"t":"prefer specific numbers over vague claims","o":"archivo"},"db692e54505e":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":75,"t":"prefer present-tense over future-tense","o":"archivo"},"5e4a95ec4d8c":{"s":"storyboard-architect","a":"examples/60s-founder-explainer/brand-lock.snapshot.md","l":76,"t":"prefer \"operator\" over \"creator\", \"infrastructure\" over \"agency\"","o":"archivo"},"929d3e62f0b7":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":43,"t":"never use stock photo aesthetic","o":"archivo"},"c5761942f155":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":44,"t":"never use AI uncanny faces","o":"archivo"},"f28e4507d045":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":45,"t":"never over-saturate the cream background","o":"archivo"},"3751f321730f":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":46,"t":"never use coral as a flood color (only as accent or signature periods)","o":"archivo"},"9132e55fcf5d":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":47,"t":"never use em dashes in copy (only periods, commas, semicolons)","o":"archivo"},"0f628683c6b8":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":48,"t":"never use emojis in body copy","o":"archivo"},"eff9c8392083":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":49,"t":"never use bullet points in narrative copy","o":"archivo"},"b700cf8f4dcb":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":50,"t":"never use clip-art or generic icon sets","o":"archivo"},"45e257d77c42":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":51,"t":"never use hype words (\"game-changing\", \"revolutionary\", \"next-level\", \"comprehensive\")","o":"archivo"},"ddb048e79808":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":52,"t":"never use exclamation points in headlines","o":"archivo"},"eb006504840c":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":53,"t":"never default to dark mode, light mode hybrid is the brand","o":"archivo"},"783ff683393c":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":54,"t":"never animate text with bouncing or wobbling, type-on, fade, or hard cut only","o":"archivo"},"8cea74bc14b1":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":55,"t":"never break the eye line between subject and the implied \"operator perspective\"","o":"archivo"},"f6abdd226436":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":66,"t":"Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup. Skin tones warm but not orange. Greens kept slightly desaturated to push focus to subject.","o":"archivo"},"d8a47abf50ca":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":70,"t":"Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only, no fancy wipes, no zooms.","o":"archivo"},"e9560a0de1ac":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":82,"t":"prefer specific numbers over vague claims (\"48 hours\" not \"fast\", \"30 minutes a week\" not \"a little time\")","o":"archivo"},"cc0c55fe6755":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":83,"t":"prefer present-tense over future-tense","o":"archivo"},"c1a8c5479b88":{"s":"storyboard-architect","a":"examples/shotkit-explainer/brand-lock.snapshot.md","l":84,"t":"prefer \"operator\" over \"creator\", \"infrastructure\" over \"agency\", \"system\" over \"service\"","o":"archivo"},"7e5f2e473cd3":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":3,"t":"Pick one. Don't invent a new one unless the brief genuinely doesn't fit. Document the choice in `storyboard.md`.","o":"archivo"},"f32c786bfbff":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":9,"t":"**Pain**, name the audience's actual problem in their actual language. Concrete, not abstract. \"Your content feels random\" not \"marketing inefficiency.\"","o":"archivo"},"d329c7d38124":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":10,"t":"**Reframe**, flip the problem on its head. The point is *not* what they thought it was. \"You don't have a content problem. You have an infrastructure problem.\"","o":"archivo"},"b55cf418fc3a":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":11,"t":"**Promise**, what life looks like on the other side. Specific, verifiable, time-bound when possible.","o":"archivo"},"e5235864c6bb":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":16,"t":"Use when: ad creative, landing-page hero video, conversion-focused social.","o":"archivo"},"0206d6df0cc3":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":22,"t":"**World**, set the context. Who lives in this world. What's broken about it.","o":"archivo"},"9b3fba335e1b":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":23,"t":"**Hero**, the product/founder/methodology arrives. Show what it does, not what it is.","o":"archivo"},"e4b20db35b44":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":24,"t":"**Transformation**, the world changes. Show before/after at scale.","o":"archivo"},"cfaecb7f5fa7":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":29,"t":"Use when: product launches, brand films, anchor pieces.","o":"archivo"},"39b17554140c":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":35,"t":"**Hook**, a one-line provocation (0–2s)","o":"archivo"},"ec4f8b7428c7":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":36,"t":"**Stakes**, why this matters (2–8s)","o":"archivo"},"3bdf77c5a1e7":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":37,"t":"**Insight**, the actual point (8–20s for 30s, 8–40s for 60s)","o":"archivo"},"6154ed831bf3":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":38,"t":"**Proof**, one concrete example or data point","o":"archivo"},"6be1e3549be6":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":39,"t":"**CTA**, what to do next, narrow and specific","o":"archivo"},"ca19a04f7f16":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":41,"t":"Use when: founder content, thought leadership, personal-brand pieces.","o":"archivo"},"e707043ad741":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":47,"t":"**Wide claim**, the headline take","o":"archivo"},"61117f1e1435":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":48,"t":"**Zoom 1**, one layer of nuance","o":"archivo"},"bcd48bb1ab67":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":49,"t":"**Zoom 2**, the layer underneath that","o":"archivo"},"409a346f14c6":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":50,"t":"**Snap-back**, return to the wide claim, now reframed by the zooms","o":"archivo"},"e4456cb5dc55":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":54,"t":"Use when: opinion videos, kinetic-type pieces, social-native commentary.","o":"archivo"},"86733dae8e0e":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":60,"t":"**Problem state**, what someone is stuck on","o":"archivo"},"4b795000d239":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":61,"t":"**Reveal**, the technique or trick","o":"archivo"},"a68a06f84fe6":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":62,"t":"**Walk-through**, apply it step by step","o":"archivo"},"0357fe063806":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":63,"t":"**Result**, the after-state, side-by-side with before","o":"archivo"},"08af446ba369":{"s":"storyboard-architect","a":"references/beat-frameworks.md","l":65,"t":"Use when: tutorials, demo videos, training content.","o":"archivo"},"428f5eebff7b":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":3,"t":"Text on screen is a load-bearing decision. Most storyboards over-text. The default should be: **does this shot need text to land?** If the visual carries the meaning, text dilutes.","o":"archivo"},"a268ba75d0b5":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":7,"t":"**Auto-play-mute environments.** Social feeds. Text replaces VO.","o":"archivo"},"efdeec778e0f":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":8,"t":"**Concept compression.** A short phrase lands harder than 4 seconds of narration.","o":"archivo"},"90221fe5fe0f":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":9,"t":"**Stat or proof point.** Numbers stick visually in a way they don't audibly.","o":"archivo"},"48c59084ee78":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":10,"t":"**Beat punctuation.** A single word or phrase that lands on a music hit.","o":"archivo"},"9f529931cccc":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":11,"t":"**CTA.** The action you want the viewer to take.","o":"archivo"},"c1fb4192e05a":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":15,"t":"**Restating the VO.** If the voice says it, the text is noise.","o":"archivo"},"84655e935767":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":16,"t":"**Decorative copy.** \"Moments matter\" floating over b-roll. Cut it.","o":"archivo"},"84f1791a022e":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":17,"t":"**Brand vibing.** Product names everywhere. Logo lockup in the CTA covers this.","o":"archivo"},"67f2beaeb3ef":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":18,"t":"**Filler beats.** If the shot doesn't need text, leave it clean.","o":"archivo"},"4ff066eab26b":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":26,"t":"When a shot has on-screen text, the **shot subject must reserve space for it**. This is enforced at storyboard time, not generation time.","o":"archivo"},"7a7cb7a4a5e8":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":43,"t":"`{x: %, y: %}` | Custom, only when the standard positions don't fit","o":"archivo"},"9f4f78bc99a2":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":63,"t":"Avoid stacking animations. Pick one per overlay.","o":"archivo"},"4cbacbc0b8fa":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":67,"t":"The `color` field of every text overlay must be a hex value that exists in the brand-lock palette. If you find yourself wanting a color that's not in the palette, the answer is not to add it, the answer is to pick a different overlay style or shot composition.","o":"auditoria"},"d7940c08b552":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":71,"t":"Same: every `font` field must reference a font defined in brand-lock typography. Two fonts max per project (display + body). More than that and the brand stops being recognizable.","o":"auditoria"},"717463d29f8f":{"s":"storyboard-architect","a":"references/on-screen-text.md","l":75,"t":"Already covered in timing-rules.md but worth repeating: text needs to be on screen long enough for someone to read it twice. Calculate, then verify. Don't eyeball.","o":"archivo"},"7268a7328d89":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":3,"t":"Controlled vocabulary. Use these exact terms in `shots.json`. Generators interpret loose language inconsistently, locked vocabulary survives translation.","o":"archivo"},"74926ea5bff7":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":11,"t":"`MCU` | Medium close-up | Head and shoulders","o":"archivo"},"6b3fa7bb2923":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":29,"t":"Default to eye-level. Use the others deliberately, not for variety.","o":"archivo"},"5528555145f9":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":50,"t":"`shallow` | Subject sharp, background blurred","o":"archivo"},"e4e41d7c48e9":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":54,"t":"Default to shallow for talking-head, deep for environmental and schematic.","o":"archivo"},"03a00602482e":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":58,"t":"Don't redefine per shot. Define once in `series_lock.lighting`. Examples:","o":"archivo"},"05f30ccb87c3":{"s":"storyboard-architect","a":"references/shot-grammar.md","l":90,"t":"**brand_lock**, locked across the entire project. Palette, type, \"never\" list.","o":"auditoria"},"22f6035ce704":{"s":"storyboard-architect","a":"references/timing-rules.md","l":3,"t":"Pacing is math, not feel. Use these as defaults. Override only with reason documented in rationale.","o":"archivo"},"32344b412ad5":{"s":"storyboard-architect","a":"references/timing-rules.md","l":19,"t":"The hook is 0–2s. Always. There are no exceptions in short-form content. Specifically:","o":"archivo"},"e67edc98e31f":{"s":"storyboard-architect","a":"references/timing-rules.md","l":21,"t":"9:16 social: first frame must telegraph the topic. Auto-play on mute means the first half-second is fighting a swipe.","o":"archivo"},"5e8113658ff6":{"s":"storyboard-architect","a":"references/timing-rules.md","l":24,"t":"The hook shot framing should be high-contrast against the shots that follow. If shot 2 is MS, shot 1 should not be MS. Visual contrast = retention.","o":"archivo"},"7e40e9d57114":{"s":"storyboard-architect","a":"references/timing-rules.md","l":30,"t":"Last shot should hold long enough for someone to read the CTA text and act","o":"archivo"},"5acc0a53e64b":{"s":"storyboard-architect","a":"references/timing-rules.md","l":31,"t":"Don't put motion on the CTA shot, let the text breathe","o":"archivo"},"8499e1ad407c":{"s":"storyboard-architect","a":"references/timing-rules.md","l":36,"t":"A text overlay needs to be on screen long enough to be **read twice**. Not once, twice. Why: viewers are skimming, eyes don't always lock on first frame.","o":"archivo"},"8a7cde5fbf44":{"s":"storyboard-architect","a":"references/timing-rules.md","l":47,"t":"Shorten the copy","o":"archivo"},"1740a84f47a3":{"s":"storyboard-architect","a":"references/timing-rules.md","l":48,"t":"Carry the text across two consecutive shots (text persists during cut)","o":"archivo"},"6c398f45603b":{"s":"storyboard-architect","a":"references/timing-rules.md","l":49,"t":"Lengthen the shot","o":"archivo"},"6c97051eb055":{"s":"storyboard-architect","a":"references/timing-rules.md","l":51,"t":"Do not under-time text. It's the most common storyboard failure.","o":"archivo"},"e7f6806c93e3":{"s":"storyboard-architect","a":"references/timing-rules.md","l":79,"t":"Sum of `(end - start)` across all shots equals project duration ±0.1s","o":"archivo"},"35389a2e7e9a":{"s":"storyboard-architect","a":"references/timing-rules.md","l":80,"t":"No shot has `start >= end`","o":"archivo"},"993e2cd1eec5":{"s":"storyboard-architect","a":"references/timing-rules.md","l":81,"t":"No two shots overlap","o":"archivo"},"40867e840a40":{"s":"storyboard-architect","a":"references/timing-rules.md","l":82,"t":"First shot starts at 0.0","o":"archivo"},"e620d729b974":{"s":"storyboard-architect","a":"references/timing-rules.md","l":83,"t":"Last shot ends at project duration","o":"archivo"},"0678f6cbf749":{"s":"storyboard-architect","a":"references/timing-rules.md","l":84,"t":"Every text overlay's `enter.at` is ≥ its shot's `start`","o":"archivo"},"5d267e42e94d":{"s":"storyboard-architect","a":"references/timing-rules.md","l":85,"t":"Every text overlay's `exit.at` is ≤ its shot's `end` (or carries to a flagged successor shot)","o":"archivo"},"18b6449fb38c":{"s":"storyboard-architect","a":"references/timing-rules.md","l":86,"t":"Every text overlay's on-screen duration ≥ read-twice threshold","o":"archivo"},"090ccfb96455":{"s":"storyboard-html-preview","a":"SKILL.md","l":10,"t":"The constraint is non-negotiable: **single file, no build step, no server, works offline.** Any time the output requires \"run this build command\" or \"host this somewhere,\" the skill has failed.","o":"archivo"},"629bb2d205d3":{"s":"storyboard-html-preview","a":"SKILL.md","l":40,"t":"An entry in `shot.assets.generated` marked `accepted: true`","o":"archivo"},"b9f0e777f95a":{"s":"storyboard-html-preview","a":"SKILL.md","l":41,"t":"The newest entry in `shot.assets.generated`","o":"archivo"},"09e4367e3b97":{"s":"storyboard-html-preview","a":"SKILL.md","l":82,"t":"The HTML preview should *feel* like the brand without going overboard. Quiet branding, not loud.","o":"archivo"},"8a2c11a5fc35":{"s":"storyboard-html-preview","a":"SKILL.md","l":86,"t":"Use `templates/preview.html.tpl` as the structural template. Read it before generating.","o":"archivo"},"410599a6e6d1":{"s":"storyboard-html-preview","a":"SKILL.md","l":159,"t":"frames as base64. Ask the user which they prefer if frames are present.","o":"archivo"},"e3ddb1d823f5":{"s":"storyboard-html-preview","a":"SKILL.md","l":211,"t":"Ensure text overlays render legibly","o":"archivo"},"32701372f5d1":{"s":"storyboard-html-preview","a":"SKILL.md","l":212,"t":"Use black-on-white where brand colors won't print well","o":"archivo"},"6975e2ff7171":{"s":"storyboard-html-preview","a":"SKILL.md","l":214,"t":"The user should be able to hit Cmd-P / Ctrl-P and get a clean PDF.","o":"archivo"},"77570da551dd":{"s":"storyboard-html-preview","a":"SKILL.md","l":224,"t":"No CDN scripts. No Google Fonts. No external CSS frameworks. The file must work with no internet connection.","o":"archivo"},"d86f1629a7f6":{"s":"storyboard-html-preview","a":"SKILL.md","l":230,"t":"Hit Cmd-P. The result should be a clean PDF. If layout breaks across page boundaries, the print stylesheet is broken.","o":"archivo"},"90b1a187484f":{"s":"storyboard-html-preview","a":"SKILL.md","l":234,"t":"Use brand colors as accents, not as full backgrounds. The reviewer's job is to read the storyboard, not admire the design. Subtle.","o":"archivo"},"9f76efb872f5":{"s":"storyboard-html-preview","a":"SKILL.md","l":238,"t":"Stakeholders open links on phones. The HTML should be readable on mobile without horizontal scroll. Simple responsive CSS.","o":"archivo"},"2d5d435df3ef":{"s":"video","a":"SKILL.md","l":16,"t":"**Still keyframes, character sheets, animatic panels** to feed the video pipeline: use the sibling `image` skill, then return with the keyframes.","o":"archivo"},"f21bcfe2dfbc":{"s":"video","a":"SKILL.md","l":76,"t":"If any shot fails, fix before sending. This is the step the user has had to enforce repeatedly. Do not skip it.","o":"archivo"},"99b3186877c9":{"s":"video","a":"SKILL.md","l":97,"t":"Prefer: ready-to-copy prompts, clear section labels, production language, motivated camera and light direction, strict continuity blocks, model-specific syntax, direct fixes.","o":"archivo"},"54b8e873fa4e":{"s":"video","a":"SKILL.md","l":99,"t":"Avoid: long theory unless asked, academic lectures, vague inspiration, decorative jargon, \"cinematic masterpiece\" filler, prompts without camera and light, prompts without continuity, stacking more than two director references, abstract emotions without physical translation.","o":"archivo"},"1abf520d87fe":{"s":"video","a":"references/animatic-keyframes.md","l":3,"t":"This is the still-panel layer. A storyboard keyframe is not a frame grab of footage — it is a single drawn image that must carry one story-beat with **no motion and (usually) no face**. The animatic hangs off these panels. A panel that only looks good is wallpaper; a panel must report its story function, its drama, and the motion it cannot show, all frozen.","o":"archivo"},"24fe340cb58e":{"s":"video","a":"references/animatic-keyframes.md","l":25,"t":"In an animatic the **panel is the unit, not the shot.** A shot has duration, motion, and sound to carry its function across time. A keyframe has one frozen image and must carry the same function in a single glance. So every panel does four things at once, in one still:","o":"archivo"},"43a9c422d34f":{"s":"video","a":"references/animatic-keyframes.md","l":29,"t":"**One emotion** — routed through metal, rubber, light, or anatomy, never named (`dramaturgy.md` §2). Mixed signals = no signal.","o":"archivo"},"b9cd34ffcb70":{"s":"video","a":"references/animatic-keyframes.md","l":77,"t":"**Ritual / staging** (quiet) | 1 hero panel, held | 1 panel living 1.5-2.5s | A silent beat is monolithic. Do not subdivide it — its power is that nothing moves while the world holds its breath. One symmetric \"breath\" frame, most negative space, least motion.","o":"archivo"},"b04a79b44100":{"s":"video","a":"references/animatic-keyframes.md","l":80,"t":"**Contest** (sustained roar) | alternating | fragment-cluster ↔ one held detail | Never two bang-clusters back to back. Between every burst, one held quiet panel — loud only works next to quiet.","o":"archivo"},"6d32d7171722":{"s":"video","a":"references/animatic-keyframes.md","l":83,"t":"**Allocation rule.** A 30s spot lands at ~18-26 panels. Plot the board as a descending duration staircase (≈2.5s → 0.5s → 4fr), broken only by the one pre-launch pause and the one post-finish hold. The board should *read* as an accelerating tachometer even on mute. Give a beat a micro-burst only when the audio detonates; everywhere else, one panel that holds is stronger than three that scatter.","o":"archivo"},"0fb332eaeff4":{"s":"video","a":"references/animatic-keyframes.md","l":89,"t":"A keyframe cannot ramp, cut, or whip. Each missing move resolves into one of **six frozen cues**. Never write \"motion\" — write the artifact motion leaves behind. State the cue in the card's *Motion-as-still* field and again in the prompt's camera/light clause; models default to over-clean stabilization and will sand the speed off unless told (§7).","o":"archivo"},"84e4c557c5f1":{"s":"video","a":"references/animatic-keyframes.md","l":97,"t":"**Sharp-subject / blurred-field separation** | Shallow-DOF macro: knuckle, needle, latch razor-sharp, everything else dissolved. Isolation = the cut-to-detail frozen. | insert chain, crash-zoom arrival, hip-hop CU","o":"archivo"},"9116b6b7205f":{"s":"video","a":"references/animatic-keyframes.md","l":115,"t":"A face does four jobs: shows the feeling, shows where it looks, shows the cost, shows the decision. Faces banned, redistribute: **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space** (§6 and `dramaturgy.md` §2). Assign one job per panel and tag it. The emotion must already be frozen *inside the object* — a still cannot let motion blur do the emo","o":"archivo"},"22aed852b261":{"s":"video","a":"references/animatic-keyframes.md","l":122,"t":"Use the substitution table as the core deliverable — when the script wants an emotion and no face is available, render this object at this crop. Cold palette throughout.","o":"archivo"},"5bea8ddfb87c":{"s":"video","a":"references/animatic-keyframes.md","l":144,"t":"**Depth-layer jobs (FG / MG / BG).** Write the prompt in three explicit depth clauses, each with a stated job. This is the engine of \"reads in one glance, rewards a second\" (extends `dramaturgy.md` §10 into a single still). If all three planes carry the same blur or scale, you have one plane, not three — force a sharp MG subject against a soft FG frame and a soft BG stake (shallow DOF is the panel","o":"archivo"},"c241a02cc037":{"s":"video","a":"references/animatic-keyframes.md","l":154,"t":"**Centerline spine, then break symmetry** — emotion: a single dominant axis (lane stripe, the Christmas Tree, a dividing wall) gives the eye a rail and makes even a chaotic frame readable; breaking it the instant one car noses ahead reads as momentum. — seen: Anderson centers for instant legibility; Bong breaks balanced staging to show a power shift. — *in a keyframe*: build one head-on symmetric ","o":"archivo"},"921f5446334f":{"s":"video","a":"references/animatic-keyframes.md","l":183,"t":"**Render audio as physical consequence, never as a named sound.** \"Loud engine\" is banned filler (`dramaturgy.md` §2) — prompt \"heat-haze warp off the headers, exhaust flame, chassis squat, sidewall wrinkle\" instead.","o":"archivo"},"d5feae1b60b8":{"s":"video","a":"references/animatic-keyframes.md","l":225,"t":"[ ] **Cold palette held** — steel/cyan/magenta/mercury-white, red and green as accents only, amber ≤15% and point-source (toxic, never cozy). One motivated source, ~70% unlit, one hard specular hit. Texture named (grain, halation, one flare), not \"clean.\"","o":"archivo"},"6f5a79ae61af":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":3,"t":"Use precise production language. \"Cinematic\" is not a direction. \"35mm, slow push-in, warm window key from frame-left\" is.","o":"archivo"},"617b9596ef1d":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":31,"t":"over-the-shoulder","o":"archivo"},"a3c2614e6e5e":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":78,"t":"shallow depth of field.","o":"archivo"},"84e552ce62b9":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":138,"t":"Define palette with concrete colors. Never write \"cinematic colors.\"","o":"archivo"},"0278247a92b4":{"s":"video","a":"references/camera-lighting-vocabulary.md","l":246,"t":"Rules of use. Name the transition and the exact moment it fires. One transition type per cut. When the choice is open, delegate: \"choose the most suitable from [natural cut / occlusion mask / match cut] for the style of this film.\"","o":"archivo"},"4594046fc713":{"s":"video","a":"references/dramaturgy.md","l":3,"t":"This is the mandatory layer. A beautiful frame without dramaturgy is wallpaper. Every prompt built by this skill must pass the dramaturgy check before it is sent to the user.","o":"archivo"},"f2664fed4b35":{"s":"video","a":"references/dramaturgy.md","l":45,"t":"The scene formula tells you **what a scene is**. The Details Law tells you **how every shot must be written**. Skip it and even a perfect dramaturgical structure produces mush on screen.","o":"archivo"},"fe8ae4c731e8":{"s":"video","a":"references/dramaturgy.md","l":53,"t":"**Environmental pressure.** A physical fact about the space that carries the emotion. Cold refrigerator light. Wet asphalt. Flickering ceiling tube. Steam from the kettle. Rain on one specific windowpane. A buzzing AC unit. Tight corridor walls. Mirror reflection. (See §9 — Environment plays.)","o":"archivo"},"291a35a705ad":{"s":"video","a":"references/dramaturgy.md","l":54,"t":"**Physical micro-action on the body.** The emotion translated into the actor's body. Jaw locks. Knuckles whiten. Lips press flat. Eyes drop a quarter-inch. He swallows hard. Fingers curl against the doorframe. The actor's body is the only place where feelings render — names of feelings do not.","o":"archivo"},"adc3e3d51477":{"s":"video","a":"references/dramaturgy.md","l":55,"t":"**Sound anchor or visual motif.** A recurring perceptual hook tied to the spine of the piece. Stomach growl repeated three times. Reflection in dark glass on every transition. The same musical sting at every Crack beat. The clock's second hand. Footsteps in an empty corridor.","o":"archivo"},"435fff89e7d5":{"s":"video","a":"references/dramaturgy.md","l":81,"t":"Every shot must do at least one of three things. If it does none, delete it.","o":"archivo"},"dbb9069efcc9":{"s":"video","a":"references/dramaturgy.md","l":93,"t":"**Emotion (51%).** Does the cut honor the emotional truth of the moment. What does the viewer feel now vs. what they should feel next.","o":"archivo"},"5d494f11d5ec":{"s":"video","a":"references/dramaturgy.md","l":94,"t":"**Story (23%).** Does the cut advance story or reveal character.","o":"archivo"},"09ecf6f81ee5":{"s":"video","a":"references/dramaturgy.md","l":95,"t":"**Rhythm (10%).** Does the cut fall on a musical beat of the scene.","o":"archivo"},"94cb46e0cdd8":{"s":"video","a":"references/dramaturgy.md","l":96,"t":"**Eye-trace (7%).** Where is the viewer's gaze at the moment of the cut. Does the new shot receive that gaze naturally.","o":"archivo"},"0cf6378a2c57":{"s":"video","a":"references/dramaturgy.md","l":97,"t":"**2D plane (5%).** Does the cut respect the axis of screen direction.","o":"archivo"},"dd109f775c6c":{"s":"video","a":"references/dramaturgy.md","l":98,"t":"**3D space (4%).** Does the cut respect the geometry of the real location.","o":"archivo"},"5b4e8d3dcda1":{"s":"video","a":"references/dramaturgy.md","l":116,"t":"Good. \"He edges toward the window but his shoulder stays angled back toward her, as if the conversation still holds him.\"","o":"archivo"},"2be8adc698a8":{"s":"video","a":"references/dramaturgy.md","l":150,"t":"Good. \"Push-in starts on 'I don't know' and stops on her jaw locking.\"","o":"archivo"},"c7fa86763233":{"s":"video","a":"references/dramaturgy.md","l":154,"t":"Spielberg principle. Even in chaos, the viewer must know.","o":"archivo"},"f88d89dd2268":{"s":"video","a":"references/dramaturgy.md","l":200,"t":"Adjust for 30s or 15s by compressing proportionally. Never skip the Crack or the Impact.","o":"archivo"},"6be9ddc67dea":{"s":"video","a":"references/dramaturgy.md","l":251,"t":"**Eye trace.** Where the viewer's gaze should land in the first 0.3s.","o":"archivo"},"c2e0a3b45412":{"s":"video","a":"references/dramaturgy.md","l":276,"t":"Always insert at least one pause before the biggest cut.","o":"archivo"},"01d9db058ef3":{"s":"video","a":"references/dramaturgy.md","l":347,"t":"Is the scene formula complete? (desire + obstacle + geometry + gaze + rhythm)","o":"archivo"},"75eee4c9c72b":{"s":"video","a":"references/dramaturgy.md","l":348,"t":"Does every shot pass the three-detail check? (environmental pressure + physical micro-action + sound or visual motif)","o":"archivo"},"c52b9a2cbc96":{"s":"video","a":"references/dramaturgy.md","l":349,"t":"Does every shot do one of the three jobs? (change emotion, advance action, increase pressure)","o":"archivo"},"cd71da05d199":{"s":"video","a":"references/dramaturgy.md","l":350,"t":"Is there a motivated reason for every camera move?","o":"archivo"},"e51237770b8c":{"s":"video","a":"references/dramaturgy.md","l":351,"t":"Is the spatial geometry readable?","o":"archivo"},"eba7494935d3":{"s":"video","a":"references/dramaturgy.md","l":352,"t":"Are the five anchors named? (emotion, motif, object, break, final image)","o":"archivo"},"4ddd5b7aae62":{"s":"video","a":"references/fixes-and-skeletons.md","l":58,"t":"For Kling. Use Element Binding with 3-4 reference images (front, side, three-quarter).","o":"archivo"},"1df0239fdbc2":{"s":"video","a":"references/fixes-and-skeletons.md","l":98,"t":"For Seedance and Veo. Use positive phrasing.","o":"archivo"},"87d2484dd6cf":{"s":"video","a":"references/fixes-and-skeletons.md","l":121,"t":"Fix. Avoid style words like \"hyperrealistic 8k masterpiece.\" These push the model into AI-art territory. Use production language instead.","o":"archivo"},"1863ac937570":{"s":"video","a":"references/fixes-and-skeletons.md","l":147,"t":"For forward extensions, the standard clause: \"prohibit rigid cutting, prohibit objects appearing out of thin air.\"","o":"archivo"},"d98803cf48d0":{"s":"video","a":"references/fixes-and-skeletons.md","l":157,"t":"On Seedance 2.5 and Veo this is reliable. On Seedance 1.x/2.0 and Kling, also avoid mentioning any on-screen text or score you do not want — mentions summon them.","o":"archivo"},"8f83dc97e5ba":{"s":"video","a":"references/fixes-and-skeletons.md","l":230,"t":"Keep character continuity.","o":"archivo"},"8ea66f62d954":{"s":"video","a":"references/fixes-and-skeletons.md","l":231,"t":"Keep story action.","o":"archivo"},"13635ca633f1":{"s":"video","a":"references/fixes-and-skeletons.md","l":232,"t":"Keep shot timecodes (where relevant).","o":"archivo"},"508966ae84b9":{"s":"video","a":"references/fixes-and-skeletons.md","l":233,"t":"Keep lighting.","o":"archivo"},"7dabe8b7b479":{"s":"video","a":"references/fixes-and-skeletons.md","l":234,"t":"Keep camera.","o":"archivo"},"b755a79d8702":{"s":"video","a":"references/fixes-and-skeletons.md","l":235,"t":"Keep editing grammar.","o":"archivo"},"2d6cacf87d0d":{"s":"video","a":"references/fixes-and-skeletons.md","l":237,"t":"Remove philosophy and meta-commentary.","o":"archivo"},"c485717d92a0":{"s":"video","a":"references/fixes-and-skeletons.md","l":238,"t":"Remove extra adjectives.","o":"archivo"},"f1cf3ccb4d13":{"s":"video","a":"references/fixes-and-skeletons.md","l":239,"t":"Remove director references.","o":"archivo"},"a7febb0fdf00":{"s":"video","a":"references/fixes-and-skeletons.md","l":249,"t":"One ready-to-copy prompt for one generation. Use the appropriate model skeleton.","o":"archivo"},"61f2696d823a":{"s":"video","a":"references/fixes-and-skeletons.md","l":274,"t":"Missing direction (camera, light, continuity).","o":"archivo"},"179286c8c088":{"s":"video","a":"references/fixes-and-skeletons.md","l":276,"t":"Model-specific mismatches (wrong syntax for the chosen model).","o":"archivo"},"c16f3957c655":{"s":"video","a":"references/fixes-and-skeletons.md","l":277,"t":"Stronger version. Rewritten prompt, ready to copy.","o":"archivo"},"a82de4fa4979":{"s":"video","a":"references/fixes-and-skeletons.md","l":294,"t":"Structured scene-by-scene JSON. Use for complex continuity. See `references/veo.md` section 6.","o":"archivo"},"d85e439effb2":{"s":"video","a":"references/kling.md","l":7,"t":"**Kling 3.0 — multi-shot, native audio, 15s (read first if user is on 3.0)**","o":"archivo"},"0809eafc4ffb":{"s":"video","a":"references/kling.md","l":65,"t":"Introduce every character and key object at the **start** of the prompt, before any shot description. Use unique consistent identifiers — the same label survives across all shots:","o":"archivo"},"bb25b6a212a2":{"s":"video","a":"references/kling.md","l":93,"t":"Each shot must answer: **framing + subject + motion**. Empty shot descriptions (\"static frame, ambient mood\") collapse into one continuous take.","o":"archivo"},"71e86bdfe510":{"s":"video","a":"references/kling.md","l":99,"t":"**P1. Structured naming.** Use unique identifiers per character.","o":"archivo"},"a4313d46162b":{"s":"video","a":"references/kling.md","l":109,"t":"✓ `[Character B, clear fearful voice]: \"Don't open it.\"`","o":"archivo"},"9e30b0899784":{"s":"video","a":"references/kling.md","l":112,"t":"**P4. Temporal control between lines.** Use linking words to prevent dialogue from merging.","o":"archivo"},"7d81fcd5ccc0":{"s":"video","a":"references/kling.md","l":113,"t":"✓ \"Character A: 'I won't ask again.' **Immediately,** Character B: 'You don't have to.'\"","o":"archivo"},"21472873e0ca":{"s":"video","a":"references/kling.md","l":130,"t":"Use these terms directly — the model treats them as instructions, not flavor:","o":"archivo"},"c9b8d9532823":{"s":"video","a":"references/kling.md","l":138,"t":"In the Kling app, Master Shot presets (\"Move Forward and Zoom Up\" etc.) are more stable than hand-written camera prose and save credits — prefer them for standard moves, prose for motivated ones.","o":"archivo"},"4286109b9522":{"s":"video","a":"references/kling.md","l":142,"t":"If the task hits any of these — **use Kling 3.0 over earlier Kling**:","o":"archivo"},"8b8795ac59fd":{"s":"video","a":"references/kling.md","l":156,"t":"`duration` — per-shot durations must sum to ≤ 15s.","o":"archivo"},"eeae0374284b":{"s":"video","a":"references/kling.md","l":175,"t":"For Kling 3.0, use the multi-shot structure from section 3 instead.","o":"archivo"},"5c7946d7fd9f":{"s":"video","a":"references/kling.md","l":189,"t":"Kling has a dedicated negative prompts field. The field auto-interprets input as exclusion. Do not write \"no X\". Write the thing itself.","o":"archivo"},"15b3f8595289":{"s":"video","a":"references/kling.md","l":220,"t":"Even lighting. Avoid hard shadows. The AI can mistake them for permanent facial features.","o":"archivo"},"7a47e689454a":{"s":"video","a":"references/kling.md","l":232,"t":"A character element takes either a **3-8s video** (the model extracts both appearance and voice) or up to **4 multi-angle stills** (front, three-quarter, profile, back), plus optional **voice binding** (5-30s audio clip). Once bound, the voice belongs to the subject — do not re-describe it in the prompt.","o":"archivo"},"d94be792c74d":{"s":"video","a":"references/kling.md","l":235,"t":"Cost of the feature: several practitioners report visible image-quality degradation the moment elements/references are enabled. Use elements only when consistency actually matters; for one-off clips, in-prompt labels are cleaner.","o":"archivo"},"0db6e0a2de52":{"s":"video","a":"references/kling.md","l":241,"t":"Critical rule. The text prompt MUST match the brush motion. If you brush a river flowing and write \"stagnant pond\" the model tears itself apart. Align prompt verbs with brush directions.","o":"archivo"},"1e5d66901508":{"s":"video","a":"references/kling.md","l":245,"t":"Copy motion from a reference video. Use when you need specific performance or choreography (dance, martial arts, specific gait). The prompt then focuses on subject description only, the reference handles motion.","o":"archivo"},"36686df1386d":{"s":"video","a":"references/kling.md","l":249,"t":"Keep the prompt short (20-40 words). Focus only on motion. Do not re-describe static elements the model already sees.","o":"archivo"},"7d3ab7f4ba2a":{"s":"video","a":"references/kling.md","l":273,"t":"Fix. Upload 3-4 reference images to Element Library. Use Bind Elements in the settings.","o":"archivo"},"cf73cec68544":{"s":"video","a":"references/kling.md","l":289,"t":"Fix. Make shot boundaries explicit: `Shot 1 (0-3s). ... Shot 2 (3-6s). ...`. Each shot description must include a different framing or camera angle. If two adjacent shots share both framing and angle, the model merges them.","o":"archivo"},"85c33c12c479":{"s":"video","a":"references/kling.md","l":301,"t":"Fix. Strip references to the essential ones only; for one-off clips prefer in-prompt `[Character A: ...]` labels over elements. Accept the trade: elements buy consistency, not fidelity.","o":"archivo"},"4b9361768f1a":{"s":"video","a":"references/kling.md","l":305,"t":"Fix. Give each character its own element (or its own labeled identity block). Never let two speaking characters share one visual description.","o":"archivo"},"f876e8f2e5cb":{"s":"video","a":"references/patterns-and-genres.md","l":17,"t":"Use for tension builds, reveals, dramatic emphasis.","o":"archivo"},"5a27254127bb":{"s":"video","a":"references/patterns-and-genres.md","l":25,"t":"Use for psychological pressure, internal conflict, impending bad news.","o":"archivo"},"5465eb46d054":{"s":"video","a":"references/patterns-and-genres.md","l":33,"t":"Use for revealing a hidden element, exploration, search.","o":"archivo"},"240a672f7a78":{"s":"video","a":"references/patterns-and-genres.md","l":41,"t":"Use for comedic or dramatic disaster. Tiny object failures play bigger than explosions.","o":"archivo"},"5eaea7d005f0":{"s":"video","a":"references/patterns-and-genres.md","l":49,"t":"Use for ads with a hero product.","o":"archivo"},"4c683ca1e1ef":{"s":"video","a":"references/patterns-and-genres.md","l":57,"t":"Use for rhythmic repetition, transformation, performance.","o":"archivo"},"fae5c2bff912":{"s":"video","a":"references/patterns-and-genres.md","l":168,"t":"Inside each 5-second prompt, use timecodes.","o":"archivo"},"de49559afcec":{"s":"video","a":"references/patterns-and-genres.md","l":184,"t":"Use timecoded structure for Seedance and Veo. Kling prefers flowing prose.","o":"archivo"},"94114b6c3c86":{"s":"video","a":"references/patterns-and-genres.md","l":188,"t":"When moving from clip N to clip N+1, the first beat of the new clip should match the final beat of the previous clip. Character in same pose. Same light. Same color temperature. This is what makes them cut together cleanly in the editor.","o":"archivo"},"00552d374a9c":{"s":"video","a":"references/race-and-speed.md","l":28,"t":"**Authentic speed, never CGI-clean or sped-up.** Build velocity into the static composition (§3); never lean on a ramp to rescue a dead frame. Over-crank, glass-smooth stabilization and post speed-ramps read subconsciously as \"ad-speed\" and drain all threat. Squat, lifted nose, slick wrinkle, smeared rim — the physics has to be visible in the still.","o":"auditoria"},"47dd1d977a21":{"s":"video","a":"references/race-and-speed.md","l":29,"t":"**Detail is the emotion.** Faces banned, feeling renders only on a knuckle, a needle, a pedal, smoke, or a sweat bead (`dramaturgy.md` §2; the full substitution method is `animatic-keyframes.md` §5). A hand mid-grip is the no-face equivalent of a close-up on the eyes. No abstract \"motion\", no named feeling.","o":"auditoria"},"a2680889ec7c":{"s":"video","a":"references/race-and-speed.md","l":30,"t":"**One governing visual promise per piece.** A 30s cut earns cohesion from a single conceit: everything through reflections in painted metal, or everything through circles (tach → headlight → bulb → wheel), or everything as machine-talks / no-music. Kon's \"one visual principle\". Name it before boarding.","o":"auditoria"},"5e64b7c7d357":{"s":"video","a":"references/race-and-speed.md","l":31,"t":"**Beat-locked cutting.** Loudness in the audio = shot count on the board (§8; the density ladder itself is `animatic-keyframes.md` §3). Silence = one held panel. Bang = a burst of 4–8-frame micro-panels. Cut length is engine RPM made visual: idle = long panels, redline = collapsing panels toward the green.","o":"auditoria"},"1f3f073247b7":{"s":"video","a":"references/race-and-speed.md","l":32,"t":"**Cold combative palette** (§7). Steel blue, cyan, magenta, dirty mercury-white; **red as danger accent only** (brake glow, redline, tail-lights, the Tree's bulbs). No warm cozy amber wash — warmth appears only as toxin. Steal Tony Scott's grain, contrast and overexposure; **discard his warm grade.**","o":"auditoria"},"11ae3ea96fb0":{"s":"video","a":"references/race-and-speed.md","l":33,"t":"**Every insert is load-bearing.** Each detail panel must be captionable with one race label — *setup / commitment / mistake / recovery / proof-of-speed / result* (§4). If you cannot label it, it is a *fantik* (`dramaturgy.md` §3) — drop it. A board that is all proof-of-speed with no commitment/mistake/recovery is a reel, not a story.","o":"auditoria"},"611f323d3615":{"s":"video","a":"references/race-and-speed.md","l":42,"t":"→ **Rule:** never write \"motion\" — write the artifact motion leaves behind, and never board a neutral panel (every frame carries a forward vector, negative space ahead of the subject).","o":"auditoria"},"ca87c9bb0cd3":{"s":"video","a":"references/race-and-speed.md","l":57,"t":"A still has no engine note and zero motion. It sells velocity through the **speed-budget rule** — a frame reads fast only when **≥3 of five cues coexist** (camera at/below bumper height · asphalt streaking the lower frame · a near foreground reference passing the edge · sharp hero against motion-blurred background · a mechanical-vibration cue). The full rule, with the anti-fake firewall, lives in ","o":"auditoria"},"be25e9cc99a1":{"s":"video","a":"references/race-and-speed.md","l":73,"t":"**Long-lens compression** — the second speed register and the antidote to \"only blur sells speed\". Frankenheimer's 1000mm stacked distant cars onto the hero so closing distance reads as collapse. Pair compression panels with low-wide panels in the cut; never board the whole spot on one lens. In `seedance.md`/`veo.md` syntax name \"motion blur, fast-shutter look on background, sharp subject\" explici","o":"auditoria"},"fc4a79f80ec2":{"s":"video","a":"references/race-and-speed.md","l":81,"t":"A face does four jobs: internal state, where it looks, the cost, the decision. Banned, those jobs redistribute — **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space.** The mechanism, the EMOTION→OBJECT substitution table and the state-change cheat-sheet are owned by `animatic-keyframes.md` §5; do not duplicate them. Two filters before you draw:","o":"auditoria"},"7a8e1fc6b5e6":{"s":"video","a":"references/race-and-speed.md","l":117,"t":"**Amber logic (decision point).** Choose the **Sportsman / full tree** for an ad: three ambers fire *sequentially 0.5s apart* — three drawable keyframes, a stretched drum-roll of dread with cut length collapsing toward the green. The Pro tree fires all three at once — one panel, brutal but no build. Draw the Sportsman stagger. Always leave on the **last amber, not the green** (holeshot): the launc","o":"auditoria"},"9bf2cbf9c271":{"s":"video","a":"references/race-and-speed.md","l":129,"t":"3 | **Hard-mounted cabin shake** | Pressure / Reaction | Rigid interior mount: dash/needle/hands vibrating, mirror trembling, world shuddering through glass | visible micro-vibration; never perfectly stable","o":"auditoria"},"0e9bacb2e8ad":{"s":"video","a":"references/race-and-speed.md","l":148,"t":"**Restless / handheld cam** | the frame never settles; constant threat, physiological unease | Never a perfectly level, perfectly clean panel — bake in a 1–3° drift, edge smear, off-true horizon, a faint micro-shake artifact even in a \"static\" cockpit | Pressure","o":"auditoria"},"98ee930c9f7c":{"s":"video","a":"references/race-and-speed.md","l":157,"t":"Faces are banned, so light is the only actor left. It does not \"set a mood\" — it **rims a material** so a piece of metal, rubber or skin reports the emotion a face would. General light grammar (sources, direction, quality) is `camera-lighting-vocabulary.md` §4–7; the anti-sterile firewall is `animatic-keyframes.md` §7 + `universal-rules.md` U12. The race-specific governing law: *embrace the dark* ","o":"auditoria"},"2be4bcd05090":{"s":"video","a":"references/race-and-speed.md","l":169,"t":"Toxic amber/sodium (rationed) | temporary, contaminated, alien — never cozy | sodium lamp as a passing smear; spilled fluid catching one lamp; the Tree's three ambers as countdown only","o":"auditoria"},"8a862f876fa8":{"s":"video","a":"references/race-and-speed.md","l":171,"t":"**Warmth as toxin** is the only permitted heat: brake-disc/exhaust glow (the machine at its thermal limit), a header flame stab gone in a frame, the Tree's alien ambers, a sickly sodium smear. Any warm element must be **point-source and surrounded by cold**. If amber fills more than ~15% of the frame it has become a wash — kill it.","o":"auditoria"},"f79825c8bfa6":{"s":"video","a":"references/race-and-speed.md","l":177,"t":"**Backlit smoke** [Pressure/Establish]: hard cyan or mercury-white punching *through* tire smoke from behind; volumetric shafts, the car a dark mass dissolving into glowing haze, red tail-light bleed inside the smoke for the danger accent. Front-lit smoke is dead gray nothing — always rim it from behind.","o":"auditoria"},"784a21fb3fba":{"s":"video","a":"references/race-and-speed.md","l":180,"t":"**Silhouette / contre-jour** [Power/Pressure]: helmet/shoulder as pure black shape against a blown headlight or the Tree's amber bank, one thin rim defining the form plus one glint on the visor edge, no features. The brain fills the dark with something worse than any face.","o":"auditoria"},"c50591694f2a":{"s":"video","a":"references/race-and-speed.md","l":183,"t":"**Texture and atmosphere.** Name the grain, never \"clean\": fine-to-medium film grain (heaviest in shadow), halation/bloom on hard practicals (soft glow ring + hard hot core), one anamorphic flare off the dominant source, slight chromatic fringe on the hottest edges (anti-sterile test in `animatic-keyframes.md` §7). One atmospheric pressure per panel (`dramaturgy.md` §9, Kurosawa) — backlit tire sm","o":"auditoria"},"5f835d0eb35a":{"s":"video","a":"references/race-and-speed.md","l":189,"t":"You storyboard the **sound first**; the keyframes hang off it. The general law — **loudness in the audio = panel count** — and the descending duration staircase are the density ladder in `animatic-keyframes.md` §3, sitting on the `dramaturgy.md` §12 rhythm staircase. Do not re-derive them. The race-specific rhythm rules:","o":"auditoria"},"a433636c2657":{"s":"video","a":"references/race-and-speed.md","l":191,"t":"**Engine as metronome.** Tie panel *duration* to RPM: idle = ~2s panels, redline = panels collapsing 2s → 1s → 0.5s → 8fr → 4fr toward the green. The board should read as an accelerating tachometer on mute. Annotate each panel with its on-screen life.","o":"auditoria"},"2d91bbc13caa":{"s":"video","a":"references/race-and-speed.md","l":194,"t":"**Pull-to-intimate at the peak.** At the contest's tensest point, cut from a wide loud pass to an ECU of glove-on-shifter / breath-fog, shallow focus, void around it — engines stripped to breath only. The *quiet* panel goes *tight*; the loud panel goes wide.","o":"auditoria"},"f5ef9ac105ef":{"s":"video","a":"references/race-and-speed.md","l":198,"t":"Every panel inherits a `Sound` cell even though it is a still (`dramaturgy.md` §11) — prompt the *physical consequence* of the sound (deformation, particulate, smear, heat-haze, isolation-in-void), never a named sound. Fill it.","o":"auditoria"},"19ef2dbc9666":{"s":"video","a":"references/race-and-speed.md","l":204,"t":"Five phases: **ritual → staging → launch → contest → release.** Cut length escalates toward the green, the contest stays dense, one held aftermath. ~20–26 panels. Function tags from `role-modes.md` §4. This is the structural skeleton; for a fully worked, panel-by-panel deliverable board of this exact structure (format C, ~13 rows), use `animatic-keyframes.md` §8 — do not draw a second worked board","o":"auditoria"},"de0ddf9ca295":{"s":"video","a":"references/race-and-speed.md","l":214,"t":"Allocation: plot the board as a descending duration staircase, broken only by the one pre-launch held panel (the single most-held still, most negative space) and the one post-finish hold. The launch is *never* one hero frame — fan it into the 6–9-panel micro-burst. No two bang-clusters touch; every burst is separated by a held quiet panel.","o":"auditoria"},"54d1d74f3df8":{"s":"video","a":"references/race-and-speed.md","l":231,"t":"[ ] No banned panel: static fetish insert (lever/badge/wheel with no verb, no state-change); anatomy at rest; a detail you cannot caption with a §4 label; all-proof-of-speed board with no commitment/mistake/recovery; decorative dashboard clutter (keyring, dice, coffee cup — \"each object is a clue\"); warm wash without narrative function.","o":"auditoria"},"1948fb0cd2ea":{"s":"video","a":"references/race-and-speed.md","l":233,"t":"Before sending the board, run `animatic-keyframes.md` §9 (per-panel master checklist), `dramaturgy.md` §15 and `universal-rules.md` §13 over it. The most-violated step is the three-detail check — do not skip it.","o":"auditoria"},"cedacf95ce49":{"s":"video","a":"references/role-modes.md","l":22,"t":"Every shot must answer at least one of these questions. If a shot answers none, delete it.","o":"auditoria"},"5c79b70fbb5a":{"s":"video","a":"references/role-modes.md","l":28,"t":"What does the viewer need to notice?","o":"auditoria"},"e47d5852520a":{"s":"video","a":"references/role-modes.md","l":47,"t":"Use one dominant director reference per scene. Translate into concrete camera, light, rhythm, blocking. Never stack three or more references.","o":"auditoria"},"d92564e28fe4":{"s":"video","a":"references/role-modes.md","l":68,"t":"Translate every beat into physical action the camera can see. Tag each beat with a shot function (see section 4). Every beat must have subtext.","o":"auditoria"},"9570d85c5b8a":{"s":"video","a":"references/role-modes.md","l":138,"t":"Every beat should carry at least one function tag. This is the editor's grammar.","o":"auditoria"},"85f471342e23":{"s":"video","a":"references/role-modes.md","l":153,"t":"A montage sequence can compress or loop. Use function tags to keep the structure readable even at high speed.","o":"auditoria"},"a84829cef94a":{"s":"video","a":"references/role-modes.md","l":155,"t":"Each tag is also a question the shot must answer. Establish. Where. Power. Who commands. Pressure. What pushes. Detail. What to notice. Reaction. What it cost. Shift. What changed inside. Impact. The moment. Aftermath. The residue. Exit. The image carried out.","o":"auditoria"},"dc069aea561b":{"s":"video","a":"references/seedance-25.md","l":52,"t":"Generation parameters (duration, aspect ratio, resolution) are set on the generation page or via API — **they do not belong in the prompt**. The 1.x/2.0 CLI tail (`--resolution ... --duration ...`) is not 2.5 syntax. Exception: in Ultra Long mode, restate duration and ratio at the top of the prompt.","o":"archivo"},"3c3a35bd5003":{"s":"video","a":"references/seedance-25.md","l":76,"t":"**Global tail.** Re-state the must-hold globals (camera position, environment, sound, lighting) and repeat the global bans.","o":"archivo"},"fe2010e7cd1e":{"s":"video","a":"references/seedance-25.md","l":82,"t":"2.5 has dedicated markers. Use them — do not describe audio in loose prose:","o":"archivo"},"5090be9f2dcb":{"s":"video","a":"references/seedance-25.md","l":103,"t":"The point of 50 slots is not dumping assets in. **Every material's role must be written in the prompt.** Do not rely on text labels inside images; do not make the model infer mappings.","o":"archivo"},"f4e68628a21b":{"s":"video","a":"references/seedance-25.md","l":115,"t":"**Bind each subject individually.** `<Character A> corresponds to @Image 1. Use only the appearance, hairstyle, and clothing.` The officially forbidden pattern: \"@Images 1 through 4 define four characters respectively\" — it never states which is which.","o":"archivo"},"1a73cf483aab":{"s":"video","a":"references/seedance-25.md","l":116,"t":"**Add exclusions** for anything that could bleed in: \"Do not use the image background.\" / \"Do not use the people in the image.\" / \"Do not use the person's identity, clothing, or scene from the video.\"","o":"archivo"},"8acb235535b4":{"s":"video","a":"references/seedance-25.md","l":117,"t":"**Do not restate what a reference already defines.** If a reference video defines the motion, state only which attributes to inherit — re-describing every action conflicts with the reference.","o":"archivo"},"9d8033a7fcbb":{"s":"video","a":"references/seedance-25.md","l":129,"t":"**Select references per scene**, not all at once: `Scene 1 | Use: <list>. Event: ... End state: ...`","o":"archivo"},"58c03455aad2":{"s":"video","a":"references/seedance-25.md","l":144,"t":"Divide the clip into consecutive stages. **One primary state change per stage, and always state the visible end state** — the end state is what the model steers toward (this is the U11 final-image rule, per stage).","o":"archivo"},"7e710b7de286":{"s":"video","a":"references/seedance-25.md","l":159,"t":"A time range is an event's **time budget, not an edit point**. Ranges must be consecutive and non-overlapping.","o":"archivo"},"2976ffd881f1":{"s":"video","a":"references/seedance-25.md","l":161,"t":"**One core action + one camera move per window.** Do not demand frequencies (\"three actions in one second\").","o":"archivo"},"83694d17ac4b":{"s":"video","a":"references/seedance-25.md","l":191,"t":"**The prohibition list is specific, not generic.** From the official farewell example: \"No exaggerated crying, no fast cuts, no large body movements, no extra dialogue, no BGM, no runny nose, no premature dropping of tears.\" Ban the exact ways this scene can collapse.","o":"archivo"},"4340f22ac789":{"s":"video","a":"references/seedance-25.md","l":225,"t":"Always attach the incantation: **\"prohibit rigid cutting, prohibit objects appearing out of thin air\"** — it is the official anti-jump-cut clause, repeated in every transition template.","o":"archivo"},"b93895a69273":{"s":"video","a":"references/seedance-25.md","l":227,"t":"Order-gate effects that must not fire early: \"The ink-wash effect must only appear AFTER 25 seconds, triggered by the 'click' sound — absolutely no premature appearance.\"","o":"archivo"},"e56653bec670":{"s":"video","a":"references/seedance-25.md","l":233,"t":"**Declare the physics regime up front.** \"Rain reflections on metal, water splashed by tires, and the specular refraction of exhaust flames must strictly obey real-world physics.\"","o":"archivo"},"809f55027421":{"s":"video","a":"references/seedance-25.md","l":234,"t":"**Narrate consequences, not just actions.** Tires kick up water curtains; the impact shatters the bridge into a spider-web pattern; the shockwave blows the rain away in a ring. Action chains where each step forces the next (\"hand grips jar → lid actually unscrews\") double as QA — a broken chain exposes a failed generation instantly.","o":"archivo"},"8870a91220dc":{"s":"video","a":"references/seedance-25.md","l":235,"t":"**Negatively constrain the known failure.** \"No soft-body or mollusk-like twisting of the mecha structure (must maintain metallic rigidity).\" \"The amber stays attached to the palm and must not clip through the fingers.\"","o":"archivo"},"5e9381b1532d":{"s":"video","a":"references/seedance-25.md","l":236,"t":"**Gate events on triggers.** \"Three seconds after she presses the button...\" / \"only when he says {now}...\" — triggers beat raw seconds for anything tied to performance.","o":"archivo"},"8dd832a85896":{"s":"video","a":"references/seedance-25.md","l":262,"t":"Any clip ≤30s extends by 4-30s per pass, nested repeatedly, **hard ceiling 60s**. The new prompt applies only to the appended segment; original frames are untouched. Required verbs: extend forward / extend backward / continue.","o":"archivo"},"324bcf02f62b":{"s":"video","a":"references/seedance-25.md","l":275,"t":"Backward (prepend a beginning): describe the preceding events, then define @Video 1's **first frame as the extension's explicit end state**. Gotcha: materials that belong to the source video only must be flagged — \"<X> must not appear early in the backward extension\" — or later characters leak into the past.","o":"archivo"},"3cc2915d07c9":{"s":"video","a":"references/seedance-25.md","l":279,"t":"Community-proven minimal extension prompt: \"Extend the video. Keep character identity, facial structure, body proportions, lighting, art style, and the space fully unchanged. Only change camera movement; do not redesign character or action.\"","o":"archivo"},"f0315e2411a6":{"s":"video","a":"references/seedance-25.md","l":285,"t":"**Timestamped** (1-minute ambient pieces): windowed beats with per-window bans — \"0-20s (quiet opening): fixed camera... no shake, no characters enter, hard cuts prohibited.\"","o":"archivo"},"ed4fbf774ee8":{"s":"video","a":"references/seedance-25.md","l":294,"t":"**Coarse blockout** — primitive geometry as a \"dynamic skeleton\" (trajectories, blocking, camera path, cuts, light changes). **Map every primitive to a reference**: \"The tall cylinder in @Video 1 corresponds to <Guide>. The rectangular block corresponds to <Display Cart>.\" Exclude the render style: \"Do not use its gray geometry or empty scene.\" Best practice: **no limbed or winged models in coarse","o":"archivo"},"7887bf99374c":{"s":"video","a":"references/seedance-25.md","l":295,"t":"**Fine blockout** — complete 3D animation; the model re-renders materials, color and style only: \"@Video 1 is a fine blockout reference. Preserve structure, action, spatial layout, camera position, camera movement, and cuts. Do not use its original gray materials or empty background. Re-render <subject> as <final subject>...\" **Clean the viewport capture first**: remove path lines, coordinate axes","o":"archivo"},"c8f9182dab48":{"s":"video","a":"references/seedance-25.md","l":306,"t":"**Storyboard grid as input**: one image, ≤15 panels official (practitioners have pushed 50), clean line art, minimal text. Declare the reading order and exclude the style: \"@Image 1 provides a 12-panel storyboard grid for shot order and approximate composition. Read it left to right, top to bottom. Do not use the grid's line-art style, text labels, or placeholder characters.\" Then `Shot 1: ... Sho","o":"auditoria"},"dbf4503191cb":{"s":"video","a":"references/seedance-25.md","l":307,"t":"**Multi-keyframe sequences**: \"Use @Image 1 through @Image N as keyframes in this order\", one key state per image. Independent images align better than a grid. Keyframes control stage order and key states, not exact frames.","o":"archivo"},"884b4b40911e":{"s":"video","a":"references/seedance-25.md","l":308,"t":"**First + last frame** works inside omni-reference mode — declare each anchor separately (\"@Image 1 is the first frame... @Image 2 is the last frame...\"), never jointly. Same aspect ratio required.","o":"archivo"},"877300b2ba56":{"s":"video","a":"references/seedance-25.md","l":314,"t":"Fix. Per-subject binding (section 5) + explicit differentiation: \"Their movements are not synchronized. Clothing colors, hairstyles, and facial features must all be distinct. No identical clones in the background.\"","o":"archivo"},"3b48069bb705":{"s":"video","a":"references/seedance-25.md","l":329,"t":"2.5 errs by commission: it completes more instructions than rivals but may cut freely even when told \"one continuous take\". Fix. \"One continuous shot, no cuts of any kind\" + a camera path that never motivates a cut; if montage keeps leaking in, drop to a 10-15s window where one-takes are stable.","o":"archivo"},"6eafd4ebaa95":{"s":"video","a":"references/seedance-25.md","l":336,"t":"Costs are real: a 30s/720p generation on Jimeng runs ~500-700 credits. Production budgets must assume re-rolls, extensions and segment reshoots — fix with edit/extend/reshoot instead of full regeneration whenever possible. Draft at 480p, finish at 720p.","o":"archivo"},"0395ddb6bd06":{"s":"video","a":"references/seedance.md","l":56,"t":"**Not 2.5 syntax.** On 2.5, duration / aspect ratio / resolution are set on the generation page or via API and do not belong in the prompt (exception: Ultra Long mode restates duration and ratio at the top — see `seedance-25.md` §2).","o":"archivo"},"73905921cedf":{"s":"video","a":"references/seedance.md","l":62,"t":"Seedance does not render abstractions. It renders **physical specifics**. Every adjective must be a sensory fact. Every emotion must be a body. Every shot must own at least three concrete details:","o":"archivo"},"a78b8143dfae":{"s":"video","a":"references/seedance.md","l":64,"t":"**One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC.","o":"archivo"},"809fb4ebddce":{"s":"video","a":"references/seedance.md","l":65,"t":"**One physical micro-action.** Jaw locks. Finger taps the counter. Knuckles whiten on the fork. Lips press into a line. He swallows hard.","o":"archivo"},"659a2eb38201":{"s":"video","a":"references/seedance.md","l":66,"t":"**One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in the dark phone screen. Rain hitting the same windowpane.","o":"archivo"},"ae09790a4e9b":{"s":"video","a":"references/seedance.md","l":70,"t":"Banned, lazy phrasing that produces mush:","o":"archivo"},"e30cec365a82":{"s":"video","a":"references/seedance.md","l":92,"t":"Write in full sentences, not tags. Seedance prefers clear grammatical prose. For dramatic / multi-shot / character-locked work, **use the production-grade skeleton in section 6 instead.**","o":"archivo"},"2d5229cb5344":{"s":"video","a":"references/seedance.md","l":96,"t":"Use this for any dramatic piece, multi-shot ad, music-video segment, or character-locked clip. Each block answers a specific failure mode. Skipping a block reintroduces that failure.","o":"archivo"},"b9c780304835":{"s":"video","a":"references/seedance.md","l":156,"t":"For a 5-second multi-shot clip, the model performs best with **5 shot beats** following a dramatic micro-arc. Use this timing as the default scaffold:","o":"auditoria"},"c6a20928bc70":{"s":"video","a":"references/seedance.md","l":170,"t":"Seedance reads explicit cut markers inside a single prompt and generates distinct shots connected by visible cuts. This is its strongest card. Use it when you need montage in a single generation.","o":"archivo"},"c3c3d1047037":{"s":"video","a":"references/seedance.md","l":196,"t":"Use 2-3 shots per 5-second clip for tight cinematic montage, 4-5 shot beats only when each beat is short and physically distinct (see section 7). Hard cap: 5 shots per generation — beyond that the model drops or compresses shots. Size the duration to the shot count (4 shots need 10-15s, not 5s). Every shot must share an anchor with its neighbors — same character, same location, or same lighting re","o":"auditoria"},"d629ec5811b5":{"s":"video","a":"references/seedance.md","l":216,"t":"Seedance 2.0 accepts image references inline using `@img1`, `@img2`, etc. Use this to lock the protagonist's likeness across all shots in a multi-shot clip and across multiple stitched clips.","o":"archivo"},"e57740e558ac":{"s":"video","a":"references/seedance.md","l":226,"t":"The full identity block must follow the `@img1` mention. The model needs the textual description as a backup signal — the image alone drifts.","o":"archivo"},"80e69a894fcc":{"s":"video","a":"references/seedance.md","l":252,"t":"Workaround for 1.x/2.0. Always invert to positive phrasing. Instead of \"no yellow tones\" write \"cold blue-gray palette with desaturated skin tones.\" Instead of \"no distorted hands\" write \"anatomically correct hands with clear finger separation.\"","o":"archivo"},"a75221469baa":{"s":"video","a":"references/seedance.md","l":254,"t":"**Seedance 2.5 fixed this.** Direct bans are reliable: \"pure video, no subtitles, no background music\" actually suppresses them, and specific prohibition lists (\"no exaggerated crying, no fast cuts\") are a core part of the official 2.5 prompt structure. See `seedance-25.md` §7.","o":"archivo"},"71fec8821328":{"s":"video","a":"references/seedance.md","l":258,"t":"When using a reference image, DO NOT describe elements already visible in the image. The model sees it. Describe only motion and camera work. Re-describing static elements creates identity drift.","o":"archivo"},"6b50e2278180":{"s":"video","a":"references/seedance.md","l":273,"t":"Dialogue goes in **double quotes** on 1.5/2.0 — the model voices it, generates the voice and syncs lips to the cut. State the delivery: \"Play her line dry and a little proud, his quiet and worn out.\" **On 2.5, use the dedicated markers instead**: dialogue in `{ }`, SFX in `< >`, music in `( )`, titles in `【 】` (see `seedance-25.md` §4).","o":"archivo"},"f1f0fcdff995":{"s":"video","a":"references/seedance.md","l":282,"t":"Fix. Add explicit \"Cut to\" markers. Say \"multi-shot sequence with visible hard cuts. Do not generate a single continuous take.\"","o":"archivo"},"27ee9fc25b00":{"s":"video","a":"references/seedance.md","l":294,"t":"Fix. Use positive substitutes. Seedance 1.0 has no negative parser.","o":"archivo"},"f4c2c207fbb8":{"s":"video","a":"references/seedance.md","l":306,"t":"Fix. Apply the Details Law (section 4). Audit your draft: every shot must have one environmental pressure, one micro-action, one sound or visual motif anchor. Replace adjectives like \"dramatic\", \"intense\", \"beautiful\" with concrete physical facts.","o":"archivo"},"e7caec8627aa":{"s":"video","a":"references/seedance.md","l":310,"t":"After the 2026 deepfake crackdown, 2.0 aggressively filters human faces, helmets, sunglasses, and anything resembling protected IP or celebrity likeness. Fix. Route face-heavy drama to Seedance 2.5 (realistic humans are its headline feature), 1.5 Pro, Kling, or Veo; keep 2.0 for scenes, architecture, product and montage work. Use only owned or synthetic character references — the IP/celebrity filt","o":"archivo"},"31550b84c066":{"s":"video","a":"references/seedance.md","l":314,"t":"A 15s narrative is **never** one prompt. It is three self-contained 5-second prompts, each with the full character lock, the full visual style, the full audio block, and a different dramatic function. Stitch in the editor.","o":"auditoria"},"dd071e4f1adc":{"s":"video","a":"references/seedance.md","l":401,"t":"For dramatic, multi-shot, character-locked, or stitched-clip work — always use the 11-block production-grade skeleton from section 6.","o":"archivo"},"1eff4afae0c5":{"s":"video","a":"references/universal-rules.md","l":9,"t":"The non-negotiable. Details intensify emotion (Details Law)","o":"archivo"},"90c9d01c7da9":{"s":"video","a":"references/universal-rules.md","l":33,"t":"**One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC. (Kurosawa: weather is a character. See `dramaturgy.md` §9.)","o":"archivo"},"3da18291f908":{"s":"video","a":"references/universal-rules.md","l":34,"t":"**One physical micro-action.** Jaw locks. Knuckles whiten on the fork. Lips press into a line. He swallows hard. Fingers curl against the doorframe. (Show, not tell — the body is the only place where feelings render.)","o":"archivo"},"01e778de1f4c":{"s":"video","a":"references/universal-rules.md","l":35,"t":"**One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in a darkened phone screen. Rain on the same windowpane. A single fluorescent flicker before each cut.","o":"archivo"},"d9efc3ad4bfb":{"s":"video","a":"references/universal-rules.md","l":39,"t":"Words that do not render and mark the writer being lazy:","o":"archivo"},"a4cd347f4b1e":{"s":"video","a":"references/universal-rules.md","l":85,"t":"Do not stack three camera moves in a 5-second clip. Pick one dominant move (dolly-in, pan, tracking, static). Layer a subtle micro-adjustment if needed (slight handheld shake, gentle rack focus). More than that produces visual chaos.","o":"archivo"},"c1d814f8c059":{"s":"video","a":"references/universal-rules.md","l":104,"t":"Identity block must include: face shape, eye color, skin tone. Hair color, length, style. Facial hair. Exact clothing items. Distinctive accessories.","o":"auditoria"},"e24b10c311e9":{"s":"video","a":"references/universal-rules.md","l":122,"t":"\"Loneliness\" does not render. \"A man sitting alone, shoulders collapsed, face lit by blue phone glow, empty bottles on the table\" does.","o":"archivo"},"9373adbe6c11":{"s":"video","a":"references/universal-rules.md","l":130,"t":"Most models work in 5-10 second clips. Longer narratives live in multiple clips stitched in the editor. Do not cram a 30-second story into a 5-second prompt.","o":"archivo"},"adbe90385564":{"s":"video","a":"references/universal-rules.md","l":154,"t":"Before returning the final prompt to the user, audit every shot. Each shot must carry at least one of each:","o":"archivo"},"75ec08f6c7e0":{"s":"video","a":"references/universal-rules.md","l":156,"t":"Environmental pressure (lighting, weather, surface, sound of the room).","o":"archivo"},"6f2d9a2fd7ba":{"s":"video","a":"references/universal-rules.md","l":157,"t":"Physical micro-action on the body (jaw, hand, breath, eye, gesture).","o":"archivo"},"e2b9c51c5ef7":{"s":"video","a":"references/universal-rules.md","l":158,"t":"Sound anchor or recurring visual motif tied to the emotional spine.","o":"archivo"},"f7ff7d98a4a9":{"s":"video","a":"references/universal-rules.md","l":160,"t":"If a shot has zero, fix it before sending. If a shot has only one, ask whether you can make it two without bloat. The strongest prompts in this skill's worked examples always have all three.","o":"archivo"},"51c07299485c":{"s":"video","a":"references/universal-rules.md","l":166,"t":"Wherever a model accepts reference assets (Seedance `@Image/@Video/@Audio`, Kling Element Binding and Omni references, Veo ingredients), **every asset gets an explicit role written in the prompt**: what it defines (appearance, motion, voice, scene, camera path) and what to ignore (\"Do not use the image background\", \"Do not use the people in the image\").","o":"archivo"},"2e0a56484152":{"s":"video","a":"references/universal-rules.md","l":168,"t":"Bind each subject individually: \"<Character A> corresponds to @Image 1 — use only the appearance, hairstyle, and clothing.\" Never the collective form \"@Images 1 through 4 define four characters respectively\" — it does not state which is which.","o":"archivo"},"21023b368ec1":{"s":"video","a":"references/universal-rules.md","l":169,"t":"Do not restate what a reference already defines. If a video reference carries the motion, name only the attributes to inherit; re-describing every action fights the reference.","o":"archivo"},"d1794addd647":{"s":"video","a":"references/universal-rules.md","l":178,"t":"The core subject that must survive every shot.","o":"archivo"},"0196c3f7220c":{"s":"video","a":"references/universal-rules.md","l":179,"t":"The key shots that must appear.","o":"archivo"},"da70b123efd4":{"s":"video","a":"references/universal-rules.md","l":180,"t":"The transitions where the model may freestyle.","o":"archivo"},"e21763705dd8":{"s":"video","a":"references/universal-rules.md","l":181,"t":"The mandatory final frame.","o":"archivo"},"dfcbb6dd0684":{"s":"video","a":"references/veo.md","l":95,"t":"Use labels `Audio:`, `Says:`, `SFX:` to separate sound direction from visual direction. The model needs an explicit signal that audio should be generated.","o":"archivo"},"a45ee38936f8":{"s":"video","a":"references/veo.md","l":99,"t":"Veo parses structured JSON. This prevents \"concept bleed\" where describing mood accidentally changes object colors. Use JSON for complex scenes with strict continuity needs.","o":"archivo"},"01a57763de37":{"s":"video","a":"references/veo.md","l":165,"t":"Complex props that must stay the same color and size.","o":"archivo"},"1c400db686fb":{"s":"video","a":"references/veo.md","l":176,"t":"Do not re-describe static elements.","o":"archivo"},"402a936cf3fe":{"s":"video","a":"references/veo.md","l":197,"t":"Use when you need a specific character in a specific place with a specific object.","o":"archivo"},"1a0831f5ce00":{"s":"video","a":"references/veo.md","l":207,"t":"Fix. Add explicit `Audio:`, `SFX:`, or `Says:` labels. Do not assume the model will infer audio from visual description.","o":"archivo"},"1dc7c87def16":{"s":"visual-asset-critic","a":"SKILL.md","l":24,"t":"**Two artifacts from every review, always both:** a human-readable markdown critique (the primary surface) and a machine-readable critique JSON (so a pipeline can gate on the verdict instead of parsing prose). The JSON is detailed in Step 6; it never replaces the markdown.","o":"archivo"},"c8195d96aaff":{"s":"visual-asset-critic","a":"SKILL.md","l":77,"t":"If you can't establish intent in one sentence, ask. Don't critique blind.","o":"archivo"},"0aebfb67e4fd":{"s":"visual-asset-critic","a":"SKILL.md","l":83,"t":"**Brand Lock**, does it respect palette, mood, \"never\" list?","o":"auditoria"},"3236a31aecea":{"s":"visual-asset-critic","a":"SKILL.md","l":84,"t":"**Series Lock**, does it match character/environment/lighting anchors?","o":"archivo"},"79f9fd6178a0":{"s":"visual-asset-critic","a":"SKILL.md","l":85,"t":"**Shot Spec**, does framing/angle/composition match the spec?","o":"auditoria"},"024638f7f93d":{"s":"visual-asset-critic","a":"SKILL.md","l":86,"t":"**Composition**, does it reserve space for on-screen text if applicable?","o":"auditoria"},"d0476aaa14d5":{"s":"visual-asset-critic","a":"SKILL.md","l":87,"t":"**Technical**, skin texture, hands, eyes, anatomy, AI artifacts?","o":"auditoria"},"4254cbeb01a9":{"s":"visual-asset-critic","a":"SKILL.md","l":88,"t":"**Continuity**, if previous shots in the series are available, does it match?","o":"archivo"},"4dabd7bdc618":{"s":"visual-asset-critic","a":"SKILL.md","l":94,"t":"For every \"not working\" point, the critique must say what to do about it. Three buckets:","o":"archivo"},"7eac9caa0ac8":{"s":"visual-asset-critic","a":"SKILL.md","l":102,"t":"**Re-roll required**, no prompt fix will help; the generator just produced a bad sample. Budget 2–3 attempts:","o":"archivo"},"c24705b39ede":{"s":"visual-asset-critic","a":"SKILL.md","l":145,"t":"**Provenance, all of it required at 1.1.** A verdict is a claim about specific bytes. Name","o":"archivo"},"fd33b1fe4a83":{"s":"visual-asset-critic","a":"SKILL.md","l":182,"t":"**Gating rule, the verdict is derived from severities, not chosen freely.** This guarantees the markdown verdict and the JSON verdict always agree:","o":"archivo"},"583d5f400a46":{"s":"visual-asset-critic","a":"SKILL.md","l":224,"t":"\"Looks great\" / \"feels off\" without specifics is not a critique. Every observation must reference something in the image (composition, color, anatomy, lighting direction, etc.).","o":"archivo"},"0cde22e1a93c":{"s":"visual-asset-critic","a":"SKILL.md","l":232,"t":"If the brief was \"founder at laptop, calm mood\" and the generation delivered exactly that, don't note that \"the room could be more visually interesting.\" That's scope creep, not critique.","o":"archivo"},"5b837820df26":{"s":"visual-asset-critic","a":"SKILL.md","l":236,"t":"Some failures (mangled hands, weird eye reflections, jewelry shimmer) are known generator weaknesses. Surface them as such, don't pretend a different prompt will fix them. Recommend re-roll or post.","o":"archivo"},"a221a716e952":{"s":"visual-asset-critic","a":"SKILL.md","l":240,"t":"Generation is one stage in a pipeline. If the image is 80% right and the gap is fixable in post, that's an ACCEPT with post notes. Don't send the user back to re-generate when an editor would handle it in 90 seconds.","o":"archivo"},"65ab63f3291c":{"s":"visual-asset-critic","a":"SKILL.md","l":276,"t":"If the verdict is REJECT, do not offer that. REJECT means a blocking issue or three or more","o":"archivo"},"c7b95c733b7f":{"s":"visual-asset-critic","a":"SKILL.md","l":281,"t":"Don't auto-revise. The user picks. The critique you just wrote is exactly what closes that","o":"archivo"},"147b5d10f118":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":40,"t":"never use stock photo aesthetic","o":"archivo"},"edb34335baee":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":41,"t":"never use AI uncanny faces","o":"auditoria"},"36f326b4fa1b":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":42,"t":"never over-saturate the cream background","o":"auditoria"},"6fcfbe5ad699":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":43,"t":"never use coral as a flood color (only as accent or signature periods)","o":"auditoria"},"e3d69437c2f6":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":44,"t":"never use em dashes in copy","o":"archivo"},"ff2826465af1":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":45,"t":"never use emojis in body copy","o":"archivo"},"bd1590a213fe":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":46,"t":"never use bullet points in narrative copy","o":"archivo"},"cf3ce4e1adaf":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":47,"t":"never use clip-art or generic icon sets","o":"auditoria"},"2ef7c79850da":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":48,"t":"never use hype words (\"game-changing\", \"revolutionary\", \"next-level\", \"comprehensive\")","o":"archivo"},"5d8f1227d198":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":49,"t":"never use exclamation points in headlines","o":"archivo"},"b1bf8c0bd438":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":50,"t":"never default to dark mode, light mode hybrid is the brand","o":"auditoria"},"2306baa11deb":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":51,"t":"never animate text with bouncing or wobbling, type-on, fade, or hard cut only","o":"auditoria"},"c2fbf1d46956":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":62,"t":"Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.","o":"archivo"},"8cb896ae3ca7":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":66,"t":"Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.","o":"auditoria"},"a3fa0f352d46":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":74,"t":"prefer specific numbers over vague claims","o":"archivo"},"c1ee0d0b5a80":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":75,"t":"prefer present-tense over future-tense","o":"archivo"},"650d25a8d091":{"s":"visual-asset-critic","a":"examples/worked-run/brand-lock.snapshot.md","l":76,"t":"prefer \"operator\" over \"creator\", \"infrastructure\" over \"agency\"","o":"archivo"},"1e898f2c0308":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":59,"t":"Technical hard fails are almost always **re-roll required**. The prompt was probably fine; the generator just produced a bad sample. Budget 2–3 re-rolls.","o":"archivo"},"31afcb61a699":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":101,"t":"Soft fails are noted but don't change the verdict on their own. If you have three or more of","o":"archivo"},"788f1a8f5595":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":107,"t":"**Don't critique what wasn't asked**, if the spec didn't call for cinematic mood, don't say \"could be more cinematic\"","o":"archivo"},"8014a721e61b":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":108,"t":"**Don't pile-on once verdict is set**, if you're rejecting, list the issues that drive the rejection; don't list every cosmetic concern","o":"archivo"},"9b616f961fba":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":109,"t":"**Be specific, always**, \"lighting is off\" is not a critique; \"key light is camera-right but series_lock says camera-left\" is","o":"archivo"},"b1bf47b129ef":{"s":"visual-asset-critic","a":"references/critique-rubric.md","l":111,"t":"**Distinguish prompt failure from generator failure**, if the prompt was fine and the generator produced garbage hands, that's \"re-roll required\", not \"fix the prompt\"","o":"archivo"},"73fe57cd2392":{"s":"visual-prompt-forge","a":"SKILL.md","l":21,"t":"If the user wants to build a storyboard from scratch (no shots.json yet), use `storyboard-architect` first, then chain into this skill.","o":"archivo"},"30bbbcefca75":{"s":"visual-prompt-forge","a":"SKILL.md","l":53,"t":"**Brand Lock**, palette, type, mood, \"never\" list (constant across project)","o":"archivo"},"3a6fba22ac13":{"s":"visual-prompt-forge","a":"SKILL.md","l":54,"t":"**Series Lock**, character/environment/lighting anchors (constant across storyboard)","o":"archivo"},"ea1a9a227c90":{"s":"visual-prompt-forge","a":"SKILL.md","l":55,"t":"**Shot Spec**, framing, angle, motion, subject (per shot)","o":"archivo"},"d584b5f6dd31":{"s":"visual-prompt-forge","a":"SKILL.md","l":56,"t":"**Text Layer**, **never in the prompt**, composited separately","o":"archivo"},"2ad7d2bd5837":{"s":"visual-prompt-forge","a":"SKILL.md","l":57,"t":"**Generator Adapter**, model-specific syntax wrapper","o":"archivo"},"409086978069":{"s":"visual-prompt-forge","a":"SKILL.md","l":100,"t":"Each adapter file documents the prompting style, parameter syntax, and known pitfalls for that generator. You **must** read the adapter before writing prompts for it. Don't guess from training data, image-gen syntax has churned multiple times.","o":"archivo"},"a8d68a296084":{"s":"visual-prompt-forge","a":"SKILL.md","l":122,"t":"**Strip any on_screen_text reference**, text never goes in the prompt","o":"archivo"},"24d0e917035e":{"s":"visual-prompt-forge","a":"SKILL.md","l":261,"t":"Colors come from the series_lock color_grade and the brand_lock palette. They get rendered into the prompt by the adapter. Don't write \"deep navy blazer\" in the shot subject if \"deep navy\" is already in the palette, that's a duplicated description and produces oversaturation.","o":"auditoria"},"4a9a9f1d1b5a":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":36,"t":"Flux handles **80–150 words** comfortably. Don't pad, but you have headroom Midjourney doesn't.","o":"archivo"},"cf6ea7ae4157":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":48,"t":"`shallow DOF` | `Shot at f/1.8 with shallow depth of field, background softly out of focus.`","o":"archivo"},"90c1b290af77":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":90,"t":"**Don't write \"highly detailed, 4k, masterpiece\"**, these are Stable Diffusion crutches. Flux ignores them and the line burns tokens","o":"archivo"},"c55494cbbad4":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":91,"t":"**Don't use weight syntax `(thing:1.4)`**. Flux 2 doesn't support it; Flux 1.1 partially does. Stick to natural language","o":"archivo"},"0447e389826e":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":92,"t":"**Don't enable prompt upsampling for series work**, fal.ai's auto-rewrite produces inconsistent shots","o":"archivo"},"d070363f06ff":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":93,"t":"**Don't include text content**, even if Flux 2 handles text better than Flux 1.1, composite separately for editability","o":"archivo"},"bc7cb8df5ee2":{"s":"visual-prompt-forge","a":"adapters/flux.md","l":94,"t":"**Don't omit the photoreal closing line**, the \"no AI artifacts\" anchor measurably reduces the AI-look","o":"archivo"},"3e22b4c62b1b":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":38,"t":"GPT Image handles **150–300 words** comfortably. Longer than other generators. Use the headroom for explicit spatial descriptions.","o":"archivo"},"4e37b6108b10":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":46,"t":"\"The subject's shoulders are angled 30 degrees toward the camera, face turned to look at the off-frame light source.\"","o":"auditoria"},"20ebea9d8a54":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":48,"t":"Use this when the shot's composition is load-bearing.","o":"archivo"},"226a236b4dcc":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":75,"t":"GPT Image handles text-in-image at roughly 95% accuracy, second only to Ideogram. When text is required:","o":"auditoria"},"fd93590ae5d9":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":86,"t":"**Don't write Midjourney-style comma stacks**. GPT Image parses them as a list of disconnected concepts","o":"archivo"},"b5fa2fb924bd":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":87,"t":"**Don't omit spatial language when the shot has specific composition**, you're paying for the model's strength; use it","o":"archivo"},"e1f3ed8e587b":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":88,"t":"**Don't pile too many objects**, five or fewer distinct elements per scene; more degrades fidelity","o":"archivo"},"a6bec722c41f":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":89,"t":"**Don't include `--ar` flags or weight syntax**. GPT Image ignores them","o":"archivo"},"d4f119799fc1":{"s":"visual-prompt-forge","a":"adapters/gpt-image.md","l":90,"t":"**Don't forget that GPT Image's \"AI look\" is real**, the closing \"natural skin texture, no AI rendering artifacts\" line meaningfully helps but isn't a complete fix. For pure photoreal, Flux is still stronger","o":"archivo"},"a5926981e848":{"s":"visual-prompt-forge","a":"adapters/hailuo.md","l":66,"t":"**Don't enable the prompt optimizer for series work.** Auto-rewrite breaks shot-to-shot consistency.","o":"archivo"},"c52dc68d0daf":{"s":"visual-prompt-forge","a":"adapters/hailuo.md","l":67,"t":"**Don't stack two camera moves.** One move per shot.","o":"archivo"},"4755505de7d6":{"s":"visual-prompt-forge","a":"adapters/hailuo.md","l":68,"t":"**Don't include text content.** Composite captions in post.","o":"auditoria"},"88ac8d8506e0":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":15,"t":"Use when the on-screen text is meant to appear as part of the image itself, a poster headline, a sign in the scene, a packaging label. This is the only case where a generator prompt contains the text content.","o":"auditoria"},"73aaed94b890":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":30,"t":"The exact text must be in straight double-quotes. Ideogram parses these as the text-render target.","o":"auditoria"},"8ad2673a7cf6":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":91,"t":"**Don't trust magic_prompt**, it auto-rewrites and produces inconsistent shots across a series","o":"archivo"},"83c574fc9ce5":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":92,"t":"**Don't pile multiple text elements in one prompt**. Ideogram handles one text element well, two becomes lottery, three is broken","o":"auditoria"},"e0e022e50a9e":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":93,"t":"**Don't use cursive/decorative fonts**, even Ideogram fails on these. Sans-serif and clean serif are reliable","o":"auditoria"},"22d09b130cbd":{"s":"visual-prompt-forge","a":"adapters/ideogram.md","l":94,"t":"**Don't forget seed**, for any series work, lock the seed at the storyboard level","o":"archivo"},"34c9774072b9":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":15,"t":"Camera motion goes **first**. This is the inverse of image generators where camera is implied. With video the camera's behaviour is the first thing the model must understand.","o":"archivo"},"a96d5275630a":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":26,"t":"`negative_prompt` | per series | Supported. Use to suppress drift, e.g. `extra fingers, warped face`","o":"archivo"},"c05a37e6c694":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":37,"t":"Kling handles **80–150 words** comfortably. Motion description adds a beat over a still prompt; do not pad past it.","o":"archivo"},"dd11b5da1036":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":73,"t":"Use `start_image` from the previous shot's accepted final frame to chain a sequence.","o":"archivo"},"1e43dbde9ec3":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":75,"t":"Do not flip lighting direction between consecutive shots (window-left stays window-left).","o":"archivo"},"5996725c4119":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":80,"t":"**Don't put camera motion at the end.** Kling parses motion best as the leading instruction.","o":"archivo"},"28b092664be0":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":81,"t":"**Don't request multiple camera moves in one shot.** Pick one; compound moves break.","o":"archivo"},"9d51ba168710":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":82,"t":"**Don't describe motion faster than the duration allows.** A slow dolly over 5s is plausible; over 1s it is jitter.","o":"archivo"},"3d67beea0470":{"s":"visual-prompt-forge","a":"adapters/kling.md","l":83,"t":"**Don't include text content.** Video text rendering is unreliable; composite or animate text in post.","o":"auditoria"},"35ad63b182a1":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":43,"t":"`shallow DOF` | `shallow depth of field, f/1.8, bokeh background`","o":"archivo"},"c51e98883ae8":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":97,"t":"**Don't use \"AI\" or \"rendered\"**, produces stylized outputs that look generated","o":"archivo"},"e6bae7347048":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":98,"t":"**Don't over-stack adjectives**, three adjectives per noun phrase max","o":"archivo"},"f85b78ac44b0":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":99,"t":"**Don't include text content**, even if the shot has `on_screen_text`, leave it out. Composited separately.","o":"archivo"},"8452bcb3abe4":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":100,"t":"**Don't use `--c` for series work**, chaos kills consistency","o":"archivo"},"3ac7c1186c62":{"s":"visual-prompt-forge","a":"adapters/midjourney.md","l":101,"t":"**Don't change `--seed` mid-storyboard**, set once at series_lock level","o":"archivo"},"43331142e7ea":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":101,"t":"**Don't use Midjourney-style flag syntax**. Nano Banana ignores `--ar`, expects `aspectRatio` parameter","o":"archivo"},"c169c881a0e6":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":102,"t":"**Don't expect Midjourney-level aesthetic by default**. Nano Banana is a workhorse, not a stylist. Stack mood adjectives explicitly","o":"archivo"},"03aa46d144b5":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":103,"t":"**Don't pile multiple modifications in one image-to-image prompt**, one change per pass produces cleaner results","o":"archivo"},"c4812cc96bc2":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":104,"t":"**Don't forget the \"preserve\" clause in image-to-image**, without it, Nano Banana treats the reference as loose inspiration and drifts","o":"archivo"},"5fc1cc954fb0":{"s":"visual-prompt-forge","a":"adapters/nano-banana.md","l":105,"t":"**Don't include text content in image prompts**, composite separately; text rendering is mediocre","o":"archivo"},"07771e486a77":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":74,"t":"**Don't force unrelated beats into one sequence.** Multi-shot is for shots that genuinely belong to one take.","o":"archivo"},"cee8c4cd6183":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":75,"t":"**Don't write more than ~4 cuts per generation.** Consistency degrades past that; split and assemble in edit.","o":"archivo"},"e84b5c0448b9":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":76,"t":"**Don't vary the character anchor between cuts.** Restate it once for the whole sequence, verbatim.","o":"archivo"},"98d91e461feb":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":77,"t":"**Don't include text content.** Composite captions from `text-overlays.json` in post.","o":"auditoria"},"750cf06a6b5c":{"s":"visual-prompt-forge","a":"adapters/seedance.md","l":78,"t":"**Don't stack two camera moves inside one cut.** One move per cut.","o":"archivo"},"5c181b49f9d4":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":38,"t":"**40–70 words per prompt**. Shorter than most. Don't pad.","o":"archivo"},"b58550816f3f":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":75,"t":"**Don't vary** the lighting language between shots, series_lock string in, no paraphrasing","o":"archivo"},"735b1edeccc3":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":80,"t":"**Don't write paragraphs**. Seedream wants comma-separated phrases","o":"archivo"},"8c221aa40298":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":81,"t":"**Don't use `--ar` syntax**, pass aspect_ratio as a parameter","o":"archivo"},"679f8c322dba":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":82,"t":"**Don't include text content**, text rendering is poor; composite separately","o":"archivo"},"3de5ebeb511c":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":83,"t":"**Don't expect Midjourney aesthetic**. Seedream produces clean but less art-directed output","o":"archivo"},"14306fa1f1c7":{"s":"visual-prompt-forge","a":"adapters/seedream.md","l":84,"t":"**Don't skip the seed lock for series work**, without it, character consistency breaks","o":"archivo"},"c962c96606da":{"s":"visual-prompt-forge","a":"adapters/veo.md","l":76,"t":"**Don't overrun the duration with dialogue.** A line that needs 12s of speech will clip or rush at 8s.","o":"archivo"},"1087e186fed5":{"s":"visual-prompt-forge","a":"adapters/veo.md","l":77,"t":"**Don't put on-screen text in the prompt.** Spoken lines are fine; rendered captions still come from `text-overlays.json` in post.","o":"auditoria"},"0acb882ac4aa":{"s":"visual-prompt-forge","a":"adapters/veo.md","l":78,"t":"**Don't stack two camera moves.** One move per shot.","o":"archivo"},"561e4601866e":{"s":"visual-prompt-forge","a":"adapters/veo.md","l":79,"t":"**Don't let Veo's auto-audio fight a post audio bed.** Pick one owner of sound per shot.","o":"archivo"},"00ad95b7807d":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":33,"t":"Same principle for `series_lock.lighting`. Lighting direction in particular is critical, flipping window-left to window-right between shots produces obvious cuts where there shouldn't be any.","o":"archivo"},"199cfb9ab91d":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":60,"t":"Generate the hero shot first (any shot, usually `shot_01` or whichever is most defining)","o":"auditoria"},"b2e806d6105a":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":61,"t":"Use that image as the reference for every subsequent shot","o":"auditoria"},"14c534d5e7f2":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":62,"t":"Each subsequent prompt has the verbatim character anchor PLUS the reference image link","o":"auditoria"},"926508430703":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":70,"t":"**This is the most effective lock for character consistency** in 2026. Use it whenever the storyboard features the same person across multiple shots.","o":"archivo"},"a0d393395e3a":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":74,"t":"When the storyboard has a distinctive visual style (specific film stock, specific lighting school, specific color theory), use a style reference image:","o":"archivo"},"4140ed69949c":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":84,"t":"A subtle one that breaks scenes when violated. If `series_lock.lighting` says \"soft natural side-light, large window LEFT\", then every shot's lighting must respect that direction.","o":"archivo"},"20b3434a9a5d":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":86,"t":"When a shot reverses character orientation (e.g., over-the-shoulder reverse), update the rationale to acknowledge the lighting flip:","o":"archivo"},"3b984b2349a3":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":113,"t":"A few things people try that don't actually fix consistency:","o":"archivo"},"0f136ad02a4a":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":115,"t":"**Adding \"consistent character\" or \"same person\" to the prompt**, generators don't read meta-instructions","o":"archivo"},"985e93f22844":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":116,"t":"**Numbering shots in the prompt** (\"shot 3 of 7, same as before\"), generators don't have memory across calls","o":"archivo"},"dd6e04a7a56e":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":118,"t":"**Asking for \"exactly the same\"**, there is no such thing in stateless image gen; you reduce drift, you don't eliminate it","o":"archivo"},"bfb6f1d9e6b2":{"s":"visual-prompt-forge","a":"references/consistency-locks.md","l":120,"t":"Accept that some shots will need re-rolls. Budget for it. The locks reduce the failure rate; they don't eliminate it.","o":"auditoria"},"2757ce63d7e2":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":19,"t":"Verify brand-lock \"never\" list is being applied, if it includes \"no AI uncanny\", surface that into the prompt","o":"archivo"},"8f8dc623566a":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":20,"t":"Use Flux 2 Pro or Midjourney v7 instead of cheaper models for hero shots","o":"archivo"},"b826ad9667a2":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":37,"t":"Use reference image after the first successful shot","o":"archivo"},"717c03da642d":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":39,"t":"For Midjourney, use `--cref` with `--cw 50`","o":"archivo"},"6447bec15b56":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":53,"t":"The right answer is almost always: **don't put text in the prompt**. Composite separately from `text-overlays.json`.","o":"archivo"},"359736f73561":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":54,"t":"If text must be in-image (poster work), use Ideogram v3 with explicit override flag","o":"archivo"},"5945d25c9b90":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":56,"t":"Use simple fonts (sans-serif, clean serif), cursive and decorative fonts fail even on Ideogram","o":"archivo"},"ecb6a8e221f1":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":87,"t":"For GPT Image (best at spatial reasoning), use percentage references: \"subject at left 30% of frame\"","o":"archivo"},"982752f60d62":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":122,"t":"**Accept editorially when:** generation is close enough that retouching gets there. Don't burn API credits chasing perfect on-prompt.","o":"archivo"},"1f983ff0ee18":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":128,"t":"You've re-rolled the same shot 5+ times with no improvement → the prompt is fine; the model can't render this concept; pick a different shot or different generator","o":"archivo"},"12009aa60167":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":129,"t":"You're tweaking single words and hoping → you've hit prompt-level diminishing returns; move to image-to-image refinement (Nano Banana) or post-production","o":"archivo"},"4be94337bb02":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":130,"t":"The image is 80% right and the gap is editorial → ship to post and let the editor finish","o":"archivo"},"33fc833724e0":{"s":"visual-prompt-forge","a":"references/failure-modes.md","l":132,"t":"Generation is one stage in a pipeline. Don't try to make it the whole pipeline.","o":"archivo"},"bcaac139f9b7":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":16,"t":"\"Never\" list (things this brand never does, e.g. \"no stock photo aesthetic\", \"no AI uncanny\", \"no over-saturated\", \"no shouting copy\")","o":"archivo"},"67037c4b307e":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":60,"t":"**Never appears in image prompts** (except Ideogram Mode 2 with explicit override).","o":"archivo"},"e177c4f10a04":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":64,"t":"**Editability.** Composited text can be revised without re-generating images.","o":"archivo"},"4c22b71ebf0a":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":65,"t":"**Quality.** Even Ideogram and GPT Image (the best at text) produce typography that lags professional design tools.","o":"archivo"},"5f5e6ee4ad91":{"s":"visual-prompt-forge","a":"references/prompt-anatomy.md","l":66,"t":"**Animation.** Animated text needs After Effects / Remotion / CapCut. Static rendered text is dead-on-arrival for motion content.","o":"archivo"}},"meta":{"reglas":852,"skills":11,"auditorias":343}};
const ETAPAS = D.etapas, CAT = Object.fromEntries(ETAPAS.map(e=>[e.clave,e]));
const $ = (s,r=document)=>r.querySelector(s);
const esc = s => String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const bytes = s => new TextEncoder().encode(s).length;
const uid = () => Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const nowIso = () => new Date().toISOString();
const MAX_BYTES = 62000;

// ------------------------------------------------------------ estado
let sample=null, db=null, mcp=null, caps={images:false};
let S = {proyectos:[], pid:null, view:'brief', imgs:[], busy:false, error:'', bloqueo:false, ajustes:{rondas:3, tierGen:'complex', tierAud:'default', rondasEval:1}};
// Nada de alert/confirm/prompt: dentro del visor de artifacts esos dialogos
// pueden estar bloqueados, y entonces el error no se ve por ningun lado.
function fallo(msg){ S.error=msg; render(); }
const P = () => S.proyectos.find(p=>p.id===S.pid);
const ajustesLS = 'ejecutor.ajustes';
try{ Object.assign(S.ajustes, JSON.parse(localStorage.getItem(ajustesLS)||'{}')); }catch(e){}

// ------------------------------------------------------------ persistencia
async function guardar(p){
  p.actualizado = nowIso();
  if(db){ try{ await db.doc('proyectos/'+p.id).set(p); return; }catch(e){ console.warn('db set',e); } }
  try{ localStorage.setItem('ejecutor.p.'+p.id, JSON.stringify(p)); }catch(e){}
}
async function cargarLista(){
  let lista=[];
  if(db){
    try{ const q = await db.collection('proyectos').orderBy('creado','desc').limit(100).get(); lista = q.docs.map(d=>d.data()); }
    catch(e){ console.warn('db list',e); }
  }
  if(!lista.length){
    for(let i=0;i<localStorage.length;i++){ const k=localStorage.key(i); if(k&&k.startsWith('ejecutor.p.')){ try{ lista.push(JSON.parse(localStorage.getItem(k))); }catch(e){} } }
    lista.sort((a,b)=>(b.creado||'').localeCompare(a.creado||''));
  }
  S.proyectos = lista;
}
function nuevoProyecto(){
  const p = {id:uid(), nombre:'Sin título', brief:'', creado:nowIso(), plan:null, etapas:{}, orden:[], evaluaciones:[]};
  S.proyectos.unshift(p); S.pid=p.id; S.imgs=[]; S.view='brief'; render();
}

// ------------------------------------------------------------ reglas
function reglasDe(casos){
  const ids = new Set();
  for(const c of casos||[]) for(const id of (D.porCaso[c]||[])) ids.add(id);
  const pri = {auditoria:0, regla:1, archivo:2};
  return [...ids].map(id=>({id, ...D.idx[id]})).sort((a,b)=>(pri[a.o]-pri[b.o])||a.s.localeCompare(b.s)||a.a.localeCompare(b.a)||a.l-b.l);
}
const lineaRegla = r => `- [${r.id}] (${r.s}) ${r.t}`;
function empacarReglas(reglas, presupuesto){
  const out=[]; let usado=0, n=0;
  for(const r of reglas){ const l=lineaRegla(r)+'\n'; const b=bytes(l); if(usado+b>presupuesto) break; out.push(l); usado+=b; n++; }
  return {texto:out.join(''), incluidas:n, total:reglas.length};
}
function tandasReglas(reglas, presupuesto){
  const tandas=[]; let cur=[], usado=0;
  for(const r of reglas){ const l=lineaRegla(r)+'\n'; const b=bytes(l); if(usado+b>presupuesto && cur.length){ tandas.push(cur.join('')); cur=[]; usado=0; } cur.push(l); usado+=b; }
  if(cur.length) tandas.push(cur.join(''));
  return tandas;
}
const corta = (s,n) => (s||'').length>n ? s.slice(0,n)+`\n[… recortado a ${n} caracteres]` : (s||'');

// ------------------------------------------------------------ prompts
function catalogoTexto(){
  return ETAPAS.map(e=>`- ${e.clave} · ${e.nombre}${e.cond?' — cuándo: '+e.cond:''}\n    entra: ${e.entra}\n    sale: ${e.sale}\n    gate: ${e.gate}\n    casos de reglas permitidos: ${e.casos.length?e.casos.join(', '):'ninguno (sin reglas de skill)'}${e.tracks.length?'\n    tracks: '+e.tracks.join(', '):''}${e.ok?'\n    requiere OK explícito del director antes de continuar':''}`).join('\n');
}
function casosTexto(){ return Object.entries(D.casos).filter(([k])=>k!=='NINGUNO').map(([k,v])=>`  ${k}: ${v} (${(D.porCaso[k]||[]).length} reglas)`).join('\n'); }

function promptPlan(p){
  return `Eres el director de producción de Final Upgrade AI. Recibes un BRIEF y decides qué etapas de trabajo hacen falta para entregarlo. No ejecutes ninguna etapa: solo planifica.

CATÁLOGO DE ETAPAS (usa solo estas claves, en el orden en que deben ejecutarse):
${catalogoTexto()}

TRACKS DE VIDEO:
${Object.entries(D.tracks).map(([k,v])=>`  ${k}: ${v}`).join('\n')}

CASOS DE PRODUCCIÓN (cada etapa toma las reglas de sus casos):
${casosTexto()}

REGLAS DE PLANIFICACIÓN:
- Un brief de una sola imagen → una sola etapa PROMPT_IMAGEN con el caso exacto (T1 rostro, T2 cuerpo, T3 escena con 1 persona, T4 con 2 personas, T5 edición, PROD producto sin persona, GRAF pieza gráfica, MULTI grid).
- Un brief que pide el prompt para recrear una imagen adjunta → REF (hay ${S.imgs.length} imagen(es) adjunta(s)).
- Un brief de un solo clip de video → PROMPT_VIDEO.
- Un brief de video completo (spot, campaña, reel con narrativa, brand film) → etapas E0–E7 según el track. E0 solo si hay marca o cliente. E5 lleva solo los casos de imagen que el proyecto necesita.
- Un brief que pide estrategia o plan de algo que no es una pieza visual → ESTRATEGIA, y DOC por cada entregable adicional que pida.
- Cada etapa lleva: objetivo específico para ESTE brief (no genérico), el entregable exacto, y de 3 a 6 criterios de aceptación verificables, escritos para que un auditor pueda marcarlos cumplido / no cumplido con evidencia textual.
- "formato" es el formato de entrega de la pieza y manda sobre todos los prompts. Dedúcelo del brief: 9:16 para TikTok, Reels y Shorts; 16:9 para YouTube y spot apaisado; 1:1 para post de feed; 4:5 para feed vertical de Instagram. Si el brief no lo dice, elige el que corresponde al medio que menciona y anótalo en "supuestos". "duracion" solo para video.
- "usaImagenes": true solo en etapas que necesitan ver las imágenes adjuntas.
- Si el brief es ambiguo, no preguntes: decide y anota el supuesto en "supuestos".
- Responde en español.

BRIEF:
<<<
${corta(p.brief, 30000)}
>>>

Responde SOLO con JSON con esta forma exacta:
{"nombre":"título corto del proyecto","tipo":"qué se va a producir","track":"EXPRESS|STANDARD|FILM|null","resumen":"2 líneas","formato":{"aspect":"9:16","resolucion":"1080x1920","duracion":"30s o null"},"supuestos":["..."],"etapas":[{"clave":"E5","nombre":"nombre para este proyecto","objetivo":"...","entregable":"...","casos":["T3"],"criterios":["..."],"usaImagenes":false}]}`;
}

const PARAMS = `
PARÁMETROS DE GENERACIÓN — obligatorios junto a CADA prompt de imagen o video.
Un prompt sin aspect ratio está incompleto y se rechaza. Debajo de cada bloque
de código va una línea rotulada "Parámetros de generación:" con modelo, aspect
ratio, resolución o tamaño en píxeles, y duración si es video.
Dónde se escribe cada parámetro depende del modelo, y equivocarse es un error:
- Midjourney los lee DENTRO del prompt, como \`--ar 9:16\`.
- Nano Banana ignora \`--ar\` dentro del prompt: espera el parámetro \`aspectRatio\`.
- Seedream ignora \`--ar\`: aspect_ratio va como parámetro.
- GPT Image ignora \`--ar\` y las banderas de peso: el tamaño va como parámetro
  (1024x1024, 1536x1024 apaisado, 1024x1536 vertical).
- Seedance 2.5: duración, aspect ratio y resolución se fijan en la página de
  generación o por API y NO van en el texto del prompt.
Cuando el parámetro no va dentro del prompt, se entrega igual en esa línea
aparte, diciendo que se fija en la página de generación.`;

function fmtTexto(p){
  const f = (p.plan&&p.plan.formato)||null;
  if(!f || !f.aspect) return 'sin definir — dedúcelo del brief y dilo explícitamente';
  return [f.aspect, f.resolucion, f.duracion].filter(Boolean).join(' · ');
}

function contextoAprobado(p, hastaKey, limite){
  const partes=[]; let usado=0;
  for(const k of p.orden){ if(k===hastaKey) break; const e=p.etapas[k]; if(!e||!e.output||!['aprobada','espera_ok'].includes(e.estado)) continue;
    const t = `## ${e.nombre} (${e.clave})\n${e.output}\n`; partes.push(t); usado+=t.length; }
  let s = partes.join('\n');
  if(s.length>limite){ s = s.slice(s.length-limite); s = '[… contexto anterior recortado]\n'+s; }
  return s;
}

function promptEtapa(p, e, correcciones, feedback){
  const cat = CAT[e.clave]||{};
  const fijo = `Eres el ejecutor de la etapa "${e.nombre}" (${e.clave}: ${cat.nombre||''}) de un pipeline de producción visual con IA. Tu objetivo es maximizar la calidad del entregable, nunca ahorrar esfuerzo. Este entregable será auditado contra cada criterio y cada regla listada abajo; lo que no cumpla se rechaza y se vuelve a pedir.

BRIEF DEL PROYECTO:
<<<
${corta(p.brief, 20000)}
>>>

OBJETIVO DE ESTA ETAPA: ${e.objetivo}
ENTREGABLE EXACTO: ${e.entregable}
FORMATO DE ENTREGA DEL PROYECTO: ${fmtTexto(p)}
QUÉ SALE SEGÚN EL SKILL: ${cat.sale||''}
GATE DE LA ETAPA: ${cat.gate||''}
CRITERIOS DE ACEPTACIÓN:
${(e.criterios||[]).map((c,i)=>`${i+1}. ${c}`).join('\n')}
${feedback?`\nINSTRUCCIONES DEL DIRECTOR PARA ESTA ITERACIÓN (obligatorias):\n${feedback}\n`:''}${correcciones&&correcciones.length?`\nCORRECCIONES OBLIGATORIAS — el auditor rechazó la versión anterior por esto; cada punto debe quedar resuelto:\n${correcciones.map(f=>`- [${f.ref}] ${f.correccion}${f.evidencia?' (evidencia: '+f.evidencia+')':''}`).join('\n')}\n`:''}
FORMATO DE SALIDA: Markdown en español. Los prompts finales para modelos de imagen o video van en inglés, cada uno dentro de un bloque de código, precedido de su cabecera de 3 líneas SKILL: / RIESGOS: / TÉCNICA: y del modelo recomendado. Sin disculpas, sin preámbulos, sin resumen final: solo el entregable completo.
${PARAMS}
`;
  const ctx = contextoAprobado(p, e.key, 14000);
  const ctxTxt = ctx ? `\nCONTEXTO APROBADO DE ETAPAS ANTERIORES (es la fuente de verdad; no lo contradigas):\n${ctx}\n` : '';
  const reglas = reglasDe(e.casos);
  const cabecera = `REGLAS OBLIGATORIAS DE LOS SKILLS (casos ${(e.casos||[]).join(', ')||'ninguno'}):\n`;
  const presupuesto = MAX_BYTES - bytes(fijo) - bytes(ctxTxt) - bytes(cabecera) - 800;
  const pack = empacarReglas(reglas, Math.max(presupuesto, 0));
  const nota = pack.incluidas<pack.total ? `(caben ${pack.incluidas} de ${pack.total}; el resto se verifica en la auditoría)\n` : '';
  return {prefijo: reglas.length ? cabecera+nota+pack.texto : '', texto: fijo + ctxTxt,
          incluidas:pack.incluidas, total:pack.total};
}

function promptAuditoria(p, e, output, tanda, i, n){
  const prefijo = tanda ? `REGLAS A VERIFICAR (tanda ${i} de ${n}):\n${tanda}` : '';
  const texto = `Eres el auditor de calidad de la etapa "${e.nombre}" (${e.clave}). Tu única tarea es verificar si el ENTREGABLE cumple los CRITERIOS y las REGLAS. No lo reescribas ni lo mejores. Está prohibido aprobar para complacer: si una regla aplicable a este entregable no se cumple, es una falla. Una regla que no aplica a este tipo de entregable no es falla. Cada falla lleva la referencia (id de regla o número de criterio), evidencia textual (cita del entregable, o "ausente" si falta algo obligatorio) y una corrección concreta que el ejecutor pueda aplicar sin adivinar.

BRIEF (resumen): ${corta(p.brief, 3000)}
OBJETIVO DE LA ETAPA: ${e.objetivo}
ENTREGABLE ESPERADO: ${e.entregable}
GATE: ${(CAT[e.clave]||{}).gate||''}
CRITERIOS:
${(e.criterios||[]).map((c,k)=>`${k+1}. ${c}`).join('\n')}

CHEQUEO OBLIGATORIO, ADEMÁS DE LOS CRITERIOS: si el entregable contiene uno o más
prompts de imagen o video, cada uno debe traer su línea de "Parámetros de
generación" con modelo, aspect ratio, resolución o tamaño, y duración si es
video, coherentes con el formato de entrega del proyecto (${fmtTexto(p)}).
Un prompt sin aspect ratio es una falla con ref "FORMATO". Además es falla usar
\`--ar\` con Nano Banana, Seedream o GPT Image, que lo ignoran, o meter duración,
aspect ratio o resolución dentro del texto del prompt en Seedance 2.5, donde se
fijan en la página de generación.

${tanda?'Las reglas a verificar están listadas arriba.':'(esta etapa no tiene reglas de skill; audita solo los criterios)'}

ENTREGABLE A AUDITAR:
<<<
${corta(output, 24000)}
>>>

Responde SOLO con JSON: {"veredicto":"APRUEBA"|"RECHAZA","fallas":[{"ref":"id de regla o C1..C6","evidencia":"...","correccion":"..."}],"nota":"una línea"}`;
  return {prefijo, texto};
}

// Dentro del visor de artifacts no hay cache de prefijo: ahi el bloque de
// reglas se concatena, que es lo que ya se hacia. Con servidor propio va
// aparte y marcado, y la API lo lee de cache.
function conPrefijo(pr, o){
  return SRV ? [pr.texto, Object.assign({}, o||{}, {cachePrefix:pr.prefijo})]
             : [(pr.prefijo? pr.prefijo+'\n\n':'') + pr.texto, o];
}

function promptEvalImagen(p, refTexto, nImgs){
  return `Eres el evaluador de assets de Final Upgrade AI. Se adjuntan ${nImgs} imagen(es) generadas con IA. Evalúa si cumplen con el BRIEF y con lo APROBADO. Sé específico y visual: describe lo que ves antes de juzgar. Prohibido aprobar para complacer.

BRIEF:
<<<
${corta(p.brief, 12000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
RÚBRICA: fidelidad al brief · identidad y consistencia de personajes/marca · composición y lente · luz y color · legibilidad de texto si lo hay · artefactos de IA (manos, ojos, texto roto, geometría imposible, superficies plásticas) · lo que un cliente notaría primero.

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"descripcion":"qué se ve, 2-3 líneas","criterios":[{"criterio":"...","cumple":true|false,"evidencia":"..."}],"correcciones":["instrucción concreta para el siguiente intento"],"prompt_ajustado":"si aplica, el cambio de prompt sugerido en inglés"}`;
}

function promptEvalVideo(p, refTexto, escenas){
  const esc = escenas.map(s=>`Escena ${s.scene_number} [${s.timestamp_start}–${s.timestamp_end}] ${s.label||''} · ${s.shot_type||''}\n  visual: ${s.visual}\n  audio: ${s.audio||'—'}`).join('\n');
  return `Eres el evaluador de video de Final Upgrade AI. Un analizador externo describió el video escena por escena (abajo). Con esa descripción, evalúa si el video cumple con el BRIEF y con lo APROBADO. Prohibido aprobar para complacer. Si la descripción no permite verificar un criterio, dilo como "no verificable" en vez de suponer.

BRIEF:
<<<
${corta(p.brief, 10000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
ANÁLISIS ESCENA POR ESCENA:
${corta(esc, 20000)}

RÚBRICA: fidelidad al brief y a los shots aprobados · continuidad de personajes, vestuario y entorno entre escenas · cámara y ritmo · dramaturgia (¿hay cambio de emoción, avance o presión?) · texto en pantalla y audio · artefactos de IA (morphing, manos, física imposible).

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"criterios":[{"criterio":"...","cumple":true|false|null,"evidencia":"..."}],"por_escena":[{"escena":1,"nota":"..."}],"correcciones":["..."]}`;
}

function promptEvalCuadros(p, refTexto, tiempos){
  return `Eres el evaluador de video de Final Upgrade AI. Se adjuntan ${tiempos.length} cuadros extraídos del mismo video, en orden, en estos segundos: ${tiempos.map(t=>t.toFixed(1)+'s').join(', ')}. Son muestras, no el video completo: no puedes juzgar movimiento continuo ni audio, y lo que no puedas verificar con los cuadros dilo como "no verificable" en vez de suponerlo.

BRIEF:
<<<
${corta(p.brief, 10000)}
>>>
${refTexto?`\nLO APROBADO (estrategia, shots, prompts):\n<<<\n${refTexto}\n>>>\n`:''}
RÚBRICA: fidelidad al brief y a los shots aprobados · continuidad de personaje, vestuario y entorno entre cuadros · encuadre y composición · luz y color · texto en pantalla · artefactos de IA (manos, ojos, texto roto, morphing entre cuadros).

Responde SOLO con JSON: {"veredicto":"CUMPLE"|"PARCIAL"|"NO CUMPLE","puntaje":0-100,"descripcion":"qué se ve, 2-3 líneas","criterios":[{"criterio":"...","cumple":true|false|null,"evidencia":"..."}],"por_escena":[{"escena":"0.0s","nota":"..."}],"correcciones":["..."]}`;
}

function referenciaAprobada(p){
  const partes=[];
  for(const k of p.orden){ const e=p.etapas[k]; if(e&&e.output&&e.estado==='aprobada') partes.push(`## ${e.nombre}\n${e.output}`); }
  return corta(partes.join('\n\n'), 18000);
}

// ------------------------------------------------------------ servidor propio (Vercel)
// Dentro de claude.ai la pagina usa las capacidades del visor. Servida desde
// un dominio propio no hay visor: se habla con /api/sample, que corre en el
// servidor con la API key del proyecto.
let SRV=null;
const claveLS='ejecutor.clave';
async function detectarServidor(){
  if(!/^https?:$/.test(location.protocol)) return null;
  try{ const r=await fetch('/api/config',{cache:'no-store',headers:cabeceras()}); if(!r.ok) return null; const j=await r.json(); return j&&j.servidor?j:null; }catch(e){ return null; }
}
function claveGuardada(){ try{ return localStorage.getItem(claveLS)||''; }catch(e){ return ''; } }
function cabeceras(){ const h={'Content-Type':'application/json'}; const k=claveGuardada(); if(k) h['x-app-password']=k; return h; }
async function probarClave(k){
  try{ const r=await fetch('/api/config',{cache:'no-store',headers:{'x-app-password':k}}); if(!r.ok) return null; return await r.json(); }catch(e){ return null; }
}
// El cuerpo de una peticion a Vercel no puede pasar de 4.5 MB — medido: hasta
// 4.0 MB pasa, 4.4 MB devuelve FUNCTION_PAYLOAD_TOO_LARGE. Base64 infla un
// tercio. Asi que las imagenes se reducen aqui hasta que el total quepa, y si
// no cabe no se manda: rebotar con 413 no le sirve a nadie.
const PRESUPUESTO = 3200000;                                   // base64, total
const PASOS = [[1568, 0.85], [1100, 0.8], [800, 0.72], [560, 0.6]];

async function aBitmap(blob){
  try{ return await createImageBitmap(blob, {imageOrientation:'from-image'}); }
  catch(e){ try{ return await createImageBitmap(blob); }catch(e2){ return null; } }
}
function b64de(buf){
  let bin=''; const b=new Uint8Array(buf);
  for(let i=0;i<b.length;i+=0x8000) bin+=String.fromCharCode.apply(null,b.subarray(i,i+0x8000));
  return btoa(bin);
}
async function codificar(bmp, lado, calidad){
  const k=Math.min(1, lado/Math.max(bmp.width,bmp.height));
  const w=Math.max(1,Math.round(bmp.width*k)), h=Math.max(1,Math.round(bmp.height*k));
  const c=document.createElement('canvas'); c.width=w; c.height=h;
  c.getContext('2d').drawImage(bmp,0,0,w,h);
  return await new Promise(r=>c.toBlob(r,'image/jpeg',calidad));
}
// Devuelve { imagenes, avisos }. Nunca devuelve algo que no quepa.
async function prepararImagenes(archivos){
  const avisos=[], bmps=[];
  for(const f of archivos||[]){
    const bm = await aBitmap(f);
    if(!bm){ avisos.push(`"${f.name}": el navegador no puede leer este formato. Si es HEIC (el de iPhone y Mac por defecto), ábrela y expórtala como JPG.`); continue; }
    bmps.push({bm, nombre:f.name});
  }
  if(!bmps.length) return {imagenes:[], avisos};
  let blobs=null;
  for(const [lado,cal] of PASOS){
    blobs = [];
    for(const x of bmps) blobs.push(await codificar(x.bm, lado, cal));
    if(blobs.reduce((t,b)=>t+b.size,0)*4/3 <= PRESUPUESTO) break;
  }
  // Ni en el paso mas chico caben todas: se mandan las que quepan y se avisa.
  const usados=[]; let total=0;
  for(let i=0;i<blobs.length;i++){
    const peso = blobs[i].size*4/3;
    if(total+peso > PRESUPUESTO){
      avisos.push(`"${bmps[i].nombre}" no se envió: entre todas superan el límite de 4.5 MB del servidor. Manda menos imágenes por vez.`);
      continue;
    }
    total+=peso; usados.push(blobs[i]);
  }
  const imagenes=[];
  for(const b of usados) imagenes.push({media_type:'image/jpeg', data:b64de(await b.arrayBuffer())});
  for(const x of bmps) if(x.bm.close) x.bm.close();
  return {imagenes, avisos};
}

function parseJSONsuelto(txt){
  const t=(txt||'').trim();
  try{ return JSON.parse(t); }catch(e){}
  const f=/```(?:json)?\s*([\s\S]*?)```/.exec(t); if(f){ try{ return JSON.parse(f[1]); }catch(e){} }
  const i=Math.min(...[t.indexOf('{'),t.indexOf('[')].filter(x=>x>=0)), j=Math.max(t.lastIndexOf('}'),t.lastIndexOf(']'));
  if(isFinite(i)&&j>i){ try{ return JSON.parse(t.slice(i,j+1)); }catch(e){} }
  throw {code:'invalid_json', message:'La respuesta no traía JSON.', text:txt};
}
function sampleDeServidor(){
  const f = async (input, o={}) => {
    const cuerpo = {input, modelTier:o.modelTier||'default'};
    if(o.cachePrefix) cuerpo.cachePrefix=o.cachePrefix;
    if(o.images && o.images.length){
      const prep = await prepararImagenes([...o.images]);
      if(prep.imagenes.length) cuerpo.images = prep.imagenes;
      if(prep.avisos.length){
        if(!prep.imagenes.length) throw {code:'image_rejected', message:prep.avisos.join(' ')};
        S.error = prep.avisos.join(' ');
      }
    }
    const crudo = JSON.stringify(cuerpo);
    if(crudo.length > 4000000) throw {code:'prompt_too_large', message:'La petición pesa '+(crudo.length/1048576).toFixed(1)+' MB y el servidor acepta 4.5 MB. Quita alguna imagen o acorta el brief.'};
    let r;
    try{ r = await fetch('/api/sample',{method:'POST',headers:cabeceras(),body:crudo,signal:o.signal}); }
    catch(e){ throw (o.signal&&o.signal.aborted) ? {code:'cancelled',message:'Detenido.'} : {code:'upstream_error', message:'No se pudo llegar al servidor.'}; }
    if(r.status===401){ S.bloqueo=true; render(); throw {code:'not_granted', message:'La contraseña de la app cambió. Vuelve a escribirla.'}; }
    if(r.status===413) throw {code:'prompt_too_large', message:'Las imágenes pesan demasiado para el servidor. Recarga la página y vuelve a adjuntarlas: la versión nueva las reduce automáticamente.'};
    if(!r.ok){ let j={}; try{ j=await r.json(); }catch(e){} throw {code:j.code||'upstream_error', message:j.message||('El servidor respondió '+r.status)}; }
    const rd=r.body.getReader(), dec=new TextDecoder(); let buf='', texto='', pensando='', trunc=false, err=null;
    for(;;){
      let chunk; try{ chunk=await rd.read(); }catch(e){ throw {code:'cancelled', message:'Detenido.', text:texto}; }
      if(chunk.done) break;
      buf+=dec.decode(chunk.value,{stream:true});
      let k;
      while((k=buf.indexOf('\n\n'))>=0){
        const linea=buf.slice(0,k).replace(/^data:\s?/,''); buf=buf.slice(k+2);
        if(!linea) continue;
        let ev; try{ ev=JSON.parse(linea); }catch(e){ continue; }
        if(ev.t==='text'){ texto+=ev.d; if(o.onText) o.onText({text:texto, delta:ev.d}); }
        else if(ev.t==='think'){ pensando+=ev.d; if(o.onThink) o.onThink({text:pensando}); }
        else if(ev.t==='done'){ trunc=!!ev.truncated; if(ev.usage&&o.onUso) o.onUso(ev.usage); }
        else if(ev.t==='error'){ err={code:ev.code, message:ev.message, text:texto||undefined}; }
      }
    }
    if(err) throw err;
    if(!texto.trim()) throw {code:'empty_completion', message:'El modelo no escribió nada.'};
    return {text:texto, truncated:trunc};
  };
  f.json = async (input,o) => parseJSONsuelto((await f(input,o)).text);
  f.limits = async () => ({maxPromptBytes:65536, images:{maxCount:8, maxInputBytes:20000000, mediaTypes:['image/jpeg','image/png','image/webp','image/gif']}});
  return f;
}

function motivoSinClaude(){
  if(SRV && !SRV.ia) return 'El servidor no tiene OPENAI_API_KEY configurada. Ponla en las variables de entorno del proyecto de Vercel y vuelve a desplegar.';
  if(SRV) return 'El servidor no respondió. Recarga la página.';
  if(window.claude && window.claude.use) return 'Esta página no tiene permiso para usar Claude. Vuelve a abrir el artifact desde el enlace original; si sigue igual, hay que volver a publicarlo declarando la capacidad sample.';
  return 'Esta copia de la página no está conectada a Claude. Ábrela desde el artifact en claude.ai o desde el dominio donde está desplegada.';
}

// ------------------------------------------------------------ llamadas
function errMsg(e){
  const m = {not_granted:'No autorizaste el uso del modelo en esta página.', rate_limited:'Límite de uso alcanzado. Espera un momento y vuelve a intentar.', prompt_too_large:'El brief o el contexto es demasiado grande para una llamada.', invalid_json:'La respuesta no vino en el formato esperado. Vuelve a intentar.', refused:'El modelo rechazó esta entrada. Cambia el brief.', cancelled:'Detenido.', images_unavailable:'Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en https://ai-production-director.vercel.app', image_rejected:'Imagen rechazada: tipo o tamaño no válido.', sampling_disabled:'El modelo no está disponible en esta cuenta.'};
  // Cuando el mensaje lo escribio esta pagina (nombra el archivo, el peso, el
  // formato), gana sobre el texto generico del codigo.
  if(e && e.message && ['image_rejected','prompt_too_large','upstream_error','not_granted'].includes(e.code) && e.message.length>40) return e.message;
  return m[e&&e.code] || ((e&&e.message)||'Error inesperado.');
}
let ctl=null; const VOZ={rec:null};
// Una llamada con esfuerzo alto tarda minutos y pasa el primer tramo pensando
// en silencio. Sin un contador corriendo, eso se lee como una app trabada.
let RELOJ=null, T0=0;
function relojOn(){ T0=Date.now(); clearInterval(RELOJ); RELOJ=setInterval(()=>{
  const t=Math.round((Date.now()-T0)/1000);
  const txt = t<60 ? t+'s' : Math.floor(t/60)+'m '+String(t%60).padStart(2,'0')+'s';
  document.querySelectorAll('.reloj').forEach(el=>el.textContent=txt);
},1000); }
function relojOff(){ clearInterval(RELOJ); RELOJ=null; }
function opts(tier, extra){ ctl = new AbortController(); return Object.assign({modelTier:tier, cache:false, signal:ctl.signal}, extra||{}); }

async function planificar(){
  const p=P(); if(!p) return;
  if(!p.brief.trim()) return fallo('Escribe el brief primero.');
  if(!sample) return fallo(motivoSinClaude());
  S.error=''; S.busy='Leyendo el brief…'; render();
  try{
    relojOn();
    const paso = m => { S.busy=m; const el=$('#busyN'); if(el) el.textContent=m; };
    const o = opts(S.ajustes.tierGen, {
      onThink:({text})=>paso('Pensando el plan… '+text.length+' caracteres'),
      onText:({text})=>paso('Escribiendo el plan… '+text.length+' caracteres'),
    });
    if(S.imgs.length) o.images = S.imgs.slice(0, (caps.images&&caps.images.maxCount)||S.imgs.length);
    const plan = await sample.json(promptPlan(p), o);
    if(!plan||!Array.isArray(plan.etapas)||!plan.etapas.length) throw {code:'invalid_json', message:'sin etapas'};
    p.plan = plan; if(plan.nombre) p.nombre = plan.nombre;
    p.orden=[]; p.etapas={};
    plan.etapas.forEach((e,i)=>{ const key=`${e.clave}_${i}`; const cat=CAT[e.clave]||{}; const casos=(e.casos||[]).filter(c=>(cat.casos||[]).includes(c)); p.orden.push(key);
      p.etapas[key]={key, clave:e.clave, nombre:e.nombre||cat.nombre||e.clave, objetivo:e.objetivo||'', entregable:e.entregable||cat.sale||'', casos: casos.length?casos:(cat.casos||[]).slice(0, cat.clave==='E5'?0:99), criterios:e.criterios||[], usaImagenes:!!e.usaImagenes, ok:!!cat.ok, estado:'pendiente', output:'', rondas:[], feedback:''}; });
    S.view='plan'; await guardar(p);
  }catch(e){ S.error=errMsg(e); }
  relojOff(); S.busy=false; render();
}

async function ejecutarEtapa(key){
  const p=P(); const e=p.etapas[key]; if(!e||!sample) return;
  const max = Number(S.ajustes.rondas)||3;
  let correcciones = e.rondas.length && e.estado==='agotada' ? (e.rondas[e.rondas.length-1].fallas||[]) : [];
  let ronda = e.estado==='agotada' ? e.rondas.length : 0;
  if(e.estado!=='agotada'){ e.rondas=[]; }
  const feedback = e.feedback||'';
  const limite = ronda+max;
  while(ronda<limite){
    ronda++;
    e.estado='generando'; e.progreso=`ronda ${ronda} · generando`; e.parcial=''; relojOn(); render(); await guardar(p);
    const tRonda = Date.now();
    const pr = promptEtapa(p, e, correcciones, feedback);
    e.reglasIncluidas=pr.incluidas; e.reglasTotal=pr.total;
    let out, uso=null;
    try{
      const pinta = t => { e.parcial=t; const el=$(`#parcial-${key}`); if(el) el.textContent=t; };
      const o = opts(S.ajustes.tierGen, {
        onThink:({text})=>{ e.progreso=`ronda ${ronda} · pensando`; pinta(text); },
        onText:({text})=>{ e.progreso=`ronda ${ronda} · escribiendo`; pinta(text); },
        onUso:u=>{ uso=u; },
      });
      if(e.usaImagenes && S.imgs.length) o.images = S.imgs.slice(0, (caps.images&&caps.images.maxCount)||S.imgs.length);
      const r = await sample(...conPrefijo(pr, o)); out = r.text; if(r.truncated) out += '\n\n[SALIDA TRUNCADA por el límite del modelo]';
    }catch(err){ relojOff(); e.estado = e.output?'rechazada':'pendiente'; e.error=errMsg(err); e.parcial=''; render(); await guardar(p); return; }
    e.parcial='';
    // auditoría en tandas: cubre el 100% de las reglas del caso
    e.estado='auditando'; render();
    const reglas = reglasDe(e.casos);
    const tandas = reglas.length ? tandasReglas(reglas, 22000) : [''];
    let fallas=[], veredicto='APRUEBA', notas=[];
    // Las tandas son independientes: en serie multiplican la espera por nada.
    e.progreso=`ronda ${ronda} · auditando ${tandas.length} tanda(s) de reglas`; render();
    const ctlAud=new AbortController(); ctl=ctlAud;
    const res = await Promise.all(tandas.map((t,i)=>
      sample.json(...conPrefijo(promptAuditoria(p, e, out, t, i+1, tandas.length),
                  {modelTier:S.ajustes.tierAud, cache:false, signal:ctlAud.signal}))
        .then(a=>({a})).catch(err=>({err, i}))));
    for(const r of res){
      if(r.err){ notas.push('auditoría '+(r.i+1)+' falló: '+errMsg(r.err)); continue; }
      const a=r.a;
      if(a && a.veredicto==='RECHAZA') veredicto='RECHAZA';
      if(a && Array.isArray(a.fallas)) fallas.push(...a.fallas.filter(f=>f&&(f.correccion||f.ref)));
      if(a && a.nota) notas.push(a.nota);
    }
    if(veredicto==='APRUEBA' && fallas.length) veredicto='RECHAZA';
    e.rondas.push({n:ronda, veredicto, fallas, notas, fecha:nowIso(), palabras:out.split(/\s+/).length,
                   cache: (uso&&uso.cache_read_input_tokens)||0,
                   seg: Math.round((Date.now()-tRonda)/1000)});
    e.output = out;
    if(veredicto==='APRUEBA'){ relojOff(); e.estado = e.ok?'espera_ok':'aprobada'; e.progreso=''; e.feedback=''; render(); await guardar(p); if(!e.ok) continuar(); return; }
    correcciones = fallas; e.estado='rechazada'; render(); await guardar(p);
  }
  relojOff(); e.estado='agotada'; e.progreso=''; render(); await guardar(p);
}

function siguientePendiente(p){
  for(const k of p.orden){ const e=p.etapas[k]; if(e.estado==='pendiente') return k; if(!['aprobada'].includes(e.estado)) return null; }
  return null;
}
async function continuar(){ const p=P(); if(!p) return; const k=siguientePendiente(p); if(k) await ejecutarEtapa(k); else render(); }
async function iniciar(){ const p=P(); if(!p||!p.orden.length) return; S.view='run'; render(); await continuar(); }
async function aprobar(key){ const p=P(); p.etapas[key].estado='aprobada'; render(); await guardar(p); await continuar(); }
async function iterar(key){
  const p=P(); const e=p.etapas[key]; const fb=($(`#fb-${key}`)||{}).value||'';
  if(!fb.trim()) return fallo('Escribe qué quieres cambiar en esa etapa.');
  const idx=p.orden.indexOf(key); const abajo=p.orden.slice(idx+1).filter(k=>p.etapas[k].estado!=='pendiente');
  if(abajo.length && !e.confirmado){ e.confirmado=true; return fallo(`Iterar "${e.nombre}" reinicia ${abajo.length} etapa(s) posteriores. Vuelve a darle a Iterar para confirmar.`); }
  e.confirmado=false; S.error='';
  for(const k of abajo){ Object.assign(p.etapas[k], {estado:'pendiente', output:'', rondas:[], feedback:''}); }
  e.feedback=fb; e.estado='pendiente'; e.rondas=[]; await guardar(p); await ejecutarEtapa(key);
}
async function otraRonda(key){ await ejecutarEtapa(key); }
async function aprobarAsi(key){ const p=P(); const e=p.etapas[key];
  if(!e.confirmado){ e.confirmado=true; return fallo('El auditor no aprobó esta versión. Vuelve a darle a "Aprobar así" para confirmar.'); }
  e.confirmado=false; S.error=''; e.estado='aprobada'; await guardar(p); render(); await continuar(); }
function detener(){ if(ctl) ctl.abort(); }

// ------------------------------------------------------------ evaluador
let EV = {modo:'imagen', imgs:[], fuente:'cuadros', url:'', gens:null, genSel:null, file:null, n:6, miniaturas:[], estado:'', res:null, escenas:null, analisisId:null, err:''};
async function evaluarImagen(){
  const p=P(); if(!p||!sample||!EV.imgs.length) return;
  EV.estado='Evaluando…'; EV.res=null; EV.err=''; render();
  try{
    const r = await sample.json(promptEvalImagen(p, referenciaAprobada(p), EV.imgs.length), opts(S.ajustes.tierGen, {images:EV.imgs.slice(0, (caps.images&&caps.images.maxCount)||EV.imgs.length)}));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'imagen', fecha:nowIso(), n:EV.imgs.length, veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err=errMsg(e); }
  EV.estado=''; render();
}
function mcpErr(e){
  const m={server_not_connected:'Higgsfield no está conectado en esta cuenta. Agrégalo en claude.ai → Settings → Connectors.', needs_reauth:'Higgsfield pide volver a autorizar. Reconéctalo en claude.ai → Settings → Connectors.', not_in_manifest:'Esta herramienta no está en el manifiesto de la página.', tool_error:'Higgsfield reportó un error: '+((e&&e.message)||''), not_granted:'No autorizaste el conector para esta página.', selection_required:'Tienes más de un conector Higgsfield: elige uno cuando la página lo pida.'};
  return m[e&&e.code] || ((e&&e.message)||'Error del conector.');
}
async function cargarGeneraciones(){
  if(!mcp) return; EV.estado='Cargando tus generaciones de video…'; EV.err=''; render();
  try{ const r = await mcp.callTool('Higgsfield','show_generations',{type:'video', size:24}); const pl = r.payload||{}; EV.gens = (pl.items||[]).filter(g=>g.status==='completed' && g.results && g.results.rawUrl); }
  catch(e){ EV.err=mcpErr(e); }
  EV.estado=''; render();
}
async function extraerCuadros(file, n){
  const v=document.createElement('video'); v.muted=true; v.playsInline=true; v.preload='auto';
  const url=URL.createObjectURL(file); v.src=url;
  try{
    await new Promise((res,rej)=>{ v.onloadedmetadata=()=>res(); v.onerror=()=>rej(new Error('el navegador no pudo leer este video')); });
    const dur = isFinite(v.duration)&&v.duration>0 ? v.duration : 0;
    const cuadros=[], tiempos=[];
    for(let i=0;i<n;i++){
      const t = dur ? dur*(i+0.5)/n : 0;
      await new Promise((res,rej)=>{ v.onseeked=()=>res(); v.onerror=()=>rej(new Error('no se pudo avanzar el video')); v.currentTime=Math.min(t, Math.max(0,dur-0.05)); });
      const w=Math.min(v.videoWidth||640, 1024), h=Math.round((v.videoHeight||360)*(w/(v.videoWidth||640)));
      const c=document.createElement('canvas'); c.width=w; c.height=h;
      c.getContext('2d').drawImage(v,0,0,w,h);
      const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',0.85));
      if(!blob) throw new Error('no se pudo capturar el cuadro');
      cuadros.push(blob); tiempos.push(t);
      if(!dur) break;
    }
    return {cuadros, tiempos};
  } finally { URL.revokeObjectURL(url); }
}
async function evaluarCuadros(){
  const p=P(); if(!p||!sample||!EV.file) return;
  EV.res=null; EV.escenas=null; EV.err=''; EV.estado='Extrayendo cuadros…'; render();
  try{
    const {cuadros, tiempos} = await extraerCuadros(EV.file, Number(EV.n)||6);
    EV.miniaturas = cuadros.map(b=>URL.createObjectURL(b));
    EV.estado=`Evaluando ${cuadros.length} cuadros…`; render();
    const r = await sample.json(promptEvalCuadros(p, referenciaAprobada(p), tiempos), opts(S.ajustes.tierGen, {images:cuadros}));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'video (cuadros)', fecha:nowIso(), veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err = (e&&e.code)?errMsg(e):('No se pudo procesar el video: '+((e&&e.message)||e)); }
  EV.estado=''; render();
}
const esYouTube = u => /^https:\/\/((www\.|m\.)?youtube\.com\/|youtu\.be\/)/.test(u);
async function evaluarVideo(){
  const p=P(); if(!p||!sample||!mcp) return;
  let url = EV.fuente==='gens' ? (EV.genSel&&EV.genSel.results.rawUrl) : EV.url.trim();
  if(!url){ EV.err='Falta el video.'; render(); return; }
  EV.res=null; EV.escenas=null; EV.err='';
  try{
    let input;
    if(esYouTube(url)) input={youtube_url:url};
    else { EV.estado='Importando el video a Higgsfield…'; render(); const im = await mcp.callTool('Higgsfield','media_import_url',{url, type:'video'}); const id=(im.payload||{}).media_id; if(!id) throw {code:'tool_error', message:'la importación no devolvió media_id'}; input={video_input_id:id}; }
    EV.estado='Pidiendo el análisis escena por escena (10 créditos de Higgsfield)…'; render();
    const cr = await mcp.callTool('Higgsfield','video_analysis_create', input);
    const aid = ((cr.payload||{}).result||{}).id; if(!aid) throw {code:'tool_error', message:'no llegó el id del análisis'};
    EV.analisisId=aid;
    const t0=Date.now(); let res=null;
    while(Date.now()-t0 < 12*60*1000){
      await new Promise(r=>setTimeout(r,6000));
      EV.estado=`Analizando el video… ${Math.round((Date.now()-t0)/1000)}s`; render();
      const st = await mcp.callTool('Higgsfield','video_analysis_status',{video_analyze_id:aid},{cache:false});
      res = (st.payload||{}).result||{};
      if(res.status==='completed') break;
      if(res.status==='failed') throw {code:'tool_error', message:res.fail_reason||'el análisis falló'};
    }
    if(!res||res.status!=='completed') throw {code:'tool_error', message:'el análisis no terminó en 12 minutos'};
    EV.escenas = res.scenes||[];
    EV.estado='Evaluando contra el brief…'; render();
    const r = await sample.json(promptEvalVideo(p, referenciaAprobada(p), EV.escenas), opts(S.ajustes.tierGen));
    EV.res=r; p.evaluaciones=(p.evaluaciones||[]).slice(-20); p.evaluaciones.push({tipo:'video', fecha:nowIso(), url, veredicto:r.veredicto, puntaje:r.puntaje}); await guardar(p);
  }catch(e){ EV.err = e&&e.code&&['not_granted','rate_limited','invalid_json','refused','cancelled','prompt_too_large'].includes(e.code) ? errMsg(e) : mcpErr(e); }
  EV.estado=''; render();
}

// ------------------------------------------------------------ markdown mínimo
function md(src){
  const lines=(src||'').split('\n'); let out=[], i=0, inCode=false, buf=[], list=null;
  const flush=()=>{ if(list){ out.push(`</${list}>`); list=null; } };
  const inline = s => esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>').replace(/(^|\W)\*([^*\n]+)\*(?=\W|$)/g,'$1<i>$2</i>');
  for(;i<lines.length;i++){ const l=lines[i];
    if(/^```/.test(l)){ if(inCode){ out.push('<pre><code>'+esc(buf.join('\n'))+'</code></pre>'); buf=[]; inCode=false; } else { flush(); inCode=true; } continue; }
    if(inCode){ buf.push(l); continue; }
    let m;
    if((m=/^(#{1,3})\s+(.*)/.exec(l))){ flush(); out.push(`<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`); continue; }
    if((m=/^\s*[-*•]\s+(.*)/.exec(l))){ if(list!=='ul'){ flush(); out.push('<ul>'); list='ul'; } out.push('<li>'+inline(m[1])+'</li>'); continue; }
    if((m=/^\s*\d+[.)]\s+(.*)/.exec(l))){ if(list!=='ol'){ flush(); out.push('<ol>'); list='ol'; } out.push('<li>'+inline(m[1])+'</li>'); continue; }
    if(/^\s*\|.*\|\s*$/.test(l)){ flush(); const rows=[]; while(i<lines.length && /^\s*\|.*\|\s*$/.test(lines[i])){ rows.push(lines[i]); i++; } i--; const cells=r=>r.trim().slice(1,-1).split('|').map(c=>inline(c.trim())); const body=rows.filter(r=>!/^\s*\|[\s:|-]+\|\s*$/.test(r)); out.push('<table>'+body.map((r,k)=>'<tr>'+cells(r).map(c=>k===0?`<th>${c}</th>`:`<td>${c}</td>`).join('')+'</tr>').join('')+'</table>'); continue; }
    if(!l.trim()){ flush(); continue; }
    flush(); out.push('<p>'+inline(l)+'</p>');
  }
  if(inCode) out.push('<pre><code>'+esc(buf.join('\n'))+'</code></pre>');
  flush(); return out.join('');
}

// ------------------------------------------------------------ render
const ESTADO = {pendiente:['','Pendiente'], generando:['gen','Generando'], auditando:['aud','Auditando'], rechazada:['rech','Rechazada por el auditor'], agotada:['agot','No pasó la auditoría'], espera_ok:['espera','Espera tu OK'], aprobada:['aprob','Aprobada']};
const pillEstado = e => { const [cls,txt]=ESTADO[e.estado]||['',e.estado]; const c = {gen:'info',aud:'info',rech:'bad',agot:'bad',espera:'warn',aprob:'ok'}[cls]||''; return `<span class="pill ${c}">${txt}</span>`; };

function render(){
  const p=P();
  $('#ver').textContent = `${D.meta.reglas} reglas · ${D.meta.auditorias} auditorías`;
  $('#plist').innerHTML = S.proyectos.map(x=>`<button class="${x.id===S.pid?'act':''}" data-p="${x.id}"><b>${esc(x.nombre)}</b><small>${(x.creado||'').slice(0,10)} · ${x.orden?x.orden.length:0} etapas</small></button>`).join('') || '<div class="mute" style="padding:6px 9px">Ningún proyecto todavía.</div>';
  $('#plist').querySelectorAll('button').forEach(b=>b.onclick=()=>{ S.pid=b.dataset.p; S.imgs=[]; EV.res=null; EV.escenas=null; S.view = P().orden.length?'run':'brief'; render(); });
  $('#tabs').querySelectorAll('button').forEach(b=>{ b.classList.toggle('act', b.dataset.v===S.view); b.onclick=()=>{ S.view=b.dataset.v; render(); }; });
  $('#nPlan').textContent = p&&p.orden.length ? p.orden.length : '';
  $('#nRun').textContent = p&&p.orden.length ? `${p.orden.filter(k=>p.etapas[k].estado==='aprobada').length}/${p.orden.length}` : '';
  $('#btnNuevo').onclick = nuevoProyecto;
  const m=$('#main');
  if(S.bloqueo){ vBloqueo(m); return; }
  if(!p){ m.innerHTML = `<div class="hd"><div><h2>Brief</h2></div></div><div class="empty">Sin proyectos. Usa <b>Nuevo brief</b>.</div>`; return; }
  ({brief:vBrief, plan:vPlan, run:vRun, eval:vEval, ajustes:vAjustes})[S.view](m,p);
  banner(m);
}

function banner(m){
  if(!S.error) return;
  const d=document.createElement('div');
  d.className='badbox'; d.style.marginBottom='12px'; d.style.cursor='pointer';
  d.title='Clic para cerrar';
  d.textContent=S.error;
  d.onclick=()=>{ S.error=''; render(); };
  m.insertBefore(d, m.firstChild);
}

function vBloqueo(m){
  m.innerHTML = `<div class="hd"><div><h2>Contraseña</h2><p class="sub">Esta app usa la cuenta de OpenAI del servidor. La contraseña evita que la gaste alguien más.</p></div></div>
  <div class="card" style="max-width:440px">
    <div><div class="lbl">Contraseña</div><input type="password" id="pw" autocomplete="current-password"></div>
    <div class="row"><button class="prim" id="btnPw">Entrar</button><span class="mute" id="pwMsg"></span></div>
  </div>`;
  const inp=$('#pw'), msg=$('#pwMsg'), btn=$('#btnPw');
  const entrar=async()=>{
    const k=inp.value.trim();
    if(!k){ msg.textContent='Escribe la contraseña.'; return; }
    btn.disabled=true; msg.textContent='Verificando…';
    const j=await probarClave(k);
    btn.disabled=false;
    if(!j){ msg.textContent='No se pudo hablar con el servidor.'; return; }
    if(!j.claveOk){ msg.textContent='Contraseña incorrecta.'; inp.select(); return; }
    try{ localStorage.setItem(claveLS,k); }catch(e){}
    SRV=j; S.bloqueo=false; S.error=''; render();
  };
  btn.onclick=entrar;
  inp.onkeydown=e=>{ if(e.key==='Enter') entrar(); };
  inp.focus();
}

function vBrief(m,p){
  m.innerHTML = `<div class="hd"><div><h2>Brief</h2></div></div>
  <div class="card">
    <div><div class="lbl">Nombre del proyecto</div><input type="text" id="nombre" value="${esc(p.nombre)}"></div>
    <div><div class="row" style="justify-content:space-between"><div class="lbl">Brief</div><div class="row"><button class="sm" id="btnVoz">Dictar</button><span class="mute" style="font-size:12px" id="vozN"></span></div></div><textarea id="brief" style="min-height:260px">${esc(p.brief)}</textarea><div class="mute" style="font-size:12px;margin-top:4px" id="briefN"></div></div>
    <div class="grid2">
      <div><div class="lbl">Documentos</div><div class="row"><input type="file" id="docs" hidden accept=".txt,.md,.pdf,.docx,text/plain,text/markdown,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" multiple><button id="btnDocs">Subir txt, md, pdf o docx</button><span class="mute" style="font-size:12px" id="docsN">El texto se agrega al brief.</span></div></div>
      <div><div class="lbl">Imágenes de referencia</div><div class="row"><input type="file" id="imgs" hidden accept="image/*" multiple><button id="btnImgs" ${caps.images?'':'disabled'}>Subir imágenes</button><span class="mute" style="font-size:12px" id="imgsN">${caps.images?(S.imgs.length?`${S.imgs.length} adjunta(s). Se pierden al recargar.`:''):'No disponible aquí.'}</span></div><div class="thumbs" id="thumbs"></div>${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}</div>
    </div>
    ${sample?'':`<div class="badbox">${esc(motivoSinClaude())}</div>`}
    <div class="row"><button class="prim" id="btnPlan" ${S.busy?'disabled':''}>Analizar brief y proponer etapas</button>${p.orden.length?`<span class="mute">Ya hay un plan de ${p.orden.length} etapas. Volver a analizar lo reemplaza.</span>`:''}${S.busy?`<span class="status"><span class="spin"></span><span id="busyN">${esc(S.busy)}</span> · <span class="reloj">0s</span></span>`:''}</div>
  </div>`;
  const ta=$('#brief'), nm=$('#nombre'), cnt=$('#briefN');
  const upd=()=>{ cnt.textContent = `${ta.value.length.toLocaleString('es-MX')} caracteres`; };
  upd();
  ta.oninput=()=>{ p.brief=ta.value; upd(); }; ta.onchange=()=>guardar(p);
  nm.onchange=()=>{ p.nombre=nm.value||'Sin título'; guardar(p); render(); };
  const th=$('#thumbs'); const pintar=()=>{ th.innerHTML=''; S.imgs.forEach(f=>{ const im=document.createElement('img'); im.src=URL.createObjectURL(f); im.alt=f.name; th.appendChild(im); }); };
  pintar();
  $('#btnImgs').onclick=()=>$('#imgs').click(); $('#btnDocs').onclick=()=>$('#docs').click();
  const bv=$('#btnVoz'), vn=$('#vozN'); const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){ bv.disabled=true; vn.textContent='Este navegador no tiene reconocimiento de voz.'; }
  else bv.onclick=()=>{ if(VOZ.rec){ VOZ.rec.stop(); return; } const r=new SR(); VOZ.rec=r; r.lang='es-MX'; r.continuous=true; r.interimResults=true; let base=ta.value, fin='';
    r.onstart=()=>{ bv.textContent='Detener'; bv.classList.add('prim'); vn.textContent='Escuchando…'; };
    r.onresult=ev=>{ let inter=''; for(let i=ev.resultIndex;i<ev.results.length;i++){ const t=ev.results[i][0].transcript; if(ev.results[i].isFinal) fin+=t+' '; else inter+=t; } ta.value=(base.trim()?base.replace(/\s+$/,'')+' ':'')+fin+inter; p.brief=ta.value; upd(); };
    r.onerror=ev=>{ vn.textContent = ev.error==='not-allowed'||ev.error==='service-not-allowed' ? 'Micrófono bloqueado: permite el micrófono en el navegador o dicta con el teclado del sistema.' : 'Error de voz: '+ev.error; };
    r.onend=()=>{ VOZ.rec=null; bv.textContent='Dictar'; bv.classList.remove('prim'); if(vn.textContent==='Escuchando…') vn.textContent=''; guardar(p); };
    try{ r.start(); }catch(e){ vn.textContent='No se pudo iniciar el dictado.'; VOZ.rec=null; } };
  $('#imgs').onchange=ev=>{ S.imgs=[...S.imgs, ...ev.target.files]; ev.target.value=''; pintar(); $('#imgsN').textContent=`${S.imgs.length} adjunta(s). Se pierden al recargar.`; };
  $('#docs').onchange=async ev=>{ const files=[...ev.target.files]; const dn=$('#docsN'); for(const f of files){ dn.textContent=`Leyendo ${f.name}…`; try{ const t=(await textoDe(f)).trim(); if(!t) throw new Error('sin texto legible'); ta.value = (ta.value.trim()? ta.value.replace(/\s+$/,'')+'\n\n':'') + `--- ${f.name} ---\n${t}`; p.brief=ta.value; upd(); dn.textContent=`${f.name}: ${t.length.toLocaleString('es-MX')} caracteres agregados.`; }catch(e){ dn.textContent=`${f.name}: no se pudo leer (${e.message||e}).`; } } ev.target.value=''; await guardar(p); };
  $('#btnPlan').onclick=()=>{ p.brief=ta.value; planificar(); };
}

// ------------------------------------------------------------ documentos
const PDFJS='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', PDFW='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', MAMMOTH='https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.8.0/mammoth.browser.min.js';
function loadScript(src){ return new Promise((res,rej)=>{ if(document.querySelector(`script[src="${src}"]`)) return res(); const s=document.createElement('script'); s.src=src; s.onload=res; s.onerror=()=>rej(new Error('no se pudo cargar la librería')); document.head.appendChild(s); }); }
async function textoDe(f){
  const n=f.name.toLowerCase();
  if(n.endsWith('.pdf')){ await loadScript(PDFJS); pdfjsLib.GlobalWorkerOptions.workerSrc=PDFW; const doc=await pdfjsLib.getDocument({data:new Uint8Array(await f.arrayBuffer())}).promise; const out=[]; for(let i=1;i<=doc.numPages;i++){ const tc=await (await doc.getPage(i)).getTextContent(); out.push(tc.items.map(it=>it.str+(it.hasEOL?'\n':' ')).join('').replace(/[ \t]+\n/g,'\n')); } return out.join('\n\n'); }
  if(n.endsWith('.docx')){ await loadScript(MAMMOTH); return (await mammoth.extractRawText({arrayBuffer:await f.arrayBuffer()})).value; }
  return await f.text();
}

function vPlan(m,p){
  if(!p.plan){ m.innerHTML=`<div class="hd"><div><h2>Plan</h2></div></div><div class="empty">Todavía no hay plan. Analiza el brief primero.</div>`; return; }
  const pl=p.plan; const corriendo = p.orden.some(k=>['generando','auditando'].includes(p.etapas[k].estado));
  m.innerHTML = `<div class="hd"><div><h2>${esc(p.nombre)}</h2><p class="sub">${esc(pl.tipo||'')}${pl.track?` · track ${esc(pl.track)}`:''}</p></div>
    <div class="row"><button class="prim" id="btnRun" ${corriendo?'disabled':''}>${p.orden.some(k=>p.etapas[k].estado!=='pendiente')?'Ir a la ejecución':'Aprobar plan y ejecutar'}</button></div></div>
  <div class="stack">
    <div class="card"><p>${esc(pl.resumen||'')}</p>
      <div class="row"><div><div class="lbl">Aspect ratio</div><input type="text" id="fAspect" style="width:110px" value="${esc((pl.formato||{}).aspect||'')}"></div>
        <div><div class="lbl">Resolución</div><input type="text" id="fRes" style="width:150px" value="${esc((pl.formato||{}).resolucion||'')}"></div>
        <div><div class="lbl">Duración</div><input type="text" id="fDur" style="width:110px" value="${esc((pl.formato||{}).duracion||'')}"></div>
        <span class="mute" style="font-size:12.5px;align-self:flex-end">Manda sobre todos los prompts. Corrígelo aquí antes de ejecutar.</span></div>
      ${(pl.supuestos||[]).length?`<div><div class="lbl">Supuestos que tomó el planificador</div><ul class="crit">${pl.supuestos.map(s=>`<li>${esc(s)}</li>`).join('')}</ul></div>`:''}</div>
    <div class="card"><h3>Etapas (${p.orden.length})</h3>
    <div>${p.orden.map((k,i)=>{ const e=p.etapas[k]; const n=reglasDe(e.casos).length; return `<div class="plan-et"><div class="k">${i+1} · ${esc(e.clave)}</div><div><b>${esc(e.nombre)}</b>${e.ok?' <span class="pill warn">pide tu OK</span>':''}<div class="mute" style="margin:2px 0 4px">${esc(e.objetivo)}</div><div style="font-size:13px"><span class="lbl">Entrega</span> ${esc(e.entregable)}</div><ol class="crit" style="margin-top:4px">${(e.criterios||[]).map(c=>`<li>${esc(c)}</li>`).join('')}</ol><div class="meta" style="margin-top:6px"><span class="pill">${n} reglas</span>${(e.casos||[]).map(c=>`<span class="pill">${c}</span>`).join('')}${e.usaImagenes?'<span class="pill info">ve las imágenes</span>':''}</div></div><div><button class="sm" data-quitar="${k}" ${corriendo?'disabled':''}>Quitar</button></div></div>`; }).join('')}</div>
    <div class="row"><select id="addEt" style="width:auto"><option value="">Agregar etapa…</option>${ETAPAS.map(e=>`<option value="${e.clave}">${e.clave} · ${esc(e.nombre)}</option>`).join('')}</select></div></div>
  </div>`;
  $('#btnRun').onclick=iniciar;
  const guardaFmt=()=>{ pl.formato={aspect:$('#fAspect').value.trim(), resolucion:$('#fRes').value.trim(), duracion:$('#fDur').value.trim()}; guardar(p); };
  ['#fAspect','#fRes','#fDur'].forEach(sel=>$(sel).onchange=guardaFmt);
  m.querySelectorAll('[data-quitar]').forEach(b=>b.onclick=async()=>{ const k=b.dataset.quitar; p.orden=p.orden.filter(x=>x!==k); delete p.etapas[k]; await guardar(p); render(); });
  $('#addEt').onchange=async ev=>{ const c=ev.target.value; if(!c) return; const cat=CAT[c]; const key=`${c}_${uid()}`; p.orden.push(key); p.etapas[key]={key, clave:c, nombre:cat.nombre, objetivo:cat.sale, entregable:cat.sale, casos:cat.casos.slice(0, c==='E5'||c==='PROMPT_IMAGEN'?1:99), criterios:[cat.gate], usaImagenes:c==='REF', ok:cat.ok, estado:'pendiente', output:'', rondas:[], feedback:''}; await guardar(p); render(); };
}

function vRun(m,p){
  if(!p.orden.length){ m.innerHTML=`<div class="hd"><div><h2>Ejecución</h2></div></div><div class="empty">Sin plan. Analiza el brief y aprueba el plan.</div>`; return; }
  const corriendo = p.orden.some(k=>['generando','auditando'].includes(p.etapas[k].estado));
  const listas = p.orden.filter(k=>p.etapas[k].estado==='aprobada').length;
  m.innerHTML = `<div class="hd"><div><h2>${esc(p.nombre)}</h2><p class="sub">${listas} de ${p.orden.length} etapas aprobadas${p.plan&&p.plan.track?` · track ${esc(p.plan.track)}`:''}</p></div>
    <div class="row">${corriendo?`<button id="btnStop">Detener</button>`:`<button class="prim" id="btnCont" ${siguientePendiente(p)?'':'disabled'}>Continuar</button>`}</div></div>
  <div class="stack">${p.orden.map((k,i)=>etapaHTML(p.etapas[k],i)).join('')}</div>`;
  if($('#btnStop')) $('#btnStop').onclick=detener;
  if($('#btnCont')) $('#btnCont').onclick=continuar;
  m.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>({aprobar, iterar, otraRonda, aprobarAsi, ejecutar:ejecutarEtapa, copiar:k=>{ navigator.clipboard.writeText(p.etapas[k].output||''); b.textContent='Copiado'; }})[b.dataset.act](b.dataset.k));
}

function etapaHTML(e,i){
  const cls=(ESTADO[e.estado]||[''])[0]; const activa=['generando','auditando'].includes(e.estado);
  const ult = e.rondas[e.rondas.length-1];
  return `<section class="etapa ${cls}"><div class="stripe"></div><div class="body">
    <div class="top"><div><div class="lbl">${i+1} · ${esc(e.clave)}</div><h3>${esc(e.nombre)}</h3></div><div class="meta">${pillEstado(e)}${e.rondas.length?`<span class="pill">${e.rondas.length} ronda${e.rondas.length>1?'s':''}</span>`:''}${e.reglasTotal?`<span class="pill" title="reglas que cupieron en la instrucción / reglas auditadas">${e.reglasIncluidas}/${e.reglasTotal} reglas</span>`:''}</div></div>
    <p class="mute">${esc(e.objetivo)}</p>
    ${activa?`<div class="status"><span class="spin"></span>${esc(e.progreso||'')} · <span class="reloj">0s</span></div>${activa?`<pre class="mono" id="parcial-${e.key}" style="white-space:pre-wrap;max-height:220px;overflow:auto;margin:0;color:var(--mute)">${esc(e.parcial||'')}</pre>`:''}`:''}
    ${e.error?`<div class="badbox">${esc(e.error)}</div>`:''}
    ${e.rondas.length?`<details ${['rechazada','agotada'].includes(e.estado)?'open':''}><summary>Auditoría · ${e.rondas.map(r=>`R${r.n} ${r.veredicto==='APRUEBA'?'✓':'✗'+r.fallas.length}`).join(' · ')}</summary><div class="log" style="margin-top:8px">${e.rondas.map(r=>`<div class="r"><div>ronda ${r.n}<br>${r.veredicto==='APRUEBA'?'aprueba':'rechaza'}${r.seg?`<br>${r.seg<60?r.seg+'s':Math.floor(r.seg/60)+'m '+String(r.seg%60).padStart(2,'0')+'s'}`:''}<br>${r.palabras} pal.${r.cache?`<br>${Math.round(r.cache/1000)}K de caché`:''}</div><div>${r.fallas.length?r.fallas.map(f=>`<div class="falla"><b>${esc(f.ref)}</b> ${esc(f.correccion)}${f.evidencia?`<div class="ev">${esc(f.evidencia)}</div>`:''}</div>`).join(''):'<span class="mute">Sin fallas.</span>'}${r.notas&&r.notas.length?`<div class="mute" style="margin-top:4px;font-size:12px">${r.notas.map(esc).join(' · ')}</div>`:''}</div></div>`).join('')}</div></details>`:''}
    ${e.output&&!activa?`<div class="out"><div class="row" style="justify-content:space-between"><span class="lbl">Entregable${e.estado==='agotada'?' (última versión, no aprobada)':''}</span><button class="sm" data-act="copiar" data-k="${e.key}">Copiar</button></div><div class="md">${md(e.output)}</div></div>`:''}
    ${!activa?`<div class="row" style="border-top:1px solid var(--line);padding-top:10px">
      ${e.estado==='espera_ok'?`<button class="prim" data-act="aprobar" data-k="${e.key}">Aprobar y continuar</button>`:''}
      ${e.estado==='agotada'?`<button class="prim" data-act="otraRonda" data-k="${e.key}">Otras ${S.ajustes.rondas} rondas</button><button data-act="aprobarAsi" data-k="${e.key}">Aprobar así</button>`:''}
      ${e.estado==='rechazada'?`<button class="prim" data-act="otraRonda" data-k="${e.key}">Reintentar</button>`:''}
      ${e.estado==='pendiente'&&!e.output?`<button class="sm" data-act="ejecutar" data-k="${e.key}">Ejecutar solo esta</button>`:''}
      ${e.output||e.estado==='rechazada'?`<div style="flex:1;min-width:260px"><textarea id="fb-${e.key}" style="min-height:56px" placeholder="Qué cambiar en esta etapa (iteración)">${esc(e.feedback||'')}</textarea></div><button data-act="iterar" data-k="${e.key}">Iterar</button>`:''}
    </div>`:''}
  </div></section>`;
}

function vEval(m,p){
  const ref = p.orden.filter(k=>p.etapas[k].estado==='aprobada').length;
  m.innerHTML = `<div class="hd"><div><h2>Evaluador</h2><p class="sub">Referencia: brief${ref?` + ${ref} etapas aprobadas`:''} de <b>${esc(p.nombre)}</b></p></div>
    <div class="seg"><button data-m="imagen" class="${EV.modo==='imagen'?'act':''}">Imagen</button><button data-m="video" class="${EV.modo==='video'?'act':''}">Video</button></div></div>
  <div class="stack">
  ${EV.modo==='imagen'?`<div class="card">
      <div><div class="lbl">Imágenes generadas</div><div class="row"><input type="file" id="evImgs" hidden accept="image/*" multiple><button id="btnEvPick" ${caps.images?'':'disabled'}>Subir imágenes</button><span class="mute" style="font-size:12px">${caps.images?(EV.imgs.length?`${EV.imgs.length} adjunta(s)`:''):'No disponible aquí.'}</span></div><div class="thumbs" id="evThumbs"></div>${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}</div>
      <div class="row"><button class="prim" id="btnEvImg" ${!sample||!EV.imgs.length||EV.estado?'disabled':''}>Evaluar</button>${EV.estado?`<span class="status"><span class="spin"></span>${esc(EV.estado)}</span>`:''}</div>
    </div>`
  :`<div class="card">
      ${caps.images?'':`<div class="warnbox">Esta vista del visor no puede enviar imágenes al modelo. Para trabajar con referencias visuales abre la app en <a href="https://ai-production-director.vercel.app">ai-production-director.vercel.app</a>.</div>`}
      <div class="seg"><button data-f="cuadros" class="${EV.fuente==='cuadros'?'act':''}">Archivo de video</button>${mcp?`<button data-f="url" class="${EV.fuente==='url'?'act':''}">URL</button><button data-f="gens" class="${EV.fuente==='gens'?'act':''}">Higgsfield</button>`:''}</div>
      ${EV.fuente==='cuadros'?`<div class="row"><input type="file" id="evVid" hidden accept="video/*"><button id="btnVidPick">Elegir video</button><span class="mute" style="font-size:12.5px">${EV.file?esc(EV.file.name):'mp4, mov o webm del disco'}</span><select id="evN" style="width:auto">${[4,6,8,12].map(n=>`<option ${EV.n==n?'selected':''}>${n}</option>`).join('')}</select><span class="mute" style="font-size:12.5px">cuadros</span></div>${EV.miniaturas.length?`<div class="thumbs">${EV.miniaturas.map(u=>`<img src="${u}" alt="">`).join('')}</div>`:''}<div class="row"><button class="prim" id="btnEvCuadros" ${!sample||!caps.images||!EV.file||EV.estado?'disabled':''}>Evaluar</button><span class="mute" style="font-size:12.5px">Sin audio ni movimiento continuo: se evalúan cuadros.</span></div>`
      :EV.fuente==='url'?`<input type="url" id="evUrl" placeholder="https://youtu.be/… o https://….cloudfront.net/….mp4" value="${esc(EV.url)}">`
      :`<div class="row"><button class="sm" id="btnGens" ${!mcp||EV.estado?'disabled':''}>${EV.gens?'Recargar':'Cargar mis videos'}</button><span class="mute" style="font-size:12.5px">${EV.gens?`${EV.gens.length} videos completados`:''}</span></div>${EV.gens?`<div class="gens">${EV.gens.map(g=>`<button data-g="${g.id}" class="${EV.genSel&&EV.genSel.id===g.id?'act':''}"><img src="${esc(g.results.thumbnailUrl||'')}" alt=""><small>${esc((g.params&&g.params.prompt||g.model||g.id).slice(0,60))}</small></button>`).join('')}</div>`:''}`}
      ${EV.fuente!=='cuadros'?`<div class="row"><button class="prim" id="btnEvVid" ${!sample||!mcp||EV.estado?'disabled':''}>Analizar y evaluar</button><span class="mute" style="font-size:12.5px">10 créditos de Higgsfield por análisis.</span></div>`:''}
      ${EV.estado?`<div class="status"><span class="spin"></span>${esc(EV.estado)}</div>`:''}
    </div>`}
  ${EV.err?`<div class="badbox">${esc(EV.err)}</div>`:''}
  ${EV.res?resultadoHTML(EV.res):''}
  ${EV.escenas?`<div class="card"><h3>Escenas detectadas (${EV.escenas.length})</h3><table class="tbl"><tr><th>#</th><th>Tiempo</th><th>Plano</th><th>Visual</th><th>Audio</th></tr>${EV.escenas.map(s=>`<tr><td>${s.scene_number}</td><td class="mono">${esc(s.timestamp_start)}–${esc(s.timestamp_end)}</td><td>${esc(s.shot_type||'')}</td><td>${esc(s.visual||'')}</td><td class="mute">${esc(s.audio||'')}</td></tr>`).join('')}</table></div>`:''}
  ${(p.evaluaciones||[]).length?`<details><summary>Historial · ${p.evaluaciones.length} evaluaciones</summary><table class="tbl" style="margin-top:8px"><tr><th>Fecha</th><th>Tipo</th><th>Veredicto</th><th>Puntaje</th></tr>${p.evaluaciones.slice().reverse().map(x=>`<tr><td class="mono">${esc(x.fecha.slice(0,16).replace('T',' '))}</td><td>${esc(x.tipo)}</td><td>${esc(x.veredicto||'')}</td><td class="mono">${x.puntaje??''}</td></tr>`).join('')}</table></details>`:''}
  </div>`;
  m.querySelectorAll('[data-m]').forEach(b=>b.onclick=()=>{ EV.modo=b.dataset.m; EV.res=null; EV.escenas=null; EV.err=''; render(); });
  m.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{ EV.fuente=b.dataset.f; render(); });
  m.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{ EV.genSel=EV.gens.find(g=>g.id===b.dataset.g); render(); });
  if($('#evImgs')){ const th=$('#evThumbs'); const pintar=()=>{ th.innerHTML=''; EV.imgs.forEach(f=>{ const im=document.createElement('img'); im.src=URL.createObjectURL(f); im.alt=f.name; th.appendChild(im); }); }; pintar(); $('#btnEvPick').onclick=()=>$('#evImgs').click(); $('#evImgs').onchange=ev=>{ EV.imgs=[...ev.target.files]; render(); }; $('#btnEvImg').onclick=evaluarImagen; }
  if($('#btnVidPick')){ $('#btnVidPick').onclick=()=>$('#evVid').click(); $('#evVid').onchange=ev=>{ EV.file=ev.target.files[0]||null; EV.miniaturas=[]; EV.res=null; render(); }; $('#evN').onchange=ev=>{ EV.n=Number(ev.target.value); }; $('#btnEvCuadros').onclick=evaluarCuadros; }
  if($('#evUrl')) $('#evUrl').oninput=ev=>{ EV.url=ev.target.value; };
  if($('#btnGens')) $('#btnGens').onclick=cargarGeneraciones;
  if($('#btnEvVid')) $('#btnEvVid').onclick=evaluarVideo;
}

function resultadoHTML(r){
  const v=r.veredicto||''; const c = v==='CUMPLE'?'ok':v==='PARCIAL'?'warn':'bad';
  return `<div class="card"><div class="row" style="justify-content:space-between"><div class="row"><span class="score">${r.puntaje??'–'}</span><span class="pill ${c}">${esc(v)}</span></div></div>
    ${r.descripcion?`<p>${esc(r.descripcion)}</p>`:''}
    ${Array.isArray(r.criterios)?`<table class="tbl"><tr><th>Criterio</th><th>Cumple</th><th>Evidencia</th></tr>${r.criterios.map(x=>`<tr><td>${esc(x.criterio)}</td><td>${x.cumple===true?'<span class="pill ok">sí</span>':x.cumple===false?'<span class="pill bad">no</span>':'<span class="pill">n/v</span>'}</td><td class="mute">${esc(x.evidencia||'')}</td></tr>`).join('')}</table>`:''}
    ${Array.isArray(r.por_escena)&&r.por_escena.length?`<div><div class="lbl">Por escena</div><ul class="crit">${r.por_escena.map(x=>`<li><b>${esc(x.escena)}</b> ${esc(x.nota)}</li>`).join('')}</ul></div>`:''}
    ${Array.isArray(r.correcciones)&&r.correcciones.length?`<div><div class="lbl">Correcciones para el siguiente intento</div><ol class="crit" style="color:var(--ink)">${r.correcciones.map(x=>`<li>${esc(x)}</li>`).join('')}</ol></div>`:''}
    ${r.prompt_ajustado?`<div><div class="lbl">Ajuste de prompt sugerido</div><div class="md"><pre><code>${esc(r.prompt_ajustado)}</code></pre></div></div>`:''}
  </div>`;
}

const ESF=[['complex','alto'],['default','medio'],['quick','bajo']];
function vAjustes(m,p){
  const a=S.ajustes;
  m.innerHTML=`<div class="hd"><div><h2>Ajustes</h2></div></div>
  <div class="card"><div class="grid2">
    <div><div class="lbl">Rondas máximas de auditoría por etapa</div><select id="aR">${[1,2,3,4,5].map(n=>`<option ${a.rondas==n?'selected':''}>${n}</option>`).join('')}</select></div>
    <div></div>
    <div><div class="lbl">Esfuerzo al generar</div><select id="aG">${ESF.map(([v,n])=>`<option value="${v}" ${a.tierGen===v?'selected':''}>${n}</option>`).join('')}</select></div>
    <div><div class="lbl">Esfuerzo al auditar</div><select id="aA">${ESF.map(([v,n])=>`<option value="${v}" ${a.tierAud===v?'selected':''}>${n}</option>`).join('')}</select></div>
  </div>
    <div><div class="lbl">Base de reglas</div><div class="mute" style="font-size:13px">${D.meta.reglas} reglas de ${D.meta.skills} skills · ${D.meta.auditorias} correcciones de auditoría externa · casos: ${Object.keys(D.porCaso).map(c=>`${c} ${D.porCaso[c].length}`).join(' · ')}</div></div>
  </div>`;
  const save=()=>{ a.rondas=Number($('#aR').value); a.tierGen=$('#aG').value; a.tierAud=$('#aA').value; try{ localStorage.setItem(ajustesLS, JSON.stringify(a)); }catch(e){} };
  ['#aR','#aG','#aA'].forEach(s=>$(s).onchange=save);
}

// ------------------------------------------------------------ arranque
(async()=>{
  render();
  const cl=$('#capline');
  const use = n => (window.claude&&window.claude.use) ? window.claude.use(n).catch(()=>null) : Promise.resolve(null);
  [sample, db, mcp] = await Promise.all([use('sample'), use('db'), use('mcp')]);
  if(!sample){
    SRV = await detectarServidor();
    if(SRV && SRV.ia){ sample = sampleDeServidor(); if(SRV.clave && !SRV.claveOk) S.bloqueo=true; }
  }
  if(sample){ try{ const l=await sample.limits(); caps.images=l.images||false; }catch(e){} }
  await cargarLista();
  if(S.proyectos.length && !S.pid){ S.pid=S.proyectos[0].id; S.view = P().orden.length?'run':'brief'; }
  if(!S.proyectos.length){ const p={id:uid(), nombre:'Sin título', brief:'', creado:nowIso(), plan:null, etapas:{}, orden:[], evaluaciones:[]}; S.proyectos.push(p); S.pid=p.id; S.view='brief'; }
  const parts=[ sample?(SRV?('ChatGPT '+(SRV.modelo||'')+' vía servidor propio'):'Claude listo'):(SRV&&!SRV.ia?'Falta OPENAI_API_KEY en el servidor':'Modelo no disponible'), db?'guardado en la nube':'guardado local', mcp?'Higgsfield listo':'video por cuadros' ];
  cl.textContent = parts.join(' · ');
  render();
})();
</script>

<!-- SOURCE_FILE_END: repo/app/ejecutor.html -->


<!-- SOURCE_FILE_START: repo/nblm-ids/PREGUNTA.txt -->
# SOURCE FILE: `repo/nblm-ids/PREGUNTA.txt`

CASO: maestro de rostro (T1) para Nano Banana Pro — ancla de campana.

Las fuentes de este notebook contienen 1162 reglas. Cada una lleva un id de 12
caracteres entre corchetes.

Clasifica CADA UNA de las 1162 reglas para este caso. Formato exacto, una linea
por regla, sin texto adicional:

[id] APLICA
[id] NO APLICA - razon breve

Reglas del formato:
- Deben aparecer los 1162 ids. Ninguno puede faltar.
- Prohibido agrupar. Nada de "todo el contenido de este archivo": una linea por id.
- Si la respuesta no cabe, corta donde vayas y dime el ultimo id que clasificaste;
  yo te pido la continuacion. No resumas para que quepa.
- No repitas un id con dos veredictos distintos.

<!-- SOURCE_FILE_END: repo/nblm-ids/PREGUNTA.txt -->


<!-- SOURCE_FILE_START: repo/nblm-ids/ai-production-director.md -->
# SOURCE FILE: `repo/nblm-ids/ai-production-director.md`

# Reglas del skill: ai-production-director

25 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## ai-production-director/SKILL.md

- [1f8ed1aa2f82] **Clasificar** el proyecto y elegir el track correcto.
- [976919fb7afd] **Secuenciar** las etapas y cargar la sub-skill correcta en cada una.
- [8a2a24e72003] **Custodiar los gates**: ninguna etapa arranca sin que la anterior pase su quality gate.
- [c83679230b88] **Resolver conflictos** entre sub-skills con las reglas de la sección 6 — las decidiste una vez, no se renegocian por proyecto.
- [2c2da899a44d] **Mantener trazabilidad**: todo artefacto downstream traza a un shot ID, todo shot traza a una escena, toda escena al concepto aprobado.
- [4ca2dc8c76f1] Cada etapa declara: sub-skill, entradas, salidas, y gate. El gate se verifica ANTES de avanzar. Si falla, se corrige en la etapa actual — nunca se "arregla después".
- [36dd5696e226] **Gate:** el usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto.
- [043b9dc0b02e] **Gate:** cero palabras del vocabulario prohibido (sección 6.1). Cada decisión de cámara tiene razón dramática escrita.
- [3fb8782f57b8] **Gate obligatorio:** los dos checks de `video` (dramaturgy check de 6 puntos + auditoría de 3 detalles) Y, si `aurora-prompt-linter` está instalada, el linter pasa limpio. Un prompt que falla cualquiera de los dos NO se entrega.
- [5673820bc473] Nunca preguntes lo que el brief o los artefactos previos ya responden.
- [f556f97c9939] El vocabulario prohibido de `video`/dramaturgy (+ `aurora-prompt-linter` si está) **gana siempre**: "cinematic", "epic", "stunning", "masterpiece", "beautiful lighting", "professional", "high quality", emociones nombradas sin cuerpo. Esto **anula explícitamente** la regla de `ai-video-storyboard` de cerrar cada prompt con "cinematic 1080p, synchronized audio". En su lugar: la resolución, aspect ra
- [4c5ba2b2ce9e] De la Etapa 4 en adelante: `shots.json`. Un cambio creativo se hace primero en shots.json y se propaga hacia abajo; nunca se parcha un prompt de forma que contradiga su shot.
- [1cf2b2af3609] `visual-prompt-forge` es dueño del **flujo de datos** (shots.json → borrador, critique.json → revisión selectiva). `video`/`image` smixs son dueños del **texto final** del prompt. El borrador del forge se reescribe a sintaxis smixs; nunca al revés.
- [b2a93a3b39b9] **Proyectos de animación** (2D/3D/motion graphics): es la única skill instalada con los 12 principios de Disney y el flujo de producción de animación. En un proyecto animado, su sección de animación se suma a la Etapa 3 como referencia de performance y timing.
- [036eba29584d] **Material didáctico o de cara al cliente en español**: glosario de terminología audiovisual ES-MX para briefs, capacitaciones o justificar decisiones ante cliente hispanohablante.
- [201666abd399] `references/creative-strategy.md` — Protocolo completo de la Etapa 1: territorios, big ideas, concept cards, matriz de selección, dirección narrativa. Léelo SIEMPRE al ejecutar la Etapa 1.
- [0574ba956e73] `references/production-package.md` — Spec del Final AI Video Production Package, reglas de trazabilidad y checklist maestro. Léelo SIEMPRE al ejecutar la Etapa 7.

## ai-production-director/references/creative-strategy.md

- [476511682f20] Si el single-minded proposition no se puede escribir en una frase, la Etapa 1 no puede continuar. Resuélvelo con el usuario primero.
- [240748ade236] De los territorios más fuertes, baja 3–5 conceptos (FILM) o 2–3 (STANDARD). Cada concepto es UNA película posible, no una variación de la anterior. Formato obligatorio:

## ai-production-director/references/production-package.md

- [eee77c7d576a] Todo prompt (imagen o video) lleva en comentario su `shot_id`.
- [f999ef3808aa] Todo shot en shots.json referencia su escena del script (`scene` field o nota).
- [8c97f2430a2a] El script referencia la concept card ganadora en su encabezado.
- [ed8f12484923] Cambios: si un prompt necesita cambiar algo que su shot fija (encuadre, acción, luz), el cambio se hace en shots.json y se regenera hacia abajo. El paquete nunca contiene un prompt que contradiga su shot.
- [69545d03256e] Verificación de cierre: muestrea 3 prompts al azar y traza la cadena prompt → shot → escena → concepto. Si un eslabón falta, el paquete no se entrega.
- [9848dbda5e26] [ ] Dirección cinematográfica sin vocabulario prohibido
<!-- SOURCE_FILE_END: repo/nblm-ids/ai-production-director.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/ai-video-storyboard.md -->
# SOURCE FILE: `repo/nblm-ids/ai-video-storyboard.md`

# Reglas del skill: ai-video-storyboard

35 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## ai-video-storyboard/SKILL.md

- [eb02f32299e5] **Core insight:** Visual consistency across shots matters more than any single shot being perfect. A mediocre but consistent set of shots edits together; six gorgeous but mismatched shots do not.
- [962fd158c1b1] **Do NOT use for:**
- [fe59b8611a5b] **Goal platform and duration?** (TikTok 30s / Reel 15-60s / YouTube Short / Instagram Ad / explainer)
- [4a161f379427] **What is the video about?** (subject, story, product)
- [53a3fb486be4] **Brand vibe / tone?** (cozy, energetic, premium, minimalist, playful, cinematic, etc.)
- [0a4395028757] **Call to action at the end?** (visit website, buy product, follow channel, etc.)
- [375413fbe1a3] **Any hard constraints?** (must include logo, specific colors, locations, etc.)
- [658b20f679d9] **Lens character** (shallow DOF / deep focus / wide angle distortion / macro)
- [ce8831e8984c] Write these as a **Visual Theme** block at the top of the output. Every shot's prompt must respect this block.
- [68f234798bd5] **Always specify the shared visual language** in every prompt (color palette, lighting, lens character, film look). This is how you enforce consistency.
- [87680002b885] **Specify exact duration** (4s / 5s / 8s) and **aspect ratio** (9:16 for TikTok/Reels, 16:9 for YouTube landscape, 1:1 for feed posts).
- [097929817bc7] **Always end with "cinematic 1080p, synchronized audio"** — this signals professional-grade quality and works with modern video models that support both.
- [79369bcf16d4] **Use cinematography vocabulary**: ECU (extreme close-up), CU, MS (medium shot), WS (wide shot), OTS (over-the-shoulder), POV, Dutch angle, low angle, high angle, bird's eye, dolly in, dolly out, tracking, handheld, rack focus, etc.
- [3dde58c707c6] **Don't write abstract prompts** — be concrete. "A woman" → "A barista in her late 20s with wavy auburn hair, wearing a denim apron".
- [60f13533c38e] **No model-specific hacks** — don't write prompts tuned to specific model quirks. Write model-agnostic cinematic prompts that work anywhere.
- [c04789da6e17] The sequence of shots must have a **story arc**, not a random list. Use one of these patterns:
- [f136c00c3d59] **Header** — Title, duration, shot count, aspect ratio
- [f44cf9ff7226] **Visual Theme** — Shared palette, lighting, lens, film look, motion
- [5598ee94689f] **Shot List** — N shots, each following the structure in Step 4
- [b08dd9e82d1c] **Post-Production Checklist**
- [ab3cc98cbe7f] **Why This Works** — creative rationale
- [8a413ce6fe28] MIT — use freely, commercial or personal.

## ai-video-storyboard/examples/tiktok-reel-30s-coffee.md

- [39512433dfc7] **Lens character:** Shallow depth of field, gentle bokeh, 35mm full-frame look
- [ca2cb60ffbf7] > Extreme close-up overhead shot of hot water pouring from a brass gooseneck kettle into a white ceramic V60 dripper filled with dark coffee grounds, the grounds blooming and rising in slow motion, warm golden backlight with visible steam curling upward, shallow depth of field, 35mm full-frame look, subtle 16mm film grain, deep espresso brown and cream color palette, muted saturation, cinematic 10
- [017d7bcfc4cf] > Medium wide shot slow dolly forward into a cozy specialty coffee shop interior, warm morning sunlight streaming through large windows on the left, reclaimed dark wood counter in sharp focus with shelves of handmade ceramic mugs blurred in background, dust motes visible in sun rays, muted sage green wall accents, shallow depth of field, 35mm full-frame look, subtle film grain, warm 3200K color te
- [7dc3223937b9] > Medium close-up slightly low angle of a female barista in her late twenties with wavy auburn hair tied back, wearing a denim apron over cream linen shirt, standing behind a dark wood café counter, soft window light from the left creating warm rim light on her hair, she looks down at a pour-over coffee in her hands then slowly looks up at camera with a genuine small smile, shallow depth of field,
- [b8d91aaa1e04] > Macro extreme close-up of a hand scooping whole dark roasted coffee beans from a burlap sack into a small wooden measuring cup, slow motion cascade of beans spilling out as the hand tips the scoop, warm directional window light from upper right creating strong shadow depth, individual beans visible in sharp detail, shallow depth of field, deep espresso brown and burlap cream palette, subtle 16mm
- [69193134c05e] **Purpose:** Show the space in use. Aspirational — "this could be you."
- [92efe93b2278] **Composition:** Medium shot (MS), over-the-shoulder angle (OTS)
- [498de0013578] > Over-the-shoulder medium shot of a young female customer sitting at a wooden window counter inside a coffee shop, her laptop open in soft focus, a handmade ceramic coffee cup in her hand, warm window backlight creating gentle rim light on her silhouette, amber interior lamps in background blur, she slowly takes a sip of coffee and briefly closes her eyes in appreciation, slow pedestal camera mov
- [556cbcfe637d] > Medium wide locked-off shot of a hand-painted wooden shop sign above a dark-framed café door, below it a small chalkboard reading "Opening Saturday", a hand reaches in frame to hang a wooden "OPEN" sign on the door handle, soft even morning light, sage green accent wall visible, warm muted palette, shallow depth of field on the door, 35mm full-frame look, subtle film grain, cinematic 1080p, sync
- [81a8cfa35760] [ ] Generate all 6 shots with your preferred AI video tool
- [ab185f56879d] [ ] Add 0.3-0.4s **dissolve transitions** between Shots 1→2, 2→3, 4→5. Use a **hard cut** for Shot 3→4 (energy shift) and Shot 5→6 (CTA impact)
- [b8cf8ac90edc] **Visual consistency:** Every shot shares the same color palette (espresso/cream/amber/sage), the same lighting temperature (warm 3200K with motivated window light), the same lens character (shallow DOF, 35mm), and the same film look (subtle 16mm grain). Even if the 6 shots are generated in separate runs, they will edit together as if shot by the same cinematographer in the same session.
- [ac436694e34e] **Why the prompts work:** They lean heavily on concrete cinematic vocabulary (shallow DOF, rim light, warm backlight, film grain) — specifics that modern AI video models can actually execute. The synchronized audio direction means each shot arrives with ambient café sounds pre-baked, dramatically reducing post-production sound design time.
<!-- SOURCE_FILE_END: repo/nblm-ids/ai-video-storyboard.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/brand-lock-extractor.md -->
# SOURCE FILE: `repo/nblm-ids/brand-lock-extractor.md`

# Reglas del skill: brand-lock-extractor

89 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## brand-lock-extractor/SKILL.md

- [ebc1422e5d22] This skill extracts. It does not invent. Every value is sampled from a real asset or flagged as an estimate the user must confirm. A confident-sounding wrong hex is worse than a flagged guess.
- [fcc9a56efa31] Written description | Use directly | Identity, archetype, voice posture
- [96e709999be1] Tell the user what you are pulling. Do not ask follow-ups yet, extract first, confirm gaps at the end.
- [5fe217339055] **Identity** (brand, one-line description, archetype, voice posture)
- [0dae3fdc0ace] **Palette** (sampled hex, by role)
- [39e68cb30388] **Typography** (display, body, optional mono, with weights)
- [c183542f6090] **Mood adjectives** (3-5, specific, contrast clauses preferred)
- [6257a4f1fd42] **Never list** (what the brand avoids, inferred from consistency)
- [89c96fc0932b] **Aspect ratios**
- [ddd43db015c9] **Color grade direction** (one sentence)
- [4075284680a4] **Motion language** (one paragraph)
- [086086b8d7f3] **Voice rules** (copy-level constraints)
- [c9c3a9312a4c] **inferred**, reasoned from evidence but not stated (archetype from positioning, never-list from consistency). Reasonable to ship, worth noting.
- [cd4c7a7c3646] Use `templates/brand-lock.md.tpl`. Fill **every** required section, no placeholders left behind. Then append an `## Extraction notes` section that lists every `inferred` and `needs confirmation` value with its source and your reasoning. This section is the audit trail; it does not break validation (the validator checks the nine required sections are present, extra sections are fine).
- [49fd83a4b509] All nine required sections present: Identity, Palette, Typography, Mood adjectives, Never list, Aspect ratios, Color grade direction, Motion language, Voice rules.
- [06963ad7d543] > "Here is your brand-lock. I sampled the palette and type from your assets and flagged N values that need your eyes (see Extraction notes). Drop it in `brand-packs/`, confirm the flagged values, and run `python tools/validate_brand_lock.py path/to/file.md` to verify. Then: `'30-second explainer. Use brand-packs/your-brand.md as the brand lock.'`"
- [afdb75007c72] Colors are sampled, never guessed. Read them from a brand book, from CSS, or by sampling pixels in a screenshot. If you genuinely cannot determine a color, fill your closest estimate and mark it `needs confirmation` in Extraction notes. "Navy" is not a palette entry. `#0F1F3A` is. A wrong hex stated confidently corrupts every downstream prompt.
- [6eb4f8ba4dbc] Identify fonts from the brand book, the site's CSS/font files, or clear visual match. If you cannot identify one, say so and flag it, do not name a plausible-sounding font you did not verify.
- [03ede5f175d7] It is also the hardest to extract, because brands document what they do, not what they avoid. Infer it from consistency: if every image avoids stock-photo gloss, that is a never. If copy never uses exclamation points, that is a never. Read `references/extraction-rubric.md` for the method. Do not ship an empty never-list.
- [165991e88830] `examples/` contains a worked extraction: the source material provided (`input-brief.md`) and the `brand-lock.md` produced from it, including the Extraction notes audit trail. Use it to calibrate the level of specificity and the confidence flagging.

## brand-lock-extractor/brand-packs/README.md

- [5cff35ce456c] Copy `_template.md` to a new file (e.g. `acme.md`)
- [e49a82b5336a] Fill in every field. No placeholders left behind.
- [3e5b03db5bd2] Reference it from your storyboard requests:
- [242353d6abcd] > "30-second founder explainer. Use `brand-packs/acme.md` as the brand lock."
- [ab8ee2cc3cfb] The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.
- [3f9aad2c4e2c] **Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.
- [db7addc154a9] **`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.
- [df43eb92b1b2] Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

## brand-lock-extractor/brand-packs/_template.md

- [18cee24eb65b] Role | Hex | Use
- [c5e62839e1ee] Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.
- [2f545717c91e] What this brand never does, visually or tonally. Be specific.
- [e03457ae7069] never use stock photo aesthetic
- [25f0ecf00da8] never use AI uncanny faces
- [1acd5803bd0f] never over-saturate
- [3214012dc24d] never shout in copy
- [250eda4c5849] never use clip-art icons
- [5ada3d9e3057] How footage and generated images should be graded. One sentence.
- [74acfc03835c] > e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

## brand-lock-extractor/brand-packs/examples/saas-clean.md

- [073359ebd4a2] Role | Hex | Use
- [3d50d9dc8cee] never use stock photo aesthetic
- [2b77fe0ab77d] never use AI uncanny faces
- [528f3aca58d3] never use illustrations of people (real photography or abstract data viz only)
- [34f304b45ae2] never use gradients (flat color only)
- [70f50258fc9f] never use rounded corners larger than 8px
- [a61acb519eac] never use exclamation points
- [39f21f0bd621] never use vague claims ("the best", "industry-leading", "cutting-edge")
- [bdeeca395947] never use AI/ML buzzwords without specifics
- [21f3127a222e] never default to dark mode in primary marketing
- [289646ec1639] never use animated icons or lottie illustrations
- [5108ce119398] prefer specific numbers ("40% reduction in 90 days" not "significant improvement")
- [98944bc5d597] prefer "we" and "you" over "the company" and "the user"
- [5e5cfb4ec221] prefer present-tense
- [cc15db8a3ce1] never start a sentence with "Just" or "Simply"
- [f861a19be4ca] avoid corporate hedge language ("seek to", "look to", "aim to")

## brand-lock-extractor/examples/brand-lock.md

- [16a2f6133356] Role | Hex | Use
- [42b960dda0f5] never use stock smiles or posed lifestyle photography
- [e320951a2f69] never use latte art as decoration
- [deff6acf6ba6] never use the word "artisanal"
- [995266039bd6] never use exclamation points
- [9c0afb7d325a] never shoot glossy product-on-white; matte and natural-light only
- [00c5d773e8d3] never lean on burnt, dark-roast cliche imagery
- [a9ed618bb40b] > Matte, low contrast, natural window light, warm but restrained. Reminiscent of Kinfolk editorial photography. Never glossy commercial product lighting.
- [2d715d9073e7] never the word "artisanal" (or "curated", "elevated")
- [b5797c1841f0] short declarative sentences; cut adjectives before nouns that do not need them
- [fb243b53c635] prefer specific origin claims (farm, region, roast date) over vague quality words
- [007361a9a9c7] Audit trail for this extraction. Values not listed here were read directly from an asset (`extracted`): the four palette hex from the site CSS, both font names from the CSS, the never-list lines from the brand sheet, and the aspect ratios from the brand sheet.

## brand-lock-extractor/examples/input-brief.md

- [b10928de456e] Photography: matte, low-contrast, natural window light. Beans, hands, kraft bags. Never glossy product-on-white.
- [4f015f7fb337] "We don't do: stock smiles, latte art as decoration, exclamation points, or the word 'artisanal'."

## brand-lock-extractor/references/extraction-rubric.md

- [daf6cf4dbcb9] **inferred**, reasoned from evidence, not stated. Archetype from how the brand frames problems. Never-list from what the assets consistently avoid. Ship it, note the reasoning.
- [d446778cd38a] **One-line description:** what the brand does and who for. This is the load-bearing sentence; a generator implicitly references it on every prompt. Pull it from the hero headline plus the about page. Prefer concrete over abstract: "Managed bookkeeping for solo law firms" beats "Financial services for professionals." If the site only offers a vague tagline, sharpen it from the services/about copy a
- [b4fbf43a4a92] **Archetype:** one word, Operator, Sage, Caregiver, Rebel, Creator, Jester, Ruler, Everyman, etc. Almost always `inferred`. Read it from how the brand frames the customer's problem:
- [04363c882bf7] **Never guess a hex.** If you cannot read or sample one, estimate, label it `needs confirmation`, and tell the user exactly which role to verify. (See SKILL.md Rule 1.)
- [a69c36bdec51] **Screenshots:** identify by eye only if confident; otherwise flag `needs confirmation`. Do not invent a plausible name (Rule 2).
- [a1ad2f291171] 3-5 adjectives, specific, contrast clauses preferred. Read tone from the body copy and the imagery together.
- [775e72423ee9] The hardest and most valuable section. Brands document what they do; you infer what they avoid from consistency across the assets.
- [3f18cfa9b5e8] Imagery: no stock-photo gloss? no people? no gradients? no clip-art icons? Each absence is a never.
- [a86e2eb18131] Copy: no exclamation points? no hype words ("revolutionary", "game-changing")? no emojis? no questions in headlines? Each pattern is a never.
- [451be222e3f4] Color/layout: never full-bleed photography? never more than one accent? never centered body text?
- [f419380942de] Turn each observed constraint into a `never` line. Be specific: "never use stock-photo aesthetic" beats "keep it authentic". Aim for 5+. Never ship an empty list (Rule 4).
- [dd519aa232b4] One sentence on how footage and generated images should be graded, with a reference point where possible (Kodak Portra 400, Apple keynote photography, A24 film grade). Infer from the existing photography's warmth, contrast, and saturation. If there is no photography to read, base it on the palette and flag `needs confirmation`.
- [5a0a397f54c1] One paragraph: camera moves, cut style, text animation, pacing. Read from any existing video or motion on the site; if there is none, infer a conservative default consistent with the voice posture (a Quiet/Authoritative brand -> minimal, slow, deliberate) and flag `needs confirmation`. Keep it to one coherent motion language, do not blend "minimal and deliberate" with "energetic whip pans".
- [f3fad8754516] Copy-level constraints for VO and on-screen text. Many overlap the never-list but are phrased as authoring rules: "no em dashes", "sentences under 14 words", "prefer specific numbers over vague claims", "no exclamation points in headlines". Extract from observed copy patterns. These become prompt constraints downstream, so make them enforceable, not aspirational.

## brand-lock-extractor/tools/README.md

- [697ee94e32d3] Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
- [c9c4d69a1e9d] Checks a brand-lock has all required sections and Identity fields, that its palette declares
- [4f5a12623761] `<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.
- [d06f5a7d29d6] to be identified, and a named generator has to exist in the capability matrix.
- [43590512414d] a frame on disk with no critique for its round, never reviewed at all
- [4833d679d27e] template the skill uses, through the small engine in `_template.py`. It did not always: the
- [540c0d3d82a5] never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
<!-- SOURCE_FILE_END: repo/nblm-ids/brand-lock-extractor.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/image.md -->
# SOURCE FILE: `repo/nblm-ids/image.md`

# Reglas del skill: image

167 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## image/SKILL.md

- [11ea00e863de] The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone. The actual rules — what the models reward, what they punish, how to phrase a 5-slot template, when to add `quality: high`, when to use image grounding — live only in the reference files.
- [3f921ee68519] **Motion, clips, montage** (Seedance, Kling, Veo, any image-to-video): use the sibling `video` skill. This skill's storyboard and keyframe outputs feed it.
- [e00683c0b45f] Image grounding for real locations. Extreme aspect ratios (1:8, 8:1, 4:1). Thinking mode. JSON for 5+ elements. Up to 14 reference images. Why you must NOT write `50mm / f-stop / ISO` numbers.
- [7753f474afb0] 5-slot template (Scene / Subject / Important Details / Use Case / Constraints). Anti-slop banned-words list. `quality: low / medium / high` as a deliberate fidelity lever. Size constraints (multiples of 16, max 3:1, up to 2560×1440). Two-column edit logic (Change / Preserve / Constraints). Up to 16 reference images with explicit roles.
- [485206c1697b] Universal rules that apply to both models: start with a verb, positive framing, hex colors, quote text, edit don't re-roll, one change per iteration, reference images.
- [67a7dd9329dc] For edits, also include an explicit preserve-list (mandatory for gpt-image-2, recommended for nano-banana):
- [890a0b28f120] Prefer: ready-to-copy prompts, hex colors, concrete materials, named compositions, model-specific syntax (5-slot for GPT Image, natural prose for Nano Banana).
- [0e7900ffe2af] Avoid: tag soup ("cool, modern, 4k"), vague praise ("stunning, epic, masterpiece" — actively hurts GPT Image 2), negative framing ("no people, no cars" — invert to positive), external comparisons ("like Apple ad" — describe the visual properties instead), numerical lens parameters in Nano Banana prompts (it ignores them).

## image/references/creative-direction.md

- [09ec7d23fe12] Hasselblad — medium format, shallow DOF, fashion/portrait
- [b921448eda9a] "Waist-up portrait", "full body", "over-the-shoulder"
- [b8fa85d560e3] "Shallow depth of field" — blurred background
- [5ad1340da288] > descriptive terms. Prefer "shallow depth of field" over "f/1.8".
- [862a4c0ea3bc] Define physical makeup of subjects. Don't just say the thing — describe what it's MADE of.

## image/references/golden-rules.md

- [d9bcca3cf113] Describe what you WANT, not what you don't want. The model understands presence better than absence.
- [1dd54b582a02] ✅ "empty street" → ❌ "street with no cars"
- [7fff008d0b4a] ✅ "clean background" → ❌ "no clutter"
- [f5bdd52eae18] ✅ "solo portrait" → ❌ "no other people"
- [cc4167f1d432] ❌ Bad: "Cool car, neon, city, night, 8k"
- [8d02f99b51e9] ✅ Good: "A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. Neon signs reflect off wet pavement and metallic chassis."
- [8901152207fe] "for Brazilian gourmet cookbook" → infers professional plating, shallow DOF
- [dd9305290d20] Используй для:
- [04c28ccbddf9] **Используй как HIGH-LEVEL steering** — якорь задаёт настроение и эстетику, а не заменяет весь промпт
- [3db8f42e251f] **Комбинируй с конкретными визуальными деталями** — якорь устанавливает мир, детали устанавливают специфику
- [16ec02525ce7] **Не стакай несколько genre anchors** — выбери один. "Peter Lindbergh + Wes Anderson" = каша
- [47652229b5ab] **Era/cultural anchors работают лучше с GPT Image 2** (world knowledge). С Nano Banana результат менее предсказуем — NB больше опирается на явные описания

## image/references/gpt-image.md

- [0fdc95a5bbec] ❌ Не пиши | ✅ Пиши
- [1848820351ae] мудовый язык, в котором тонут функциональные требования | прямое заявление: «image must contain a transit kiosk»
- [20e10fa23ffc] Маленький/плотный/multi-font → `quality: high` обязательно.
- [26e0c5fc6ab4] **Object removal:** «Remove [X]. Do not change anything else. Use `input_fidelity: high` to maintain surrounding context» (только gpt-image-1.5/1, в gpt-image-2 high-fidelity по умолчанию).
- [822ae545689f] GPT Image 2 умеет домысливать контекст: «Bethel, NY, August 1969» → выведет Woodstock-эстетику. Используй: дай исторический/культурный анкер, не расписывай каждую деталь.

## image/references/models.md

- [c10c7e21ff29] **Структурированный 5-slot промпт.** Чёткое разделение Scene/Subject/Details/Use case/Constraints даёт предсказуемость.

## image/references/multi-panel.md

- [c842524ed79f] **When to use:** TVC or commercial shot breakdown — one image = 9 panels with scene titles and timestamps.
- [a127cca4810d] **Recommended size:** 1536x1024 (landscape)
- [e01904554508] Vague scene descriptions produce near-identical panels — each must have a distinct action, angle, or subject
- [3d26f71cccce] **When to use:** Same person shown from 4 angles/crops in one image for an editorial or casting look.
- [52c7e13d4185] **Recommended size:** 1024x1024 (square) or 1024x1536 (vertical for portrait emphasis)
- [796a278bda86] **When to use:** Hero shot + close-up + action for a campaign visual — horizontal or vertical triptych.
- [3a5fb89a88b1] **Recommended size:** 1536x1024 (horizontal triptych) or 1024x1536 (vertical triptych)
- [7421490e82fa] **Model:** GPT Image 2 `quality: medium` — if text overlay needed, use `quality: high`
- [576f2ecf7dd2] **When to use:** 12 panels telling a story or showing moods — no gaps between panels, seamless mosaic feel.
- [5eca40f8b2dc] **Recommended size:** 1536x1024 (landscape) — gives each cell enough resolution
- [e25ece2ca897] **When to use:** Fashion editorial or film-style sequence — multiple camera angles of the same scene in one image.
- [0237812f9545] **Recommended size:** 1536x1024 (landscape, 3x2 grid)
- [79ad480edaab] Top-down and low-angle in the same grid confuse the model if you don't anchor each frame to a grid position
- [921aa8a23672] Motion blur instruction must be specific ("blur on hands and feet") or the model applies blur everywhere
- [d9727650ad44] **When to use:** Product transformation, makeover, time comparison, renovation — two states side by side.
- [90d4b17bba47] **Recommended size:** 1536x1024 (landscape — gives each half a portrait-like proportion)
- [910dd4553129] **Model:** GPT Image 2 `quality: medium` — for text labels ("BEFORE" / "AFTER"), use `quality: high`
- [d8c349628ad4] Left/right assignment matters — always state which side is before and which is after
- [1e4fc13d2d29] **When to use:** Full narrative in one image — 3x4 grid (3 columns, 4 rows) for animation or video pre-production.
- [a0be4760c51c] **Recommended size:** 1024x1536 (portrait — 3 columns x 4 rows needs vertical space)
- [1062c830e923] **Model:** GPT Image 2 `quality: high` (text-heavy — scene numbers and captions must be readable)
- [eb71e5086205] Art style must be stated once and applied uniformly; mixing styles across panels produces visual chaos
- [bf6161618f55] **Subject consistency:** Always include an explicit instruction: "same person / same character / same product across all panels." Repeat key identity markers (hair color, clothing, distinguishing features) rather than saying "same as before."
- [f6982091002c] **Grid specification:** Always state the grid dimensions (e.g., "3x2 grid, 3 columns 2 rows"). Saying "6 panels" without layout instruction lets the model choose an unpredictable arrangement.

## image/references/nano-banana.md

- [dabc108ffb16] Числовые параметры объектива: **50mm, 85mm, f/2.8, ISO 400** — NB игнорит. Используй описание: «shallow depth of field», «wide-angle distortion».
- [0456a3106233] Включён по умолчанию; у NBP отключить нельзя (модель рисует до 2 «thought images» в бэкенде, они не тарифицируются как картинки, но thinking-токены платные). У NB2 есть рычаг `thinking_level: minimal | high` (default `minimal`) — поднимай до `high` для:
- [a509f495c750] Interactions API держит контекст сессии — до 3 последовательных правок стэкаются без потери исходника. Правило «Edit, don't re-roll»: картинка верна на 80% — проси точечное изменение, а не новую генерацию.
- [82d4b1aa2d36] **Хэндофф в видеомодель — motion brief, не пересказ.** Движение камеры, движение субъекта, движение фона, длительность, framing lock, запрещённые изменения. Видео-промпт не переописывает то, что уже есть в кадре.
- [3de5ceee5c4e] Инфографика может содержать фактически неверные данные — цифры проверять всегда, grounding помогает, но не гарантирует.

## image/references/patterns/character-design.md

- [f7781b9ee5c2] Use for game or animation pre-production — front, side, and back views of a character on a single white canvas with color callouts and height reference lines.
- [31a9f9f11aa7] **Recommended model:** GPT Image 2 (`quality: high`) — height reference lines and color callout text require precise rendering
- [a8c47d2e697e] Use to produce a grid of 6–9 facial expressions for the same character — consistent head angle and art style, with emotion labels under each face.
- [b5749680d5b1] **Recommended model:** GPT Image 2 (`quality: high`) — text labels and consistent facial identity across 9 cells need precise control
- [e849bbafb08a] Use to show one character in multiple outfits or costumes — for fashion exploration, game skin concepts, or wardrobe design.
- [608c66f4b15a] **Recommended model:** GPT Image 2 (`quality: medium`) — character consistency is the priority; `high` only if outfit labels need fine legibility
- [639574d396e1] Use to transform a realistic character into a cute 3D collectible figurine — oversized head, compact body, multiple poses performing different activities.
- [be07ac1a9f48] **Recommended model:** GPT Image 2 (`quality: medium`) — smooth 3D vinyl surfaces render well at medium; `high` for marketing-ready close-ups
- [bc5138b583ba] Use for a full character reference card with portrait, full body, key items, and color palette — organized on a white background in a professional concept art layout.
- [ee853dd503fd] **Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout with hex codes, labels, and stat block requires precise rendering

## image/references/patterns/ecommerce.md

- [c3d4dd460549] Use when you need a playful, attention-grabbing product visual where tiny workers interact with an oversized product — ideal for social media ads and launch campaigns.
- [19234ef99d6a] **Recommended model:** GPT Image 2 (`quality: high`) — precise figurine detail and product label legibility
- [6a46a42327af] Use for premium beauty or fragrance product photography — dark, moody, tactile surfaces with atmospheric effects.
- [9a00a07b257d] **Recommended model:** GPT Image 2 (`quality: high`) — surface materials and condensation detail
- [afdcc8f7bc89] Use to present a product commercial shot breakdown in a single image — pitch decks, creative presentations, client approvals.
- [4f23b10353c9] **Recommended model:** GPT Image 2 (`quality: high`) — grid precision and text in panel 9
- [09817e522cce] Use for food, beverage, or supplement products where suspended ingredients communicate freshness, flavor, or composition.
- [d1f50fd09fa8] **Recommended model:** GPT Image 2 (`quality: high`) — frozen detail precision and label legibility
- [6fc560223ecb] Use for disruptive, scroll-stopping social ads where the product packaging appears squeezed, inflated, or physically distorted as if made of soft rubber or vinyl.
- [bf758f621b50] **Recommended model:** NBP — complex spatial reasoning for believable physical distortion

## image/references/patterns/fashion-editorial.md

- [e85f3a2c01a5] Use for fashion brand campaign hero images — one wide shot combining hero pose, close-up detail, and action/movement in a triptych layout.
- [e200695107d8] **Recommended model:** GPT Image 2 (`quality: high`) — identity consistency across panels and fabric texture detail
- [ce04a04c45aa] Use for model tests, casting cards, or editorial portfolio pages — four angles of the same person in a clean grid.
- [97ef5791058f] **Recommended model:** GPT Image 2 (`quality: high`) — identity consistency critical across four frames
- [9b5c3232e804] Use for streetwear drops, limited edition launches, or urban fashion brand campaigns where bold type dominates the composition.
- [348b0b1ed027] **Recommended model:** GPT Image 2 (`quality: high`) — text rendering and model-type depth interplay
- [1bf69ac8c5e3] Use for playful, nostalgic sportswear or athleisure campaigns with 70s-80s visual language.
- [eb03e137df6e] **Key levers:** `{model_description}`, `{outfit_description}` (high-waisted terry shorts in coral, cropped zip-up in cream, tube socks with racing stripes), `{location_description}` (Venice Beach boardwalk, empty suburban tennis court, coastal promenade), `{film_stock}` (Kodak Gold 200, Fuji Superia 400), `{palette_description}` (terracotta #CC5533, cream #FFF5E1, sky blue #87CEEB, mustard #D4A017
- [c5971eabbb4b] **Recommended model:** NB2 — natural movement, analog film grain, atmospheric grounding
- [6dfcd0919723] Use for forward-looking athletic or techwear editorials where abstract 3D forms create a surreal spatial environment around the model.
- [ce24e75d12a1] **Recommended model:** NBP — complex spatial reasoning for blob placement and reflections

## image/references/patterns/food-beverage.md

- [46ce53039819] Use for premium chocolate or confectionery brand visuals — moody, textural, with controlled color and atmosphere. Adaptable across mood variants (dark indulgence, bright artisan, earthy origin-story).
- [a9c702b552f4] **Recommended model:** GPT Image 2 (`quality: high`) — fracture detail and cocoa powder precision
- [20bb122f18fb] Use for premium beverage brand campaigns that combine lifestyle and product in a structured board layout — model shot + hero product + product lineup.
- [1ba1ff7577c8] **Recommended model:** GPT Image 2 (`quality: high`) — label legibility and panel consistency
- [d4f497bb93d1] Use for hero food posters — restaurants, delivery apps, menu boards — where the food is the entire composition with fillable content slots.
- [4c926ca35845] **Recommended model:** GPT Image 2 (`quality: high`) — steam, condensation, and ingredient texture fidelity
- [df532917ca8c] Use for educational food content, ingredient features, or artisanal brand storytelling — the food item rendered as a scientific illustration in the style of 19th-century naturalist prints.
- [a30c3b235f2e] **Recommended model:** NB2 — naturalist illustration style, grounding on botanical plate aesthetics
- [de44302b8294] Use for restaurant guides, food festival materials, travel content, or local cuisine features — a bird's-eye illustrated map showing food specialties across a city.
- [d62c529d34db] **Recommended model:** NB2 — image grounding for real city landmarks + illustration style

## image/references/patterns/portrait-cinema.md

- [bdc7c98423b2] Use for warm, emotive street portraits with strong backlight flare — editorial, personal branding, album covers.
- [e80f84e82cd7] **Key levers:** `{street_description}` (narrow European alley with stone walls, wide boulevard with linden trees, industrial backstreet with brick), `{person_description}`, `{expression}` (quiet confidence, mid-smile with closed lips, contemplative gaze), `{bounce_surface}` (cream-painted wall, parked white van, sand-colored buildings), `{clothing_detail}` (linen shirt collar, leather jacket shoul
- [2260c15e96b4] **Recommended model:** GPT Image 2 — backlight exposure control and skin rendering
- [36bbbe701ad0] Use for urban night portraits with mixed artificial lighting — fluorescent overhead + colored neon signage creating a chromatic push-pull on the subject's face.
- [5b0ec72c5a49] **Recommended model:** GPT Image 2 (`quality: high`) — precise dual-light color rendering on skin
- [9a20603f7d87] Use for edgy, tech-forward portraits — artist profiles, electronic music press, tech brand campaigns. High contrast black-and-white with selective red digital artifacts.
- [29940f3cd9ae] **Key levers:** `{person_description}`, `{direction}` (left, right), `{hair_detail}` (tight buzz cut showing skull contour, shoulder-length hair with flyaway strands catching backlight, pulled-back bun), `{glitch_positions}` (across the eye, across the mouth, across the forehead — specify 2-3 positions), `{accent_color}` (#FF0000 red, #00FF41 terminal green, #FF00FF magenta), `{max_glitch_lines}` 
- [f708635c6957] **Recommended model:** GPT Image 2 — high-contrast mono rendering and controlled glitch placement
- [b8ecc6c820c5] Use for moody, atmospheric portraits with overexposed analog film qualities — muted colors, lifted shadows, and a feeling of faded memory. Ideal for editorial, zine, or personal project work.
- [25c7ab649b75] **Recommended model:** NB2 — analog film grain emulation and atmospheric mood
- [b6f22ea21acd] Use for beauty campaigns, conceptual art, or album visuals — a portrait where the subject floats in clear water surrounded by translucent aquatic elements.
- [be5a2e46231a] **Recommended model:** NBP — complex physics (floating hair, fabric, fish transparency, caustic light)

## image/references/patterns/poster-illustration.md

- [5c934f24e5bd] Use for urban development campaigns, anniversary materials, cultural exhibitions, or editorial features — a single city view divided down the middle, one half historical and one half modern.
- [535d74d81a91] **Recommended model:** NBP — spatial reasoning for architectural morphing and perspective consistency
- [44c898225d80] Use for sport and fitness brand campaigns — a dynamic 3-panel collage combining action, detail, and atmosphere around a boxing/combat sport theme.
- [4c1d2cabad77] **Recommended model:** GPT Image 2 — identity consistency across panels and sweat/texture detail
- [7b6acbb90a0a] Use for tech product launch visuals — clean, color-dominant hero shots where a smartphone (or similar device) floats against a monochromatic gradient with soft 3D accent elements.
- [57fca5220269] **Recommended model:** GPT Image 2 (`quality: high`) — text rendering, screen content legibility, device accuracy
- [c755ff2903b8] Use for fashion drops, event announcements, or editorial magazine covers where bold typography and a street fashion figure share equal visual weight on a saturated color field.
- [cd1fa75558c5] **Recommended model:** GPT Image 2 (`quality: high`) — typography rendering and figure-type layering
- [803245de38c4] Use for decorative prints, packaging illustration, wallpaper design, or editorial art — a symmetrical composition combining a peacock with botanical elements in a vintage printmaking style.
- [b6a40416c21b] **Recommended model:** NB2 — image grounding for accurate peacock anatomy and botanical species

## image/references/patterns/ui-social.md

- [7a21ad4f3c7d] Use for vertical product or brand ads targeting Instagram Stories — hero product, bold headline, and swipe-up CTA zone at the bottom.
- [be784fefef07] **Recommended model:** GPT Image 2 (`quality: high`) — headline text legibility and glassmorphism transparency effects need precision
- [f5f07232cc75] Use for square-format posts on Instagram or Facebook — quote cards, feature announcements, or product highlights with centered layout.
- [ac9f15b7d326] **Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout; legibility at small sizes is critical
- [76fa850073b5] Use to create a polished App Store or Google Play listing screenshot — device frame with app UI inside, feature headline, and clean gradient background.
- [d4e8f76bb757] **Recommended model:** GPT Image 2 (`quality: high`) — device bezel precision, small UI text, and headline legibility all demand high quality
- [b1a90c3a0a1d] Use for realistic analytics dashboard mockups — dark or light theme with data visualizations, KPI cards, and sidebar navigation.
- [8f24d3e22d84] **Recommended model:** GPT Image 2 (`quality: high`) — dense text (labels, numbers, navigation), precise chart rendering, and small UI elements require high fidelity
- [6b8e9a41cbf9] Use to create a visual color analysis graphic from a portrait — seasonal palette classification, clothing color comparisons, and accessory recommendations in an organized layout.
- [5bb61a5742b2] **Key levers:** `{subject_description}` (age, skin tone, hair color, eye color — needed for accurate seasonal analysis), `{season_type}` (Warm Spring, Cool Summer, Warm Autumn, Cool Winter — or sub-seasons like Soft Autumn, Bright Winter), `{palette_colors}` (12 hex values matching the season, e.g. Warm Autumn: rust #B7410E, olive #708238, mustard #E1AD01, burgundy #722F37...), `{num_palette}` (12
- [e3ff88ae7b6f] **Recommended model:** GPT Image 2 (`quality: high`) — color accuracy of palette swatches is critical, plus small text labels throughout

## image/references/prompt-framework.md

- [e3f6e1ce49a2] **Обязательные:**
- [c8d4fff1dabe] **Палитра** - цвета (лучше hex)
- [58817d380494] > - **Nano Banana** — игнорит числа, пиши описательно («shallow depth of field»)
- [85e2a5dc4aa8] > Формулируй позитивно! NBP лучше понимает "clean background" чем "no clutter"
- [5856058c8a75] Переменные записываются как `{name, default="value"}`. Если значение не указано — используется дефолт. Если дефолта нет — переменная обязательна.
- [84828d3c69a2] **Заменяй только то, что меняется** — остальное берётся из дефолтов
- [a90636943228] **Структура стабильна** — порядок слотов одинаковый для всех вариаций, модель получает консистентный формат
- [8005da81a345] **Batch-генерация** — идеально для серий: продуктовые ракурсы, позы персонажа, локации в одном стиле
- [42a42a73fa09] **Surface wear & aging** — "chipped paint on window frame, hairline scratches on metal surface, green patina on copper fittings, oxidation marks on iron hinges"
- [4bc498edcc17] **Micro-textures** — "visible pores on skin, individual hair strands catching backlight, fabric weave pattern on linen shirt, grain of weathered wood"
- [bc6d5c9aff5f] **Atmospheric particles** — "dust motes suspended in light beam, steam wisps rising from coffee cup, pollen floating in golden hour air, fine rain droplets on glass surface"
- [318b118d917d] **Specular behavior** — "specular highlights on metal edges of watch, caustic reflections dancing inside glass bottle, wet surface sheen on cobblestones after rain"
- [92eeb4747a7e] **Fabric & material drape** — "natural fabric folds at elbow crease, gravity pull on loose linen garment, weight distribution visible in heavy wool coat"
- [51b0bfedb210] **Contact shadows** — "soft contact shadow where cup meets saucer, ambient occlusion in crevices of stone wall, dark line where book spine meets table"
- [329aa0a4fa84] **Environmental reflections** — "building reflections in wet pavement, sky gradient in chrome bumper surface, warm neon glow on skin from nearby sign"
- [11ec80431f42] **Motion cues** — "slight motion blur on trailing hair strand, frozen splash droplet from espresso pour, wind-displaced fabric edge of scarf"

## image/references/slides.md

- [796d88912233] Избегай pure white #fff на чёрном - используй #f5f5f5
- [2f0619f0ec28] Контент должен дышать

## image/references/storyboards.md

- [c9068adfe734] "Identity must stay consistent throughout"
- [3244bb3011e7] "Expressions and poses should vary"

## image/references/structural.md

- [2cb77800410c] **What** proportions to use
- [f2ffb547ac87] Use reference for:

## image/references/text-rendering.md

- [8e32b234137b] Ask the model to write/refine the text content
- [7447d548b9f0] Then ask for an image with that exact text
- [0db1539c575d] Upload with prompt: "Use layout from attached image"

## image/references/vision-decomposer.md

- [7e22722f52fa] Use this reference when the user asks to analyze an image and convert it to a generation prompt: **style transfer**, **mood reference**, **"сделай промпт по этой картинке"**, **"перенеси стиль/образ"**, **"проанализируй кадр"**, **"image to prompt"**, **"reverse-engineer this look"**.
- [442a75c51f58] The process has two strict steps. Do not skip Step 1. Do not freestyle Step 2.
- [a712726b25c7] **Figure & ground (Arnheim):** degree of subject isolation, overlapping of forms, mass relationships. Use of reflections (mirrors, windows) to expand context.
- [04cb7f3e5408] **Broken light & reflexes (Zheleznyakov):** use of shadow masks (gobos), light through blinds / foliage, color reflexes from neighboring objects onto skin / clothing.
- [7d2338d1b298] **Camera (angles & viewpoint):** Angle (High angle, Low angle, Eye-level, Dutch tilt). Objective camera, Subjective, POV, Over-the-shoulder (OTS). Movement imitation (Push-in, Tracking shot).
- [3d2a2115477d] Describe **strictly what you see**. Do not invent new objects.
- [7cf887e9d7c2] **No filler.** Never write "The image shows...", "A picture of...", "I can see...".
- [526a0bad384e] Do NOT load this for: pure generation requests where no reference image is given. For those, use the standard model files.
<!-- SOURCE_FILE_END: repo/nblm-ids/image.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/produccion-visual-sw30.md -->
# SOURCE FILE: `repo/nblm-ids/produccion-visual-sw30.md`

# Reglas del skill: produccion-visual-sw30

45 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## produccion-visual-sw30/SKILL.md

- [dadff5459383] respuesta honesta a esta pregunta no sea SÍ SIN MATICES:
- [67008f8c2960] Si la respuesta es NO: no se entrega. Se leen los archivos faltantes, se aplica lo que falte y
- [ab216a6c933f] Prohibido responder SÍ para complacer. Un SÍ falso es una mentira y cuesta más que el NO.
- [5c17fa63163e] Prohibido responder SÍ con matices, condiciones o notas al pie disfrazadas de honestidad.
- [760b8e4708d1] (SKILL.md indica el orden obligatorio), no fragmentos ni grep.
- [26da6aecb6fb] Orden de dirección: nunca se escribe un prompt de corrido ni se parchea texto. Tres pasos, en este orden:
- [e420b46bb400] **CATALOGAR** — identificar el TIPO de prompt y leer qué reglas aplican a ese tipo en la matriz
- [2d922b05c376] **DEFINIR SECCIONES** — antes de redactar, listar las secciones que ese tipo exige. Cada regla vive
- [6ca53cccfb89] colour, hair, fabric, clean_*, autocontain_*), nunca en texto suelto dentro del brief.
- [91c96c167fa3] **ENSAMBLAR POR SECCIÓN** — el prompt se construye llamando P(scene, subject, [details], mood,
- [34d661f0601e] `rule_registry.py` — relee los 23 archivos del skill image y EXTRAE mecánicamente cada enunciado
- [33f4eb1675f2] `rule_ledger.py` — obliga a que CADA regla aplicable tenga disposición explícita: CHECK (existe
- [b37aa531231e] `audit_gi2.py` — verifica los prompts columna por columna.
- [d39e08ccf999] Sección | Bloque obligatorio | Por qué
- [5a5348b20c81] usecase | `usecase_doc` | fotografía documental Kodak Tri-X de reportaje. Kodak Portra suaviza la piel por diseño y contradice los poros — PROHIBIDO en rostros
- [7ba769efe2d7] `production-package/template_engine.py` es OBLIGATORIO para construir cualquier prompt visual.
- [c0bc3ce2b122] Un prompt no se escribe: se INSTANCIA con `build(tipo, ..., notes=...)`. El motor lanza
- [08823c86198b] **PROHIBIDO editar el texto de un brief individual.** Eso es parchar: arregla una cosa y rompe otra,
- [bebb99bf97f5] Un solo trabajo por generación. Con dos personajes: un sujeto por generación, o técnica
- [faf775460a18] de colocación probada; nunca "a ver si sale".
- [a384c44a2c78] Posición SIEMPRE por ancla legible de la propia imagen (letterforms del mundo: "his back
- [8ec5e9322188] level with the letter L of WORLD"). Prohibido "left half", "centre", "just left of X".
- [cbef3fae6beb] El editor no tiene memoria: solo verbos operativos (Move/Replace/Add/Remove/Swap), cero
- [cb50b580f819] Autocontención: toda comparación ("same X") exige ambos referentes adjuntos en ESE prompt.
- [521775e327c8] Herencia mínima: "same face and clothes" + solo los deltas. Cero re-descripción de lo que
- [51cca5b2efc6] Swap de identidad = última operación, sola: "Replace X with Y — same position, same pose,
- [b9c774059bf0] Mundos por dos pasos: placa vacía primero; insert con "use only the person from image N,
- [b6df20344be1] Stills en instante congelado ("frozen mid-stride"); nada de movimiento en imagen fija.
- [da9c2b7805b2] Contactos entre personas: "a natural high five" — la anatomía la fija el keyframe
- [5a6617eee79e] aprobado, nunca la asignación de manos por texto.
- [0f5ddb9db10d] Logos solo heredados de asset aprobado o descripción canónica del brand-lock; los
- [0cdb2895402f] cuerpos nunca tapan logo ni lettering en frames congelados.
- [0895bf9c3c72] Lo aprobado se canoniza con hash y se EDITA desde ahí; lo caro nunca se regenera.
- [ad949972d434] "Edit, don't re-roll": resultado ≥80% correcto → cambio puntual (hasta 3 ediciones
- [aabccd80baaf] apiladas), nunca re-tirar.
- [fa22c737a647] Máximo 2 intentos por método. A la 2ª falla: cambio de método con causa declarada, o
- [55b0509b18b5] alto y consulta. Nunca tercera vuelta de lo mismo.
- [86d8cbf3a110] Validadores del paquete y techos de palabras en verde antes de entregar; inspección
- [0e2d999b1256] visual propia (zooms 100% de rostros y manos) antes de presentar. Si algo falla: no se
- [aeb5f5e9292c] shots.json es la fuente de verdad: todo cambio entra ahí primero y se propaga.
- [0e27fd6783a1] Clips: solo Preserve-cues, roles de start/tail ("The tail image defines X — inherit
- [23a76633c745] Entregas en unidades chicas con OK de dirección; se entrega el delta, no el paquete.
- [abcfd077a336] Respuestas: el dato o entregable en la primera línea. Cero adulación y cero evaluación
- [9d8d3f84a47e] Prohibido afirmar capacidades, límites o hechos de plataforma sin verificarlos en este
- [229b9b46e2e4] /research solo para problemas genuinamente nuevos; /briefing solo al retomar tras días
<!-- SOURCE_FILE_END: repo/nblm-ids/produccion-visual-sw30.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/screenwriter.md -->
# SOURCE FILE: `repo/nblm-ids/screenwriter.md`

# Reglas del skill: screenwriter

57 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## screenwriter/SKILL.md

- [fb3896038afa] Always use ALL CAPS for sluglines
- [4d9355018ad2] Use hyphens to separate elements
- [57e9c487ac74] Time should suggest lighting/mood
- [fa0199539554] **Show, Don't Tell:** Write what's visible, not internal thoughts
- [e10b5f7be709] **Sensory Details:** Include lighting, atmosphere, textures, colors
- [45f2e43f67e0] **Present Tense:** Always write in present tense
- [a93dbeef8737] **Active Voice:** Use strong, active verbs
- [10e5da2fcf9a] **Specific Props:** Name objects that matter visually
- [59d398f4c454] **Atmosphere:** Set mood through environmental details
- [671c49de0056] Avoid excessive detail—just enough for visual consistency
- [27e302d3a37e] Use dialogue ONLY when essential to story
- [5645bf344589] `CUT TO:` - Scene change (usually implied, use for emphasis)
- [68d5f2185557] **Modern Best Practice:** Most transitions are IMPLIED. Use sparingly, only for specific narrative effect.
- [c775d8acd13e] **Emotional beats:** Each scene should shift emotional state
- [8cc0ef448f33] **Consistent naming:** Use same character names throughout
- [bff5030b3380] **Lean prose:** Each word should serve the image
- [35abb8abc912] ❌ **Vague descriptions:** "A person walks" → ✅ "A weathered woman in her 50s trudges through snow"
- [df9b899dbc91] ❌ **Telling emotions:** "She feels sad" → ✅ "Tears streak her dusty cheeks"
- [de28e225dfa5] ❌ **Camera directions:** "CLOSE UP ON" → ✅ "The crack in the glass spreads"
- [aa1edc03619b] ❌ **Over-dialogue:** Short films need visual storytelling
- [0cf150e839a8] ❌ **Inconsistent character names:** Stick to ONE name per character

## screenwriter/references/advanced-techniques.md

- [90c5d5126758] [Camera Movement Hints (For Arch-V)](#camera-movement-hints-for-arch-v)
- [b7d064023d0d] [Dialogue Polish Techniques](#dialogue-polish-techniques)
- [1c4f7d2165c8] [Pacing Optimization](#pacing-optimization)
- [0f0193ec9566] [Advanced Visual Storytelling](#advanced-visual-storytelling)
- [206b86beff99] [Short Film Specific Techniques](#short-film-specific-techniques)
- [b6cf18f1ea26] While avoiding technical camera directions in action lines, you can *suggest* camera movement through visual description and scene structure.
- [5c5b85a079dc] **❌ On-the-nose:**
- [118e505786a4] **✅ Subtext:**
- [f1221744d7a1] Each character should have distinct speech patterns:
- [42187af933ee] Each scene should raise stakes or tension incrementally:
- [38b4028efe2f] Use color to track emotional/narrative arc:
- [5ea772208440] Every scene must serve multiple purposes:
- [3697579b1689] First 10-15 seconds must grip audience:

## screenwriter/references/pipeline-integration.md

- [9c577fb2318c] [Scene Metadata Standards](#scene-metadata-standards)
- [5b3dfb82edff] [Imagine-Ready Visual Descriptions](#imagine-ready-visual-descriptions)
- [4091766c17f1] [Character Consistency Tracking](#character-consistency-tracking)
- [5c45c9d37a0f] [Scene Numbering Conventions](#scene-numbering-conventions)
- [43640ae6f014] [Duration Estimation Guidelines](#duration-estimation-guidelines)
- [f781421a09f6] [Output Format Validation](#output-format-validation)
- [64821fb649fa] [Pipeline Handoff Checklist](#pipeline-handoff-checklist)
- [dcba7967bb86] Every scene MUST include all required metadata fields for reliable pipeline processing:
- [5a421a0a0c7f] **Required Fields:**
- [34d356cca129] Use 1-3 adjectives that guide visual tone:
- [06f7cfabe30d] Avoid: "the character feels anxious" (this describes internal state, not mood)
- [f02d8dcae6c2] The `key_visuals` array should contain discrete, image-generation-friendly descriptions:
- [9a04fd13f520] After first appearance, use consistent identifiers:
- [ee32154734ae] **Preferred Pattern:**
- [d58376dbc7f5] Use character name only: "Maya checks her phone"
- [33379bbc4b87] Option B: Use fractional numbering (1, 2, 2A, 3...)
- [8a33756b8cb8] For pipeline simplicity, prefer Option A (complete renumbering).
- [3172bdb34a71] Ensure valid XML structure:
- [f139664debd1] **❌ Missing closing tag:**
- [415ef4d14678] **✅ Properly closed:**
- [f034c18c96e4] **❌ Unescaped special characters:**
- [b18a910b547f] **✅ Properly escaped:**
- [47f320764950] [ ] No technical camera directions (use visual descriptions instead)
<!-- SOURCE_FILE_END: repo/nblm-ids/screenwriter.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/storyboard-architect.md -->
# SOURCE FILE: `repo/nblm-ids/storyboard-architect.md`

# Reglas del skill: storyboard-architect

152 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## storyboard-architect/SKILL.md

- [364c86aacbd6] If the user only wants prompts for an image generator (no narrative structure), use `visual-prompt-forge` directly instead.
- [7696a03e6c31] Write it once, at the end of the run, and never edit it.
- [8f9cad0e2224] If the user asks for image prompts or HTML preview, hand off to `visual-prompt-forge` or `storyboard-html-preview`, those skills consume `shots.json` directly. Don't try to do their job here.
- [6c9cf5270a4d] Input | Required? | Default if absent
- [8d21f65f4329] Brand-lock file path | No | Use `brand-packs/_template.md` and flag the gap
- [0a6768420027] Follow this sequence. Don't skip steps even if the brief seems simple.
- [c7861b2bb543] "Never" list (what this brand will never do visually)
- [8b27a216f395] Aspect-ratio preferences
- [5b7b1c8fb6ae] If no brand-lock is provided, copy `brand-packs/_template.md` into the output as `brand-lock.snapshot.md` with a note: `# UNCONFIGURED, using template defaults. Recommend providing a real brand-lock for production work.`
- [0b4182e7f0fc] Don't fight the framework. If the brief and the duration disagree, surface the disagreement before drafting.
- [37204f4e9d9d] `start` / `end`, timestamps in seconds, decimal allowed. `end` must be after `start`
- [bbcf9882e50b] `depth_of_field`, optional, shallow / deep / rack
- [5942ba44f22f] Every piece of on-screen text becomes an entry in `text-overlays.json`. Never bake text into the visual description. Each overlay has:
- [1cec4673e7f2] `color`, hex (must come from brand-lock palette)
- [abc02ebdb6a8] Every shot has a one-sentence rationale. Why this beat. Why this framing. Why this on-screen text. This is the audit trail. Do not skip it.
- [38de07452a46] Use the template at `templates/storyboard.md.tpl`. Read it before writing.
- [16f6bf46f67c] Must validate against `templates/shots.schema.json`. Read it before writing. The structure is:
- [85e3ed23b8ae] Must validate against `templates/text-overlays.schema.json`. Read it before writing.
- [953b9b11b0eb] Run the validator. Do not eyeball this list.
- [4c1f6d0ef267] Don't run those automatically. The user picks.

## storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md

- [d57bd1da3f85] Role | Hex | Use
- [25d9cd499896] never use stock photo aesthetic
- [e815875bfd9e] never use AI uncanny faces
- [dd6e8d6008ac] never over-saturate the cream background
- [333c20110ff3] never use coral as a flood color (only as accent or signature periods)
- [5aecc4ca21d4] never use em dashes in copy
- [dac6a52ee58c] never use emojis in body copy
- [c95b248c14c2] never use bullet points in narrative copy
- [c906d8795790] never use clip-art or generic icon sets
- [ba0238372a4c] never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- [03c4f6662db6] never use exclamation points in headlines
- [91020f8aff04] never default to dark mode, light mode hybrid is the brand
- [26257934361a] never animate text with bouncing or wobbling, type-on, fade, or hard cut only
- [65805ba83e7e] Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.
- [19abf8cb5067] Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.
- [d81969febc9e] prefer specific numbers over vague claims
- [e1559d443197] prefer present-tense over future-tense
- [f380cff82f61] prefer "operator" over "creator", "infrastructure" over "agency"

## storyboard-architect/examples/30s-pain-proof-promise/storyboard.md

- [cb070662db9b] **Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed
- [3361115a3c24] **Subject:** founder at laptop, scrolling social feed, content tiles glowing on screen, slight slump in shoulders, mug of coffee mid-distance
- [f3a0d5dd594d] **On-screen text:** "You don't have a content problem. / You have an infrastructure problem." (Inter Black 900, coral, center, type-on at 11.5s)

## storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md

- [905efed35c14] Role | Hex | Use
- [e10409cde634] never use stock photo aesthetic
- [5c3ec0c8cf75] never use AI uncanny faces
- [fef9fe44ef96] never over-saturate the cream background
- [4590b5aee804] never use coral as a flood color (only as accent or signature periods)
- [d40b84764301] never use em dashes in copy
- [478143da99e2] never use emojis in body copy
- [1bbba41d8f5e] never use bullet points in narrative copy
- [1249aae4215a] never use clip-art or generic icon sets
- [621b3df6eb6a] never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- [d9e264405291] never use exclamation points in headlines
- [64c7eedde7cc] never default to dark mode, light mode hybrid is the brand
- [38c7b73cec5b] never animate text with bouncing or wobbling, type-on, fade, or hard cut only
- [4b55ac47f0e7] Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.
- [ff35cc7d69fd] Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.
- [995296a29fb4] prefer specific numbers over vague claims
- [db692e54505e] prefer present-tense over future-tense
- [5e4a95ec4d8c] prefer "operator" over "creator", "infrastructure" over "agency"

## storyboard-architect/examples/60s-founder-explainer/storyboard.md

- [d7aa7bcd6517] **Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed
- [cab7b8309e7a] **Beat:** insight · **VO:** "Every brand has a voice. Most founders never extract it. So every post starts from scratch."

## storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md

- [5566ff43eca7] Role | Hex | Use
- [929d3e62f0b7] never use stock photo aesthetic
- [c5761942f155] never use AI uncanny faces
- [f28e4507d045] never over-saturate the cream background
- [3751f321730f] never use coral as a flood color (only as accent or signature periods)
- [9132e55fcf5d] never use em dashes in copy (only periods, commas, semicolons)
- [0f628683c6b8] never use emojis in body copy
- [eff9c8392083] never use bullet points in narrative copy
- [b700cf8f4dcb] never use clip-art or generic icon sets
- [45e257d77c42] never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")
- [ddb048e79808] never use exclamation points in headlines
- [eb006504840c] never default to dark mode, light mode hybrid is the brand
- [783ff683393c] never animate text with bouncing or wobbling, type-on, fade, or hard cut only
- [8cea74bc14b1] never break the eye line between subject and the implied "operator perspective"
- [f6abdd226436] Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup. Skin tones warm but not orange. Greens kept slightly desaturated to push focus to subject.
- [d8a47abf50ca] Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only, no fancy wipes, no zooms.
- [e9560a0de1ac] prefer specific numbers over vague claims ("48 hours" not "fast", "30 minutes a week" not "a little time")
- [cc0c55fe6755] prefer present-tense over future-tense
- [c1a8c5479b88] prefer "operator" over "creator", "infrastructure" over "agency", "system" over "service"

## storyboard-architect/examples/shotkit-explainer/storyboard.md

- [d14865cb6d2f] > matching the artifact it produced: editing it to describe a video that was never made is
- [35a8d9d8702e] **On-screen text:** "You don't have a content problem. You have a pre-production problem." (Inter Black 900, center, fade)

## storyboard-architect/references/beat-frameworks.md

- [7e5f2e473cd3] Pick one. Don't invent a new one unless the brief genuinely doesn't fit. Document the choice in `storyboard.md`.
- [f32c786bfbff] **Pain**, name the audience's actual problem in their actual language. Concrete, not abstract. "Your content feels random" not "marketing inefficiency."
- [d329c7d38124] **Reframe**, flip the problem on its head. The point is *not* what they thought it was. "You don't have a content problem. You have an infrastructure problem."
- [b55cf418fc3a] **Promise**, what life looks like on the other side. Specific, verifiable, time-bound when possible.
- [e5235864c6bb] Use when: ad creative, landing-page hero video, conversion-focused social.
- [0206d6df0cc3] **World**, set the context. Who lives in this world. What's broken about it.
- [9b3fba335e1b] **Hero**, the product/founder/methodology arrives. Show what it does, not what it is.
- [e4b20db35b44] **Transformation**, the world changes. Show before/after at scale.
- [cfaecb7f5fa7] Use when: product launches, brand films, anchor pieces.
- [39b17554140c] **Hook**, a one-line provocation (0–2s)
- [ec4f8b7428c7] **Stakes**, why this matters (2–8s)
- [3bdf77c5a1e7] **Insight**, the actual point (8–20s for 30s, 8–40s for 60s)
- [6154ed831bf3] **Proof**, one concrete example or data point
- [6be1e3549be6] **CTA**, what to do next, narrow and specific
- [ca19a04f7f16] Use when: founder content, thought leadership, personal-brand pieces.
- [e707043ad741] **Wide claim**, the headline take
- [61117f1e1435] **Zoom 1**, one layer of nuance
- [bcd48bb1ab67] **Zoom 2**, the layer underneath that
- [409a346f14c6] **Snap-back**, return to the wide claim, now reframed by the zooms
- [e4456cb5dc55] Use when: opinion videos, kinetic-type pieces, social-native commentary.
- [86733dae8e0e] **Problem state**, what someone is stuck on
- [4b795000d239] **Reveal**, the technique or trick
- [a68a06f84fe6] **Walk-through**, apply it step by step
- [0357fe063806] **Result**, the after-state, side-by-side with before
- [08af446ba369] Use when: tutorials, demo videos, training content.

## storyboard-architect/references/on-screen-text.md

- [428f5eebff7b] Text on screen is a load-bearing decision. Most storyboards over-text. The default should be: **does this shot need text to land?** If the visual carries the meaning, text dilutes.
- [a268ba75d0b5] **Auto-play-mute environments.** Social feeds. Text replaces VO.
- [efdeec778e0f] **Concept compression.** A short phrase lands harder than 4 seconds of narration.
- [90221fe5fe0f] **Stat or proof point.** Numbers stick visually in a way they don't audibly.
- [48c59084ee78] **Beat punctuation.** A single word or phrase that lands on a music hit.
- [9f529931cccc] **CTA.** The action you want the viewer to take.
- [c1fb4192e05a] **Restating the VO.** If the voice says it, the text is noise.
- [84655e935767] **Decorative copy.** "Moments matter" floating over b-roll. Cut it.
- [84f1791a022e] **Brand vibing.** Product names everywhere. Logo lockup in the CTA covers this.
- [67f2beaeb3ef] **Filler beats.** If the shot doesn't need text, leave it clean.
- [4ff066eab26b] When a shot has on-screen text, the **shot subject must reserve space for it**. This is enforced at storyboard time, not generation time.
- [a526c207e3dc] Position | Use when
- [7a7cb7a4a5e8] `{x: %, y: %}` | Custom, only when the standard positions don't fit
- [4a432ad00196] Size | Pixel approx (1080p) | Use for
- [9f4f78bc99a2] Avoid stacking animations. Pick one per overlay.
- [4cbacbc0b8fa] The `color` field of every text overlay must be a hex value that exists in the brand-lock palette. If you find yourself wanting a color that's not in the palette, the answer is not to add it, the answer is to pick a different overlay style or shot composition.
- [d7940c08b552] Same: every `font` field must reference a font defined in brand-lock typography. Two fonts max per project (display + body). More than that and the brand stops being recognizable.
- [717463d29f8f] Already covered in timing-rules.md but worth repeating: text needs to be on screen long enough for someone to read it twice. Calculate, then verify. Don't eyeball.

## storyboard-architect/references/shot-grammar.md

- [7268a7328d89] Controlled vocabulary. Use these exact terms in `shots.json`. Generators interpret loose language inconsistently, locked vocabulary survives translation.
- [74926ea5bff7] `MCU` | Medium close-up | Head and shoulders
- [6b3fa7bb2923] Default to eye-level. Use the others deliberately, not for variety.
- [7faa95961da0] Code | Effect | Use when
- [5528555145f9] `shallow` | Subject sharp, background blurred
- [e4e41d7c48e9] Default to shallow for talking-head, deep for environmental and schematic.
- [03a00602482e] Don't redefine per shot. Define once in `series_lock.lighting`. Examples:
- [05f30ccb87c3] **brand_lock**, locked across the entire project. Palette, type, "never" list.

## storyboard-architect/references/timing-rules.md

- [22f6035ce704] Pacing is math, not feel. Use these as defaults. Override only with reason documented in rationale.
- [32344b412ad5] The hook is 0–2s. Always. There are no exceptions in short-form content. Specifically:
- [e67edc98e31f] 9:16 social: first frame must telegraph the topic. Auto-play on mute means the first half-second is fighting a swipe.
- [5e8113658ff6] The hook shot framing should be high-contrast against the shots that follow. If shot 2 is MS, shot 1 should not be MS. Visual contrast = retention.
- [7e40e9d57114] Last shot should hold long enough for someone to read the CTA text and act
- [5acc0a53e64b] Don't put motion on the CTA shot, let the text breathe
- [8499e1ad407c] A text overlay needs to be on screen long enough to be **read twice**. Not once, twice. Why: viewers are skimming, eyes don't always lock on first frame.
- [8a7cde5fbf44] Shorten the copy
- [1740a84f47a3] Carry the text across two consecutive shots (text persists during cut)
- [6c398f45603b] Lengthen the shot
- [6c97051eb055] Do not under-time text. It's the most common storyboard failure.
- [e7f6806c93e3] Sum of `(end - start)` across all shots equals project duration ±0.1s
- [35389a2e7e9a] No shot has `start >= end`
- [993e2cd1eec5] No two shots overlap
- [40867e840a40] First shot starts at 0.0
- [e620d729b974] Last shot ends at project duration
- [0678f6cbf749] Every text overlay's `enter.at` is ≥ its shot's `start`
- [5d267e42e94d] Every text overlay's `exit.at` is ≤ its shot's `end` (or carries to a flagged successor shot)
- [18b6449fb38c] Every text overlay's on-screen duration ≥ read-twice threshold
<!-- SOURCE_FILE_END: repo/nblm-ids/storyboard-architect.md -->


<!-- SOURCE_FILE_START: repo/nblm-ids/storyboard-html-preview.md -->
# SOURCE FILE: `repo/nblm-ids/storyboard-html-preview.md`

# Reglas del skill: storyboard-html-preview

17 enunciados normativos extraidos mecanicamente.
El id entre corchetes es la referencia obligatoria para clasificar.


## storyboard-html-preview/SKILL.md

- [090ccfb96455] The constraint is non-negotiable: **single file, no build step, no server, works offline.** Any time the output requires "run this build command" or "host this somewhere," the skill has failed.
- [629bb2d205d3] An entry in `shot.assets.generated` marked `accepted: true`
- [b9f0e777f95a] The newest entry in `shot.assets.generated`
- [b86cdec0bdb7] `frames/round-{highest}/{shot_id}.{png,jpg,jpeg,webp}`
- [ed9eefdf08c5] `generated/{shot_id}.{ext}`, the pre-3.0.0 flat layout
- [09e4367e3b97] The HTML preview should *feel* like the brand without going overboard. Quiet branding, not loud.
- [8a2c11a5fc35] Use `templates/preview.html.tpl` as the structural template. Read it before generating.
- [410599a6e6d1] frames as base64. Ask the user which they prefer if frames are present.
- [0c58d39b58a3] `text-overlays.json` always did. A single set of `overlay_*` fields could hold one, so the
- [e3ddb1d823f5] Ensure text overlays render legibly
- [32701372f5d1] Use black-on-white where brand colors won't print well
- [6975e2ff7171] The user should be able to hit Cmd-P / Ctrl-P and get a clean PDF.
- [77570da551dd] No CDN scripts. No Google Fonts. No external CSS frameworks. The file must work with no internet connection.
- [d86f1629a7f6] Hit Cmd-P. The result should be a clean PDF. If layout breaks across page boundaries, the print stylesheet is broken.
- [90b1a187484f] Use brand colors as accents, not as full backgrounds. The reviewer's job is to read the storyboard, not admire the design. Subtle.
- [9f76efb872f5] Stakeholders open links on phones. The HTML should be readable on mobile without horizontal scroll. Simple responsive CSS.
- [3c8013b57f39] was written. They are separate lines in the footer and they must stay separate.
<!-- SOURCE_FILE_END: repo/nblm-ids/storyboard-html-preview.md -->
