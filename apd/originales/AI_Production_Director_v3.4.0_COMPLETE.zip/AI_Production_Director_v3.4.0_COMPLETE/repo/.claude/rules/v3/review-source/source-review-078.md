# Source coverage review 78/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 24d83aa333738ba5 — image/references/vision-decomposer.md:89-89 (paragraph)

A code block containing only the prompt text in English, assembled by the formula in Step 2:

Extracted rules inside block: NONE

## 000ff65f7b752c6e — image/references/vision-decomposer.md:91-92 (code)

````
```

Extracted rules inside block: NONE

## 41fdf1a487fc51f7 — image/references/vision-decomposer.md:93-93 (paragraph)

<comma-separated keywords following the strict 6-segment formula>

Extracted rules inside block: NONE

## 54a1b0ba7ce542c2 — image/references/vision-decomposer.md:94-95 (code)

```
````

Extracted rules inside block: NONE

## b45cdd98110125a1 — image/references/vision-decomposer.md:97-97 (paragraph)

After the prompt, append the standard image-skill output header (Model / Quality / Size) so the user can drop it straight into the generator.

Extracted rules inside block: NONE

## a4f11b8106c757cd — image/references/vision-decomposer.md:101-101 (heading)

## When to load this file

Extracted rules inside block: NONE

## 8c78e14c59f99e3a — image/references/vision-decomposer.md:103-103 (paragraph)

Load `vision-decomposer.md` whenever:

Extracted rules inside block: NONE

## 389ed66ddc044e3d — image/references/vision-decomposer.md:104-104 (list_item)

- The user attaches an image and asks for a prompt to **recreate / transfer / match** its style

Extracted rules inside block: NONE

## 5d94a5a162a69ef1 — image/references/vision-decomposer.md:105-105 (list_item)

- The user asks to **decompose, deconstruct, reverse-engineer** a visual reference

Extracted rules inside block: NONE

## 433dc37e8b6368f3 — image/references/vision-decomposer.md:106-106 (list_item)

- The user says **"перенеси стиль", "сделай так же", "повтори образ", "проанализируй кадр", "разбери картинку на промпт"**

Extracted rules inside block: NONE

## dadd11b4b6ecc23f — image/references/vision-decomposer.md:107-107 (list_item)

- Mood-board work: extracting cinematic DNA from a film still, ad frame, painting, photo

Extracted rules inside block: NONE

## 2a61512f9ce4c2b2 — image/references/vision-decomposer.md:109-109 (paragraph)

Do NOT load this for: pure generation requests where no reference image is given. For those, use the standard model files.

Extracted rules inside block: 0bbe3f73a630

## b59547b464ae87ed — image/references/vision-decomposer.md:113-113 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 23fa6fd9fdb4c925 — produccion-visual-sw30/SKILL.md:2-3 (paragraph)

name: produccion-visual-sw30
description: Reglas criticas y micro-gate de produccion visual AI para Final Upgrade (proyecto SW30 y cualquier generacion de imagen/video). USA ESTE SKILL SIEMPRE que se escriba o entregue un prompt visual (imagen o video), se genere con Nano Banana, Kling, Veo, GPT Image o el conector Higgsfield, se gasten creditos de generacion, se trabaje cualquier shot, ancla, clip o asset del proyecto SW30/Sports World, o Eric escriba "gate", "micro-gate" o "reglas de produccion". APLICAR ANTES de producir - el micro-gate de 3 lineas es obligatorio antes de gastar creditos o entregar prompts; entrega sin cabecera es invalida.

Extracted rules inside block: NONE

## 776fdc1bf0a9177d — produccion-visual-sw30/SKILL.md:6-6 (heading)

# Producción visual SW30 — micro-gate + 20 reglas críticas

Extracted rules inside block: NONE

## 2f0de51ef67f519e — produccion-visual-sw30/SKILL.md:8-9 (paragraph)

OBJETIVO ÚNICO: máxima calidad de imagen conforme al script, al menor costo de créditos.
Toda decisión se evalúa contra ese objetivo. El production-package es la fuente de verdad.

Extracted rules inside block: NONE

## 885584b8e9faa67f — produccion-visual-sw30/SKILL.md:11-11 (heading)

## PREGUNTA DE AVANCE (gate de entrega, antes del micro-gate)

Extracted rules inside block: NONE

## d5b77a5d3d7243e9 — produccion-visual-sw30/SKILL.md:12-13 (paragraph)

Ninguna respuesta es satisfactoria para el usuario — y viola el prompt maestro — mientras la
respuesta honesta a esta pregunta no sea SÍ SIN MATICES:

Extracted rules inside block: 753cf237f52c

## 1e9ce632446e5279 — produccion-visual-sw30/SKILL.md:15-16 (paragraph)

  RESPONDE HONESTAMENTE: ¿UTILIZASTE DE FORMA EXHAUSTIVA Y CORRECTA TODAS LAS REGLAS DEL SKILL
  APLICABLES A ESTE CASO? RESPONDE SI O NO.

Extracted rules inside block: NONE

## a55e3e012d0f7f21 — produccion-visual-sw30/SKILL.md:18-18 (paragraph)

Reglas de uso:

Extracted rules inside block: NONE

## 4527c94a1598d0ac — produccion-visual-sw30/SKILL.md:19-19 (list_item)

- La pregunta se responde ANTES de entregar, no después de que el usuario la haga.

Extracted rules inside block: NONE

## 3fcb1396b8808ec3 — produccion-visual-sw30/SKILL.md:20-21 (list_item)

- Si la respuesta es NO: no se entrega. Se leen los archivos faltantes, se aplica lo que falte y
  se vuelve a preguntar. Se repite cuantas veces sea necesario.

Extracted rules inside block: a95b3e8f01f8

## 5d39472c4264f018 — produccion-visual-sw30/SKILL.md:22-22 (list_item)

- Prohibido responder SÍ para complacer. Un SÍ falso es una mentira y cuesta más que el NO.

Extracted rules inside block: 14653b391db0

## 21b1992bbb7dc9c0 — produccion-visual-sw30/SKILL.md:23-23 (list_item)

- Prohibido responder SÍ con matices, condiciones o notas al pie disfrazadas de honestidad.

Extracted rules inside block: 8cabcfd84c43

## 96eee72bc35c4d98 — produccion-visual-sw30/SKILL.md:24-25 (list_item)

- "Exhaustiva" significa: leídos COMPLETOS todos los archivos del skill aplicables al caso
  (SKILL.md indica el orden obligatorio), no fragmentos ni grep.

Extracted rules inside block: d0ed4afe71b9

## 5a19c671ffe1f016 — produccion-visual-sw30/SKILL.md:26-27 (list_item)

- "Correcta" significa: cada regla verificable corre en un lint o auditor ejecutable por el
  usuario; las no mecanizables se contrastan una a una contra el texto del archivo.

Extracted rules inside block: NONE

## 88627b71d161ef62 — produccion-visual-sw30/SKILL.md:28-29 (list_item)

- Ante duda sobre si un archivo aplica, se lee su sección "cuándo cargar / when to load" en vez
  de decidirlo por criterio propio.

Extracted rules inside block: NONE

## be9addee3f67324c — produccion-visual-sw30/SKILL.md:30-30 (list_item)

- Se permite preguntar al usuario cuando la duda es de dirección creativa, no de reglas.

Extracted rules inside block: NONE

## ffc685180d66a02e — produccion-visual-sw30/SKILL.md:32-32 (heading)

## ARQUITECTURA POR SECCIONES (obligatoria antes de escribir cualquier prompt)

Extracted rules inside block: NONE

## 82fad6a8adfdb96d — produccion-visual-sw30/SKILL.md:33-33 (paragraph)

Orden de dirección: nunca se escribe un prompt de corrido ni se parchea texto. Tres pasos, en este orden:

Extracted rules inside block: d6939a03c608
