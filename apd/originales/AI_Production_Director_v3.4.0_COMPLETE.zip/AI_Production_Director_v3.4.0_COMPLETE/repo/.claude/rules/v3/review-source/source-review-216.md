# Source coverage review 216/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2f078325e4d2739b — visual-prompt-forge/adapters/nano-banana.md:87-87 (list_item)

- The text-to-image prompt (for first-pass generation)

Extracted rules inside block: NONE

## b565326523ce320b — visual-prompt-forge/adapters/nano-banana.md:88-88 (list_item)

- A modification template comment showing how to use the result for variants:

Extracted rules inside block: 31a65699308b

## c87f4378a63cb18f — visual-prompt-forge/adapters/nano-banana.md:90-97 (code)

```
# shot_01, text-to-image prompt:
{prompt}

# shot_01, variant template (after generating once):
# Reference: [the generated image]. Modify the image to {your change}.
# Preserve {anchors}. Change {target}.
```

Extracted rules inside block: NONE

## 17348cfdf712a8eb — visual-prompt-forge/adapters/nano-banana.md:99-99 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 9d27499d1b47c2bc — visual-prompt-forge/adapters/nano-banana.md:101-101 (list_item)

- **Don't use Midjourney-style flag syntax**. Nano Banana ignores `--ar`, expects `aspectRatio` parameter

Extracted rules inside block: 468653f75140

## afb947b230d3a77a — visual-prompt-forge/adapters/nano-banana.md:102-102 (list_item)

- **Don't expect Midjourney-level aesthetic by default**. Nano Banana is a workhorse, not a stylist. Stack mood adjectives explicitly

Extracted rules inside block: f795b44d5d19

## 9a2a992e18f0b588 — visual-prompt-forge/adapters/nano-banana.md:103-103 (list_item)

- **Don't pile multiple modifications in one image-to-image prompt**, one change per pass produces cleaner results

Extracted rules inside block: 9a7a4569d7d4

## 29a939314d577f2b — visual-prompt-forge/adapters/nano-banana.md:104-104 (list_item)

- **Don't forget the "preserve" clause in image-to-image**, without it, Nano Banana treats the reference as loose inspiration and drifts

Extracted rules inside block: c9cfe10ba5a7

## e50aafaf80a32897 — visual-prompt-forge/adapters/nano-banana.md:105-105 (list_item)

- **Don't include text content in image prompts**, composite separately; text rendering is mediocre

Extracted rules inside block: f140dceba074

## 23e0c3b187fb0fef — visual-prompt-forge/adapters/nano-banana.md:107-107 (heading)

## API access

Extracted rules inside block: NONE

## 5a789e4ff5977793 — visual-prompt-forge/adapters/nano-banana.md:109-109 (paragraph)

Through Google Gemini API (`gemini-2.5-flash-image` model endpoint). Available via:

Extracted rules inside block: NONE

## e56459134de1d48f — visual-prompt-forge/adapters/nano-banana.md:111-111 (list_item)

- Gemini API direct

Extracted rules inside block: NONE

## f47b8d2189b77a7d — visual-prompt-forge/adapters/nano-banana.md:112-112 (list_item)

- Vertex AI

Extracted rules inside block: NONE

## 25a3fa9e40d915cb — visual-prompt-forge/adapters/nano-banana.md:113-113 (list_item)

- Replicate

Extracted rules inside block: NONE

## 671026ecae85adf7 — visual-prompt-forge/adapters/nano-banana.md:114-114 (list_item)

- fal.ai (under "google/nano-banana")

Extracted rules inside block: NONE

## 4e9b0300551cbbb9 — visual-prompt-forge/adapters/nano-banana.md:116-116 (paragraph)

Same prompt syntax across all four.

Extracted rules inside block: NONE

## 9133650888480ba0 — visual-prompt-forge/adapters/seedance.md:1-1 (heading)

# Adapter: Seedance 2.0 (motion-aware video, multi-shot)

Extracted rules inside block: NONE

## dfa209e6f86482c1 — visual-prompt-forge/adapters/seedance.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: 6f11bad3f095

## 8de1b018e2b82ca5 — visual-prompt-forge/adapters/seedance.md:5-5 (paragraph)

Seedance 2.0 is the multi-shot model. It can generate a **short sequence of cuts in a single generation** while holding subject and environment consistency across them. Reach for it when several consecutive storyboard beats share one subject and you want them to feel like one continuous take, it beats stitching four independent Kling clips that drift apart. For a single isolated shot, Kling is the simpler default.

Extracted rules inside block: NONE

## 17719be98554d017 — visual-prompt-forge/adapters/seedance.md:7-7 (paragraph)

With video the **camera motion is load-bearing**, and with Seedance the **cut structure is also load-bearing**, you describe the sequence of shots, not just one frame.

Extracted rules inside block: NONE

## c8fef056514dee1e — visual-prompt-forge/adapters/seedance.md:9-9 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## e8ee67d444ee6981 — visual-prompt-forge/adapters/seedance.md:11-11 (paragraph)

Single shot:

Extracted rules inside block: NONE

## 88e81ae43849b0b1 — visual-prompt-forge/adapters/seedance.md:12-14 (code)

```
{Camera motion sentence, leading.} {Subject and action.} {Environment and lighting from series_lock.} {Color grade and mood from brand_lock.}
```

Extracted rules inside block: NONE

## 83c11e27f2a10f2c — visual-prompt-forge/adapters/seedance.md:16-16 (paragraph)

Multi-shot sequence (Seedance's strength):

Extracted rules inside block: NONE

## 0b62c33f2ce64e8f — visual-prompt-forge/adapters/seedance.md:17-19 (code)

```
Shot 1: {camera + action}. Shot 2: {camera + action}. Shot 3: {camera + action}. Consistent subject throughout: {series_lock character anchor, verbatim}. {Environment and lighting from series_lock.} {Color grade and mood from brand_lock.}
```

Extracted rules inside block: NONE

## 1c440b7d43e7e1ca — visual-prompt-forge/adapters/seedance.md:21-21 (heading)

## Parameters

Extracted rules inside block: NONE

## 103075bb38a170f4 — visual-prompt-forge/adapters/seedance.md:23-23 (table_row)

| Parameter | Default | Notes |

Extracted rules inside block: NONE

## 8ef9c8f37ad39de2 — visual-prompt-forge/adapters/seedance.md:25-25 (table_row)

| `duration` | `5s` per shot block | Multi-shot sequences run longer; check the current fal.ai ceiling |

Extracted rules inside block: NONE

## 8a6f6d0c2259cc31 — visual-prompt-forge/adapters/seedance.md:26-26 (table_row)

| `aspect_ratio` | from `project.aspect` | |

Extracted rules inside block: NONE

## 966d873854365135 — visual-prompt-forge/adapters/seedance.md:27-27 (table_row)

| `start_image` | optional | Image-to-video reference for the opening frame |

Extracted rules inside block: NONE
