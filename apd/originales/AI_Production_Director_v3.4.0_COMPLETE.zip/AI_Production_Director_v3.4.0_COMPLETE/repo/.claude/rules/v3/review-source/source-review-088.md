# Source coverage review 88/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 03ac65023543b132 — screenwriter/references/advanced-techniques.md:148-148 (heading)

## Advanced Visual Storytelling

Extracted rules inside block: NONE

## 3b16883885318eed — screenwriter/references/advanced-techniques.md:150-150 (heading)

### Using Objects as Story Beats

Extracted rules inside block: NONE

## 57f592db0b712580 — screenwriter/references/advanced-techniques.md:152-152 (paragraph)

Let objects carry narrative weight:

Extracted rules inside block: NONE

## 9660593b7adc2a26 — screenwriter/references/advanced-techniques.md:154-154 (paragraph)

**The Flower Example:**

Extracted rules inside block: NONE

## 5339f7a6b3bd01a5 — screenwriter/references/advanced-techniques.md:155-155 (list_item)

- Scene 1: Flower is vibrant, yellow

Extracted rules inside block: NONE

## 6821d99e94193790 — screenwriter/references/advanced-techniques.md:156-156 (list_item)

- Scene 3: Flower petals drooping

Extracted rules inside block: NONE

## b1e85a7a63cc988c — screenwriter/references/advanced-techniques.md:157-157 (list_item)

- Scene 5: Single petal falls

Extracted rules inside block: NONE

## 98fc6365e0188691 — screenwriter/references/advanced-techniques.md:158-158 (list_item)

- Scene 7: Flower completely wilted

Extracted rules inside block: NONE

## c19663519af8ebe8 — screenwriter/references/advanced-techniques.md:160-160 (heading)

### Environmental Storytelling

Extracted rules inside block: NONE

## a9f0c413d2032869 — screenwriter/references/advanced-techniques.md:162-162 (paragraph)

Show passage of time or change through environment:

Extracted rules inside block: NONE

## 3bb8c63d4d081acf — screenwriter/references/advanced-techniques.md:164-168 (code)

```
Scene 1: "Sunlight streams through clean windows"
Scene 5: "Dust motes drift through afternoon light"
Scene 10: "Shadows lengthen across abandoned chairs"
```

Extracted rules inside block: NONE

## 3452570f57e82ed8 — screenwriter/references/advanced-techniques.md:170-170 (heading)

### Color Progression

Extracted rules inside block: NONE

## 003a6a3037e250f7 — screenwriter/references/advanced-techniques.md:172-172 (paragraph)

Use color to track emotional/narrative arc:

Extracted rules inside block: fe8b081309d3

## d6f83527984a324e — screenwriter/references/advanced-techniques.md:174-176 (paragraph)

**Beginning:** Warm, golden tones (hope)
**Middle:** Desaturated, gray (struggle)
**End:** Cool blue light (resolution/melancholy)

Extracted rules inside block: NONE

## 0063d2ff7429c456 — screenwriter/references/advanced-techniques.md:180-180 (heading)

## Short Film Specific Techniques

Extracted rules inside block: NONE

## c0580020e2a8a270 — screenwriter/references/advanced-techniques.md:182-182 (heading)

### Economy of Storytelling

Extracted rules inside block: NONE

## 5eca53254f5d72c6 — screenwriter/references/advanced-techniques.md:184-184 (paragraph)

Every scene must serve multiple purposes:

Extracted rules inside block: dec135eea8ef

## d4cd2f869f595e76 — screenwriter/references/advanced-techniques.md:185-185 (list_item)

- Advance plot

Extracted rules inside block: NONE

## 0548704acbb30eb0 — screenwriter/references/advanced-techniques.md:186-186 (list_item)

- Reveal character

Extracted rules inside block: NONE

## 828c949271a4164d — screenwriter/references/advanced-techniques.md:187-187 (list_item)

- Build world

Extracted rules inside block: NONE

## ef3a89e40d943f15 — screenwriter/references/advanced-techniques.md:188-188 (list_item)

- Create emotion

Extracted rules inside block: NONE

## a4f44c2859901a77 — screenwriter/references/advanced-techniques.md:190-190 (paragraph)

**Example Scene Serving 4 Purposes:**

Extracted rules inside block: NONE

## c46209ca492767ce — screenwriter/references/advanced-techniques.md:191-198 (code)

```
Scene: Robot discovers flower

Purpose 1 (Plot): Introduces story catalyst
Purpose 2 (Character): Shows robot's capacity for wonder
Purpose 3 (World): Reveals post-apocalyptic setting
Purpose 4 (Emotion): Creates hope/fragility contrast
```

Extracted rules inside block: NONE

## bbf1993aa1784720 — screenwriter/references/advanced-techniques.md:200-200 (heading)

### Opening Hook Strategies

Extracted rules inside block: NONE

## 469dffe1578066ba — screenwriter/references/advanced-techniques.md:202-202 (paragraph)

First 10-15 seconds must grip audience:

Extracted rules inside block: aab3df978ab8

## 9015678ff9c40119 — screenwriter/references/advanced-techniques.md:204-207 (paragraph)

**Visual Hook:** Striking, unusual image
**Question Hook:** Raise mystery to be solved
**Action Hook:** Start mid-event
**Emotion Hook:** Immediate emotional connection

Extracted rules inside block: NONE

## 4fce3d28fd66f24a — screenwriter/references/advanced-techniques.md:209-209 (heading)

### Ending Impact

Extracted rules inside block: NONE

## 886ae85ead20476d — screenwriter/references/advanced-techniques.md:211-211 (paragraph)

Strong endings for short films:

Extracted rules inside block: NONE

## 0b6709208f0de162 — screenwriter/references/advanced-techniques.md:213-216 (paragraph)

**Circular:** Return to opening image, transformed
**Revelation:** Final scene reveals new understanding
**Resonance:** Emotionally satisfying moment
**Question:** Leave audience pondering

Extracted rules inside block: NONE

## 822f30bfa19b2f77 — screenwriter/references/pipeline-integration.md:1-1 (heading)

# Pipeline Integration Guide

Extracted rules inside block: NONE
