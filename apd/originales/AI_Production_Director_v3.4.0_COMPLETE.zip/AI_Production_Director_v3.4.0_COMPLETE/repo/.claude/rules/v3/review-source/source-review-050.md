# Source coverage review 50/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 6816661f3de183b0 — image/references/multi-panel.md:177-195 (code)

```
Scene: 6-frame cinematic sequence arranged in a 3x2 grid. Dark film-strip aesthetic with thin black borders. {location_description}.

Subject: {subject_description}, wearing {wardrobe_description}. Same person, same outfit, same location across all 6 frames.

Important Details:
Frame 1 (top-left): Top-down bird's eye view — subject seen from directly above, full body visible against ground/floor
Frame 2 (top-center): Low angle looking up — subject towering over camera, dramatic perspective, sky/ceiling visible
Frame 3 (top-right): Wide isolation shot — subject small in frame, vast environment dominates, sense of scale
Frame 4 (bottom-left): Close-up with slight tilt — face and upper body, Dutch angle, intimate intensity
Frame 5 (bottom-center): Motion frame — subject mid-action ({motion_action}), natural motion blur on limbs
Frame 6 (bottom-right): Grounded final — medium shot, subject at rest, direct gaze, resolving the sequence

Photographer reference: {photographer_style}
Lighting: consistent {lighting_description} across all frames

Use Case: fashion editorial, film lookbook, director's shot list visualization
Constraints: same person and wardrobe in every frame, no costume changes, consistent color grading, no text overlays
```

Extracted rules inside block: NONE

## b9b9e010bf8eb102 — image/references/multi-panel.md:197-197 (paragraph)

**Variables:**

Extracted rules inside block: NONE

## 3b8205bfe7e0fc8d — image/references/multi-panel.md:198-198 (list_item)

- `{subject_description}` — model details

Extracted rules inside block: NONE

## 48314ded568a1ed5 — image/references/multi-panel.md:199-199 (list_item)

- `{wardrobe_description}` — clothing

Extracted rules inside block: NONE

## 83939d53dd789e4b — image/references/multi-panel.md:200-200 (list_item)

- `{location_description}` — setting

Extracted rules inside block: NONE

## bb82e83d71884cdc — image/references/multi-panel.md:201-201 (list_item)

- `{motion_action}` — what the motion frame captures (e.g., "walking forward", "turning sharply", "jumping")

Extracted rules inside block: NONE

## a12ea354ba6ecad7 — image/references/multi-panel.md:202-202 (list_item)

- `{photographer_style}` — (e.g., "Peter Lindbergh desaturated realism", "Helmut Newton dramatic contrast")

Extracted rules inside block: NONE

## a111a7517c7fbb71 — image/references/multi-panel.md:203-203 (list_item)

- `{lighting_description}` — (e.g., "overcast natural light, soft shadows")

Extracted rules inside block: NONE

## 008823b3097fe968 — image/references/multi-panel.md:205-207 (paragraph)

**Recommended size:** 1536x1024 (landscape, 3x2 grid)
**Model:** GPT Image 2 `quality: medium` or Nano Banana Pro
**Common pitfalls:**

Extracted rules inside block: ee9b74f9a7d8

## 9a1a483a6516c6fc — image/references/multi-panel.md:208-208 (list_item)

- Not naming each frame explicitly — "various angles" is too vague, the model needs per-frame instructions

Extracted rules inside block: NONE

## d8b4722fa8caff70 — image/references/multi-panel.md:209-209 (list_item)

- Top-down and low-angle in the same grid confuse the model if you don't anchor each frame to a grid position

Extracted rules inside block: 8ecc3dab1066

## f73660c3d26d4849 — image/references/multi-panel.md:210-210 (list_item)

- Motion blur instruction must be specific ("blur on hands and feet") or the model applies blur everywhere

Extracted rules inside block: c652d8fa20e4

## cd332d6dc96e205c — image/references/multi-panel.md:214-214 (heading)

## 6. Before/After Split

Extracted rules inside block: NONE

## 297d7f89520fd483 — image/references/multi-panel.md:216-216 (paragraph)

**When to use:** Product transformation, makeover, time comparison, renovation — two states side by side.

Extracted rules inside block: 38de28fc48d0

## c6bcf28cf3186070 — image/references/multi-panel.md:218-218 (heading)

### Template (5-slot format)

Extracted rules inside block: NONE

## e054e1398da19b4d — image/references/multi-panel.md:220-233 (code)

```
Scene: Single image split into left and right halves with a {divider_style} dividing line down the center. Before/after comparison.

Subject: {subject_description}

Important Details:
Left half (BEFORE): {before_description} — {before_condition}
Right half (AFTER): {after_description} — {after_condition}

The transition at the center line should feel {transition_style}. Same camera angle, same framing, same background perspective in both halves — only the subject's state changes.

Use Case: {use_case}
Constraints: identical composition and camera angle on both sides, same lighting direction, no text unless specified, the dividing line must be clearly visible
```

Extracted rules inside block: NONE

## 42b8f06e94f9db65 — image/references/multi-panel.md:235-235 (paragraph)

**Variables:**

Extracted rules inside block: NONE

## b095b4fa05f87238 — image/references/multi-panel.md:236-236 (list_item)

- `{subject_description}` — what is being compared

Extracted rules inside block: NONE

## 90153414864b8beb — image/references/multi-panel.md:237-237 (list_item)

- `{before_description}` / `{before_condition}` — left side state (e.g., "faded, cracked wall with peeling paint")

Extracted rules inside block: NONE

## 5c9129db0034d1d5 — image/references/multi-panel.md:238-238 (list_item)

- `{after_description}` / `{after_condition}` — right side state (e.g., "freshly painted wall, smooth finish, vibrant color")

Extracted rules inside block: NONE

## ae7263eb40c0551b — image/references/multi-panel.md:239-239 (list_item)

- `{divider_style}` — "thin white line" / "subtle gradient blend" / "sharp vertical cut"

Extracted rules inside block: NONE

## 1bc4557973d19bfb — image/references/multi-panel.md:240-240 (list_item)

- `{transition_style}` — "clean and abrupt" / "natural, as if wiping away"

Extracted rules inside block: NONE

## d243e7ec4c41afaa — image/references/multi-panel.md:241-241 (list_item)

- `{use_case}` — "product marketing", "renovation portfolio", "skincare results"

Extracted rules inside block: NONE

## 519d13e35c1ba323 — image/references/multi-panel.md:243-245 (paragraph)

**Recommended size:** 1536x1024 (landscape — gives each half a portrait-like proportion)
**Model:** GPT Image 2 `quality: medium` — for text labels ("BEFORE" / "AFTER"), use `quality: high`
**Common pitfalls:**

Extracted rules inside block: a5ca2f339c15, a775b2d2ebbe

## 14f0d5d7b4be9b07 — image/references/multi-panel.md:246-246 (list_item)

- Not specifying "same camera angle both sides" — model may show two completely different viewpoints

Extracted rules inside block: NONE

## 754e31d492e6c62f — image/references/multi-panel.md:247-247 (list_item)

- Without a visible divider, the two halves can merge into one ambiguous scene

Extracted rules inside block: NONE

## 69c2040fcf6df046 — image/references/multi-panel.md:248-248 (list_item)

- Left/right assignment matters — always state which side is before and which is after

Extracted rules inside block: 81194a49b6d3

## 4ebdcc82afc04795 — image/references/multi-panel.md:252-252 (heading)

## 7. 12-Panel Storyboard Poster

Extracted rules inside block: NONE

## 0d9022b5b4c55890 — image/references/multi-panel.md:254-254 (paragraph)

**When to use:** Full narrative in one image — 3x4 grid (3 columns, 4 rows) for animation or video pre-production.

Extracted rules inside block: b5a69994600b

## a46cfcc0e8d7d1b2 — image/references/multi-panel.md:256-256 (heading)

### Template (5-slot format)

Extracted rules inside block: NONE
