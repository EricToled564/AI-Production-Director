# Source coverage review 158/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 74de3a01ecc2adf8 — video/references/patterns-and-genres.md:57-57 (paragraph)

Use for rhythmic repetition, transformation, performance.

Extracted rules inside block: 0c9c5c079633

## 90aeeee5013319c4 — video/references/patterns-and-genres.md:59-61 (code)

```text
gesture A -> cut -> gesture A from new angle -> cut -> transformation -> repeat gesture A -> release
```

Extracted rules inside block: NONE

## 6360acc42e15e90c — video/references/patterns-and-genres.md:65-65 (heading)

## 2. Genre modules

Extracted rules inside block: NONE

## 4f10a1595ff2e604 — video/references/patterns-and-genres.md:67-67 (paragraph)

Each genre has a distinct visual grammar. Match style and rhythm to the genre.

Extracted rules inside block: NONE

## f3bf52f6131f1564 — video/references/patterns-and-genres.md:69-69 (heading)

### Domestic tragedy

Extracted rules inside block: NONE

## 7c013091dfd1fc2f — video/references/patterns-and-genres.md:71-71 (paragraph)

Ordinary objects treated with extreme seriousness. Tiny event as cosmic disaster.

Extracted rules inside block: NONE

## 020bbac906048a48 — video/references/patterns-and-genres.md:73-73 (list_item)

- Style. Cold night interior. Mundane location. Dramatic close-ups. Slow push-ins. Macro inserts. Sudden silence.

Extracted rules inside block: NONE

## d7c9184e601f92a5 — video/references/patterns-and-genres.md:74-74 (list_item)

- Tone. Tragicomic. Absurd sincerity.

Extracted rules inside block: NONE

## f7e008d48ddc1005 — video/references/patterns-and-genres.md:75-75 (list_item)

- Pace. Slow build, longer reaction shots.

Extracted rules inside block: NONE

## 55e4143763941f3c — video/references/patterns-and-genres.md:76-76 (list_item)

- Example. A man discovering his fridge is empty, played like a Greek tragedy.

Extracted rules inside block: NONE

## 350aae0d58d30af9 — video/references/patterns-and-genres.md:78-78 (heading)

### Music video

Extracted rules inside block: NONE

## 4c4ac16b20e6252f — video/references/patterns-and-genres.md:80-80 (paragraph)

Rhythm. Repetition. Visual motif. Transformation.

Extracted rules inside block: NONE

## 58986dbd1b6733f1 — video/references/patterns-and-genres.md:82-82 (list_item)

- Style. Repeated gestures. Match cuts. Performance fragments. Visual loops. Color-coded sections. Aggressive lens changes.

Extracted rules inside block: NONE

## 61ce0a4563046a43 — video/references/patterns-and-genres.md:83-83 (list_item)

- Tone. Emotional intensity. Sensory overload with readable structure.

Extracted rules inside block: NONE

## 46286efcbf1fabad — video/references/patterns-and-genres.md:84-84 (list_item)

- Pace. Fast, beat-driven.

Extracted rules inside block: NONE

## 1a35f3a7adba4206 — video/references/patterns-and-genres.md:86-86 (heading)

### Commercial

Extracted rules inside block: NONE

## 2845343c56b7a1d4 — video/references/patterns-and-genres.md:88-88 (paragraph)

Clarity. Product logic. Sensory detail.

Extracted rules inside block: NONE

## 5e952f9b97c247cd — video/references/patterns-and-genres.md:90-90 (list_item)

- Style. Clean lighting. Intentional macro. Clear product visibility. Controlled movement. Readable final hero shot.

Extracted rules inside block: NONE

## 980d09e8943dd06a — video/references/patterns-and-genres.md:91-91 (list_item)

- Tone. Desire. Transformation. Benefit shown through action.

Extracted rules inside block: NONE

## 00ce6f4898e8fbb7 — video/references/patterns-and-genres.md:92-92 (list_item)

- Pace. Medium, building to hero shot.

Extracted rules inside block: NONE

## 52085ec386999450 — video/references/patterns-and-genres.md:94-94 (heading)

### Psychological drama

Extracted rules inside block: NONE

## 196c38eec80ebc52 — video/references/patterns-and-genres.md:96-96 (paragraph)

Pressure. Stillness. Negative space.

Extracted rules inside block: NONE

## ed4f0071b96b3e09 — video/references/patterns-and-genres.md:98-98 (list_item)

- Style. Locked frames. Long close-ups. Reflections. Obstructed framing. Quiet sound design.

Extracted rules inside block: NONE

## 1e7dc4e6f9448ffa — video/references/patterns-and-genres.md:99-99 (list_item)

- Tone. Internal conflict. Hidden tension. Emotional compression.

Extracted rules inside block: NONE

## 0f937ce959600292 — video/references/patterns-and-genres.md:100-100 (list_item)

- Pace. Slow, sustained.

Extracted rules inside block: NONE

## d8fe97f3f3ab472a — video/references/patterns-and-genres.md:102-102 (heading)

### Action

Extracted rules inside block: NONE

## 2631212de8f20b56 — video/references/patterns-and-genres.md:104-104 (paragraph)

Spatial clarity above all else.

Extracted rules inside block: NONE

## 695cd02516fae5dc — video/references/patterns-and-genres.md:106-106 (list_item)

- Style. Establishing geography. Clear direction of movement. Impact inserts. Wide shots between close-ups. Strong eyeline continuity.

Extracted rules inside block: NONE

## 346414d90fcacc08 — video/references/patterns-and-genres.md:107-107 (list_item)

- Tone. Urgency. Force. Readable chaos.

Extracted rules inside block: NONE

## 5b380a7265e08864 — video/references/patterns-and-genres.md:108-108 (list_item)

- Pace. Fast but geometrically clear.

Extracted rules inside block: NONE
