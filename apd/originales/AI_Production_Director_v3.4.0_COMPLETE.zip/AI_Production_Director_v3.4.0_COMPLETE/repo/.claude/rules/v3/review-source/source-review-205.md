# Source coverage review 205/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## ed2843bcc8e0f7f2 — visual-prompt-forge/adapters/flux.md:19-19 (table_row)

| Parameter | Where | Default |

Extracted rules inside block: NONE

## 99bbc5e85f59564a — visual-prompt-forge/adapters/flux.md:21-21 (table_row)

| `aspect_ratio` | API call field | from `project.aspect` |

Extracted rules inside block: NONE

## 8ef884e729dc2993 — visual-prompt-forge/adapters/flux.md:22-22 (table_row)

| `output_format` | API call field | `png` for compositing |

Extracted rules inside block: NONE

## 52dacd87dbc9feb2 — visual-prompt-forge/adapters/flux.md:23-23 (table_row)

| `safety_tolerance` | API call field | `2` (default) |

Extracted rules inside block: NONE

## 1fefe22a0e462673 — visual-prompt-forge/adapters/flux.md:24-24 (table_row)

| `prompt_upsampling` | API call field | `false` for series work, auto-rewrites kill consistency |

Extracted rules inside block: NONE

## 639127aa3128225d — visual-prompt-forge/adapters/flux.md:25-25 (table_row)

| `seed` | API call field | set per-storyboard for series consistency |

Extracted rules inside block: NONE

## e5fd2231edadabbf — visual-prompt-forge/adapters/flux.md:27-27 (paragraph)

In the `flux.txt` output, document parameters as a comment line above each prompt:

Extracted rules inside block: NONE

## f0d1a0d25c4ac9a2 — visual-prompt-forge/adapters/flux.md:29-32 (code)

```
# shot_01, params: ar=9:16, seed=2840193, upsampling=false
{prompt}
```

Extracted rules inside block: NONE

## 363327446cf0b016 — visual-prompt-forge/adapters/flux.md:34-34 (heading)

## Length

Extracted rules inside block: NONE

## eef79dd74f6f9cfe — visual-prompt-forge/adapters/flux.md:36-36 (paragraph)

Flux handles **80–150 words** comfortably. Don't pad, but you have headroom Midjourney doesn't.

Extracted rules inside block: edccdc4a5b19

## c99c578877cb7561 — visual-prompt-forge/adapters/flux.md:38-38 (heading)

## Composition mapping

Extracted rules inside block: NONE

## a08ef563f05b3746 — visual-prompt-forge/adapters/flux.md:40-40 (paragraph)

Translate shot grammar into descriptive language:

Extracted rules inside block: NONE

## 1e70e80136d4110e — visual-prompt-forge/adapters/flux.md:42-42 (table_row)

| shot_grammar | Flux phrasing |

Extracted rules inside block: NONE

## 35cdcea7b5124cc3 — visual-prompt-forge/adapters/flux.md:44-44 (table_row)

| `MCU eye-level` | `Medium close-up framing, camera at eye level.` |

Extracted rules inside block: NONE

## 3d1f73a60d19a8cf — visual-prompt-forge/adapters/flux.md:45-45 (table_row)

| `WS overhead` | `Wide overhead shot, looking straight down.` |

Extracted rules inside block: NONE

## d5b5ade9efedb2c5 — visual-prompt-forge/adapters/flux.md:46-46 (table_row)

| `push` | `Camera pushing slowly toward the subject.` |

Extracted rules inside block: NONE

## f41230070ac280e0 — visual-prompt-forge/adapters/flux.md:47-47 (table_row)

| `handheld` | `Handheld camera with slight natural movement.` |

Extracted rules inside block: NONE

## d365035027b37a8f — visual-prompt-forge/adapters/flux.md:48-48 (table_row)

| `shallow DOF` | `Shot at f/1.8 with shallow depth of field, background softly out of focus.` |

Extracted rules inside block: 7721bcb76850

## 29441b0218a5402d — visual-prompt-forge/adapters/flux.md:49-49 (table_row)

| `deep DOF` | `Shot at f/8, everything in sharp focus front to back.` |

Extracted rules inside block: NONE

## f74a48db861858a5 — visual-prompt-forge/adapters/flux.md:51-51 (heading)

## Photographic specifics

Extracted rules inside block: NONE

## 035087e3875da4a6 — visual-prompt-forge/adapters/flux.md:53-53 (paragraph)

Flux rewards camera/lens vocabulary. Add when relevant:

Extracted rules inside block: NONE

## 0312fb27a57cbf74 — visual-prompt-forge/adapters/flux.md:55-55 (list_item)

- `Shot on Hasselblad, 80mm lens, f/2.8`

Extracted rules inside block: NONE

## b53faedb1e86598a — visual-prompt-forge/adapters/flux.md:56-56 (list_item)

- `Sony FX6, 35mm prime, natural light only`

Extracted rules inside block: NONE

## 38c2fdc997999b0e — visual-prompt-forge/adapters/flux.md:57-57 (list_item)

- `Documentary 16mm film aesthetic, slight grain`

Extracted rules inside block: NONE

## 616dbebcec4a6a64 — visual-prompt-forge/adapters/flux.md:58-58 (list_item)

- `Editorial fashion lighting, large softbox key`

Extracted rules inside block: NONE

## ad63650efbbdfbb8 — visual-prompt-forge/adapters/flux.md:60-60 (heading)

## Composition pattern

Extracted rules inside block: NONE

## 2bac07e5e1a83a4c — visual-prompt-forge/adapters/flux.md:62-64 (code)

```
{Framing description with character anchor and action}. {Environment description from series_lock}. {Lighting sentence from series_lock}. {Photographic spec, camera, lens, depth of field}. {Color grade and mood from brand_lock}. Photorealistic, natural skin texture, no AI artifacts.
```

Extracted rules inside block: NONE

## 67979bbbfaeffc1c — visual-prompt-forge/adapters/flux.md:66-66 (paragraph)

The closing "Photorealistic, natural skin texture, no AI artifacts" line meaningfully reduces the AI-look in Flux output. Include in every prompt.

Extracted rules inside block: NONE

## 5be27ed829e74eb0 — visual-prompt-forge/adapters/flux.md:68-68 (heading)

## Example

Extracted rules inside block: NONE

## 74847542676b6599 — visual-prompt-forge/adapters/flux.md:70-70 (paragraph)

**Same shot data as Midjourney example.**

Extracted rules inside block: NONE
