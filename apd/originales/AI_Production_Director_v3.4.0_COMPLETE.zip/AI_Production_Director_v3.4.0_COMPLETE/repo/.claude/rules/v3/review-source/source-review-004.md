# Source coverage review 4/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## a88e9d7d6513c349 — ai-production-director/SKILL.md:135-135 (paragraph)

Todo entregable que use la capa smixs conserva la línea: *Serge Shima — github.com/smixs/visual-skills* (CC BY 4.0, obligatorio, incluye derivados generados por agentes). Colócala en los créditos del production package, no en cada prompt.

Extracted rules inside block: NONE

## 99740ac043afb9fb — ai-production-director/SKILL.md:137-137 (heading)

## 7. Rol de visual-media (decisión de alcance)

Extracted rules inside block: NONE

## c51dbe4d44fb91c9 — ai-production-director/SKILL.md:139-139 (paragraph)

`visual-media` NO participa en el pipeline live-action: todo lo que cubre (composición, tipos de plano, luz, movimientos de cámara, ritmo de edición) lo cubren con más profundidad `video`, `image` y `storyboard-architect`, y activarla ahí solo mete ruido de triggers. Se invoca ÚNICAMENTE en dos casos:

Extracted rules inside block: NONE

## 18c5c4027da60219 — ai-production-director/SKILL.md:141-141 (list_item)

1. **Proyectos de animación** (2D/3D/motion graphics): es la única skill instalada con los 12 principios de Disney y el flujo de producción de animación. En un proyecto animado, su sección de animación se suma a la Etapa 3 como referencia de performance y timing.

Extracted rules inside block: a85a4da9dbef

## 7461e34efc7f3852 — ai-production-director/SKILL.md:142-142 (list_item)

2. **Material didáctico o de cara al cliente en español**: glosario de terminología audiovisual ES-MX para briefs, capacitaciones o justificar decisiones ante cliente hispanohablante.

Extracted rules inside block: 353ecf5d5ffa

## ba6d8928cfe039ef — ai-production-director/SKILL.md:144-144 (heading)

## 8. Degradación

Extracted rules inside block: NONE

## 60a349c7e0643ce3 — ai-production-director/SKILL.md:146-146 (paragraph)

Si una sub-skill no está instalada, no improvises su oficio en silencio: dilo en una línea y aplica el sustituto — brand-lock ausente → Visual Theme ligero; storyboard-architect ausente → ai-video-storyboard con IDs de shot manuales; critic ausente → checklist de crítica manual contra el shot card; linter ausente → los dos checks de `video` como gate final. Los `tools/` de shotkit viajan dentro de cada .skill empaquetado; requieren `pyyaml` y `jsonschema`.

Extracted rules inside block: NONE

## d844d2acf698a436 — ai-production-director/SKILL.md:148-148 (heading)

## 9. Referencias de este skill

Extracted rules inside block: NONE

## dd8835a08e4feb33 — ai-production-director/SKILL.md:150-150 (list_item)

- `references/creative-strategy.md` — Protocolo completo de la Etapa 1: territorios, big ideas, concept cards, matriz de selección, dirección narrativa. Léelo SIEMPRE al ejecutar la Etapa 1.

Extracted rules inside block: 70522638554f

## 662458ebc08ca45b — ai-production-director/SKILL.md:151-151 (list_item)

- `references/production-package.md` — Spec del Final AI Video Production Package, reglas de trazabilidad y checklist maestro. Léelo SIEMPRE al ejecutar la Etapa 7.

Extracted rules inside block: 74bf2653eee4

## e171aef3d9c8f1f7 — ai-production-director/references/creative-strategy.md:1-1 (heading)

# Etapa 1 — Creative Strategy

Extracted rules inside block: NONE

## 577dafc24b58f15f — ai-production-director/references/creative-strategy.md:3-3 (paragraph)

Este módulo es la autoridad de la Etapa 1 del pipeline. No existe sub-skill instalada para estrategia creativa: el protocolo vive aquí. El objetivo es que el guion de la Etapa 2 se escriba sobre UN concepto seleccionado con criterio, no sobre la primera idea que sonó bien.

Extracted rules inside block: NONE

## 32ff7bdc348467d1 — ai-production-director/references/creative-strategy.md:5-5 (paragraph)

Profundidad por track: FILM ejecuta todo. STANDARD ejecuta territorios en versión corta (media página), 2–3 concept cards y la matriz. EXPRESS no ejecuta esta etapa.

Extracted rules inside block: NONE

## f7eb35d4ab1f79d2 — ai-production-director/references/creative-strategy.md:7-7 (heading)

## 1. Lectura del brief

Extracted rules inside block: NONE

## de4d57299d59e757 — ai-production-director/references/creative-strategy.md:9-9 (paragraph)

Antes de idear, extrae del brief y deja por escrito:

Extracted rules inside block: NONE

## 109298a9db632a23 — ai-production-director/references/creative-strategy.md:11-11 (list_item)

- **Problema de negocio** (qué debe cambiar en el mundo real si el video funciona)

Extracted rules inside block: NONE

## 28685f327d2e44e4 — ai-production-director/references/creative-strategy.md:12-12 (list_item)

- **Audiencia** (quién, en qué momento, con qué fricción — no demografía vacía)

Extracted rules inside block: NONE

## 5aac224df0f7a3d0 — ai-production-director/references/creative-strategy.md:13-13 (list_item)

- **Single-minded proposition**: la única cosa que el video debe dejar instalada. Una frase. Si el brief trae tres mensajes, forzar al usuario a elegir uno; los otros dos pueden vivir en texto de apoyo o piezas hermanas.

Extracted rules inside block: NONE

## f0b23d50f726a3e7 — ai-production-director/references/creative-strategy.md:14-14 (list_item)

- **Tono de marca** (del brand-lock si existe)

Extracted rules inside block: NONE

## 1becdb57313773a9 — ai-production-director/references/creative-strategy.md:15-15 (list_item)

- **Restricciones duras** (legales, de plataforma, de presupuesto de generación)

Extracted rules inside block: NONE

## eedcb4feecf08b86 — ai-production-director/references/creative-strategy.md:17-17 (paragraph)

Si el single-minded proposition no se puede escribir en una frase, la Etapa 1 no puede continuar. Resuélvelo con el usuario primero.

Extracted rules inside block: c040d9ba5468

## 7359c3cb7400f279 — ai-production-director/references/creative-strategy.md:19-19 (heading)

## 2. Territorios creativos

Extracted rules inside block: NONE

## cb351e48c32372ab — ai-production-director/references/creative-strategy.md:21-21 (paragraph)

Un territorio es un espacio conceptual desde el cual se puede contar la proposición — no una idea todavía. Explora 3–4 territorios genuinamente distintos entre sí. Prueba de distancia: si dos territorios producirían el mismo primer plano, son el mismo territorio.

Extracted rules inside block: NONE

## f3348b5f034bd9da — ai-production-director/references/creative-strategy.md:23-23 (paragraph)

Formato por territorio (4–6 líneas):

Extracted rules inside block: NONE

## bc67442008973f86 — ai-production-director/references/creative-strategy.md:25-31 (code)

```
### Territorio: [nombre evocador]
- Ángulo: desde dónde se mira la proposición (el ritual, el antagonista, el después, el detalle invisible…)
- Tensión que explota: qué fricción humana real usa como motor
- Textura: cómo se ve y suena este territorio (2 líneas sensoriales, sin vocabulario prohibido)
- Riesgo: por qué podría fallar o ya estar quemado en la categoría
```

Extracted rules inside block: NONE

## b1e95458b4364049 — ai-production-director/references/creative-strategy.md:33-33 (paragraph)

Registros útiles para forzar distancia entre territorios: emocional vs. funcional · íntimo vs. épico de escala · humor vs. gravedad · protagonista humano vs. producto/entorno como personaje · tiempo real vs. elipsis.

Extracted rules inside block: NONE

## fd56c5f5741b77d2 — ai-production-director/references/creative-strategy.md:35-35 (heading)

## 3. Big ideas y concept cards

Extracted rules inside block: NONE

## 700da84d259b6b53 — ai-production-director/references/creative-strategy.md:37-37 (paragraph)

De los territorios más fuertes, baja 3–5 conceptos (FILM) o 2–3 (STANDARD). Cada concepto es UNA película posible, no una variación de la anterior. Formato obligatorio:

Extracted rules inside block: c7738d061b81

## 345cd5bcbb5b328c — ai-production-director/references/creative-strategy.md:39-49 (code)

```
## Concept Card [N] — [Nombre]
**Territorio de origen:** [cuál]
**Logline:** [la película en 1–2 frases: quién quiere qué, qué lo impide, qué vemos]
**Insight:** [la verdad humana sobre la que se para — algo que la audiencia reconoce como cierto]
**Arco en 3 beats:** [apertura → quiebre → resolución, una línea cada uno]
**Imagen final:** [el último frame, concreto — es lo que el espectador se lleva]
**Por qué vende la proposición:** [mecánica explícita: cómo este concepto instala la single-minded proposition]
**Riesgo principal:** [producción, tono, o percepción — y su mitigación en una línea]
**Complejidad de generación AI:** [Baja/Media/Alta — nº de personajes con continuidad, entornos, física difícil, diálogo lip-sync]
```

Extracted rules inside block: NONE

## 7869c88d4a1af72b — ai-production-director/references/creative-strategy.md:51-51 (paragraph)

El campo de complejidad AI no es decorativo: un concepto brillante con 4 personajes en continuidad a través de 12 shots es un riesgo de producción real en video generativo, y el usuario debe elegirlo sabiéndolo.

Extracted rules inside block: NONE
