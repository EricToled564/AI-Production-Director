# Source coverage review 76/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 896e628f45619976 — image/references/text-rendering.md:159-159 (heading)

## Tips

Extracted rules inside block: NONE

## be5987c6f2bff61f — image/references/text-rendering.md:161-161 (paragraph)

**Provide your own content:**

Extracted rules inside block: NONE

## 2676a2d77561824c — image/references/text-rendering.md:162-162 (list_item)

- Paste article text, video transcript, your notes

Extracted rules inside block: NONE

## 110f00a35c906873 — image/references/text-rendering.md:163-163 (list_item)

- More accurate than relying only on search

Extracted rules inside block: NONE

## b4d23d225eee8956 — image/references/text-rendering.md:165-165 (paragraph)

**Sketch-to-Image:**

Extracted rules inside block: NONE

## 9c603738be3023c8 — image/references/text-rendering.md:166-166 (list_item)

- Draw messy layout sketch on paper

Extracted rules inside block: NONE

## b5e70a7dda3b4e29 — image/references/text-rendering.md:167-167 (list_item)

- Upload with prompt: "Use layout from attached image"

Extracted rules inside block: 3c37ff5f736f

## d962b48d82931e05 — image/references/text-rendering.md:169-169 (paragraph)

**Iterative editing:**

Extracted rules inside block: NONE

## 8f421dcf742f8a5d — image/references/text-rendering.md:170-170 (list_item)

- "Leave everything else exactly the same, but change [X]"

Extracted rules inside block: NONE

## ac3456bd52cd505f — image/references/text-rendering.md:171-171 (list_item)

- Annotate downloaded image, upload back as reference

Extracted rules inside block: NONE

## bb701ac7279e087e — image/references/text-rendering.md:175-175 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## dac1cac6726ff260 — image/references/vision-decomposer.md:1-1 (heading)

# Vision Decomposer — Image-to-Prompt Analysis

Extracted rules inside block: NONE

## 7d16a17ec721eadc — image/references/vision-decomposer.md:3-3 (paragraph)

Use this reference when the user asks to analyze an image and convert it to a generation prompt: **style transfer**, **mood reference**, **"сделай промпт по этой картинке"**, **"перенеси стиль/образ"**, **"проанализируй кадр"**, **"image to prompt"**, **"reverse-engineer this look"**.

Extracted rules inside block: 6e2610917111

## 498d8e0b10f9337e — image/references/vision-decomposer.md:5-5 (paragraph)

You become a **professional Vision Agent**. Your task is deep cinematic, psychological and optical-colorimetric analysis of the image, translating it into a perfect, highly detailed text prompt for generation.

Extracted rules inside block: NONE

## 8525e85c801d6492 — image/references/vision-decomposer.md:7-7 (paragraph)

The process has two strict steps. Do not skip Step 1. Do not freestyle Step 2.

Extracted rules inside block: 21ff9a74e1fa

## fae6ad574edbec7f — image/references/vision-decomposer.md:11-11 (heading)

## STEP 1 — DEEP DECOMPOSITION

Extracted rules inside block: NONE

## 357f24dbd36d123c — image/references/vision-decomposer.md:13-13 (paragraph)

Scan the image as **raw data** and extract facts based on:

Extracted rules inside block: NONE

## 70f7858b4f6c9514 — image/references/vision-decomposer.md:15-15 (list_item)

- **Cinematic composition** — Bruce Block's visual structure

Extracted rules inside block: NONE

## eaa1ce09e6d0e0aa — image/references/vision-decomposer.md:16-16 (list_item)

- **Color theory** — Itten

Extracted rules inside block: NONE

## 8bac21d5d14adcbb — image/references/vision-decomposer.md:17-17 (list_item)

- **Perceptual psychology** — Arnheim

Extracted rules inside block: NONE

## a3f02389b9f495bc — image/references/vision-decomposer.md:18-18 (list_item)

- **Directing references** — Spielberg / Scorsese / Tarantino

Extracted rules inside block: NONE

## 8304d154e736bb81 — image/references/vision-decomposer.md:19-19 (list_item)

- **Cinematography & colorimetry** — Valentin Zheleznyakov

Extracted rules inside block: NONE

## f212aa40ae6c8c44 — image/references/vision-decomposer.md:21-21 (paragraph)

Evaluate the following four parameter blocks.

Extracted rules inside block: NONE

## 94f38f0cec2cb8f8 — image/references/vision-decomposer.md:23-23 (heading)

### 1. Subject — psychology and mise-en-scène

Extracted rules inside block: NONE

## e6ad330a190062a3 — image/references/vision-decomposer.md:25-25 (list_item)

- **Who / What:** precise clothing (era, style, materials), age, skin texture, makeup / toning, micro-expressions.

Extracted rules inside block: NONE

## 8c9742e04280b2f0 — image/references/vision-decomposer.md:26-26 (list_item)

- **Shot size (after Mascelli):** Extreme Long Shot (ELS), Long Shot, Medium Shot, Two-shot / Three-shot, Close-Up (CU), Choker CU, Extreme CU, Insert shot.

Extracted rules inside block: NONE

## a0de6fb8ebb3afea — image/references/vision-decomposer.md:27-27 (list_item)

- **Directing & force placement (Blocking after Kenworthy):** isolating the character at the edge of the frame (anxiety), physical barriers, face turned away from camera, shooting from behind (effect of unknown / powerlessness). Height difference (Level Change) for dominance.

Extracted rules inside block: NONE

## bc1872ba707d8f9f — image/references/vision-decomposer.md:28-28 (list_item)

- **Kinetics & perceptual forces (Arnheim):** visual weight of the object, center of gravity. Internal tension of form (compression / stretching / twisting). Pose, plasticity, motion vectors. Imitation of swift action (motion blur) or monumental stillness.

Extracted rules inside block: NONE

## 427aafa6183f9e67 — image/references/vision-decomposer.md:29-29 (list_item)

- **Color and emotion (Itten):** psychological impact of the local color of the subject.

Extracted rules inside block: NONE

## a2c87c08189e54b9 — image/references/vision-decomposer.md:30-30 (list_item)

- **Gaze:** direction, eyeline anchor, interaction with the frame edges, look into the lens.

Extracted rules inside block: NONE
