# Source coverage review 177/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## b4751e2d3c1072ec — video/references/seedance.md:227-227 (list_item)

- Repeat the identity block in **every** clip of a stitched sequence. Treat each generation as briefing a new intern.

Extracted rules inside block: NONE

## 3cd75d7d26c5b859 — video/references/seedance.md:228-228 (list_item)

- For multiple references (character + setting, character + outfit), label each: `@img1` is the protagonist, `@img2` is the location reference, `@img3` is the outfit reference. Then state the role inline.

Extracted rules inside block: NONE

## 1aa438446d1c7e57 — video/references/seedance.md:229-229 (list_item)

- 2.0 also takes `@Video1` (motion/style reference, 480-720p) and `@Audio1` (voiceover / music) tags — state each reference's role in prose, e.g. "@Audio1 plays as the voiceover". Limits: 12 files total on 2.0 (up to 9 images, 3 videos, 3 audio); up to 50 on 2.5.

Extracted rules inside block: NONE

## 60c88f765b59cdcb — video/references/seedance.md:231-231 (heading)

## 11. Camera movements (9 presets)

Extracted rules inside block: NONE

## 211027ff923122aa — video/references/seedance.md:233-233 (list_item)

- Dolly Out. Reveals context, pulling away.

Extracted rules inside block: NONE

## 4c162c3cbe922ae6 — video/references/seedance.md:234-234 (list_item)

- Dolly In. Pushes into subject, builds tension.

Extracted rules inside block: NONE

## c14d7f01553d7e83 — video/references/seedance.md:235-235 (list_item)

- Pan Left / Pan Right. Horizontal reveal, landscape, row.

Extracted rules inside block: NONE

## 74f93a92bebe628b — video/references/seedance.md:236-236 (list_item)

- Tilt Up / Tilt Down. Vertical reveal.

Extracted rules inside block: NONE

## c6a1f3b75858a0ee — video/references/seedance.md:237-237 (list_item)

- Tracking. Follows a moving subject.

Extracted rules inside block: NONE

## c22c5e4fc715154f — video/references/seedance.md:238-238 (list_item)

- Crane / Aerial. Epic scale, establishing.

Extracted rules inside block: NONE

## b099495cafe161ff — video/references/seedance.md:239-239 (list_item)

- Handheld. Documentary, intimate, UGC.

Extracted rules inside block: NONE

## 7f656e0ea57977ae — video/references/seedance.md:240-240 (list_item)

- Zoom In / Zoom Out. Tension or detail.

Extracted rules inside block: NONE

## f5c2a0f58c1fd0d7 — video/references/seedance.md:241-241 (list_item)

- Hitchcock Zoom. "dolly out while zooming in" for vertigo effect.

Extracted rules inside block: NONE

## 7c5594f691921191 — video/references/seedance.md:242-242 (list_item)

- Static (via `--camerafixed true`). Locked frame.

Extracted rules inside block: NONE

## 267d733bac541237 — video/references/seedance.md:244-244 (paragraph)

Combine sparingly. Multiple camera moves in 5s rarely resolve cleanly.

Extracted rules inside block: NONE

## f9aca6fd14bdd8ef — video/references/seedance.md:246-246 (heading)

## 12. Negative prompts

Extracted rules inside block: NONE

## e0efd1967c4d1a03 — video/references/seedance.md:248-248 (paragraph)

Seedance 1.0 Pro does NOT support negative prompts. No `--no blur` syntax works.

Extracted rules inside block: NONE

## 24f9ecc8ed05319a — video/references/seedance.md:250-250 (paragraph)

Seedance 2.0 adds limited negative prompt support but it's fragile and often ignored.

Extracted rules inside block: NONE

## ad6c0ac49671f476 — video/references/seedance.md:252-252 (paragraph)

Workaround for 1.x/2.0. Always invert to positive phrasing. Instead of "no yellow tones" write "cold blue-gray palette with desaturated skin tones." Instead of "no distorted hands" write "anatomically correct hands with clear finger separation."

Extracted rules inside block: 994ee8176f58

## bc467432a5241e7a — video/references/seedance.md:254-254 (paragraph)

**Seedance 2.5 fixed this.** Direct bans are reliable: "pure video, no subtitles, no background music" actually suppresses them, and specific prohibition lists ("no exaggerated crying, no fast cuts") are a core part of the official 2.5 prompt structure. See `seedance-25.md` §7.

Extracted rules inside block: d6d88112085e

## e24954c1759e7e13 — video/references/seedance.md:256-256 (heading)

## 13. Image-to-video rule

Extracted rules inside block: NONE

## d41fdbc9d093c654 — video/references/seedance.md:258-258 (paragraph)

When using a reference image, DO NOT describe elements already visible in the image. The model sees it. Describe only motion and camera work. Re-describing static elements creates identity drift.

Extracted rules inside block: e54880eddb12

## 5c39aaba62988738 — video/references/seedance.md:260-261 (paragraph)

Bad. "A man in red shirt stands in kitchen. He walks to the fridge."
Good. "He slowly walks toward the fridge, opens it with hesitation, freezes when he sees the empty shelves. Tracking shot from behind, 35mm."

Extracted rules inside block: NONE

## b4e18784de75aa55 — video/references/seedance.md:263-263 (heading)

## 14. Audio (1.5+)

Extracted rules inside block: NONE

## 8fc8a939f75ee33c — video/references/seedance.md:265-265 (paragraph)

Seedance 1.5 Pro, 2.0 and 2.5 generate native audio and support lip-sync. Include audio cues in the body of the prompt — treat the prompt as a sound brief.

Extracted rules inside block: NONE

## a24630cba0ae76ff — video/references/seedance.md:267-269 (code)

```text
Audio. fridge hum, distant rain on window, one stomach growl at 2.3 sec, final silence.
```

Extracted rules inside block: NONE

## f2fcde0cf2ff3403 — video/references/seedance.md:271-271 (paragraph)

Rules:

Extracted rules inside block: NONE

## 3df571cd967fbd29 — video/references/seedance.md:273-273 (list_item)

- Dialogue goes in **double quotes** on 1.5/2.0 — the model voices it, generates the voice and syncs lips to the cut. State the delivery: "Play her line dry and a little proud, his quiet and worn out." **On 2.5, use the dedicated markers instead**: dialogue in `{ }`, SFX in `< >`, music in `( )`, titles in `【 】` (see `seedance-25.md` §4).

Extracted rules inside block: dd1daf88cabf

## be93702a53f667e4 — video/references/seedance.md:274-274 (list_item)

- Keep lines short. Long monologues drift out of sync — split into several lines and hold sync with cuts. Still less robust than Veo for speech-first work.

Extracted rules inside block: NONE

## 9a3ca843dea02493 — video/references/seedance.md:275-275 (list_item)

- Write **"no music"** explicitly when you want none — otherwise the model lays an ad-style score under everything.

Extracted rules inside block: NONE
