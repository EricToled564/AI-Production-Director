# Source coverage review 32/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 7cd370d256cdb4f8 — brand-lock-extractor/tools/README.md:185-191 (code)

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

Extracted rules inside block: NONE

## 5401a383d60bcc4d — brand-lock-extractor/tools/README.md:193-196 (paragraph)

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Extracted rules inside block: 1af7caeeaf8e

## 762582f2aba021e7 — brand-lock-extractor/tools/README.md:198-199 (paragraph)

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

Extracted rules inside block: NONE

## 19b4cf1074a777e1 — brand-lock-extractor/tools/README.md:201-202 (paragraph)

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

Extracted rules inside block: NONE

## 8b3a56320c21924e — brand-lock-extractor/tools/README.md:204-205 (paragraph)

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

Extracted rules inside block: NONE

## 2690adf70d2b999a — brand-lock-extractor/tools/README.md:207-207 (heading)

### `copy-prompt.py`

Extracted rules inside block: NONE

## 2c51da11a1da9877 — brand-lock-extractor/tools/README.md:209-210 (paragraph)

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

Extracted rules inside block: NONE

## e51b9864e82c10fa — brand-lock-extractor/tools/README.md:212-217 (code)

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Extracted rules inside block: NONE

## 6b34f739ea9e0141 — brand-lock-extractor/tools/README.md:219-222 (paragraph)

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Extracted rules inside block: 7153eacbba42

## fdbf31a196f3c7a0 — brand-lock-extractor/tools/README.md:224-224 (paragraph)

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

Extracted rules inside block: NONE

## 4c5f3385bb8e6e82 — brand-lock-extractor/tools/README.md:226-226 (heading)

## Internal modules

Extracted rules inside block: NONE

## 312730f0a1ada4ff — brand-lock-extractor/tools/README.md:228-228 (paragraph)

Not entry points. Imported by the tools above.

Extracted rules inside block: NONE

## a9150965624417dd — brand-lock-extractor/tools/README.md:230-231 (list_item)

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.

Extracted rules inside block: NONE

## eaffa3550d5b1705 — brand-lock-extractor/tools/README.md:232-233 (list_item)

- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

Extracted rules inside block: NONE

## f48e78e13dbe4885 — brand-lock-extractor/tools/README.md:235-235 (heading)

## Adding new tools

Extracted rules inside block: NONE

## 1016bc0c82073bcb — brand-lock-extractor/tools/README.md:237-237 (list_item)

- Make it executable (`chmod +x`)

Extracted rules inside block: NONE

## 35f8ba17a3be1beb — brand-lock-extractor/tools/README.md:238-238 (list_item)

- Add a usage docstring at the top of the file

Extracted rules inside block: NONE

## 1ca4b2b7072a7796 — brand-lock-extractor/tools/README.md:239-239 (list_item)

- Give it a `--selftest` that proves the check fires

Extracted rules inside block: NONE

## f117e0a022cdd53d — brand-lock-extractor/tools/README.md:240-240 (list_item)

- Document it in this README

Extracted rules inside block: NONE

## 0c191ee4c107477f — brand-lock-extractor/tools/README.md:241-241 (list_item)

- Wire it into `tools/check.sh`, which is what CI calls

Extracted rules inside block: NONE

## 8bfe54cbab3834ee — brand-lock-extractor/tools/README.md:243-243 (paragraph)

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

Extracted rules inside block: NONE

## 055cd854c48ca1a6 — image/SKILL.md:2-11 (paragraph)

name: image
license: CC-BY-4.0 (attribution required — Serge Shima, github.com/smixs/visual-skills)
description: >
  Image prompting skill for Nano Banana (NBP/NB2) and GPT Image 2. Writes ready-to-use
  prompts with model/quality/size recommendations. Use when: "нарисуй", "сгенерируй
  картинку", "image prompt", "промпт для картинки", blog covers, slides, posters,
  product shots, UI mockups, storyboards, character sheets, edit/colorize, style transfer,
  vision analysis, image-to-prompt, nb, NBP, NB2, gpt-image-2, multi-panel grids,
  ecommerce product photography, fashion editorial, food/beverage ads, cinematic portraits.
  Do NOT use for: video (use video skill), 3D models, audio, non-image tasks.

Extracted rules inside block: NONE

## 3344da8b3e3d7fa9 — image/SKILL.md:14-14 (heading)

# Image Prompting — Nano Banana & GPT Image 2

Extracted rules inside block: NONE

## 1b8d4c4d392a5476 — image/SKILL.md:16-16 (paragraph)

This skill writes image prompts. It does not generate images. The output is: model name + quality / size / aspect ratio + the prompt itself.

Extracted rules inside block: NONE

## 454a186e6c816954 — image/SKILL.md:18-18 (paragraph)

The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone. The actual rules — what the models reward, what they punish, how to phrase a 5-slot template, when to add `quality: high`, when to use image grounding — live only in the reference files.

Extracted rules inside block: 4f7dd441110e

## 1def914f3b87a240 — image/SKILL.md:20-20 (heading)

## Route first — is this actually an image-prompt task?

Extracted rules inside block: NONE

## 1a9a5f4c71452797 — image/SKILL.md:22-22 (list_item)

- **Motion, clips, montage** (Seedance, Kling, Veo, any image-to-video): use the sibling `video` skill. This skill's storyboard and keyframe outputs feed it.

Extracted rules inside block: 65b0b50050af

## 58ab30e9a3e9e084 — image/SKILL.md:23-23 (list_item)

- **No idea or script yet** (user wants a concept or an ad scenario, not a picture): if the `creative-director` skill is installed, start there — it develops ideas and scripts for commercials and beyond ([github.com/smixs/creative-director-skill](https://github.com/smixs/creative-director-skill)).

Extracted rules inside block: NONE

## fa95fa2fadada1a6 — image/SKILL.md:24-24 (list_item)

- **A concrete image is needed** — this skill. Continue below.

Extracted rules inside block: NONE

## c92c2ec54aa3873c — image/SKILL.md:28-28 (heading)

# Mandatory reading order — DO NOT WRITE A PROMPT WITHOUT THIS

Extracted rules inside block: NONE
