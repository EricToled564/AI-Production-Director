# Source coverage review 150/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## e3f493d2df9f38ae — video/references/fixes-and-skeletons.md:233-233 (list_item)

4. Keep lighting.

Extracted rules inside block: 3087fbde1cce

## 5095c40dcaba5d78 — video/references/fixes-and-skeletons.md:234-234 (list_item)

5. Keep camera.

Extracted rules inside block: f2b96a5cd675

## f21ba27805d10a56 — video/references/fixes-and-skeletons.md:235-235 (list_item)

6. Keep editing grammar.

Extracted rules inside block: 8eaa0b475aba

## a12ef1e3ea9508d5 — video/references/fixes-and-skeletons.md:236-236 (list_item)

7. Keep sound.

Extracted rules inside block: NONE

## c557b767c55a30dc — video/references/fixes-and-skeletons.md:237-237 (list_item)

8. Remove philosophy and meta-commentary.

Extracted rules inside block: 4d9ffd69aa66

## b8fbebd83c9c68ef — video/references/fixes-and-skeletons.md:238-238 (list_item)

9. Remove extra adjectives.

Extracted rules inside block: 69f409c59fce

## 4673090a24ddf5bc — video/references/fixes-and-skeletons.md:239-239 (list_item)

10. Remove director references.

Extracted rules inside block: d6cae7807174

## 263edd9b35054acc — video/references/fixes-and-skeletons.md:241-241 (paragraph)

The goal. Preserve the skeleton. Lose the perfume.

Extracted rules inside block: NONE

## f8c90754ceb61ee9 — video/references/fixes-and-skeletons.md:245-245 (heading)

## 6. Output format templates

Extracted rules inside block: NONE

## 087dd971c2cc3358 — video/references/fixes-and-skeletons.md:247-247 (heading)

### Format A. Single prompt

Extracted rules inside block: NONE

## 0d5a0647e0ad4c37 — video/references/fixes-and-skeletons.md:249-249 (paragraph)

One ready-to-copy prompt for one generation. Use the appropriate model skeleton.

Extracted rules inside block: 84024b4f6746

## 0b11fa489401edb5 — video/references/fixes-and-skeletons.md:251-251 (heading)

### Format B. Multi-clip prompts

Extracted rules inside block: NONE

## 708f33629b5dc1e7 — video/references/fixes-and-skeletons.md:253-253 (paragraph)

Sequence of self-contained prompts. Each one repeats the full continuity block. Label them `Clip 1 / 5`, `Clip 2 / 5`, etc.

Extracted rules inside block: NONE

## 48e014076fc51136 — video/references/fixes-and-skeletons.md:255-255 (paragraph)

Between clips, add a one-line note explaining how they cut together. "Clip 1 ends on his hand reaching into the fridge. Clip 2 opens on his hand already inside the fridge, same light."

Extracted rules inside block: NONE

## fac7fcf3bda929bc — video/references/fixes-and-skeletons.md:257-257 (heading)

### Format C. Storyboard (раскадровка)

Extracted rules inside block: NONE

## ed18b3a937a0b556 — video/references/fixes-and-skeletons.md:259-259 (paragraph)

Table with columns.

Extracted rules inside block: NONE

## bf3b41e4a0054ca6 — video/references/fixes-and-skeletons.md:261-261 (table_row)

| Time | Shot | Function | Action | Camera | Light | Sound | Emotion |

Extracted rules inside block: NONE

## 74f8be22a1328685 — video/references/fixes-and-skeletons.md:263-263 (table_row)

| 0-1s | WS | Establish | Man walks to fridge | 35mm, slow push-in | Cold fluorescent overhead | Fridge hum | Exhaustion |

Extracted rules inside block: NONE

## 918b4f30eb93fc94 — video/references/fixes-and-skeletons.md:264-264 (table_row)

| 1-2s | MCU | Reveal | He opens fridge door | 50mm, static | Cold fridge light as key | Door seal pop | Anticipation |

Extracted rules inside block: NONE

## 6623b19c86ed995e — video/references/fixes-and-skeletons.md:266-266 (paragraph)

Adjust row count to clip length.

Extracted rules inside block: NONE

## f28666831eba603f — video/references/fixes-and-skeletons.md:268-268 (heading)

### Format D. Prompt audit

Extracted rules inside block: NONE

## be6ff6ede67f1dfa — video/references/fixes-and-skeletons.md:270-270 (paragraph)

Given a user prompt. Return six sections.

Extracted rules inside block: NONE

## abe0fd3d48a75ab4 — video/references/fixes-and-skeletons.md:272-272 (list_item)

1. What works.

Extracted rules inside block: NONE

## ac9ed5c1113d8c10 — video/references/fixes-and-skeletons.md:273-273 (list_item)

2. What breaks generation.

Extracted rules inside block: 8045527970db

## 3a72691b5614ea87 — video/references/fixes-and-skeletons.md:274-274 (list_item)

3. Missing direction (camera, light, continuity).

Extracted rules inside block: b2e95327bbdb

## 3049df545f0d37ea — video/references/fixes-and-skeletons.md:275-275 (list_item)

4. Continuity risks.

Extracted rules inside block: 9f1fa0f24301

## 6f38115d03f3d753 — video/references/fixes-and-skeletons.md:276-276 (list_item)

5. Model-specific mismatches (wrong syntax for the chosen model).

Extracted rules inside block: b818c3c7b630

## 5c91193bc5f0531a — video/references/fixes-and-skeletons.md:277-277 (list_item)

6. Stronger version. Rewritten prompt, ready to copy.

Extracted rules inside block: 7b5515d63254

## 150ff170cff623c5 — video/references/fixes-and-skeletons.md:279-279 (heading)

### Format E. Director treatment

Extracted rules inside block: NONE

## 27a9f738ceb88478 — video/references/fixes-and-skeletons.md:281-281 (paragraph)

For concept stage before any prompt is written.

Extracted rules inside block: NONE
