# Source coverage review 54/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 673ee1a6c1eb3bba — image/references/nano-banana.md:138-138 (list_item)

- Склонность к overcooked HDR / пересату — проси «natural contrast, no HDR look».

Extracted rules inside block: NONE

## c82d54099daf9b77 — image/references/nano-banana.md:139-139 (list_item)

- SynthID-водяной знак стоит на всех генерациях (невидимый); на Vertex дополнительно C2PA.

Extracted rules inside block: NONE

## 1e12955956170b36 — image/references/nano-banana.md:141-141 (heading)

## Когда переключаться NB2 → NBP

Extracted rules inside block: NONE

## 2926bbcbad9ba297 — image/references/nano-banana.md:143-143 (list_item)

- NB2 не справляется со сложным многослойным промптом.

Extracted rules inside block: NONE

## 85283aaf09b39c12 — image/references/nano-banana.md:144-144 (list_item)

- Нужен максимум референсов с разбивкой по ролям (6 объектов + 5 character + 3 style).

Extracted rules inside block: NONE

## 343f17c51ecf7e1e — image/references/nano-banana.md:145-145 (list_item)

- Photoreal с очень тонкой работой по материалам и свету.

Extracted rules inside block: NONE

## 965aeb9b1d9e360a — image/references/nano-banana.md:146-146 (list_item)

- NBP медленнее и дороже; на лицах иногда проигрывает NB2 — для портретной серии сначала тестируй оба.

Extracted rules inside block: NONE

## 1a9c97389ce6d6bc — image/references/nano-banana.md:150-150 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## b77e962ec0ecd1bd — image/references/patterns/character-design.md:1-1 (heading)

# Character Design Patterns

Extracted rules inside block: NONE

## c477550904d2e7b5 — image/references/patterns/character-design.md:3-3 (paragraph)

Reusable prompt templates for character turnarounds, expression sheets, outfit variants, and collectible/card formats. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

Extracted rules inside block: NONE

## dbac053f4dd4a1fd — image/references/patterns/character-design.md:7-7 (heading)

## Character Turnaround Sheet (3-View)

Extracted rules inside block: NONE

## 3128ac538e6dbb91 — image/references/patterns/character-design.md:9-9 (paragraph)

Use for game or animation pre-production — front, side, and back views of a character on a single white canvas with color callouts and height reference lines.

Extracted rules inside block: 7a23a22739e1

## 37e63134935708ae — image/references/patterns/character-design.md:11-11 (paragraph)

<!-- Source concept: character model sheet / turnaround sheet for 3D modelers and animators -->

Extracted rules inside block: NONE

## 46b1b3ef1f097757 — image/references/patterns/character-design.md:13-19 (code)

```
Scene: clean white background, flat even lighting with no cast shadows, thin horizontal height reference lines in #CCCCCC spanning the full width at head, shoulder, waist, knee, and foot level
Subject: {character_name} — {character_description} — shown in three views arranged left to right: front view (facing camera), three-quarter side view (turned 75 degrees right), back view (facing away)
Important Details: all three views share identical proportions and vertical alignment along the height lines, feet on the same baseline, arms relaxed at sides for clear silhouette reading, color callout annotations — small circles of each key color ({color_1} {hex_1}, {color_2} {hex_2}, {color_3} {hex_3}) connected by thin #999999 leader lines to the corresponding material on the front view, fine line weight for height markers, clothing folds and seam lines consistent across all three angles
Use Case: game character pre-production, animation model sheet, 3D reference handoff
Constraints: no background elements, no props in hands, no dramatic poses — neutral standing pose only, all three views must depict the exact same character with identical outfit and proportions, no drop shadows, no gradient backgrounds
```

Extracted rules inside block: NONE

## c844f7edc998d076 — image/references/patterns/character-design.md:21-21 (paragraph)

**Key levers:** `{character_name}`, `{character_description}` (age, build, hairstyle, outfit — be specific), `{color_1}`/`{hex_1}` through `{color_3}`/`{hex_3}` (key palette colors for callouts, e.g. jacket navy #1B2A4A, skin warm beige #D4A574, hair auburn #8B3A2F)

Extracted rules inside block: NONE

## 45a8a7810740ac7d — image/references/patterns/character-design.md:23-23 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — height reference lines and color callout text require precise rendering

Extracted rules inside block: 050355e5f639

## 5d332515a74e8bf5 — image/references/patterns/character-design.md:27-27 (heading)

## Expression Sheet

Extracted rules inside block: NONE

## e0b1478276d04a6f — image/references/patterns/character-design.md:29-29 (paragraph)

Use to produce a grid of 6–9 facial expressions for the same character — consistent head angle and art style, with emotion labels under each face.

Extracted rules inside block: bb01b41e7ff5

## 363c6c5e32f07d22 — image/references/patterns/character-design.md:31-31 (paragraph)

<!-- Source concept: character expression/emotion reference sheet for animation or visual novel production -->

Extracted rules inside block: NONE

## b92d34e3a52f2633 — image/references/patterns/character-design.md:33-48 (code)

```
Scene: white background, 3x3 grid (or 3x2 for 6 expressions) with thin #DDDDDD divider lines, each cell contains one head-and-shoulders portrait
Subject: {character_name} — {character_description} — same head angle (three-quarter left), same hairstyle, same lighting across all cells
Important Details:
  Cell 1: neutral — relaxed brow, closed mouth, calm eyes. Label: "NEUTRAL"
  Cell 2: happy — genuine smile reaching the eyes, raised cheeks. Label: "HAPPY"
  Cell 3: angry — furrowed brow, clenched jaw, narrowed eyes. Label: "ANGRY"
  Cell 4: sad — downturned mouth, glistening eyes, slightly lowered head. Label: "SAD"
  Cell 5: surprised — wide eyes, raised eyebrows, open mouth. Label: "SURPRISED"
  Cell 6: disgusted — wrinkled nose, upper lip raised, squinted eyes. Label: "DISGUSTED"
  {extra_expressions}
  Labels in small {label_font} beneath each cell, #555555 text
  Consistent {art_style} rendering across all cells — skin tone, line weight, shading approach identical
Use Case: animation expression reference, visual novel sprite guide, game character documentation
Constraints: same character identity in every cell — no variation in hair, accessories, skin tone, or clothing between expressions, head angle stays fixed, no hand gestures, labels must be legible
```

Extracted rules inside block: NONE

## e80e8ae4f21346b6 — image/references/patterns/character-design.md:50-50 (paragraph)

**Key levers:** `{character_name}`, `{character_description}` (face shape, skin tone, hair, distinguishing marks), `{art_style}` (clean cel-shaded anime, painterly semi-realism, flat vector illustration), `{label_font}` (condensed sans-serif, monospace, rounded sans), `{extra_expressions}` (add cells 7-9: e.g. "Cell 7: smirk — one corner of mouth raised, knowing look. Label: 'SMIRK'")

Extracted rules inside block: NONE

## ed23cd66725a9306 — image/references/patterns/character-design.md:52-52 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — text labels and consistent facial identity across 9 cells need precise control

Extracted rules inside block: 5294f7e75e43

## 1ff1fa6b9e930527 — image/references/patterns/character-design.md:56-56 (heading)

## Outfit Variant Grid

Extracted rules inside block: NONE

## 477305fd92f845cb — image/references/patterns/character-design.md:58-58 (paragraph)

Use to show one character in multiple outfits or costumes — for fashion exploration, game skin concepts, or wardrobe design.

Extracted rules inside block: 0aa0d010db93

## d53d68aa6b338502 — image/references/patterns/character-design.md:60-60 (paragraph)

<!-- Source concept: character costume/skin variant sheet for fashion or game design -->

Extracted rules inside block: NONE

## 93c1e5a5ddbaffbc — image/references/patterns/character-design.md:62-76 (code)

```
Scene: light neutral background ({bg_color}), {grid_layout} grid, thin white gaps between cells, soft even front lighting in every cell
Subject: {character_name} — {character_description} — same pose ({pose_description}) in every cell, only the outfit changes
Important Details:
  Cell 1: {outfit_1_name} — {outfit_1_description}
  Cell 2: {outfit_2_name} — {outfit_2_description}
  Cell 3: {outfit_3_name} — {outfit_3_description}
  Cell 4: {outfit_4_name} — {outfit_4_description}
  Cell 5: {outfit_5_name} — {outfit_5_description}
  Cell 6: {outfit_6_name} — {outfit_6_description}
  Outfit name in small bold sans-serif centered below each cell, #333333 text
  Character body proportions, face, hairstyle, and skin tone identical across all cells — only clothing and accessories differ
Use Case: game skin lineup, fashion mood board, costume design exploration
Constraints: same character identity and pose in every cell, no background scenery — character only, outfit labels must be readable, no overlapping garments between cells, {grid_layout} layout must be uniform
```

Extracted rules inside block: NONE

## 274ae97971c2e9d4 — image/references/patterns/character-design.md:78-78 (paragraph)

**Key levers:** `{character_name}`, `{character_description}` (build, face, hair — anchor identity), `{bg_color}` (#F0F0F0 light gray, #FFF8F0 warm cream, #E8EDF2 cool blue-gray), `{grid_layout}` (2x3 or 3x3), `{pose_description}` (hands on hips, relaxed standing, one hand raised), `{outfit_N_name}` / `{outfit_N_description}` (e.g. "Street Casual" — oversized denim jacket, white tee, black cargo pants, chunky sneakers)

Extracted rules inside block: NONE

## 3686c75461db836e — image/references/patterns/character-design.md:80-80 (paragraph)

**Recommended model:** GPT Image 2 (`quality: medium`) — character consistency is the priority; `high` only if outfit labels need fine legibility

Extracted rules inside block: 9dd0c4a077a6

## d531ad7c4c005acf — image/references/patterns/character-design.md:84-84 (heading)

## Chibi / Mini-Me Collectible

Extracted rules inside block: NONE

## 8867d6d3e365c531 — image/references/patterns/character-design.md:86-86 (paragraph)

Use to transform a realistic character into a cute 3D collectible figurine — oversized head, compact body, multiple poses performing different activities.

Extracted rules inside block: e8c2e6289fa8
