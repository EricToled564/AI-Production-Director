# Source coverage review 201/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 8e7717a1db0b9728 — visual-prompt-forge/SKILL.md:104-107 (paragraph)

`max_prompt_words` is a ceiling. The range in an adapter `.md` is the recommended target
and always sits inside that ceiling, so a `.md` saying "40 to 70 words" under a ceiling of
120 is guidance, not a conflict. Where a fact in a `.md` and a fact in the JSON genuinely
disagree, **the JSON wins**.

Extracted rules inside block: eae568cd8fa1, b04b11ca5ff4

## 108319e7f33bd17b — visual-prompt-forge/SKILL.md:109-113 (paragraph)

That rule is now enforced rather than trusted. `tools/validate_capabilities.py` fails the
build when an adapter advertises more words than its ceiling, or when an adapter never
documents the `aspect_param` the JSON tells you to send. The second check exists because
nano-banana's matrix entry said `aspect_ratio` while its adapter said the API expects
`aspectRatio`; the precedence rule meant the wrong one won, silently, on every prompt.

Extracted rules inside block: 07271a44b40d

## 6038725a732f0678 — visual-prompt-forge/SKILL.md:115-115 (heading)

### Step 3. Compose per shot

Extracted rules inside block: NONE

## 085bfe61d1fb8d10 — visual-prompt-forge/SKILL.md:117-117 (paragraph)

For each shot in `shots.json`, for each target generator:

Extracted rules inside block: NONE

## 9fc070f20a3bdd17 — visual-prompt-forge/SKILL.md:119-119 (list_item)

1. Pull brand-lock palette, mood, "never" list

Extracted rules inside block: 8c44b242f104

## d8039fdd762184a4 — visual-prompt-forge/SKILL.md:120-120 (list_item)

2. Pull series_lock character/environment/lighting

Extracted rules inside block: 5ee565ac959a

## 3c61b03f8241eab3 — visual-prompt-forge/SKILL.md:121-121 (list_item)

3. Pull shot framing/angle/motion/subject

Extracted rules inside block: 6f9dae549b21

## b25be06839473d5c — visual-prompt-forge/SKILL.md:122-122 (list_item)

4. **Strip any on_screen_text reference**, text never goes in the prompt

Extracted rules inside block: 83414e65ec45

## 6ada5e6fed43fd39 — visual-prompt-forge/SKILL.md:123-123 (list_item)

5. Apply the generator adapter's syntax wrapper

Extracted rules inside block: c8713d0a8fe6

## 6ee98fb822892f00 — visual-prompt-forge/SKILL.md:124-124 (list_item)

6. Append generator-specific parameters (aspect ratio, style flags, seed if applicable)

Extracted rules inside block: 2988766eac65

## b68cc54f8a14ae5e — visual-prompt-forge/SKILL.md:126-126 (heading)

### Step 4. Write output files

Extracted rules inside block: NONE

## 065ffbd0f4d22b7e — visual-prompt-forge/SKILL.md:128-128 (paragraph)

One file per generator, into `output/prompts/round-{N}/`. Format:

Extracted rules inside block: NONE

## 340a78f7498386da — visual-prompt-forge/SKILL.md:130-146 (code)

```
# Storyboard: {project title}
# Generator: midjourney
# Model: {model_version from _capabilities.json}
# Aspect: 9:16
# Brand-lock: brand-lock.snapshot.md
# Run: {run_id from run.json}
# Round: 1

# shot_01, hook, 0.0-2.0s, MCU eye-level static
{the prompt}

# shot_02, pain, 2.0-6.0s, MS eye-level push
{the prompt}

...
```

Extracted rules inside block: NONE

## 936545ea5c7727b7 — visual-prompt-forge/SKILL.md:148-150 (paragraph)

The `#` lines are comments; the user copies just the prompt body. `tools/copy-prompt.py`
parses this format, treating a comment line that names a shot as a block header and any
other comment inside a block as an annotation it will not copy.

Extracted rules inside block: NONE

## 5ed3f640ac7b0e5d — visual-prompt-forge/SKILL.md:152-154 (paragraph)

Record the run and round in the header, not a wall-clock "Generated" line. A timestamp in
the header made every file differ between two otherwise identical runs, which is a strange
thing to put in an artifact whose selling point is determinism.

Extracted rules inside block: NONE

## 668b1819ca1f14b9 — visual-prompt-forge/SKILL.md:156-156 (heading)

### Step 4b. Append the round to run.json

Extracted rules inside block: NONE

## 2702113c1569bc5b — visual-prompt-forge/SKILL.md:158-160 (paragraph)

After writing the files, append an entry to `run.json`'s `rounds` array: the round number,
`started_at`, a `reason`, and for each file its generator, path, SHA-256, and the shot ids
it covers.

Extracted rules inside block: NONE

## 8cb84450ca3b744e — visual-prompt-forge/SKILL.md:162-164 (code)

```bash
shasum -a 256 output/prompts/round-1/*.txt
```

Extracted rules inside block: NONE

## 041d236e5635bb71 — visual-prompt-forge/SKILL.md:166-167 (paragraph)

This is the only writeable part of `run.json`. Everything else was fixed when the
architect wrote it.

Extracted rules inside block: NONE

## f89e08985661a783 — visual-prompt-forge/SKILL.md:169-169 (heading)

### Step 5. Hand off

Extracted rules inside block: NONE

## e7f8482d3566babc — visual-prompt-forge/SKILL.md:171-171 (paragraph)

Tell the user where the files are. Offer the next step:

Extracted rules inside block: NONE

## cf80dada74a37723 — visual-prompt-forge/SKILL.md:173-173 (list_item)

> "Want me to QA the generated images against the storyboard? Use `visual-asset-critic` once you have the renders."

Extracted rules inside block: 96282de02dde

## ef798c5f6a162cad — visual-prompt-forge/SKILL.md:175-175 (paragraph)

For paste-into-generator workflows, the user can pipe individual shots to the clipboard with the bundled helper:

Extracted rules inside block: NONE

## 8a54cdb6a3e48f87 — visual-prompt-forge/SKILL.md:177-180 (code)

```bash
python tools/copy-prompt.py output/prompts/round-1/midjourney.txt
python tools/copy-prompt.py output/prompts/round-2/revised-midjourney.txt --shot shot_03
```

Extracted rules inside block: NONE

## 28a528f1c520a9fa — visual-prompt-forge/SKILL.md:182-182 (paragraph)

This is optional. The `.txt` files are also directly readable, and the user can copy any block by hand. The helper exists for the case where the operator is bouncing between the terminal and a generator UI repeatedly.

Extracted rules inside block: NONE

## 41455cc4bd8fe84c — visual-prompt-forge/SKILL.md:184-184 (heading)

## Revision mode (closing the QA loop)

Extracted rules inside block: NONE

## d7b5bfdf9b99467f — visual-prompt-forge/SKILL.md:186-186 (paragraph)

This is what `visual-asset-critic`'s structured output is for. When the user hands you `shots.json` plus one or more `critique.json` files (the machine-readable verdict the critic writes), don't re-forge the whole storyboard, re-emit prompts for **only the shots that failed**, with the fix already applied.

Extracted rules inside block: f2e080c448e3

## c304c229cf654e5c — visual-prompt-forge/SKILL.md:188-188 (heading)

### Trigger

Extracted rules inside block: NONE

## dde2afe3729d3c2a — visual-prompt-forge/SKILL.md:190-190 (paragraph)

The user says "apply the critique", "revise the failed shots", "re-roll what didn't pass", or hands over an output tree containing `critiques/`.

Extracted rules inside block: NONE

## 4f8572201db2fdfa — visual-prompt-forge/SKILL.md:192-192 (heading)

### Workflow

Extracted rules inside block: NONE
