# Source coverage review 127/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0cb7b85f296eaa5a — video/SKILL.md:9-9 (paragraph)

Hybrid role. You direct (see frame, emotion, motivated camera), write (build beat, action, consequence, final image), and edit (cut rhythm, protect continuity, drive montage). Prompt engineering is fourth — it serves the first three.

Extracted rules inside block: NONE

## f18a9de0771513b0 — video/SKILL.md:11-11 (paragraph)

A beautiful frame without dramaturgy is wallpaper. A dramaturgically clean prompt without details is mush. The whole craft of this skill lives in the reference files. The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone.

Extracted rules inside block: NONE

## 0f53911e2931bded — video/SKILL.md:13-13 (heading)

## Route first — is this actually a video-prompt task?

Extracted rules inside block: NONE

## 4db51ff9a1128822 — video/SKILL.md:15-15 (list_item)

- **No idea or script yet** (user wants a concept, a Big Idea, a campaign, an ad scenario — not a prompt): if the `creative-director` skill is installed, start there — it develops ideas and scripts for commercials and beyond ([github.com/smixs/creative-director-skill](https://github.com/smixs/creative-director-skill)). Come back here once there is a script to shoot.

Extracted rules inside block: NONE

## 7130f8813d18474e — video/SKILL.md:16-16 (list_item)

- **Still keyframes, character sheets, animatic panels** to feed the video pipeline: use the sibling `image` skill, then return with the keyframes.

Extracted rules inside block: 7f4ebe869b7f

## 258a42c5def60c2f — video/SKILL.md:17-17 (list_item)

- **A script or scene exists and needs prompts** — this skill. Continue below.

Extracted rules inside block: NONE

## 30aa49cbc8936a3a — video/SKILL.md:21-21 (heading)

# Mandatory reading order — DO NOT WRITE A PROMPT WITHOUT THIS

Extracted rules inside block: NONE

## dfae89b7e05a2a8c — video/SKILL.md:23-23 (paragraph)

Past attempts to write prompts directly from this skill body produced lazy, mush-prone results. The fix is structural: the process lives only in the reference files, and you load them in this order before producing output. Skipping a step **silently** degrades the result — the model cannot tell that a shot is wallpaper, only the writer can, and only by applying the rules from these files.

Extracted rules inside block: NONE

## 1be96980f5e6aba7 — video/SKILL.md:25-25 (paragraph)

For every video prompt request, load the files in this order:

Extracted rules inside block: NONE

## f68abddf325a1f90 — video/SKILL.md:27-27 (heading)

### Step 1 — always read first → [dramaturgy.md](references/dramaturgy.md)

Extracted rules inside block: NONE

## 7da46bc46adcffb7 — video/SKILL.md:29-29 (paragraph)

Scene formula. Details Law (the second core law, most violated). Murch Rule of Six. Three-jobs rule. Five anchors. Blocking, staging, environment as pressure. Three-layer storyboard. 14-field shot card. Rhythm ladder. Dramaturgy check.

Extracted rules inside block: NONE

## e2b4e497f3de0b18 — video/SKILL.md:31-31 (paragraph)

You cannot decide whether a prompt is ready without running the dramaturgy check from this file.

Extracted rules inside block: NONE

## 278abbbac05e3e18 — video/SKILL.md:33-33 (heading)

### Step 2 — always read second → [universal-rules.md](references/universal-rules.md)

Extracted rules inside block: NONE

## 2bd0c63162690109 — video/SKILL.md:35-35 (paragraph)

U1–U12 universal rules that apply to every video model: prompt skeleton, weight-at-start, show-don't-tell, lens language, character anchor, contradictions, duration discipline, final image rule, three-detail check.

Extracted rules inside block: 6ebda3899eb2

## aad8009e7a3bd201 — video/SKILL.md:37-37 (heading)

### Step 3 — pick the model and read **one** model file

Extracted rules inside block: NONE

## fb887e79fd83b43d — video/SKILL.md:39-39 (paragraph)

Use this short selector. The full reasoning is in the chosen file.

Extracted rules inside block: 354735b74358

## 008f53581deedf1a — video/SKILL.md:41-41 (table_row)

| Cue from the user / task | Read |

Extracted rules inside block: NONE

## 757bcdcbe198aa3d — video/SKILL.md:43-43 (table_row)

| Seedance, ByteDance, Doubao, Jimeng, multi-shot in one clip, `--resolution`, `--duration`, `--camerafixed`, "Cut to", `@img1`, fast multi-shot drama | [seedance.md](references/seedance.md) |

Extracted rules inside block: NONE

## a973b8f2be291616 — video/SKILL.md:44-44 (table_row)

| **Seedance 2.5 production work**: 30s single-pass, 50-slot reference kits, video editing / partial re-render, extension, Ultra Long (30-180s), 3D blockout / green screen, `@Image N`, `{ }` dialogue markers | [seedance.md](references/seedance.md) **+** [seedance-25.md](references/seedance-25.md) |

Extracted rules inside block: NONE

## a459ccee2d003575 — video/SKILL.md:45-45 (table_row)

| Kling, Kuaishou, Element Binding, Motion Brush, Motion Control, dedicated negative prompt field, **Kling 3.0 multi-shot with `[Character A: ...]` labels, native dialogue + lip-sync, 15s, Turbo (cheap lip-sync), Omni (references + editing, 4K)** | [kling.md](references/kling.md) |

Extracted rules inside block: NONE

## 4060b4102eb7286e — video/SKILL.md:46-46 (table_row)

| Veo, Google video, dialogue / lip-sync, JSON prompts, synchronized SFX, commercial polish with voiceover | [veo.md](references/veo.md) |

Extracted rules inside block: NONE

## 267bccb6c1c4ab89 — video/SKILL.md:48-48 (paragraph)

Default if nothing in the request hints at a model:

Extracted rules inside block: NONE

## 180d9eca790f20a4 — video/SKILL.md:49-49 (list_item)

- Multi-shot narrative or fast montage drama → Seedance, or Kling 3.0 if dialogue is involved.

Extracted rules inside block: NONE

## d0ef0b69a6be52a8 — video/SKILL.md:50-50 (list_item)

- Dialogue / commercial polish / synchronized SFX → Veo, or Kling 3.0 for multi-character dialogue scenes up to 15s.

Extracted rules inside block: NONE

## f69748150f83a6c4 — video/SKILL.md:51-51 (list_item)

- Character consistency across many social clips → Kling 2.6 Pro (cheaper) or Kling 3.0 (with in-prompt `[Character A: ...]` labels).

Extracted rules inside block: NONE

## 1239f302555cc68a — video/SKILL.md:52-52 (list_item)

- 10-15s continuous narrative with audio → Kling 3.0.

Extracted rules inside block: NONE

## 9c7388a6ea406a34 — video/SKILL.md:53-53 (list_item)

- 15-30s continuous single-generation arc, heavy reference kits (up to 50 assets), editing or extending existing footage, 30-180s long-form → Seedance 2.5.

Extracted rules inside block: NONE

## 0a3d922ffdb3188b — video/SKILL.md:54-54 (list_item)

- Face-heavy drama → Seedance 2.5 (realistic humans + lip-sync are its headline feature), Kling, or Veo. On a 2.0-only pipeline route faces to 1.5 Pro (2.0 filters human faces aggressively).

Extracted rules inside block: NONE

## 3c3e1a8c94894a12 — video/SKILL.md:56-56 (paragraph)

For a more detailed comparison (max clip length, audio support, character lock methods, motion brush, etc.), read the model file you picked. Do not load all three.

Extracted rules inside block: ff1ab6bbaf46

## 131085adc71e2f18 — video/SKILL.md:58-58 (heading)

### Step 4 — task-shaped reading (load only those that match)

Extracted rules inside block: NONE
