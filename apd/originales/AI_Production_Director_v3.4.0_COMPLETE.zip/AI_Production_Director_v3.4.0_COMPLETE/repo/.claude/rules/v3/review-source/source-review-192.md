# Source coverage review 192/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## aa048522a379813d — visual-asset-critic/references/critique-rubric.md:10-10 (table_row)

| Mood adjectives | Image reads as the brand mood | Mood reads as adjacent (e.g. "calm" vs "neutral") | Image reads as a different mood (e.g. "energetic" when brief was "calm") |

Extracted rules inside block: NONE

## 5a02f404ced38fb2 — visual-asset-critic/references/critique-rubric.md:11-11 (table_row)

| "Never" list | None of the items in the never list are present | One item in the never list shows softly | Multiple never-list violations |

Extracted rules inside block: 40bb01661724

## adbdbce4bb2a8902 — visual-asset-critic/references/critique-rubric.md:12-12 (table_row)

| Aspect ratio | Matches `project.aspect` | Within a crop of the spec | Wrong aspect |

Extracted rules inside block: NONE

## 335e6943bef01945 — visual-asset-critic/references/critique-rubric.md:14-14 (paragraph)

Hard fail on Brand Lock = REJECT or REVISE depending on whether prompt fix exists.

Extracted rules inside block: NONE

## 6b07351fa057a123 — visual-asset-critic/references/critique-rubric.md:16-16 (heading)

## Layer 2. Series Lock check

Extracted rules inside block: NONE

## 08685d9d74295fec — visual-asset-critic/references/critique-rubric.md:18-18 (table_row)

| Check | Pass | Soft fail | Hard fail |

Extracted rules inside block: NONE

## b5f93ea23180f295 — visual-asset-critic/references/critique-rubric.md:20-20 (table_row)

| Character anchor | All described features visible | One minor feature off (e.g. wrong shirt color) | Wrong person (different age/race/build than anchor) |

Extracted rules inside block: NONE

## 41c65a3148d5ee08 — visual-asset-critic/references/critique-rubric.md:21-21 (table_row)

| Environment | Matches series_lock | Slight environment drift | Different environment entirely |

Extracted rules inside block: NONE

## dfdbf418fd992ece — visual-asset-critic/references/critique-rubric.md:22-22 (table_row)

| Lighting direction | Matches series_lock | Lighting is right but slightly different angle | Lighting from wrong direction (continuity break) |

Extracted rules inside block: NONE

## 232bc8cb084f1edc — visual-asset-critic/references/critique-rubric.md:23-23 (table_row)

| Color grade | Matches series_lock | Slight tonal drift | Different color grade |

Extracted rules inside block: NONE

## e8739f5ed89ee0b0 — visual-asset-critic/references/critique-rubric.md:25-25 (paragraph)

Hard fail on Series Lock = REJECT (continuity break) or REVISE if specific fix available.

Extracted rules inside block: NONE

## 5ea494ee0e11329c — visual-asset-critic/references/critique-rubric.md:27-27 (heading)

## Layer 3. Shot Spec check

Extracted rules inside block: NONE

## d13866e1a4c301d6 — visual-asset-critic/references/critique-rubric.md:29-29 (table_row)

| Check | Pass | Soft fail | Hard fail |

Extracted rules inside block: NONE

## ba37f09a06cdff14 — visual-asset-critic/references/critique-rubric.md:31-31 (table_row)

| Framing | Matches spec (ECU/CU/MS/etc.) | One step off (e.g. MS instead of MCU) | Two+ steps off |

Extracted rules inside block: NONE

## 3ad1684255541692 — visual-asset-critic/references/critique-rubric.md:32-32 (table_row)

| Angle | Matches spec | Slight angle variation | Wrong angle (low when spec was eye-level) |

Extracted rules inside block: NONE

## 5cf54c7acf14a36a — visual-asset-critic/references/critique-rubric.md:33-33 (table_row)

| Subject action | Matches `subject` description | Subject doing similar but slightly different action | Subject doing wrong action |

Extracted rules inside block: NONE

## cb47e68b9a9c5a64 — visual-asset-critic/references/critique-rubric.md:34-34 (table_row)

| Depth of field | Matches if specified | Slight DOF variation | Deep when shallow was specified |

Extracted rules inside block: 66404602f287

## 60c734fced9c7fd8 — visual-asset-critic/references/critique-rubric.md:36-36 (paragraph)

Soft fail = post-level fix or accept. Hard fail = revise.

Extracted rules inside block: NONE

## b275936a819a0921 — visual-asset-critic/references/critique-rubric.md:38-38 (heading)

## Layer 4. Composition check

Extracted rules inside block: NONE

## 34caa19b8847c427 — visual-asset-critic/references/critique-rubric.md:40-40 (table_row)

| Check | Pass | Soft fail | Hard fail |

Extracted rules inside block: NONE

## 815ca10d6a954d4c — visual-asset-critic/references/critique-rubric.md:42-42 (table_row)

| Negative space for text | Reserved per spec | Reserved but tight | No reserved space, overlay won't fit |

Extracted rules inside block: NONE

## 9166a7c351d8c81c — visual-asset-critic/references/critique-rubric.md:43-43 (table_row)

| Subject placement | Matches rationale | Slightly off (subject in left-third vs right-third) | Subject blocks where text was meant to go |

Extracted rules inside block: NONE

## d2680cb8a56c0ec8 — visual-asset-critic/references/critique-rubric.md:44-44 (table_row)

| Eye-line | Looks where intended | Slight gaze direction off | Looking the wrong way |

Extracted rules inside block: NONE

## d3853e46eb45a8ed — visual-asset-critic/references/critique-rubric.md:45-45 (table_row)

| Headroom | Appropriate | Slightly tight or loose | Cropped at hairline / huge headroom |

Extracted rules inside block: NONE

## fc4b9ffbfd38da4b — visual-asset-critic/references/critique-rubric.md:47-47 (paragraph)

Composition fails are usually prompt-level fixable. Re-roll with explicit composition language.

Extracted rules inside block: NONE

## 51f7647647497f1e — visual-asset-critic/references/critique-rubric.md:49-49 (heading)

## Layer 5. Technical check

Extracted rules inside block: NONE

## 76a0788ec5596dbf — visual-asset-critic/references/critique-rubric.md:51-51 (table_row)

| Check | Pass | Soft fail | Hard fail |

Extracted rules inside block: NONE

## 1e5e455f42ec21c3 — visual-asset-critic/references/critique-rubric.md:53-53 (table_row)

| Hands | Anatomically correct | Slight finger weirdness | Six fingers, fused fingers, wrong joints |

Extracted rules inside block: NONE

## 2f155be1c3fdff17 — visual-asset-critic/references/critique-rubric.md:54-54 (table_row)

| Eyes | Symmetrical, focused | Slight asymmetry | Wonky eyes, wrong reflections |

Extracted rules inside block: NONE

## 9a8ab80f0e5e6f5e — visual-asset-critic/references/critique-rubric.md:55-55 (table_row)

| Skin texture | Natural | Slightly plastic | Heavy AI plastic |

Extracted rules inside block: NONE
