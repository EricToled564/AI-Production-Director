# Source coverage review 20/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f8fba3a4af3401b1 — brand-lock-extractor/SKILL.md:23-23 (paragraph)

If the user has nothing but a vague idea (no assets, no description), they are not extracting, they are authoring. Point them at `brand-packs/_template.md` and help them fill it directly.

Extracted rules inside block: NONE

## fe82adb227f26351 — brand-lock-extractor/SKILL.md:25-25 (heading)

## Inputs

Extracted rules inside block: NONE

## 4bc18ec0352e10c3 — brand-lock-extractor/SKILL.md:27-27 (paragraph)

You can work from any one of these. More sources is a better extraction.

Extracted rules inside block: NONE

## db205e0a190e0db2 — brand-lock-extractor/SKILL.md:29-29 (table_row)

| Source | How you read it | Best for |

Extracted rules inside block: NONE

## 4a74bfe7715bf231 — brand-lock-extractor/SKILL.md:31-31 (table_row)

| Website URL | `WebFetch` homepage + about + one more page | Voice, positioning, palette, type |

Extracted rules inside block: NONE

## 9de46a42e8e5a7d6 — brand-lock-extractor/SKILL.md:32-32 (table_row)

| Brand book PDF | `Read` the PDF | Palette (exact hex), type, motion rules |

Extracted rules inside block: NONE

## 3a6d677f8c39b8a8 — brand-lock-extractor/SKILL.md:33-33 (table_row)

| Screenshots / image files | `Read` the images | Palette (sample pixels), mood, layout |

Extracted rules inside block: NONE

## 256d7105ed3314d3 — brand-lock-extractor/SKILL.md:34-34 (table_row)

| Written description | Use directly | Identity, archetype, voice posture |

Extracted rules inside block: f64a1b15787a

## 7807b68054433331 — brand-lock-extractor/SKILL.md:36-36 (paragraph)

At minimum you need one source. If the user offers none, ask for the one they have: **"What can I work from, a website URL, a brand book PDF, screenshots, or a short description?"** One question.

Extracted rules inside block: NONE

## 846900f9f19b4488 — brand-lock-extractor/SKILL.md:38-38 (heading)

## Workflow

Extracted rules inside block: NONE

## bbef88978bd9c2d8 — brand-lock-extractor/SKILL.md:40-40 (heading)

### Step 1. Gather the source material

Extracted rules inside block: NONE

## 12bc75c03b32ef81 — brand-lock-extractor/SKILL.md:42-42 (list_item)

- **URL:** `WebFetch` the homepage, then try the about page (`/about`, `/about-us`, `/our-story`) and one more (`/services`, `/work`, recent blog). Skip pages that 404. The homepage is the floor.

Extracted rules inside block: NONE

## 06f86338059d06c2 — brand-lock-extractor/SKILL.md:43-43 (list_item)

- **PDF / images:** `Read` each file. Brand books carry exact hex and type; screenshots are for sampling color and reading mood.

Extracted rules inside block: NONE

## b758133e8cda74e6 — brand-lock-extractor/SKILL.md:44-44 (list_item)

- **Description:** take it as written.

Extracted rules inside block: NONE

## ea35e9d5d22d42a9 — brand-lock-extractor/SKILL.md:46-46 (paragraph)

Tell the user what you are pulling. Do not ask follow-ups yet, extract first, confirm gaps at the end.

Extracted rules inside block: 345e51cdd0e8

## 0ca8875c6ff46d56 — brand-lock-extractor/SKILL.md:48-48 (heading)

### Step 2. Extract each section

Extracted rules inside block: NONE

## 2f24eda3c879c478 — brand-lock-extractor/SKILL.md:50-50 (paragraph)

Read `references/extraction-rubric.md`. It maps every brand-lock section to where the signal lives and how to read it. Work the nine sections in order:

Extracted rules inside block: NONE

## 28151fab084d4f0e — brand-lock-extractor/SKILL.md:52-52 (list_item)

1. **Identity** (brand, one-line description, archetype, voice posture)

Extracted rules inside block: 86eaea2929ff

## 0e806c29f1680744 — brand-lock-extractor/SKILL.md:53-53 (list_item)

2. **Palette** (sampled hex, by role)

Extracted rules inside block: d55e33adff98

## 40f1c26722dde384 — brand-lock-extractor/SKILL.md:54-54 (list_item)

3. **Typography** (display, body, optional mono, with weights)

Extracted rules inside block: 087a02f85a83

## 71deb2fc2ca22982 — brand-lock-extractor/SKILL.md:55-55 (list_item)

4. **Mood adjectives** (3-5, specific, contrast clauses preferred)

Extracted rules inside block: cc8d067c481f

## 0e245555031588bf — brand-lock-extractor/SKILL.md:56-56 (list_item)

5. **Never list** (what the brand avoids, inferred from consistency)

Extracted rules inside block: 16bdbf3c53a1

## 540c2eb44a2facba — brand-lock-extractor/SKILL.md:57-57 (list_item)

6. **Aspect ratios**

Extracted rules inside block: b0db566195c3

## c307184af508b3cf — brand-lock-extractor/SKILL.md:58-58 (list_item)

7. **Color grade direction** (one sentence)

Extracted rules inside block: a3a57fcfe2f3

## 2fa909678385c91b — brand-lock-extractor/SKILL.md:59-59 (list_item)

8. **Motion language** (one paragraph)

Extracted rules inside block: a514b90f152f

## 81ea148edc2f98ee — brand-lock-extractor/SKILL.md:60-60 (list_item)

9. **Voice rules** (copy-level constraints)

Extracted rules inside block: a655e17cddb6

## befb01ac1fda3839 — brand-lock-extractor/SKILL.md:62-62 (paragraph)

For every value, hold two things: the value, and where it came from (which asset, which quote, which sampled swatch). You will need the source for the confidence pass.

Extracted rules inside block: NONE

## 943817ef7ca199ef — brand-lock-extractor/SKILL.md:64-64 (heading)

### Step 3. Assign confidence and flag estimates

Extracted rules inside block: NONE

## 55663256f804f2f0 — brand-lock-extractor/SKILL.md:66-66 (paragraph)

Each value is one of:

Extracted rules inside block: NONE

## 40026101149d5ea4 — brand-lock-extractor/SKILL.md:68-68 (list_item)

- **extracted**, read directly from an asset (a hex in the brand book, a font in the CSS, a quote from the site). State it plainly.

Extracted rules inside block: NONE
