# Source coverage review 135/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4227047240cfccb5 — video/references/camera-lighting-vocabulary.md:77-77 (list_item)

- anamorphic 40mm. Cinematic widescreen.

Extracted rules inside block: NONE

## 285acb97831cfacd — video/references/camera-lighting-vocabulary.md:78-78 (list_item)

- shallow depth of field.

Extracted rules inside block: ea320b5350ef

## 48a4f97e52e9d49d — video/references/camera-lighting-vocabulary.md:79-79 (list_item)

- deep focus.

Extracted rules inside block: NONE

## 46202ae06ef40bca — video/references/camera-lighting-vocabulary.md:80-80 (list_item)

- compressed telephoto background.

Extracted rules inside block: NONE

## 70ad2d145d4b0b0d — video/references/camera-lighting-vocabulary.md:81-81 (list_item)

- distorted wide-angle proximity.

Extracted rules inside block: NONE

## 4296439dc0851ecd — video/references/camera-lighting-vocabulary.md:83-83 (heading)

## 4. Light sources

Extracted rules inside block: NONE

## 024a9c40ded39622 — video/references/camera-lighting-vocabulary.md:85-85 (list_item)

- cold refrigerator light

Extracted rules inside block: NONE

## 1aa13e9af226b24e — video/references/camera-lighting-vocabulary.md:86-86 (list_item)

- harsh overhead kitchen LED

Extracted rules inside block: NONE

## 4b290e0a986934e6 — video/references/camera-lighting-vocabulary.md:87-87 (list_item)

- moonlight through window

Extracted rules inside block: NONE

## c7907cb3ead1e4c3 — video/references/camera-lighting-vocabulary.md:88-88 (list_item)

- neon sign spill

Extracted rules inside block: NONE

## db46e394b994bd65 — video/references/camera-lighting-vocabulary.md:89-89 (list_item)

- phone screen glow

Extracted rules inside block: NONE

## 3961c590cd1ce3fd — video/references/camera-lighting-vocabulary.md:90-90 (list_item)

- car headlights

Extracted rules inside block: NONE

## 77d37713ab8d3a0e — video/references/camera-lighting-vocabulary.md:91-91 (list_item)

- streetlamp backlight

Extracted rules inside block: NONE

## 4a14a902d616ea43 — video/references/camera-lighting-vocabulary.md:92-92 (list_item)

- fluorescent office light

Extracted rules inside block: NONE

## d5745ea1c5afce9d — video/references/camera-lighting-vocabulary.md:93-93 (list_item)

- practical lamp

Extracted rules inside block: NONE

## 5e5ef50aa5f6670c — video/references/camera-lighting-vocabulary.md:94-94 (list_item)

- candlelight

Extracted rules inside block: NONE

## 74405b469d89583f — video/references/camera-lighting-vocabulary.md:95-95 (list_item)

- monitor glow

Extracted rules inside block: NONE

## bdabd9e4e9be77f3 — video/references/camera-lighting-vocabulary.md:96-96 (list_item)

- emergency red light

Extracted rules inside block: NONE

## 2a918de2e8ef6d50 — video/references/camera-lighting-vocabulary.md:97-97 (list_item)

- sodium vapor street light

Extracted rules inside block: NONE

## d894ecc196914f30 — video/references/camera-lighting-vocabulary.md:98-98 (list_item)

- police strobe

Extracted rules inside block: NONE

## 0d7e1dad28deaeee — video/references/camera-lighting-vocabulary.md:99-99 (list_item)

- theater house lights

Extracted rules inside block: NONE

## cd5fc860158e13a2 — video/references/camera-lighting-vocabulary.md:100-100 (list_item)

- stage spotlight

Extracted rules inside block: NONE

## 6fd020ff141cbc1f — video/references/camera-lighting-vocabulary.md:101-101 (list_item)

- campfire flicker

Extracted rules inside block: NONE

## 78a94dcfdf952c21 — video/references/camera-lighting-vocabulary.md:102-102 (list_item)

- sunset through blinds

Extracted rules inside block: NONE

## 78c537bfd8b845e3 — video/references/camera-lighting-vocabulary.md:103-103 (list_item)

- under-counter kitchen LED

Extracted rules inside block: NONE

## 05f9b026f100a46a — video/references/camera-lighting-vocabulary.md:105-105 (heading)

## 5. Light direction

Extracted rules inside block: NONE

## dd48413af4b1e6d3 — video/references/camera-lighting-vocabulary.md:107-107 (list_item)

- top light

Extracted rules inside block: NONE

## 72a4d52da8e5c871 — video/references/camera-lighting-vocabulary.md:108-108 (list_item)

- side light

Extracted rules inside block: NONE

## 7eaca29676ef29c6 — video/references/camera-lighting-vocabulary.md:109-109 (list_item)

- backlight

Extracted rules inside block: NONE

## e9dcfdbc02b1b786 — video/references/camera-lighting-vocabulary.md:110-110 (list_item)

- underlight

Extracted rules inside block: NONE
