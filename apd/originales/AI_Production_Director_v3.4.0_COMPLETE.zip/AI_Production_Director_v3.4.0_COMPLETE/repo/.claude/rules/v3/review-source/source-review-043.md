# Source coverage review 43/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c3d3c826c867406f — image/references/golden-rules.md:159-159 (list_item)

2. **Комбинируй с конкретными визуальными деталями** — якорь устанавливает мир, детали устанавливают специфику

Extracted rules inside block: 0ec5aec56e84

## f1c8f50514635613 — image/references/golden-rules.md:160-160 (list_item)

3. **Не стакай несколько genre anchors** — выбери один. "Peter Lindbergh + Wes Anderson" = каша

Extracted rules inside block: 2159d19c0f77

## 9437778692585d6d — image/references/golden-rules.md:161-161 (list_item)

4. **Era/cultural anchors работают лучше с GPT Image 2** (world knowledge). С Nano Banana результат менее предсказуем — NB больше опирается на явные описания

Extracted rules inside block: eff09e56b393

## 0c0aa03e597b1c46 — image/references/golden-rules.md:163-163 (heading)

### Примеры

Extracted rules inside block: NONE

## e1e7f505e327e59e — image/references/golden-rules.md:165-165 (paragraph)

**Era anchor + конкретные детали:**

Extracted rules inside block: NONE

## 55ec5bf5c5f54c22 — image/references/golden-rules.md:166-173 (code)

```
Create an editorial portrait set in Havana, 1957.

Subject: jazz musician leaning against pastel-colored colonial building,
holding trumpet loosely at his side. Linen suit, open collar.
Lighting: harsh Caribbean afternoon sun, deep shadows under awning.
Format: 3:4
```

Extracted rules inside block: NONE

## 84f199c455049b8d — image/references/golden-rules.md:174-174 (list_item)

> "Havana, 1957" вызывает: старые американские машины на заднем плане, облупившаяся штукатурка, кованые балконы, тропическая атмосфера — без необходимости это описывать.

Extracted rules inside block: NONE

## fa2dad5a9535867a — image/references/golden-rules.md:176-176 (paragraph)

**Cultural anchor + новый контекст:**

Extracted rules inside block: NONE

## 26254205a95d592a — image/references/golden-rules.md:177-182 (code)

```
Create a scene of a quiet Kyoto temple garden, rendered in the visual style
of Studio Ghibli. Morning mist over moss-covered stones, a single monk
sweeping fallen maple leaves. Soft watercolor textures, warm nostalgic palette.
Format: 16:9
```

Extracted rules inside block: NONE

## 2d3cf86c291ab300 — image/references/golden-rules.md:183-183 (list_item)

> "Studio Ghibli" задаёт акварельность, теплоту, ностальгию. Детали (мох, клён, монах) задают конкретную сцену.

Extracted rules inside block: NONE

## c9abb5ecc732b292 — image/references/golden-rules.md:185-185 (paragraph)

**Genre anchor + специфика:**

Extracted rules inside block: NONE

## a4466f8ff6e90a8e — image/references/golden-rules.md:186-193 (code)

```
Create a fashion editorial portrait with Peter Lindbergh influence.

Subject: model in oversized men's blazer, no makeup, wind-tousled hair.
Setting: empty winter beach, overcast sky.
Mood: raw, unpolished beauty
Format: 2:3
```

Extracted rules inside block: NONE

## 7c3aef24e6600b43 — image/references/golden-rules.md:194-194 (list_item)

> "Peter Lindbergh influence" даёт: мощный Ч/Б (или desaturated), отсутствие ретуши, raw emotional quality. Детали (пляж, блейзер, ветер) конкретизируют кадр.

Extracted rules inside block: NONE

## 38a8d8bf0872681f — image/references/golden-rules.md:198-198 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 9fcadf91c1882c51 — image/references/gpt-image.md:1-1 (heading)

# GPT Image 2 — Specific Rules

Extracted rules inside block: NONE

## f46e86d074cbc3ab — image/references/gpt-image.md:3-3 (paragraph)

Production default OpenAI: `gpt-image-2`. Migration-only: `gpt-image-1.5`, `gpt-image-1`. Бюджетный: `gpt-image-1-mini`.

Extracted rules inside block: NONE

## 9e2a24d9d06cabf2 — image/references/gpt-image.md:5-5 (heading)

## Структура промпта — 5 slots

Extracted rules inside block: NONE

## 6e4ba65934522c8c — image/references/gpt-image.md:7-7 (paragraph)

GPT Image 2 сильнее всего реагирует на разделение по секциям. Пиши лейблами, не сплошным текстом.

Extracted rules inside block: NONE

## d4e79ea0412219b4 — image/references/gpt-image.md:9-15 (code)

```
Scene: location, time of day, background, environment
Subject: primary focus — who or what is central
Important Details: materials, textures, lighting, camera angle, mood, composition
Use Case: editorial, product mockup, UI, poster, infographic
Constraints: what must NOT change/appear (no watermarks, preserve face, no extra text)
```

Extracted rules inside block: NONE

## 5df3e07e70a31fc8 — image/references/gpt-image.md:17-17 (list_item)

> «The fifth slot is where most mediocre prompts fail silently.» Без явных constraints модель дрейфует.

Extracted rules inside block: NONE

## 30747015c82fb91a — image/references/gpt-image.md:19-19 (heading)

### Минимальный пример

Extracted rules inside block: NONE

## 030bac2d36d2dea5 — image/references/gpt-image.md:21-28 (code)

```
Scene: small Lisbon florist storefront at blue hour, wet cobblestones
Subject: woman in navy apron locking the front door, half-turned to camera
Important Details: warm interior glow spilling onto pavement, 50mm feel,
  soft contact shadows, brushed brass door handle, "Florista" hand-painted sign
Use Case: editorial photography
Constraints: no extra signage, no people in background, no text other than the sign
```

Extracted rules inside block: NONE

## 81dcb556dbb6ccd5 — image/references/gpt-image.md:30-30 (heading)

## Anti-Slop Rules

Extracted rules inside block: NONE

## 0833bd71cce4590a — image/references/gpt-image.md:32-32 (paragraph)

GPT Image 2 особенно чувствителен к качеству формулировок. Vague praise = деградация результата.

Extracted rules inside block: NONE

## cb27ea3b6e450457 — image/references/gpt-image.md:34-34 (table_row)

| ❌ Не пиши | ✅ Пиши |

Extracted rules inside block: 682ff9b8f09d

## 39cdde88c1487eb2 — image/references/gpt-image.md:36-36 (table_row)

| stunning, incredible, epic, gorgeous, masterpiece | overcast daylight, brushed aluminum, chipped paint, 50mm feel |

Extracted rules inside block: NONE

## 38abe6e7d4a75709 — image/references/gpt-image.md:37-37 (table_row)

| «minimalist brutalist luxury photoreal» (стиль-теги) | «cream background, heavy black sans-serif, asymmetrical type block, one hero object, generous negative space» |

Extracted rules inside block: NONE

## f4f551c18bf6f2cf — image/references/gpt-image.md:38-38 (table_row)

| «как в Apple-рекламе» | конкретные визуальные факты |

Extracted rules inside block: NONE

## 4f1bc597c0f356d1 — image/references/gpt-image.md:39-39 (table_row)

| мудовый язык, в котором тонут функциональные требования | прямое заявление: «image must contain a transit kiosk» |

Extracted rules inside block: 6a716fb0fb7c

## 2e5a3c7ac20dbbf1 — image/references/gpt-image.md:41-41 (heading)

## Quality Settings — рычаг fidelity / latency

Extracted rules inside block: NONE
