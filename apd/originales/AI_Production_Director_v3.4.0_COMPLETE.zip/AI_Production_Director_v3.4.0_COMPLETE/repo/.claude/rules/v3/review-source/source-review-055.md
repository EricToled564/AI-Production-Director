# Source coverage review 55/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 625660f85d1023ed — image/references/patterns/character-design.md:88-88 (paragraph)

<!-- Source concept: chibi/super-deformed vinyl collectible figurine with consistent identity across poses -->

Extracted rules inside block: NONE

## 713f472d03a846be — image/references/patterns/character-design.md:90-104 (code)

```
Scene: soft gradient background ({bg_gradient}), studio product lighting with rim light from behind and soft fill from front, subtle ground shadow beneath each figurine
Subject: chibi-style 3D collectible figurine of {character_name} — {character_description_simplified} — large head (roughly 1:2 head-to-body ratio), rounded limbs, smooth matte vinyl surface, {num_poses} poses arranged in a row
Important Details:
  Pose 1: {pose_1_description}
  Pose 2: {pose_2_description}
  Pose 3: {pose_3_description}
  {extra_poses}
  Face retains recognizable features from the original character — {face_markers} — simplified into the chibi style with large round eyes and small nose/mouth
  Outfit matches the original: {outfit_simplified} — colors preserved ({color_palette}), details reduced to clean shapes
  Each figurine sits on a small circular base ({base_color} matte finish)
  Vinyl toy aesthetic — visible seam line at sides, slight glossy highlight on forehead and cheeks
Use Case: merchandise concept, social media avatar set, fan collectible design
Constraints: consistent face and outfit across all poses, chibi proportions must stay uniform (no realistic proportions creeping in), no text on bases, smooth render — not cel-shaded, matte vinyl material throughout
```

Extracted rules inside block: NONE

## eac9627d13efe3f3 — image/references/patterns/character-design.md:106-106 (paragraph)

**Key levers:** `{character_name}`, `{character_description_simplified}` (key outfit and hair only), `{face_markers}` (e.g. round glasses, scar on left cheek, green eyes), `{color_palette}` (hex values for 2-3 dominant colors), `{bg_gradient}` (#F5F0EB to #FFFFFF warm, #E0E8F0 to #FFFFFF cool), `{num_poses}` (3-5), `{pose_N_description}` (e.g. sitting cross-legged reading a book, waving with both hands, holding a coffee cup), `{base_color}` (white, black, matching character's main color)

Extracted rules inside block: NONE

## 408e42b18fe83526 — image/references/patterns/character-design.md:108-108 (paragraph)

**Recommended model:** GPT Image 2 (`quality: medium`) — smooth 3D vinyl surfaces render well at medium; `high` for marketing-ready close-ups

Extracted rules inside block: 6aa23a563673

## d08c0d5e230296a9 — image/references/patterns/character-design.md:110-110 (heading)

### Nano Banana version:

Extracted rules inside block: NONE

## e5a95cdbd338a0fd — image/references/patterns/character-design.md:112-114 (code)

```
A row of {num_poses} chibi-style 3D vinyl collectible figurines of {character_name}, each in a different pose. Large head (1:2 head-to-body ratio), rounded limbs, smooth matte vinyl surface with visible seam lines and subtle glossy highlights on the forehead. Face retains {face_markers} simplified into chibi proportions with large round eyes. Outfit: {outfit_simplified} in {color_palette}. Poses left to right: {pose_1_description}, {pose_2_description}, {pose_3_description}. Each figurine on a small circular {base_color} matte base. Soft gradient background ({bg_gradient}), studio product lighting with rim light from behind and soft fill from front, subtle ground shadow. Format: 16:9.
```

Extracted rules inside block: NONE

## b04091c05dc9cd24 — image/references/patterns/character-design.md:118-118 (heading)

## Anime-Style Character Card

Extracted rules inside block: NONE

## d6bbdc713097ec04 — image/references/patterns/character-design.md:120-120 (paragraph)

Use for a full character reference card with portrait, full body, key items, and color palette — organized on a white background in a professional concept art layout.

Extracted rules inside block: 402eddb3d3df

## e418d9e8d960773a — image/references/patterns/character-design.md:122-122 (paragraph)

<!-- Source concept: anime/game character reference sheet with stats, items, and palette swatches -->

Extracted rules inside block: NONE

## 50c1a8ae18ed42a2 — image/references/patterns/character-design.md:124-136 (code)

```
Scene: white background, organized reference card layout divided into clear sections with thin #CCCCCC separator lines
Subject: {character_name} — {character_description} — anime-style rendering with clean line art and flat cel shading
Important Details:
  Left section (40% width): full-body standing pose, front-facing, arms slightly away from body to show full outfit, feet visible, confident neutral expression
  Upper-right section: portrait bust — head and shoulders, three-quarter angle, detailed face rendering showing {face_details}
  Mid-right section: {num_items} key items arranged in a row — {item_1}, {item_2}, {item_3} — each drawn at consistent scale with thin outline, labeled in small text below
  Lower-right section: color palette — {num_swatches} rectangular swatches in a horizontal strip showing the character's key colors ({swatch_colors}), hex code below each swatch
  Bottom strip: brief stat block or bio text in clean sans-serif — "Name: {character_name} | Class: {class} | Height: {height} | Affiliation: {affiliation}"
  Consistent line weight and shading style across all sections
Use Case: game character documentation, light novel illustration guide, animation production reference
Constraints: unified anime art style across all sections — portrait and full body must be the same character with identical design, items must match what the character wears/carries in the full body view, no decorative borders or ornamental frames, text must be legible at screen resolution
```

Extracted rules inside block: NONE

## 87265777499bc411 — image/references/patterns/character-design.md:138-138 (paragraph)

**Key levers:** `{character_name}`, `{character_description}` (detailed: hair color/style, eye color, outfit layers, accessories), `{face_details}` (distinctive facial features — e.g. heterochromia, facial tattoo, sharp jawline), `{item_1}`/`{item_2}`/`{item_3}` (signature weapon, accessory, artifact), `{swatch_colors}` (e.g. midnight blue #191970, cherry red #C41E3A, silver #C0C0C0, warm skin #E8B89D), `{num_swatches}` (4-6), `{class}` / `{height}` / `{affiliation}` (stat block fields)

Extracted rules inside block: NONE

## 805655526f56efc8 — image/references/patterns/character-design.md:140-140 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout with hex codes, labels, and stat block requires precise rendering

Extracted rules inside block: d0c1944e5b00

## 2c613d464989ed4b — image/references/patterns/character-design.md:142-142 (heading)

### Nano Banana version:

Extracted rules inside block: NONE

## d39814cc9d7139a8 — image/references/patterns/character-design.md:144-146 (code)

```
An anime-style character reference card for {character_name} on a white background. Left side: full-body standing pose, front-facing, clean cel-shaded anime rendering — {character_description}. Upper right: portrait bust at three-quarter angle showing {face_details}. Mid-right: key items laid out in a row — {item_1}, {item_2}, {item_3} — each drawn consistently and labeled. Lower right: horizontal color palette strip with {num_swatches} rectangular swatches ({swatch_colors}). Clean layout with thin gray separator lines between sections. Professional concept art quality, consistent line weight throughout. Format: 3:4.
```

Extracted rules inside block: NONE

## 43ee1d683f01e5bc — image/references/patterns/character-design.md:150-150 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## f7883be1031d38eb — image/references/patterns/ecommerce.md:1-1 (heading)

# E-Commerce Product Photography Patterns

Extracted rules inside block: NONE

## 2420ff18f411a07c — image/references/patterns/ecommerce.md:3-3 (paragraph)

Reusable prompt templates for product ads, packaging, and commercial visuals. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

Extracted rules inside block: NONE

## 98b8f71c10c3cd68 — image/references/patterns/ecommerce.md:7-7 (heading)

## Miniature Diorama Product Ad

Extracted rules inside block: NONE

## e0902cdcf66dbdf7 — image/references/patterns/ecommerce.md:9-9 (paragraph)

Use when you need a playful, attention-grabbing product visual where tiny workers interact with an oversized product — ideal for social media ads and launch campaigns.

Extracted rules inside block: 96013c252397

## 4ddadabbc3fdc579 — image/references/patterns/ecommerce.md:11-11 (paragraph)

<!-- Source concept: miniature/tilt-shift product advertising with construction-worker scale play -->

Extracted rules inside block: NONE

## 439488ecf7978da2 — image/references/patterns/ecommerce.md:13-19 (code)

```
Scene: clean {surface_color} tabletop studio, soft overhead diffused light, shallow depth of field with tilt-shift blur at edges
Subject: oversized {product_name} centered in frame, surrounded by miniature construction workers (1/87 scale figurines) — some climbing the packaging with tiny ladders, others operating a miniature crane to lift the cap/lid, a crew painting the label
Important Details: {product_material} surface catches key light from upper left, visible condensation/texture on product, figurines cast tiny hard shadows, warm {accent_color} hard hats on workers, fine detail on miniature tools, slightly desaturated background, eye-level camera angle
Use Case: social media product ad, Instagram carousel hero
Constraints: no text, no logos other than product label, no floating elements, product must remain recognizable and unaltered, no more than 8 figurines
```

Extracted rules inside block: NONE

## 522d2a27f1fda4a1 — image/references/patterns/ecommerce.md:21-21 (paragraph)

**Key levers:** `{product_name}`, `{product_material}` (frosted glass, matte aluminum, glossy plastic), `{surface_color}` (white marble, raw concrete, light birch wood), `{accent_color}` (safety orange #FF6600, yellow #FFD600)

Extracted rules inside block: NONE

## 4ddece853deadc2c — image/references/patterns/ecommerce.md:23-23 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — precise figurine detail and product label legibility

Extracted rules inside block: 87cb543ee901

## 427e6709b1145721 — image/references/patterns/ecommerce.md:27-27 (heading)

## Luxury Cosmetics Studio Shot

Extracted rules inside block: NONE

## 4de132482e63dae3 — image/references/patterns/ecommerce.md:29-29 (paragraph)

Use for premium beauty or fragrance product photography — dark, moody, tactile surfaces with atmospheric effects.

Extracted rules inside block: 3f5c274f1636

## 1656b6dff20af090 — image/references/patterns/ecommerce.md:31-31 (paragraph)

<!-- Source concept: luxury perfume/cosmetics dark-marble studio photography with condensation and smoke -->

Extracted rules inside block: NONE

## d2b6c2d4485f06a1 — image/references/patterns/ecommerce.md:33-39 (code)

```
Scene: dark studio, {background_surface} surface with subtle reflections, thin layer of low-hanging smoke drifting left to right, {time_mood} ambient
Subject: {product_name} bottle/tube centered, three-quarter angle, {product_finish} catching a single key light from upper right
Important Details: fine water droplets on product surface (condensation, not spray), {accent_material} accent elements flanking the product (raw stone, dried botanicals, metal shavings), volumetric haze behind product, reflection on surface below is soft and dark, color palette restricted to {palette}, contact shadow sharp near base fading to soft
Use Case: luxury brand campaign hero, print ad, website banner
Constraints: no text overlays, no human hands, background stays dark (#0a0a0a to #1a1a1a gradient), no color spill outside the defined palette, no lens flare
```

Extracted rules inside block: NONE

## bc16a73b8c0ee39c — image/references/patterns/ecommerce.md:41-41 (paragraph)

**Key levers:** `{background_surface}` (nero marquina marble, wet obsidian slab, brushed gunmetal), `{product_finish}` (frosted glass, lacquered black, brushed gold), `{accent_material}` (raw quartz crystals, dried lavender stems, black river stones), `{palette}` (golds #C9A84C and blacks, rose #B76E79 and creams, emerald #2D6A4F and silvers), `{time_mood}` (cold blue, warm amber)

Extracted rules inside block: NONE

## 648cfbf310c24b81 — image/references/patterns/ecommerce.md:43-43 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — surface materials and condensation detail

Extracted rules inside block: cae7f3b213d2

## 72eba4c038c0105d — image/references/patterns/ecommerce.md:47-47 (heading)

## 9-Panel TVC Storyboard Grid

Extracted rules inside block: NONE
