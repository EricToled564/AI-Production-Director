# Source coverage review 21/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4ad64b6b79e03343 — brand-lock-extractor/SKILL.md:69-69 (list_item)

- **inferred**, reasoned from evidence but not stated (archetype from positioning, never-list from consistency). Reasonable to ship, worth noting.

Extracted rules inside block: f4e3551ca54e

## 7ee2acba64092597 — brand-lock-extractor/SKILL.md:70-70 (list_item)

- **needs confirmation**, your best estimate where the assets were silent or ambiguous (a color sampled from a JPEG with compression, a font you could not identify). Fill it, then flag it.

Extracted rules inside block: NONE

## af64169980aa89a4 — brand-lock-extractor/SKILL.md:72-72 (heading)

### Step 4. Write the brand-lock

Extracted rules inside block: NONE

## 239af3d5f383ab7a — brand-lock-extractor/SKILL.md:74-74 (paragraph)

Use `templates/brand-lock.md.tpl`. Fill **every** required section, no placeholders left behind. Then append an `## Extraction notes` section that lists every `inferred` and `needs confirmation` value with its source and your reasoning. This section is the audit trail; it does not break validation (the validator checks the nine required sections are present, extra sections are fine).

Extracted rules inside block: e22ec7c92139

## e50227842725c3ac — brand-lock-extractor/SKILL.md:76-76 (paragraph)

Set the footer: `Last updated` to today, `Owner` to the user or "extracted", `Version: 1.0`.

Extracted rules inside block: NONE

## bec0346c3ded705d — brand-lock-extractor/SKILL.md:78-78 (heading)

### Step 5. Self-check, then hand off

Extracted rules inside block: NONE

## 09dc4534df0d9ab6 — brand-lock-extractor/SKILL.md:80-80 (paragraph)

Before you present it, confirm the file would pass validation:

Extracted rules inside block: NONE

## 2e83fd1542abedfa — brand-lock-extractor/SKILL.md:82-82 (list_item)

- All nine required sections present: Identity, Palette, Typography, Mood adjectives, Never list, Aspect ratios, Color grade direction, Motion language, Voice rules.

Extracted rules inside block: 0e8edd11509b

## c7f7a9d157d623cb — brand-lock-extractor/SKILL.md:83-83 (list_item)

- Identity contains all four fields: Brand, One-line description, Archetype, Voice posture.

Extracted rules inside block: NONE

## 1f096e015c03b689 — brand-lock-extractor/SKILL.md:84-84 (list_item)

- Palette has at least one real `#RRGGBB` hex (not a placeholder).

Extracted rules inside block: NONE

## 7b6fc2e4bca9cc56 — brand-lock-extractor/SKILL.md:86-86 (paragraph)

Then hand off:

Extracted rules inside block: NONE

## b0f515502af6678a — brand-lock-extractor/SKILL.md:88-88 (list_item)

> "Here is your brand-lock. I sampled the palette and type from your assets and flagged N values that need your eyes (see Extraction notes). Drop it in `brand-packs/`, confirm the flagged values, and run `python tools/validate_brand_lock.py path/to/file.md` to verify. Then: `'30-second explainer. Use brand-packs/your-brand.md as the brand lock.'`"

Extracted rules inside block: 5fd02bdf692d

## 047db907fa4525db — brand-lock-extractor/SKILL.md:90-90 (heading)

## Hard rules

Extracted rules inside block: NONE

## 4bcdd9b4f545dbe9 — brand-lock-extractor/SKILL.md:92-92 (heading)

### Rule 1. Never invent a hex value

Extracted rules inside block: NONE

## f7c136a183ca38c4 — brand-lock-extractor/SKILL.md:94-94 (paragraph)

Colors are sampled, never guessed. Read them from a brand book, from CSS, or by sampling pixels in a screenshot. If you genuinely cannot determine a color, fill your closest estimate and mark it `needs confirmation` in Extraction notes. "Navy" is not a palette entry. `#0F1F3A` is. A wrong hex stated confidently corrupts every downstream prompt.

Extracted rules inside block: 8d59454c87ee

## 6291babd4f54014a — brand-lock-extractor/SKILL.md:96-96 (heading)

### Rule 2. Never fabricate a typeface

Extracted rules inside block: NONE

## e50040babd3e028c — brand-lock-extractor/SKILL.md:98-98 (paragraph)

Identify fonts from the brand book, the site's CSS/font files, or clear visual match. If you cannot identify one, say so and flag it, do not name a plausible-sounding font you did not verify.

Extracted rules inside block: d6d1b7da8559

## b26214f14b75215d — brand-lock-extractor/SKILL.md:100-100 (heading)

### Rule 3. Source everything

Extracted rules inside block: NONE

## 58e26f7e213b44c3 — brand-lock-extractor/SKILL.md:102-102 (paragraph)

Every extracted value traces to an asset. Every inferred value traces to reasoning. This is the same audit-trail discipline as the brand-lock snapshot, applied at extraction time.

Extracted rules inside block: NONE

## 246ecfc0be1bf659 — brand-lock-extractor/SKILL.md:104-104 (heading)

### Rule 4. The never-list is the highest-value section

Extracted rules inside block: NONE

## 2fabccca24e64e8b — brand-lock-extractor/SKILL.md:106-106 (paragraph)

It is also the hardest to extract, because brands document what they do, not what they avoid. Infer it from consistency: if every image avoids stock-photo gloss, that is a never. If copy never uses exclamation points, that is a never. Read `references/extraction-rubric.md` for the method. Do not ship an empty never-list.

Extracted rules inside block: 1cd7266731ef

## d85f355bcc53043f — brand-lock-extractor/SKILL.md:108-108 (heading)

### Rule 5. Mood adjectives must be specific

Extracted rules inside block: NONE

## 468b3536e1fca80a — brand-lock-extractor/SKILL.md:110-110 (paragraph)

"Professional, modern, clean" describes every brand and constrains nothing. Extract contrast clauses that do work: "operator not creator", "warm not precious", "confident without volume". If the assets only support generic adjectives, that is a `needs confirmation` flag, not a license to ship filler.

Extracted rules inside block: NONE

## fa37399212cfc54a — brand-lock-extractor/SKILL.md:112-112 (heading)

### Rule 6. No emojis, no hype

Extracted rules inside block: NONE

## 0a0d96a6d864bc40 — brand-lock-extractor/SKILL.md:114-114 (paragraph)

The output is a clinical specification. It models the standards the brand-lock enforces. No emojis anywhere. No marketing adjectives about the brand in your own voice, report what the assets show.

Extracted rules inside block: NONE

## ac42624c93896ecb — brand-lock-extractor/SKILL.md:116-116 (heading)

## Reference

Extracted rules inside block: NONE

## 24bb46599a57df93 — brand-lock-extractor/SKILL.md:118-118 (list_item)

- `references/extraction-rubric.md`, section-by-section extraction method and confidence definitions.

Extracted rules inside block: NONE

## fa9da9b18f5a56aa — brand-lock-extractor/SKILL.md:120-120 (heading)

## Example

Extracted rules inside block: NONE

## f8d682e50f0c0939 — brand-lock-extractor/SKILL.md:122-122 (paragraph)

`examples/` contains a worked extraction: the source material provided (`input-brief.md`) and the `brand-lock.md` produced from it, including the Extraction notes audit trail. Use it to calibrate the level of specificity and the confidence flagging.

Extracted rules inside block: ff7824966969

## 21f9895cb1b58df7 — brand-lock-extractor/brand-packs/README.md:1-1 (heading)

# Brand Packs

Extracted rules inside block: NONE
