# Source coverage review 3/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 96dec01802ec18cc — ai-production-director/SKILL.md:91-91 (list_item)

- Desde aquí, **shots.json es la fuente de verdad**. Ningún prompt, imagen o revisión existe sin shot ID.

Extracted rules inside block: NONE

## e9141274eee9e7ca — ai-production-director/SKILL.md:93-93 (heading)

### Etapa 5 — Anchor Images

Extracted rules inside block: NONE

## ddb7abf27dd46527 — ai-production-director/SKILL.md:94-94 (list_item)

- **Skills:** `visual-prompt-forge` genera los borradores desde shots.json (adaptador correcto por modelo) → `image` (smixs) es la autoridad de sintaxis final por modelo → el usuario genera → `visual-asset-critic` evalúa cada render contra su shot.

Extracted rules inside block: NONE

## 9b7ccd9dc3d4b663 — ai-production-director/SKILL.md:95-95 (list_item)

- **Salida:** plan de anchors (character refs, environment refs, keyframes por shot clave), prompts finales, y critiques por ronda.

Extracted rules inside block: NONE

## b0f38fbd759facce — ai-production-director/SKILL.md:96-96 (list_item)

- **Gate:** cada anchor crítico tiene critique ACCEPT, con máximo 2 rondas de revisión vía forge en modo revisión (solo shots reprobados). A la tercera falla, se replantea el shot, no el prompt.

Extracted rules inside block: NONE

## f23aad18f0f7b00b — ai-production-director/SKILL.md:98-98 (heading)

### Etapa 6 — Video Prompts

Extracted rules inside block: NONE

## 95b752a02ecc19e0 — ai-production-director/SKILL.md:99-99 (list_item)

- **Skills:** `visual-prompt-forge` estructura el prompt de movimiento desde shots.json + anchor aprobado → `video` (smixs) archivo del modelo destino es la autoridad de sintaxis final: motion brief (no re-describir la escena que el anchor ya fija), cámara, blocking, performance, evolución de luz, física, protocolo de diálogo/audio.

Extracted rules inside block: NONE

## 001449256ce6ab7a — ai-production-director/SKILL.md:100-100 (list_item)

- **Salida:** prompts de video finales por shot, con continuity blocks entre clips.

Extracted rules inside block: NONE

## 44eabb0b61a7ea61 — ai-production-director/SKILL.md:101-101 (list_item)

- **Gate obligatorio:** los dos checks de `video` (dramaturgy check de 6 puntos + auditoría de 3 detalles) Y, si `aurora-prompt-linter` está instalada, el linter pasa limpio. Un prompt que falla cualquiera de los dos NO se entrega.

Extracted rules inside block: 0367132dbb79

## fe6f4508c80b6b32 — ai-production-director/SKILL.md:103-103 (heading)

### Etapa 7 — Package & Delivery

Extracted rules inside block: NONE

## 7cbaea405aebbed9 — ai-production-director/SKILL.md:104-104 (list_item)

- **Skill:** `storyboard-html-preview` para el preview de cliente + `references/production-package.md` de este skill para el ensamblado.

Extracted rules inside block: NONE

## b15102eaa93c96ce — ai-production-director/SKILL.md:105-105 (list_item)

- **Salida:** Final AI Video Production Package (spec completa en la referencia) + checklist de postproducción.

Extracted rules inside block: NONE

## 0d40033b2a2388ea — ai-production-director/SKILL.md:106-106 (list_item)

- **Gate:** checklist maestro de la referencia completo; trazabilidad verificada (muestreo: 3 prompts al azar trazan hasta su concepto).

Extracted rules inside block: NONE

## 7cc0fed499bd66a7 — ai-production-director/SKILL.md:108-108 (heading)

## 4. Interacción con el usuario entre etapas

Extracted rules inside block: NONE

## e2c6b5fbe2c8de09 — ai-production-director/SKILL.md:110-110 (list_item)

- Al cerrar cada gate, entrega el artefacto de la etapa y anuncia la siguiente en una línea. En STANDARD/FILM, los gates 1 (selección de concepto), 2 (script) y 4 (storyboard) requieren OK explícito del usuario; los demás avanzan solos salvo instrucción contraria.

Extracted rules inside block: NONE

## ca7c4c2c0ba4f9c4 — ai-production-director/SKILL.md:111-111 (list_item)

- En EXPRESS, solo el shot list requiere OK antes de escribir prompts.

Extracted rules inside block: NONE

## 730864c3dad8853c — ai-production-director/SKILL.md:112-112 (list_item)

- Nunca preguntes lo que el brief o los artefactos previos ya responden.

Extracted rules inside block: 45917b38bd15

## 8d6ef8d2c5d9df9c — ai-production-director/SKILL.md:114-114 (heading)

## 5. Ejecución por etapa — regla de carga

Extracted rules inside block: NONE

## 85f88b9be8945a01 — ai-production-director/SKILL.md:116-116 (paragraph)

En claude.ai las sub-skills están instaladas por separado. Al entrar a una etapa: (1) nombra la sub-skill que vas a usar, (2) lee su SKILL.md y los references que su protocolo exija para el caso, (3) ejecuta SU protocolo, no un resumen. La calidad del pipeline es la calidad de la sub-skill peor ejecutada.

Extracted rules inside block: NONE

## 417a06851c3481f2 — ai-production-director/SKILL.md:118-118 (heading)

## 6. Reglas de resolución de conflictos

Extracted rules inside block: NONE

## e6c5cd0c59ee426a — ai-production-director/SKILL.md:120-120 (paragraph)

Estas reglas son decisiones tomadas. Aplícalas sin reabrir el debate en medio de un proyecto.

Extracted rules inside block: NONE

## 5fd8b5de292ba0ac — ai-production-director/SKILL.md:122-122 (heading)

### 6.1 Vocabulario

Extracted rules inside block: NONE

## 61a8b568838bda76 — ai-production-director/SKILL.md:123-123 (paragraph)

El vocabulario prohibido de `video`/dramaturgy (+ `aurora-prompt-linter` si está) **gana siempre**: "cinematic", "epic", "stunning", "masterpiece", "beautiful lighting", "professional", "high quality", emociones nombradas sin cuerpo. Esto **anula explícitamente** la regla de `ai-video-storyboard` de cerrar cada prompt con "cinematic 1080p, synchronized audio". En su lugar: la resolución, aspect ratio, duración y si el modelo genera audio se especifican como parámetros técnicos concretos según el archivo del modelo destino.

Extracted rules inside block: 77b7f55707a0

## eeeddeb9525c15ef — ai-production-director/SKILL.md:125-125 (heading)

### 6.2 Sintaxis de modelo

Extracted rules inside block: NONE

## 33a3842aa3d46628 — ai-production-director/SKILL.md:126-126 (paragraph)

`ai-video-storyboard` pide prompts model-agnostic; `video`/`image` (smixs) existen para sintaxis por modelo. Resolución: model-agnostic SOLO en artefactos intermedios (storyboard, shot cards). Todo prompt FINAL se escribe en la sintaxis del modelo destino según el archivo smixs correspondiente. Si el modelo no tiene archivo smixs (p.ej. Flux, Midjourney, Ideogram), la autoridad es el adaptador de `visual-prompt-forge`.

Extracted rules inside block: NONE

## 2ca0a2c6f6e4623b — ai-production-director/SKILL.md:128-128 (heading)

### 6.3 Fuente de verdad estructural

Extracted rules inside block: NONE

## a52ad9c07b214055 — ai-production-director/SKILL.md:129-129 (paragraph)

De la Etapa 4 en adelante: `shots.json`. Un cambio creativo se hace primero en shots.json y se propaga hacia abajo; nunca se parcha un prompt de forma que contradiga su shot.

Extracted rules inside block: c378595cfd38

## fc3a5f64e14ff4ba — ai-production-director/SKILL.md:131-131 (heading)

### 6.4 División forge ↔ smixs

Extracted rules inside block: NONE

## 2295bd43594f0c18 — ai-production-director/SKILL.md:132-132 (paragraph)

`visual-prompt-forge` es dueño del **flujo de datos** (shots.json → borrador, critique.json → revisión selectiva). `video`/`image` smixs son dueños del **texto final** del prompt. El borrador del forge se reescribe a sintaxis smixs; nunca al revés.

Extracted rules inside block: faad91016c5d

## 297683809961d2b2 — ai-production-director/SKILL.md:134-134 (heading)

### 6.5 Atribución

Extracted rules inside block: NONE
