# Source coverage review 41/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## e1f19861e5b51bc9 — image/references/golden-rules.md:32-32 (table_row)

| Element | Vague | Specific |

Extracted rules inside block: NONE

## ffda5cd4f820afe9 — image/references/golden-rules.md:34-34 (table_row)

| Subject | "a woman" | "sophisticated elderly woman in vintage Chanel-style suit" |

Extracted rules inside block: NONE

## b37bce9f37b8e903 — image/references/golden-rules.md:35-35 (table_row)

| Material | "shiny" | "brushed steel with matte finish" |

Extracted rules inside block: NONE

## 21de882880e126f2 — image/references/golden-rules.md:36-36 (table_row)

| Color | "dark green" | "#0d3d2d deep emerald" |

Extracted rules inside block: NONE

## da2459fca53e0739 — image/references/golden-rules.md:37-37 (table_row)

| Position | "on the right" | "right third, bleeding off edge" |

Extracted rules inside block: NONE

## ba4eae4be8f012d0 — image/references/golden-rules.md:39-39 (heading)

## 6. Provide Context

Extracted rules inside block: NONE

## b714bfd1c52a2d48 — image/references/golden-rules.md:41-41 (paragraph)

Context helps model make logical decisions:

Extracted rules inside block: NONE

## 7e7f25322c603dbd — image/references/golden-rules.md:42-42 (list_item)

- "for Brazilian gourmet cookbook" → infers professional plating, shallow DOF

Extracted rules inside block: ac9a2964acf8

## 67799a83aa6cb43f — image/references/golden-rules.md:43-43 (list_item)

- "for executive strategy presentation" → infers corporate aesthetic

Extracted rules inside block: NONE

## e075e805665d8633 — image/references/golden-rules.md:44-44 (list_item)

- "for children's educational app" → infers friendly, colorful style

Extracted rules inside block: NONE

## 04d64776d1611a84 — image/references/golden-rules.md:46-46 (heading)

## 7. Quote Text Exactly

Extracted rules inside block: NONE

## 1a33f950e02445d0 — image/references/golden-rules.md:48-48 (paragraph)

Any text for rendering goes in quotes:

Extracted rules inside block: NONE

## b0e0d09a34a77ac6 — image/references/golden-rules.md:49-49 (list_item)

- "[HEADLINE TEXT]"

Extracted rules inside block: NONE

## 37fe49bf10635cc4 — image/references/golden-rules.md:50-50 (list_item)

- Labels: "[Revenue Growth]", "[Net Income]"

Extracted rules inside block: NONE

## 84a5aabd98d2e3af — image/references/golden-rules.md:51-51 (list_item)

- Specify weight: bold, thin, extra bold

Extracted rules inside block: NONE

## a8ff9d864050ad21 — image/references/golden-rules.md:52-52 (list_item)

- Specify position: "upper third", "centered"

Extracted rules inside block: NONE

## 1321b724cd1d71ae — image/references/golden-rules.md:54-54 (heading)

## Prompt Template

Extracted rules inside block: NONE

## 86c414363130837c — image/references/golden-rules.md:56-72 (code)

```
Create a [TYPE] for [CONTEXT].

Background: [Description with hex colors]. [Atmospheric effects].

[HERO ELEMENT]:
[Detailed description - position, lighting, angle]

Typography:
Line 1: "[TEXT]" in [weight], [color], [size], [position]
Line 2: "[TEXT]" in [weight], [color], [size], [position]

[ADDITIONAL ELEMENTS]

Mood: [Emotional descriptor]
Format: [ASPECT RATIO]
```

Extracted rules inside block: NONE

## 5fd7f1fee1973d6c — image/references/golden-rules.md:74-74 (list_item)

> **Thinking Mode** (NB only), **`quality: low/medium/high`** (GPT Image 2 only) — см. соответствующие references.

Extracted rules inside block: NONE

## b1b1bc57fb1d462a — image/references/golden-rules.md:76-76 (heading)

## Cost Optimization (Batch Work)

Extracted rules inside block: NONE

## 6c17fc035e7eceb2 — image/references/golden-rules.md:78-78 (list_item)

- **Nano Banana:** прогон вариантов на `0.5K` Flash → отбор → переген победителя на `2K`/`4K`.

Extracted rules inside block: NONE

## 98a407b87c6366d2 — image/references/golden-rules.md:79-79 (list_item)

- **GPT Image 2:** прогон на `quality: low` → отбор → переген на `medium` или `high`.

Extracted rules inside block: NONE

## d93225be5f7aec02 — image/references/golden-rules.md:81-81 (paragraph)

В обоих случаях: дешёвая разведка → дорогой финал.

Extracted rules inside block: NONE

## 03b83939ff145b98 — image/references/golden-rules.md:83-83 (heading)

## Conversational Refinement

Extracted rules inside block: NONE

## e88802656ff08a10 — image/references/golden-rules.md:85-85 (paragraph)

After generation:

Extracted rules inside block: NONE

## 766aa453c538f765 — image/references/golden-rules.md:86-86 (list_item)

- "Change the headline color to #3b82f6"

Extracted rules inside block: NONE

## 4281ba4ff75eadec — image/references/golden-rules.md:87-87 (list_item)

- "Add subtle drop shadow to text"

Extracted rules inside block: NONE

## 66aa947d66cf863a — image/references/golden-rules.md:88-88 (list_item)

- "Increase contrast, make it more dramatic"

Extracted rules inside block: NONE

## 26f3f0cac93fdb8c — image/references/golden-rules.md:89-89 (list_item)

- "Soften the background, add blur"

Extracted rules inside block: NONE

## 94554c6e967c2e32 — image/references/golden-rules.md:91-91 (heading)

## Reference Images

Extracted rules inside block: NONE
