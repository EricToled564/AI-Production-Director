# Source coverage review 146/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 775aa3c0351fb17e — video/references/dramaturgy.md:322-322 (list_item)

- Shot 07. Detail. Phone screen close-up.

Extracted rules inside block: NONE

## c800344836a53dec — video/references/dramaturgy.md:323-323 (list_item)

- Shot 09. Reaction. His face, jaw tightening.

Extracted rules inside block: NONE

## c61953927b5aeb1b — video/references/dramaturgy.md:324-324 (list_item)

- Shot 11. Shift. Hand hesitates over keyboard.

Extracted rules inside block: NONE

## f61cc7f32df23bed — video/references/dramaturgy.md:325-325 (list_item)

- Shot 13. Impact. Thumb taps Delete.

Extracted rules inside block: NONE

## fb193cc573fbb7cf — video/references/dramaturgy.md:326-326 (list_item)

- Shot 14. Aftermath. Dark screen, his ghosted reflection.

Extracted rules inside block: NONE

## 30012bd0e856ed67 — video/references/dramaturgy.md:328-328 (heading)

### Layer 3. Rhythm (final 10 seconds)

Extracted rules inside block: NONE

## 7ff1c296357814b2 — video/references/dramaturgy.md:330-330 (list_item)

- 2s. Finger hovers over Delete.

Extracted rules inside block: NONE

## 5f232a26e9381f08 — video/references/dramaturgy.md:331-331 (list_item)

- 1s. His face.

Extracted rules inside block: NONE

## 3b00dddb8447b3fa — video/references/dramaturgy.md:332-332 (list_item)

- 0.5s. Thumb.

Extracted rules inside block: NONE

## dd2a80bc8e520152 — video/references/dramaturgy.md:333-333 (list_item)

- 0.5s. Screen confirmation prompt.

Extracted rules inside block: NONE

## 8a8d94d097fb439b — video/references/dramaturgy.md:334-334 (list_item)

- 1s. His eyes.

Extracted rules inside block: NONE

## 8e65e8582128b5a0 — video/references/dramaturgy.md:335-335 (list_item)

- 0.5s. Thumb taps Delete.

Extracted rules inside block: NONE

## 26a68d8644178471 — video/references/dramaturgy.md:336-336 (list_item)

- 3s silence. Screen goes black.

Extracted rules inside block: NONE

## 7ed71c666b33df08 — video/references/dramaturgy.md:337-337 (list_item)

- 1.5s. His reflection on the dark phone.

Extracted rules inside block: NONE

## 52338b40fc0fc285 — video/references/dramaturgy.md:339-339 (paragraph)

Now each beat can be translated into a model-specific prompt using `references/seedance.md`, `references/kling.md`, or `references/veo.md`.

Extracted rules inside block: NONE

## 1fbeb712d5502120 — video/references/dramaturgy.md:343-343 (heading)

## 15. Dramaturgy check before sending any prompt

Extracted rules inside block: NONE

## 135529fe31ae588b — video/references/dramaturgy.md:345-345 (paragraph)

Run this six-point check before returning the final prompt to the user.

Extracted rules inside block: NONE

## d256cbd2053ce99f — video/references/dramaturgy.md:347-347 (list_item)

1. Is the scene formula complete? (desire + obstacle + geometry + gaze + rhythm)

Extracted rules inside block: e2f96ea6fe63

## 8e49e4569162394a — video/references/dramaturgy.md:348-348 (list_item)

2. Does every shot pass the three-detail check? (environmental pressure + physical micro-action + sound or visual motif)

Extracted rules inside block: 45ba5dca7617

## f640e0bf1c95950e — video/references/dramaturgy.md:349-349 (list_item)

3. Does every shot do one of the three jobs? (change emotion, advance action, increase pressure)

Extracted rules inside block: 7cfc96d05146

## 6c0b9e0b6609b88a — video/references/dramaturgy.md:350-350 (list_item)

4. Is there a motivated reason for every camera move?

Extracted rules inside block: 50d0094b8e4a

## b7cf0405d4f85a59 — video/references/dramaturgy.md:351-351 (list_item)

5. Is the spatial geometry readable?

Extracted rules inside block: 6b4d7dfd7fe4

## 5036636d945f27e0 — video/references/dramaturgy.md:352-352 (list_item)

6. Are the five anchors named? (emotion, motif, object, break, final image)

Extracted rules inside block: 85306c8ed949

## 90bdee60fb3a5924 — video/references/dramaturgy.md:354-354 (paragraph)

If any answer is no, fix before sending. Step 2 is the most violated.

Extracted rules inside block: NONE

## c0d7a6c613840085 — video/references/dramaturgy.md:358-358 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## dcae497fe11964ed — video/references/fixes-and-skeletons.md:1-1 (heading)

# Fixes, checklist, and cross-model skeletons

Extracted rules inside block: NONE

## 76cb4b832a3ca353 — video/references/fixes-and-skeletons.md:3-3 (heading)

## Contents

Extracted rules inside block: NONE

## a06bb5479ec66882 — video/references/fixes-and-skeletons.md:5-5 (list_item)

1. Continuity checklist (before final output)

Extracted rules inside block: d618a42f7025

## 8f536e7ab5a05e13 — video/references/fixes-and-skeletons.md:6-6 (list_item)

2. Common failures and fixes

Extracted rules inside block: b405dbdb707f

## 030c8d6224b34f4e — video/references/fixes-and-skeletons.md:7-7 (list_item)

3. Cross-model prompt skeletons

Extracted rules inside block: 8ccd220bd5b3
