# Source coverage review 80/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## b097596caffc06f1 — produccion-visual-sw30/SKILL.md:96-96 (list_item)

- El cambio se propaga solo a todos los briefs que usan ese bloque.

Extracted rules inside block: NONE

## b5d49829713e190e — produccion-visual-sw30/SKILL.md:97-98 (list_item)

- **PROHIBIDO editar el texto de un brief individual.** Eso es parchar: arregla una cosa y rompe otra,
  y es la causa raíz de los ciclos de tres reescrituras.

Extracted rules inside block: 3166a8f4f0a8

## cd63226c46e0a6ae — produccion-visual-sw30/SKILL.md:100-100 (heading)

### Verificación mecánica (no depende de criterio)

Extracted rules inside block: NONE

## 2f9f66e971d38694 — produccion-visual-sw30/SKILL.md:101-103 (list_item)

- `audit_gi2.py` valida 15 columnas: slots · anti-slop · ratio estándar · metadatos fuera del prompt ·
  Notes · cámara con los 5 efectos ópticos (compresión, bokeh/wash, viñeta, halación, grano) · mood ·
  color · identity-lock · texto de marca · framing positivo · mirada · manos.

Extracted rules inside block: NONE

## c6496c99c9450d9d — produccion-visual-sw30/SKILL.md:104-104 (list_item)

- El lint del builder ROMPE la compilación ante cualquier desviación de plantilla.

Extracted rules inside block: NONE

## 349ccda83b991665 — produccion-visual-sw30/SKILL.md:106-106 (heading)

## MICRO-GATE (obligatorio en los dos puntos de no retorno)

Extracted rules inside block: NONE

## 10979149c38c7e9a — produccion-visual-sw30/SKILL.md:107-113 (paragraph)

Antes de (a) cualquier generación que gaste créditos y (b) entregar cualquier prompt visual,
la respuesta abre con exactamente 3 líneas:
  SKILL: <archivo y sección leídos EN ESTE turno>
  RIESGOS: <qué puede fallar y qué línea del prompt lo mitiga>
  TÉCNICA: <técnica probada encontrada y fuente, o "no encontrada">
Entrega sin cabecera = inválida; Eric la rechaza sin leerla. Generación sin preflight de
costo = prohibida.

Extracted rules inside block: NONE

## 7a040dbbed2047f1 — produccion-visual-sw30/SKILL.md:115-115 (heading)

## REGLAS CRÍTICAS

Extracted rules inside block: NONE

## 5e1124b19b9ee6e0 — produccion-visual-sw30/SKILL.md:116-117 (list_item)

1. Un solo trabajo por generación. Con dos personajes: un sujeto por generación, o técnica
   de colocación probada; nunca "a ver si sale".

Extracted rules inside block: 0e349eb3d601

## 861f123fa8cb9b9a — produccion-visual-sw30/SKILL.md:118-119 (list_item)

2. Posición SIEMPRE por ancla legible de la propia imagen (letterforms del mundo: "his back
   level with the letter L of WORLD"). Prohibido "left half", "centre", "just left of X".

Extracted rules inside block: c141b7d36f7f

## f875366c74d5696b — produccion-visual-sw30/SKILL.md:120-121 (list_item)

3. El editor no tiene memoria: solo verbos operativos (Move/Replace/Add/Remove/Swap), cero
   narrativa ("has become", "again").

Extracted rules inside block: 22a58fe6bad7

## 5442a92f44875025 — produccion-visual-sw30/SKILL.md:122-122 (list_item)

4. Autocontención: toda comparación ("same X") exige ambos referentes adjuntos en ESE prompt.

Extracted rules inside block: 49df7a8c190f

## 045194b311de6837 — produccion-visual-sw30/SKILL.md:123-124 (list_item)

5. Herencia mínima: "same face and clothes" + solo los deltas. Cero re-descripción de lo que
   la referencia ya muestra.

Extracted rules inside block: 9795f4039ac2

## 12b5306b897b1aa4 — produccion-visual-sw30/SKILL.md:125-126 (list_item)

6. Swap de identidad = última operación, sola: "Replace X with Y — same position, same pose,
   same scale".

Extracted rules inside block: 28fa75d7e21f

## c38a45c8714c5806 — produccion-visual-sw30/SKILL.md:127-128 (list_item)

7. Mundos por dos pasos: placa vacía primero; insert con "use only the person from image N,
   ignore its setting" + "keep the world of image 1 untouched".

Extracted rules inside block: 1b509854dab2

## 2afe4b7e45ab4c58 — produccion-visual-sw30/SKILL.md:129-129 (list_item)

8. Stills en instante congelado ("frozen mid-stride"); nada de movimiento en imagen fija.

Extracted rules inside block: 765066b04741

## 7e5ed2d418b254ee — produccion-visual-sw30/SKILL.md:130-131 (list_item)

9. Contactos entre personas: "a natural high five" — la anatomía la fija el keyframe
   aprobado, nunca la asignación de manos por texto.

Extracted rules inside block: 3d87c28794d7

## ea8424551ff7964e — produccion-visual-sw30/SKILL.md:132-133 (list_item)

10. Logos solo heredados de asset aprobado o descripción canónica del brand-lock; los
    cuerpos nunca tapan logo ni lettering en frames congelados.

Extracted rules inside block: 1f65681e2725

## 6a23e7d6ae06a5a3 — produccion-visual-sw30/SKILL.md:134-134 (list_item)

11. Lo aprobado se canoniza con hash y se EDITA desde ahí; lo caro nunca se regenera.

Extracted rules inside block: 31f5b0456b3a

## 8eaa8dfcaecfe83b — produccion-visual-sw30/SKILL.md:135-136 (list_item)

12. "Edit, don't re-roll": resultado ≥80% correcto → cambio puntual (hasta 3 ediciones
    apiladas), nunca re-tirar.

Extracted rules inside block: 0da4ba63e69d

## 1600cd1c3f6e9f28 — produccion-visual-sw30/SKILL.md:137-138 (list_item)

13. Máximo 2 intentos por método. A la 2ª falla: cambio de método con causa declarada, o
    alto y consulta. Nunca tercera vuelta de lo mismo.

Extracted rules inside block: 71e73c3bfcd2

## 1fb14df253368dad — produccion-visual-sw30/SKILL.md:139-141 (list_item)

14. Validadores del paquete y techos de palabras en verde antes de entregar; inspección
    visual propia (zooms 100% de rostros y manos) antes de presentar. Si algo falla: no se
    entrega, se repite — y se dice qué falló en una línea.

Extracted rules inside block: d5fd08bdb869

## bfe3d8fa8801f3d6 — produccion-visual-sw30/SKILL.md:142-142 (list_item)

15. shots.json es la fuente de verdad: todo cambio entra ahí primero y se propaga.

Extracted rules inside block: 1f9a9b8de3ca

## b3504816faa8b63a — produccion-visual-sw30/SKILL.md:143-144 (list_item)

16. Clips: solo Preserve-cues, roles de start/tail ("The tail image defines X — inherit
    exactly"), movimiento puro, imagen final nombrada; negativos sin "no X", ≤8 ítems.

Extracted rules inside block: 084f0c4f151a

## 97199ab5e0fe6e59 — produccion-visual-sw30/SKILL.md:145-146 (list_item)

17. Entregas en unidades chicas con OK de dirección; se entrega el delta, no el paquete.
    Una regla nueva de dirección se aplica a TODOS los prompts, no a la mitad.

Extracted rules inside block: f52348820e6f

## 2e2679e7d5a44f2f — produccion-visual-sw30/SKILL.md:147-148 (list_item)

18. Respuestas: el dato o entregable en la primera línea. Cero adulación y cero evaluación
    de las acciones de Eric salvo que la pida. Error = una línea de corrección, sin disculpas.

Extracted rules inside block: 16c17b8e1acd

## 45eecc3151ebc12d — produccion-visual-sw30/SKILL.md:149-150 (list_item)

19. Prohibido afirmar capacidades, límites o hechos de plataforma sin verificarlos en este
    turno (leer la fuente o buscar); lo no verificado se etiqueta como inferencia.

Extracted rules inside block: 408bd188d7f5

## 26c5e6b9eaf96521 — produccion-visual-sw30/SKILL.md:151-152 (list_item)

20. /research solo para problemas genuinamente nuevos; /briefing solo al retomar tras días
    fuera; /handoff al cerrar sesión. Ninguno por default.

Extracted rules inside block: 76c1dbf51899

## ce22b20c821b6dbf — screenwriter/SKILL.md:2-4 (paragraph)

name: screenwriter
description: >
  Transform creative ideas into professional, production-ready screenplays optimized for AI video generation pipelines. Converts raw concepts into structured scene-by-scene narratives with rich visual descriptions, proper screenplay formatting, and XML-tagged output for seamless integration with image/video generation tools (imagine, arch-v).

Extracted rules inside block: NONE

## 25a46d899e458f62 — screenwriter/SKILL.md:6-6 (paragraph)

  USE WHEN: Converting story ideas into screenplay format, preparing content for AI video pipelines, structuring narratives for 5-10 minute short films, generating visual-rich scene descriptions for image generation. Use this even when the user doesn't say "screenplay" explicitly — e.g. "break this idea into scenes" or "write the script for this short film."

Extracted rules inside block: NONE
