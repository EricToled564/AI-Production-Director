# Source coverage review 105/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 905d760b72f50c38 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:24-24 (heading)

## Typography

Extracted rules inside block: NONE

## d491a711308c7cf4 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:26-28 (paragraph)

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

Extracted rules inside block: NONE

## aa22b3d6643d5a7b — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:30-30 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## 46e1b95dbfc3421e — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:32-32 (list_item)

- operator (not creator)

Extracted rules inside block: NONE

## d8f5e539d0909061 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:33-33 (list_item)

- considered (not reactive)

Extracted rules inside block: NONE

## bf863b3a97666f68 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:34-34 (list_item)

- deterministic (not vibes-based)

Extracted rules inside block: NONE

## ee3b463e96f1d3b4 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:35-35 (list_item)

- confident (without volume)

Extracted rules inside block: NONE

## d7f926045db19f6f — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:36-36 (list_item)

- defense-grade (not fragile)

Extracted rules inside block: NONE

## f6b0175582448796 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:38-38 (heading)

## Never list

Extracted rules inside block: NONE

## f63d07846bd35bb7 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:40-40 (list_item)

- never use stock photo aesthetic

Extracted rules inside block: a3a914e3cc76

## 351014e83763c2ef — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:41-41 (list_item)

- never use AI uncanny faces

Extracted rules inside block: 27106589325a

## 3346c0a735a95c01 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:42-42 (list_item)

- never over-saturate the cream background

Extracted rules inside block: e36e4e915e22

## a5e41edd33dd078a — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:43-43 (list_item)

- never use coral as a flood color (only as accent or signature periods)

Extracted rules inside block: e332bd9ab5e4

## 3b3fd4be09351297 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:44-44 (list_item)

- never use em dashes in copy

Extracted rules inside block: 8872811db986

## 7311e8d742b2f27c — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:45-45 (list_item)

- never use emojis in body copy

Extracted rules inside block: 238d45333621

## 0f6c8f0b57737c13 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:46-46 (list_item)

- never use bullet points in narrative copy

Extracted rules inside block: 2c4049036a1c

## 4082f82010032e40 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:47-47 (list_item)

- never use clip-art or generic icon sets

Extracted rules inside block: a395c22dcc78

## 077f1c2df6330878 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:48-48 (list_item)

- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")

Extracted rules inside block: 00995a3683fc

## bed68345f85d1b88 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:49-49 (list_item)

- never use exclamation points in headlines

Extracted rules inside block: b8ecf738aef4

## 195e7dd9922cf1b5 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:50-50 (list_item)

- never default to dark mode, light mode hybrid is the brand

Extracted rules inside block: 6c29ef0b91ea

## 9098ff6a99b9b03d — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:51-51 (list_item)

- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

Extracted rules inside block: 2fffe09d9421

## 880fdefe127a8cf6 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:53-53 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## 47a5759e633e4bc5 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:55-55 (list_item)

- 9:16, primary for short-form social

Extracted rules inside block: NONE

## 4e442d72e42c175f — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:56-56 (list_item)

- 16:9, long-form, hero films, web embeds

Extracted rules inside block: NONE

## 5d2413c30bc253f3 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:57-57 (list_item)

- 1:1, feed posts, podcast covers

Extracted rules inside block: NONE

## 57e242faab1c20f2 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:58-58 (list_item)

- 4:5. Instagram feed alternative

Extracted rules inside block: NONE

## ad015c082cc1f185 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:60-60 (heading)

## Color grade direction

Extracted rules inside block: NONE

## abb6eb4fbed6d383 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:62-62 (paragraph)

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

Extracted rules inside block: 3360a984540d

## 205c2edf302a30c2 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:64-64 (heading)

## Motion language

Extracted rules inside block: NONE

## 9ce0618912ed8486 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:66-66 (paragraph)

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

Extracted rules inside block: 16757b9fc180
