# Rule classification review 35/35

Review all 31 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## a6573f638fb4 — visual-prompt-forge/references/consistency-locks.md:120

Accept that some shots will need re-rolls. Budget for it. The locks reduce the failure rate; they don't eliminate it.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "a6573f638fb4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "continuity.level",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 082ef4c63248 — visual-prompt-forge/references/failure-modes.md:3

What goes wrong when generated images don't match the storyboard, and what to fix at the prompt level vs. accept as editorial work.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "082ef4c63248",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## 26f67e595bc5 — visual-prompt-forge/references/failure-modes.md:13

No "never" list applied from brand-lock

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "26f67e595bc5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## c927233dce49 — visual-prompt-forge/references/failure-modes.md:19

Verify brand-lock "never" list is being applied, if it includes "no AI uncanny", surface that into the prompt

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "c927233dce49",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## c6f5af57536e — visual-prompt-forge/references/failure-modes.md:20

Use Flux 2 Pro or Midjourney v7 instead of cheaper models for hero shots

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "c6f5af57536e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## aada37d743da — visual-prompt-forge/references/failure-modes.md:37

Use reference image after the first successful shot

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "aada37d743da",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "stage",
        "value": [
          "prompt",
          "qa"
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 3d08083cf84c — visual-prompt-forge/references/failure-modes.md:39

For Midjourney, use `--cref` with `--cw 50`

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "3d08083cf84c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "stage",
        "value": [
          "prompt",
          "qa"
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 034e657259a2 — visual-prompt-forge/references/failure-modes.md:53

The right answer is almost always: **don't put text in the prompt**. Composite separately from `text-overlays.json`.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "034e657259a2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "stage",
        "value": [
          "prompt",
          "qa"
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 680241b62a60 — visual-prompt-forge/references/failure-modes.md:54

If text must be in-image (poster work), use Ideogram v3 with explicit override flag

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "680241b62a60",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "stage",
        "value": [
          "prompt",
          "qa"
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 5c6209516d60 — visual-prompt-forge/references/failure-modes.md:56

Use simple fonts (sans-serif, clean serif), cursive and decorative fonts fail even on Ideogram

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "5c6209516d60",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## ddd438309be8 — visual-prompt-forge/references/failure-modes.md:87

For GPT Image (best at spatial reasoning), use percentage references: "subject at left 30% of frame"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "ddd438309be8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## e1a5f9f21b69 — visual-prompt-forge/references/failure-modes.md:122

**Accept editorially when:** generation is close enough that retouching gets there. Don't burn API credits chasing perfect on-prompt.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "e1a5f9f21b69",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## 65e9cd1d5013 — visual-prompt-forge/references/failure-modes.md:128

You've re-rolled the same shot 5+ times with no improvement → the prompt is fine; the model can't render this concept; pick a different shot or different generator

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "65e9cd1d5013",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## 6f6d83244015 — visual-prompt-forge/references/failure-modes.md:129

You're tweaking single words and hoping → you've hit prompt-level diminishing returns; move to image-to-image refinement (Nano Banana) or post-production

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "6f6d83244015",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## 01b98a09215e — visual-prompt-forge/references/failure-modes.md:130

The image is 80% right and the gap is editorial → ship to post and let the editor finish

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "01b98a09215e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## c03c9bff65b0 — visual-prompt-forge/references/failure-modes.md:132

Generation is one stage in a pipeline. Don't try to make it the whole pipeline.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "c03c9bff65b0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "prompt",
      "qa"
    ]
  }
}
```

## 5e30e8fdcae7 — visual-prompt-forge/references/prompt-anatomy.md:16

"Never" list (things this brand never does, e.g. "no stock photo aesthetic", "no AI uncanny", "no over-saturated", "no shouting copy")

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "5e30e8fdcae7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 04faf520c218 — visual-prompt-forge/references/prompt-anatomy.md:20

This layer answers: **what does the brand always look and feel like?**

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "04faf520c218",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 3cc53cc41c37 — visual-prompt-forge/references/prompt-anatomy.md:60

**Never appears in image prompts** (except Ideogram Mode 2 with explicit override).

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "3cc53cc41c37",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## c7812f433b4b — visual-prompt-forge/references/prompt-anatomy.md:64

**Editability.** Composited text can be revised without re-generating images.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "c7812f433b4b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## a81c7c2a9375 — visual-prompt-forge/references/prompt-anatomy.md:65

**Quality.** Even Ideogram and GPT Image (the best at text) produce typography that lags professional design tools.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": "vocabulary.visual_style_quality",
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "a81c7c2a9375",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 13be37c4c704 — visual-prompt-forge/references/prompt-anatomy.md:66

**Animation.** Animated text needs After Effects / Remotion / CapCut. Static rendered text is dead-on-arrival for motion content.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "13be37c4c704",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 2189476c0707 — visual-prompt-forge/references/prompt-anatomy.md:67

**Brand control.** Composited text uses exact brand fonts and exact brand colors. Generated text approximates.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "2189476c0707",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 15db8f90d04d — visual-prompt-forge/references/prompt-anatomy.md:98

The adapter pulls from Layers 1–3 and produces a string. Layer 4 lives parallel and never enters the prompt.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "15db8f90d04d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 5619289cd7dc — visual-prompt-forge/tools/README.md:32

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "5619289cd7dc",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 1bf282b70f39 — visual-prompt-forge/tools/README.md:72

Checks a brand-lock has all required sections and Identity fields, that its palette declares

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "1bf282b70f39",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 53ee4336e895 — visual-prompt-forge/tools/README.md:86

`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "53ee4336e895",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 7d3ff60d0cc2 — visual-prompt-forge/tools/README.md:144

to be identified, and a named generator has to exist in the capability matrix.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "7d3ff60d0cc2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## ccbc2a89cf61 — visual-prompt-forge/tools/README.md:172

a frame on disk with no critique for its round, never reviewed at all

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "ccbc2a89cf61",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 40759795a164 — visual-prompt-forge/tools/README.md:194

template the skill uses, through the small engine in `_template.py`. It did not always: the

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "40759795a164",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## cad388b91f11 — visual-prompt-forge/tools/README.md:220

never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "cad388b91f11",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```
