# Rule classification review 4/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## e2e810a4492f — brand-lock-extractor/brand-packs/README.md:21

**Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "e2e810a4492f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## fac90d12086b — brand-lock-extractor/brand-packs/README.md:29

**`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "fac90d12086b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## b98efaf4637c — brand-lock-extractor/brand-packs/README.md:36

Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "b98efaf4637c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "any": [
          {
            "op": "eq",
            "path": "stage",
            "value": "brief"
          },
          {
            "op": "eq",
            "path": "operation",
            "value": "brand_extract"
          },
          {
            "op": "not_in",
            "path": "brand.mode",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "eq",
        "path": "subject.hands_visible",
        "value": true
      }
    ]
  }
}
```

## 035e44d5794b — brand-lock-extractor/brand-packs/_template.md:17

Role | Hex | Use

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "035e44d5794b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## e12b6c2a6277 — brand-lock-extractor/brand-packs/_template.md:25

Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "e12b6c2a6277",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## c8b1e667f806 — brand-lock-extractor/brand-packs/_template.md:49

What this brand never does, visually or tonally. Be specific.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "c8b1e667f806",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 5899a276b08f — brand-lock-extractor/brand-packs/_template.md:51

never use stock photo aesthetic

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "5899a276b08f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## c8855e3ad412 — brand-lock-extractor/brand-packs/_template.md:52

never use AI uncanny faces

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "c8855e3ad412",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 892dc09a58db — brand-lock-extractor/brand-packs/_template.md:53

never over-saturate

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "892dc09a58db",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## e71e5baec3de — brand-lock-extractor/brand-packs/_template.md:54

never shout in copy

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "e71e5baec3de",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 17c0a050ea13 — brand-lock-extractor/brand-packs/_template.md:55

never use clip-art icons

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "17c0a050ea13",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 1c4e1a34a49b — brand-lock-extractor/brand-packs/_template.md:64

How footage and generated images should be graded. One sentence.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "1c4e1a34a49b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 4d6b16d72e53 — brand-lock-extractor/brand-packs/_template.md:72

> e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "4d6b16d72e53",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 341af56c8857 — brand-lock-extractor/brand-packs/examples/saas-clean.md:14

Role | Hex | Use

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "341af56c8857",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## c8d50a9effa6 — brand-lock-extractor/brand-packs/examples/saas-clean.md:40

never use stock photo aesthetic

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "c8d50a9effa6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 1299d1bab833 — brand-lock-extractor/brand-packs/examples/saas-clean.md:41

never use AI uncanny faces

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "1299d1bab833",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## b8cbe1a1fdf6 — brand-lock-extractor/brand-packs/examples/saas-clean.md:42

never use illustrations of people (real photography or abstract data viz only)

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "b8cbe1a1fdf6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 5c7051389a09 — brand-lock-extractor/brand-packs/examples/saas-clean.md:43

never use gradients (flat color only)

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "5c7051389a09",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 8c2ead69c2df — brand-lock-extractor/brand-packs/examples/saas-clean.md:44

never use rounded corners larger than 8px

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "8c2ead69c2df",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## f1fb6a703226 — brand-lock-extractor/brand-packs/examples/saas-clean.md:45

never use exclamation points

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "f1fb6a703226",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## cdfbbae8aef0 — brand-lock-extractor/brand-packs/examples/saas-clean.md:46

never use vague claims ("the best", "industry-leading", "cutting-edge")

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "cdfbbae8aef0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 8fa3aca3d811 — brand-lock-extractor/brand-packs/examples/saas-clean.md:47

never use AI/ML buzzwords without specifics

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "8fa3aca3d811",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## bcca72586f78 — brand-lock-extractor/brand-packs/examples/saas-clean.md:48

never default to dark mode in primary marketing

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "bcca72586f78",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## d1200822cff3 — brand-lock-extractor/brand-packs/examples/saas-clean.md:49

never use animated icons or lottie illustrations

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "d1200822cff3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 9b81d2c474e2 — brand-lock-extractor/brand-packs/examples/saas-clean.md:70

prefer specific numbers ("40% reduction in 90 days" not "significant improvement")

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "9b81d2c474e2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 43e1c6267db0 — brand-lock-extractor/brand-packs/examples/saas-clean.md:71

prefer "we" and "you" over "the company" and "the user"

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "43e1c6267db0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 08008c9a018e — brand-lock-extractor/brand-packs/examples/saas-clean.md:72

prefer present-tense

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "08008c9a018e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 81325a38d881 — brand-lock-extractor/brand-packs/examples/saas-clean.md:73

never start a sentence with "Just" or "Simply"

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "81325a38d881",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 3c45f75a8756 — brand-lock-extractor/brand-packs/examples/saas-clean.md:74

avoid corporate hedge language ("seek to", "look to", "aim to")

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "3c45f75a8756",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 6c25ef1475f6 — brand-lock-extractor/examples/brand-lock.md:14

Role | Hex | Use

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "6c25ef1475f6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## f36e0e650709 — brand-lock-extractor/examples/brand-lock.md:36

never use stock smiles or posed lifestyle photography

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "f36e0e650709",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 69053c1a14a1 — brand-lock-extractor/examples/brand-lock.md:37

never use latte art as decoration

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "69053c1a14a1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 90a0525b5cb2 — brand-lock-extractor/examples/brand-lock.md:38

never use the word "artisanal"

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "90a0525b5cb2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## cb341b2dcf41 — brand-lock-extractor/examples/brand-lock.md:39

never use exclamation points

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "cb341b2dcf41",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 862d91a99313 — brand-lock-extractor/examples/brand-lock.md:40

never shoot glossy product-on-white; matte and natural-light only

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "862d91a99313",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```
