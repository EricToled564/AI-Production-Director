# Source coverage review 206/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 52d1f72aac9f3fa2 — visual-prompt-forge/adapters/flux.md:72-72 (paragraph)

**Output prompt:**

Extracted rules inside block: NONE

## b0893ff90ac7ff4b — visual-prompt-forge/adapters/flux.md:73-75 (code)

```
Medium shot of a founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck, leaning forward at his laptop with his face partially turned toward window light. Composition leaves negative space on the right side of the frame. The setting is a minimalist home office with white walls and an oak desk. Soft natural side-light from a large window on the left, warm afternoon golden hour. Shot on a 50mm prime at f/2.0, shallow depth of field. Warm filmic color grade with muted teal shadows. Calm, considered mood, operator, not creator. Photorealistic, natural skin texture, no AI artifacts.
```

Extracted rules inside block: NONE

## e1dafe095d48025f — visual-prompt-forge/adapters/flux.md:77-77 (heading)

## Flux variant selection

Extracted rules inside block: NONE

## 06aa93f46b4b0bc4 — visual-prompt-forge/adapters/flux.md:79-79 (table_row)

| Variant | When | Cost ratio |

Extracted rules inside block: NONE

## b04f8a6c8e47f559 — visual-prompt-forge/adapters/flux.md:81-81 (table_row)

| Flux 2 Pro | Hero shots, final assets | 1× (highest) |

Extracted rules inside block: NONE

## b8fd26613dd29b01 — visual-prompt-forge/adapters/flux.md:82-82 (table_row)

| Flux 1.1 Pro | Series work, balanced | ~0.6× |

Extracted rules inside block: NONE

## 2c68fde7a75df020 — visual-prompt-forge/adapters/flux.md:83-83 (table_row)

| Flux Schnell | Quick iteration, drafts | ~0.1× |

Extracted rules inside block: NONE

## 4a4a1b747329d6d4 — visual-prompt-forge/adapters/flux.md:84-84 (table_row)

| Flux Dev | Self-hosted, scale | ~0× per image, GPU cost |

Extracted rules inside block: NONE

## f9fa65ca0132e446 — visual-prompt-forge/adapters/flux.md:86-86 (paragraph)

Default to Flux 2 Pro for storyboard previews. The `flux.txt` file works for any variant, same prompt syntax.

Extracted rules inside block: NONE

## f69ecd28289db59f — visual-prompt-forge/adapters/flux.md:88-88 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 03852fd792c71045 — visual-prompt-forge/adapters/flux.md:90-90 (list_item)

- **Don't write "highly detailed, 4k, masterpiece"**, these are Stable Diffusion crutches. Flux ignores them and the line burns tokens

Extracted rules inside block: 4594abb35540

## d8d7ead797cad304 — visual-prompt-forge/adapters/flux.md:91-91 (list_item)

- **Don't use weight syntax `(thing:1.4)`**. Flux 2 doesn't support it; Flux 1.1 partially does. Stick to natural language

Extracted rules inside block: 2b23f1b39bd9

## dd1d529222ac59eb — visual-prompt-forge/adapters/flux.md:92-92 (list_item)

- **Don't enable prompt upsampling for series work**, fal.ai's auto-rewrite produces inconsistent shots

Extracted rules inside block: a942932e61bb

## 744f8ae903702580 — visual-prompt-forge/adapters/flux.md:93-93 (list_item)

- **Don't include text content**, even if Flux 2 handles text better than Flux 1.1, composite separately for editability

Extracted rules inside block: d8eda9fe8b4e

## 961998813cd7c046 — visual-prompt-forge/adapters/flux.md:94-94 (list_item)

- **Don't omit the photoreal closing line**, the "no AI artifacts" anchor measurably reduces the AI-look

Extracted rules inside block: 6cab01ccec55

## aa2b51970921a74b — visual-prompt-forge/adapters/flux.md:96-96 (heading)

## API access

Extracted rules inside block: NONE

## 4c52de6f11fb7c41 — visual-prompt-forge/adapters/flux.md:98-98 (paragraph)

Flux has multiple API surfaces:

Extracted rules inside block: NONE

## ed961b8a088956f9 — visual-prompt-forge/adapters/flux.md:100-100 (list_item)

- **fal.ai**, fastest, most stable, supports all variants

Extracted rules inside block: NONE

## ee2948e4eea71408 — visual-prompt-forge/adapters/flux.md:101-101 (list_item)

- **Replicate**, broader model selection, slightly slower

Extracted rules inside block: NONE

## bafac1e0890dc3f3 — visual-prompt-forge/adapters/flux.md:102-102 (list_item)

- **BFL direct API**, official, requires their key

Extracted rules inside block: NONE

## 897f775fad1367d5 — visual-prompt-forge/adapters/flux.md:103-103 (list_item)

- **WaveSpeedAI**, unified interface across many models

Extracted rules inside block: NONE

## 1bda1aa53854111b — visual-prompt-forge/adapters/flux.md:105-105 (paragraph)

Same prompt syntax across all four. The `flux.txt` file is portable.

Extracted rules inside block: NONE

## 1fccc918489998c9 — visual-prompt-forge/adapters/gpt-image.md:1-1 (heading)

# Adapter: GPT Image (1.5 / 2)

Extracted rules inside block: NONE

## 24ccd04b37eaf970 — visual-prompt-forge/adapters/gpt-image.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: 673e96a9dc08

## 16b9c2cba6fb70d8 — visual-prompt-forge/adapters/gpt-image.md:5-5 (paragraph)

GPT Image rewards paragraph-form prompts with explicit spatial reasoning and complex composition descriptions. It interprets relational language ("to the left of", "behind", "in the foreground") more accurately than any other generator. Choose GPT Image when the brief requires precise scene composition, multiple objects, or accurate text rendering.

Extracted rules inside block: NONE

## e3dd98992c0ee4c1 — visual-prompt-forge/adapters/gpt-image.md:7-7 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## 00517885af90c2ed — visual-prompt-forge/adapters/gpt-image.md:9-15 (code)

```
{Paragraph 1: subject, action, spatial composition}

{Paragraph 2: environment and contextual details}

{Paragraph 3: lighting, photographic specs, mood}
```

Extracted rules inside block: NONE

## dc075851eb774025 — visual-prompt-forge/adapters/gpt-image.md:17-17 (paragraph)

Paragraph breaks help GPT Image parse separate beats. One long monolithic paragraph underperforms, the model loses track of which detail applies where.

Extracted rules inside block: NONE

## c5ef253721dee085 — visual-prompt-forge/adapters/gpt-image.md:19-19 (heading)

## Parameters

Extracted rules inside block: NONE

## dc2026c549ebbdd9 — visual-prompt-forge/adapters/gpt-image.md:21-21 (paragraph)

GPT Image is API-driven through OpenAI:

Extracted rules inside block: NONE
