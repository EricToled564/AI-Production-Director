# Source coverage review 190/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 8a1004b53d4426bf — visual-asset-critic/SKILL.md:273-273 (list_item)

> "Want me to draft the revised prompt? Point `visual-prompt-forge` at this output tree in

Extracted rules inside block: NONE

## 7ba14a13fb4acbc0 — visual-asset-critic/SKILL.md:274-274 (list_item)

> revision mode and it will re-emit prompts for just the shots that need them."

Extracted rules inside block: NONE

## 366f194ccc3b7eee — visual-asset-critic/SKILL.md:276-279 (paragraph)

If the verdict is REJECT, do not offer that. REJECT means a blocking issue or three or more
major ones, which is a failure with no clear fix path, and revision mode is built to stop
there and ask. Say what blocked it and what decision it needs: a changed shot spec, a
changed brand-lock, or a different generator.

Extracted rules inside block: bccdb4ab63c0

## 942443904de2da8e — visual-asset-critic/SKILL.md:281-282 (paragraph)

Don't auto-revise. The user picks. The critique you just wrote is exactly what closes that
loop.

Extracted rules inside block: 96f2260b3e34

## e2de9220db7dd858 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:1-2 (paragraph)

<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->

Extracted rules inside block: NONE

## 2c816881626dfac1 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:4-4 (heading)

# Brand Lock: WhyStrohm

Extracted rules inside block: NONE

## 9538285847debad2 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:6-6 (heading)

## Identity

Extracted rules inside block: NONE

## 95dbcdb8e3601a65 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:8-11 (paragraph)

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

Extracted rules inside block: NONE

## fbfa2c81c35783d6 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:13-13 (heading)

## Palette

Extracted rules inside block: NONE

## 4f6a0ad3de4cfa56 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:15-15 (table_row)

| Role | Hex | Use |

Extracted rules inside block: ca6e66773a76

## 0dbb4157b67e4733 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:17-17 (table_row)

| Background | `#F5F0E8` | Cream, primary canvas |

Extracted rules inside block: NONE

## 2cb1cf6f9161bf28 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:18-18 (table_row)

| Ink | `#2A2A32` | Near-black, primary text and dark elements |

Extracted rules inside block: NONE

## dc0eb1763c7c9cd4 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:19-19 (table_row)

| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |

Extracted rules inside block: NONE

## 7656f51edcc92796 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:20-20 (table_row)

| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |

Extracted rules inside block: NONE

## 5248e51a043102ce — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:21-21 (table_row)

| Muted | `#7A7580` | Secondary text, captions |

Extracted rules inside block: NONE

## be0fc4790871936d — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:22-22 (table_row)

| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

Extracted rules inside block: NONE

## 494d035b4915ba93 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:24-24 (heading)

## Typography

Extracted rules inside block: NONE

## 96c94589f00f1281 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:26-28 (paragraph)

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

Extracted rules inside block: NONE

## c9c3daeac6f74562 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:30-30 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## a1f7b81003c6a3f6 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:32-32 (list_item)

- operator (not creator)

Extracted rules inside block: NONE

## 937fc667b9d123b3 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:33-33 (list_item)

- considered (not reactive)

Extracted rules inside block: NONE

## 286689205e174d63 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:34-34 (list_item)

- deterministic (not vibes-based)

Extracted rules inside block: NONE

## b9dab01b89a102c4 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:35-35 (list_item)

- confident (without volume)

Extracted rules inside block: NONE

## 0dd2521e60015d88 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:36-36 (list_item)

- defense-grade (not fragile)

Extracted rules inside block: NONE

## 051c17f6b86256fb — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:38-38 (heading)

## Never list

Extracted rules inside block: NONE

## 479bcb706af026b1 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:40-40 (list_item)

- never use stock photo aesthetic

Extracted rules inside block: c359aa23b4a9

## 6569936d7503660e — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:41-41 (list_item)

- never use AI uncanny faces

Extracted rules inside block: f5446eb4686c

## 0f01b2dc26a20ed9 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:42-42 (list_item)

- never over-saturate the cream background

Extracted rules inside block: 7917460675d6

## c14380c48d2040e8 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:43-43 (list_item)

- never use coral as a flood color (only as accent or signature periods)

Extracted rules inside block: 15691ed21276

## db8f6c6407f6c473 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:44-44 (list_item)

- never use em dashes in copy

Extracted rules inside block: 7b0e7459a9cc
