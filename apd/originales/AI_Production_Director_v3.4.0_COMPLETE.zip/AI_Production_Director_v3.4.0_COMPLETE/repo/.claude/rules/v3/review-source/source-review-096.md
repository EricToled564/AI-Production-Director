# Source coverage review 96/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## ec75271a8002ecb6 — storyboard-architect/SKILL.md:134-134 (list_item)

- `position`, `center`, `lower-third`, `upper-third`, `left-third`, `right-third`, or `{x, y}` percentages

Extracted rules inside block: NONE

## 498be8864a356b3f — storyboard-architect/SKILL.md:135-135 (list_item)

- `size`, `display`, `headline`, `body`, `caption`

Extracted rules inside block: NONE

## 2222f3ac5b321ed6 — storyboard-architect/SKILL.md:136-136 (list_item)

- `weight`, `regular`, `medium`, `bold`, `black`

Extracted rules inside block: NONE

## b6ff7c86c5d97a83 — storyboard-architect/SKILL.md:137-137 (list_item)

- `color`, hex (must come from brand-lock palette)

Extracted rules inside block: 803fbd9cb44a

## 037c856ecd8605a8 — storyboard-architect/SKILL.md:138-138 (list_item)

- `enter`, `{ at: seconds, animation: fade-in | slide-up | slide-down | type-on | hard-cut }`

Extracted rules inside block: NONE

## 2ed30ef64490e4e5 — storyboard-architect/SKILL.md:139-139 (list_item)

- `exit`, `{ at: seconds, animation: fade-out | slide-up | slide-down | hard-cut }`

Extracted rules inside block: NONE

## 1d1a05ab09272354 — storyboard-architect/SKILL.md:141-143 (paragraph)

Enter and exit have different animation vocabularies, and `templates/text-overlays.schema.json`
is the authority on both. A shot may carry more than one overlay; list every id in that
shot's `on_screen_text` array, or the extra overlays render nowhere.

Extracted rules inside block: NONE

## ff62b6d3b915794f — storyboard-architect/SKILL.md:145-145 (heading)

### Step 6. Lock the series

Extracted rules inside block: NONE

## 80afb507657b738a — storyboard-architect/SKILL.md:147-147 (paragraph)

Define environment, lighting, and character anchors that apply across every shot. These go at the top of `shots.json` under `series_lock`. Without these, image generation will produce incoherent frames.

Extracted rules inside block: NONE

## 6a1d938f4c47d015 — storyboard-architect/SKILL.md:149-149 (heading)

### Step 7. Write rationale

Extracted rules inside block: NONE

## 8c398d09cee76003 — storyboard-architect/SKILL.md:151-151 (paragraph)

Every shot has a one-sentence rationale. Why this beat. Why this framing. Why this on-screen text. This is the audit trail. Do not skip it.

Extracted rules inside block: ff853701593a

## 60dec84c26c25283 — storyboard-architect/SKILL.md:153-153 (heading)

### Step 8. Snapshot the brand-lock

Extracted rules inside block: NONE

## 1c508eae8765d064 — storyboard-architect/SKILL.md:155-156 (paragraph)

Copy the brand-lock file (or template) into the output as `brand-lock.snapshot.md`. Add
these two comments at the very top, in this order:

Extracted rules inside block: NONE

## 522bf14d24ed57ce — storyboard-architect/SKILL.md:158-161 (code)

```
<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->
```

Extracted rules inside block: NONE

## 85b129f198ff052f — storyboard-architect/SKILL.md:163-166 (paragraph)

The timestamp is a full UTC instant, `YYYY-MM-DDThh:mm:ssZ`. A bare date cannot
distinguish two runs made on the same day, which is the case that matters. The source is
the path it was copied from, or the literal string `template default` for an
unconfigured run. Extra comments after these two are fine.

Extracted rules inside block: NONE

## 0a82dabf61a1ef51 — storyboard-architect/SKILL.md:168-168 (paragraph)

`tools/validate_brand_lock.py --snapshot <path>` checks both lines. Run it.

Extracted rules inside block: NONE

## 2161cc67e9086a0f — storyboard-architect/SKILL.md:170-170 (heading)

### Step 9. Write run.json

Extracted rules inside block: NONE

## d56879aba89add83 — storyboard-architect/SKILL.md:172-174 (paragraph)

Last step, after the other four files are final. Fill in
`templates/run.schema.json`: a `run_id`, the `created_at` instant, and the SHA-256 of
`shots.json`, `text-overlays.json`, and `brand-lock.snapshot.md` as written.

Extracted rules inside block: NONE

## 9820308a9217a011 — storyboard-architect/SKILL.md:176-178 (code)

```bash
shasum -a 256 output/shots.json output/text-overlays.json output/brand-lock.snapshot.md
```

Extracted rules inside block: NONE

## 811a49343e6427e2 — storyboard-architect/SKILL.md:180-183 (paragraph)

`run_id` is the compact UTC timestamp, a dash, then 8 hex characters, e.g.
`20260730T142300Z-9f2c1ab4`. The hex suffix is what keeps two operators starting a run
in the same second from colliding. Set `brand_lock_configured: false` when the snapshot
is an unfilled template.

Extracted rules inside block: NONE

## 5967b474dd0af354 — storyboard-architect/SKILL.md:185-186 (paragraph)

Leave `rounds` empty. `visual-prompt-forge` appends a round entry when it writes
prompts.

Extracted rules inside block: NONE

## 8b5baf2d1bcb6de3 — storyboard-architect/SKILL.md:188-188 (heading)

## Output formats

Extracted rules inside block: NONE

## 471de1e9231644e5 — storyboard-architect/SKILL.md:190-190 (heading)

### `storyboard.md`

Extracted rules inside block: NONE

## 24cf2f74b7b27c4f — storyboard-architect/SKILL.md:192-192 (paragraph)

Use the template at `templates/storyboard.md.tpl`. Read it before writing.

Extracted rules inside block: 7be8e98587ed

## dbfd87f46fd260e3 — storyboard-architect/SKILL.md:194-194 (heading)

### `shots.json`

Extracted rules inside block: NONE

## 562d99d2d8bfac3f — storyboard-architect/SKILL.md:196-196 (paragraph)

Must validate against `templates/shots.schema.json`. Read it before writing. The structure is:

Extracted rules inside block: c58ef3e5f174

## a33522e6123b4edb — storyboard-architect/SKILL.md:198-228 (code)

```json
{
  "version": "1.2",
  "project": { "title": "...", "duration_s": 30, "aspect": "9:16", "framework": "..." },
  "brand_lock_ref": "brand-lock.snapshot.md",
  "series_lock": {
    "character": "...",
    "environment": "...",
    "lighting": "...",
    "color_grade": "..."
  },
  "shots": [
    {
      "id": "shot_01",
      "beat": "hook",
      "start": 0.0,
      "end": 2.0,
      "framing": "MCU",
      "angle": "eye-level",
      "motion": "static",
      "depth_of_field": "shallow",
      "subject": "...",
      "environment_ref": "series_lock.environment",
      "lighting_ref": "series_lock.lighting",
      "on_screen_text": "text_01",
      "vo": null,
      "rationale": "..."
    }
  ]
}
```

Extracted rules inside block: NONE

## 130d3cc537c3c50c — storyboard-architect/SKILL.md:230-231 (paragraph)

Write `1.2` for new storyboards. `1.0` and `1.1` files stay valid; the array form of
`on_screen_text` and the hashed `assets` block need `1.2`.

Extracted rules inside block: NONE

## c41333dc13d1a324 — storyboard-architect/SKILL.md:233-233 (heading)

### `text-overlays.json`

Extracted rules inside block: NONE

## a272745e6a36470a — storyboard-architect/SKILL.md:235-235 (paragraph)

Must validate against `templates/text-overlays.schema.json`. Read it before writing.

Extracted rules inside block: 7085a38d1bb4
