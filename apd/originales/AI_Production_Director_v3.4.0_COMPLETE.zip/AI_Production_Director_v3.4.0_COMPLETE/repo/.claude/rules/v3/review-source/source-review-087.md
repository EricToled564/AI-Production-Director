# Source coverage review 87/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 7686f33001a6bff6 — screenwriter/references/advanced-techniques.md:66-66 (heading)

## Dialogue Polish Techniques

Extracted rules inside block: NONE

## 436510867fe7055d — screenwriter/references/advanced-techniques.md:68-68 (heading)

### Subtext Over Direct Statement

Extracted rules inside block: NONE

## 7c23f3b4938aa692 — screenwriter/references/advanced-techniques.md:70-70 (paragraph)

**❌ On-the-nose:**

Extracted rules inside block: e76538dc0865

## c355a3bc568fdee8 — screenwriter/references/advanced-techniques.md:71-74 (code)

```
JOHN
I'm angry at you for lying to me.
```

Extracted rules inside block: NONE

## da776e184674aa4b — screenwriter/references/advanced-techniques.md:76-76 (paragraph)

**✅ Subtext:**

Extracted rules inside block: 4811167cc1f1

## 1bdcd14f17ef3268 — screenwriter/references/advanced-techniques.md:77-81 (code)

```
JOHN
(barely looking at her)
Coffee's cold.
```

Extracted rules inside block: NONE

## 6dcd778d71a1eba5 — screenwriter/references/advanced-techniques.md:83-83 (heading)

### Character Voice Consistency

Extracted rules inside block: NONE

## 5a4c2721f787e3fc — screenwriter/references/advanced-techniques.md:85-85 (paragraph)

Each character should have distinct speech patterns:

Extracted rules inside block: f5754ffc35b0

## 760e7173d85c2f65 — screenwriter/references/advanced-techniques.md:87-87 (paragraph)

**Marcus (technical, precise):**

Extracted rules inside block: NONE

## 9c4da667491dcf7d — screenwriter/references/advanced-techniques.md:88-92 (code)

```
MARCUS
Probability of success: 47 percent.
Margin of error: plus or minus 3.
```

Extracted rules inside block: NONE

## 9764bad547c4afd4 — screenwriter/references/advanced-techniques.md:94-94 (paragraph)

**Sarah (emotional, intuitive):**

Extracted rules inside block: NONE

## b896936104462272 — screenwriter/references/advanced-techniques.md:95-98 (code)

```
SARAH
We'll make it work. We always do.
```

Extracted rules inside block: NONE

## 81e46128f0a43ef9 — screenwriter/references/advanced-techniques.md:100-100 (heading)

### Dialogue Rhythm

Extracted rules inside block: NONE

## 002c9435396d0c6c — screenwriter/references/advanced-techniques.md:102-102 (paragraph)

Vary sentence length for natural flow:

Extracted rules inside block: NONE

## 52d8b093111a825f — screenwriter/references/advanced-techniques.md:104-108 (code)

```
ELENA
Three years. That's how long I waited.
For what? This?
```

Extracted rules inside block: NONE

## 3dfbb366e96c462a — screenwriter/references/advanced-techniques.md:112-112 (heading)

## Pacing Optimization

Extracted rules inside block: NONE

## 2b1eeb8256e546c2 — screenwriter/references/advanced-techniques.md:114-114 (heading)

### Scene Length Variation

Extracted rules inside block: NONE

## 55fe6ff33036b18c — screenwriter/references/advanced-techniques.md:116-116 (paragraph)

Alternate between long and short scenes for rhythm:

Extracted rules inside block: NONE

## bb4bbabe7ad375a4 — screenwriter/references/advanced-techniques.md:118-118 (paragraph)

**Pattern Example:**

Extracted rules inside block: NONE

## f4c1806e6f99a503 — screenwriter/references/advanced-techniques.md:119-119 (list_item)

- Scene 1: 60s (long, establishing)

Extracted rules inside block: NONE

## a2883115047de256 — screenwriter/references/advanced-techniques.md:120-120 (list_item)

- Scene 2: 30s (short, tense)

Extracted rules inside block: NONE

## 4b6ad1e2d96e58cc — screenwriter/references/advanced-techniques.md:121-121 (list_item)

- Scene 3: 45s (medium, development)

Extracted rules inside block: NONE

## 0fd96cdfd9baf5f3 — screenwriter/references/advanced-techniques.md:122-122 (list_item)

- Scene 4: 30s (short, action)

Extracted rules inside block: NONE

## 150e65823871e2e7 — screenwriter/references/advanced-techniques.md:123-123 (list_item)

- Scene 5: 90s (long, climax)

Extracted rules inside block: NONE

## 36c2900018f0258f — screenwriter/references/advanced-techniques.md:125-125 (heading)

### Tension Escalation

Extracted rules inside block: NONE

## 6a0fabfa5df79294 — screenwriter/references/advanced-techniques.md:127-127 (paragraph)

Each scene should raise stakes or tension incrementally:

Extracted rules inside block: d97f3e40d00d

## 0948528566fcefdd — screenwriter/references/advanced-techniques.md:129-134 (paragraph)

**Scene 1:** Character wants something
**Scene 2:** Obstacle appears
**Scene 3:** Obstacle worsens
**Scene 4:** New complications
**Scene 5:** Crisis point
**Scene 6:** Resolution

Extracted rules inside block: NONE

## c2027ed29f8d261f — screenwriter/references/advanced-techniques.md:136-136 (heading)

### Visual Momentum

Extracted rules inside block: NONE

## 832fa9fd01457eb1 — screenwriter/references/advanced-techniques.md:138-138 (paragraph)

Alternate visual energy levels:

Extracted rules inside block: NONE

## e3bf7d48603f468a — screenwriter/references/advanced-techniques.md:140-144 (code)

```
Scene A: Still, contemplative (character alone, quiet)
Scene B: Dynamic, energetic (chase, conflict, movement)
Scene C: Medium tempo (conversation, planning)
```

Extracted rules inside block: NONE
