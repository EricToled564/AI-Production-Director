# Source coverage review 116/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 410c5f61e05ac164 — storyboard-architect/references/shot-grammar.md:88-88 (paragraph)

This trips people up. The rule:

Extracted rules inside block: NONE

## 130fe80038f78f66 — storyboard-architect/references/shot-grammar.md:90-90 (list_item)

- **brand_lock**, locked across the entire project. Palette, type, "never" list.

Extracted rules inside block: 45cc46f93b45

## 9a87f68744d20626 — storyboard-architect/references/shot-grammar.md:91-91 (list_item)

- **series_lock**, locked across this storyboard. Character anchor, environment, lighting style, color grade.

Extracted rules inside block: NONE

## 6fff2e30d3379ec2 — storyboard-architect/references/shot-grammar.md:92-92 (list_item)

- **subject (per shot)**, what's different about *this* shot. Action, expression, framing-specific composition notes.

Extracted rules inside block: NONE

## c402abb413a2b4db — storyboard-architect/references/shot-grammar.md:94-94 (paragraph)

If you find yourself repeating the same lighting description across shots, it belongs in series_lock. If you find yourself repeating the same color description across storyboards, it belongs in brand_lock.

Extracted rules inside block: NONE

## b96378bca94189dc — storyboard-architect/references/timing-rules.md:1-1 (heading)

# Timing Rules

Extracted rules inside block: NONE

## c1daec5705ac4abb — storyboard-architect/references/timing-rules.md:3-3 (paragraph)

Pacing is math, not feel. Use these as defaults. Override only with reason documented in rationale.

Extracted rules inside block: 1f7b55ddf11d

## 46f14e9a0201d558 — storyboard-architect/references/timing-rules.md:5-5 (heading)

## Shot duration baselines

Extracted rules inside block: NONE

## 2701e28cc07a0617 — storyboard-architect/references/timing-rules.md:7-7 (table_row)

| Content type | Default shot duration | Range |

Extracted rules inside block: NONE

## d5d65913fdfb7b0d — storyboard-architect/references/timing-rules.md:9-9 (table_row)

| Kinetic typography / opinion | 1.0–1.5s | 0.5–2.0s |

Extracted rules inside block: NONE

## 514bf71f54533019 — storyboard-architect/references/timing-rules.md:10-10 (table_row)

| Founder talking-head | 2.5–4.0s | 2.0–6.0s |

Extracted rules inside block: NONE

## c9425cda08c11d3a — storyboard-architect/references/timing-rules.md:11-11 (table_row)

| Product/lifestyle b-roll | 1.5–2.5s | 1.0–3.5s |

Extracted rules inside block: NONE

## b014c00a084c5fb6 — storyboard-architect/references/timing-rules.md:12-12 (table_row)

| Demo / how-to | 3.0–5.0s | 2.0–7.0s |

Extracted rules inside block: NONE

## 2fc4e7fe9876327a — storyboard-architect/references/timing-rules.md:13-13 (table_row)

| Cinematic brand film | 3.5–6.0s | 2.0–10.0s |

Extracted rules inside block: NONE

## c7b334a11bb591c0 — storyboard-architect/references/timing-rules.md:15-15 (paragraph)

If a single shot is longer than 7 seconds in a 30-second piece, justify it in rationale. Long shots are not bad. Unjustified long shots are.

Extracted rules inside block: NONE

## fcbdd2472bf5c47b — storyboard-architect/references/timing-rules.md:17-17 (heading)

## Hook timing (the first beat)

Extracted rules inside block: NONE

## 60029c9e13a65b59 — storyboard-architect/references/timing-rules.md:19-19 (paragraph)

The hook is 0–2s. Always. There are no exceptions in short-form content. Specifically:

Extracted rules inside block: 9f6cfadcdf60

## cc38fa8b151cd176 — storyboard-architect/references/timing-rules.md:21-21 (list_item)

- 9:16 social: first frame must telegraph the topic. Auto-play on mute means the first half-second is fighting a swipe.

Extracted rules inside block: fae558c30a80

## a737754ee1185577 — storyboard-architect/references/timing-rules.md:22-22 (list_item)

- 16:9 in-feed: first 2s decides watch-time.

Extracted rules inside block: NONE

## cccb91e83c1ed5a1 — storyboard-architect/references/timing-rules.md:24-24 (paragraph)

The hook shot framing should be high-contrast against the shots that follow. If shot 2 is MS, shot 1 should not be MS. Visual contrast = retention.

Extracted rules inside block: f0cb3ea97558

## 77c2c84df355d039 — storyboard-architect/references/timing-rules.md:26-26 (heading)

## CTA timing (the final beat)

Extracted rules inside block: NONE

## 1cf759571a1bf298 — storyboard-architect/references/timing-rules.md:28-28 (paragraph)

The CTA is the final 4–6s for 30s content, 6–10s for 60s content. Specifically:

Extracted rules inside block: NONE

## 9c953f50d6a2e3d8 — storyboard-architect/references/timing-rules.md:30-30 (list_item)

- Last shot should hold long enough for someone to read the CTA text and act

Extracted rules inside block: 260192b4debd

## 0af40d592fafae2f — storyboard-architect/references/timing-rules.md:31-31 (list_item)

- Don't put motion on the CTA shot, let the text breathe

Extracted rules inside block: 6f071cba5114

## 370e4de236c46066 — storyboard-architect/references/timing-rules.md:32-32 (list_item)

- If there's a logo lockup, it lives in the final 2s, not earlier

Extracted rules inside block: NONE

## 55c3d12ab6e78813 — storyboard-architect/references/timing-rules.md:34-34 (heading)

## On-screen text duration math

Extracted rules inside block: NONE

## 1752461809bc75bd — storyboard-architect/references/timing-rules.md:36-36 (paragraph)

A text overlay needs to be on screen long enough to be **read twice**. Not once, twice. Why: viewers are skimming, eyes don't always lock on first frame.

Extracted rules inside block: 41ff6c012cb1

## 57159064f8ada2b2 — storyboard-architect/references/timing-rules.md:38-38 (paragraph)

Reading speed reference (assume average viewer):

Extracted rules inside block: NONE

## 94d2f526a280eb2a — storyboard-architect/references/timing-rules.md:39-39 (list_item)

- 1 short word (≤5 chars): 0.6s minimum read

Extracted rules inside block: NONE

## 347c49500713925a — storyboard-architect/references/timing-rules.md:40-40 (list_item)

- Short phrase (≤6 words): 1.2s

Extracted rules inside block: NONE
