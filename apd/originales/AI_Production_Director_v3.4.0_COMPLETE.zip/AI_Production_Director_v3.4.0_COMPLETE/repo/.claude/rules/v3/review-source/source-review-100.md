# Source coverage review 100/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 81984f17cbc1fcb6 — storyboard-architect/brand-packs/_template.md:53-53 (list_item)

- never over-saturate

Extracted rules inside block: 671cc3f9bb8b

## 1aa4ca1fb080e2bf — storyboard-architect/brand-packs/_template.md:54-54 (list_item)

- never shout in copy

Extracted rules inside block: a0d0f54e8cec

## 82a38dccd3e1ce3a — storyboard-architect/brand-packs/_template.md:55-55 (list_item)

- never use clip-art icons

Extracted rules inside block: 39334acdbd3d

## 57f839e7c26dc429 — storyboard-architect/brand-packs/_template.md:56-56 (list_item)

- (add more, the more specific, the better)

Extracted rules inside block: NONE

## 142b9ce54a9ce56a — storyboard-architect/brand-packs/_template.md:58-58 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## 7eaf7fec810564b8 — storyboard-architect/brand-packs/_template.md:60-60 (paragraph)

Default: 16:9 / 9:16 / 1:1 / 4:5 / other

Extracted rules inside block: NONE

## 688c82448d2b58e0 — storyboard-architect/brand-packs/_template.md:62-62 (heading)

## Color grade direction

Extracted rules inside block: NONE

## 4d6551366c07e616 — storyboard-architect/brand-packs/_template.md:64-64 (paragraph)

How footage and generated images should be graded. One sentence.

Extracted rules inside block: 083e7f152f6b

## 56cc58114b1a97a3 — storyboard-architect/brand-packs/_template.md:66-66 (list_item)

> e.g. "Warm filmic, muted teal shadows, slight grain. Reminiscent of Kodak Portra 400."

Extracted rules inside block: NONE

## da0872406023df46 — storyboard-architect/brand-packs/_template.md:68-68 (heading)

## Motion language

Extracted rules inside block: NONE

## b64268d61846d9dc — storyboard-architect/brand-packs/_template.md:70-70 (paragraph)

How motion behaves in this brand's content. One paragraph.

Extracted rules inside block: NONE

## 30111d27ccc074c1 — storyboard-architect/brand-packs/_template.md:72-72 (list_item)

> e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

Extracted rules inside block: 73a660ab6755

## 0a06d5a453ac6c22 — storyboard-architect/brand-packs/_template.md:74-74 (heading)

## Voice rules

Extracted rules inside block: NONE

## 59c31d01f45a52b4 — storyboard-architect/brand-packs/_template.md:76-76 (paragraph)

Copy-level rules that apply to VO and on-screen text.

Extracted rules inside block: NONE

## 0df3bd1a11e11550 — storyboard-architect/brand-packs/_template.md:78-78 (list_item)

- e.g. no em dashes

Extracted rules inside block: NONE

## 783c5ea80a216f82 — storyboard-architect/brand-packs/_template.md:79-79 (list_item)

- no emojis in body copy

Extracted rules inside block: NONE

## 12a087009f334c10 — storyboard-architect/brand-packs/_template.md:80-80 (list_item)

- no exclamation points in headlines

Extracted rules inside block: NONE

## d65ae300dce3720e — storyboard-architect/brand-packs/_template.md:81-81 (list_item)

- no clichéd metaphors ("game-changing", "revolutionary", "next-level")

Extracted rules inside block: NONE

## 3ccf248031979037 — storyboard-architect/brand-packs/_template.md:82-82 (list_item)

- no hype words

Extracted rules inside block: NONE

## c1f7f70ae2e851c2 — storyboard-architect/brand-packs/_template.md:84-84 (heading)

## Reference materials

Extracted rules inside block: NONE

## e84c44cb2c13c1c4 — storyboard-architect/brand-packs/_template.md:86-86 (paragraph)

Optional. Links to past work, mood boards, or style guides that further define the brand.

Extracted rules inside block: NONE

## 607e876eb2c93f5e — storyboard-architect/brand-packs/_template.md:88-88 (list_item)

- Link to brand guide

Extracted rules inside block: NONE

## a3cb11b6dc7d99c8 — storyboard-architect/brand-packs/_template.md:89-89 (list_item)

- Link to past hero film

Extracted rules inside block: NONE

## 347a99923deb2a7d — storyboard-architect/brand-packs/_template.md:90-90 (list_item)

- Link to mood board

Extracted rules inside block: NONE

## d7aa8860b795d204 — storyboard-architect/brand-packs/_template.md:94-96 (paragraph)

**Last updated:** YYYY-MM-DD
**Owner:** name / role
**Version:** 1.0

Extracted rules inside block: NONE

## 4ff0fa771dee691a — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:1-2 (paragraph)

<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->

Extracted rules inside block: NONE

## 08dab628243d279b — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:4-4 (heading)

# Brand Lock: WhyStrohm

Extracted rules inside block: NONE

## c99eec4aa1dc1fd7 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:6-6 (heading)

## Identity

Extracted rules inside block: NONE

## f07cc75372f8d463 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:8-11 (paragraph)

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

Extracted rules inside block: NONE

## 16123be1e7f900dd — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:13-13 (heading)

## Palette

Extracted rules inside block: NONE
