# Rule classification review 34/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## 1d0075533417 — visual-prompt-forge/adapters/seedance.md:43

One beat, one frame | Single shot (or use Kling)

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "1d0075533417",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedance"
      }
    ]
  }
}
```

## 809c2ad96fb5 — visual-prompt-forge/adapters/seedance.md:74

**Don't force unrelated beats into one sequence.** Multi-shot is for shots that genuinely belong to one take.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "809c2ad96fb5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedance"
      }
    ]
  }
}
```

## 048f897b25c5 — visual-prompt-forge/adapters/seedance.md:75

**Don't write more than ~4 cuts per generation.** Consistency degrades past that; split and assemble in edit.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "048f897b25c5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedance"
      }
    ]
  }
}
```

## 76a577ed1882 — visual-prompt-forge/adapters/seedance.md:76

**Don't vary the character anchor between cuts.** Restate it once for the whole sequence, verbatim.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "76a577ed1882",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedance"
      }
    ]
  }
}
```

## 1e69aea69fe9 — visual-prompt-forge/adapters/seedance.md:77

**Don't include text content.** Composite captions from `text-overlays.json` in post.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "1e69aea69fe9",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "seedance"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 88e3343e529d — visual-prompt-forge/adapters/seedance.md:78

**Don't stack two camera moves inside one cut.** One move per cut.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "88e3343e529d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedance"
      }
    ]
  }
}
```

## 7df5670c97b7 — visual-prompt-forge/adapters/seedream.md:3

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "7df5670c97b7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "seedream"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 20f17c8343ed — visual-prompt-forge/adapters/seedream.md:38

**40–70 words per prompt**. Shorter than most. Don't pad.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "20f17c8343ed",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedream"
      }
    ]
  }
}
```

## df529c9e4562 — visual-prompt-forge/adapters/seedream.md:75

**Don't vary** the lighting language between shots, series_lock string in, no paraphrasing

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "df529c9e4562",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedream"
      }
    ]
  }
}
```

## 2b980155a316 — visual-prompt-forge/adapters/seedream.md:80

**Don't write paragraphs**. Seedream wants comma-separated phrases

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "2b980155a316",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedream"
      }
    ]
  }
}
```

## cf97312c16f6 — visual-prompt-forge/adapters/seedream.md:81

**Don't use `--ar` syntax**, pass aspect_ratio as a parameter

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "cf97312c16f6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedream"
      }
    ]
  }
}
```

## 6d4af2b1c810 — visual-prompt-forge/adapters/seedream.md:82

**Don't include text content**, text rendering is poor; composite separately

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "6d4af2b1c810",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "seedream"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## bed0b0adba27 — visual-prompt-forge/adapters/seedream.md:83

**Don't expect Midjourney aesthetic**. Seedream produces clean but less art-directed output

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "bed0b0adba27",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "seedream"
      }
    ]
  }
}
```

## e44a4828f32f — visual-prompt-forge/adapters/seedream.md:84

**Don't skip the seed lock for series work**, without it, character consistency breaks

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "e44a4828f32f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "seedream"
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## b1877986517b — visual-prompt-forge/adapters/veo.md:3

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "b1877986517b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "veo"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 2cb8d44c9c71 — visual-prompt-forge/adapters/veo.md:75

**Don't use Veo for silent B-roll.** You are paying for an audio engine you turned off; use Kling.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "2cb8d44c9c71",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "veo"
      }
    ]
  }
}
```

## 0f7c9aeb8f35 — visual-prompt-forge/adapters/veo.md:76

**Don't overrun the duration with dialogue.** A line that needs 12s of speech will clip or rush at 8s.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "0f7c9aeb8f35",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "veo"
      }
    ]
  }
}
```

## 2f0b1c1117c7 — visual-prompt-forge/adapters/veo.md:77

**Don't put on-screen text in the prompt.** Spoken lines are fine; rendered captions still come from `text-overlays.json` in post.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "2f0b1c1117c7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "veo"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 7421f96fc6af — visual-prompt-forge/adapters/veo.md:78

**Don't stack two camera moves.** One move per shot.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "7421f96fc6af",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "veo"
      }
    ]
  }
}
```

## bb9fa2418c71 — visual-prompt-forge/adapters/veo.md:79

**Don't let Veo's auto-audio fight a post audio bed.** Pick one owner of sound per shot.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "bb9fa2418c71",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "veo"
      }
    ]
  }
}
```

## 73d5b86aaf30 — visual-prompt-forge/adapters/veo.md:83

Veo clips arrive with audio attached. They still need: editorial assembly to timing, on-screen text compositing from `text-overlays.json`, a color-grade pass, and an audio decision, keep Veo's native track, or mute it and use the storyboard's recorded VO and music. State which in handoff.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "73d5b86aaf30",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "veo"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## c8b6ffda298d — visual-prompt-forge/examples/one-shot-all-adapters/README.md:3

This example takes a single shot from the WhyStrohm 30-second pitch and renders it through the generator adapters in the pack. Use it as a calibration reference: same intent, same data, different prompt syntaxes. Six stills adapters are shown, plus the default motion adapter (Kling) standing in for the motion video lane.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "c8b6ffda298d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 2b19da8c2aea — visual-prompt-forge/examples/one-shot-all-adapters/README.md:63

The on-screen text content. Even though shot_04 has an on-screen text overlay (`text_03`, "You don't have a content problem. You have an infrastructure problem."), none of the prompts contain that text. It's composited separately per the five-layer model.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "2b19da8c2aea",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 9ef19434032d — visual-prompt-forge/references/consistency-locks.md:33

Same principle for `series_lock.lighting`. Lighting direction in particular is critical, flipping window-left to window-right between shots produces obvious cuts where there shouldn't be any.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "9ef19434032d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "continuity.level",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## b462b8394f70 — visual-prompt-forge/references/consistency-locks.md:60

Generate the hero shot first (any shot, usually `shot_01` or whichever is most defining)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "b462b8394f70",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "continuity.level",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 3935d4158c07 — visual-prompt-forge/references/consistency-locks.md:61

Use that image as the reference for every subsequent shot

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "3935d4158c07",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "not_in",
            "path": "continuity.level",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 38f9f3067723 — visual-prompt-forge/references/consistency-locks.md:62

Each subsequent prompt has the verbatim character anchor PLUS the reference image link

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "38f9f3067723",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "not_in",
            "path": "continuity.level",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 22d338e382a0 — visual-prompt-forge/references/consistency-locks.md:70

**This is the most effective lock for character consistency** in 2026. Use it whenever the storyboard features the same person across multiple shots.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "22d338e382a0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "not_in",
            "path": "continuity.level",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## bef0fed7f638 — visual-prompt-forge/references/consistency-locks.md:74

When the storyboard has a distinctive visual style (specific film stock, specific lighting school, specific color theory), use a style reference image:

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "bef0fed7f638",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "not_in",
            "path": "continuity.level",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 78ffb0d37f72 — visual-prompt-forge/references/consistency-locks.md:84

A subtle one that breaks scenes when violated. If `series_lock.lighting` says "soft natural side-light, large window LEFT", then every shot's lighting must respect that direction.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "78ffb0d37f72",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "continuity.level",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 76f3265ebf27 — visual-prompt-forge/references/consistency-locks.md:86

When a shot reverses character orientation (e.g., over-the-shoulder reverse), update the rationale to acknowledge the lighting flip:

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "76f3265ebf27",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "continuity.level",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## d5bcf85dd207 — visual-prompt-forge/references/consistency-locks.md:113

A few things people try that don't actually fix consistency:

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d5bcf85dd207",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "continuity.level",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 7b3702dfb9b2 — visual-prompt-forge/references/consistency-locks.md:115

**Adding "consistent character" or "same person" to the prompt**, generators don't read meta-instructions

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "7b3702dfb9b2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "not_in",
            "path": "continuity.level",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## d2a5a9d6f2cc — visual-prompt-forge/references/consistency-locks.md:116

**Numbering shots in the prompt** ("shot 3 of 7, same as before"), generators don't have memory across calls

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d2a5a9d6f2cc",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "continuity.level",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 09c105d7a76f — visual-prompt-forge/references/consistency-locks.md:118

**Asking for "exactly the same"**, there is no such thing in stateless image gen; you reduce drift, you don't eliminate it

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "09c105d7a76f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "continuity.level",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```
