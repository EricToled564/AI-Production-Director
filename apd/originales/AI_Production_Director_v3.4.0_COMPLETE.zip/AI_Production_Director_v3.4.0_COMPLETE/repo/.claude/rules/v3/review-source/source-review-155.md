# Source coverage review 155/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c1778c88a67a6d0c — video/references/kling.md:209-209 (paragraph)

Required angles.

Extracted rules inside block: 7449672e1c17

## 6d6c64a6ec6b79dc — video/references/kling.md:211-211 (list_item)

- Front

Extracted rules inside block: NONE

## 3b5bf54b70c7bc24 — video/references/kling.md:212-212 (list_item)

- Side (profile)

Extracted rules inside block: NONE

## 421bc38f0f7eff7b — video/references/kling.md:213-213 (list_item)

- Three-quarter

Extracted rules inside block: NONE

## 7d4efe0e194e4565 — video/references/kling.md:215-215 (paragraph)

Then in Image-to-Video settings, enable "Bind Elements" to lock features. This gives the AI a visual anchor that survives camera pans and light changes.

Extracted rules inside block: NONE

## 38d9e2ed175ea7a6 — video/references/kling.md:217-217 (paragraph)

Source image rules.

Extracted rules inside block: NONE

## 68b42625a522c7cc — video/references/kling.md:219-219 (list_item)

- 1080p or higher.

Extracted rules inside block: NONE

## 4a62d154957ff5a0 — video/references/kling.md:220-220 (list_item)

- Even lighting. Avoid hard shadows. The AI can mistake them for permanent facial features.

Extracted rules inside block: b78a033176fb

## 2b88153e12161724 — video/references/kling.md:221-221 (list_item)

- No text or watermarks.

Extracted rules inside block: NONE

## fb0da65bb7043aa0 — video/references/kling.md:222-222 (list_item)

- Clean uncluttered background.

Extracted rules inside block: NONE

## c9245c2759d286ba — video/references/kling.md:223-223 (list_item)

- Centered subject.

Extracted rules inside block: NONE

## 13f0133d89fb6ce7 — video/references/kling.md:224-224 (list_item)

- Well-contrasted.

Extracted rules inside block: NONE

## 14f020fc45c0a5da — video/references/kling.md:226-226 (paragraph)

For Kling 3.0 — Element Library still works, but the in-prompt `[Character A: ...]` labels (see section 3) are usually enough on their own.

Extracted rules inside block: NONE

## ebe3a7bab2cc2ef3 — video/references/kling.md:228-228 (heading)

### Elements 3.0 (Omni)

Extracted rules inside block: NONE

## ba750528f5af8aa6 — video/references/kling.md:230-230 (paragraph)

On 3.0 Omni the element system got deeper:

Extracted rules inside block: NONE

## 284370d8d7cb00b2 — video/references/kling.md:232-232 (list_item)

- A character element takes either a **3-8s video** (the model extracts both appearance and voice) or up to **4 multi-angle stills** (front, three-quarter, profile, back), plus optional **voice binding** (5-30s audio clip). Once bound, the voice belongs to the subject — do not re-describe it in the prompt.

Extracted rules inside block: 1d11893cca49

## 5153eab3790794a5 — video/references/kling.md:233-233 (list_item)

- Define a character / product / location **once** as an element, then tag it in prose: `@Grace picks up the folder`. The prompt carries only action and camera; identity lives in the element.

Extracted rules inside block: NONE

## 6e12aaa85aa56435 — video/references/kling.md:234-234 (list_item)

- Holds 3+ distinct characters in frame without feature blending — but only if **each** has its own element.

Extracted rules inside block: NONE

## 4246968f445e7be3 — video/references/kling.md:235-235 (list_item)

- Cost of the feature: several practitioners report visible image-quality degradation the moment elements/references are enabled. Use elements only when consistency actually matters; for one-off clips, in-prompt labels are cleaner.

Extracted rules inside block: ffa8b89c5945

## 665c05d8c7588b3c — video/references/kling.md:237-237 (heading)

## 8. Motion Brush (unique)

Extracted rules inside block: NONE

## 590d4fb88eb24f5d — video/references/kling.md:239-239 (paragraph)

Animate up to 6 regions of a single image independently. Each region gets its own motion path.

Extracted rules inside block: NONE

## 1ce0a89fdd976cee — video/references/kling.md:241-241 (paragraph)

Critical rule. The text prompt MUST match the brush motion. If you brush a river flowing and write "stagnant pond" the model tears itself apart. Align prompt verbs with brush directions.

Extracted rules inside block: 8d9febeaf2b7

## d9bdec6e2849a948 — video/references/kling.md:243-243 (heading)

## 9. Motion Control (2.6 Pro, unique)

Extracted rules inside block: NONE

## 46ca96f05be704a1 — video/references/kling.md:245-245 (paragraph)

Copy motion from a reference video. Use when you need specific performance or choreography (dance, martial arts, specific gait). The prompt then focuses on subject description only, the reference handles motion.

Extracted rules inside block: 62bf7945f8c5

## a40387da437a085d — video/references/kling.md:247-247 (heading)

## 10. Image-to-video rule

Extracted rules inside block: NONE

## aff06a510d2262a1 — video/references/kling.md:249-249 (paragraph)

Keep the prompt short (20-40 words). Focus only on motion. Do not re-describe static elements the model already sees.

Extracted rules inside block: 98e53bb5512f

## 4d7b30300a3bc7a5 — video/references/kling.md:251-251 (paragraph)

Include explicit continuity cues. Kling responds well to "preserve X" instructions.

Extracted rules inside block: NONE

## 61efa820f8c88fd7 — video/references/kling.md:253-253 (paragraph)

Example.

Extracted rules inside block: NONE

## cdae9a4a933983c2 — video/references/kling.md:255-257 (code)

```text
Preserve silhouette and label text. Slow tracking shot from the side. She turns her head toward camera. Wind catches her hair. 35mm, golden hour rim light.
```

Extracted rules inside block: NONE

## 8e39b2709714980d — video/references/kling.md:259-259 (paragraph)

For Kling 3.0 image-to-video — see section 3 ("Image-to-video on 3.0 — lock first, then move").

Extracted rules inside block: NONE
