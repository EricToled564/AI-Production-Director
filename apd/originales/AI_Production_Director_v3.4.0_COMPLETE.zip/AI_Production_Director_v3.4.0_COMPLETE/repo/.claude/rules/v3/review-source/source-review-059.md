# Source coverage review 59/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c456156c17a93c27 — image/references/patterns/food-beverage.md:91-91 (list_item)

- `{prop_list}` — linen napkin, vintage fork, small bowl of sauce, scattered herbs

Extracted rules inside block: NONE

## 254b97d69ee8e450 — image/references/patterns/food-beverage.md:92-92 (list_item)

- `{food_lighting}` — warm directional from upper-left with fill bounce, harsh noon daylight, moody side light

Extracted rules inside block: NONE

## d3f64ada551e0ccc — image/references/patterns/food-beverage.md:93-93 (list_item)

- `{background_treatment}` — dark vignette, clean bright, rustic blur

Extracted rules inside block: NONE

## 93c4f222494f9acc — image/references/patterns/food-beverage.md:94-94 (list_item)

- `{camera_angle}` — 45-degree three-quarter, straight-on eye-level, overhead flat-lay

Extracted rules inside block: NONE

## 23ff9e46f024cf62 — image/references/patterns/food-beverage.md:96-96 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — steam, condensation, and ingredient texture fidelity

Extracted rules inside block: bbeda24dae03

## 6bfe3bc2c5172e8e — image/references/patterns/food-beverage.md:100-100 (heading)

## Naturalist Food Specimen Cross-Section

Extracted rules inside block: NONE

## bd7381c563bd0b16 — image/references/patterns/food-beverage.md:102-102 (paragraph)

Use for educational food content, ingredient features, or artisanal brand storytelling — the food item rendered as a scientific illustration in the style of 19th-century naturalist prints.

Extracted rules inside block: 41fa33d29353

## 54eb12eb69229ec1 — image/references/patterns/food-beverage.md:104-104 (paragraph)

<!-- Source concept: Audubon-style naturalist botanical/food specimen illustration with cross-section -->

Extracted rules inside block: NONE

## c91c62fc8e02d7db — image/references/patterns/food-beverage.md:106-106 (paragraph)

A detailed naturalist illustration of {food_item} rendered in the style of 19th-century scientific specimen plates. The composition shows the item in three states arranged vertically on an aged {paper_color} parchment background: whole specimen at top with botanical accuracy, lateral cross-section at center revealing internal structure ({internal_details}), and an exploded detail of {detail_element} at bottom with fine ink annotation lines pointing to key features. Drawn with precise {medium_description} — visible hatching for shadow, stippling for texture, thin ink outlines. Color is naturalistic but slightly muted as if from a hand-tinted lithograph. A thin decorative border frames the composition. Small italic Latin-style label "{latin_label}" at the bottom in serif font, {ink_color} ink. Format: 3:4.

Extracted rules inside block: NONE

## c14961695a2f82d3 — image/references/patterns/food-beverage.md:108-108 (paragraph)

**Key levers:** `{food_item}` (pomegranate, sourdough loaf, wagyu ribeye, cacao pod), `{internal_details}` (seed chambers with ruby arils, crumb structure with irregular air pockets, marbling fat distribution), `{detail_element}` (individual seed anatomy, crust layering, fat crystal structure), `{paper_color}` (warm cream #FDF5E6, cool ivory #FFFFF0), `{medium_description}` (watercolor wash with ink line, graphite with colored pencil, pure ink with minimal color), `{latin_label}` (a playful Latinized name), `{ink_color}` (sepia #704214, India black #1A1A1A)

Extracted rules inside block: NONE

## 610a1f0c314174c6 — image/references/patterns/food-beverage.md:110-110 (paragraph)

**Recommended model:** NB2 — naturalist illustration style, grounding on botanical plate aesthetics

Extracted rules inside block: e78d36ffd533

## c245420ce83d398b — image/references/patterns/food-beverage.md:114-114 (heading)

## City Food Map Illustration

Extracted rules inside block: NONE

## 2eae9b4e18a967a3 — image/references/patterns/food-beverage.md:116-116 (paragraph)

Use for restaurant guides, food festival materials, travel content, or local cuisine features — a bird's-eye illustrated map showing food specialties across a city.

Extracted rules inside block: 34a670fb6a2e

## b26fc21725a71a47 — image/references/patterns/food-beverage.md:118-118 (paragraph)

<!-- Source concept: hand-drawn illustrated food map of a city with dish icons and landmarks -->

Extracted rules inside block: NONE

## bcbd348f5d387c3a — image/references/patterns/food-beverage.md:120-120 (paragraph)

A hand-drawn illustrated bird's-eye map of {city_name} showing its food culture. The map covers the {area_description} with simplified but recognizable {landmark_list} drawn in a loose ink-and-watercolor style. Scattered across the map are {dish_count} illustrated food items representing local specialties — each dish ({dish_list}) drawn at exaggerated scale hovering near its neighborhood, rendered in warm appetizing watercolor with visible brushstrokes. Streets are thin ink lines with {street_style}. Water features rendered in soft {water_color} wash. The overall palette is {palette_description}. A decorative hand-lettered title "{MAP_TITLE}" sits in a banner at the top. Small hand-written labels mark each dish and neighborhood. Style references vintage travel poster illustration meets editorial food drawing. Format: {aspect_ratio}.

Extracted rules inside block: NONE

## c60007f772dc1ef6 — image/references/patterns/food-beverage.md:122-122 (paragraph)

**Key levers:** `{city_name}`, `{area_description}` (central 5 km, old town quarter, waterfront district), `{landmark_list}` (main cathedral, central market, river bridges), `{dish_count}` (6-10), `{dish_list}` (plov near the bazaar, samsa near the old town, shashlik near the park), `{street_style}` (slightly wobbly freehand, clean but simplified), `{water_color}` (cerulean #0077B6, teal #2A9D8F), `{palette_description}` (warm terracotta and cream with food items in full saturated color, cool blues and greens with warm food accents), `{MAP_TITLE}` ("A Taster's Guide to {city_name}"), `{aspect_ratio}` (3:4, 1:1)

Extracted rules inside block: NONE

## 6da29c49e79ad1cc — image/references/patterns/food-beverage.md:124-124 (paragraph)

**Recommended model:** NB2 — image grounding for real city landmarks + illustration style

Extracted rules inside block: fc985cfb25ad

## 4fd7282bd737e61f — image/references/patterns/food-beverage.md:126-126 (heading)

### Nano Banana version:

Extracted rules inside block: NONE

## ea62076f2c06e142 — image/references/patterns/food-beverage.md:128-130 (code)

```
A hand-drawn illustrated bird's-eye food map of {city_name}, covering the {area_description}. Simplified but recognizable {landmark_list} are drawn in loose ink-and-watercolor style. {dish_count} local dishes ({dish_list}) float at exaggerated scale near their neighborhoods, each painted in warm appetizing watercolor with visible brushstrokes. Streets are thin freehand ink lines. Water features in soft {water_color} wash. A hand-lettered banner at top reads "{MAP_TITLE}". Small hand-written labels mark dishes and neighborhoods. Style mixes vintage travel poster illustration with editorial food drawing. Palette: {palette_description}. Format: {aspect_ratio}.
```

Extracted rules inside block: NONE

## 36c1a1b4dcebd83c — image/references/patterns/food-beverage.md:134-134 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 894e9843af897f1f — image/references/patterns/portrait-cinema.md:1-1 (heading)

# Portrait & Cinema Patterns

Extracted rules inside block: NONE

## ba9464eec156783a — image/references/patterns/portrait-cinema.md:3-3 (paragraph)

Reusable prompt templates for cinematic portraits, atmospheric character photography, and mood-driven portraiture. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

Extracted rules inside block: NONE

## 70ad37b4392b2974 — image/references/patterns/portrait-cinema.md:7-7 (heading)

## Golden Hour Street Backlit Portrait

Extracted rules inside block: NONE

## 2a95c4767449bdf5 — image/references/patterns/portrait-cinema.md:9-9 (paragraph)

Use for warm, emotive street portraits with strong backlight flare — editorial, personal branding, album covers.

Extracted rules inside block: 15636f3c7b42

## 89433f21ff5cddb8 — image/references/patterns/portrait-cinema.md:11-11 (paragraph)

<!-- Source concept: golden hour backlit street portrait with lens flare and warm atmospheric haze -->

Extracted rules inside block: NONE

## 1c3a8c43deec2746 — image/references/patterns/portrait-cinema.md:13-19 (code)

```
Scene: {street_description} at golden hour, sun positioned directly behind subject (5-10 degrees above horizon line), warm amber light flooding the street, slight atmospheric haze diffusing the backlight
Subject: {person_description}, standing at {position_in_street}, body angled three-quarter to camera, face turned toward lens with {expression}
Important Details: strong rim light outlining hair and shoulders in warm gold (#FFAA33), face lit primarily by bounce light from {bounce_surface} on the opposite side — softer and cooler than the backlight, shallow depth of field rendering background into warm bokeh circles, {clothing_detail} catches backlight along edges showing fabric texture, visible lens flare — one or two hexagonal flare artifacts near frame edge (organic, not excessive), long shadow cast toward camera on {ground_surface}, skin rendered naturally with warm undertones — no heavy smoothing, visible pores, {color_grade}
Use Case: editorial portrait, personal brand photography, album art
Constraints: face must be visible and well-exposed despite backlight (not silhouetted), no reflectors or studio equipment visible, lens flare limited to one or two subtle artifacts — not a starburst explosion, no added text, no vignette
```

Extracted rules inside block: NONE

## e0421abd5875e4c8 — image/references/patterns/portrait-cinema.md:21-21 (paragraph)

**Key levers:** `{street_description}` (narrow European alley with stone walls, wide boulevard with linden trees, industrial backstreet with brick), `{person_description}`, `{expression}` (quiet confidence, mid-smile with closed lips, contemplative gaze), `{bounce_surface}` (cream-painted wall, parked white van, sand-colored buildings), `{clothing_detail}` (linen shirt collar, leather jacket shoulder seam, scarf edge), `{ground_surface}` (wet cobblestones, dry asphalt, packed earth), `{color_grade}` (Kodak Portra 400 warmth, slightly lifted blacks with amber cast, clean digital with warm white balance)

Extracted rules inside block: 6142246a3de0

## ae2bdc5b00bae5df — image/references/patterns/portrait-cinema.md:23-23 (paragraph)

**Recommended model:** GPT Image 2 — backlight exposure control and skin rendering

Extracted rules inside block: c9d745ca2d82

## 11dcb26830071d72 — image/references/patterns/portrait-cinema.md:27-27 (heading)

## Convenience Store Neon Portrait

Extracted rules inside block: NONE

## 2e77437e66b5be8f — image/references/patterns/portrait-cinema.md:29-29 (paragraph)

Use for urban night portraits with mixed artificial lighting — fluorescent overhead + colored neon signage creating a chromatic push-pull on the subject's face.

Extracted rules inside block: 0518f1160c29
