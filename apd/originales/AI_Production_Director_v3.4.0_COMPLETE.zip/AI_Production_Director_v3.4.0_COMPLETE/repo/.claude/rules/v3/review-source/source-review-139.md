# Source coverage review 139/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 1de72f843365f587 — video/references/camera-lighting-vocabulary.md:244-244 (list_item)

- **ink-wash dissolve** — stylized bleed, common in guofeng / animation work

Extracted rules inside block: NONE

## f26d7f6eafe012e3 — video/references/camera-lighting-vocabulary.md:246-246 (paragraph)

Rules of use. Name the transition and the exact moment it fires. One transition type per cut. When the choice is open, delegate: "choose the most suitable from [natural cut / occlusion mask / match cut] for the style of this film."

Extracted rules inside block: 02aa19d9c833

## 23855f8e53949a41 — video/references/camera-lighting-vocabulary.md:250-250 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## f751bf56cc9eae71 — video/references/dramaturgy.md:1-1 (heading)

# Dramaturgy, detail, montage

Extracted rules inside block: NONE

## 766f73eec1b53da4 — video/references/dramaturgy.md:3-3 (paragraph)

This is the mandatory layer. A beautiful frame without dramaturgy is wallpaper. Every prompt built by this skill must pass the dramaturgy check before it is sent to the user.

Extracted rules inside block: 86b32d5d66d3

## 02db4ba2dd9e1340 — video/references/dramaturgy.md:5-5 (heading)

## Contents

Extracted rules inside block: NONE

## f23833eb5901dbc3 — video/references/dramaturgy.md:7-7 (list_item)

1. Core law. Scene formula

Extracted rules inside block: 479e77aad455

## f7292ebb9e2a42bd — video/references/dramaturgy.md:8-8 (list_item)

2. Second law. Details intensify emotion

Extracted rules inside block: a1a18fee60a3

## 8c31c2e6fea3fe3b — video/references/dramaturgy.md:9-9 (list_item)

3. The three-jobs rule (what every shot must do)

Extracted rules inside block: 0d7199d6f27f

## 67af460d9b8e6d4b — video/references/dramaturgy.md:10-10 (list_item)

4. Walter Murch Rule of Six

Extracted rules inside block: a5dbcb81080e

## 208ebc7c7e88385e — video/references/dramaturgy.md:11-11 (list_item)

5. Blocking as choreography of desire

Extracted rules inside block: adf441ccfbcc

## dda4738f6c997de4 — video/references/dramaturgy.md:12-12 (list_item)

6. Staging controls subtext

Extracted rules inside block: 027c6e566ecf

## 5c646cf4ba35436f — video/references/dramaturgy.md:13-13 (list_item)

7. Camera must have a reason

Extracted rules inside block: 75dd25364868

## 2eccf7a9d3d0fd7d — video/references/dramaturgy.md:14-14 (list_item)

8. Spatial clarity beats montage hysteria

Extracted rules inside block: 7973365cff72

## 4d7e049ecff49631 — video/references/dramaturgy.md:15-15 (list_item)

9. Environment plays

Extracted rules inside block: 56080e651eb3

## 1f08c942f89ede78 — video/references/dramaturgy.md:16-16 (list_item)

10. Three-layer storyboard method

Extracted rules inside block: ecf444cb8b44

## e2d4416185fa814f — video/references/dramaturgy.md:17-17 (list_item)

11. Shot card template (14 fields)

Extracted rules inside block: cedac221d541

## d612126ebc53345b — video/references/dramaturgy.md:18-18 (list_item)

12. Rhythm ladder

Extracted rules inside block: 0f9b3b9bbc39

## 7824d79dd95cb98b — video/references/dramaturgy.md:19-19 (list_item)

13. One-anchor principle

Extracted rules inside block: 0fa3c7060a92

## d24dbc6debee12b5 — video/references/dramaturgy.md:20-20 (list_item)

14. Worked example

Extracted rules inside block: 5046f1e31401

## d1170d97452a0321 — video/references/dramaturgy.md:21-21 (list_item)

15. Dramaturgy check before sending any prompt

Extracted rules inside block: fb39bdd69c68

## c051813f78451825 — video/references/dramaturgy.md:25-25 (heading)

## 1. Core law. Scene formula

Extracted rules inside block: NONE

## 2e24592fab7c1d89 — video/references/dramaturgy.md:27-27 (paragraph)

A scene exists only when all five elements are present.

Extracted rules inside block: NONE

## 484873c73f71bbeb — video/references/dramaturgy.md:29-31 (code)

```text
Scene = hero's desire + obstacle + space geometry + controlled gaze + editing rhythm
```

Extracted rules inside block: NONE

## 05349264769abeec — video/references/dramaturgy.md:33-33 (paragraph)

If any element is missing, the scene collapses into decoration.

Extracted rules inside block: NONE

## 15ceb2298005db62 — video/references/dramaturgy.md:35-35 (list_item)

- Desire. What does the character want right now in this specific second.

Extracted rules inside block: NONE

## e031a144eed50aa9 — video/references/dramaturgy.md:36-36 (list_item)

- Obstacle. What blocks them. Object, person, fear, distance, rule.

Extracted rules inside block: NONE

## 45468948aa8c43b5 — video/references/dramaturgy.md:37-37 (list_item)

- Space geometry. Who stands where. Who has the power position. Which direction is threat, which is escape.

Extracted rules inside block: NONE

## dad57d2a9abbda7d — video/references/dramaturgy.md:38-38 (list_item)

- Controlled gaze. Where the viewer's eye is forced to look, one focal point per frame.

Extracted rules inside block: NONE

## 6fe4d289237cf84a — video/references/dramaturgy.md:39-39 (list_item)

- Editing rhythm. How long each shot lives, where the pause lands, where the cut bites.

Extracted rules inside block: NONE
