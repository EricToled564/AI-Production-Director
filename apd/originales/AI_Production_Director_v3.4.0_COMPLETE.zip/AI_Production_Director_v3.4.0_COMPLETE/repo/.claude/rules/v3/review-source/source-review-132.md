# Source coverage review 132/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0ef3fbcfe436e188 — video/references/animatic-keyframes.md:199-199 (table_row)

| 6.5–8.0 | Stage bulb + knuckles | Pressure | Second bulb lit, knuckles whiten on the trans-brake (depth: bulb BG, hand FG) | CU, depth layers, static | two blue bulbs, crushed black | idle DROPS to silence | point of no return |

Extracted rules inside block: NONE

## 45d7228d1bc0fa9e — video/references/animatic-keyframes.md:200-200 (table_row)

| 8.0–9.5 | Amber stagger (1 of 3) | Pressure → Shift | First amber lights; foot pre-loading the pedal | tree-cam, snap-tight | amber pulse (sole warm, toxic) | vacuum of silence | trigger tension |

Extracted rules inside block: NONE

## 6c7ca8aa7c6de6f3 — video/references/animatic-keyframes.md:201-201 (table_row)

| 9.5–10.3 | Held breath frame | Pressure | Staged car dead-still, last amber, tach needle the only tremor | symmetric, locked (HOLD) | amber flare, steel rim | silence (the pause) | loaded spring |

Extracted rules inside block: NONE

## b6fa05e3d612adab — video/references/animatic-keyframes.md:202-202 (table_row)

| 10.3–11.6 | LAUNCH lunge | Impact | Both cars squat, front wheels lift, green flares, asphalt smears back | low bumper-POV, fisheye (smear) | green flash + hard flare | BANG, leads pic 3fr | release / violence |

Extracted rules inside block: NONE

## 1d4c8af3c0f84cf9 — video/references/animatic-keyframes.md:203-203 (table_row)

| 11.6–13.5 | **Slick wrinkle** (HOLD) | Detail / Reaction | Sidewall folds and hooks at the contact patch; speed-ramp pause, partial blur | macro slick-cam (frozen ramp) | hard side light, smoke bloom | tyre bite (near-silent) | physics felt |

Extracted rules inside block: NONE

## e71b09e77e87d873 — video/references/animatic-keyframes.md:204-204 (table_row)

| 13.5–15.5 | Cabin shake | Pressure | Needle buried in red, mirror doubled by vibration, glass strobing | hard-mount interior (tremor) | strobing exterior, red needle accent | rising rev, gear stab | strain |

Extracted rules inside block: NONE

## 3b9d79c455c4c6ab — video/references/animatic-keyframes.md:205-205 (table_row)

| 15.5–18.5 | Bumper POV | Pressure | Asphalt tears under the nose, lane stripes strobe to a vanishing point | low forward hood-cam, 24mm (radial smear) | streaked specular, mercury-white | doppler build | commitment |

Extracted rules inside block: NONE

## 652f4189c374bd4b — video/references/animatic-keyframes.md:206-206 (table_row)

| 18.5–22.5 | Joust / parallel pass | Power | Rival closes head-on, offset; cone huge-blurred on the opposite edge | chase tracking + joust (closing) | streaked roadside lights, red tail accent | engine duel, doppler swell | rivalry |

Extracted rules inside block: NONE

## 2b10073d73bd731e — video/references/animatic-keyframes.md:207-207 (table_row)

| 22.5–26.5 | Finish | Impact | Slicks blown-up and distorted, two cars inches apart across the line | slight high, finish-cam | cold-white finish pool | sound peak → cut | margin |

Extracted rules inside block: NONE

## 5c719c286a984f12 — video/references/animatic-keyframes.md:208-208 (table_row)

| 26.5–30.0 | Hand unclenches / chute | Aftermath / Exit | Fingers release the wheel; chute bloomed, smoke drifting through a beam | ECU then rear wide (settling) | single cold rim, residue haze | hard cut to silence, one breath | consequence / release |

Extracted rules inside block: NONE

## 490dfc3ad7bde8b8 — video/references/animatic-keyframes.md:210-210 (paragraph)

Notes on the board: the 9.5–10.3 held panel is the single most-held still — the pause that triggers the bang. The launch is *not* one hero frame; in a fuller cut, fan 10.3–11.6 into a 6-9 panel micro-burst (§3) — that expansion is what carries the 13 compressed rows up to the ~18-26 panel count of §3. The wrinkle is the one place time expands inside the loud section. No two bang-clusters touch; every burst is separated by a held quiet panel. End on consequence, held ~2s — the vacuum is the punctuation.

Extracted rules inside block: NONE

## 5122c9d049aca53b — video/references/animatic-keyframes.md:214-214 (heading)

## 9. Checklist: does this keyframe earn its place

Extracted rules inside block: NONE

## 4a00f124bf2592a1 — video/references/animatic-keyframes.md:216-216 (paragraph)

Run before every panel ships. Drop the panel if it fails.

Extracted rules inside block: NONE

## efacca323ba96127 — video/references/animatic-keyframes.md:218-218 (list_item)

- [ ] **Function tag named.** One of Establish / Reveal / Power / Pressure / Detail / Reaction / Shift / Impact / Aftermath / Exit. No tag → drop it.

Extracted rules inside block: NONE

## 877961dca5581e1e — video/references/animatic-keyframes.md:219-219 (list_item)

- [ ] **One readable beat**, sayable in one sentence. If you cannot caption it (setup / commitment / mistake / recovery / proof-of-speed / result), it is a *fantik* — drop it.

Extracted rules inside block: NONE

## daa75e07fcd47510 — video/references/animatic-keyframes.md:220-220 (list_item)

- [ ] **Emotion-via-object** present — the feeling a face would carry, frozen in a knuckle / needle / pedal / smoke / sweat-bead (§5). No state-change, no emotion → drop it.

Extracted rules inside block: NONE

## ea99cd3f01376dd1 — video/references/animatic-keyframes.md:221-221 (list_item)

- [ ] **Speed or drama cue** present — ≥1 of the six motion-as-still cues (smear / partial blur / streak / vector / sharp-blur / held stillness), or a deliberate held-still pause. "Fast" panels carry ≥3 of the five speed cues (§4).

Extracted rules inside block: NONE

## 26b82e3b7f100f14 — video/references/animatic-keyframes.md:222-222 (list_item)

- [ ] **State-change, not static fetish** — the object crosses a threshold (idle→flare, clean→smoked, planted→lifting). No idle anatomy, no parked gear-lever.

Extracted rules inside block: NONE

## 7979b34704449d5b — video/references/animatic-keyframes.md:223-223 (list_item)

- [ ] **Three depth layers**, each with a stated job (FG frame/obstruct, MG subject, BG stake). One focal point; every other object is evidence, not decoration.

Extracted rules inside block: NONE

## 2e1f5639e006a359 — video/references/animatic-keyframes.md:224-224 (list_item)

- [ ] **Implied camera named** — the move this still is the first frame of, physically mountable on the car (no god-angle render).

Extracted rules inside block: NONE

## c8b5046e7c3d2352 — video/references/animatic-keyframes.md:225-225 (list_item)

- [ ] **Cold palette held** — steel/cyan/magenta/mercury-white, red and green as accents only, amber ≤15% and point-source (toxic, never cozy). One motivated source, ~70% unlit, one hard specular hit. Texture named (grain, halation, one flare), not "clean."

Extracted rules inside block: 12f5c2518511

## f823237b1c3badc8 — video/references/animatic-keyframes.md:226-226 (list_item)

- [ ] **No face**, or a face fragmented past usefulness (silhouette / reflection only).

Extracted rules inside block: NONE

## 5b4956312d216a27 — video/references/animatic-keyframes.md:227-227 (list_item)

- [ ] **Sound cell filled** even though the panel is a still — what audio underlies the held frame, where the cut bites (`dramaturgy.md` §11).

Extracted rules inside block: NONE

## d25a003c3f23c722 — video/references/animatic-keyframes.md:228-228 (list_item)

- [ ] **Earns its density slot** — a held beat gets one panel, a bang gets a burst; the board reads as an accelerating tachometer on mute (§3).

Extracted rules inside block: NONE

## da1e32d1aa5f1e11 — video/references/animatic-keyframes.md:230-230 (paragraph)

If a panel survives all ten, it is an *opornyi kadr*, not wallpaper. Hand it to `seedance.md` / `kling.md` / `veo.md` as the locked first frame.

Extracted rules inside block: NONE

## 2a490c98eb02933f — video/references/animatic-keyframes.md:234-234 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 7348d5399763196a — video/references/camera-lighting-vocabulary.md:1-1 (heading)

# Camera, lighting, color, sound vocabulary

Extracted rules inside block: NONE

## 0edb1f11f49bc30f — video/references/camera-lighting-vocabulary.md:3-3 (paragraph)

Use precise production language. "Cinematic" is not a direction. "35mm, slow push-in, warm window key from frame-left" is.

Extracted rules inside block: 3d060f8d9326

## cb80263c129eb037 — video/references/camera-lighting-vocabulary.md:5-5 (heading)

## Contents

Extracted rules inside block: NONE

## 8682825763eb19fa — video/references/camera-lighting-vocabulary.md:7-7 (list_item)

1. Framing

Extracted rules inside block: NONE
