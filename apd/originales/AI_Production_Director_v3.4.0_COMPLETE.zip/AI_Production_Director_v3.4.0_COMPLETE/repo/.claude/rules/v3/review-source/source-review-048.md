# Source coverage review 48/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 06ce07938a2b2d43 — image/references/multi-panel.md:3-3 (paragraph)

Single-image layouts containing multiple frames, panels, or grid cells. Unlike [storyboards.md](storyboards.md) (sequential images generated one-at-a-time), these patterns produce **one image** with all panels baked in.

Extracted rules inside block: NONE

## fee50fecc2913683 — image/references/multi-panel.md:5-5 (paragraph)

Core principle: explicitly number and describe every panel. Models need panel-by-panel instructions — vague requests like "show multiple angles" produce inconsistent grids.

Extracted rules inside block: NONE

## 2c6671c55ad7b909 — image/references/multi-panel.md:9-9 (heading)

## 1. 9-Cell Grid Storyboard

Extracted rules inside block: NONE

## fb37bdad85a4154f — image/references/multi-panel.md:11-11 (list_item)

> For a product-focused narrative variant, see [patterns/ecommerce.md](patterns/ecommerce.md#9-panel-tvc-storyboard-grid).

Extracted rules inside block: NONE

## 29b0de81a55bdeee — image/references/multi-panel.md:13-13 (paragraph)

**When to use:** TVC or commercial shot breakdown — one image = 9 panels with scene titles and timestamps.

Extracted rules inside block: 8d6fa38ceae4

## c874de1fa4fd0024 — image/references/multi-panel.md:15-15 (heading)

### Template (5-slot format)

Extracted rules inside block: NONE

## 4c2ece97a2ba72cf — image/references/multi-panel.md:17-37 (code)

```
Scene: Dark storyboard layout — 3x3 grid of cinematic frames for a {duration}-second {product_name} commercial. Each cell has a thin dark border. Below each cell: scene number, title, and timestamp in small white sans-serif text on dark background.

Subject: {product_name} commercial storyboard showing the complete narrative arc across 9 panels.

Important Details:
Panel 1 (0:00–{t1}): {scene_1_description}
Panel 2 ({t1}–{t2}): {scene_2_description}
Panel 3 ({t2}–{t3}): {scene_3_description}
Panel 4 ({t3}–{t4}): {scene_4_description}
Panel 5 ({t4}–{t5}): {scene_5_description}
Panel 6 ({t5}–{t6}): {scene_6_description}
Panel 7 ({t6}–{t7}): {scene_7_description}
Panel 8 ({t7}–{t8}): {scene_8_description}
Panel 9 ({t8}–{duration}): {scene_9_description}

Each panel labeled below: "Scene {N}: {title}" and "{start}–{end}"

Use Case: Pre-production storyboard for video production team
Constraints: All 9 panels must be clearly separated, no merged cells, every panel must contain distinct content, timestamps must be legible, {language} titles
```

Extracted rules inside block: NONE

## 58998d8c5b15becd — image/references/multi-panel.md:39-39 (paragraph)

**Variables:**

Extracted rules inside block: NONE

## d4725c930202bb98 — image/references/multi-panel.md:40-40 (list_item)

- `{product_name}` — brand/product

Extracted rules inside block: NONE

## 21fd5ea83a74327d — image/references/multi-panel.md:41-41 (list_item)

- `{duration}` — total spot length (e.g., "30", "60")

Extracted rules inside block: NONE

## 76756d045f129133 — image/references/multi-panel.md:42-42 (list_item)

- `{t1}` through `{t8}` — timestamp boundaries

Extracted rules inside block: NONE

## 8143bb34cf2b0e54 — image/references/multi-panel.md:43-43 (list_item)

- `{scene_1_description}` through `{scene_9_description}` — shot description per panel

Extracted rules inside block: NONE

## fecb2bee3fd38f6a — image/references/multi-panel.md:44-44 (list_item)

- `{language}` — "Chinese" / "English" / "bilingual"

Extracted rules inside block: NONE

## 31186bce267dd17e — image/references/multi-panel.md:46-48 (paragraph)

**Recommended size:** 1536x1024 (landscape)
**Model:** GPT Image 2 `quality: high` (text-heavy — timestamps and titles need legibility)
**Common pitfalls:**

Extracted rules inside block: 992a892740f5

## f34dc29a5d714c6f — image/references/multi-panel.md:49-49 (list_item)

- Omitting panel numbers causes the model to merge or skip panels

Extracted rules inside block: NONE

## 6f09e31b2b6bfe18 — image/references/multi-panel.md:50-50 (list_item)

- Vague scene descriptions produce near-identical panels — each must have a distinct action, angle, or subject

Extracted rules inside block: fc346d6b9d10

## abec3318090bdb40 — image/references/multi-panel.md:51-51 (list_item)

- Timestamps in very small text need `quality: high` to remain readable

Extracted rules inside block: NONE

## 8420298f5d840ac8 — image/references/multi-panel.md:55-55 (heading)

## 2. 2x2 Editorial Portrait Grid

Extracted rules inside block: NONE

## a3b2d56c69445d68 — image/references/multi-panel.md:57-57 (paragraph)

**When to use:** Same person shown from 4 angles/crops in one image for an editorial or casting look.

Extracted rules inside block: 5cd420d8b027

## 000f06c1ba8acc58 — image/references/multi-panel.md:59-59 (heading)

### Template (5-slot format)

Extracted rules inside block: NONE

## 32f231c5694d1c1e — image/references/multi-panel.md:61-76 (code)

```
Scene: 2x2 grid of four editorial portraits, minimal gap between panels. {background_description}. {lighting_style}.

Subject: {subject_description} — same person in all four panels, consistent identity and wardrobe.

Important Details:
Top-left: front-facing portrait, direct eye contact, shoulders up
Top-right: extreme macro close-up of face — eyes, skin texture, freckles visible
Bottom-left: lower angle looking up, chin slightly raised, confident expression
Bottom-right: side profile, clean silhouette against background

Consistent lighting across all four panels. Skin texture realistic, no airbrushing.

Use Case: editorial photography, model portfolio, casting composite
Constraints: same person in every panel, no wardrobe changes between panels, no extra people, no text overlays
```

Extracted rules inside block: NONE

## 9a104abecaf4f0ab — image/references/multi-panel.md:78-78 (paragraph)

**Variables:**

Extracted rules inside block: NONE

## 90e31cb81ef4dec8 — image/references/multi-panel.md:79-79 (list_item)

- `{subject_description}` — age, appearance, wardrobe (e.g., "woman in her 30s, dark curly hair, white linen shirt")

Extracted rules inside block: NONE

## 040bc7cb8c8e6507 — image/references/multi-panel.md:80-80 (list_item)

- `{background_description}` — (e.g., "soft gray studio backdrop")

Extracted rules inside block: NONE

## 52b9394d3d291f42 — image/references/multi-panel.md:81-81 (list_item)

- `{lighting_style}` — (e.g., "single key light from upper left, subtle fill from right")

Extracted rules inside block: NONE

## fb2eeeb993128f0c — image/references/multi-panel.md:83-85 (paragraph)

**Recommended size:** 1024x1024 (square) or 1024x1536 (vertical for portrait emphasis)
**Model:** GPT Image 2 `quality: medium` or Nano Banana Pro (both handle photorealistic portraits well)
**Common pitfalls:**

Extracted rules inside block: 336c811ae999

## aa78f4c7959f34dc — image/references/multi-panel.md:86-86 (list_item)

- Not specifying "same person" in every panel — model may generate four different people

Extracted rules inside block: NONE

## 89d9261493cba7b6 — image/references/multi-panel.md:87-87 (list_item)

- Omitting which quadrant gets which angle — model arranges arbitrarily

Extracted rules inside block: NONE

## 6d51ef898afd1750 — image/references/multi-panel.md:88-88 (list_item)

- Requesting too-different crops (full body + extreme close-up) creates scale inconsistency within the grid

Extracted rules inside block: NONE

## 46a6e257143bcf8f — image/references/multi-panel.md:92-92 (heading)

## 3. 3-Panel Campaign Collage

Extracted rules inside block: NONE
