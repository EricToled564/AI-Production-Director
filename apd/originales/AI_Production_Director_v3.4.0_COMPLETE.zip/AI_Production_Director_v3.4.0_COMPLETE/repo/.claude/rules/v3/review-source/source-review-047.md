# Source coverage review 47/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 58b58c54ea7c46c9 — image/references/models.md:33-33 (list_item)

- **UI-моки и продуктовые скриншоты.** Иерархия, реальные интерфейс-элементы, читаемые лейблы.

Extracted rules inside block: NONE

## f332e247dac39122 — image/references/models.md:34-34 (list_item)

- **Структурированный 5-slot промпт.** Чёткое разделение Scene/Subject/Details/Use case/Constraints даёт предсказуемость.

Extracted rules inside block: ea7e62c159d5

## ee883616da45e9eb — image/references/models.md:35-35 (list_item)

- **`quality` рычаг.** low/medium/high — осознанный trade-off скорости и точности.

Extracted rules inside block: NONE

## 008fc1c091203046 — image/references/models.md:37-37 (heading)

### Где обе модели одинаково хороши

Extracted rules inside block: NONE

## b93217eb3ad730fc — image/references/models.md:38-38 (list_item)

- Photorealistic портреты.

Extracted rules inside block: NONE

## a4946c5fc4aee393 — image/references/models.md:39-39 (list_item)

- Product shots на нейтральном фоне.

Extracted rules inside block: NONE

## fc9c06d3af04b42c — image/references/models.md:40-40 (list_item)

- Минималистичные постеры.

Extracted rules inside block: NONE

## fcdfe3fbf2d0a1e2 — image/references/models.md:41-41 (list_item)

- Editorial-фотография.

Extracted rules inside block: NONE

## 02c8a41e81a637ee — image/references/models.md:43-43 (heading)

## Различия в синтаксисе промпта

Extracted rules inside block: NONE

## 3280fe51e6d6908f — image/references/models.md:45-45 (table_row)

| Аспект | Nano Banana | GPT Image 2 |

Extracted rules inside block: NONE

## b7bc3862c1c5e03a — image/references/models.md:47-47 (table_row)

| Стиль промпта | Натуральный язык, 1-2 параграфа | 5-slot с лейблами секций |

Extracted rules inside block: NONE

## cb43afa8f0339571 — image/references/models.md:48-48 (table_row)

| Камера/линза | **Не указывать** числа (50mm, f/2.8) — NB игнорит | Можно «50mm feel», но как high-level look |

Extracted rules inside block: NONE

## a0138a15705e4395 — image/references/models.md:49-49 (table_row)

| «Stunning/epic/masterpiece» | Игнорит, не вредит | **Anti-slop**: вредит, делает результат хуже |

Extracted rules inside block: NONE

## 796ecf22ce756f6c — image/references/models.md:50-50 (table_row)

| Text in image | `"..."` в кавычках, font + position | `"..."` или ALL CAPS + «no extra words / no duplicate text» |

Extracted rules inside block: NONE

## 95e79e7d12c30503 — image/references/models.md:51-51 (table_row)

| Negative framing | Использовать позитив | Использовать позитив + явный preserve list |

Extracted rules inside block: NONE

## e57dcd03bc389fdd — image/references/models.md:52-52 (table_row)

| Сложные сцены | JSON для 5+ элементов | 5-slot template со секциями |

Extracted rules inside block: NONE

## ff9d5f672ff8391a — image/references/models.md:53-53 (table_row)

| Edit | «Keep X same, change Y» | «Change: X / Preserve: Y / Constraints: Z» — повторять preserve каждую итерацию |

Extracted rules inside block: NONE

## add747662602efad — image/references/models.md:54-54 (table_row)

| Множественные референсы | До 14, индексировать | До 16, индексировать с ролью («Image 1: base», «Image 2: jacket reference») |

Extracted rules inside block: NONE

## 1909cca2f5c879c2 — image/references/models.md:56-56 (heading)

## Стоимость (ориентир)

Extracted rules inside block: NONE

## 888441af85198d15 — image/references/models.md:58-58 (table_row)

| Модель | Цена | Заметки |

Extracted rules inside block: NONE

## bfe247e4a44377d7 — image/references/models.md:60-60 (table_row)

| Nano Banana 2 Lite | ~$0.034/img | Только 1K, ~4 сек. Черновики и массовые батчи |

Extracted rules inside block: NONE

## 401f9bbad13da3e7 — image/references/models.md:61-61 (table_row)

| Nano Banana 2 (Flash) | ~$0.04/img | Default для большинства задач |

Extracted rules inside block: NONE

## f26e09265e46f43d — image/references/models.md:62-62 (table_row)

| Nano Banana Pro | ~$0.15/img | Сложные сцены, до 14 рефов |

Extracted rules inside block: NONE

## 5b3c30a9196c5db9 — image/references/models.md:63-63 (table_row)

| GPT Image 2 (`low`) | дёшево | Latency-sensitive, превью |

Extracted rules inside block: NONE

## 8e8ddf1ab0581b6d — image/references/models.md:64-64 (table_row)

| GPT Image 2 (`medium`) | средне | Default для GPT Image |

Extracted rules inside block: NONE

## 463d0898001c912c — image/references/models.md:65-65 (table_row)

| GPT Image 2 (`high`) | дороже | Маленький текст, brand-sensitive, photorealism |

Extracted rules inside block: NONE

## 4475ceeba4a2b587 — image/references/models.md:66-66 (table_row)

| gpt-image-1-mini | дешёвый | Высокообъёмная exploratory-генерация |

Extracted rules inside block: NONE

## ce767fe8c93fd177 — image/references/models.md:68-68 (list_item)

> Скилл сам не запускает генерацию — выдаёт промпт. Модель/quality указываем рядом с промптом как мета.

Extracted rules inside block: NONE

## 14aaa4312928555d — image/references/models.md:72-72 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## af9245b3215f8e81 — image/references/multi-panel.md:1-1 (heading)

# Multi-Panel Compositions

Extracted rules inside block: NONE
