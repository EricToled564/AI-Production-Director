# Source coverage review 19/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 9bd68648566ffe07 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:93-93 (heading)

## Cambio 9 — Añadir entrada al CHANGELOG

Extracted rules inside block: NONE

## 1db5a9a5c17ca445 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:95-95 (heading)

### Insertar al inicio del bloque CHANGELOG (después del header de versión)

Extracted rules inside block: NONE

## f8bffcba60db25a5 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:97-106 (code)

```
CHANGELOG v6.1 (desde v6.0)
Origen: Retrospectiva F7 sesión 2026-05-27 — proyecto "Sports World Mundial 2026", múltiples prompts I2V con redundancia repetida.
- [CRÍTICO] Nueva Regla 28: linter determinista obligatorio antes de entregar cualquier prompt. Sin PASS o sin overrides cubriendo violaciones, no se entrega al usuario.
- [MAYOR] Sección 5.5: nueva sub-sección sobre disciplina vía linter determinista — la memoria del agente falla bajo presión, el código no.
- [MAYOR] Sección 1.3: nuevo principio — cuando una regla puede codificarse, debe codificarse.
- [MENOR] Override de linter requiere autorización expresa escrita en turno actual con scope específico (sintaxis `OVERRIDE: <term> - <reason>`).
- [MENOR] Actualizadas Secciones 4.6, 4.7, 4.8 con llamada explícita a Regla 28 antes de entrega.
- Consistencia: v6.0 → v6.1; Reglas Inviolables 27 → 28; fecha 2026-05-23 → 2026-05-27.
```

Extracted rules inside block: NONE

## 7c54d56b301f4914 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:108-108 (heading)

## Resumen de propuestas

Extracted rules inside block: NONE

## 596b46822d56a965 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:110-110 (table_row)

| # | Cambio | Tipo | Sección |

Extracted rules inside block: NONE

## 2cdf489e0d352769 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:112-112 (table_row)

| 1 | Nueva Regla 28 | CRÍTICO | §14 |

Extracted rules inside block: NONE

## 2468793150d61746 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:113-113 (table_row)

| 2 | Nuevo principio enforcement determinista | MAYOR | §1.3 |

Extracted rules inside block: NONE

## 7707f7b2a2ef3b46 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:114-114 (table_row)

| 3 | F4 paso final con linter | MENOR | §4.6 |

Extracted rules inside block: NONE

## f21d7310e41b1282 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:115-115 (table_row)

| 4 | F5 paso final con linter | MENOR | §4.7 |

Extracted rules inside block: NONE

## 35eb4ff949a33b6e — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:116-116 (table_row)

| 5 | F6 paso final con linter | MENOR | §4.8 |

Extracted rules inside block: NONE

## d6b649570dd0d5cb — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:117-117 (table_row)

| 6 | Nueva sub-sección 5.5 | MAYOR | §5 |

Extracted rules inside block: NONE

## f2ad7bd81e58c330 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:118-118 (table_row)

| 7 | Contador 27→28 | MENOR | §14 |

Extracted rules inside block: NONE

## d045c2428232c343 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:119-119 (table_row)

| 8 | Versión + fecha | MENOR | header |

Extracted rules inside block: NONE

## 79e3e2ca9209faed — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:120-120 (table_row)

| 9 | CHANGELOG v6.1 | MENOR | inicio doc |

Extracted rules inside block: NONE

## 5b525ac4e6e7848f — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:122-122 (heading)

## Aprobación

Extracted rules inside block: NONE

## 74a7c532b35a3520 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:124-124 (paragraph)

Cada cambio puede aprobarse/rechazarse individualmente. Recomendación: aprobar el bundle completo (los 9 cambios forman una unidad coherente).

Extracted rules inside block: NONE

## f00d8fec43ef9fe2 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:126-126 (list_item)

- [ ] Aprobar bundle completo (recomendado)

Extracted rules inside block: NONE

## 567402f145c525d1 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:127-127 (list_item)

- [ ] Aprobar selectivamente (especificar cuáles)

Extracted rules inside block: NONE

## d2539ada15ef8c7d — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:128-128 (list_item)

- [ ] Rechazar bundle (linter queda como herramienta opcional sin regla inviolable)

Extracted rules inside block: NONE

## a55c1627315079cf — brand-lock-extractor/SKILL.md:2-3 (paragraph)

name: brand-lock-extractor
description: Extract a production-ready brand-lock.md from a brand's existing assets. Point it at a website URL, a brand book PDF, screenshots, or a written description and it produces the nine-section brand-lock the rest of shotkit consumes, with a confidence and source noted for every value. Use when the user wants to onboard a brand, says "build a brand lock", "extract my brand", "make a brand pack from my site", or hands over brand assets. The cold-start killer that turns a blank brand-pack template into a filled, validate-ready file. Pairs with storyboard-architect downstream.

Extracted rules inside block: NONE

## 7751c8bb05e43c2d — brand-lock-extractor/SKILL.md:6-6 (heading)

# Brand Lock Extractor

Extracted rules inside block: NONE

## 58946120cd93d919 — brand-lock-extractor/SKILL.md:8-8 (paragraph)

The blank `brand-packs/_template.md` is the single biggest point of friction in shotkit. Nobody wants to hand-author nine sections of brand parameters before they can produce a single storyboard. This skill removes that wall: hand it what you already have, get a filled brand-lock back.

Extracted rules inside block: NONE

## e03f231f1c38035d — brand-lock-extractor/SKILL.md:10-10 (paragraph)

The output is a `brand-lock.md` in the exact format `tools/validate_brand_lock.py` validates and every other skill consumes. Same file the pipeline reads, produced from your assets instead of from scratch.

Extracted rules inside block: NONE

## 8a8f99a85a0b6876 — brand-lock-extractor/SKILL.md:12-12 (paragraph)

This skill extracts. It does not invent. Every value is sampled from a real asset or flagged as an estimate the user must confirm. A confident-sounding wrong hex is worse than a flagged guess.

Extracted rules inside block: 119333aa9698

## d99bed34f75641d2 — brand-lock-extractor/SKILL.md:14-14 (heading)

## When to use

Extracted rules inside block: NONE

## 61b0775ae4bc2beb — brand-lock-extractor/SKILL.md:16-16 (paragraph)

Trigger when the user:

Extracted rules inside block: NONE

## df21d0c33b29fa82 — brand-lock-extractor/SKILL.md:18-18 (list_item)

- Wants to onboard a brand into shotkit and has assets (a site, a brand book, screenshots)

Extracted rules inside block: NONE

## f843b2430633c7e5 — brand-lock-extractor/SKILL.md:19-19 (list_item)

- Says "extract my brand", "build a brand lock", "make a brand pack from my site/PDF"

Extracted rules inside block: NONE

## 40b8d4e82d490e1e — brand-lock-extractor/SKILL.md:20-20 (list_item)

- Hands over a URL, a PDF, image files, or a written brand description and asks for a brand-lock

Extracted rules inside block: NONE

## 9da70510bed0be4a — brand-lock-extractor/SKILL.md:21-21 (list_item)

- Has a brand-lock that is half-filled and wants the gaps extracted from assets

Extracted rules inside block: NONE
