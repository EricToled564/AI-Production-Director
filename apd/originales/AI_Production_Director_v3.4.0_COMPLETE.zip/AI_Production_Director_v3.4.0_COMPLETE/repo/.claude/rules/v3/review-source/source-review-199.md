# Source coverage review 199/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## e8a16344f41eebfd — visual-media/SKILL.md:320-320 (list_item)

- **Profesional**: Premiere Pro, DaVinci Resolve, Final Cut

Extracted rules inside block: NONE

## 444717ea9f3a2aa0 — visual-media/SKILL.md:321-321 (list_item)

- **Ligero**: CapCut, iMovie, Filmora

Extracted rules inside block: NONE

## 0a06e36e4240ea06 — visual-media/SKILL.md:322-322 (list_item)

- **VFX**: After Effects, Motion

Extracted rules inside block: NONE

## f92e876f6c3e6a1a — visual-media/SKILL.md:324-324 (heading)

### Herramientas de animación

Extracted rules inside block: NONE

## a7aeb2d90f4cc07f — visual-media/SKILL.md:325-325 (list_item)

- **2D**: Toon Boom, Clip Studio, Procreate

Extracted rules inside block: NONE

## 203537386d65bc0e — visual-media/SKILL.md:326-326 (list_item)

- **3D**: Blender, Maya, Cinema 4D

Extracted rules inside block: NONE

## fac7dbe71e1b4de9 — visual-media/SKILL.md:327-327 (list_item)

- **Motion**: After Effects, Lottie

Extracted rules inside block: NONE

## 51f1dab538d60c7b — visual-media/SKILL.md:329-329 (heading)

## Recursos

Extracted rules inside block: NONE

## 8015c3e8d7e55e33 — visual-media/SKILL.md:331-331 (list_item)

- [StudioBinder](https://www.studiobinder.com/) — Formación en producción audiovisual

Extracted rules inside block: NONE

## 41c0d910ed825ed5 — visual-media/SKILL.md:332-332 (list_item)

- [Peter McKinnon](https://www.youtube.com/@PeterMcKinnon) — Fotografía y video

Extracted rules inside block: NONE

## 165006881be5ab87 — visual-media/SKILL.md:333-333 (list_item)

- [Corridor Crew](https://www.youtube.com/@CorridorCrew) — Tutoriales de VFX

Extracted rules inside block: NONE

## 3353baf6625a2ef4 — visual-media/SKILL.md:334-334 (list_item)

- [The Animator's Survival Kit](https://www.amazon.com/Animators-Survival-Kit-Richard-Williams/dp/0571238343)

Extracted rules inside block: NONE

## 6cdab9c5b2cb15d5 — visual-prompt-forge/SKILL.md:2-3 (paragraph)

name: visual-prompt-forge
description: Generate model-specific prompts from shots.json. Outputs copy-paste-ready prompts for stills (Midjourney, Flux, Ideogram, GPT Image, Nano Banana, Seedream) and motion video (Kling, Veo, Seedance, Hailuo). Also runs a revision mode that reads a critique.json and re-emits prompts for only the failed shots, closing the QA loop. Use when the user asks for image or video prompts, mentions any of those generators, wants AI-generated frames for a storyboard, or hands over shots.json. The prompt half of the pipeline. Composes with storyboard-architect upstream, visual-asset-critic downstream.

Extracted rules inside block: NONE

## d9b4af2935a41cf4 — visual-prompt-forge/SKILL.md:6-6 (heading)

# Visual Prompt Forge

Extracted rules inside block: NONE

## 9938f177ea30474f — visual-prompt-forge/SKILL.md:8-8 (paragraph)

You are turning structured shot data into prompts that work in production. Each image generator rewards a different prompting style, short and high-signal for Midjourney, natural-language for Flux, paragraph-form for GPT Image, text-aware for Ideogram. A prompt that crushes in one will produce slop in another.

Extracted rules inside block: NONE

## 98a2ab1504f77a78 — visual-prompt-forge/SKILL.md:10-10 (paragraph)

This skill adapts. Same shot, different syntax.

Extracted rules inside block: NONE

## 0f4279e251b3ea96 — visual-prompt-forge/SKILL.md:12-12 (heading)

## When to use

Extracted rules inside block: NONE

## a1eb49e95e7fc27b — visual-prompt-forge/SKILL.md:14-14 (paragraph)

Trigger when the user:

Extracted rules inside block: NONE

## 939ce0ad57c5c4ed — visual-prompt-forge/SKILL.md:16-16 (list_item)

- Hands over a `shots.json` (or any structured shot list) and asks for prompts

Extracted rules inside block: NONE

## af5f0d0ebf6a06b5 — visual-prompt-forge/SKILL.md:17-17 (list_item)

- Names a specific generator (Midjourney, Flux, Ideogram, GPT Image, Nano Banana, Seedream, Kling, Veo, Seedance, Hailuo)

Extracted rules inside block: NONE

## cc6da3afe4ae64cb — visual-prompt-forge/SKILL.md:18-18 (list_item)

- Asks for "image prompts," "Midjourney prompts," "AI prompts," "generation prompts" for a storyboard

Extracted rules inside block: NONE

## e1d13c19dcec462d — visual-prompt-forge/SKILL.md:19-19 (list_item)

- Wants the same shot adapted to multiple generators

Extracted rules inside block: NONE

## 003239dc82717d52 — visual-prompt-forge/SKILL.md:21-21 (paragraph)

If the user wants to build a storyboard from scratch (no shots.json yet), use `storyboard-architect` first, then chain into this skill.

Extracted rules inside block: 7de160615e64

## 54b3a7632362161a — visual-prompt-forge/SKILL.md:23-23 (heading)

## What you produce

Extracted rules inside block: NONE

## 1c99c1f9a92545df — visual-prompt-forge/SKILL.md:25-26 (paragraph)

For a given `shots.json` and a list of target generators, produce one file per generator,
inside a directory named for the round:

Extracted rules inside block: NONE

## c55ec32c2be7956b — visual-prompt-forge/SKILL.md:28-40 (code)

```
output/prompts/round-1/
├── midjourney.txt          # If targeted
├── flux.txt
├── ideogram.txt
├── gpt-image.txt
├── nano-banana.txt
├── seedream.txt
├── kling.txt               # Motion-aware video, default
├── veo.txt                 # Motion, dialogue/lipsync + native audio
├── seedance.txt            # Motion, multi-shot sequences
└── hailuo.txt              # Motion, budget iteration
```

Extracted rules inside block: NONE

## 2c2c028d2a5b71e2 — visual-prompt-forge/SKILL.md:42-45 (paragraph)

Round 1 is the first pass. Revision mode writes `output/prompts/round-2/`, and so on.
The round in the path is not decoration: prompt files used to be written to one fixed
path per generator, so round 2 destroyed round 1 and the prompt that actually produced
most of the surviving frames was gone.

Extracted rules inside block: NONE

## 88d349058252acfc — visual-prompt-forge/SKILL.md:47-47 (paragraph)

Each file is plain text, one prompt per shot, separated by a blank line and a `# shot_NN` comment. Designed for copy-paste workflows, drop into the generator's UI or pipe into an API.

Extracted rules inside block: NONE

## 3934ac502b0930e8 — visual-prompt-forge/SKILL.md:49-49 (heading)

## The five-layer prompt anatomy

Extracted rules inside block: NONE

## fe57bc9ac1131d1e — visual-prompt-forge/SKILL.md:51-51 (paragraph)

Every prompt is composed from these layers. Read `references/prompt-anatomy.md` for the full theory. Quick version:

Extracted rules inside block: NONE
