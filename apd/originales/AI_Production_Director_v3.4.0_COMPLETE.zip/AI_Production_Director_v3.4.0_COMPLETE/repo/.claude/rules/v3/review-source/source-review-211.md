# Source coverage review 211/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c080586032b5c869 — visual-prompt-forge/adapters/ideogram.md:91-91 (list_item)

- **Don't trust magic_prompt**, it auto-rewrites and produces inconsistent shots across a series

Extracted rules inside block: c8bc50d668b3

## f2cf6385012bb81e — visual-prompt-forge/adapters/ideogram.md:92-92 (list_item)

- **Don't pile multiple text elements in one prompt**. Ideogram handles one text element well, two becomes lottery, three is broken

Extracted rules inside block: 9ad47ed02a8c

## 72acacbc408c2213 — visual-prompt-forge/adapters/ideogram.md:93-93 (list_item)

- **Don't use cursive/decorative fonts**, even Ideogram fails on these. Sans-serif and clean serif are reliable

Extracted rules inside block: e3d3f2d7d478

## 310371c52919a1cf — visual-prompt-forge/adapters/ideogram.md:94-94 (list_item)

- **Don't forget seed**, for any series work, lock the seed at the storyboard level

Extracted rules inside block: 5498320272fa

## 41e622074092ebfe — visual-prompt-forge/adapters/kling.md:1-1 (heading)

# Adapter: Kling 3.0 (motion-aware video)

Extracted rules inside block: NONE

## 9b594250ace8daf4 — visual-prompt-forge/adapters/kling.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: f1d93f765961

## 1cc496d9b1fef01c — visual-prompt-forge/adapters/kling.md:5-5 (paragraph)

Kling 3.0 generates short video clips, not still frames. It is the default motion model: the best camera-motion realism per dollar on fal.ai, and the strongest image-to-video of the four. Reach for it first. Escalate to Veo (dialogue/lipsync), Seedance (multi-shot), or Hailuo (cheap iteration) only when the shot needs what Kling does not do.

Extracted rules inside block: NONE

## eb18956e12aab9ba — visual-prompt-forge/adapters/kling.md:7-7 (paragraph)

With video the **camera motion becomes load-bearing** instead of optional. The same shot generates differently when `motion` is `static` versus `push` versus `handheld`. Use this adapter when the storyboard is destined for video generation rather than still-frame compositing.

Extracted rules inside block: 9d40edcc93cc

## 32f1f7856b9a5358 — visual-prompt-forge/adapters/kling.md:9-9 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## 96ec334ef01c3610 — visual-prompt-forge/adapters/kling.md:11-13 (code)

```
{Camera motion sentence, explicit, leading.} {Subject and action over the duration.} {Environment and lighting from series_lock.} {Photographic spec.} {Color grade and mood from brand_lock.}
```

Extracted rules inside block: NONE

## f41732fd680fc21c — visual-prompt-forge/adapters/kling.md:15-15 (paragraph)

Camera motion goes **first**. This is the inverse of image generators where camera is implied. With video the camera's behaviour is the first thing the model must understand.

Extracted rules inside block: 95f77ee79758

## 2867cf0c10ef29d8 — visual-prompt-forge/adapters/kling.md:17-17 (heading)

## Parameters

Extracted rules inside block: NONE

## f7cebc25d23a3604 — visual-prompt-forge/adapters/kling.md:19-19 (table_row)

| Parameter | Default | Notes |

Extracted rules inside block: NONE

## b40911ccac8d0cb3 — visual-prompt-forge/adapters/kling.md:21-21 (table_row)

| `duration` | `5s` for shots, `10s` for hero | 5s and 10s are the supported lengths |

Extracted rules inside block: NONE

## e4a1d36f1a74e570 — visual-prompt-forge/adapters/kling.md:22-22 (table_row)

| `aspect_ratio` | from `project.aspect` | |

Extracted rules inside block: NONE

## 46a801f6ede3e1b0 — visual-prompt-forge/adapters/kling.md:23-23 (table_row)

| `cfg_scale` | `0.5` | Lower = looser/more dynamic, higher = closer to prompt |

Extracted rules inside block: NONE

## 002b7b857f1aa6a0 — visual-prompt-forge/adapters/kling.md:24-24 (table_row)

| `start_image` | optional | Image-to-video. Pass an accepted still from `shots.json` assets to lock the opening frame |

Extracted rules inside block: NONE

## af028b0361b56779 — visual-prompt-forge/adapters/kling.md:25-25 (table_row)

| `tail_image` | optional | End-frame target for controlled moves |

Extracted rules inside block: NONE

## 74990da87d972a13 — visual-prompt-forge/adapters/kling.md:26-26 (table_row)

| `negative_prompt` | per series | Supported. Use to suppress drift, e.g. `extra fingers, warped face` |

Extracted rules inside block: af35f9995402

## eedb110dc50627b8 — visual-prompt-forge/adapters/kling.md:28-28 (paragraph)

Document parameters as a comment line above each prompt:

Extracted rules inside block: NONE

## 676088a2961a5a3b — visual-prompt-forge/adapters/kling.md:30-33 (code)

```
# shot_01. Kling 3.0: duration=5s, ar=9:16, cfg=0.5, start_image=frames/round-1/shot_01.png
{prompt}
```

Extracted rules inside block: NONE

## 14ab6b4fd6e47f66 — visual-prompt-forge/adapters/kling.md:35-35 (heading)

## Length

Extracted rules inside block: NONE

## ad6b22c69c73f487 — visual-prompt-forge/adapters/kling.md:37-37 (paragraph)

Kling handles **80–150 words** comfortably. Motion description adds a beat over a still prompt; do not pad past it.

Extracted rules inside block: e4ce642461b9

## 0a85a6065f0a3f82 — visual-prompt-forge/adapters/kling.md:39-39 (heading)

## Motion vocabulary

Extracted rules inside block: NONE

## d6d6f2f3ef7ec8dd — visual-prompt-forge/adapters/kling.md:41-41 (paragraph)

The shot grammar `motion` field maps directly. One move per shot.

Extracted rules inside block: NONE

## f8dfb06072bb5dae — visual-prompt-forge/adapters/kling.md:43-43 (table_row)

| `motion` | Video prompt phrase |

Extracted rules inside block: NONE

## 1597ee3c7dbda981 — visual-prompt-forge/adapters/kling.md:45-45 (table_row)

| `static` | "Static camera, locked off." |

Extracted rules inside block: NONE

## 39c81389ee929aa5 — visual-prompt-forge/adapters/kling.md:46-46 (table_row)

| `push` | "Camera dollies forward slowly at a steady pace." |

Extracted rules inside block: NONE

## af07ece8ce24a4ec — visual-prompt-forge/adapters/kling.md:47-47 (table_row)

| `pull` | "Camera dollies backward, pulling away from the subject." |

Extracted rules inside block: NONE

## b0cdaf629984e895 — visual-prompt-forge/adapters/kling.md:48-48 (table_row)

| `pan-left` / `pan-right` | "Camera pans smoothly to the left / right." |

Extracted rules inside block: NONE
