# Source coverage review 143/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## d5f3d418f364f327 — video/references/dramaturgy.md:184-184 (paragraph)

Build storyboards in three layers, in this order. Skipping a layer produces pretty but empty output.

Extracted rules inside block: NONE

## 6c8c2f017fcccc76 — video/references/dramaturgy.md:186-186 (heading)

### Layer 1. Dramatic beats

Extracted rules inside block: NONE

## 2666b886e543cfd6 — video/references/dramaturgy.md:188-188 (paragraph)

For a 60-90 second piece, a reliable beat map.

Extracted rules inside block: NONE

## a0acd0abb9862eb5 — video/references/dramaturgy.md:190-198 (code)

```text
0-5s    Hook.        Hero already in tension. No setup. Problem on screen.
5-15s   Context.     Where we are. Who is near. What is at stake.
15-30s  Pressure.    Hero tries to hold control.
30-45s  Crack.       A detail appears that breaks the hero's position.
45-60s  Acceleration. Cuts shorten. Breath tightens.
60-75s  Impact.      Decision, break, confession, or action.
75-90s  Aftermath.   Brief silence or visual residue.
```

Extracted rules inside block: NONE

## 0b5b4c73a0117b72 — video/references/dramaturgy.md:200-200 (paragraph)

Adjust for 30s or 15s by compressing proportionally. Never skip the Crack or the Impact.

Extracted rules inside block: cc6a7c5f56f1

## 04f29da18c4eca3e — video/references/dramaturgy.md:202-202 (heading)

### Layer 2. Shot functions

Extracted rules inside block: NONE

## a665c679ae4c9762 — video/references/dramaturgy.md:204-204 (paragraph)

Tag every shot with a function. Same taxonomy as in role-modes.md, expanded with Power.

Extracted rules inside block: NONE

## 7af730ecb053762f — video/references/dramaturgy.md:206-206 (list_item)

- **Establish.** Where we are.

Extracted rules inside block: NONE

## 5452a66fcc511d2d — video/references/dramaturgy.md:207-207 (list_item)

- **Power.** Who controls the scene right now.

Extracted rules inside block: NONE

## d20f2e027b4875bc — video/references/dramaturgy.md:208-208 (list_item)

- **Pressure.** What is pushing down on the hero.

Extracted rules inside block: NONE

## 53eab8a983974e6a — video/references/dramaturgy.md:209-209 (list_item)

- **Detail.** Object, hand, phone, eye, drop, receipt, door. Macro anchor.

Extracted rules inside block: NONE

## 83651476b022a27d — video/references/dramaturgy.md:210-210 (list_item)

- **Reaction.** Face after the event.

Extracted rules inside block: NONE

## f50bbcd09bd34ed6 — video/references/dramaturgy.md:211-211 (list_item)

- **Shift.** Inner change made visible.

Extracted rules inside block: NONE

## 28e86c6061f65402 — video/references/dramaturgy.md:212-212 (list_item)

- **Impact.** The decisive frame.

Extracted rules inside block: NONE

## d886acbb012f10af — video/references/dramaturgy.md:213-213 (list_item)

- **Aftermath.** Emptiness after action.

Extracted rules inside block: NONE

## b418d046c6283a0f — video/references/dramaturgy.md:214-214 (list_item)

- **Exit.** Final image the viewer carries out.

Extracted rules inside block: NONE

## ed3e5ba4ae1714f3 — video/references/dramaturgy.md:216-216 (paragraph)

This is cinema grammar. Everything else is decorative wallpaper.

Extracted rules inside block: NONE

## 31de67fa58d821e4 — video/references/dramaturgy.md:218-218 (heading)

### Layer 3. Editing rhythm

Extracted rules inside block: NONE

## b113e293d509628e — video/references/dramaturgy.md:220-220 (paragraph)

Not random mincing. A rhythmic staircase.

Extracted rules inside block: NONE

## 625fbe15107d40a1 — video/references/dramaturgy.md:222-224 (code)

```text
long - shorter - shorter - pause - impact
```

Extracted rules inside block: NONE

## a11672ae07ec7561 — video/references/dramaturgy.md:226-226 (paragraph)

Example internal structure of an 8-10 second montage.

Extracted rules inside block: NONE

## 8661944f0d7bbc9f — video/references/dramaturgy.md:228-228 (list_item)

- 4s. Wide. Hero enters.

Extracted rules inside block: NONE

## 6f7151e4f5f78760 — video/references/dramaturgy.md:229-229 (list_item)

- 2s. Medium. Hero notices the object.

Extracted rules inside block: NONE

## 29d8b476258b4fc9 — video/references/dramaturgy.md:230-230 (list_item)

- 1s. Close-up. Eyes.

Extracted rules inside block: NONE

## b9cfbe0fd8e68aeb — video/references/dramaturgy.md:231-231 (list_item)

- 12 frames (0.5s). Macro insert of the object.

Extracted rules inside block: NONE

## e8f390c7803553b6 — video/references/dramaturgy.md:232-232 (list_item)

- 8 frames (0.33s). Hand.

Extracted rules inside block: NONE

## 83fec5b1418b23b3 — video/references/dramaturgy.md:233-233 (list_item)

- 6 frames (0.25s). Detail / sound cue.

Extracted rules inside block: NONE

## 1e6ddfcf1ae1c6c2 — video/references/dramaturgy.md:234-234 (list_item)

- 2s. Sudden silence.

Extracted rules inside block: NONE

## b0d521aebf8716b2 — video/references/dramaturgy.md:235-235 (list_item)

- 1s. Decision.

Extracted rules inside block: NONE

## b1cdb977b3d8bfc2 — video/references/dramaturgy.md:237-237 (paragraph)

Rule. The pause before the impact is more important than the speed of the cuts. Without a pause, speed becomes visual meat grinder.

Extracted rules inside block: NONE
