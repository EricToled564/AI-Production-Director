# Source coverage review 66/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 485a9c3e53493b75 — image/references/prompt-framework.md:205-205 (list_item)

- Key visual, который будет масштабироваться на все форматы

Extracted rules inside block: NONE

## 3b22d91d0939fe31 — image/references/prompt-framework.md:206-206 (list_item)

- Портфолийная работа, где каждый пиксель имеет значение

Extracted rules inside block: NONE

## 50297a11ef7eefca — image/references/prompt-framework.md:208-208 (heading)

### Чеклист микро-деталей

Extracted rules inside block: NONE

## 1175cc6b64efaa90 — image/references/prompt-framework.md:210-210 (paragraph)

Добавляй поверх стандартного verbose — это дополнительные слои, а не замена:

Extracted rules inside block: NONE

## 59edc4d840093955 — image/references/prompt-framework.md:212-212 (list_item)

1. **Surface wear & aging** — "chipped paint on window frame, hairline scratches on metal surface, green patina on copper fittings, oxidation marks on iron hinges"

Extracted rules inside block: e796e8e72bfb

## a4470768e0405ef8 — image/references/prompt-framework.md:213-213 (list_item)

2. **Micro-textures** — "visible pores on skin, individual hair strands catching backlight, fabric weave pattern on linen shirt, grain of weathered wood"

Extracted rules inside block: 51cfe5023e99

## 3c3f2e4109f36365 — image/references/prompt-framework.md:214-214 (list_item)

3. **Atmospheric particles** — "dust motes suspended in light beam, steam wisps rising from coffee cup, pollen floating in golden hour air, fine rain droplets on glass surface"

Extracted rules inside block: c95b74e4d1e7

## c84e4542fd52bf43 — image/references/prompt-framework.md:215-215 (list_item)

4. **Specular behavior** — "specular highlights on metal edges of watch, caustic reflections dancing inside glass bottle, wet surface sheen on cobblestones after rain"

Extracted rules inside block: 45a1fff021c6

## ed68c3de7bd37677 — image/references/prompt-framework.md:216-216 (list_item)

5. **Fabric & material drape** — "natural fabric folds at elbow crease, gravity pull on loose linen garment, weight distribution visible in heavy wool coat"

Extracted rules inside block: 1bf9438ec870

## cff25898ce92da81 — image/references/prompt-framework.md:217-217 (list_item)

6. **Contact shadows** — "soft contact shadow where cup meets saucer, ambient occlusion in crevices of stone wall, dark line where book spine meets table"

Extracted rules inside block: 143c6dad0eb7

## 1870eda1b8834d06 — image/references/prompt-framework.md:218-218 (list_item)

7. **Environmental reflections** — "building reflections in wet pavement, sky gradient in chrome bumper surface, warm neon glow on skin from nearby sign"

Extracted rules inside block: c7fc30fb6c1d

## 92293f6867567bee — image/references/prompt-framework.md:219-219 (list_item)

8. **Motion cues** — "slight motion blur on trailing hair strand, frozen splash droplet from espresso pour, wind-displaced fabric edge of scarf"

Extracted rules inside block: a5fe99c46079

## 5a6262251c42d97c — image/references/prompt-framework.md:221-221 (heading)

### Before / After

Extracted rules inside block: NONE

## 94240e1e425bbde8 — image/references/prompt-framework.md:223-223 (paragraph)

**Standard Verbose:**

Extracted rules inside block: NONE

## 267bffdb9f5dfed2 — image/references/prompt-framework.md:224-233 (code)

```
Create a cinematic portrait for coffee brand campaign.

Setting: Small Italian café, early morning. Espresso machine prominent in background.
Subject: Barista in white shirt, mid-pour, focused expression.
Atmosphere: Steam rising, warm tones, golden morning light through window.
Mood: Craftsmanship, ritual, quiet dedication
Lighting: Warm directional light from left window
Format: 4:5
```

Extracted rules inside block: NONE

## 7a290416788cdb17 — image/references/prompt-framework.md:235-235 (paragraph)

**Cinematic Verbose:**

Extracted rules inside block: NONE

## 0e476e9677feed89 — image/references/prompt-framework.md:236-250 (code)

```
Create a cinematic portrait for coffee brand campaign.

Setting: Small Italian café, early morning. Brass-and-chrome La Marzocca espresso machine in background, oxidation marks on steam wand, hairline scratches on drip tray from years of use. Chipped paint on wooden window frame behind machine.

Subject: Barista in white linen shirt — fabric weave pattern visible, natural folds at rolled-up sleeves, gravity pull on loose collar. Mid-pour with focused expression, visible pores on forehead, individual eyebrow hairs catching backlight.

Atmosphere: Steam wisps rising from espresso cup, dust motes suspended in morning light beam cutting through window. Fine coffee grounds scattered on worn marble counter — soft contact shadow where cup meets saucer. Wet surface sheen on freshly wiped counter edge.

Details: Specular highlights on chrome portafilter handle. Caustic reflections dancing inside glass water carafe on shelf. Warm neon glow of "APERTO" sign reflecting on barista's forearm. Slight motion blur on trailing steam, frozen droplet mid-drip from group head.

Mood: Craftsmanship, ritual, quiet dedication
Lighting: Warm directional light from left window, volumetric through steam
Format: 4:5
```

Extracted rules inside block: NONE

## 4d0241a61af853d9 — image/references/prompt-framework.md:254-254 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 0bcc474d62986e3a — image/references/slides.md:1-1 (heading)

# Presentation Slides

Extracted rules inside block: NONE

## e6bf13f3a1a452ce — image/references/slides.md:3-3 (paragraph)

Professional slide visuals for decks and pitches.

Extracted rules inside block: NONE

## 1362c7f429ffcacd — image/references/slides.md:5-5 (heading)

## Design Principles

Extracted rules inside block: NONE

## df8e9c1e9c449cb5 — image/references/slides.md:7-7 (heading)

### One Slide = One Idea

Extracted rules inside block: NONE

## fe5bb790c6282a45 — image/references/slides.md:8-8 (paragraph)

Не комбинируй несвязные концепции. Аудитория запоминает 65% визуального vs 10% услышанного.

Extracted rules inside block: NONE

## 7e009a865929158e — image/references/slides.md:10-10 (heading)

### Content Limits

Extracted rules inside block: NONE

## f08e6a3b7f9bd6e6 — image/references/slides.md:11-11 (list_item)

- Max 5 пунктов на слайде

Extracted rules inside block: NONE

## e91bd325a12b8753 — image/references/slides.md:12-12 (list_item)

- 15-20 слов в блоке текста

Extracted rules inside block: NONE

## ad721bfe81388f0e — image/references/slides.md:13-13 (list_item)

- Заголовок + список ИЛИ абзац, не оба

Extracted rules inside block: NONE

## 845f535b9d6ff36d — image/references/slides.md:15-15 (heading)

### Typography

Extracted rules inside block: NONE

## 41ab7ccbb391d3b7 — image/references/slides.md:16-23 (code)

```
Заголовок: 44-54 pt, bold
Подзаголовок: 28-36 pt, medium
Текст: 18-24 pt, regular (min 18 для читаемости)

Шрифты: sans-serif основной (Inter, Helvetica, Roboto)
Serif только для акцента
```

Extracted rules inside block: NONE

## f76e4c4813c7d30a — image/references/slides.md:25-25 (heading)

### Contrast & Color

Extracted rules inside block: NONE
