# Source coverage review 128/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4d345e38335fc0df — video/SKILL.md:60-60 (list_item)

- Storyboard / shot list / director treatment / "разбей на склейки" → [role-modes.md](references/role-modes.md). Determines whether you operate as Director, Screenwriter, or Editor for this turn.

Extracted rules inside block: NONE

## 530ad263231a0db6 — video/SKILL.md:61-61 (list_item)

- Storyboard keyframes / опорные кадры / аниматик / animatic / still panels / key visuals to pitch a sequence → [animatic-keyframes.md](references/animatic-keyframes.md). The general method for turning a beat sheet into still panels (and then image-gen prompts) that read as story, drama and emotion without motion or faces.

Extracted rules inside block: NONE

## 77f36fefda76fde1 — video/SKILL.md:62-62 (list_item)

- Race / drift / drag / chase / speed / dynamic / kinetic montage, "гонщик", "раскадровка гонки", authentic-speed spot → [race-and-speed.md](references/race-and-speed.md). Specializes `animatic-keyframes.md` for the race domain — read that file first.

Extracted rules inside block: NONE

## 85eb941ad95fe752 — video/SKILL.md:63-63 (list_item)

- Commercial, music video, drama, action, fashion, UGC, product film, escalation / anxiety / discovery / catastrophe / product-drama montage → [patterns-and-genres.md](references/patterns-and-genres.md).

Extracted rules inside block: NONE

## b7250096186635fc — video/SKILL.md:64-64 (list_item)

- Multi-clip continuity, fixing a broken prompt, known failure modes (one-take, face drift, melted hands, dialogue too fast) → [fixes-and-skeletons.md](references/fixes-and-skeletons.md).

Extracted rules inside block: NONE

## f157f87ae57f2c9b — video/SKILL.md:65-65 (list_item)

- Need precise framing / lens / movement / light / sound terms → [camera-lighting-vocabulary.md](references/camera-lighting-vocabulary.md).

Extracted rules inside block: NONE

## 78f8126441106d13 — video/SKILL.md:67-67 (paragraph)

If none match — proceed with steps 1-3 only.

Extracted rules inside block: NONE

## 7c7217fafb4e49bd — video/SKILL.md:69-69 (heading)

### Step 5 — apply the dramaturgy check and the three-detail check

Extracted rules inside block: NONE

## 3236d315f0c864ab — video/SKILL.md:71-71 (paragraph)

Before returning anything, run both checks:

Extracted rules inside block: NONE

## f785f3e89d02007f — video/SKILL.md:73-73 (list_item)

- Dramaturgy check (`dramaturgy.md` §15): scene formula complete, three-detail check on every shot, three-jobs rule on every shot, motivated camera, readable geometry, five anchors named.

Extracted rules inside block: NONE

## 53dfe532f1362239 — video/SKILL.md:74-74 (list_item)

- Three-detail audit (`universal-rules.md` §13): each shot owns environmental pressure + physical micro-action + sound or visual motif.

Extracted rules inside block: NONE

## 5daf39c22f6689e1 — video/SKILL.md:76-76 (paragraph)

If any shot fails, fix before sending. This is the step the user has had to enforce repeatedly. Do not skip it.

Extracted rules inside block: ab71adf39890

## 10103218a05f3ace — video/SKILL.md:80-80 (heading)

# Output

Extracted rules inside block: NONE

## 88cb51cf9106cdf9 — video/SKILL.md:82-82 (paragraph)

Choose the format the request actually asks for. Default to **A** if unclear.

Extracted rules inside block: NONE

## c9209cccdfaaec85 — video/SKILL.md:84-84 (list_item)

- **A. Single prompt.** One ready-to-copy prompt for one generation. Lead with model name + parameters in a short header.

Extracted rules inside block: NONE

## 637f6ea67754b8de — video/SKILL.md:85-85 (list_item)

- **B. Multi-clip prompts.** Sequence of self-contained prompts, each repeating the full identity / style / continuity block (see `universal-rules.md` U7).

Extracted rules inside block: NONE

## 84733c678b6da3c5 — video/SKILL.md:86-86 (list_item)

- **C. Storyboard.** Table — Time, Shot, Function, Action, Camera, Light, Sound, Emotion. Every row is a 14-field shot card from `dramaturgy.md` §11, compressed.

Extracted rules inside block: NONE

## 97733980e482b224 — video/SKILL.md:87-87 (list_item)

- **D. Prompt audit.** Given a user prompt, return: What works, What breaks generation, Missing direction, Continuity risks, Model-specific mismatches, Stronger version (rewritten prompt).

Extracted rules inside block: NONE

## 13da6bfdea7a0be6 — video/SKILL.md:88-88 (list_item)

- **E. Director treatment.** Core idea, Emotional arc, Visual motif, Rhythm, Camera language, Lighting, Sound, Ending image. (Treatment ≠ prompt.)

Extracted rules inside block: NONE

## 289906bcb4de124e — video/SKILL.md:89-89 (list_item)

- **F. JSON (Veo only).** Structured scene-by-scene continuity. See `veo.md`.

Extracted rules inside block: NONE

## 279ea25a6f1889d4 — video/SKILL.md:91-91 (paragraph)

Default output language follows the user. The final AI prompt itself goes in English unless the user asks otherwise — Seedance, Kling, and Veo all perform better in English.

Extracted rules inside block: NONE

## ee538e8c15981b39 — video/SKILL.md:95-95 (heading)

# Final response style

Extracted rules inside block: NONE

## c76a03188f12e8bf — video/SKILL.md:97-97 (paragraph)

Prefer: ready-to-copy prompts, clear section labels, production language, motivated camera and light direction, strict continuity blocks, model-specific syntax, direct fixes.

Extracted rules inside block: d7ef31af9c08

## c95fa4e7d6d88fcd — video/SKILL.md:99-99 (paragraph)

Avoid: long theory unless asked, academic lectures, vague inspiration, decorative jargon, "cinematic masterpiece" filler, prompts without camera and light, prompts without continuity, stacking more than two director references, abstract emotions without physical translation.

Extracted rules inside block: a33aa9875120

## df750a04b6c32566 — video/SKILL.md:101-101 (paragraph)

When in doubt about a model-specific detail — re-read the model file before writing the final prompt. It costs nothing and prevents bad output.

Extracted rules inside block: NONE

## 5d21215ec63a8def — video/SKILL.md:105-105 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 74aa0120788fbf83 — video/references/animatic-keyframes.md:1-1 (heading)

# Keyframes for an animatic (opornye kadry)

Extracted rules inside block: NONE

## e45b5a48d0d3c764 — video/references/animatic-keyframes.md:3-3 (paragraph)

This is the still-panel layer. A storyboard keyframe is not a frame grab of footage — it is a single drawn image that must carry one story-beat with **no motion and (usually) no face**. The animatic hangs off these panels. A panel that only looks good is wallpaper; a panel must report its story function, its drama, and the motion it cannot show, all frozen.

Extracted rules inside block: 8527c39c05d1

## 99ca86c267a55280 — video/references/animatic-keyframes.md:5-5 (paragraph)

This file converts a beat sheet / treatment into **opornye kadry**, then into image-generation prompts. It sits on top of `dramaturgy.md` (§2 Details Law, §10 three-layer method, §11 shot card, §12 rhythm ladder, §15 check) and `universal-rules.md` (U1 skeleton, U11 final image). Pairs with `camera-lighting-vocabulary.md` for framing/lens/light tokens, `role-modes.md` §4 for the function taxonomy, `patterns-and-genres.md` (Action genre, Escalation pattern) for the spatial-clarity spine, and `seedance.md` / `kling.md` / `veo.md` to animate each locked frame. Output stays compatible with Storyboard format C: `Time | Shot | Function | Action | Camera | Light | Sound | Emotion`.

Extracted rules inside block: NONE

## 8722ac33ffbe9352 — video/references/animatic-keyframes.md:7-7 (paragraph)

The running brief through every example below: drag/drift race spot, cold combative palette (steel blue, cyan, magenta, mercury-white; **red and green as accents only**; amber only as the start-tree's alien pulse or a toxic spill), faces absent or unusably fragmented. Swap subject as the task demands — the method holds.

Extracted rules inside block: NONE
