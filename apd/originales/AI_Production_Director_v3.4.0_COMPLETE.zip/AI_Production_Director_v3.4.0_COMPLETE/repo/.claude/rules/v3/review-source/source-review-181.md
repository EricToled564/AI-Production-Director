# Source coverage review 181/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 1dabe24e91cfd426 — video/references/universal-rules.md:100-100 (heading)

## 8. U7. Character consistency anchor

Extracted rules inside block: NONE

## 8ffa6d774c07fdf3 — video/references/universal-rules.md:102-102 (paragraph)

Anchor identity at the START of every prompt. In a multi-clip sequence, repeat the full identity block in every single prompt. Video generators have no memory between generations. Treat every clip like briefing a brilliant intern with memory damage.

Extracted rules inside block: NONE

## 62fd0dcfd162c9aa — video/references/universal-rules.md:104-104 (paragraph)

Identity block must include: face shape, eye color, skin tone. Hair color, length, style. Facial hair. Exact clothing items. Distinctive accessories.

Extracted rules inside block: d11ce22fc4fc

## 658ec9c90690feb4 — video/references/universal-rules.md:106-106 (paragraph)

Model-specific syntax for character locking:

Extracted rules inside block: NONE

## 95a98bfad0b41a6b — video/references/universal-rules.md:107-107 (list_item)

- Seedance: `@img1` reference + identity block (see `seedance.md` §10)

Extracted rules inside block: NONE

## ea0b71ca80dd65f6 — video/references/universal-rules.md:108-108 (list_item)

- Kling 1.x – 2.x: Element Binding with 3-4 reference images (see `kling.md` §7)

Extracted rules inside block: NONE

## 579cb62d3937ee8f — video/references/universal-rules.md:109-109 (list_item)

- Kling 3.0: in-prompt `[Character A: <full identity>]` labels, optionally combined with Element Library (see `kling.md` §3)

Extracted rules inside block: NONE

## 0ff2c8e5f1d4a44e — video/references/universal-rules.md:110-110 (list_item)

- Veo: reference ingredients / JSON identity (see `veo.md`)

Extracted rules inside block: NONE

## 10a74660bd1e796a — video/references/universal-rules.md:112-112 (heading)

## 9. U8. No contradictions

Extracted rules inside block: NONE

## 424639e0316421f9 — video/references/universal-rules.md:114-114 (paragraph)

The model obeys the strongest signal. Contradictions produce artifacts.

Extracted rules inside block: NONE

## 9460f35aa3857665 — video/references/universal-rules.md:116-116 (list_item)

- Bad. "Still pond" + "flowing water."

Extracted rules inside block: NONE

## 2fadb2341d90ae48 — video/references/universal-rules.md:117-117 (list_item)

- Bad. "Close-up" + "wide cinematic landscape."

Extracted rules inside block: NONE

## 49bf130d026c6a4e — video/references/universal-rules.md:118-118 (list_item)

- Bad. "Quiet moment" + "explosive action."

Extracted rules inside block: NONE

## c7c2b59572e9d25e — video/references/universal-rules.md:120-120 (heading)

## 10. U9. Concrete physical detail over abstract concept

Extracted rules inside block: NONE

## f78c66a48a270208 — video/references/universal-rules.md:122-122 (paragraph)

"Loneliness" does not render. "A man sitting alone, shoulders collapsed, face lit by blue phone glow, empty bottles on the table" does.

Extracted rules inside block: 84bc57465f9e

## 464565079537fd89 — video/references/universal-rules.md:124-124 (paragraph)

This is the same rule as the Details Law in section 1, viewed from a different angle. Section 1 is the audit. This is the principle.

Extracted rules inside block: NONE

## e23c1e32a344a58a — video/references/universal-rules.md:126-126 (paragraph)

Corollary — **consequence prompting**. Current models render real physics, so describe the consequence of an action, not just the action: tires kick up water curtains; the hand grips the jar and the lid actually unscrews; the impact shatters the surface into a spider-web pattern. Action chains where each step forces the next also work as QA — a broken chain exposes a failed generation at a glance.

Extracted rules inside block: NONE

## 888376c5c0894838 — video/references/universal-rules.md:128-128 (heading)

## 11. U10. Duration discipline

Extracted rules inside block: NONE

## 19846d77c8938cb4 — video/references/universal-rules.md:130-130 (paragraph)

Most models work in 5-10 second clips. Longer narratives live in multiple clips stitched in the editor. Do not cram a 30-second story into a 5-second prompt.

Extracted rules inside block: 140f62653896

## b9ce33a0b23abecc — video/references/universal-rules.md:132-132 (paragraph)

Default splits:

Extracted rules inside block: NONE

## 6ebbe06e594013f2 — video/references/universal-rules.md:134-134 (list_item)

- 10s = 2 clips × 5s

Extracted rules inside block: NONE

## 208ed471bf86a324 — video/references/universal-rules.md:135-135 (list_item)

- 15s = 3 × 5s

Extracted rules inside block: NONE

## 3e2c75a5ebcbd9d4 — video/references/universal-rules.md:136-136 (list_item)

- 30s = 6 × 5s

Extracted rules inside block: NONE

## 7748e94f226ccc93 — video/references/universal-rules.md:137-137 (list_item)

- 60s = 12 × 5s

Extracted rules inside block: NONE

## 817fbacdea166f4e — video/references/universal-rules.md:139-139 (paragraph)

Three exceptions:

Extracted rules inside block: NONE

## bc4753a1bff05666 — video/references/universal-rules.md:140-140 (list_item)

- Seedance — 2-3 shots inside one 5-10s clip via "Cut to" syntax (see `seedance.md` §8).

Extracted rules inside block: NONE

## 1047716a6a25be11 — video/references/universal-rules.md:141-141 (list_item)

- Kling 3.0 — up to 6 shots inside one generation, up to 15s, with native audio and dialogue (see `kling.md` §3).

Extracted rules inside block: NONE

## c02041043b69d38d — video/references/universal-rules.md:142-142 (list_item)

- Seedance 2.5 — up to 30s in one pass. The working structure is consecutive stages, each with one primary state change and an explicit visible end state (see `seedance-25.md` §6).

Extracted rules inside block: NONE

## 4116691bde6a5774 — video/references/universal-rules.md:144-144 (heading)

## 12. U11. The final image rule

Extracted rules inside block: NONE

## 23368befe5b0fdaa — video/references/universal-rules.md:146-146 (paragraph)

Every clip needs a clear final frame. The model uses the ending as emotional destination.

Extracted rules inside block: NONE
