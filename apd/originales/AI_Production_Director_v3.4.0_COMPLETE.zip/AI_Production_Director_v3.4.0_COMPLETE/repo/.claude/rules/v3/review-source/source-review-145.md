# Source coverage review 145/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 91fd8d546b6b6026 — video/references/dramaturgy.md:282-282 (list_item)

- One main emotion.

Extracted rules inside block: NONE

## 5b26009f25fe0486 — video/references/dramaturgy.md:283-283 (list_item)

- One visual motif.

Extracted rules inside block: NONE

## b8d894b54fbafeb1 — video/references/dramaturgy.md:284-284 (list_item)

- One anchor object.

Extracted rules inside block: NONE

## bbcd169766974c7c — video/references/dramaturgy.md:285-285 (list_item)

- One break.

Extracted rules inside block: NONE

## 18033b1fa2c4d67b — video/references/dramaturgy.md:286-286 (list_item)

- One final image.

Extracted rules inside block: NONE

## e7ad797d4cf5f75a — video/references/dramaturgy.md:288-288 (paragraph)

Example.

Extracted rules inside block: NONE

## 2553452bdde2ec0d — video/references/dramaturgy.md:290-290 (list_item)

- Emotion. Guilt.

Extracted rules inside block: NONE

## 89f48e6876488bcd — video/references/dramaturgy.md:291-291 (list_item)

- Motif. The hero keeps being reflected in glass surfaces (window, phone screen, elevator door).

Extracted rules inside block: NONE

## 0c2a0a13c88a49c4 — video/references/dramaturgy.md:292-292 (list_item)

- Anchor object. A phone with one unread message.

Extracted rules inside block: NONE

## 13e66d4dd95c68e3 — video/references/dramaturgy.md:293-293 (list_item)

- Break. The hero deletes the message.

Extracted rules inside block: NONE

## 8b3ee5ca1c939170 — video/references/dramaturgy.md:294-294 (list_item)

- Final image. The hero's face stays reflected in the darkened phone screen.

Extracted rules inside block: NONE

## 959013344c8b9556 — video/references/dramaturgy.md:296-296 (paragraph)

This set can be storyboarded, prompted, and cut together into something that carries real weight. It beats stacking "cinematic, professional, high quality, masterpiece" forever.

Extracted rules inside block: NONE

## 0803cde634bd7c97 — video/references/dramaturgy.md:298-298 (heading)

## 14. Worked example. Guilt, 30 seconds

Extracted rules inside block: NONE

## 75394cfde052437b — video/references/dramaturgy.md:300-300 (heading)

### Five anchors

Extracted rules inside block: NONE

## a4c99ac81453ac19 — video/references/dramaturgy.md:302-302 (list_item)

- Emotion. Guilt.

Extracted rules inside block: NONE

## 3da3da1bc82a3b81 — video/references/dramaturgy.md:303-303 (list_item)

- Motif. Reflections in glass.

Extracted rules inside block: NONE

## c3e14db65bee9ced — video/references/dramaturgy.md:304-304 (list_item)

- Anchor object. Phone with unread message.

Extracted rules inside block: NONE

## dcf42785e49bc3f9 — video/references/dramaturgy.md:305-305 (list_item)

- Break. He deletes it.

Extracted rules inside block: NONE

## 6b9d9640d449fe4a — video/references/dramaturgy.md:306-306 (list_item)

- Final image. His face ghosted on the dark phone screen.

Extracted rules inside block: NONE

## ab4f3fa1e8169c1c — video/references/dramaturgy.md:308-308 (heading)

### Layer 1. Dramatic beats

Extracted rules inside block: NONE

## 870b8bdf44d2fc76 — video/references/dramaturgy.md:310-310 (list_item)

- 0-3s. Hook. Phone buzzes on a dark desk. His face lit from below.

Extracted rules inside block: NONE

## 2210373509de202f — video/references/dramaturgy.md:311-311 (list_item)

- 3-10s. Context. Small office after hours. Empty cubicles. Cold fluorescent. His reflection in the monitor.

Extracted rules inside block: NONE

## 63bcfc76768cac50 — video/references/dramaturgy.md:312-312 (list_item)

- 10-18s. Pressure. He stares at the message preview. His jaw tightens. Hand hovers.

Extracted rules inside block: NONE

## 38038977e76ee942 — video/references/dramaturgy.md:313-313 (list_item)

- 18-22s. Crack. He starts to type. Stops. Deletes character by character.

Extracted rules inside block: NONE

## a3d2d04391c84b15 — video/references/dramaturgy.md:314-314 (list_item)

- 22-26s. Acceleration. Tight cuts. Finger. Screen. Eye. Breath. Window reflection.

Extracted rules inside block: NONE

## 50d2bcc9720a3340 — video/references/dramaturgy.md:315-315 (list_item)

- 26-28s. Impact. He taps Delete Conversation. One tap. Silence.

Extracted rules inside block: NONE

## 24bc35f69c3170d3 — video/references/dramaturgy.md:316-316 (list_item)

- 28-30s. Aftermath. Screen goes black. His face remains reflected in the dark glass.

Extracted rules inside block: NONE

## 134dc353326db6ee — video/references/dramaturgy.md:318-318 (heading)

### Layer 2. Shot functions (selected)

Extracted rules inside block: NONE

## 574d9a131f521f31 — video/references/dramaturgy.md:320-320 (list_item)

- Shot 03. Establish. Empty office.

Extracted rules inside block: NONE

## 8b472ed7b1a7c2f4 — video/references/dramaturgy.md:321-321 (list_item)

- Shot 05. Power. He is alone. The room looms.

Extracted rules inside block: NONE
