# Source coverage review 209/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## a381c149230ef905 — visual-prompt-forge/adapters/hailuo.md:45-45 (table_row)

| `whip` | "Fast whip pan with motion blur." |

Extracted rules inside block: NONE

## 649228da262cd7ce — visual-prompt-forge/adapters/hailuo.md:46-46 (table_row)

| `rack` | "Rack focus from foreground to background." |

Extracted rules inside block: NONE

## c3d3319b88dbfd14 — visual-prompt-forge/adapters/hailuo.md:48-48 (heading)

## Iteration workflow

Extracted rules inside block: NONE

## 06d72c37a78262e1 — visual-prompt-forge/adapters/hailuo.md:50-50 (list_item)

1. Draft the shot on Hailuo with `prompt_optimizer=false`. Cheap, fast.

Extracted rules inside block: cf3f591a6ef3

## 3506285067bffccb — visual-prompt-forge/adapters/hailuo.md:51-51 (list_item)

2. Lock the camera move, framing, and timing that read best.

Extracted rules inside block: 4cb6d00484ad

## 0b0fce8ee899ed05 — visual-prompt-forge/adapters/hailuo.md:52-52 (list_item)

3. Re-generate the keeper on the right final-tier model: **Kling** for motion finals, **Veo** for dialogue/lipsync, **Seedance** for multi-shot sequences.

Extracted rules inside block: c6ab7fac5c88

## 5931c42a13190d92 — visual-prompt-forge/adapters/hailuo.md:53-53 (list_item)

4. Carry the exact prompt forward, the adapters share the same five-layer anatomy, so the prompt body ports with only parameter changes.

Extracted rules inside block: f3d705e0d43a

## 47c12ca900057356 — visual-prompt-forge/adapters/hailuo.md:55-55 (heading)

## Example

Extracted rules inside block: NONE

## ed296557446f4da8 — visual-prompt-forge/adapters/hailuo.md:57-57 (paragraph)

**Draft of the `motion = "push"` shot.**

Extracted rules inside block: NONE

## 7c821f09428bfbe2 — visual-prompt-forge/adapters/hailuo.md:59-61 (code)

```
Camera dollies forward slowly at a steady pace. A founder in his mid-thirties with salt-and-pepper hair in a navy crewneck sits at his laptop in a minimalist home office and leans slightly forward toward window light off-camera left. Soft natural side-light, warm afternoon. Warm filmic color grade, muted teal shadows. Calm operator mood.
```

Extracted rules inside block: NONE

## 82644922aa71693f — visual-prompt-forge/adapters/hailuo.md:63-63 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 8ecd1c0e264b3412 — visual-prompt-forge/adapters/hailuo.md:65-65 (list_item)

- **Don't ship Hailuo drafts as finals.** Re-roll the keeper on a final-tier model.

Extracted rules inside block: 6e41c34e6c78

## d4ca46d3051b0434 — visual-prompt-forge/adapters/hailuo.md:66-66 (list_item)

- **Don't enable the prompt optimizer for series work.** Auto-rewrite breaks shot-to-shot consistency.

Extracted rules inside block: c129c5234396

## ef20e65a0fe6fb35 — visual-prompt-forge/adapters/hailuo.md:67-67 (list_item)

- **Don't stack two camera moves.** One move per shot.

Extracted rules inside block: c13cb19d4c53

## 80649edb2d635714 — visual-prompt-forge/adapters/hailuo.md:68-68 (list_item)

- **Don't include text content.** Composite captions in post.

Extracted rules inside block: c513fc2be570

## 65015636095bcce8 — visual-prompt-forge/adapters/hailuo.md:69-69 (list_item)

- **Don't over-polish the draft prompt.** Spend words on motion and framing; save the photographic detail for the final-tier re-roll.

Extracted rules inside block: 4a6552a51f8e

## 9f34654236152817 — visual-prompt-forge/adapters/hailuo.md:71-71 (heading)

## Output handoff

Extracted rules inside block: NONE

## dfb1cbb62bce7f06 — visual-prompt-forge/adapters/hailuo.md:73-73 (paragraph)

Hailuo output is a draft used to choose the shot. The deliverable comes from the final-tier re-roll. If a Hailuo take is genuinely good enough to keep, treat it like any other clip: editorial assembly, text-overlay compositing, color grade, audio.

Extracted rules inside block: NONE

## caf7a96e9b102252 — visual-prompt-forge/adapters/ideogram.md:1-1 (heading)

# Adapter: Ideogram (v3)

Extracted rules inside block: NONE

## bc51ec85583a9649 — visual-prompt-forge/adapters/ideogram.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: 10f229855b04

## 9005626c375c4097 — visual-prompt-forge/adapters/ideogram.md:5-5 (paragraph)

Ideogram is the only generator that reliably renders text inside images. Use it for cases where text-as-image is the deliverable, posters, branded social tiles, signage, packaging mockups. For everything else, default to Flux or Midjourney and composite text separately.

Extracted rules inside block: c30661bd947b

## 414c09525a6ecc2f — visual-prompt-forge/adapters/ideogram.md:7-7 (paragraph)

This adapter has **two modes**: composited (default) and text-in-image (override).

Extracted rules inside block: NONE

## c397d709a8ac5976 — visual-prompt-forge/adapters/ideogram.md:9-9 (heading)

## Mode 1: Composited (default)

Extracted rules inside block: NONE

## 5ae39cd004d16d79 — visual-prompt-forge/adapters/ideogram.md:11-11 (paragraph)

Same as Flux, generate the image clean, composite text in post. Use when Ideogram is being chosen for general image quality, not text rendering. Syntax matches Flux conventions.

Extracted rules inside block: 63bc557f81dc

## d13fc4bf57d82692 — visual-prompt-forge/adapters/ideogram.md:13-13 (heading)

## Mode 2: Text-in-image (override)

Extracted rules inside block: NONE

## 4f0a61993dda4f99 — visual-prompt-forge/adapters/ideogram.md:15-15 (paragraph)

Use when the on-screen text is meant to appear as part of the image itself, a poster headline, a sign in the scene, a packaging label. This is the only case where a generator prompt contains the text content.

Extracted rules inside block: ec8795138a19

## ffad65667e4b072b — visual-prompt-forge/adapters/ideogram.md:17-17 (paragraph)

**To trigger Mode 2, the shot must have an explicit override flag in rationale**, e.g.:

Extracted rules inside block: b6dd2d46ff28

## edf947a6bcb6d73a — visual-prompt-forge/adapters/ideogram.md:18-20 (code)

```
"rationale": "Text-in-image override: poster shot, headline must render as part of composition"
```

Extracted rules inside block: NONE

## c5ddff4b4140419c — visual-prompt-forge/adapters/ideogram.md:22-22 (paragraph)

If you don't see that override flag, default to Mode 1.

Extracted rules inside block: d8cf8ae5938a

## a97c9d3f3c05e51e — visual-prompt-forge/adapters/ideogram.md:24-24 (heading)

## Syntax pattern (Mode 2)

Extracted rules inside block: NONE
