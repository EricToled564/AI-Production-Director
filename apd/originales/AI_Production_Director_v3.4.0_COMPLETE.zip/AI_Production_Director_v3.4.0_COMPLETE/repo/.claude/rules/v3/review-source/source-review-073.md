# Source coverage review 73/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 70b8b7734aaa7926 — image/references/structural.md:100-100 (list_item)

- "Match layout precisely"

Extracted rules inside block: NONE

## b99edca3c08180cd — image/references/structural.md:101-101 (list_item)

- "Keep proportions from reference"

Extracted rules inside block: NONE

## eedef8242cad48b6 — image/references/structural.md:105-105 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## cf7fb5aa185a2a9a — image/references/text-rendering.md:1-1 (heading)

# Text Rendering & Infographics

Extracted rules inside block: NONE

## 71753aa74792f843 — image/references/text-rendering.md:3-3 (paragraph)

Универсальные стили, layout-типы, примеры. Применимо к обеим моделям, но детали рендера расходятся:

Extracted rules inside block: NONE

## 4d55110738834d93 — image/references/text-rendering.md:5-5 (list_item)

- **Nano Banana:** SOTA по 100+ языкам, multi-language в одном кадре, можно называть конкретные шрифты («Century Gothic 12px», «Brush Script»). См. [nano-banana.md](nano-banana.md).

Extracted rules inside block: NONE

## 68f6423e5a7c29f8 — image/references/text-rendering.md:6-6 (list_item)

- **GPT Image 2:** EXACT TEXT в `"..."` или ALL CAPS, добавляй «no extra words / no duplicate text», для мелкого текста — `quality: high`. См. [gpt-image.md](gpt-image.md).

Extracted rules inside block: NONE

## 62d1a3e84fc98fb2 — image/references/text-rendering.md:8-8 (heading)

## Prompt Structure

Extracted rules inside block: NONE

## d655ed60ba5b5c1d — image/references/text-rendering.md:10-18 (code)

```
Create an educational infographic about [TOPIC].
Target Audience: [GRADE/LEVEL]
Content: [SPECIFIC FACTS/SEQUENCE]
Title: "[TITLE TEXT]"
Visual Style: [STYLE]
Layout: [LAYOUT TYPE]
Format: [ASPECT RATIO]
```

Extracted rules inside block: NONE

## ce1af5b13a0f8dfb — image/references/text-rendering.md:20-20 (heading)

## Visual Styles

Extracted rules inside block: NONE

## 814bc804dbbf16cd — image/references/text-rendering.md:22-22 (paragraph)

**Educational/Friendly:**

Extracted rules inside block: NONE

## 3046de3c309e8104 — image/references/text-rendering.md:23-23 (list_item)

- Paper Cutout: construction paper collage look

Extracted rules inside block: NONE

## 483c6b9b42fe1f6c — image/references/text-rendering.md:24-24 (list_item)

- Claymation/Plasticine: 3D tactile, Wallace & Gromit style

Extracted rules inside block: NONE

## 8cc229bd014a15d5 — image/references/text-rendering.md:25-25 (list_item)

- Kawaii/Cute Vector: rounded edges, pastel colors

Extracted rules inside block: NONE

## a91e99be3b36801c — image/references/text-rendering.md:26-26 (list_item)

- Storybook Watercolor: soft painted textures

Extracted rules inside block: NONE

## 9a972f873d63968a — image/references/text-rendering.md:27-27 (list_item)

- Chalkboard Art: white chalk on green/black

Extracted rules inside block: NONE

## ebe2827a9b29fbce — image/references/text-rendering.md:28-28 (list_item)

- Pixel Art (8-Bit): retro gaming nostalgia

Extracted rules inside block: NONE

## 023379607390e5d5 — image/references/text-rendering.md:30-30 (paragraph)

**Technical/Professional:**

Extracted rules inside block: NONE

## 3cd6a3df13493629 — image/references/text-rendering.md:31-31 (list_item)

- Isometric 3D: video game map style, processes

Extracted rules inside block: NONE

## 0088bf6c16356317 — image/references/text-rendering.md:32-32 (list_item)

- Blueprint/Schematic: white lines on blue

Extracted rules inside block: NONE

## e1d361667e28abb3 — image/references/text-rendering.md:33-33 (list_item)

- Da Vinci Notebook: renaissance sketch, scientific

Extracted rules inside block: NONE

## aa8dd82aa2d3332c — image/references/text-rendering.md:34-34 (list_item)

- UI/UX Wireframe: app blueprint style

Extracted rules inside block: NONE

## b1b907cde2e893d5 — image/references/text-rendering.md:35-35 (list_item)

- Dashboard: analytics screen with numbers

Extracted rules inside block: NONE

## 70570fe22e1af4c8 — image/references/text-rendering.md:37-37 (paragraph)

**Stylized:**

Extracted rules inside block: NONE

## 7ce802d06d927194 — image/references/text-rendering.md:38-38 (list_item)

- Cyberpunk/Neon: dark + bright neon accents

Extracted rules inside block: NONE

## a1f6eae1b80ebc2d — image/references/text-rendering.md:39-39 (list_item)

- Graphic Novel/Comic Book: bold outlines, flat colors

Extracted rules inside block: NONE

## b5ebb035db9828d5 — image/references/text-rendering.md:40-40 (list_item)

- Vintage Science Poster: muted, aged paper, fine lines

Extracted rules inside block: NONE

## e6bea17c4c5670ab — image/references/text-rendering.md:41-41 (list_item)

- Pop Art (Warhol): high contrast, bold, dots

Extracted rules inside block: NONE

## 96fc438566611d31 — image/references/text-rendering.md:42-42 (list_item)

- Corporate Memphis/Flat Art: tech company style

Extracted rules inside block: NONE

## 9fc8735da95601fd — image/references/text-rendering.md:44-44 (paragraph)

**Specialized:**

Extracted rules inside block: NONE
