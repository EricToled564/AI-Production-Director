# Source coverage review 107/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2e9b77bd8c842242 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:40-40 (heading)

### shot_01 · 0.0–2.0s · MCU · static

Extracted rules inside block: NONE

## 5df66e2a2ba068d2 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:42-45 (paragraph)

**Beat:** hook · **VO:** "Most founders treat content like a hobby."
**Subject:** founder, looking directly into camera, slight knowing smile, mid-statement.
**On-screen text:** "Most founders treat content like a hobby." (lower-third, hard-cut)
**Rationale:** Hook is provocative but calm, voice carries the bite. Direct eye contact, MCU lock-in.

Extracted rules inside block: NONE

## 2d2f26addb731eb3 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:47-47 (heading)

### shot_02 · 2.0–8.0s · MS · static

Extracted rules inside block: NONE

## 4035804556f92add — storyboard-architect/examples/60s-founder-explainer/storyboard.md:49-51 (paragraph)

**Beat:** stakes · **VO:** "Then they wonder why every post feels like starting over. New idea, new angle, no compounding."
**Subject:** founder, gesturing slightly with one hand, explaining, eye contact maintained.
**Rationale:** Stakes beat. Pulled out to MS to let the gesture read. VO does the work, no on-screen text needed.

Extracted rules inside block: NONE

## 5ec2afc1b7f61fe1 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:53-53 (heading)

### shot_03 · 8.0–14.0s · ECU · static

Extracted rules inside block: NONE

## be8657ec352240f4 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:55-58 (paragraph)

**Beat:** stakes · **VO:** "It's not creativity. It's missing infrastructure."
**Subject:** close on founder's eyes, considered expression, slight head tilt.
**On-screen text:** "It's missing infrastructure." (coral, lower-third, type-on)
**Rationale:** ECU pulls the audience into the realization moment. Text reinforces the line that needs to land.

Extracted rules inside block: NONE

## 2b83e485b8980a01 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:60-60 (heading)

### shot_04 · 14.0–24.0s · MCU · push

Extracted rules inside block: NONE

## 6b054933b3ae543b — storyboard-architect/examples/60s-founder-explainer/storyboard.md:62-64 (paragraph)

**Beat:** insight · **VO:** "Every brand has a voice. Most founders never extract it. So every post starts from scratch."
**Subject:** founder, leaning slightly forward, more energy in delivery, hands resting on desk.
**Rationale:** Slow push as the thesis builds. VO is the load-bearing element here.

Extracted rules inside block: 6b0bd36bc2b5

## 04e6e3ebb56a5cdd — storyboard-architect/examples/60s-founder-explainer/storyboard.md:66-66 (heading)

### shot_05 · 24.0–32.0s · MS · static

Extracted rules inside block: NONE

## c906f917f8ade9e9 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:68-71 (paragraph)

**Beat:** insight · **VO:** "Extract it once. Lock it in code. Now every post compounds."
**Subject:** founder gestures toward laptop screen, kanban content pipeline, voice extraction interface, brand-lock file open in editor.
**On-screen text:** "Extract. Lock. Compound." (upper-third, slide-up)
**Rationale:** Show the artifact. Text reinforces the three-step pattern. Deep DOF keeps the screen legible.

Extracted rules inside block: NONE

## f309462d5c0e312d — storyboard-architect/examples/60s-founder-explainer/storyboard.md:73-73 (heading)

### shot_06 · 32.0–42.0s · MCU · static

Extracted rules inside block: NONE

## 8a9b7a09ce03daf2 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:75-78 (paragraph)

**Beat:** proof · **VO:** "Hundreds of videos rendered from code. 48-hour content cycles. One operator."
**Subject:** founder, calm steady delivery, eye contact, hands folded.
**On-screen text:** "hundreds of videos · 48hr cycles · 1 operator" (upper-third, fade)
**Rationale:** Proof beat, concrete numbers. Stat callout lets viewer absorb visually while VO confirms.

Extracted rules inside block: NONE

## c16f5d71e6b2b956 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:80-80 (heading)

### shot_07 · 42.0–50.0s · MS · pull

Extracted rules inside block: NONE

## 1b547b57062826b1 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:82-84 (paragraph)

**Beat:** insight · **VO:** "Not because we work harder. Because the system runs."
**Subject:** founder, slight smile, settled into the explanation, room visible around him.
**Rationale:** Slow pull releases tension. The thesis lands. VO carries, text would dilute.

Extracted rules inside block: NONE

## 4bdbe4b05dd792fc — storyboard-architect/examples/60s-founder-explainer/storyboard.md:86-86 (heading)

### shot_08 · 50.0–60.0s · MCU · static

Extracted rules inside block: NONE

## 7a1aaa2fd1e046cc — storyboard-architect/examples/60s-founder-explainer/storyboard.md:88-91 (paragraph)

**Beat:** cta · **VO:** "If this sounds like the version of content you actually want, run a free scan."
**Subject:** founder, calm, looks directly into camera one more time, almost-smile, settled.
**On-screen text:** "whystrohm.com/scan" (coral, lower-third, type-on)
**Rationale:** CTA beat. Static MCU brings it home. URL holds in lower-third for full read-twice duration.

Extracted rules inside block: NONE

## c11a83613ccb124f — storyboard-architect/examples/60s-founder-explainer/storyboard.md:95-95 (heading)

## Handoff notes

Extracted rules inside block: NONE

## 5721284107bea8f4 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:97-97 (list_item)

- **For image generation:** run `visual-prompt-forge` against `shots.json`

Extracted rules inside block: NONE

## 3df28c139aa43ee5 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:98-98 (list_item)

- **For HTML preview:** run `storyboard-html-preview` against this folder

Extracted rules inside block: NONE

## 42c0d55e9bfff7df — storyboard-architect/examples/60s-founder-explainer/storyboard.md:99-99 (list_item)

- **For QA:** run `visual-asset-critic` per shot

Extracted rules inside block: NONE

## bfb73eb05409c0fd — storyboard-architect/examples/60s-founder-explainer/storyboard.md:101-101 (heading)

## Audit trail

Extracted rules inside block: NONE

## b54b3eddf27ca553 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:103-103 (paragraph)

Generated against `brand-lock.snapshot.md` (frozen at 2026-05-07T14:31:00Z, source `brand-packs/whystrohm.md`).

Extracted rules inside block: NONE

## 9ec7ecbd546a2dd4 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:1-3 (paragraph)

<!-- snapshot taken: 2026-05-08T14:34:24Z -->
<!-- source: brand-packs/whystrohm.md -->
<!-- storyboard: shotkit-explainer -->

Extracted rules inside block: NONE

## f0ee2c7105913e2a — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:5-5 (heading)

# Brand Lock: WhyStrohm

Extracted rules inside block: NONE

## 584d78b6722c11f5 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:7-7 (heading)

## Identity

Extracted rules inside block: NONE

## 741a9918008c4f70 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:9-12 (paragraph)

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

Extracted rules inside block: NONE

## c04d46e643b010e1 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:14-14 (heading)

## Palette

Extracted rules inside block: NONE

## c8118dc4857253c0 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:16-16 (table_row)

| Role | Hex | Use |

Extracted rules inside block: 02f8afcf0321

## bbb16b34368fbf2d — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:18-18 (table_row)

| Background | `#F5F0E8` | Cream, primary canvas |

Extracted rules inside block: NONE

## cce39a383cd568e8 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:19-19 (table_row)

| Ink | `#2A2A32` | Near-black, primary text and dark elements |

Extracted rules inside block: NONE
