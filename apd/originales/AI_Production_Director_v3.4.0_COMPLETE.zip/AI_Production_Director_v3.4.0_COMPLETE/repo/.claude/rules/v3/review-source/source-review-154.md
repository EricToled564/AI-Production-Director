# Source coverage review 154/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f2f719cdae38b0bd — video/references/kling.md:146-146 (list_item)

- Multi-character with distinct voices

Extracted rules inside block: NONE

## 141f6a9563b6df3d — video/references/kling.md:147-147 (list_item)

- Image-to-video where text on the image must stay legible

Extracted rules inside block: 36c4fdb541d5

## 4cd1babe084a78c9 — video/references/kling.md:149-149 (paragraph)

Within the 3.0 family: talking heads and dialogue on a budget → **Turbo** (best lip-sync per dollar, audio included, 1080p cap); reference-heavy or editing work, 4K delivery → **Omni**; everything else → base 3.0.

Extracted rules inside block: NONE

## 99f397e477ad9086 — video/references/kling.md:151-151 (paragraph)

For everything else (single clip, no dialogue, < 10s, character lock via reference images, Motion Brush) — older versions still work and are cheaper.

Extracted rules inside block: NONE

## 43379521fa7e9d8a — video/references/kling.md:153-153 (heading)

### API parameters (3.0, fal/official)

Extracted rules inside block: NONE

## b553e446f6223cac — video/references/kling.md:155-155 (list_item)

- `cfg_scale` 0-1, default 0.5. 0.3-0.4 = creative freedom, 0.7-1.0 = strict prompt adherence (product / explainer work).

Extracted rules inside block: NONE

## ba2a8d6939b83e83 — video/references/kling.md:156-156 (list_item)

- `duration` — per-shot durations must sum to ≤ 15s.

Extracted rules inside block: a1840d2d23c0

## 9c28d518d99bc89d — video/references/kling.md:157-157 (list_item)

- `aspect_ratio` — 16:9 / 9:16 / 1:1.

Extracted rules inside block: NONE

## 86eb93aa7ebbf4fc — video/references/kling.md:158-158 (list_item)

- `generate_audio` — bool. There is no "no music" toggle: the model lays music even against a negative prompt. If you need clean audio, generate with audio off or strip the track in post.

Extracted rules inside block: NONE

## 7e6981304eb46ef0 — video/references/kling.md:160-160 (heading)

## 4. Prompt formula (1.x – 2.x)

Extracted rules inside block: NONE

## 269f620be60ab4b2 — video/references/kling.md:162-162 (paragraph)

For 1.6, 2.1 Pro, 2.5 Turbo Pro, 2.6 Pro:

Extracted rules inside block: NONE

## f61a9782832903b3 — video/references/kling.md:164-171 (code)

```text
Subject (with specific details)
+ Subject Movement (one clean verb phrase)
+ Scene (3-5 elements max)
+ Camera Language
+ Lighting
+ Atmosphere
```

Extracted rules inside block: NONE

## a6cc4ad9ca18ea6a — video/references/kling.md:173-173 (paragraph)

Write as flowing prose. Kling 1.x – 2.x dislikes fragmented tag-style inputs.

Extracted rules inside block: NONE

## 2720d8369adb8362 — video/references/kling.md:175-175 (paragraph)

For Kling 3.0, use the multi-shot structure from section 3 instead.

Extracted rules inside block: bb2ddcc6443a

## 92f648e86ece4b60 — video/references/kling.md:177-177 (heading)

## 5. Prompt length by model

Extracted rules inside block: NONE

## 8da47a6cf4a52123 — video/references/kling.md:179-179 (list_item)

- 1.6. Keep it simple, minimal.

Extracted rules inside block: NONE

## f184a0abde215c52 — video/references/kling.md:180-180 (list_item)

- 2.5 Turbo Pro. 3-4 elements max. 50-80 words.

Extracted rules inside block: NONE

## 19e5c6226626a3ad — video/references/kling.md:181-181 (list_item)

- 2.6 Pro. 5-7 elements. 50-80 words.

Extracted rules inside block: NONE

## 2d6923ff8f25523b — video/references/kling.md:182-182 (list_item)

- 3.0. Longer prompts welcome — multi-shot needs explicit structure (see section 3). Plan ~30-60 words per shot.

Extracted rules inside block: NONE

## a6ce2e3baff35826 — video/references/kling.md:183-183 (list_item)

- Image-to-video (any version). 20-40 words. Shorter, motion-focused.

Extracted rules inside block: NONE

## 39842d0f3e2ad512 — video/references/kling.md:185-185 (paragraph)

Long prompts on 1.x – 2.x = melted outputs. Compress ruthlessly. On 3.0, structure beats length.

Extracted rules inside block: NONE

## 8440fec3f0f0a6fc — video/references/kling.md:187-187 (heading)

## 6. Negative prompts (critical rule)

Extracted rules inside block: NONE

## 780dd4fc5b09a594 — video/references/kling.md:189-189 (paragraph)

Kling has a dedicated negative prompts field. The field auto-interprets input as exclusion. Do not write "no X". Write the thing itself.

Extracted rules inside block: df72e4582718

## 7e4c3b07f2c2347f — video/references/kling.md:191-192 (paragraph)

Bad. "no robots"
Good. "robots"

Extracted rules inside block: NONE

## 5ef903df4f07f053 — video/references/kling.md:194-195 (paragraph)

Bad. "no blurry faces, no distorted hands"
Good. "blurry faces, distorted hands, melted features"

Extracted rules inside block: NONE

## a09fde66087d30d8 — video/references/kling.md:197-197 (paragraph)

Common effective negatives.

Extracted rules inside block: NONE

## 69581fc8f043d777 — video/references/kling.md:199-201 (code)

```text
low resolution, blurry, distorted hands, extra fingers, melted face, watermark, subtitles, logo, text overlay, jitter, shaking camera, deformed
```

Extracted rules inside block: NONE

## 81a1b677811d5aa6 — video/references/kling.md:203-203 (paragraph)

Keep the list short. Long negative stacks reduce motion and detail.

Extracted rules inside block: NONE

## 01d6b6f7b09b236e — video/references/kling.md:205-205 (heading)

## 7. Element Library and Element Binding (1.x – 2.x)

Extracted rules inside block: NONE

## 91d28f40c226de14 — video/references/kling.md:207-207 (paragraph)

For character consistency across generations, Kling has an Element Library. Upload 3-4 reference images of the character from different angles.

Extracted rules inside block: NONE
