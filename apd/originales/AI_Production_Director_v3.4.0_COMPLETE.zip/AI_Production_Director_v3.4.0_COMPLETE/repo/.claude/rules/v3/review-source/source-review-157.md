# Source coverage review 157/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4ef008bdd9946c31 — video/references/kling.md:325-325 (heading)

### Image-to-video

Extracted rules inside block: NONE

## f6a368e01dd2d136 — video/references/kling.md:327-331 (code)

```text
Preserve [silhouette / label / specific feature]. [Camera movement, one lens]. [One or two motion verbs]. [Atmospheric cue, light change].

Negative field. blurry, distorted hands, melted face, jitter.
```

Extracted rules inside block: NONE

## 5b0d25abdc9e755c — video/references/kling.md:333-333 (heading)

### Worked example. Fashion, image-to-video (2.6 Pro)

Extracted rules inside block: NONE

## f049a21a169f6d28 — video/references/kling.md:335-339 (code)

```text
Preserve silhouette and fabric texture. Slow lateral tracking, 85mm. She turns her head toward camera, exhales through her nose, hair catches golden hour wind. Warm rim light. Confident stillness.

Negative field. blurry, distorted hands, extra fingers, melted face, watermark, motion blur, jitter.
```

Extracted rules inside block: NONE

## c501285e821415f3 — video/references/kling.md:341-341 (heading)

### Multi-shot with dialogue (Kling 3.0)

Extracted rules inside block: NONE

## 541f4881202d92d6 — video/references/kling.md:343-361 (code)

```text
[Character A: Investigator — late 30s, navy raincoat, tired blue eyes, three-day stubble]
[Character B: Witness — early 20s, oversized hoodie, hands wrapped around a paper cup, eyes red from crying]

Master intent: a 12-second interrogation in a fluorescent-lit precinct break room at 2am. The investigator holds back, the witness breaks.

Shot 1 (0-3s). Two-shot, eye level, 35mm. Character A sits across from Character B. Static frame.
Shot 2 (3-6s). OTS over Character A's shoulder. Character B's hands tighten on the paper cup.
Shot 3 (6-9s). Profile close-up on Character A. He slides a photo across the table.
[Character A, low even voice]: "You were there."
Shot 4 (9-12s). Reverse — close-up on Character B. She does not look up.
Immediately, [Character B, fragile broken voice]: "I didn't see anything."

Camera. Locked frames, no movement except the slide of the photo. Sony FX6 feel.
Lighting. Cold overhead fluorescent, slight flicker. Pale skin, hard shadows under the eyes.
Audio. Distant police radio chatter, the buzz of the fluorescent tube, a vending machine humming in the corridor. No music.

Negative field. blurry, distorted hands, extra fingers, melted face, watermark, subtitles, jitter, dialogue overlap.
```

Extracted rules inside block: NONE

## 5c77dbc389b8ab76 — video/references/kling.md:365-365 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 3c9ca76eefe2967b — video/references/patterns-and-genres.md:1-1 (heading)

# Montage patterns and genre modules

Extracted rules inside block: NONE

## d61b633d763a2d99 — video/references/patterns-and-genres.md:3-3 (heading)

## Contents

Extracted rules inside block: NONE

## 791b9b0aa607356c — video/references/patterns-and-genres.md:5-5 (list_item)

1. Montage patterns (6 ready structures)

Extracted rules inside block: 4ea2d740c9fb

## e9b8906041e54df8 — video/references/patterns-and-genres.md:6-6 (list_item)

2. Genre modules (7 archetypes)

Extracted rules inside block: 5e036b5dbfbe

## fb32f2de4be93bfd — video/references/patterns-and-genres.md:7-7 (list_item)

3. Multi-clip story structure

Extracted rules inside block: 23daca849a3b

## 869f6139422f8179 — video/references/patterns-and-genres.md:11-11 (heading)

## 1. Montage patterns

Extracted rules inside block: NONE

## 1988e0340b385042 — video/references/patterns-and-genres.md:13-13 (paragraph)

These are pre-built structures that solve common scene types. Pick one, fill with your specifics.

Extracted rules inside block: NONE

## f08b836b68598114 — video/references/patterns-and-genres.md:15-15 (heading)

### Pattern 1. Escalation

Extracted rules inside block: NONE

## c31baafe0376256b — video/references/patterns-and-genres.md:17-17 (paragraph)

Use for tension builds, reveals, dramatic emphasis.

Extracted rules inside block: 8f04847c2a22

## 6d530ec8fe5acc2c — video/references/patterns-and-genres.md:19-21 (code)

```text
wide -> medium -> close-up -> macro -> reaction close-up -> impact
```

Extracted rules inside block: NONE

## 9a791e09b3fb47d3 — video/references/patterns-and-genres.md:23-23 (heading)

### Pattern 2. Anxiety

Extracted rules inside block: NONE

## 2ce097f4e57dbace — video/references/patterns-and-genres.md:25-25 (paragraph)

Use for psychological pressure, internal conflict, impending bad news.

Extracted rules inside block: 50d97079d8b7

## 47ffddcaf94a6b0d — video/references/patterns-and-genres.md:27-29 (code)

```text
face -> object -> hand -> face -> object closer -> sound cue -> sudden stillness
```

Extracted rules inside block: NONE

## 7abfb320addf21ea — video/references/patterns-and-genres.md:31-31 (heading)

### Pattern 3. Discovery

Extracted rules inside block: NONE

## 26e48893d980a00b — video/references/patterns-and-genres.md:33-33 (paragraph)

Use for revealing a hidden element, exploration, search.

Extracted rules inside block: 1c762875bfb4

## 96bb808653365d99 — video/references/patterns-and-genres.md:35-37 (code)

```text
POV -> empty space -> searching hand -> hidden object -> rack focus -> emotional reaction
```

Extracted rules inside block: NONE

## ccb332310b3c2179 — video/references/patterns-and-genres.md:39-39 (heading)

### Pattern 4. Catastrophe

Extracted rules inside block: NONE

## c4d07ffb30f6c628 — video/references/patterns-and-genres.md:41-41 (paragraph)

Use for comedic or dramatic disaster. Tiny object failures play bigger than explosions.

Extracted rules inside block: 37c83abdc8f5

## 127f339af1641c23 — video/references/patterns-and-genres.md:43-45 (code)

```text
anticipation -> object instability -> reaction -> object falling -> impact -> silence -> emotional collapse
```

Extracted rules inside block: NONE

## 510daa8af2024e2c — video/references/patterns-and-genres.md:47-47 (heading)

### Pattern 5. Commercial product drama

Extracted rules inside block: NONE

## c9b5ffae05ca0cce — video/references/patterns-and-genres.md:49-49 (paragraph)

Use for ads with a hero product.

Extracted rules inside block: 5397f132e042

## b5bbcf34ed46b42e — video/references/patterns-and-genres.md:51-53 (code)

```text
lifestyle setup -> product reveal -> macro texture -> human reaction -> use moment -> hero product shot
```

Extracted rules inside block: NONE

## 67f1bfd266864ede — video/references/patterns-and-genres.md:55-55 (heading)

### Pattern 6. Music video loop

Extracted rules inside block: NONE
