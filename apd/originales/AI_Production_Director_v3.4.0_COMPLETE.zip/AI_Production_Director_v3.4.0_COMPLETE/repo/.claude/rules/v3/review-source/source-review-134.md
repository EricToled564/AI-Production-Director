# Source coverage review 134/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## a39bf92f86c84875 — video/references/camera-lighting-vocabulary.md:44-44 (list_item)

- slow push-in

Extracted rules inside block: NONE

## 21d4c43af06697fa — video/references/camera-lighting-vocabulary.md:45-45 (list_item)

- fast push-in

Extracted rules inside block: NONE

## 7432c755ac469f3b — video/references/camera-lighting-vocabulary.md:46-46 (list_item)

- pull-back

Extracted rules inside block: NONE

## faffa1a7d487c04d — video/references/camera-lighting-vocabulary.md:47-47 (list_item)

- tracking shot

Extracted rules inside block: NONE

## b81cd0bb36bbd9be — video/references/camera-lighting-vocabulary.md:48-48 (list_item)

- lateral tracking

Extracted rules inside block: NONE

## a893609775a2e815 — video/references/camera-lighting-vocabulary.md:49-49 (list_item)

- handheld micro-shake

Extracted rules inside block: NONE

## 3d013d3693297532 — video/references/camera-lighting-vocabulary.md:50-50 (list_item)

- whip pan

Extracted rules inside block: NONE

## ca5fd7f417230acc — video/references/camera-lighting-vocabulary.md:51-51 (list_item)

- snap zoom

Extracted rules inside block: NONE

## 5b6b95132b5c3a9c — video/references/camera-lighting-vocabulary.md:52-52 (list_item)

- rack focus

Extracted rules inside block: NONE

## 43156c91dbdbea39 — video/references/camera-lighting-vocabulary.md:53-53 (list_item)

- tilt up

Extracted rules inside block: NONE

## ec8592d296a6df3a — video/references/camera-lighting-vocabulary.md:54-54 (list_item)

- tilt down

Extracted rules inside block: NONE

## 5bdf325227606809 — video/references/camera-lighting-vocabulary.md:55-55 (list_item)

- orbit

Extracted rules inside block: NONE

## f0f298414b036210 — video/references/camera-lighting-vocabulary.md:56-56 (list_item)

- gimbal glide

Extracted rules inside block: NONE

## d1f04f9658fe31ab — video/references/camera-lighting-vocabulary.md:57-57 (list_item)

- dolly-in

Extracted rules inside block: NONE

## 9a23776c00fcc6c4 — video/references/camera-lighting-vocabulary.md:58-58 (list_item)

- dolly-out

Extracted rules inside block: NONE

## d5ae3b0b38c2a8da — video/references/camera-lighting-vocabulary.md:59-59 (list_item)

- crane shot

Extracted rules inside block: NONE

## 8c15e19026ee0e54 — video/references/camera-lighting-vocabulary.md:60-60 (list_item)

- aerial shot

Extracted rules inside block: NONE

## f08a36d4287d393a — video/references/camera-lighting-vocabulary.md:61-61 (list_item)

- Hitchcock zoom (dolly-zoom)

Extracted rules inside block: NONE

## 92d707b42fff321c — video/references/camera-lighting-vocabulary.md:62-62 (list_item)

- dive (camera plunges downward)

Extracted rules inside block: NONE

## ad1e1bbd408c807b — video/references/camera-lighting-vocabulary.md:63-63 (list_item)

- FPV (drone first-person flight)

Extracted rules inside block: NONE

## 78a2f64c6e5ce705 — video/references/camera-lighting-vocabulary.md:64-64 (list_item)

- one-take shot

Extracted rules inside block: NONE

## 001b516725b98b12 — video/references/camera-lighting-vocabulary.md:65-65 (list_item)

- bullet time

Extracted rules inside block: NONE

## 7043c3d78bf4fad9 — video/references/camera-lighting-vocabulary.md:66-66 (list_item)

- bounce speed ramp (speed up - slow down - speed up)

Extracted rules inside block: NONE

## f95afd71f2105ef8 — video/references/camera-lighting-vocabulary.md:68-68 (paragraph)

Universal rule. Pick one dominant move per 5-second shot. Layer one subtle secondary move at most. The popular techniques (one-take, dolly zoom, FPV, bullet time, bounce speed ramp) still need a subject, a start point and an end point — the name alone is not a direction.

Extracted rules inside block: NONE

## ee1234a06ce961a8 — video/references/camera-lighting-vocabulary.md:70-70 (heading)

## 3. Lens language

Extracted rules inside block: NONE

## af3845e95c1d0a75 — video/references/camera-lighting-vocabulary.md:72-72 (list_item)

- 24mm. Wide, immersive, exaggerated proximity.

Extracted rules inside block: NONE

## f38e9cb6a9f3ce7d — video/references/camera-lighting-vocabulary.md:73-73 (list_item)

- 35mm. Natural documentary.

Extracted rules inside block: NONE

## 94db0350d092be9c — video/references/camera-lighting-vocabulary.md:74-74 (list_item)

- 50mm. Intimate, human perspective.

Extracted rules inside block: NONE

## fd7549ac898aa4e1 — video/references/camera-lighting-vocabulary.md:75-75 (list_item)

- 85mm. Portrait, compressed background.

Extracted rules inside block: NONE

## 80bd6f416145098c — video/references/camera-lighting-vocabulary.md:76-76 (list_item)

- 100mm macro. Texture, detail.

Extracted rules inside block: NONE
