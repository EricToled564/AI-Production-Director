# Source coverage review 115/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 915c4cc4f353821f — storyboard-architect/references/shot-grammar.md:35-35 (table_row)

| `static` | No movement | Default. Static is not boring. |

Extracted rules inside block: NONE

## 6e0d532531c7060b — storyboard-architect/references/shot-grammar.md:36-36 (table_row)

| `push` | Camera moves toward subject | Building intensity, revealing |

Extracted rules inside block: NONE

## c5a7510ab10a6cf6 — storyboard-architect/references/shot-grammar.md:37-37 (table_row)

| `pull` | Camera moves away | Releasing, contextualizing |

Extracted rules inside block: NONE

## 2167d44afc607c9a — storyboard-architect/references/shot-grammar.md:38-38 (table_row)

| `pan-left` / `pan-right` | Camera rotates horizontally | Surveying environment |

Extracted rules inside block: NONE

## bd8db4e3f311d8d5 — storyboard-architect/references/shot-grammar.md:39-39 (table_row)

| `tilt-up` / `tilt-down` | Camera rotates vertically | Reveal scale or detail |

Extracted rules inside block: NONE

## 0769aea5d2ace4e6 — storyboard-architect/references/shot-grammar.md:40-40 (table_row)

| `handheld` | Subtle organic shake | Documentary feel, urgency |

Extracted rules inside block: NONE

## 58070a0acb33f361 — storyboard-architect/references/shot-grammar.md:41-41 (table_row)

| `orbit` | Camera circles subject | Hero shots, product reveal |

Extracted rules inside block: NONE

## cb886920bc6f9440 — storyboard-architect/references/shot-grammar.md:42-42 (table_row)

| `whip` | Fast pan as transition | Beat-cuts in fast-paced content |

Extracted rules inside block: NONE

## c6ca69fe14890e1f — storyboard-architect/references/shot-grammar.md:44-44 (paragraph)

For AI-generated still frames, motion is mostly intent for the editor. For motion-video prompts (Kling, Veo, Seedance, Hailuo), motion translates directly.

Extracted rules inside block: NONE

## 9b087f39d174ac49 — storyboard-architect/references/shot-grammar.md:46-46 (heading)

## Depth of field

Extracted rules inside block: NONE

## c04cccee75bf448d — storyboard-architect/references/shot-grammar.md:48-48 (table_row)

| Code | Effect |

Extracted rules inside block: NONE

## da0e83b648be7a11 — storyboard-architect/references/shot-grammar.md:50-50 (table_row)

| `shallow` | Subject sharp, background blurred |

Extracted rules inside block: 0c31c62df035

## d9597062d9615a02 — storyboard-architect/references/shot-grammar.md:51-51 (table_row)

| `deep` | Everything in focus |

Extracted rules inside block: NONE

## c74ea4891af8f87f — storyboard-architect/references/shot-grammar.md:52-52 (table_row)

| `rack` | Focus shifts mid-shot |

Extracted rules inside block: NONE

## a400df683526dcf6 — storyboard-architect/references/shot-grammar.md:54-54 (paragraph)

Default to shallow for talking-head, deep for environmental and schematic.

Extracted rules inside block: fcfb18290cdd

## e8d8ea4a372b25b1 — storyboard-architect/references/shot-grammar.md:56-56 (heading)

## Lighting style (referenced from series_lock)

Extracted rules inside block: NONE

## d9fe5ddabc4de196 — storyboard-architect/references/shot-grammar.md:58-58 (paragraph)

Don't redefine per shot. Define once in `series_lock.lighting`. Examples:

Extracted rules inside block: 981bd14b103d

## 48ff03de697cb54b — storyboard-architect/references/shot-grammar.md:60-60 (list_item)

- `soft natural side-light, large window left, warm afternoon`

Extracted rules inside block: NONE

## c2c79ba7d6795d0d — storyboard-architect/references/shot-grammar.md:61-61 (list_item)

- `hard top-light, single source, deep shadows, studio black`

Extracted rules inside block: NONE

## 85d75a79d6ee1f50 — storyboard-architect/references/shot-grammar.md:62-62 (list_item)

- `practical mixed sources, neon accents, urban night`

Extracted rules inside block: NONE

## 3da11d5ea0b44222 — storyboard-architect/references/shot-grammar.md:64-64 (paragraph)

The series_lock string flows into every prompt automatically.

Extracted rules inside block: NONE

## 814921b4defe3cf5 — storyboard-architect/references/shot-grammar.md:66-66 (heading)

## Subject description

Extracted rules inside block: NONE

## 7a59b4814b57a4fc — storyboard-architect/references/shot-grammar.md:68-68 (paragraph)

Structured, not poetic. Pattern:

Extracted rules inside block: NONE

## 4602c54554f8ce8b — storyboard-architect/references/shot-grammar.md:70-72 (code)

```
[who/what], [doing what], [emotional or compositional note]
```

Extracted rules inside block: NONE

## 55271f0c9f982f78 — storyboard-architect/references/shot-grammar.md:74-74 (paragraph)

Good:

Extracted rules inside block: NONE

## 3dddbb1849c166e9 — storyboard-architect/references/shot-grammar.md:75-77 (code)

```
"Founder, mid-thirties, leaning forward at laptop, face partially turned to window light"
```

Extracted rules inside block: NONE

## dc408336722810af — storyboard-architect/references/shot-grammar.md:79-79 (paragraph)

Bad:

Extracted rules inside block: NONE

## 275daeb1565d3e0e — storyboard-architect/references/shot-grammar.md:80-82 (code)

```
"A determined entrepreneur conquering the digital frontier with passion"
```

Extracted rules inside block: NONE

## 0859cf54b921788f — storyboard-architect/references/shot-grammar.md:84-84 (paragraph)

Generators reward precision. Adjectives describing emotion ("determined", "passionate") produce stock-photo aesthetics. Describe what the camera actually sees.

Extracted rules inside block: NONE

## d5f2ee5239ff53d5 — storyboard-architect/references/shot-grammar.md:86-86 (heading)

## What goes in `subject` vs `series_lock` vs `brand_lock`

Extracted rules inside block: NONE
