# Source coverage review 229/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4f13e1a9097afc9c — visual-prompt-forge/references/prompt-anatomy.md:100-100 (heading)

## Why this matters operationally

Extracted rules inside block: NONE

## a238a5758f2ebe52 — visual-prompt-forge/references/prompt-anatomy.md:102-102 (paragraph)

**Change the brand color** → edit brand-lock.md. Every prompt across every storyboard updates. No find-and-replace across files.

Extracted rules inside block: NONE

## 50c8347e8663b860 — visual-prompt-forge/references/prompt-anatomy.md:104-104 (paragraph)

**Change the character** → edit series_lock in shots.json. Every shot in this storyboard updates. Other storyboards untouched.

Extracted rules inside block: NONE

## e84e154fce2065f4 — visual-prompt-forge/references/prompt-anatomy.md:106-106 (paragraph)

**Change one shot** → edit just that shot's spec. Other shots unaffected.

Extracted rules inside block: NONE

## fd23afe318baffed — visual-prompt-forge/references/prompt-anatomy.md:108-108 (paragraph)

**Change the generator** → swap adapters. Same shot data, different output file. Zero edits to brand-lock or series_lock.

Extracted rules inside block: NONE

## 8ba621029eee93be — visual-prompt-forge/references/prompt-anatomy.md:110-110 (paragraph)

**Audit a render** → check brand-lock.snapshot.md to see what version the storyboard was built against.

Extracted rules inside block: NONE

## c1782c17a5731e0d — visual-prompt-forge/references/prompt-anatomy.md:112-112 (paragraph)

This is why guardrails-in-code beat guardrails-in-vibes. Each layer has one job. Changes are surgical. Outputs are reproducible.

Extracted rules inside block: NONE

## 0c927a9a0d5d24c8 — visual-prompt-forge/tools/README.md:1-1 (heading)

# Tools

Extracted rules inside block: NONE

## 06ea9b538ce53406 — visual-prompt-forge/tools/README.md:3-4 (paragraph)

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

Extracted rules inside block: NONE

## 897fe7ac85efd4d8 — visual-prompt-forge/tools/README.md:6-6 (heading)

## Requirements

Extracted rules inside block: NONE

## f8a8de3dd93c915b — visual-prompt-forge/tools/README.md:8-10 (code)

```bash
pip install pyyaml jsonschema
```

Extracted rules inside block: NONE

## db61f74775566e87 — visual-prompt-forge/tools/README.md:12-12 (paragraph)

Standard library otherwise. No pandas, no numpy.

Extracted rules inside block: NONE

## 0a49f39d2ab6ff45 — visual-prompt-forge/tools/README.md:14-14 (heading)

## Run everything

Extracted rules inside block: NONE

## 9e6e416855da668e — visual-prompt-forge/tools/README.md:16-20 (code)

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

Extracted rules inside block: NONE

## 09753617d21ed893 — visual-prompt-forge/tools/README.md:22-22 (paragraph)

This is exactly what CI runs, so a green local run means a green PR.

Extracted rules inside block: NONE

## e0843c3c2a465748 — visual-prompt-forge/tools/README.md:24-26 (paragraph)

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

Extracted rules inside block: NONE

## defff5e7aecfa859 — visual-prompt-forge/tools/README.md:28-28 (heading)

## Repo checks

Extracted rules inside block: NONE

## cb0b14942124d2d7 — visual-prompt-forge/tools/README.md:30-30 (heading)

### `validate_skills.py`

Extracted rules inside block: NONE

## 0e9b26f6aab97e7f — visual-prompt-forge/tools/README.md:32-33 (paragraph)

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

Extracted rules inside block: 5619289cd7dc

## b45c98dfa40e8b40 — visual-prompt-forge/tools/README.md:35-37 (code)

```bash
python tools/validate_skills.py
```

Extracted rules inside block: NONE

## 0e173b6f1bd6f756 — visual-prompt-forge/tools/README.md:39-39 (heading)

### `validate_schemas.py`

Extracted rules inside block: NONE

## fd458917c5e68d6d — visual-prompt-forge/tools/README.md:41-42 (paragraph)

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

Extracted rules inside block: NONE

## b22fb7ef70ba6c30 — visual-prompt-forge/tools/README.md:44-46 (code)

```bash
python tools/validate_schemas.py
```

Extracted rules inside block: NONE

## 4e9c0cd3dce26a02 — visual-prompt-forge/tools/README.md:48-48 (paragraph)

It validates schemas, not instances. For instances, see `validate_shots.py`.

Extracted rules inside block: NONE

## 80595bed62c68558 — visual-prompt-forge/tools/README.md:50-50 (heading)

### `validate_capabilities.py`

Extracted rules inside block: NONE

## 66d9903ccb14ebad — visual-prompt-forge/tools/README.md:52-54 (paragraph)

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

Extracted rules inside block: NONE

## c046fb4c8758e2d8 — visual-prompt-forge/tools/README.md:56-56 (list_item)

- every generator id has an adapter `.md` and every adapter `.md` has an entry

Extracted rules inside block: NONE

## 55f27119ec2ab13d — visual-prompt-forge/tools/README.md:57-57 (list_item)

- no adapter advertises more words than its own `max_prompt_words` ceiling

Extracted rules inside block: NONE

## e85ffb4e7b42eea9 — visual-prompt-forge/tools/README.md:58-58 (list_item)

- every adapter documents the `aspect_param` the matrix says to send

Extracted rules inside block: NONE

## 49ad9112fa52f3d5 — visual-prompt-forge/tools/README.md:59-59 (list_item)

- no `notes` field cites a word count above its own ceiling

Extracted rules inside block: NONE
