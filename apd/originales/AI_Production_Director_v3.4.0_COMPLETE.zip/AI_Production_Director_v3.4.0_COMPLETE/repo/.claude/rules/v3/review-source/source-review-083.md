# Source coverage review 83/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2d8465c6715d5421 — screenwriter/SKILL.md:106-106 (list_item)

- [ ] Atmosphere/mood established (fog, rain, dust, clarity)

Extracted rules inside block: NONE

## f6d50738ddcc5798 — screenwriter/SKILL.md:107-107 (list_item)

- [ ] Character appearance detailed (first appearance only)

Extracted rules inside block: NONE

## f0ac6e9cfc0fc039 — screenwriter/SKILL.md:108-108 (list_item)

- [ ] Props/objects specified (important visual elements)

Extracted rules inside block: NONE

## b8e1ae358c787e1f — screenwriter/SKILL.md:109-109 (list_item)

- [ ] Composition suggested (without technical camera direction)

Extracted rules inside block: NONE

## 8504520347e0f6cb — screenwriter/SKILL.md:110-110 (list_item)

- [ ] Colors/textures mentioned when relevant

Extracted rules inside block: NONE

## 7cc293af33855a1e — screenwriter/SKILL.md:112-112 (heading)

### Character Introduction

Extracted rules inside block: NONE

## ec85e1d5f02111e0 — screenwriter/SKILL.md:114-114 (paragraph)

**First Appearance - Detailed:**

Extracted rules inside block: NONE

## 0d3280c38bce51ef — screenwriter/SKILL.md:115-117 (code)

```
SARAH (28, sharp eyes, wearing a weathered leather jacket over faded jeans) enters the frame. Her dark hair is pulled back, revealing a small scar above her left eyebrow.
```

Extracted rules inside block: NONE

## f527a4c3d6c1f07f — screenwriter/SKILL.md:119-119 (paragraph)

**Subsequent Appearances - Brief:**

Extracted rules inside block: NONE

## efbcc2151b88196d — screenwriter/SKILL.md:120-122 (code)

```
Sarah checks her watch.
```

Extracted rules inside block: NONE

## 8886c2be923b395e — screenwriter/SKILL.md:124-124 (paragraph)

**Guidelines:**

Extracted rules inside block: NONE

## bd27a02623a798e1 — screenwriter/SKILL.md:125-125 (list_item)

- Character names in ALL CAPS on first appearance only

Extracted rules inside block: NONE

## d5803397cd5507d9 — screenwriter/SKILL.md:126-126 (list_item)

- Include: age (if relevant), key physical traits, wardrobe

Extracted rules inside block: NONE

## 13aea18c4e25a1b0 — screenwriter/SKILL.md:127-127 (list_item)

- Focus on visual identifiers for consistent image generation

Extracted rules inside block: NONE

## 12adcd488d9a8c50 — screenwriter/SKILL.md:128-128 (list_item)

- Avoid excessive detail—just enough for visual consistency

Extracted rules inside block: 586416c651f7

## 9103a1c7be378b05 — screenwriter/SKILL.md:130-130 (heading)

### Dialogue (Use Sparingly)

Extracted rules inside block: NONE

## 0c77cf72084a9df4 — screenwriter/SKILL.md:132-132 (paragraph)

**Format:**

Extracted rules inside block: NONE

## 69b945b126480e20 — screenwriter/SKILL.md:133-137 (code)

```
CHARACTER NAME
(parenthetical - optional)
Dialogue goes here.
```

Extracted rules inside block: NONE

## 2f38d37d35fb0838 — screenwriter/SKILL.md:139-139 (paragraph)

**Guidelines for Short Films:**

Extracted rules inside block: NONE

## cacd8d44522a7167 — screenwriter/SKILL.md:140-140 (list_item)

- Use dialogue ONLY when essential to story

Extracted rules inside block: c543a651cf13

## 42ef38476c1a0da5 — screenwriter/SKILL.md:141-141 (list_item)

- Favor visual storytelling over talking

Extracted rules inside block: NONE

## 66b8ca12e85e4b7a — screenwriter/SKILL.md:142-142 (list_item)

- Keep lines concise (max 3-4 lines per block)

Extracted rules inside block: NONE

## 28f1920f8c17ca11 — screenwriter/SKILL.md:143-143 (list_item)

- Parentheticals only for critical tone/action

Extracted rules inside block: NONE

## 0b15e2e994301a5f — screenwriter/SKILL.md:144-144 (list_item)

- Character names centered, ALL CAPS

Extracted rules inside block: NONE

## 5d7fe704c1000d2a — screenwriter/SKILL.md:146-146 (paragraph)

**Example:**

Extracted rules inside block: NONE

## 182cb376ae199516 — screenwriter/SKILL.md:147-151 (code)

```
UNIT-7 (robotic voice, soft)
Organic life form detected.
Probability of survival: low.
```

Extracted rules inside block: NONE

## 956b082389b8adb4 — screenwriter/SKILL.md:153-153 (heading)

### Transitions (Minimal Use)

Extracted rules inside block: NONE

## 9832e1c99e7a8734 — screenwriter/SKILL.md:155-155 (paragraph)

**Common Transitions:**

Extracted rules inside block: NONE

## b342a5afd48a2d73 — screenwriter/SKILL.md:156-156 (list_item)

- `FADE IN:` - Opening of screenplay only

Extracted rules inside block: NONE

## e8ba67fea55f9863 — screenwriter/SKILL.md:157-157 (list_item)

- `CUT TO:` - Scene change (usually implied, use for emphasis)

Extracted rules inside block: e8ccbb618ba3
