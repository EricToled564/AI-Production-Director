# Source coverage review 74/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c9933a46ed5a73af — image/references/text-rendering.md:45-45 (list_item)

- Subway/Transit Map: journey, connections

Extracted rules inside block: NONE

## 360a467b9044178d — image/references/text-rendering.md:46-46 (list_item)

- IKEA Manual: wordless step-by-step

Extracted rules inside block: NONE

## 4d47f1e18fa28d53 — image/references/text-rendering.md:47-47 (list_item)

- Knolling (Flat Lay): objects at 90° angles, overhead

Extracted rules inside block: NONE

## 9168c5a886786d4d — image/references/text-rendering.md:48-48 (list_item)

- Origami/Paper Folding: geometric, clean

Extracted rules inside block: NONE

## d4615859fdb3581a — image/references/text-rendering.md:50-50 (heading)

## Layout Types

Extracted rules inside block: NONE

## 992fe0fde7563baa — image/references/text-rendering.md:52-52 (paragraph)

**Linear:**

Extracted rules inside block: NONE

## 0fdebd9ca776b73e — image/references/text-rendering.md:53-53 (list_item)

- Horizontal Timeline: history, biography

Extracted rules inside block: NONE

## cb359bf0f14ef531 — image/references/text-rendering.md:54-54 (list_item)

- Step-by-Step Flow: recipes, experiments, processes

Extracted rules inside block: NONE

## e5bfedab588bb96e — image/references/text-rendering.md:55-55 (list_item)

- Winding Roadmap: journey through topic

Extracted rules inside block: NONE

## 07922700db05fe2d — image/references/text-rendering.md:57-57 (paragraph)

**Comparison:**

Extracted rules inside block: NONE

## 62b7f0d3af07dda7 — image/references/text-rendering.md:58-58 (list_item)

- Split Screen (Versus): instant contrast

Extracted rules inside block: NONE

## f5462feac3b62fb1 — image/references/text-rendering.md:59-59 (list_item)

- Comparison Matrix: multiple items, same criteria

Extracted rules inside block: NONE

## bc8f08bdb34f805a — image/references/text-rendering.md:60-60 (list_item)

- Before and After: cause and effect

Extracted rules inside block: NONE

## b0d371357c1fa736 — image/references/text-rendering.md:61-61 (list_item)

- Venn Diagram: compare and contrast

Extracted rules inside block: NONE

## 964973d13a12b7f5 — image/references/text-rendering.md:63-63 (paragraph)

**Hierarchical:**

Extracted rules inside block: NONE

## 8ee31cfd394b78d7 — image/references/text-rendering.md:64-64 (list_item)

- Pyramid: foundation to peak (Maslow, food pyramid)

Extracted rules inside block: NONE

## 3a7e2bb39d68a353 — image/references/text-rendering.md:65-65 (list_item)

- Funnel: filtering process (bill→law, sales)

Extracted rules inside block: NONE

## 647fd0a0758cbc6d — image/references/text-rendering.md:66-66 (list_item)

- Iceberg: visible vs invisible (10% above, 90% below)

Extracted rules inside block: NONE

## 83c00e282a21281a — image/references/text-rendering.md:68-68 (paragraph)

**Radial/Connected:**

Extracted rules inside block: NONE

## 06efcae69b27d176 — image/references/text-rendering.md:69-69 (list_item)

- Hub and Spoke: core topic + attributes

Extracted rules inside block: NONE

## 266b94841a8d426a — image/references/text-rendering.md:70-70 (list_item)

- Tree/Branching Map: genealogy, taxonomy

Extracted rules inside block: NONE

## 5de2cab750bc070f — image/references/text-rendering.md:71-71 (list_item)

- Concentric Circles: layers (Earth, proximity)

Extracted rules inside block: NONE

## dda1a5ca1f62b347 — image/references/text-rendering.md:73-73 (paragraph)

**Grid-Based:**

Extracted rules inside block: NONE

## 5d2dcf12248ba6f3 — image/references/text-rendering.md:74-74 (list_item)

- Bento Grid: tidy boxes, modular

Extracted rules inside block: NONE

## 0b887651d7ec6259 — image/references/text-rendering.md:75-75 (list_item)

- Periodic Table Grid: items by type/family

Extracted rules inside block: NONE

## 40bb23dc802094c6 — image/references/text-rendering.md:76-76 (list_item)

- Comic Strip: narrative in scenes

Extracted rules inside block: NONE

## fbca14bc179e93f4 — image/references/text-rendering.md:77-77 (list_item)

- Jigsaw: pieces forming whole

Extracted rules inside block: NONE

## eb7badbaca1d92c7 — image/references/text-rendering.md:79-79 (paragraph)

**Spatial:**

Extracted rules inside block: NONE

## cfc9a43288e91f1f — image/references/text-rendering.md:80-80 (list_item)

- Isometric Map: 3D game world style

Extracted rules inside block: NONE

## 0e0161bf625cbbd1 — image/references/text-rendering.md:81-81 (list_item)

- Cross-Section (Cutaway): inside something solid

Extracted rules inside block: NONE
