# Source coverage review 25/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 95a37965082fd8c4 — brand-lock-extractor/brand-packs/examples/saas-clean.md:21-21 (table_row)

| Success | `#10B981` | Emerald, positive metrics, gains |

Extracted rules inside block: NONE

## 1f20aed2f5915ce2 — brand-lock-extractor/brand-packs/examples/saas-clean.md:22-22 (table_row)

| Warning | `#F59E0B` | Amber, alerts, attention items |

Extracted rules inside block: NONE

## 9bed87a5acef19f8 — brand-lock-extractor/brand-packs/examples/saas-clean.md:24-24 (heading)

## Typography

Extracted rules inside block: NONE

## 1406dc8b20c25f88 — brand-lock-extractor/brand-packs/examples/saas-clean.md:26-28 (paragraph)

**Display font:** `Inter Bold 700`
**Body font:** `Inter Regular 400`
**Mono font:** `JetBrains Mono Regular`, for data, code, dashboards

Extracted rules inside block: NONE

## 08eaf3fde60b9a22 — brand-lock-extractor/brand-packs/examples/saas-clean.md:30-30 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## b8b238c23c3bd973 — brand-lock-extractor/brand-packs/examples/saas-clean.md:32-32 (list_item)

- credible

Extracted rules inside block: NONE

## 397450a3daf6c20e — brand-lock-extractor/brand-packs/examples/saas-clean.md:33-33 (list_item)

- precise

Extracted rules inside block: NONE

## 1676574c24fdfac7 — brand-lock-extractor/brand-packs/examples/saas-clean.md:34-34 (list_item)

- helpful

Extracted rules inside block: NONE

## de4fd9521ce8a009 — brand-lock-extractor/brand-packs/examples/saas-clean.md:35-35 (list_item)

- restrained

Extracted rules inside block: NONE

## 97ac7e12fbe25c61 — brand-lock-extractor/brand-packs/examples/saas-clean.md:36-36 (list_item)

- expert

Extracted rules inside block: NONE

## 3fabe718f29e4bd5 — brand-lock-extractor/brand-packs/examples/saas-clean.md:38-38 (heading)

## Never list

Extracted rules inside block: NONE

## c57ef113629dea42 — brand-lock-extractor/brand-packs/examples/saas-clean.md:40-40 (list_item)

- never use stock photo aesthetic

Extracted rules inside block: c8d50a9effa6

## f84831f100954993 — brand-lock-extractor/brand-packs/examples/saas-clean.md:41-41 (list_item)

- never use AI uncanny faces

Extracted rules inside block: 1299d1bab833

## 6eaf4ff0f56695f2 — brand-lock-extractor/brand-packs/examples/saas-clean.md:42-42 (list_item)

- never use illustrations of people (real photography or abstract data viz only)

Extracted rules inside block: b8cbe1a1fdf6

## 417f224c01f184f4 — brand-lock-extractor/brand-packs/examples/saas-clean.md:43-43 (list_item)

- never use gradients (flat color only)

Extracted rules inside block: 5c7051389a09

## 8df1fcb4141383c1 — brand-lock-extractor/brand-packs/examples/saas-clean.md:44-44 (list_item)

- never use rounded corners larger than 8px

Extracted rules inside block: 8c2ead69c2df

## 353ecdf89a6e0ed7 — brand-lock-extractor/brand-packs/examples/saas-clean.md:45-45 (list_item)

- never use exclamation points

Extracted rules inside block: f1fb6a703226

## 455c972cfea09d26 — brand-lock-extractor/brand-packs/examples/saas-clean.md:46-46 (list_item)

- never use vague claims ("the best", "industry-leading", "cutting-edge")

Extracted rules inside block: cdfbbae8aef0

## 42d75de190b86da1 — brand-lock-extractor/brand-packs/examples/saas-clean.md:47-47 (list_item)

- never use AI/ML buzzwords without specifics

Extracted rules inside block: 8fa3aca3d811

## 76f84ad5c2eca1c9 — brand-lock-extractor/brand-packs/examples/saas-clean.md:48-48 (list_item)

- never default to dark mode in primary marketing

Extracted rules inside block: bcca72586f78

## ab1bc73000a7369d — brand-lock-extractor/brand-packs/examples/saas-clean.md:49-49 (list_item)

- never use animated icons or lottie illustrations

Extracted rules inside block: d1200822cff3

## 140df81905215771 — brand-lock-extractor/brand-packs/examples/saas-clean.md:51-51 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## 0709d8ddc93ca036 — brand-lock-extractor/brand-packs/examples/saas-clean.md:53-53 (list_item)

- 16:9, primary for product demos and hero films

Extracted rules inside block: NONE

## cc192527ff4f40cb — brand-lock-extractor/brand-packs/examples/saas-clean.md:54-54 (list_item)

- 9:16, short-form social

Extracted rules inside block: NONE

## 1ce6e7ae023ea5c0 — brand-lock-extractor/brand-packs/examples/saas-clean.md:55-55 (list_item)

- 1:1. LinkedIn carousels

Extracted rules inside block: NONE

## b24f8e3de4eb346d — brand-lock-extractor/brand-packs/examples/saas-clean.md:57-57 (heading)

## Color grade direction

Extracted rules inside block: NONE

## 5ebdf9e3060979aa — brand-lock-extractor/brand-packs/examples/saas-clean.md:59-59 (paragraph)

Clean, neutral, slight cool bias. White points pure white, blacks deep but not crushed. Skin tones natural. No filmic grain. Reminiscent of Apple keynote photography, clean, evenly lit, technically perfect.

Extracted rules inside block: NONE

## 61cfa20e41b0d25e — brand-lock-extractor/brand-packs/examples/saas-clean.md:61-61 (heading)

## Motion language

Extracted rules inside block: NONE

## 93f56f426a27e340 — brand-lock-extractor/brand-packs/examples/saas-clean.md:63-63 (paragraph)

Minimal motion. UI elements appear with subtle 200ms fade. Cuts on logic beats, not on time. Data visualizations animate with linear easing, no bounce, no overshoot. Camera moves limited to slow push on hero shots. No handheld, no whip pans, no transitions beyond hard cuts.

Extracted rules inside block: NONE

## 010f524cee0a9490 — brand-lock-extractor/brand-packs/examples/saas-clean.md:65-65 (heading)

## Voice rules

Extracted rules inside block: NONE
