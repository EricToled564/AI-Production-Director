# Source coverage review 170/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 1bb5f337a4097182 — video/references/seedance-25.md:88-88 (table_row)

| Dialogue | `{ }` | `{Hello, welcome back.}` |

Extracted rules inside block: NONE

## a01015248cc5126e — video/references/seedance-25.md:89-89 (table_row)

| Subtitles / titles | `【 】` | `【Chapter One: Departure】` |

Extracted rules inside block: NONE

## 9babcd8d009b867e — video/references/seedance-25.md:91-91 (paragraph)

Dialogue language reinforcement — the formula is `Dialogue language + regional variety or accent + delivery style + speaker + {line}`:

Extracted rules inside block: NONE

## b71431f9c085d597 — video/references/seedance-25.md:93-97 (code)

```text
Dialogue language: authentic Los Angeles English. The young man says in natural
Los Angeles vernacular: {No way, you actually made it.}
The girl says softly in Japanese: {もう大丈夫です}
```

Extracted rules inside block: NONE

## 31fafb5bf96d7723 — video/references/seedance-25.md:99-99 (paragraph)

Lip shape, speech rhythm and face match the assigned language in one pass — this holds across all 11 supported languages, including mixed-language scenes.

Extracted rules inside block: NONE

## e6330d7ab33867ab — video/references/seedance-25.md:101-101 (heading)

## 5. Reference discipline (the 50-slot system)

Extracted rules inside block: NONE

## 73930faacbdc164f — video/references/seedance-25.md:103-103 (paragraph)

The point of 50 slots is not dumping assets in. **Every material's role must be written in the prompt.** Do not rely on text labels inside images; do not make the model infer mappings.

Extracted rules inside block: 80b31e0a88b0

## 8715bc5c9e8095b4 — video/references/seedance-25.md:105-105 (paragraph)

Role template:

Extracted rules inside block: NONE

## e1922a31906fc459 — video/references/seedance-25.md:107-111 (code)

```text
@Image 1 defines <subject>'s <appearance, clothing, structure, or material>.
@Video 1 defines <motion, camera movement, or pacing>.
@Audio 1 defines <character or sound type>'s <voice, dialogue, ambience, or music>.
```

Extracted rules inside block: NONE

## 1d9a6fc9309c884e — video/references/seedance-25.md:113-113 (paragraph)

Rules:

Extracted rules inside block: NONE

## 7ddbb2ffacb9a97b — video/references/seedance-25.md:115-115 (list_item)

- **Bind each subject individually.** `<Character A> corresponds to @Image 1. Use only the appearance, hairstyle, and clothing.` The officially forbidden pattern: "@Images 1 through 4 define four characters respectively" — it never states which is which.

Extracted rules inside block: ae7b6e0fbccb

## 4d377031e545bdff — video/references/seedance-25.md:116-116 (list_item)

- **Add exclusions** for anything that could bleed in: "Do not use the image background." / "Do not use the people in the image." / "Do not use the person's identity, clothing, or scene from the video."

Extracted rules inside block: a04f5200004c

## b911f6ccf489f45f — video/references/seedance-25.md:117-117 (list_item)

- **Do not restate what a reference already defines.** If a reference video defines the motion, state only which attributes to inherit — re-describing every action conflicts with the reference.

Extracted rules inside block: 7df596a951c6

## 3167546c119fe63b — video/references/seedance-25.md:118-118 (list_item)

- **Subject Profile** for a recurring character:

Extracted rules inside block: NONE

## 0e04a803aabfc221 — video/references/seedance-25.md:120-127 (code)

```text
[Subject Profile: Conservator]
Appearance and clothing: @Image 1.
Fixed prop: <Sample Case> from @Image 5.
Locations: <Conservation Lab> and <Gallery>.
Motion references: the case-opening motion from @Video 1.
Do not use: other characters' clothing. Do not give this character <Record Board>.
```

Extracted rules inside block: NONE

## 869b878821f5adb1 — video/references/seedance-25.md:129-129 (list_item)

- **Select references per scene**, not all at once: `Scene 1 | Use: <list>. Event: ... End state: ...`

Extracted rules inside block: 3bb1e989a2bb

## ddb16b50bb37c809 — video/references/seedance-25.md:130-130 (list_item)

- The same character in two states (before / after a transformation) = **two separate image slots**, each bound to its time range. Expect this to be the flakiest binding — budget re-rolls.

Extracted rules inside block: NONE

## 11a0e351e10e79a6 — video/references/seedance-25.md:132-132 (paragraph)

Official stability sweet spots:

Extracted rules inside block: NONE

## 89fbe0de97bf6d18 — video/references/seedance-25.md:134-134 (table_row)

| Input | Best | Possible but unstable |

Extracted rules inside block: NONE

## a7305caef347a736 — video/references/seedance-25.md:136-136 (table_row)

| Subjects in a reference video/audio | 1-5 | 6-10 |

Extracted rules inside block: NONE

## 9158e506b5b12fd0 — video/references/seedance-25.md:137-137 (table_row)

| Reference clip length | 5-10s per subject | longer |

Extracted rules inside block: NONE

## 0d1e03e1f18df6d0 — video/references/seedance-25.md:138-138 (table_row)

| Subjects across reference images | 1-8 | 9-12 |

Extracted rules inside block: NONE

## e19dda4cdf839648 — video/references/seedance-25.md:139-139 (table_row)

| Multi-view sheets | ≤5 subjects: any | >5 subjects: single view only; separate images per view beat a collage |

Extracted rules inside block: NONE

## ec44415dad2882ad — video/references/seedance-25.md:140-140 (table_row)

| Video-edit source length | ≤20s | longer stalls |

Extracted rules inside block: NONE

## f45ebe75b0ca1cac — video/references/seedance-25.md:142-142 (heading)

## 6. The 30-second structure: stages and end states

Extracted rules inside block: NONE

## 0882ed812462e9b4 — video/references/seedance-25.md:144-144 (paragraph)

Divide the clip into consecutive stages. **One primary state change per stage, and always state the visible end state** — the end state is what the model steers toward (this is the U11 final-image rule, per stage).

Extracted rules inside block: 1e87d8cb0649

## f52fcf2cf90fbc63 — video/references/seedance-25.md:146-155 (code)

```text
[Generation Goal] Generate a <video type>. The central subject is <subject>,
and the primary event is <story summary>.
[Stage 1] Initial state: ... Primary event: <one primary action>. End state: <visible state>.
[Stage 2] Continue from the previous stage: <what must remain unchanged>.
          Primary event: ... End state: ...
[Stage 3] Primary event: <closing event>. End state: <final visible state>.
[Maintain Consistency] Keep <identity, count, clothing, prop ownership,
spatial direction, audio relationships> consistent.
```

Extracted rules inside block: NONE

## b78cd21e66eed391 — video/references/seedance-25.md:157-157 (paragraph)

Timestamp rules:

Extracted rules inside block: NONE

## 7fd049999fe60fad — video/references/seedance-25.md:159-159 (list_item)

- A time range is an event's **time budget, not an edit point**. Ranges must be consecutive and non-overlapping.

Extracted rules inside block: 4899a6863473

## 0f5337df0ff01c65 — video/references/seedance-25.md:160-160 (list_item)

- **Windows of 3 seconds or more.** Shorter windows execute unreliably.

Extracted rules inside block: NONE
