# Source coverage review 92/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4d308562e45fa496 — screenwriter/references/pipeline-integration.md:177-177 (paragraph)

For pipeline simplicity, prefer Option A (complete renumbering).

Extracted rules inside block: 1c1db6f7160a

## 8823518eae17f0e8 — screenwriter/references/pipeline-integration.md:181-181 (heading)

## Duration Estimation Guidelines

Extracted rules inside block: NONE

## c2bdecf27a570363 — screenwriter/references/pipeline-integration.md:183-183 (heading)

### Per-Scene Duration

Extracted rules inside block: NONE

## 9862dee55bbacd45 — screenwriter/references/pipeline-integration.md:185-185 (paragraph)

Estimate based on scene complexity:

Extracted rules inside block: NONE

## 00d21efac0b261ee — screenwriter/references/pipeline-integration.md:187-187 (paragraph)

**30-45 seconds:** Simple scenes

Extracted rules inside block: NONE

## ea12a84585283d9f — screenwriter/references/pipeline-integration.md:188-188 (list_item)

- Single action

Extracted rules inside block: NONE

## 6f292730be87b30c — screenwriter/references/pipeline-integration.md:189-189 (list_item)

- Minimal dialogue

Extracted rules inside block: NONE

## a52c28fdc58e89d6 — screenwriter/references/pipeline-integration.md:190-190 (list_item)

- One primary visual

Extracted rules inside block: NONE

## 918674a744f360e8 — screenwriter/references/pipeline-integration.md:192-192 (paragraph)

**45-60 seconds:** Standard scenes

Extracted rules inside block: NONE

## 267f8423af893684 — screenwriter/references/pipeline-integration.md:193-193 (list_item)

- Multiple actions or dialogue exchanges

Extracted rules inside block: NONE

## 7411f93a0cd54f20 — screenwriter/references/pipeline-integration.md:194-194 (list_item)

- 2-3 visual beats

Extracted rules inside block: NONE

## 1722e2e23eeae186 — screenwriter/references/pipeline-integration.md:195-195 (list_item)

- Character interaction

Extracted rules inside block: NONE

## ff7f09a08bf6680a — screenwriter/references/pipeline-integration.md:197-197 (paragraph)

**60-90 seconds:** Complex scenes

Extracted rules inside block: NONE

## 342ca5df14404c99 — screenwriter/references/pipeline-integration.md:198-198 (list_item)

- Extended dialogue

Extracted rules inside block: NONE

## 6413e40624d9b9b8 — screenwriter/references/pipeline-integration.md:199-199 (list_item)

- Multiple visual beats

Extracted rules inside block: NONE

## d3dd0cbde2d3a380 — screenwriter/references/pipeline-integration.md:200-200 (list_item)

- Scene climax or key moment

Extracted rules inside block: NONE

## c8204729128a720e — screenwriter/references/pipeline-integration.md:202-202 (heading)

### Total Film Duration

Extracted rules inside block: NONE

## ee56934aa4e69240 — screenwriter/references/pipeline-integration.md:204-204 (paragraph)

Track cumulative duration across all scenes:

Extracted rules inside block: NONE

## 99b446e0d8ca19ba — screenwriter/references/pipeline-integration.md:206-212 (code)

```
Scene 1: 30s
Scene 2: 45s
Scene 3: 40s
...
Total: 8 minutes 20 seconds
```

Extracted rules inside block: NONE

## 3e96ee672854790e — screenwriter/references/pipeline-integration.md:214-214 (paragraph)

Adjust scene count or duration to hit target length (5-10 min).

Extracted rules inside block: NONE

## 9fecf60a3cd363fd — screenwriter/references/pipeline-integration.md:218-218 (heading)

## Output Format Validation

Extracted rules inside block: NONE

## efa1daa9a8266a1d — screenwriter/references/pipeline-integration.md:220-220 (heading)

### XML Well-Formedness

Extracted rules inside block: NONE

## 6e9fd5f3794cef07 — screenwriter/references/pipeline-integration.md:222-222 (paragraph)

Ensure valid XML structure:

Extracted rules inside block: a536af1b94d3

## 73103564ae851e78 — screenwriter/references/pipeline-integration.md:223-223 (list_item)

- All opening tags have closing tags

Extracted rules inside block: NONE

## a9264fa5d588eb37 — screenwriter/references/pipeline-integration.md:224-224 (list_item)

- Proper nesting (no overlapping tags)

Extracted rules inside block: NONE

## 1d64e18eaf564564 — screenwriter/references/pipeline-integration.md:225-225 (list_item)

- Special characters escaped (&lt; &gt; &amp;)

Extracted rules inside block: NONE

## 605eb312fa9db245 — screenwriter/references/pipeline-integration.md:227-227 (heading)

### Common XML Errors

Extracted rules inside block: NONE

## 9accb1dadeb29fc5 — screenwriter/references/pipeline-integration.md:229-229 (paragraph)

**❌ Missing closing tag:**

Extracted rules inside block: bd4c514dc791

## d0aba6529a5586eb — screenwriter/references/pipeline-integration.md:230-234 (code)

```xml
<scene number="1">
  <action>Text here
</scene>
```

Extracted rules inside block: NONE

## ff852ab7d04cd47e — screenwriter/references/pipeline-integration.md:236-236 (paragraph)

**✅ Properly closed:**

Extracted rules inside block: a03789dab187
