# Rule classification review 3/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## 79b295934461 — aurora-prompt-linter/SKILL.md:160

**Vocabulary base**: las listas en `scripts/vocabularies.yaml` están calibradas para casos típicos de Aurora (cycling, soccer, fitness). Si el proyecto usa otros dominios (cocina, automotriz, etc.) hay que expandir las listas.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "79b295934461",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 0571c5dbdc31 — aurora-prompt-linter/references/README.md:3

Linter determinista que bloquea entrega de prompts AI con redundancia respecto a refs, violaciones de estructura, vocabulario baneado o falta de keywords obligatorios. Integra con el skill `prompt-production-protocol` como gate obligatorio en Step 5.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "0571c5dbdc31",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 1e0ccc4385c5 — aurora-prompt-linter/references/README.md:92

**Redundancia por categoría**: si ref carga categoría X, no describir X en MAIN.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "1e0ccc4385c5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 65774d17b5ad — aurora-prompt-linter/references/README.md:93

**Vocabulario baneado cross-platform**: `slow motion`, `cartoon`, `anime`, `3D render`, etc. solo en NEGATIVE block.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "65774d17b5ad",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 530dfe9aa47b — aurora-prompt-linter/references/README.md:94

**Word count**: cap MAX duro = 90 (I2V) o 130 (T2I); MIN soft = 50/75.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "530dfe9aa47b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## c737439439ae — aurora-prompt-linter/references/README.md:95

**Negative prompt**: bloque obligatorio.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "c737439439ae",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 3de3d8001972 — aurora-prompt-linter/references/README.md:96

**Sports broadcast**: si flag activo, requiere `60fps` y `broadcast realism` en MAIN (Regla 26 v6.0).

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "3de3d8001972",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## a7cb646e6f7f — aurora-prompt-linter/references/README.md:97

**Exenciones**: términos en contexto de motion/cámara o como anchor direccional (`away from her face`, `across the climbing wall`) NO se flaggean.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "a7cb646e6f7f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## a5ae02a3009f — aurora-prompt-linter/references/skill_update_step5.md:31

> **Step 5b — Linter determinista (NUEVO, obligatorio para casos 3a/3b/3c — recomendado para 1/2/4):**

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "a5ae02a3009f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 81e601ada119 — aurora-prompt-linter/references/skill_update_step5.md:35

> - Si STATUS=FAIL sin override válido → NO entregar. Iterar el draft. NO se permite entregar al usuario con FAIL del linter.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "81e601ada119",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 119333aa9698 — brand-lock-extractor/SKILL.md:12

This skill extracts. It does not invent. Every value is sampled from a real asset or flagged as an estimate the user must confirm. A confident-sounding wrong hex is worse than a flagged guess.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "119333aa9698",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## f64a1b15787a — brand-lock-extractor/SKILL.md:34

Written description | Use directly | Identity, archetype, voice posture

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "f64a1b15787a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "any": [
          {
            "op": "eq",
            "path": "stage",
            "value": "brief"
          },
          {
            "op": "eq",
            "path": "operation",
            "value": "brand_extract"
          },
          {
            "op": "not_in",
            "path": "brand.mode",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 345e51cdd0e8 — brand-lock-extractor/SKILL.md:46

Tell the user what you are pulling. Do not ask follow-ups yet, extract first, confirm gaps at the end.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "345e51cdd0e8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 86eaea2929ff — brand-lock-extractor/SKILL.md:52

**Identity** (brand, one-line description, archetype, voice posture)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "86eaea2929ff",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "any": [
          {
            "op": "eq",
            "path": "stage",
            "value": "brief"
          },
          {
            "op": "eq",
            "path": "operation",
            "value": "brand_extract"
          },
          {
            "op": "not_in",
            "path": "brand.mode",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## d55e33adff98 — brand-lock-extractor/SKILL.md:53

**Palette** (sampled hex, by role)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "d55e33adff98",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 087a02f85a83 — brand-lock-extractor/SKILL.md:54

**Typography** (display, body, optional mono, with weights)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "087a02f85a83",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## cc8d067c481f — brand-lock-extractor/SKILL.md:55

**Mood adjectives** (3-5, specific, contrast clauses preferred)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "cc8d067c481f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 16bdbf3c53a1 — brand-lock-extractor/SKILL.md:56

**Never list** (what the brand avoids, inferred from consistency)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "16bdbf3c53a1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## b0db566195c3 — brand-lock-extractor/SKILL.md:57

**Aspect ratios**

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "b0db566195c3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## a3a57fcfe2f3 — brand-lock-extractor/SKILL.md:58

**Color grade direction** (one sentence)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "a3a57fcfe2f3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## a514b90f152f — brand-lock-extractor/SKILL.md:59

**Motion language** (one paragraph)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "a514b90f152f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## a655e17cddb6 — brand-lock-extractor/SKILL.md:60

**Voice rules** (copy-level constraints)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "a655e17cddb6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## f4e3551ca54e — brand-lock-extractor/SKILL.md:69

**inferred**, reasoned from evidence but not stated (archetype from positioning, never-list from consistency). Reasonable to ship, worth noting.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "f4e3551ca54e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## e22ec7c92139 — brand-lock-extractor/SKILL.md:74

Use `templates/brand-lock.md.tpl`. Fill **every** required section, no placeholders left behind. Then append an `## Extraction notes` section that lists every `inferred` and `needs confirmation` value with its source and your reasoning. This section is the audit trail; it does not break validation (the validator checks the nine required sections are present, extra sections are fine).

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "e22ec7c92139",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 0e8edd11509b — brand-lock-extractor/SKILL.md:82

All nine required sections present: Identity, Palette, Typography, Mood adjectives, Never list, Aspect ratios, Color grade direction, Motion language, Voice rules.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "0e8edd11509b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "any": [
          {
            "op": "eq",
            "path": "stage",
            "value": "brief"
          },
          {
            "op": "eq",
            "path": "operation",
            "value": "brand_extract"
          },
          {
            "op": "not_in",
            "path": "brand.mode",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 5fd02bdf692d — brand-lock-extractor/SKILL.md:88

> "Here is your brand-lock. I sampled the palette and type from your assets and flagged N values that need your eyes (see Extraction notes). Drop it in `brand-packs/`, confirm the flagged values, and run `python tools/validate_brand_lock.py path/to/file.md` to verify. Then: `'30-second explainer. Use brand-packs/your-brand.md as the brand lock.'`"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "5fd02bdf692d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 8d59454c87ee — brand-lock-extractor/SKILL.md:94

Colors are sampled, never guessed. Read them from a brand book, from CSS, or by sampling pixels in a screenshot. If you genuinely cannot determine a color, fill your closest estimate and mark it `needs confirmation` in Extraction notes. "Navy" is not a palette entry. `#0F1F3A` is. A wrong hex stated confidently corrupts every downstream prompt.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "8d59454c87ee",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## d6d1b7da8559 — brand-lock-extractor/SKILL.md:98

Identify fonts from the brand book, the site's CSS/font files, or clear visual match. If you cannot identify one, say so and flag it, do not name a plausible-sounding font you did not verify.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d6d1b7da8559",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 1cd7266731ef — brand-lock-extractor/SKILL.md:106

It is also the hardest to extract, because brands document what they do, not what they avoid. Infer it from consistency: if every image avoids stock-photo gloss, that is a never. If copy never uses exclamation points, that is a never. Read `references/extraction-rubric.md` for the method. Do not ship an empty never-list.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "1cd7266731ef",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## ff7824966969 — brand-lock-extractor/SKILL.md:122

`examples/` contains a worked extraction: the source material provided (`input-brief.md`) and the `brand-lock.md` produced from it, including the Extraction notes audit trail. Use it to calibrate the level of specificity and the confidence flagging.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "ff7824966969",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 3a049fb85a6b — brand-lock-extractor/brand-packs/README.md:7

Copy `_template.md` to a new file (e.g. `acme.md`)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "3a049fb85a6b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 055e3983e17e — brand-lock-extractor/brand-packs/README.md:8

Fill in every field. No placeholders left behind.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "055e3983e17e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 00c429d4741a — brand-lock-extractor/brand-packs/README.md:9

Reference it from your storyboard requests:

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "00c429d4741a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 63bc88687f69 — brand-lock-extractor/brand-packs/README.md:11

> "30-second founder explainer. Use `brand-packs/acme.md` as the brand lock."

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "63bc88687f69",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## edcfdf72486a — brand-lock-extractor/brand-packs/README.md:13

The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "edcfdf72486a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```
