# Source coverage review 51/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 901ade45f8e57170 — image/references/multi-panel.md:258-284 (code)

```
Scene: 12-panel storyboard poster, 3 columns x 4 rows. Dark background with each panel in a clean rectangular frame. "{title}" in bold white text at the top of the image. Below each panel: scene number and one-line description in small white text.

Subject: {character_description} — maintain consistent character design, proportions, and colors across all 12 panels.

Important Details:
Panel 1: {scene_1} — "{caption_1}"
Panel 2: {scene_2} — "{caption_2}"
Panel 3: {scene_3} — "{caption_3}"
Panel 4: {scene_4} — "{caption_4}"
Panel 5: {scene_5} — "{caption_5}"
Panel 6: {scene_6} — "{caption_6}"
Panel 7: {scene_7} — "{caption_7}"
Panel 8: {scene_8} — "{caption_8}"
Panel 9: {scene_9} — "{caption_9}"
Panel 10: {scene_10} — "{caption_10}"
Panel 11: {scene_11} — "{caption_11}"
Panel 12: {scene_12} — "{caption_12}"

Panels read left-to-right, top-to-bottom (like a comic page). Character appearance, clothing, and color palette must stay identical across all 12 panels — only pose, expression, angle, and environment change.

Style: {art_style}

Use Case: animation pre-production, pitch deck visualization, narrative overview poster
Constraints: all 12 panels must be distinct scenes (no duplicates), character consistency is critical, scene numbers must be legible, {language} captions
Quality: high
```

Extracted rules inside block: NONE

## a4113a7de3af761f — image/references/multi-panel.md:286-286 (paragraph)

**Variables:**

Extracted rules inside block: NONE

## 60f50edcea821819 — image/references/multi-panel.md:287-287 (list_item)

- `{title}` — project/episode title displayed at top

Extracted rules inside block: NONE

## 9f8bf69625939fcc — image/references/multi-panel.md:288-288 (list_item)

- `{character_description}` — detailed character design (colors, outfit, distinguishing features)

Extracted rules inside block: NONE

## 1bdfad2e67c1e953 — image/references/multi-panel.md:289-289 (list_item)

- `{scene_1}` through `{scene_12}` — visual description of each panel

Extracted rules inside block: NONE

## bed2ba405a357f4f — image/references/multi-panel.md:290-290 (list_item)

- `{caption_1}` through `{caption_12}` — text label under each panel

Extracted rules inside block: NONE

## f5efcab2e07a7512 — image/references/multi-panel.md:291-291 (list_item)

- `{art_style}` — (e.g., "Pixar-style 3D", "anime cel shading", "watercolor illustration", "graphic novel ink")

Extracted rules inside block: NONE

## 56a1f4d9c9af253e — image/references/multi-panel.md:292-292 (list_item)

- `{language}` — caption language

Extracted rules inside block: NONE

## 0a64ca713168caa7 — image/references/multi-panel.md:294-296 (paragraph)

**Recommended size:** 1024x1536 (portrait — 3 columns x 4 rows needs vertical space)
**Model:** GPT Image 2 `quality: high` (text-heavy — scene numbers and captions must be readable)
**Common pitfalls:**

Extracted rules inside block: 5d289ee91997, 21c88671420c

## dffafddce0dd4349 — image/references/multi-panel.md:297-297 (list_item)

- Character drift is the biggest risk at 12 panels — repeat character design details in the prompt, not just "same character"

Extracted rules inside block: NONE

## 2da66d42176a07e2 — image/references/multi-panel.md:298-298 (list_item)

- Without explicit scene numbering in the prompt, panels may appear in random order

Extracted rules inside block: NONE

## 96b77c8b5665f142 — image/references/multi-panel.md:299-299 (list_item)

- 12 panels with captions is extremely text-dense — keep captions under 5 words each for legibility

Extracted rules inside block: NONE

## 9ec360877961cd90 — image/references/multi-panel.md:300-300 (list_item)

- Art style must be stated once and applied uniformly; mixing styles across panels produces visual chaos

Extracted rules inside block: 4438718fde9a

## 146197e991a848f8 — image/references/multi-panel.md:304-304 (heading)

## General Multi-Panel Tips

Extracted rules inside block: NONE

## 3a5d291bd7dbc5ff — image/references/multi-panel.md:306-306 (paragraph)

**Panel count vs. detail trade-off:** More panels = less detail per panel. 4 panels allow rich per-panel descriptions; 12 panels need brief, visually distinct descriptions (3-8 words each).

Extracted rules inside block: NONE

## eee4365c6ad091ba — image/references/multi-panel.md:308-308 (paragraph)

**Subject consistency:** Always include an explicit instruction: "same person / same character / same product across all panels." Repeat key identity markers (hair color, clothing, distinguishing features) rather than saying "same as before."

Extracted rules inside block: b9796e26aa95

## a09075b7f0f933a7 — image/references/multi-panel.md:310-310 (paragraph)

**Grid specification:** Always state the grid dimensions (e.g., "3x2 grid, 3 columns 2 rows"). Saying "6 panels" without layout instruction lets the model choose an unpredictable arrangement.

Extracted rules inside block: 79125e381338

## 4cd4381d9aae25f3 — image/references/multi-panel.md:312-312 (paragraph)

**Borders and gaps:** Be explicit — "thin white border between panels" or "borderless, no gaps." Default behavior varies by model and is unreliable.

Extracted rules inside block: NONE

## e2f0215ce4d0a91f — image/references/multi-panel.md:314-314 (paragraph)

**Reading order:** State it: "left-to-right, top-to-bottom" or "numbered 1-9 starting top-left." Without this, narrative flow may be jumbled.

Extracted rules inside block: NONE

## dc7ac61cf754040c — image/references/multi-panel.md:316-316 (paragraph)

**Model selection summary:**

Extracted rules inside block: NONE

## f106970d8ed25ef0 — image/references/multi-panel.md:317-317 (list_item)

- Text/labels in panels --> GPT Image 2 `quality: high`

Extracted rules inside block: NONE

## 8c6e2503aae4e88e — image/references/multi-panel.md:318-318 (list_item)

- No text, complex composition --> Nano Banana Pro

Extracted rules inside block: NONE

## fc67388832e36723 — image/references/multi-panel.md:319-319 (list_item)

- Budget/exploration --> Nano Banana 2 or GPT Image 2 `quality: low`

Extracted rules inside block: NONE

## 41404eed51554afb — image/references/multi-panel.md:323-323 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 9617a9b079e08053 — image/references/nano-banana.md:1-1 (heading)

# Nano Banana — Specific Rules

Extracted rules inside block: NONE

## fa91eeb3c06085a3 — image/references/nano-banana.md:3-3 (paragraph)

Три тира. «Thinking» модели — понимают намерение, физику, композицию.

Extracted rules inside block: NONE

## abea56954c3b8a09 — image/references/nano-banana.md:5-5 (table_row)

| Тир | Model ID | Роль |

Extracted rules inside block: NONE

## 2ac3c34fd2657133 — image/references/nano-banana.md:7-7 (table_row)

| **NB2 Lite** | `gemini-3.1-flash-lite-image` | Самая быстрая и дешёвая ($0.034, ~4 сек), только 1K. Черновики, массовые батчи |

Extracted rules inside block: NONE

## d5cb127bf4d6b2b3 — image/references/nano-banana.md:8-8 (table_row)

| **NB2** (Flash) | `gemini-3.1-flash-image` | Дефолтный workhorse: Pro-фичи (текст, 4K, grounding, консистентность) на скорости Flash |

Extracted rules inside block: NONE

## 8d4059a967f1fb05 — image/references/nano-banana.md:9-9 (table_row)

| **NBP** (Pro) | `gemini-3-pro-image` | Топ-тир: сложные многослойные сцены, максимум reasoning и контроля |

Extracted rules inside block: NONE
