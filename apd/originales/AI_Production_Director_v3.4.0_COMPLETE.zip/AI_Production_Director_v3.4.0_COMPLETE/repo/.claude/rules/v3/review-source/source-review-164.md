# Source coverage review 164/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 7b5af6034e9735ef — video/references/race-and-speed.md:169-169 (table_row)

| Toxic amber/sodium (rationed) | temporary, contaminated, alien — never cozy | sodium lamp as a passing smear; spilled fluid catching one lamp; the Tree's three ambers as countdown only |

Extracted rules inside block: 14fccd7551d3

## ccbe5c4106b2c26e — video/references/race-and-speed.md:171-171 (paragraph)

**Warmth as toxin** is the only permitted heat: brake-disc/exhaust glow (the machine at its thermal limit), a header flame stab gone in a frame, the Tree's alien ambers, a sickly sodium smear. Any warm element must be **point-source and surrounded by cold**. If amber fills more than ~15% of the frame it has become a wash — kill it.

Extracted rules inside block: d8555bab9213

## 07bb3c726123b343 — video/references/race-and-speed.md:173-173 (heading)

### Concrete lighting recipes (drop-in for the format-C Light column: source · direction · quality · what it rims)

Extracted rules inside block: NONE

## ebec83e787733bde — video/references/race-and-speed.md:175-175 (list_item)

- **Hard key on the working hand** [Detail/Pressure]: single hard source 45° camera-side onto knuckles on the shifter — finger shadows rake the skin, sweat reads as discrete specular dots, veins as ridges, background crushed. The whitening knuckle IS the fear.

Extracted rules inside block: NONE

## 61bb19e138582a05 — video/references/race-and-speed.md:176-176 (list_item)

- **Backlight / rim on metal edge** [Power]: hard white or cyan source behind/above at low angle drawing one bright line down the roof gutter, mirror housing or wing edge; body in shadow, only the contour glows, against black sky.

Extracted rules inside block: NONE

## 9dad2212914a7c57 — video/references/race-and-speed.md:177-177 (list_item)

- **Backlit smoke** [Pressure/Establish]: hard cyan or mercury-white punching *through* tire smoke from behind; volumetric shafts, the car a dark mass dissolving into glowing haze, red tail-light bleed inside the smoke for the danger accent. Front-lit smoke is dead gray nothing — always rim it from behind.

Extracted rules inside block: 5da3ae089a6a

## d82b2732e4dac572 — video/references/race-and-speed.md:178-178 (list_item)

- **Brake-disc glow** [Detail/Impact]: macro on the wheel, glowing orange-red rotor through the spokes as the *only* warm element (toxic heat), rim the caliper and spokes with that glow, everything else steel blue — the one ember in a cold frame.

Extracted rules inside block: NONE

## 19df7c048a2c8cf5 — video/references/race-and-speed.md:179-179 (list_item)

- **Specular on wet asphalt — the mirror** [Establish/Shift]: low bumper-height, lane stretching away, practicals (Tree, sodium lamps, headlights) reflected as long vertical smears down the wet surface as the composition's spine; pull the real lamps half out of frame, keep the mirror. Wet asphalt at night = `dramaturgy.md` §9 guilt/threat, and the cheapest way to put more cold light in frame without lifting blacks.

Extracted rules inside block: NONE

## 43e2e146fbe9b677 — video/references/race-and-speed.md:180-180 (list_item)

- **Silhouette / contre-jour** [Power/Pressure]: helmet/shoulder as pure black shape against a blown headlight or the Tree's amber bank, one thin rim defining the form plus one glint on the visor edge, no features. The brain fills the dark with something worse than any face.

Extracted rules inside block: 1acb8598b341

## ce3e64d59970e8d9 — video/references/race-and-speed.md:181-181 (list_item)

- **The Christmas Tree as the scene's lamp and clock** [Pressure→Impact]: put the Tree bank in frame as the dominant practical — its glow the only key. Stage 1: two blue bulbs as cold points in the lacquer. Stage 2: three ambers blazing, amber-as-toxin spill on wet asphalt, held. Stage 3: green pops, a single green reflection streaks the hood. Match-cut the round bulb → round headlight → round tach.

Extracted rules inside block: NONE

## 34b332e00a1212ce — video/references/race-and-speed.md:183-183 (paragraph)

**Texture and atmosphere.** Name the grain, never "clean": fine-to-medium film grain (heaviest in shadow), halation/bloom on hard practicals (soft glow ring + hard hot core), one anamorphic flare off the dominant source, slight chromatic fringe on the hottest edges (anti-sterile test in `animatic-keyframes.md` §7). One atmospheric pressure per panel (`dramaturgy.md` §9, Kurosawa) — backlit tire smoke, frozen launch grit lit on its leading edge, heat-haze warping the rimmed edge, wet asphalt as the mirror. Don't stack smoke + haze + spray in one still or it turns to mud. Keep Tony Scott's restlessness and grain; discard his warm grade.

Extracted rules inside block: 14fce3169e12

## 87eae903a7e5d89b — video/references/race-and-speed.md:187-187 (heading)

## 8. Sound & rhythm

Extracted rules inside block: NONE

## fd2604dc597ad085 — video/references/race-and-speed.md:189-189 (paragraph)

You storyboard the **sound first**; the keyframes hang off it. The general law — **loudness in the audio = panel count** — and the descending duration staircase are the density ladder in `animatic-keyframes.md` §3, sitting on the `dramaturgy.md` §12 rhythm staircase. Do not re-derive them. The race-specific rhythm rules:

Extracted rules inside block: 3dba50840063

## 0bd82794f9937e78 — video/references/race-and-speed.md:191-191 (list_item)

- **Engine as metronome.** Tie panel *duration* to RPM: idle = ~2s panels, redline = panels collapsing 2s → 1s → 0.5s → 8fr → 4fr toward the green. The board should read as an accelerating tachometer on mute. Annotate each panel with its on-screen life.

Extracted rules inside block: 8885aa0838bf

## fa7c69f07207a9e7 — video/references/race-and-speed.md:192-192 (list_item)

- **Amber collapse.** The Sportsman stagger (§5) is the audible drum-roll: idle drops out on the ambers, each amber a tighter panel, the green detonates.

Extracted rules inside block: NONE

## 0421e789722caa57 — video/references/race-and-speed.md:193-193 (list_item)

- **The wrinkle is the one time-expansion.** Dedicate 2–3 sequential panels to the slick folding (clean → wrinkled → gripping), marked "RAMP — hold", sound dropped (the Goodyear move) — the only place time *expands* inside the loud section.

Extracted rules inside block: NONE

## b23530f9548d3c62 — video/references/race-and-speed.md:194-194 (list_item)

- **Pull-to-intimate at the peak.** At the contest's tensest point, cut from a wide loud pass to an ECU of glove-on-shifter / breath-fog, shallow focus, void around it — engines stripped to breath only. The *quiet* panel goes *tight*; the loud panel goes wide.

Extracted rules inside block: a4012cff714e

## 6b7d19d3eb001819 — video/references/race-and-speed.md:195-195 (list_item)

- **Machine talks (the governing anchor).** Strip music; the `Sound` cell reads "engine + tire only" (Audi Quattro 1984).

Extracted rules inside block: NONE

## 332c4790bf0296df — video/references/race-and-speed.md:196-196 (list_item)

- **Sound leads picture by 2–3fr** (J-cuts). Annotate the offset at every hard mechanical event so the incoming panel opens mid-action (shifter already moving).

Extracted rules inside block: NONE

## 8e221972e1bd1736 — video/references/race-and-speed.md:198-198 (paragraph)

Every panel inherits a `Sound` cell even though it is a still (`dramaturgy.md` §11) — prompt the *physical consequence* of the sound (deformation, particulate, smear, heat-haze, isolation-in-void), never a named sound. Fill it.

Extracted rules inside block: ed003998e5a1

## e7631cc2fac515dd — video/references/race-and-speed.md:202-202 (heading)

## 9. 30-second structure (beat map)

Extracted rules inside block: NONE

## 9663ed91f54405fa — video/references/race-and-speed.md:204-204 (paragraph)

Five phases: **ritual → staging → launch → contest → release.** Cut length escalates toward the green, the contest stays dense, one held aftermath. ~20–26 panels. Function tags from `role-modes.md` §4. This is the structural skeleton; for a fully worked, panel-by-panel deliverable board of this exact structure (format C, ~13 rows), use `animatic-keyframes.md` §8 — do not draw a second worked board here.

Extracted rules inside block: 10a2c1fa3718

## b750c2da972f3b85 — video/references/race-and-speed.md:206-206 (table_row)

| Time | Phase | Function tags | # keyframes | Panel life | Framing | Sound | Render note |

Extracted rules inside block: NONE

## 2facc24eab1abe86 — video/references/race-and-speed.md:208-208 (table_row)

| 0:00–0:06 | **Ritual** | Establish, Detail, Pressure | 3–4 | 1.5–2s | Macro / ECU, locked | Idle lope, metal ticks, near-silence, music off | Held low-motion inserts: slick into water box, harness latch, finger over ignition, condensation on glass. Belief is won here. |

Extracted rules inside block: NONE

## 8b5f902b814a92d3 — video/references/race-and-speed.md:209-209 (table_row)

| 0:06–0:11 | **Staging** | Pressure, Power | 3–4 | 1s → held | Symmetric MS, Tree centered, static | Idle drops to silence on ambers; Tree relay click | Pre-stage/stage bulbs; one long *held* symmetric Tree panel = the pause. Tach trembling = the only motion. |

Extracted rules inside block: NONE

## 87a8a36b74c96463 — video/references/race-and-speed.md:210-210 (table_row)

| 0:11–0:19 | **Launch** | Impact | 6–9 | 8fr → 4fr (burst) | Low bumper-POV, side-rig, ECU tach | BANG: tire chirp + roar, J-cut 2–3fr ahead | Hip-hop burst cluster: bumper smear, side wheelspin, tach flare, clutch hand, lane-stripe strobe. Asphalt in frame. One speed-ramp on the wrinkle. |

Extracted rules inside block: NONE

## 963818cf566cacb6 — video/references/race-and-speed.md:211-211 (table_row)

| 0:19–0:27 | **Contest** | Power, Shift, Reaction | 6–8 | 0.5–1s | Mirror two-shot, joust, parallel pass | Layered roar; **one pull-to-intimate / in-the-head panel** | Mirrored compositions, joust, parallel pass, one medium-wide proving ground-speed. Alternate fragment-cluster ↔ one quiet detail panel. |

Extracted rules inside block: NONE

## 6a429d178417d4f8 — video/references/race-and-speed.md:212-212 (table_row)

| 0:27–0:30 | **Release / Aftermath** | Impact, Aftermath, Exit | 2–3 | 0.5s, then 2s hold | Wide-to-detail, smoke in beam | Hard cut to silence / one tick | Finish marker + microscopic edge, OR skip the result → engine drop, smoke through headlight beam, car nosing into dark. End on consequence, not explanation. |

Extracted rules inside block: NONE

## ab3856d0b2d73fe1 — video/references/race-and-speed.md:214-214 (paragraph)

Allocation: plot the board as a descending duration staircase, broken only by the one pre-launch held panel (the single most-held still, most negative space) and the one post-finish hold. The launch is *never* one hero frame — fan it into the 6–9-panel micro-burst. No two bang-clusters touch; every burst is separated by a held quiet panel.

Extracted rules inside block: 035899331704

## fd8e7a82c1caaa4a — video/references/race-and-speed.md:218-218 (heading)

## 10. Anti-fake guard

Extracted rules inside block: NONE
