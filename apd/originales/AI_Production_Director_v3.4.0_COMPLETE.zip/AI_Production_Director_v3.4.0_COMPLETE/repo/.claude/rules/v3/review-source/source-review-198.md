# Source coverage review 198/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## fddf79e8cf1a21a5 — visual-media/SKILL.md:176-176 (heading)

### Perfil de cada plataforma

Extracted rules inside block: NONE

## fc66e2716acf66b0 — visual-media/SKILL.md:178-178 (table_row)

| Plataforma | Duración óptima | Relación de aspecto | Carácter |

Extracted rules inside block: NONE

## 367104fdfaccd64f — visual-media/SKILL.md:180-180 (table_row)

| TikTok | 15–60s | 9:16 | Entretenimiento, retos |

Extracted rules inside block: NONE

## b8c70c89dee502a7 — visual-media/SKILL.md:181-181 (table_row)

| Reels | 15–90s | 9:16 | Cuidado, estética |

Extracted rules inside block: NONE

## b1f10ef2c6524850 — visual-media/SKILL.md:182-182 (table_row)

| Shorts | 15–60s | 9:16 | Divulgación, humor |

Extracted rules inside block: NONE

## 371f9ca4e9ed9622 — visual-media/SKILL.md:183-183 (table_row)

| Douyin | 15–60s | 9:16 | Contenido local |

Extracted rules inside block: NONE

## 09181c91588b7ae6 — visual-media/SKILL.md:185-185 (heading)

### Estructura de un video corto

Extracted rules inside block: NONE

## 259314ce9631e821 — visual-media/SKILL.md:187-208 (code)

```
┌─────────────────────────────────────────────────────────────────┐
│  Fórmula de oro del formato corto                               │
│                                                                 │
│  0–3 s: Hook                                                    │
│  ├─ Pregunta o intriga                                          │
│  ├─ Impacto visual                                              │
│  └─ "Espérate a ver esto…"                                      │
│                                                                 │
│  3–50 s: Contenido                                              │
│  ├─ Ritmo acelerado                                             │
│  ├─ Entrega por bloques                                         │
│  └─ Sostener el interés                                         │
│                                                                 │
│  Últimos 5 s: CTA                                               │
│  ├─ Like / seguir                                               │
│  ├─ Invitar a comentar                                          │
│  └─ Ver más contenido                                           │
│                                                                 │
│  Clave: ¡los primeros 3 segundos deciden todo!                  │
└─────────────────────────────────────────────────────────────────┘
```

Extracted rules inside block: NONE

## a06124240dfa1fc8 — visual-media/SKILL.md:210-210 (heading)

## Fundamentos de animación

Extracted rules inside block: NONE

## 3b62e6e538e7865e — visual-media/SKILL.md:212-212 (heading)

### Los 12 principios

Extracted rules inside block: NONE

## 684a14281f814623 — visual-media/SKILL.md:214-264 (code)

```markdown
## Los 12 principios de animación de Disney

1. **Squash & Stretch** (compresión y estiramiento)
   - Conservar el volumen
   - Comunicar peso y elasticidad

2. **Anticipación** (Anticipation)
   - Agacharse antes de saltar
   - Retraer el brazo antes del golpe

3. **Puesta en escena** (Staging)
   - Comunicar la intención con claridad
   - Guiar la mirada del espectador

4. **Directo vs. pose a pose** (Straight Ahead & Pose to Pose)
   - Directo: fluido, orgánico
   - Pose a pose: preciso, controlable

5. **Acción continuada y superpuesta** (Follow Through & Overlapping)
   - El retardo del cabello y la ropa
   - Aporta naturalidad

6. **Entradas y salidas lentas** (Slow In & Slow Out)
   - El movimiento arranca y termina lento
   - Y acelera en medio

7. **Arcos** (Arcs)
   - El movimiento natural es curvo
   - Evita la sensación mecánica

8. **Acción secundaria** (Secondary Action)
   - Micromovimientos además de la acción principal
   - Enriquecen al personaje

9. **Timing** (Timing)
   - El número de cuadros define la velocidad
   - Afecta la sensación de peso

10. **Exageración** (Exaggeration)
    - Más intenso que la realidad
    - Resalta el rasgo distintivo

11. **Dibujo sólido** (Solid Drawing)
    - Entender la estructura tridimensional
    - Peso y equilibrio

12. **Atractivo** (Appeal)
    - Carisma del personaje
    - Que dé ganas de verlo
```

Extracted rules inside block: NONE

## c3f3e54bf693109d — visual-media/SKILL.md:266-266 (heading)

### Flujo de producción de animación

Extracted rules inside block: NONE

## 6a12d15a6695c4e5 — visual-media/SKILL.md:268-274 (code)

```
Concepto → Guion → Storyboard → Diseño → Animación → Post → Entrega
                                   ↓
                          Diseño de personajes
                          Diseño de escenarios
                          Paleta de color
```

Extracted rules inside block: NONE

## 9e9a30ac0fdd9dfb — visual-media/SKILL.md:276-276 (heading)

## Postproducción y edición

Extracted rules inside block: NONE

## 4a36e732f7301c84 — visual-media/SKILL.md:278-278 (heading)

### Ritmo de edición

Extracted rules inside block: NONE

## f6af3036dc3209be — visual-media/SKILL.md:280-299 (code)

```markdown
## Principios de edición

### Corte en movimiento
- Cambia de plano durante la acción
- Mantiene la fluidez

### Corte en reposo
- Cambia durante una pausa
- Habitual en escenas de diálogo

### Regla de los 180 grados
- Conserva la posición relativa de los personajes
- Evita cruzar el eje

### J-Cut / L-Cut
- J-Cut: el audio entra antes que la imagen
- L-Cut: la imagen se mantiene después del audio
- Aumentan la fluidez
```

Extracted rules inside block: NONE

## 3ed9148c59b8073f — visual-media/SKILL.md:301-301 (heading)

### Fundamentos de colorización

Extracted rules inside block: NONE

## d4c6d9c3c273c80b — visual-media/SKILL.md:303-303 (table_row)

| Parámetro | Función | Ejemplo |

Extracted rules inside block: NONE

## cd228f10c71eee61 — visual-media/SKILL.md:305-305 (table_row)

| Exposición | Brillo general | Levantar una toma subexpuesta |

Extracted rules inside block: NONE

## 3ceac9637e60b54e — visual-media/SKILL.md:306-306 (table_row)

| Contraste | Distancia entre luces y sombras | Ganar volumen |

Extracted rules inside block: NONE

## bf89e6c197abc9be — visual-media/SKILL.md:307-307 (table_row)

| Temperatura | Frío / cálido | Cálido para calidez emocional |

Extracted rules inside block: NONE

## c6e4ad747af20170 — visual-media/SKILL.md:308-308 (table_row)

| Tinte | Verde / magenta | Corrección de tonos de piel |

Extracted rules inside block: NONE

## e8103e2efaa246de — visual-media/SKILL.md:309-309 (table_row)

| Saturación | Intensidad de color | Desaturar para look cinematográfico |

Extracted rules inside block: NONE

## a5ef335abaa143c1 — visual-media/SKILL.md:310-310 (table_row)

| Curvas | Ajuste fino | Curva en S para más contraste |

Extracted rules inside block: NONE

## cf6f67f6d19c6f37 — visual-media/SKILL.md:312-312 (heading)

## Herramientas recomendadas

Extracted rules inside block: NONE

## b3317b98807eea1e — visual-media/SKILL.md:314-314 (heading)

### Equipo de captura

Extracted rules inside block: NONE

## 4859bbcb482dc187 — visual-media/SKILL.md:315-315 (list_item)

- **Cámaras**: Sony A7, Canon R, Fujifilm

Extracted rules inside block: NONE

## c86a0ba4c9ec3d32 — visual-media/SKILL.md:316-316 (list_item)

- **Celular**: iPhone Pro, Pixel

Extracted rules inside block: NONE

## 3acfdc0ae5112018 — visual-media/SKILL.md:317-317 (list_item)

- **Estabilizadores**: DJI RS, Zhiyun

Extracted rules inside block: NONE

## ddf85d3dfe16dc93 — visual-media/SKILL.md:319-319 (heading)

### Software de edición

Extracted rules inside block: NONE
