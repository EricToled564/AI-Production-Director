# Source coverage review 227/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f6b45f478523f17d — visual-prompt-forge/references/failure-modes.md:118-118 (list_item)

- Tighten the shot's subject field, what specifically is the audience meant to feel or notice

Extracted rules inside block: NONE

## 9cdcc1dd696c43e2 — visual-prompt-forge/references/failure-modes.md:119-119 (list_item)

- Include a one-phrase intent at the end ("the moment of recognition", "the calm before the decision")

Extracted rules inside block: NONE

## 666ec34cf53b5f6e — visual-prompt-forge/references/failure-modes.md:120-120 (list_item)

- For complex scenes, add a "what this shot conveys" line

Extracted rules inside block: NONE

## 2cdd43b3cddab3ba — visual-prompt-forge/references/failure-modes.md:122-122 (paragraph)

**Accept editorially when:** generation is close enough that retouching gets there. Don't burn API credits chasing perfect on-prompt.

Extracted rules inside block: e1a5f9f21b69

## 4e02a66f1ecccde3 — visual-prompt-forge/references/failure-modes.md:124-124 (heading)

## When to stop iterating prompts

Extracted rules inside block: NONE

## a3ee30092b554b32 — visual-prompt-forge/references/failure-modes.md:126-126 (paragraph)

Three signs:

Extracted rules inside block: NONE

## 86da34eab64fe95d — visual-prompt-forge/references/failure-modes.md:128-128 (list_item)

1. You've re-rolled the same shot 5+ times with no improvement → the prompt is fine; the model can't render this concept; pick a different shot or different generator

Extracted rules inside block: 65e9cd1d5013

## 902a6d4e6f4dbe5a — visual-prompt-forge/references/failure-modes.md:129-129 (list_item)

2. You're tweaking single words and hoping → you've hit prompt-level diminishing returns; move to image-to-image refinement (Nano Banana) or post-production

Extracted rules inside block: 6f6d83244015

## e766b0c10dc53cc9 — visual-prompt-forge/references/failure-modes.md:130-130 (list_item)

3. The image is 80% right and the gap is editorial → ship to post and let the editor finish

Extracted rules inside block: 01b98a09215e

## dd8b400af48b2e60 — visual-prompt-forge/references/failure-modes.md:132-132 (paragraph)

Generation is one stage in a pipeline. Don't try to make it the whole pipeline.

Extracted rules inside block: c03c9bff65b0

## e6f4c1dadda2e72f — visual-prompt-forge/references/prompt-anatomy.md:1-1 (heading)

# Prompt Anatomy: The Five Layers

Extracted rules inside block: NONE

## 179f8f5215df7ef1 — visual-prompt-forge/references/prompt-anatomy.md:3-3 (paragraph)

Every image prompt this skill produces is composed from five layers. Four are inputs, one is applied at compose-time. Understanding the layers is the difference between bulletproof prompts and lottery tickets.

Extracted rules inside block: NONE

## 3cf64f70024fe3a0 — visual-prompt-forge/references/prompt-anatomy.md:5-5 (heading)

## Layer 1. Brand Lock

Extracted rules inside block: NONE

## 4a2897cbed04165f — visual-prompt-forge/references/prompt-anatomy.md:7-9 (paragraph)

**What:** the locked brand parameters for the entire project.
**Source:** `brand-lock.snapshot.md` referenced in `shots.json`.
**Constant across:** every storyboard, every shot.

Extracted rules inside block: NONE

## 448e74d51e0a4ae2 — visual-prompt-forge/references/prompt-anatomy.md:11-11 (paragraph)

Contains:

Extracted rules inside block: NONE

## 982bf457cdc4f822 — visual-prompt-forge/references/prompt-anatomy.md:13-13 (list_item)

- Palette (hex values)

Extracted rules inside block: NONE

## 52498119d342d9b6 — visual-prompt-forge/references/prompt-anatomy.md:14-14 (list_item)

- Typography (font names, weights)

Extracted rules inside block: NONE

## f0c98eea69a0af72 — visual-prompt-forge/references/prompt-anatomy.md:15-15 (list_item)

- Mood descriptors (3–5 adjectives that describe the brand's emotional posture)

Extracted rules inside block: NONE

## f4668d1dc90a2d59 — visual-prompt-forge/references/prompt-anatomy.md:16-16 (list_item)

- "Never" list (things this brand never does, e.g. "no stock photo aesthetic", "no AI uncanny", "no over-saturated", "no shouting copy")

Extracted rules inside block: 5e30e8fdcae7

## 3e041aa25cac1a18 — visual-prompt-forge/references/prompt-anatomy.md:17-17 (list_item)

- Aspect ratios used

Extracted rules inside block: NONE

## b76f4f1bf6f48173 — visual-prompt-forge/references/prompt-anatomy.md:18-18 (list_item)

- Color grade direction

Extracted rules inside block: NONE

## d2ef650eedb96611 — visual-prompt-forge/references/prompt-anatomy.md:20-20 (paragraph)

This layer answers: **what does the brand always look and feel like?**

Extracted rules inside block: 04faf520c218

## 33c53c863235c783 — visual-prompt-forge/references/prompt-anatomy.md:22-22 (heading)

## Layer 2. Series Lock

Extracted rules inside block: NONE

## 7537fb263269120e — visual-prompt-forge/references/prompt-anatomy.md:24-26 (paragraph)

**What:** the locked anchors for this specific storyboard.
**Source:** `shots.json` → `series_lock`.
**Constant across:** every shot in this one storyboard.

Extracted rules inside block: NONE

## 21849157ed2af33e — visual-prompt-forge/references/prompt-anatomy.md:28-28 (paragraph)

Contains:

Extracted rules inside block: NONE

## 81104bda581dcfbf — visual-prompt-forge/references/prompt-anatomy.md:30-30 (list_item)

- Character anchor (who's in frame, described identically every shot)

Extracted rules inside block: NONE

## eeb88bfdef3cf3f0 — visual-prompt-forge/references/prompt-anatomy.md:31-31 (list_item)

- Environment description (where the action takes place, identical every shot)

Extracted rules inside block: NONE

## aeab3308fc2dc486 — visual-prompt-forge/references/prompt-anatomy.md:32-32 (list_item)

- Lighting setup (direction, source, color temperature, identical every shot)

Extracted rules inside block: NONE

## 7c7cc6918d4905ba — visual-prompt-forge/references/prompt-anatomy.md:33-33 (list_item)

- Color grade (filmic look, identical every shot)

Extracted rules inside block: NONE

## 86e7b8a1f239509f — visual-prompt-forge/references/prompt-anatomy.md:35-35 (paragraph)

This layer answers: **what stays the same across this storyboard?**

Extracted rules inside block: NONE
