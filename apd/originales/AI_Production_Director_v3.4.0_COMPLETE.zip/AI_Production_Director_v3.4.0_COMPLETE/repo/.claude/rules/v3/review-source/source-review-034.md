# Source coverage review 34/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 75b7b40612ff4972 — image/SKILL.md:76-76 (paragraph)

Studio-quality vocabulary for lighting design, camera and hardware, color grading and film stock, materiality and texture. Read when you need precise terms beyond what `golden-rules.md` covers.

Extracted rules inside block: NONE

## e64fe963e5a8e078 — image/SKILL.md:78-78 (heading)

### Step 6 — read if structuring a complex prompt → [prompt-framework.md](references/prompt-framework.md)

Extracted rules inside block: NONE

## 42597322106802b7 — image/SKILL.md:80-80 (paragraph)

Universal element checklist (subject, context, action, environment, camera, lighting, mood, materials, palette, format), detail modes (concise / standard / verbose / cinematic verbose), parameterized templates, output structure with parameters and exclusions.

Extracted rules inside block: NONE

## 32b60d1ada820b8e — image/SKILL.md:84-84 (heading)

# Output format

Extracted rules inside block: NONE

## d265f9263f221117 — image/SKILL.md:86-86 (paragraph)

When you return the prompt, structure it like this:

Extracted rules inside block: NONE

## 3602f4edd3a2834f — image/SKILL.md:88-98 (code)

```
Model: <nano-banana-2 | nano-banana-pro | gpt-image-2>
Quality: <low | medium | high>          (only for gpt-image-2)
Size / Ratio: <e.g. 1536×1024 or 16:9>

Prompt:
<the prompt text, ready to copy>

Notes:
- <anything you inferred or assumed because the user did not specify>
```

Extracted rules inside block: NONE

## 0ebfc09f05d83048 — image/SKILL.md:100-100 (paragraph)

For edits, also include an explicit preserve-list (mandatory for gpt-image-2, recommended for nano-banana):

Extracted rules inside block: 2602e0a1b258

## ad61989bcdf4ba4a — image/SKILL.md:102-106 (code)

```
Change: <one concrete thing>
Preserve: <face, pose, lighting, framing, geometry, ...>
Constraints: <no extra objects, no drift, ...>
```

Extracted rules inside block: NONE

## 68b24077b62e1051 — image/SKILL.md:110-110 (heading)

# Final response style

Extracted rules inside block: NONE

## 9347f512c583f2f4 — image/SKILL.md:112-112 (paragraph)

Prefer: ready-to-copy prompts, hex colors, concrete materials, named compositions, model-specific syntax (5-slot for GPT Image, natural prose for Nano Banana).

Extracted rules inside block: bd9a8d88c6b7

## d5919745c630e89e — image/SKILL.md:114-114 (paragraph)

Avoid: tag soup ("cool, modern, 4k"), vague praise ("stunning, epic, masterpiece" — actively hurts GPT Image 2), negative framing ("no people, no cars" — invert to positive), external comparisons ("like Apple ad" — describe the visual properties instead), numerical lens parameters in Nano Banana prompts (it ignores them).

Extracted rules inside block: e925c956faba

## 6f0d8773bd583e8c — image/SKILL.md:118-118 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## c9d2b9162c92cd3e — image/references/characters.md:1-1 (heading)

# Character Consistency

Extracted rules inside block: NONE

## 70ffd2216abae045 — image/references/characters.md:3-3 (paragraph)

Up to 14 reference images (6 high-fidelity). Identity locking across scenes.

Extracted rules inside block: NONE

## 36a8cc5339ac27ba — image/references/characters.md:5-5 (heading)

## Identity Locking

Extracted rules inside block: NONE

## 55608f397200a6b4 — image/references/characters.md:7-12 (code)

```
Using person from [IMAGE REFERENCE]:
Keep facial features exactly the same.
Change: [EXPRESSION / POSE / CLOTHING / SETTING]
Maintain: identity, recognizable features
```

Extracted rules inside block: NONE

## 48ca65fb3619ed3a — image/references/characters.md:14-14 (paragraph)

Key phrase: "Keep facial features exactly the same as Image 1"

Extracted rules inside block: NONE

## 581ead2a41be7d1e — image/references/characters.md:16-16 (heading)

## Viral Thumbnails

Extracted rules inside block: NONE

## aa0f049620bb31a1 — image/references/characters.md:18-29 (code)

```
Design viral thumbnail using person from Image 1.

Face: Keep features same, change expression to [excited/surprised/shocked]
Action: Pose on [left/right], pointing toward [OBJECT]
Subject: [OBJECT] on opposite side
Graphics: Bold [COLOR] arrow connecting person to object
Text: "[HEADLINE]" in massive pop-style, white outline, drop shadow
Background: Blurred [SETTING]

High saturation and contrast.
```

Extracted rules inside block: NONE

## 9ef70f634582f6cc — image/references/characters.md:31-31 (heading)

## Multi-Character Consistency

Extracted rules inside block: NONE

## eba4af4d7ede22cf — image/references/characters.md:33-41 (code)

```
Create [NUMBER]-part story with these [N] characters.

Identity: Keep attire and features consistent throughout.
Variation: Different angles, expressions, distances per image.
Rule: Only one of each character per image.

Story arc: [DESCRIPTION with emotional highs/lows]
```

Extracted rules inside block: NONE

## c93da86e25cdd49f — image/references/characters.md:43-43 (heading)

## Brand Asset Generation

Extracted rules inside block: NONE

## 4cdde25613b1649b — image/references/characters.md:45-54 (code)

```
Using this [PRODUCT] as reference:
Create [NUMBER] [TYPE] shots.

Maintain: Brand consistency, quality level
Vary: Angles, lighting, context
Style: [editorial / lifestyle / product]

Generate one at a time.
```

Extracted rules inside block: NONE

## 34d90ea94c3b1902 — image/references/characters.md:56-56 (heading)

## Expression Control

Extracted rules inside block: NONE

## a6739c6d94df562f — image/references/characters.md:58-58 (paragraph)

While maintaining identity:

Extracted rules inside block: NONE

## 8dc16a93f204adab — image/references/characters.md:59-59 (list_item)

- "Change expression to excited and surprised"

Extracted rules inside block: NONE

## f38e347962d317a5 — image/references/characters.md:60-60 (list_item)

- "Make them look thoughtful, gazing left"

Extracted rules inside block: NONE

## 7f9f86ddb26d1176 — image/references/characters.md:61-61 (list_item)

- "Add confident smile, direct eye contact"

Extracted rules inside block: NONE

## 8f7602bc312f93e2 — image/references/characters.md:63-63 (heading)

## Pose/Action Control

Extracted rules inside block: NONE

## a26a44ec64be5cca — image/references/characters.md:65-65 (list_item)

- "Pose pointing finger toward [DIRECTION]"

Extracted rules inside block: NONE
