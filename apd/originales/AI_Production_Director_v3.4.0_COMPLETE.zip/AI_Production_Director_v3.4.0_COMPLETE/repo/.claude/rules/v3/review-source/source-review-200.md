# Source coverage review 200/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 6c6f95bdb8ed8280 — visual-prompt-forge/SKILL.md:53-53 (list_item)

1. **Brand Lock**, palette, type, mood, "never" list (constant across project)

Extracted rules inside block: 3693a52c164a

## 86ce11263dd6f6fb — visual-prompt-forge/SKILL.md:54-54 (list_item)

2. **Series Lock**, character/environment/lighting anchors (constant across storyboard)

Extracted rules inside block: 698ce7b724a9

## 47d73108023af25d — visual-prompt-forge/SKILL.md:55-55 (list_item)

3. **Shot Spec**, framing, angle, motion, subject (per shot)

Extracted rules inside block: 4dbcd0c014f5

## bff6f353fe79a87c — visual-prompt-forge/SKILL.md:56-56 (list_item)

4. **Text Layer**, **never in the prompt**, composited separately

Extracted rules inside block: 4b54683cb02e

## af2f8c2aee85f1ba — visual-prompt-forge/SKILL.md:57-57 (list_item)

5. **Generator Adapter**, model-specific syntax wrapper

Extracted rules inside block: 24c390558ce1

## f0ced9bc55a248ac — visual-prompt-forge/SKILL.md:59-59 (paragraph)

The first four come from `shots.json` and the brand-lock. The fifth is what this skill applies.

Extracted rules inside block: NONE

## 46f415cf3fd29be1 — visual-prompt-forge/SKILL.md:61-61 (heading)

## Workflow

Extracted rules inside block: NONE

## 0234483a3870194c — visual-prompt-forge/SKILL.md:63-63 (heading)

### Step 1. Read inputs

Extracted rules inside block: NONE

## 914b81173196a008 — visual-prompt-forge/SKILL.md:65-65 (paragraph)

You need:

Extracted rules inside block: NONE

## 15fab09f9855803a — visual-prompt-forge/SKILL.md:67-67 (list_item)

- `shots.json` (required), the structured shot list

Extracted rules inside block: 1bbd62ce94c3

## b89cf81e16cf6dd3 — visual-prompt-forge/SKILL.md:68-68 (list_item)

- `brand-lock.snapshot.md` (required), referenced from shots.json

Extracted rules inside block: 6dfc2c3bc0b1

## f29f523be4bdb10b — visual-prompt-forge/SKILL.md:69-69 (list_item)

- Target generators (required), ask if not specified

Extracted rules inside block: 806d5d19d68a

## 3ae805a35e888672 — visual-prompt-forge/SKILL.md:71-71 (paragraph)

Validate before composing:

Extracted rules inside block: NONE

## cdb0f2cd7977b58f — visual-prompt-forge/SKILL.md:73-75 (code)

```bash
python tools/validate_shots.py output/
```

Extracted rules inside block: NONE

## f6513d58f241f6bb — visual-prompt-forge/SKILL.md:77-78 (paragraph)

If the brand-lock is missing or `shots.json` does not validate, stop and tell the user.
Don't try to forge prompts from incomplete data.

Extracted rules inside block: 970c6f2cc633

## 80d75052cb1d7ed5 — visual-prompt-forge/SKILL.md:80-83 (paragraph)

If `tools/` is not on hand (a Claude.ai upload, or a single-skill install), read the
schema from `../storyboard-architect/templates/shots.schema.json` and check by hand. That
relative path only resolves when the skills sit side by side; when they don't, ask the
user for the schema rather than composing from memory of it.

Extracted rules inside block: 08916ae57b0c

## 5f8b894ad6d36b27 — visual-prompt-forge/SKILL.md:85-85 (heading)

### Step 2. Pick the adapters

Extracted rules inside block: NONE

## 932dfcc73e86b28d — visual-prompt-forge/SKILL.md:87-87 (paragraph)

For each target generator, read the matching adapter file:

Extracted rules inside block: NONE

## bbcb6f8cb8ce7fc3 — visual-prompt-forge/SKILL.md:89-89 (list_item)

- `adapters/midjourney.md`

Extracted rules inside block: NONE

## 8b5d33ac8a1941ac — visual-prompt-forge/SKILL.md:90-90 (list_item)

- `adapters/flux.md`

Extracted rules inside block: NONE

## 220a3400a7837c3a — visual-prompt-forge/SKILL.md:91-91 (list_item)

- `adapters/ideogram.md`

Extracted rules inside block: NONE

## 97578dc575e43834 — visual-prompt-forge/SKILL.md:92-92 (list_item)

- `adapters/gpt-image.md`

Extracted rules inside block: NONE

## 785703e3365f6362 — visual-prompt-forge/SKILL.md:93-93 (list_item)

- `adapters/nano-banana.md`

Extracted rules inside block: NONE

## bf5c839c2ac78af6 — visual-prompt-forge/SKILL.md:94-94 (list_item)

- `adapters/seedream.md`

Extracted rules inside block: NONE

## 40d263b54c27804f — visual-prompt-forge/SKILL.md:95-95 (list_item)

- `adapters/kling.md`      (motion video, default)

Extracted rules inside block: NONE

## a4b6b9afceb7bd5a — visual-prompt-forge/SKILL.md:96-96 (list_item)

- `adapters/veo.md`        (motion video, dialogue/lipsync + native audio)

Extracted rules inside block: NONE

## 3937279940bcbfc7 — visual-prompt-forge/SKILL.md:97-97 (list_item)

- `adapters/seedance.md`   (motion video, multi-shot sequences)

Extracted rules inside block: NONE

## 81d9e6feb8cda9fd — visual-prompt-forge/SKILL.md:98-98 (list_item)

- `adapters/hailuo.md`     (motion video, budget iteration)

Extracted rules inside block: NONE

## c13a7dc2f1b1376a — visual-prompt-forge/SKILL.md:100-100 (paragraph)

Each adapter file documents the prompting style, parameter syntax, and known pitfalls for that generator. You **must** read the adapter before writing prompts for it. Don't guess from training data, image-gen syntax has churned multiple times.

Extracted rules inside block: f43c0716cd03

## a1cb6d89b5e28f97 — visual-prompt-forge/SKILL.md:102-102 (paragraph)

**`adapters/_capabilities.json` is the single source of truth for per-generator limits** (`max_prompt_words`, `supports_text_render`, `supports_motion`, `aspect_param`, and so on). Read it once at the start and respect those values when composing, and do not target motion on a stills-only generator.

Extracted rules inside block: e90072bcc355
