# Source coverage review 228/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 459a89f828e5c80e — visual-prompt-forge/references/prompt-anatomy.md:37-37 (paragraph)

The series_lock is what makes shot 1 and shot 7 feel like the same piece. Without it, every generated frame looks like a different production.

Extracted rules inside block: NONE

## caad179cb1f146f2 — visual-prompt-forge/references/prompt-anatomy.md:39-39 (heading)

## Layer 3. Shot Spec

Extracted rules inside block: NONE

## 229856abb8e38e30 — visual-prompt-forge/references/prompt-anatomy.md:41-43 (paragraph)

**What:** the per-shot variables.
**Source:** `shots.json` → `shots[i]`.
**Variable across:** every shot.

Extracted rules inside block: NONE

## 8ae670fd470bde68 — visual-prompt-forge/references/prompt-anatomy.md:45-45 (paragraph)

Contains:

Extracted rules inside block: NONE

## 3e37fee115d821f2 — visual-prompt-forge/references/prompt-anatomy.md:47-47 (list_item)

- Framing (ECU, CU, MS, etc.)

Extracted rules inside block: NONE

## f4c023431735faf4 — visual-prompt-forge/references/prompt-anatomy.md:48-48 (list_item)

- Angle (eye-level, high, low, etc.)

Extracted rules inside block: NONE

## 70ffcffde3b15568 — visual-prompt-forge/references/prompt-anatomy.md:49-49 (list_item)

- Motion (static, push, pull, etc.)

Extracted rules inside block: NONE

## f30c1e428bb5da52 — visual-prompt-forge/references/prompt-anatomy.md:50-50 (list_item)

- Subject (what's happening in this specific shot)

Extracted rules inside block: NONE

## 9a9b2dac28337f61 — visual-prompt-forge/references/prompt-anatomy.md:51-51 (list_item)

- Depth of field

Extracted rules inside block: NONE

## 49802f7e95250bdf — visual-prompt-forge/references/prompt-anatomy.md:52-52 (list_item)

- Rationale (audit trail, why this shot, this beat, this moment)

Extracted rules inside block: NONE

## b7bf836766459523 — visual-prompt-forge/references/prompt-anatomy.md:54-54 (paragraph)

This layer answers: **what's different about this specific shot?**

Extracted rules inside block: NONE

## 52e1f3185ad27745 — visual-prompt-forge/references/prompt-anatomy.md:56-56 (heading)

## Layer 4. Text Layer

Extracted rules inside block: NONE

## 94446c000a12735e — visual-prompt-forge/references/prompt-anatomy.md:58-60 (paragraph)

**What:** on-screen text composited after generation.
**Source:** `text-overlays.json`.
**Never appears in image prompts** (except Ideogram Mode 2 with explicit override).

Extracted rules inside block: 3cc53cc41c37

## 4b184f478500cfe9 — visual-prompt-forge/references/prompt-anatomy.md:62-62 (paragraph)

Why text is a separate layer:

Extracted rules inside block: NONE

## fe4a9a0a32dec4f5 — visual-prompt-forge/references/prompt-anatomy.md:64-64 (list_item)

1. **Editability.** Composited text can be revised without re-generating images.

Extracted rules inside block: c7812f433b4b

## 7f8e917a403bc2dd — visual-prompt-forge/references/prompt-anatomy.md:65-65 (list_item)

2. **Quality.** Even Ideogram and GPT Image (the best at text) produce typography that lags professional design tools.

Extracted rules inside block: a81c7c2a9375

## 4e5c49034146dbbc — visual-prompt-forge/references/prompt-anatomy.md:66-66 (list_item)

3. **Animation.** Animated text needs After Effects / Remotion / CapCut. Static rendered text is dead-on-arrival for motion content.

Extracted rules inside block: 13be37c4c704

## cb01f88ef500b7d5 — visual-prompt-forge/references/prompt-anatomy.md:67-67 (list_item)

4. **Brand control.** Composited text uses exact brand fonts and exact brand colors. Generated text approximates.

Extracted rules inside block: 2189476c0707

## ac81e835e61b0b10 — visual-prompt-forge/references/prompt-anatomy.md:69-69 (heading)

## Layer 5. Generator Adapter

Extracted rules inside block: NONE

## cbf9dd06c356c87e — visual-prompt-forge/references/prompt-anatomy.md:71-73 (paragraph)

**What:** model-specific syntax wrapper.
**Source:** the relevant `adapters/{generator}.md` file.
**Variable across:** every target generator.

Extracted rules inside block: NONE

## 671d82996f940a9a — visual-prompt-forge/references/prompt-anatomy.md:75-75 (paragraph)

This is the only layer the skill *applies* (vs. reads). Layers 1–4 are inputs; Layer 5 is the renderer that turns inputs into a generator-specific string.

Extracted rules inside block: NONE

## b3e90aba027b6f3e — visual-prompt-forge/references/prompt-anatomy.md:77-77 (paragraph)

The adapter handles:

Extracted rules inside block: NONE

## a365a2281f391824 — visual-prompt-forge/references/prompt-anatomy.md:79-79 (list_item)

- Word order (Midjourney leads with subject; motion adapters like Kling lead with camera motion)

Extracted rules inside block: NONE

## c347b832adab8b34 — visual-prompt-forge/references/prompt-anatomy.md:80-80 (list_item)

- Length conventions (Seedream short, GPT Image long)

Extracted rules inside block: NONE

## 7a9ee641ee146fd7 — visual-prompt-forge/references/prompt-anatomy.md:81-81 (list_item)

- Parameter syntax (`--ar 9:16` vs `aspect_ratio: "9:16"`)

Extracted rules inside block: NONE

## 285629f5556784e1 — visual-prompt-forge/references/prompt-anatomy.md:82-82 (list_item)

- Idiosyncratic strengths (Ideogram for text, Flux for photoreal, etc.)

Extracted rules inside block: NONE

## 757aaf88f8ac3545 — visual-prompt-forge/references/prompt-anatomy.md:84-84 (heading)

## How layers compose

Extracted rules inside block: NONE

## bcdb4129d2f7ddb9 — visual-prompt-forge/references/prompt-anatomy.md:86-86 (paragraph)

For a single shot's prompt:

Extracted rules inside block: NONE

## 687c050647f52a6b — visual-prompt-forge/references/prompt-anatomy.md:88-96 (code)

```
Layer 1 (brand) ───┐
                   │
Layer 2 (series) ──┼──> Layer 5 (adapter) ──> {generator-specific prompt}
                   │
Layer 3 (shot) ────┘

Layer 4 (text) ────> separate compositing pipeline
```

Extracted rules inside block: NONE

## bc218f8f1df3c378 — visual-prompt-forge/references/prompt-anatomy.md:98-98 (paragraph)

The adapter pulls from Layers 1–3 and produces a string. Layer 4 lives parallel and never enters the prompt.

Extracted rules inside block: 15db8f90d04d
