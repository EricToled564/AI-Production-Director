# Source coverage review 175/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 287ed263264b24c1 — video/references/seedance.md:29-29 (heading)

## 2. Versions and specs

Extracted rules inside block: NONE

## 520bd3a67b4310d1 — video/references/seedance.md:31-31 (list_item)

- Seedance 1.0 Pro. 1080p, 5-10s (API up to 12s). Strong multi-shot.

Extracted rules inside block: NONE

## 2a2685362a7e405f — video/references/seedance.md:32-32 (list_item)

- Seedance 1.0 Lite. 720p, faster, cheaper.

Extracted rules inside block: NONE

## e85be5b17080040f — video/references/seedance.md:33-33 (list_item)

- Seedance 1.5 Pro. Native audio and lip-sync added.

Extracted rules inside block: NONE

## 3ca4b246194b3c7f — video/references/seedance.md:34-34 (list_item)

- Seedance 2.0. Improved motion, better audio, 9 camera movement presets, limited negative prompt support, up to 12 reference inputs via `@` tags. Since June 2026: native 4K, 10-bit color. 2.0 Mini: ~2× faster, ~30% cheaper, for drafts and batches.

Extracted rules inside block: NONE

## d72439e939258bdf — video/references/seedance.md:35-35 (list_item)

- **Seedance 2.5** (released 2026-07-31). Native 30-second single-pass clip, up to 60s via extension, 30-180s in Ultra Long mode. 50 multimodal reference inputs (30 images + 10 video + 10 audio), video editing (partial re-render), 3D white-model camera blockout, realistic humans with multilingual lip-sync in 11 languages. **Full production reference: `seedance-25.md`.**

Extracted rules inside block: NONE

## 6310d64ec5094159 — video/references/seedance.md:37-39 (paragraph)

Resolutions. 480p, 720p, 1080p; 2.0 adds native 4K; 2.5 outputs 480p/720p on Jimeng.
Aspect ratios. 16:9, 4:3, 1:1, 3:4, 9:16, 21:9, 9:21.
Frame rate. 24-30 fps.

Extracted rules inside block: NONE

## 712112c121389810 — video/references/seedance.md:41-41 (paragraph)

**Model pick within the family:** one continuous 15-30s arc, heavy reference kits, editing/extension of existing footage → 2.5 (realistic humans and lip-sync are a 2.5 headline feature — the 2.0-era face caution below does not apply to it). People-centric drama on a 2.0-only pipeline → 1.5 Pro (2.0 aggressively filters human faces and celebrity-adjacent content after the 2026 deepfake crackdown). Scenes, architecture, product, montage in short clips → 2.0. Cheap drafts → 2.0 Mini, then re-render keepers high.

Extracted rules inside block: NONE

## ed3a95d3d8193a9c — video/references/seedance.md:43-43 (heading)

## 3. CLI parameters (1.x / 2.0 only)

Extracted rules inside block: NONE

## 14afc88d8577d5bf — video/references/seedance.md:45-45 (paragraph)

Append at the end of the prompt.

Extracted rules inside block: NONE

## 40b045ea360f766c — video/references/seedance.md:47-49 (code)

```text
--resolution 1080p --duration 5 --camerafixed false --seed 42
```

Extracted rules inside block: NONE

## 8ce1a09655bc32e3 — video/references/seedance.md:51-51 (list_item)

- `--resolution`. 480p | 720p | 1080p

Extracted rules inside block: NONE

## 97c179fdbbb97a0a — video/references/seedance.md:52-52 (list_item)

- `--duration`. 2 to 12 (Pro)

Extracted rules inside block: NONE

## 4b2187597f734101 — video/references/seedance.md:53-53 (list_item)

- `--camerafixed`. true locks the camera. false allows movement.

Extracted rules inside block: NONE

## 1188474440c450d2 — video/references/seedance.md:54-54 (list_item)

- `--seed`. for reproducibility

Extracted rules inside block: NONE

## 634b0c43cbfef07a — video/references/seedance.md:56-56 (paragraph)

**Not 2.5 syntax.** On 2.5, duration / aspect ratio / resolution are set on the generation page or via API and do not belong in the prompt (exception: Ultra Long mode restates duration and ratio at the top — see `seedance-25.md` §2).

Extracted rules inside block: 09d79f51231c

## 561204f62e991dcf — video/references/seedance.md:58-58 (heading)

## 4. The Details Law (read this first)

Extracted rules inside block: NONE

## ba61cdac684d83ac — video/references/seedance.md:60-60 (list_item)

> **Details intensify emotion. Laziness kills the prompt.**

Extracted rules inside block: NONE

## e1c01919aa141d59 — video/references/seedance.md:62-62 (paragraph)

Seedance does not render abstractions. It renders **physical specifics**. Every adjective must be a sensory fact. Every emotion must be a body. Every shot must own at least three concrete details:

Extracted rules inside block: a36b55b9399f

## 18a076d18416a880 — video/references/seedance.md:64-64 (list_item)

1. **One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC.

Extracted rules inside block: 1b863ac90568

## 8c8ab39648298e2f — video/references/seedance.md:65-65 (list_item)

2. **One physical micro-action.** Jaw locks. Finger taps the counter. Knuckles whiten on the fork. Lips press into a line. He swallows hard.

Extracted rules inside block: 438065b7a9ce

## bfc70888da090ef0 — video/references/seedance.md:66-66 (list_item)

3. **One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in the dark phone screen. Rain hitting the same windowpane.

Extracted rules inside block: 14093a76c83b

## f2927ca346bc5bf7 — video/references/seedance.md:68-68 (paragraph)

If a shot has none of these — it is filler. Delete it or rewrite it.

Extracted rules inside block: NONE

## b424c8210d18b8fd — video/references/seedance.md:70-70 (paragraph)

Banned, lazy phrasing that produces mush:

Extracted rules inside block: 25e7807f01f1

## e48c262e4f3f52b9 — video/references/seedance.md:71-71 (list_item)

- "cinematic, professional, high quality, masterpiece"

Extracted rules inside block: NONE

## 6a82f2861f78b91d — video/references/seedance.md:72-72 (list_item)

- "beautiful lighting"

Extracted rules inside block: NONE

## 64482a7428c3d5d3 — video/references/seedance.md:73-73 (list_item)

- "epic scene"

Extracted rules inside block: NONE

## f4687b73ab27541d — video/references/seedance.md:74-74 (list_item)

- "amazing visuals"

Extracted rules inside block: NONE

## feab67372a03ef9a — video/references/seedance.md:75-75 (list_item)

- "he is sad / he is angry" (with no physical translation)

Extracted rules inside block: NONE

## 54dde2168ac77c05 — video/references/seedance.md:77-77 (paragraph)

This rule is hard. Multi-shot prompts on Seedance fail not because of the model, but because the writer was lazy on a single shot. One thin shot drags the whole sequence down.

Extracted rules inside block: NONE
