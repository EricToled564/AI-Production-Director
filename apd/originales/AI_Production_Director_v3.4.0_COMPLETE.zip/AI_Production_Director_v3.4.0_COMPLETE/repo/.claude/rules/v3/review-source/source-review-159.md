# Source coverage review 159/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f360673c875b46d9 — video/references/patterns-and-genres.md:110-110 (heading)

### Race / speed

Extracted rules inside block: NONE

## 365e2a62ba8fbcb2 — video/references/patterns-and-genres.md:112-112 (paragraph)

Authentic velocity. Faceless detail-as-emotion. Cold combative palette.

Extracted rules inside block: NONE

## 775bee270b1c7488 — video/references/patterns-and-genres.md:114-114 (list_item)

- Style. Low bumper-height. Asphalt streaking in frame. Foreground reference objects passing. Hard light on metal/rubber/sweat. Beat-locked cutting that collapses toward the launch.

Extracted rules inside block: NONE

## 2bafb8e3a44e4915 — video/references/patterns-and-genres.md:115-115 (list_item)

- Tone. Threat, not glamour. Force transmission over shiny bodywork.

Extracted rules inside block: NONE

## 5b9aa2d89a0e5d41 — video/references/patterns-and-genres.md:116-116 (list_item)

- Pace. Silence-then-bang. Held ritual, exploding launch, dense contest, one held aftermath.

Extracted rules inside block: NONE

## 0fe8fde8244c0edd — video/references/patterns-and-genres.md:117-117 (list_item)

- For the full grammar (schools, start-line ritual, 5 shot families, drift adaptation, anti-fake guard) load `race-and-speed.md`; for turning it into still panels load `animatic-keyframes.md`.

Extracted rules inside block: NONE

## 0417685581d4b5ff — video/references/patterns-and-genres.md:119-119 (heading)

### Fashion

Extracted rules inside block: NONE

## 72062d048f1a9748 — video/references/patterns-and-genres.md:121-121 (paragraph)

Symmetric framing. Controlled palette. Repeated silhouettes.

Extracted rules inside block: NONE

## 0bd4a70a2c59ebcd — video/references/patterns-and-genres.md:123-123 (list_item)

- Style. Slow motion micro-beats. Macro fabric detail. Confident stillness. Rim light.

Extracted rules inside block: NONE

## 5b45dc46db31e0b4 — video/references/patterns-and-genres.md:124-124 (list_item)

- Tone. Assured. Sensual.

Extracted rules inside block: NONE

## 14fc984eb8dcc294 — video/references/patterns-and-genres.md:125-125 (list_item)

- Pace. Slow, intentional.

Extracted rules inside block: NONE

## 90ef109cfb2514e5 — video/references/patterns-and-genres.md:127-127 (heading)

### UGC / Social

Extracted rules inside block: NONE

## 84e82db69c5e2085 — video/references/patterns-and-genres.md:129-129 (paragraph)

Authentic. Vertical. Quick.

Extracted rules inside block: NONE

## 143f389e97826109 — video/references/patterns-and-genres.md:131-131 (list_item)

- Style. Handheld. Natural light. 9:16. Vertical compositions. Direct-to-camera gestures. Quick beats.

Extracted rules inside block: NONE

## 61c84dcc78877fd5 — video/references/patterns-and-genres.md:132-132 (list_item)

- Tone. Immediate. Casual. Urgent relevance.

Extracted rules inside block: NONE

## c4b6ac956f169525 — video/references/patterns-and-genres.md:133-133 (list_item)

- Pace. Rapid, thumbnail-readable.

Extracted rules inside block: NONE

## b249f44dad9ca617 — video/references/patterns-and-genres.md:137-137 (heading)

## 3. Multi-clip story structure

Extracted rules inside block: NONE

## ead456347800c6b6 — video/references/patterns-and-genres.md:139-139 (paragraph)

AI video generators have no memory between generations. Longer videos live in multiple clips stitched in the edit.

Extracted rules inside block: NONE

## 7e717a8e9626d8f5 — video/references/patterns-and-genres.md:141-141 (heading)

### Default splits

Extracted rules inside block: NONE

## 923d52b26dae042e — video/references/patterns-and-genres.md:143-143 (list_item)

- 10s. 2 clips x 5s

Extracted rules inside block: NONE

## 4d1aa5d339765138 — video/references/patterns-and-genres.md:144-144 (list_item)

- 15s. 3 clips x 5s

Extracted rules inside block: NONE

## d5034f02e4516c9e — video/references/patterns-and-genres.md:145-145 (list_item)

- 30s. 6 clips x 5s

Extracted rules inside block: NONE

## b1d079f055841094 — video/references/patterns-and-genres.md:146-146 (list_item)

- 45s. 9 clips x 5s

Extracted rules inside block: NONE

## 56a49a36274cc4bb — video/references/patterns-and-genres.md:147-147 (list_item)

- 60s. 12 clips x 5s

Extracted rules inside block: NONE

## 03f99b2109da3880 — video/references/patterns-and-genres.md:149-149 (paragraph)

Exception. Seedance multi-shot can pack 2-3 shots into a single 5-10s clip.

Extracted rules inside block: NONE

## a13d742b372c8b9c — video/references/patterns-and-genres.md:151-151 (heading)

### What every clip must repeat

Extracted rules inside block: NONE

## e4a1961028b351c8 — video/references/patterns-and-genres.md:153-153 (paragraph)

Every clip is self-contained. The model has no memory. Repeat this block in every clip.

Extracted rules inside block: NONE

## d2e9c00a1626992a — video/references/patterns-and-genres.md:155-155 (list_item)

- Character identity (face, hair, clothing, distinguishing marks)

Extracted rules inside block: NONE

## 9cfce5a36c43a4f6 — video/references/patterns-and-genres.md:156-156 (list_item)

- Clothing items, exactly named

Extracted rules inside block: NONE

## 5ee1761d60169cb4 — video/references/patterns-and-genres.md:157-157 (list_item)

- Location description

Extracted rules inside block: NONE
