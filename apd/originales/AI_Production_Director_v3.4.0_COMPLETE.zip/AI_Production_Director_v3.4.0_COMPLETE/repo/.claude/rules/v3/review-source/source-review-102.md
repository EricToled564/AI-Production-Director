# Source coverage review 102/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c992284b11453ab2 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:56-56 (list_item)

- 16:9, long-form, hero films, web embeds

Extracted rules inside block: NONE

## fd87b01eb95953e7 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:57-57 (list_item)

- 1:1, feed posts, podcast covers

Extracted rules inside block: NONE

## a0098890e36e430c — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:58-58 (list_item)

- 4:5. Instagram feed alternative

Extracted rules inside block: NONE

## 417e3f0bbc00ff8c — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:60-60 (heading)

## Color grade direction

Extracted rules inside block: NONE

## 6996d4add43fe460 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:62-62 (paragraph)

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

Extracted rules inside block: c1bba522f6a4

## 393291b5caead067 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:64-64 (heading)

## Motion language

Extracted rules inside block: NONE

## fee65b5e020b800b — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:66-66 (paragraph)

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

Extracted rules inside block: 7888cba625ef

## 1de7280c91964c68 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:68-68 (heading)

## Voice rules

Extracted rules inside block: NONE

## 6ed045d1d0afda57 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:70-70 (list_item)

- no em dashes

Extracted rules inside block: NONE

## fea268c5596b63f2 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:71-71 (list_item)

- no emojis in body copy

Extracted rules inside block: NONE

## 46525a304eda11c5 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:72-72 (list_item)

- no exclamation points in headlines

Extracted rules inside block: NONE

## 10a5c6fdac3f6924 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:73-73 (list_item)

- no hype words

Extracted rules inside block: NONE

## 240a08abb3c960a1 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:74-74 (list_item)

- prefer specific numbers over vague claims

Extracted rules inside block: 3af93a2dffdd

## f9290ac47fe84cae — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:75-75 (list_item)

- prefer present-tense over future-tense

Extracted rules inside block: 5b0daac77e37

## ec04c25efaac050b — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:76-76 (list_item)

- prefer "operator" over "creator", "infrastructure" over "agency"

Extracted rules inside block: c3bb383ba372

## 75edf175f7b78db9 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:80-82 (paragraph)

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0

Extracted rules inside block: NONE

## 9eb07959ec1be377 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:1-1 (heading)

# WhyStrohm. The Content Infrastructure Pitch

Extracted rules inside block: NONE

## f81fab03b59224c9 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:5-5 (table_row)

| **Duration** | 30s |

Extracted rules inside block: NONE

## dbdcd49c9c8c62da — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:6-6 (table_row)

| **Aspect** | 9:16 |

Extracted rules inside block: NONE

## 7f177228588c8a4e — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:7-7 (table_row)

| **Beat framework** | Pain-Reframe-Promise |

Extracted rules inside block: NONE

## 9c1bdebbdbedb711 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:8-8 (table_row)

| **Brand lock** | [`brand-lock.snapshot.md`](./brand-lock.snapshot.md) |

Extracted rules inside block: NONE

## 7762797857d4cf48 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:9-9 (table_row)

| **Generated** | 2026-05-07 14:23 UTC |

Extracted rules inside block: NONE

## d0d76f61f6d05337 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:13-13 (heading)

## Brief

Extracted rules inside block: NONE

## 065c4da4b8934ed0 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:15-15 (paragraph)

A 30-second founder explainer aimed at founders running content marketing themselves. The audience knows their content output is uneven and they're tired of the treadmill. The reframe is the WhyStrohm thesis: it's not a content problem, it's an infrastructure problem. The promise is the offer, 30 min/week of founder time, 48-hour cycle. The CTA is the free /scan diagnostic.

Extracted rules inside block: NONE

## bdfbedddd12bd6cc — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:17-17 (heading)

## Beat framework: Pain-Reframe-Promise

Extracted rules inside block: NONE

## 88606f48d3fad30a — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:19-19 (paragraph)

Standard PRP for conversion content. Three beats with hook and CTA bookending.

Extracted rules inside block: NONE

## e235c8122e173e41 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:21-21 (list_item)

- 0–2s. Hook

Extracted rules inside block: NONE

## e44784a9809d9df7 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:22-22 (list_item)

- 2–11s. Pain (extended for 30s, gives the problem space to breathe)

Extracted rules inside block: NONE

## 44cb87a8ec2002d0 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:23-23 (list_item)

- 11–20s. Reframe + Proof (the WhyStrohm thesis lands, then is shown)

Extracted rules inside block: NONE

## 7295267b456f88fd — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:24-24 (list_item)

- 20–26s. Promise (specific, time-bound)

Extracted rules inside block: NONE
