# Source coverage review 8/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2b1af817b47edeb8 — ai-video-storyboard/SKILL.md:94-94 (list_item)

6. **No model-specific hacks** — don't write prompts tuned to specific model quirks. Write model-agnostic cinematic prompts that work anywhere.

Extracted rules inside block: ba2667f6b54b

## ca866cecd26e9878 — ai-video-storyboard/SKILL.md:96-96 (heading)

### Step 5 — Add Narrative Structure

Extracted rules inside block: NONE

## b8e340f3f9500629 — ai-video-storyboard/SKILL.md:98-98 (paragraph)

The sequence of shots must have a **story arc**, not a random list. Use one of these patterns:

Extracted rules inside block: ef59bbdc7b5c

## 953fb34feaf62e2c — ai-video-storyboard/SKILL.md:100-100 (paragraph)

**Pattern A — Hook / Build / Payoff / CTA (TikTok default)**

Extracted rules inside block: NONE

## f6644a5633f1d039 — ai-video-storyboard/SKILL.md:101-101 (list_item)

- Shot 1: Visual hook (stop the scroll)

Extracted rules inside block: NONE

## 806e985eb853bd24 — ai-video-storyboard/SKILL.md:102-102 (list_item)

- Shot 2-3: Build context / intrigue

Extracted rules inside block: NONE

## d17deadbcf57f4e8 — ai-video-storyboard/SKILL.md:103-103 (list_item)

- Shot 4-5: Main content / payoff

Extracted rules inside block: NONE

## ec650948e382b2ab — ai-video-storyboard/SKILL.md:104-104 (list_item)

- Shot 6: CTA

Extracted rules inside block: NONE

## 8ae285b329ba91e5 — ai-video-storyboard/SKILL.md:106-106 (paragraph)

**Pattern B — Problem / Solution / Proof / CTA (Ad default)**

Extracted rules inside block: NONE

## 6e127c28ca203ae0 — ai-video-storyboard/SKILL.md:107-107 (list_item)

- Shots 1-2: Relatable problem

Extracted rules inside block: NONE

## 925dbfd3391a344b — ai-video-storyboard/SKILL.md:108-108 (list_item)

- Shot 3: Your product as solution

Extracted rules inside block: NONE

## 615e77bea4480ae5 — ai-video-storyboard/SKILL.md:109-109 (list_item)

- Shots 4-5: Benefits / results

Extracted rules inside block: NONE

## 4c4d0af0f8dabe04 — ai-video-storyboard/SKILL.md:110-110 (list_item)

- Shot 6: CTA

Extracted rules inside block: NONE

## bd801078e059b999 — ai-video-storyboard/SKILL.md:112-112 (paragraph)

**Pattern C — Atmosphere → Climax (Brand story)**

Extracted rules inside block: NONE

## d1012699198cc679 — ai-video-storyboard/SKILL.md:113-113 (list_item)

- Longer atmospheric shots

Extracted rules inside block: NONE

## f5f06f4600865a41 — ai-video-storyboard/SKILL.md:114-114 (list_item)

- Slow reveal

Extracted rules inside block: NONE

## 868745c5ac4ed427 — ai-video-storyboard/SKILL.md:115-115 (list_item)

- Emotional climax

Extracted rules inside block: NONE

## b44bc1d9155888c9 — ai-video-storyboard/SKILL.md:116-116 (list_item)

- Logo reveal

Extracted rules inside block: NONE

## 2b52ef8969c4bba5 — ai-video-storyboard/SKILL.md:118-118 (heading)

### Step 6 — Add Post-Production Checklist

Extracted rules inside block: NONE

## d734d56958ab8582 — ai-video-storyboard/SKILL.md:120-120 (paragraph)

Close with actionable post-production notes:

Extracted rules inside block: NONE

## 81c45e95edea91f5 — ai-video-storyboard/SKILL.md:122-131 (code)

```
## Post-Production Checklist
- [ ] Generate all N shots with your preferred AI video tool
- [ ] Stitch in [CapCut / Descript / DaVinci Resolve / Premiere]
- [ ] Apply [specific LUT or color grade] for consistency
- [ ] Add [transition type and duration] between shots
- [ ] Layer BGM: [genre / BPM / mood]
- [ ] Add text overlays for [hook / CTA / captions]
- [ ] Export [platform spec: 9:16 1080x1920 30fps for TikTok, etc.]
```

Extracted rules inside block: NONE

## 1461080fadf08d9e — ai-video-storyboard/SKILL.md:133-133 (heading)

### Step 7 — Explain Why It Works

Extracted rules inside block: NONE

## 030fb7d5c062b3d0 — ai-video-storyboard/SKILL.md:135-135 (paragraph)

Close with a "Why this works" block explaining the creative decisions. This educates the user and differentiates your output from generic prompt lists. Reference:

Extracted rules inside block: NONE

## 6cfbb56913a4b00d — ai-video-storyboard/SKILL.md:137-137 (list_item)

- The hook rule (first second determines watch-through)

Extracted rules inside block: NONE

## d64f5c9082c63434 — ai-video-storyboard/SKILL.md:138-138 (list_item)

- Pacing cadence (average scroll time)

Extracted rules inside block: NONE

## d64bb1adea367433 — ai-video-storyboard/SKILL.md:139-139 (list_item)

- Story structure (why the shot order matters)

Extracted rules inside block: NONE

## c72a26e627a570e7 — ai-video-storyboard/SKILL.md:140-140 (list_item)

- Platform-specific conventions

Extracted rules inside block: NONE

## aa0de0fa3c9d0e27 — ai-video-storyboard/SKILL.md:142-142 (heading)

## Output Format

Extracted rules inside block: NONE

## 1bbb4393b6e76301 — ai-video-storyboard/SKILL.md:144-144 (paragraph)

The final output is a single Markdown document containing:

Extracted rules inside block: NONE

## f26c2e1f961124db — ai-video-storyboard/SKILL.md:146-146 (list_item)

1. **Header** — Title, duration, shot count, aspect ratio

Extracted rules inside block: 5036a582db94
