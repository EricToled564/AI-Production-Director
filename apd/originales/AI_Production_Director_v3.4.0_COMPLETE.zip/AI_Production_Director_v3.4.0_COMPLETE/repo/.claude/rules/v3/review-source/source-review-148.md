# Source coverage review 148/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## bf7f35e895c6a5e8 — video/references/fixes-and-skeletons.md:60-60 (heading)

### Object disappears mid-scene

Extracted rules inside block: NONE

## f92d467ad1d7a96a — video/references/fixes-and-skeletons.md:62-62 (paragraph)

Fix.

Extracted rules inside block: NONE

## 350c1466547e30e7 — video/references/fixes-and-skeletons.md:64-66 (code)

```text
Track the object continuously. The same object remains visible or clearly implied in every beat.
```

Extracted rules inside block: NONE

## 1478cc046c7b241e — video/references/fixes-and-skeletons.md:68-68 (paragraph)

Describe the object's state progression in one sentence. "The sausage moves. fridge -> pot -> fork -> floor."

Extracted rules inside block: NONE

## 782c7854c1a98915 — video/references/fixes-and-skeletons.md:70-70 (heading)

### Weak drama. Scene feels flat.

Extracted rules inside block: NONE

## 6f97ad0e063d7319 — video/references/fixes-and-skeletons.md:72-72 (paragraph)

Fix.

Extracted rules inside block: NONE

## 6a171f545b0ad4a1 — video/references/fixes-and-skeletons.md:74-76 (code)

```text
Play the scene with full emotional seriousness. Treat the ordinary object as if it carries life-or-death meaning. No comedy pacing. No detached observation.
```

Extracted rules inside block: NONE

## 00215f1e6aeceda4 — video/references/fixes-and-skeletons.md:78-78 (heading)

### Messy random cuts in fast montage

Extracted rules inside block: NONE

## c3c9266e782d8288 — video/references/fixes-and-skeletons.md:80-80 (paragraph)

Fix.

Extracted rules inside block: NONE

## 9e2a8c086b99e107 — video/references/fixes-and-skeletons.md:82-84 (code)

```text
Use fast montage with clear readable action per cut. Every cut shows a distinct detail. face, hand, object, reaction, impact. Each cut must have a visible function.
```

Extracted rules inside block: NONE

## 6414c610c20f261e — video/references/fixes-and-skeletons.md:86-86 (heading)

### Dialogue too fast (Veo)

Extracted rules inside block: NONE

## acabaf15cb97744a — video/references/fixes-and-skeletons.md:88-88 (paragraph)

Fix. Cut the line. 8 seconds max of spoken text. Test by reading aloud at normal pace.

Extracted rules inside block: NONE

## c37d5a98dbf7b67a — video/references/fixes-and-skeletons.md:90-90 (heading)

### Melting hands / extra fingers

Extracted rules inside block: NONE

## ef6f423554940f82 — video/references/fixes-and-skeletons.md:92-92 (paragraph)

For Kling. Add to negative field.

Extracted rules inside block: NONE

## c606ff1e75f8e229 — video/references/fixes-and-skeletons.md:94-96 (code)

```text
distorted hands, extra fingers, melted face, deformed
```

Extracted rules inside block: NONE

## fb33eec31642dfb8 — video/references/fixes-and-skeletons.md:98-98 (paragraph)

For Seedance and Veo. Use positive phrasing.

Extracted rules inside block: b3b907639aff

## d5de587b57f07006 — video/references/fixes-and-skeletons.md:100-102 (code)

```text
anatomically correct hands, clean finger separation, realistic proportions
```

Extracted rules inside block: NONE

## ce05c6f2b7d37dd7 — video/references/fixes-and-skeletons.md:104-104 (heading)

### Lighting drifts between clips

Extracted rules inside block: NONE

## 89013c7fac544151 — video/references/fixes-and-skeletons.md:106-106 (paragraph)

Fix. Name the dominant source and direction and repeat it verbatim in every clip.

Extracted rules inside block: NONE

## 5c3c084268d2a7f9 — video/references/fixes-and-skeletons.md:108-110 (code)

```text
Lighting constant. Cold fridge light as key from frame-right. Warm window spill as rim from frame-left. Same contrast ratio in every shot.
```

Extracted rules inside block: NONE

## 129bc20d7df2767b — video/references/fixes-and-skeletons.md:112-112 (heading)

### Model ignores camera instruction

Extracted rules inside block: NONE

## 52b1f071b7ac768e — video/references/fixes-and-skeletons.md:114-114 (paragraph)

Fix. Move camera to the front of the prompt.

Extracted rules inside block: NONE

## 2af8ff943c30bc6e — video/references/fixes-and-skeletons.md:116-117 (paragraph)

Bad. "A man opens a fridge. The camera is a slow push-in."
Good. "Slow 50mm push-in. A man opens the fridge."

Extracted rules inside block: NONE

## 6c1a56c6b3e4ea12 — video/references/fixes-and-skeletons.md:119-119 (heading)

### Weird AI-looking faces

Extracted rules inside block: NONE

## 2685df4ec9d2264e — video/references/fixes-and-skeletons.md:121-121 (paragraph)

Fix. Avoid style words like "hyperrealistic 8k masterpiece." These push the model into AI-art territory. Use production language instead.

Extracted rules inside block: 9a918c5f8de1

## 0e439a9415140ac3 — video/references/fixes-and-skeletons.md:123-125 (code)

```text
Shot on 50mm, natural skin texture, motivated lighting, documentary feel.
```

Extracted rules inside block: NONE

## 2f87991ab1ef3394 — video/references/fixes-and-skeletons.md:127-127 (heading)

### Twins / face-blending in multi-person scenes

Extracted rules inside block: NONE

## 9e7bb4128e92b334 — video/references/fixes-and-skeletons.md:129-129 (paragraph)

Two or more characters converge into near-identical faces, or background extras clone the hero.

Extracted rules inside block: NONE

## 73481adba04bb0aa — video/references/fixes-and-skeletons.md:131-131 (paragraph)

Fix. Bind each subject to its own reference individually (see `universal-rules.md` U13), then force differentiation.

Extracted rules inside block: NONE

## 886ceee77d198a3f — video/references/fixes-and-skeletons.md:133-135 (code)

```text
Their movements are not synchronized. Clothing colors, hairstyles, and facial features must all be distinct. No identical clones in the background.
```

Extracted rules inside block: NONE
