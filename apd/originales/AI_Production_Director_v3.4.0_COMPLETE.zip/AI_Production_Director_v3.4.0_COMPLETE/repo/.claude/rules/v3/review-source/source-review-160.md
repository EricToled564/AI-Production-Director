# Source coverage review 160/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## ee7165338fb92679 — video/references/patterns-and-genres.md:158-158 (list_item)

- Visual style (palette, grade, reference)

Extracted rules inside block: NONE

## cccac622cb0c9628 — video/references/patterns-and-genres.md:159-159 (list_item)

- Camera language (dominant grammar of the whole piece)

Extracted rules inside block: NONE

## 6ce63ee589fc4299 — video/references/patterns-and-genres.md:160-160 (list_item)

- Lighting logic (dominant source and direction)

Extracted rules inside block: NONE

## 85b17d75202151f6 — video/references/patterns-and-genres.md:161-161 (list_item)

- Continuity rules (what must remain constant)

Extracted rules inside block: 5d1aa69765ea

## 209c05c61c93ad62 — video/references/patterns-and-genres.md:162-162 (list_item)

- Color palette with specific colors

Extracted rules inside block: NONE

## c14889298c0bc646 — video/references/patterns-and-genres.md:164-164 (paragraph)

Yes, every single clip. Yes, even if it feels repetitive. That repetition is the only thing keeping the output consistent.

Extracted rules inside block: NONE

## c208935a84578ccc — video/references/patterns-and-genres.md:166-166 (heading)

### Timecoded internal beats

Extracted rules inside block: NONE

## a180209964e58eaa — video/references/patterns-and-genres.md:168-168 (paragraph)

Inside each 5-second prompt, use timecodes.

Extracted rules inside block: a6d0370c2869

## 8dd371b5c10ce745 — video/references/patterns-and-genres.md:170-176 (code)

```text
0.0-0.8. [action / camera / light]
0.8-1.6. [action / camera / light]
1.6-2.5. [action / camera / light]
2.5-3.7. [action / camera / light]
3.7-5.0. [action / camera / light]
```

Extracted rules inside block: NONE

## 40b905efa26e9587 — video/references/patterns-and-genres.md:178-178 (paragraph)

Density by genre.

Extracted rules inside block: NONE

## e8350a578d02a6cf — video/references/patterns-and-genres.md:180-180 (list_item)

- Emotional drama. 3-4 beats per 5s. Longer reactions.

Extracted rules inside block: NONE

## 911c03a3db0c3643 — video/references/patterns-and-genres.md:181-181 (list_item)

- Standard narrative. 4-7 beats per 5s.

Extracted rules inside block: NONE

## acdded942b865208 — video/references/patterns-and-genres.md:182-182 (list_item)

- Fast montage / music video. 6-9 beats per 5s.

Extracted rules inside block: NONE

## 06d1725e94ffad6e — video/references/patterns-and-genres.md:184-184 (paragraph)

Use timecoded structure for Seedance and Veo. Kling prefers flowing prose.

Extracted rules inside block: 1d78f512ab7f

## 752bec100d21bf16 — video/references/patterns-and-genres.md:186-186 (heading)

### Continuity across clips

Extracted rules inside block: NONE

## e8103303b47a0ecf — video/references/patterns-and-genres.md:188-188 (paragraph)

When moving from clip N to clip N+1, the first beat of the new clip should match the final beat of the previous clip. Character in same pose. Same light. Same color temperature. This is what makes them cut together cleanly in the editor.

Extracted rules inside block: 5f1096a6bc0d

## 780b6951300abbce — video/references/patterns-and-genres.md:190-190 (paragraph)

Example. Clip 1 ends on him reaching into the fridge. Clip 2 opens on his hand inside the fridge at the same height and light.

Extracted rules inside block: NONE

## 70eb9d1c432e81d4 — video/references/patterns-and-genres.md:194-194 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 9faad0dded04e61d — video/references/race-and-speed.md:1-1 (heading)

# Race, speed and faceless kinetic montage

Extracted rules inside block: NONE

## f829daf42904e7ca — video/references/race-and-speed.md:3-3 (paragraph)

Domain grammar for dynamic race spots — drag, drift, chase, drag-strip, kinetic montage. The brief is brutal: faces are banned, the deliverable is **still keyframes (opornye kadry)** for an animatic, and a frozen panel must read as lethal velocity at a glance. Speed is not a post effect — it is a photographic fact built from spatial cues that imply the missing motion. Emotion does not live on a face; it rides on metal, rubber, road, gauges and light. Load this file when the task involves racing, drift, drag, chase, speed, dynamic or kinetic montage, "гонщик", or "раскадровка гонки".

Extracted rules inside block: 3aaaa73dcb0a

## fe9830f42e32de34 — video/references/race-and-speed.md:5-5 (paragraph)

This file **specializes `animatic-keyframes.md` for the race domain.** That file owns the general still-panel method and is the prerequisite read: the keyframe card, the **six motion-as-still cues** (§4), the **5-cue speed budget** (§4), the **EMOTION→OBJECT substitution table** and state-change cheat-sheet (§5), the loaded-frame depth method (§6), the **density ladder** (§3), the **keyframe→image-gen prompt skeleton** (§7), the worked 30s board (§8), and the **master per-panel checklist** (§9). This file does **not** repeat them — it adds the race grammar on top: the schools, the start-line liturgy, the shot families, the drift ritual, the Christmas-Tree light logic, and the cold-combat palette. Where the method is general, this file points; where it is race-specific, it teaches.

Extracted rules inside block: NONE

## 427ba2132b54b2ad — video/references/race-and-speed.md:7-7 (paragraph)

Sits on top of `dramaturgy.md` (§2 Details Law, §3 fantik, §9 environment, §11 shot card, §12 rhythm ladder, §15 check), `universal-rules.md` (U1–U12), `role-modes.md` §4 (shot-function taxonomy). Pairs with `camera-lighting-vocabulary.md` for framing/lens/light tokens, `patterns-and-genres.md` for the action/escalation arc, and `seedance.md` / `kling.md` / `veo.md` to animate each locked keyframe.

Extracted rules inside block: NONE

## c58f41405f7c1298 — video/references/race-and-speed.md:9-9 (heading)

## Contents

Extracted rules inside block: NONE

## 9acd88f259e7e41a — video/references/race-and-speed.md:11-11 (list_item)

1. Core laws (the non-negotiables)

Extracted rules inside block: 83cd10e38b27

## 365a2f1c58b7f4c9 — video/references/race-and-speed.md:12-12 (list_item)

2. Four schools worth stealing

Extracted rules inside block: e828cb662e75

## 4b03959435aed71a — video/references/race-and-speed.md:13-13 (list_item)

3. Selling speed in a single frame

Extracted rules inside block: 86ee205e3648

## c4565446369d3a97 — video/references/race-and-speed.md:14-14 (list_item)

4. Storytelling without faces — the race captioning system

Extracted rules inside block: 4e9596c11d1e

## 60e5c020f46294f9 — video/references/race-and-speed.md:15-15 (list_item)

5. The race ritual (liturgy) + the 5 shot families

Extracted rules inside block: 044b01261c9e

## d7f6833b46b2825a — video/references/race-and-speed.md:16-16 (list_item)

6. Camera grammar for speed

Extracted rules inside block: ce2415266e7d

## 30c4ac1b0229bd50 — video/references/race-and-speed.md:17-17 (list_item)

7. Light & color for speed without faces

Extracted rules inside block: 8758f5a1932d
