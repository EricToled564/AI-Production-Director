# Source coverage review 23/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## dbf41f4da9106370 — brand-lock-extractor/brand-packs/_template.md:6-6 (heading)

## Identity

Extracted rules inside block: NONE

## c0b0381648f36e76 — brand-lock-extractor/brand-packs/_template.md:8-11 (paragraph)

**Brand:** {{BRAND_NAME}}
**One-line description:** What this brand actually does, who for.
**Archetype:** Operator / Creator / Sage / Rebel / Caregiver / Other
**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative

Extracted rules inside block: NONE

## b83e17ce1ebed0d5 — brand-lock-extractor/brand-packs/_template.md:13-13 (heading)

## Palette

Extracted rules inside block: NONE

## a6fdc40b693f8480 — brand-lock-extractor/brand-packs/_template.md:15-15 (paragraph)

Every hex value here is allowed. Anything outside this list is not.

Extracted rules inside block: NONE

## 35a3af442cadbff4 — brand-lock-extractor/brand-packs/_template.md:17-17 (table_row)

| Role | Hex | Use |

Extracted rules inside block: 035e44d5794b

## 15d735f13cd48405 — brand-lock-extractor/brand-packs/_template.md:19-19 (table_row)

| Background | `#______` | Primary canvas |

Extracted rules inside block: NONE

## 462189158f40da9a — brand-lock-extractor/brand-packs/_template.md:20-20 (table_row)

| Ink | `#______` | Primary text, dark elements |

Extracted rules inside block: NONE

## f4ef54708f872e80 — brand-lock-extractor/brand-packs/_template.md:21-21 (table_row)

| Accent | `#______` | Highlights, CTAs, brand pop |

Extracted rules inside block: NONE

## 93c49b2f3cdf9ac1 — brand-lock-extractor/brand-packs/_template.md:22-22 (table_row)

| Muted | `#______` | Secondary text, captions |

Extracted rules inside block: NONE

## 0f81114e6a7edf55 — brand-lock-extractor/brand-packs/_template.md:23-23 (table_row)

| Rule | `#______` | Borders, dividers, subtle UI |

Extracted rules inside block: NONE

## ee549fff246e2acc — brand-lock-extractor/brand-packs/_template.md:25-25 (paragraph)

Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.

Extracted rules inside block: e12b6c2a6277

## 453c34ac799fdb46 — brand-lock-extractor/brand-packs/_template.md:27-27 (heading)

## Typography

Extracted rules inside block: NONE

## 92a1ef5317cf6470 — brand-lock-extractor/brand-packs/_template.md:29-31 (paragraph)

**Display font:** `______`
**Body font:** `______`
**Mono font (optional):** `______`

Extracted rules inside block: NONE

## 52487f926acc2231 — brand-lock-extractor/brand-packs/_template.md:33-35 (paragraph)

Put the font name and weight in backticks immediately after the label, e.g.
`` **Display font:** `Inter Black 900`, headlines and hooks ``. The HTML preview and
the overlay-font check read that backticked value; anything before it is prose.

Extracted rules inside block: NONE

## 4f445103d40985ec — brand-lock-extractor/brand-packs/_template.md:37-37 (paragraph)

Two fonts max for production work. Three only if one is reserved for code/data.

Extracted rules inside block: NONE

## 54b508115cf7b59b — brand-lock-extractor/brand-packs/_template.md:39-39 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## 0e79a1424f5e91a3 — brand-lock-extractor/brand-packs/_template.md:41-41 (paragraph)

Pick 3–5. These flow into prompts as the brand's emotional posture.

Extracted rules inside block: NONE

## a7acc622eef706c1 — brand-lock-extractor/brand-packs/_template.md:43-43 (list_item)

- adjective_1

Extracted rules inside block: NONE

## fc4c6f0fbec2d1ed — brand-lock-extractor/brand-packs/_template.md:44-44 (list_item)

- adjective_2

Extracted rules inside block: NONE

## 11764d5b36c96de7 — brand-lock-extractor/brand-packs/_template.md:45-45 (list_item)

- adjective_3

Extracted rules inside block: NONE

## 80acddfdda962911 — brand-lock-extractor/brand-packs/_template.md:47-47 (heading)

## Never list

Extracted rules inside block: NONE

## bd48fd469b74df80 — brand-lock-extractor/brand-packs/_template.md:49-49 (paragraph)

What this brand never does, visually or tonally. Be specific.

Extracted rules inside block: c8b1e667f806

## d2ac81e3a677c9a9 — brand-lock-extractor/brand-packs/_template.md:51-51 (list_item)

- never use stock photo aesthetic

Extracted rules inside block: 5899a276b08f

## b54cbc4db44d3c24 — brand-lock-extractor/brand-packs/_template.md:52-52 (list_item)

- never use AI uncanny faces

Extracted rules inside block: c8855e3ad412

## 30b335519e7d69be — brand-lock-extractor/brand-packs/_template.md:53-53 (list_item)

- never over-saturate

Extracted rules inside block: 892dc09a58db

## 8c3b764ec6af3e8e — brand-lock-extractor/brand-packs/_template.md:54-54 (list_item)

- never shout in copy

Extracted rules inside block: e71e5baec3de

## 945259bb9f1e670f — brand-lock-extractor/brand-packs/_template.md:55-55 (list_item)

- never use clip-art icons

Extracted rules inside block: 17c0a050ea13

## 2d8993139eb25a63 — brand-lock-extractor/brand-packs/_template.md:56-56 (list_item)

- (add more, the more specific, the better)

Extracted rules inside block: NONE

## 598cf2686e68e1e0 — brand-lock-extractor/brand-packs/_template.md:58-58 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## b787175d476629a1 — brand-lock-extractor/brand-packs/_template.md:60-60 (paragraph)

Default: 16:9 / 9:16 / 1:1 / 4:5 / other

Extracted rules inside block: NONE
