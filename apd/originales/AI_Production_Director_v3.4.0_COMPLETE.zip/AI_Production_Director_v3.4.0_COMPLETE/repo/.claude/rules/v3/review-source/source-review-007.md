# Source coverage review 7/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## cd7cd1de8afc2612 — ai-video-storyboard/SKILL.md:36-36 (list_item)

5. **Any hard constraints?** (must include logo, specific colors, locations, etc.)

Extracted rules inside block: 755080cbffc4

## 903c7ddabdd335bc — ai-video-storyboard/SKILL.md:38-38 (paragraph)

If user already provided some of these, skip those questions and confirm the rest.

Extracted rules inside block: NONE

## 5d7048b4e70bff31 — ai-video-storyboard/SKILL.md:40-40 (heading)

### Step 2 — Infer Structure

Extracted rules inside block: NONE

## 4502ee10fbf76bfd — ai-video-storyboard/SKILL.md:42-42 (paragraph)

Based on duration and platform, divide the timeline into shots of ~5 seconds each (the sweet spot for AI video generators).

Extracted rules inside block: NONE

## 9fc6f56a9b3fe1eb — ai-video-storyboard/SKILL.md:44-44 (paragraph)

**Standard cadences:**

Extracted rules inside block: NONE

## e3e3aec6e02fb244 — ai-video-storyboard/SKILL.md:46-46 (table_row)

| Platform | Duration | Shots | Pacing |

Extracted rules inside block: NONE

## 519a15e312413379 — ai-video-storyboard/SKILL.md:48-48 (table_row)

| TikTok Hook | 15s | 3 | Fast cuts, single idea |

Extracted rules inside block: NONE

## d4e42d982138203f — ai-video-storyboard/SKILL.md:49-49 (table_row)

| TikTok Reel | 30s | 6 | Hook → Build → Payoff → CTA |

Extracted rules inside block: NONE

## b86643250bea09d0 — ai-video-storyboard/SKILL.md:50-50 (table_row)

| Instagram Ad | 15s | 3 | Hook → Product → CTA |

Extracted rules inside block: NONE

## 85f8f140be9a1abf — ai-video-storyboard/SKILL.md:51-51 (table_row)

| Instagram Ad | 30s | 6 | Hook → Problem → Product → Benefit → Social proof → CTA |

Extracted rules inside block: NONE

## ffa980c5923d9654 — ai-video-storyboard/SKILL.md:52-52 (table_row)

| YouTube Short | 60s | 12 | Hook → 3-act structure → CTA |

Extracted rules inside block: NONE

## 9946d563d6822118 — ai-video-storyboard/SKILL.md:53-53 (table_row)

| Product Explainer | 90s | 18 | Problem → Solution → How it works → Results → CTA |

Extracted rules inside block: NONE

## b1eacaf98c9edb3e — ai-video-storyboard/SKILL.md:54-54 (table_row)

| Brand Story | 60s | 10-12 | Atmosphere-driven, longer shot holds |

Extracted rules inside block: NONE

## 2eb8776b2bac4d42 — ai-video-storyboard/SKILL.md:56-56 (heading)

### Step 3 — Establish Visual Consistency Layer

Extracted rules inside block: NONE

## 0d39d2d1ad4c6783 — ai-video-storyboard/SKILL.md:58-58 (paragraph)

Before writing any shot, lock in the shared visual language. This is what makes shots edit together:

Extracted rules inside block: NONE

## 8ab9764ff6f11369 — ai-video-storyboard/SKILL.md:60-60 (list_item)

- **Color palette** (3-5 specific hex values or named colors)

Extracted rules inside block: NONE

## e3443c519e837076 — ai-video-storyboard/SKILL.md:61-61 (list_item)

- **Lighting style** (golden hour / neon / overcast / motivated / cinematic rim light)

Extracted rules inside block: NONE

## 95e7236296f9086a — ai-video-storyboard/SKILL.md:62-62 (list_item)

- **Lens character** (shallow DOF / deep focus / wide angle distortion / macro)

Extracted rules inside block: 68e23996ad0c

## d322d3a5a8acb9cc — ai-video-storyboard/SKILL.md:63-63 (list_item)

- **Film look** (clean digital / 16mm grain / anamorphic / VHS / 35mm)

Extracted rules inside block: NONE

## a8f8b146ed041e07 — ai-video-storyboard/SKILL.md:64-64 (list_item)

- **Motion language** (handheld / locked off / dolly only / gimbal smooth)

Extracted rules inside block: NONE

## 38972aead893dcfc — ai-video-storyboard/SKILL.md:66-66 (paragraph)

Write these as a **Visual Theme** block at the top of the output. Every shot's prompt must respect this block.

Extracted rules inside block: 401cc3c8e0a4

## fd951fc43d814b33 — ai-video-storyboard/SKILL.md:68-68 (heading)

### Step 4 — Write Each Shot

Extracted rules inside block: NONE

## 8604ae99ffb78390 — ai-video-storyboard/SKILL.md:70-70 (paragraph)

For each shot, produce this structure:

Extracted rules inside block: NONE

## 3aef60483405ee46 — ai-video-storyboard/SKILL.md:72-85 (code)

```
## Shot N (START-ENDs) — [Purpose label: Hook / Setting / Action / Detail / Reveal / CTA]

**Composition:** [shot type + angle, e.g., "Extreme close-up, overhead"]
**Camera move:** [locked / slow dolly in / tracking / crane up / etc.]
**Lighting:** [from the Visual Theme, applied to this scene]
**Subject:** [what is in frame]
**Action:** [what is happening]

**Prompt to copy:**
> [Complete, cinematic-quality prompt, 40-80 words, including: subject + action + environment + camera + lighting + style + technical spec (duration, aspect ratio, resolution). Always ends with "cinematic 1080p, synchronized audio"]

**Audio direction:** [what the synchronized audio should sound like — ambient sounds, music beat position, voice-over line]
```

Extracted rules inside block: NONE

## 167736eb9bfdfa62 — ai-video-storyboard/SKILL.md:87-87 (paragraph)

**Critical rules for shot prompts:**

Extracted rules inside block: NONE

## e1e1e55bbaeca559 — ai-video-storyboard/SKILL.md:89-89 (list_item)

1. **Always specify the shared visual language** in every prompt (color palette, lighting, lens character, film look). This is how you enforce consistency.

Extracted rules inside block: 9115162f73b5

## 2964b46d660c63ee — ai-video-storyboard/SKILL.md:90-90 (list_item)

2. **Specify exact duration** (4s / 5s / 8s) and **aspect ratio** (9:16 for TikTok/Reels, 16:9 for YouTube landscape, 1:1 for feed posts).

Extracted rules inside block: 981c492e0983

## e35cd078900e6e02 — ai-video-storyboard/SKILL.md:91-91 (list_item)

3. **Always end with "cinematic 1080p, synchronized audio"** — this signals professional-grade quality and works with modern video models that support both.

Extracted rules inside block: 6fd7717508c0

## 1cf2c771efb80bbb — ai-video-storyboard/SKILL.md:92-92 (list_item)

4. **Use cinematography vocabulary**: ECU (extreme close-up), CU, MS (medium shot), WS (wide shot), OTS (over-the-shoulder), POV, Dutch angle, low angle, high angle, bird's eye, dolly in, dolly out, tracking, handheld, rack focus, etc.

Extracted rules inside block: 080057ecd662

## 4067a6b2313b8863 — ai-video-storyboard/SKILL.md:93-93 (list_item)

5. **Don't write abstract prompts** — be concrete. "A woman" → "A barista in her late 20s with wavy auburn hair, wearing a denim apron".

Extracted rules inside block: 222a248ff488
