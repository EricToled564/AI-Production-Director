# Source coverage review 64/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 927965c580a3fbc8 — image/references/prompt-framework.md:30-30 (list_item)

- **Контекст** - для чего это (определяет стиль)

Extracted rules inside block: NONE

## 71ccfe497dd31280 — image/references/prompt-framework.md:32-32 (paragraph)

**По ситуации:**

Extracted rules inside block: NONE

## 8d5be01399e9cb8c — image/references/prompt-framework.md:33-33 (list_item)

- **Действие** - что происходит

Extracted rules inside block: NONE

## 097c9e5c025b676f — image/references/prompt-framework.md:34-34 (list_item)

- **Окружение** - где это происходит

Extracted rules inside block: NONE

## b34ffaf14e9a19c9 — image/references/prompt-framework.md:35-35 (list_item)

- **Камера** - крупность плана (close-up, wide shot, etc.)

Extracted rules inside block: NONE

## fe03b7b4ca6d4002 — image/references/prompt-framework.md:36-36 (list_item)

- **Освещение** - тип света

Extracted rules inside block: NONE

## 2f757654b04498a8 — image/references/prompt-framework.md:37-37 (list_item)

- **Настроение** - эмоция сцены

Extracted rules inside block: NONE

## a6edf4e4158ccac7 — image/references/prompt-framework.md:38-38 (list_item)

- **Материалы** - текстуры поверхностей

Extracted rules inside block: NONE

## 9953fbebd4f8659e — image/references/prompt-framework.md:39-39 (list_item)

- **Палитра** - цвета (лучше hex)

Extracted rules inside block: c8e5cf64bb6e

## 8ad99244555c5c1e — image/references/prompt-framework.md:40-40 (list_item)

- **Формат** - соотношение сторон

Extracted rules inside block: NONE

## aeb99684752fee31 — image/references/prompt-framework.md:42-42 (list_item)

> ⚠️ **Параметры объектива** (50mm, 85mm, f/2.8, ISO):

Extracted rules inside block: NONE

## a9296183d8619c98 — image/references/prompt-framework.md:43-43 (list_item)

> - **Nano Banana** — игнорит числа, пиши описательно («shallow depth of field»)

Extracted rules inside block: ce4d6933ae5d

## 4b739ed2cc18d16f — image/references/prompt-framework.md:44-44 (list_item)

> - **GPT Image 2** — допускает «50mm feel» как high-level look, но не как точную физическую симуляцию

Extracted rules inside block: NONE

## 8d05026b93583354 — image/references/prompt-framework.md:46-46 (heading)

## Detail Modes (Режимы)

Extracted rules inside block: NONE

## 75d94ed90582cbef — image/references/prompt-framework.md:48-48 (paragraph)

**Concise** - одно предложение, для быстрых итераций:

Extracted rules inside block: NONE

## 33adb904527ba2a3 — image/references/prompt-framework.md:49-51 (code)

```
Minimalist poster: white background, single red apple, centered, dramatic shadow.
```

Extracted rules inside block: NONE

## 5028a4fa076c14ed — image/references/prompt-framework.md:53-53 (paragraph)

**Standard** - 1-2 параграфа, баланс контроля и гибкости:

Extracted rules inside block: NONE

## 14d4ebed017dc149 — image/references/prompt-framework.md:54-60 (code)

```
Create a product shot for premium headphones marketing.

Matte black headphones on dark slate surface. Single spotlight from upper left creates dramatic shadow. Background gradient from #1a1a1a to pure black.

Format: 16:9
```

Extracted rules inside block: NONE

## b01c623d5b321cfe — image/references/prompt-framework.md:62-62 (paragraph)

**Verbose** - максимум деталей для сложных сцен:

Extracted rules inside block: NONE

## 1b1ac746321d3384 — image/references/prompt-framework.md:63-75 (code)

```
Create a cinematic wide shot for sci-fi film concept art.

Setting: Abandoned space station observation deck. Massive curved window spans entire wall, revealing dying red giant star filling half the frame. Station interior in deep shadow except where crimson light bleeds through.

Subject: Lone astronaut in weathered EVA suit, helmet off, sitting on debris pile. Back to camera, facing the star. Pose suggests exhaustion and acceptance.

Atmosphere: Dust particles float in zero-g, catching red light. Abandoned equipment scattered - coffee cup frozen mid-float, papers suspended. Frost crystals on interior surfaces where life support failed.

Mood: Melancholic beauty, end of an era
Lighting: Volumetric god rays from star through window
Format: 2.39:1 cinemascope
```

Extracted rules inside block: NONE

## 6928e70c509ed593 — image/references/prompt-framework.md:77-77 (heading)

## Output Structure

Extracted rules inside block: NONE

## 956f341eb7adbc71 — image/references/prompt-framework.md:79-79 (paragraph)

При создании промпта выдавай:

Extracted rules inside block: NONE

## 72b3a1fad5ba5a88 — image/references/prompt-framework.md:81-81 (paragraph)

**1. Prompt** - готовый к использованию

Extracted rules inside block: NONE

## debf3b089f52831e — image/references/prompt-framework.md:83-83 (paragraph)

**2. Parameters** - если нестандартные:

Extracted rules inside block: NONE

## 1009618547694188 — image/references/prompt-framework.md:84-84 (list_item)

- Aspect ratio (если не 1:1)

Extracted rules inside block: NONE

## ddcc43596f2a260d — image/references/prompt-framework.md:85-85 (list_item)

- Resolution (если нужно 2K/4K)

Extracted rules inside block: NONE

## d5c8804ee03191ba — image/references/prompt-framework.md:87-88 (paragraph)

**3. Exclusions** - что исключить (опционально):
> Формулируй позитивно! NBP лучше понимает "clean background" чем "no clutter"

Extracted rules inside block: c70e0b3c59b3

## cfb4fba1f5bdd3a7 — image/references/prompt-framework.md:90-90 (paragraph)

**4. Assumptions** - что додумано, если пользователь не указал

Extracted rules inside block: NONE

## 607720f42858f2de — image/references/prompt-framework.md:92-92 (heading)

## Quick Decision Tree

Extracted rules inside block: NONE

## 904272637616d9ee — image/references/prompt-framework.md:94-105 (code)

```
Что создаём?
├── Фото реального объекта/человека → Photorealistic
├── Рисунок/арт → Illustration  
├── Товар для продажи → Product/Commercial
├── Много пустого места → Minimalist
├── Несколько кадров/история → Sequential
├── Меняем существующее фото → Editing
├── "Как на этой картинке" → Style Transfer
├── Собираем из нескольких элементов → Composite
└── Текст - главный элемент → Text Rendering
```

Extracted rules inside block: NONE
