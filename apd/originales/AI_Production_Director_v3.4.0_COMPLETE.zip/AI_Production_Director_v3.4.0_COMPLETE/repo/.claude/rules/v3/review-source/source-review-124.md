# Source coverage review 124/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 02d580668079d634 — storyboard-html-preview/SKILL.md:281-281 (heading)

## Examples

Extracted rules inside block: NONE

## c2db27fd4acdb488 — storyboard-html-preview/SKILL.md:283-283 (paragraph)

Generated `preview.html` files ship next to the storyboards that produced them:

Extracted rules inside block: NONE

## d929091ff0a37ea6 — storyboard-html-preview/SKILL.md:285-285 (list_item)

- `../storyboard-architect/examples/30s-pain-proof-promise/preview.html`

Extracted rules inside block: NONE

## 587cce26fb529a12 — storyboard-html-preview/SKILL.md:286-286 (list_item)

- `../storyboard-architect/examples/60s-founder-explainer/preview.html`

Extracted rules inside block: NONE

## da21fd0e8f6807e3 — storyboard-html-preview/SKILL.md:287-288 (list_item)

- `../storyboard-architect/examples/shotkit-explainer/preview.html`, including the
  two-overlay shot

Extracted rules inside block: NONE

## 656dd826d23e9ce1 — storyboard-html-preview/SKILL.md:289-289 (list_item)

- `../visual-asset-critic/examples/worked-run/preview.html`, with frames and verdict badges

Extracted rules inside block: NONE

## 6fab63e693975e50 — storyboard-html-preview/SKILL.md:291-293 (paragraph)

Open them in a browser to calibrate quality. All four are re-rendered in CI with pinned
timestamps and the build fails if the output moves, so they are also the regression test for
this skill's output.

Extracted rules inside block: NONE

## 59144154a83bf947 — storyboard-html-preview/tools/README.md:1-1 (heading)

# Tools

Extracted rules inside block: NONE

## 474533136fb4705f — storyboard-html-preview/tools/README.md:3-4 (paragraph)

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

Extracted rules inside block: NONE

## d10eb2dec68e94b2 — storyboard-html-preview/tools/README.md:6-6 (heading)

## Requirements

Extracted rules inside block: NONE

## 52d1c4e316bf1015 — storyboard-html-preview/tools/README.md:8-10 (code)

```bash
pip install pyyaml jsonschema
```

Extracted rules inside block: NONE

## dc5123787c084785 — storyboard-html-preview/tools/README.md:12-12 (paragraph)

Standard library otherwise. No pandas, no numpy.

Extracted rules inside block: NONE

## e72429d3b600cd04 — storyboard-html-preview/tools/README.md:14-14 (heading)

## Run everything

Extracted rules inside block: NONE

## e1da56d38b989c49 — storyboard-html-preview/tools/README.md:16-20 (code)

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

Extracted rules inside block: NONE

## 3eb2e5aefb3a06c9 — storyboard-html-preview/tools/README.md:22-22 (paragraph)

This is exactly what CI runs, so a green local run means a green PR.

Extracted rules inside block: NONE

## 8aa0345e6715bc7d — storyboard-html-preview/tools/README.md:24-26 (paragraph)

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

Extracted rules inside block: NONE

## 50bdfaf7a753bbb8 — storyboard-html-preview/tools/README.md:28-28 (heading)

## Repo checks

Extracted rules inside block: NONE

## e3da4953e5bdb4b5 — storyboard-html-preview/tools/README.md:30-30 (heading)

### `validate_skills.py`

Extracted rules inside block: NONE

## e5a5a5b7a54af93c — storyboard-html-preview/tools/README.md:32-33 (paragraph)

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

Extracted rules inside block: 0814f76188eb

## 0d2bab39bdadbfb8 — storyboard-html-preview/tools/README.md:35-37 (code)

```bash
python tools/validate_skills.py
```

Extracted rules inside block: NONE

## ced320b37f6081a2 — storyboard-html-preview/tools/README.md:39-39 (heading)

### `validate_schemas.py`

Extracted rules inside block: NONE

## 1a8a5a81b8063da1 — storyboard-html-preview/tools/README.md:41-42 (paragraph)

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

Extracted rules inside block: NONE

## 43c8f4d7a431d3ab — storyboard-html-preview/tools/README.md:44-46 (code)

```bash
python tools/validate_schemas.py
```

Extracted rules inside block: NONE

## 27642292573e4749 — storyboard-html-preview/tools/README.md:48-48 (paragraph)

It validates schemas, not instances. For instances, see `validate_shots.py`.

Extracted rules inside block: NONE

## cde402cc91d0135b — storyboard-html-preview/tools/README.md:50-50 (heading)

### `validate_capabilities.py`

Extracted rules inside block: NONE

## 95cf2fedbf7ae500 — storyboard-html-preview/tools/README.md:52-54 (paragraph)

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

Extracted rules inside block: NONE

## 7a5cc86f16222343 — storyboard-html-preview/tools/README.md:56-56 (list_item)

- every generator id has an adapter `.md` and every adapter `.md` has an entry

Extracted rules inside block: NONE

## 12f98958635362c1 — storyboard-html-preview/tools/README.md:57-57 (list_item)

- no adapter advertises more words than its own `max_prompt_words` ceiling

Extracted rules inside block: NONE

## 0b1f9720445a0096 — storyboard-html-preview/tools/README.md:58-58 (list_item)

- every adapter documents the `aspect_param` the matrix says to send

Extracted rules inside block: NONE

## b927cbdef3525770 — storyboard-html-preview/tools/README.md:59-59 (list_item)

- no `notes` field cites a word count above its own ceiling

Extracted rules inside block: NONE
