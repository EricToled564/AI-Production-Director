# Source coverage review 166/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 12c86a884d388c30 — video/references/role-modes.md:29-29 (list_item)

- Why does the camera move?

Extracted rules inside block: NONE

## 8cfadfcaaa33b801 — video/references/role-modes.md:30-30 (list_item)

- Why does the cut happen here?

Extracted rules inside block: NONE

## fdbc66cc6fccaeed — video/references/role-modes.md:32-32 (heading)

### Output format. Director treatment

Extracted rules inside block: NONE

## a1dbd2402c4597f4 — video/references/role-modes.md:34-43 (code)

```text
Core idea. [one sentence, the point of the piece]
Emotional arc. [start -> middle -> end, three emotion states]
Visual motif. [one recurring visual element]
Rhythm. [pace logic. slow build, rapid montage, still + sudden burst]
Camera language. [dominant grammar. handheld intimacy, locked precision, gliding observer]
Lighting. [dominant source and direction]
Sound. [texture. ambient layers, music role, silence moments]
Ending image. [final frame in one sentence]
```

Extracted rules inside block: NONE

## 008a080b1b033c9a — video/references/role-modes.md:45-45 (heading)

### Style references

Extracted rules inside block: NONE

## f7293721f5efe3b4 — video/references/role-modes.md:47-47 (paragraph)

Use one dominant director reference per scene. Translate into concrete camera, light, rhythm, blocking. Never stack three or more references.

Extracted rules inside block: 9b13cc686999

## 6a9ed3ecf2b16453 — video/references/role-modes.md:49-49 (list_item)

- Fincher. Precise motivated camera. No handheld drift. Cold palette.

Extracted rules inside block: NONE

## 6e531123cb205569 — video/references/role-modes.md:50-50 (list_item)

- Kurosawa. Weather as emotional pressure. Rain, wind, heat.

Extracted rules inside block: NONE

## 821612b36413b2e0 — video/references/role-modes.md:51-51 (list_item)

- Spielberg. Readable staging. Clear geography. Emotional wide shots.

Extracted rules inside block: NONE

## d20ca7777ecd2a99 — video/references/role-modes.md:52-52 (list_item)

- Edgar Wright. Sound-driven montage. Match cuts on sound events.

Extracted rules inside block: NONE

## a7be62da3866bfa4 — video/references/role-modes.md:53-53 (list_item)

- Jonathan Glazer. Music-video visual idea translated to drama.

Extracted rules inside block: NONE

## dc888de989e7ab6d — video/references/role-modes.md:54-54 (list_item)

- Wong Kar-wai. Longing. Reflections. Slow emotional drift.

Extracted rules inside block: NONE

## 2df90bcce8defe1a — video/references/role-modes.md:55-55 (list_item)

- Safdie. Anxiety. Handheld pressure. Overlapping sound.

Extracted rules inside block: NONE

## ff92e2c4704dce7c — video/references/role-modes.md:56-56 (list_item)

- Wes Anderson. Symmetry. Controlled blocking. Color blocks.

Extracted rules inside block: NONE

## d16e42eb477b7ea0 — video/references/role-modes.md:60-60 (heading)

## 2. Screenwriter mode

Extracted rules inside block: NONE

## f1d7d664ef354cef — video/references/role-modes.md:62-62 (heading)

### Trigger

Extracted rules inside block: NONE

## 04f85969472dddfe — video/references/role-modes.md:64-64 (paragraph)

User asks to "напиши сценарий", "разбей на биты", "придумай диалог", "адаптируй историю в видео", "нужен story arc."

Extracted rules inside block: NONE

## 85b2b7d1e7c0594a — video/references/role-modes.md:66-66 (heading)

### Mindset

Extracted rules inside block: NONE

## 1afcc76704becb05 — video/references/role-modes.md:68-68 (paragraph)

Translate every beat into physical action the camera can see. Tag each beat with a shot function (see section 4). Every beat must have subtext.

Extracted rules inside block: 4d798e8705a5

## f6347af1b5985e02 — video/references/role-modes.md:70-70 (heading)

### Output format. Beat breakdown

Extracted rules inside block: NONE

## 257bc0891ad88e2f — video/references/role-modes.md:72-77 (code)

```text
Beat 1. [function] - [physical action]. Subtext. [what it means].
Beat 2. [function] - [physical action]. Subtext. [what it means].
...
Final image. [what the viewer takes with them].
```

Extracted rules inside block: NONE

## 679f886352c889ff — video/references/role-modes.md:79-79 (heading)

### Dialogue format (for Veo specifically)

Extracted rules inside block: NONE

## 5d93bcddbb85c4d1 — video/references/role-modes.md:81-81 (paragraph)

Write spoken lines in ready-to-paste Veo syntax.

Extracted rules inside block: NONE

## 051d951290382483 — video/references/role-modes.md:83-85 (code)

```text
He says, in a flat exhausted voice, "We are fine. We are fine."
```

Extracted rules inside block: NONE

## 6530152105124c49 — video/references/role-modes.md:87-87 (paragraph)

Cut lines until they fit 8 seconds of natural speech.

Extracted rules inside block: NONE

## ad05bbc8d8b9d61f — video/references/role-modes.md:89-89 (heading)

### Internal monologue rule

Extracted rules inside block: NONE

## f3a509f2917ee5a4 — video/references/role-modes.md:91-91 (paragraph)

Veo cannot render internal monologue. Translate into visible bodily signal.

Extracted rules inside block: NONE

## bc4c71c60b9024d5 — video/references/role-modes.md:93-94 (paragraph)

Bad. "He is thinking about his father."
Good. "He stops mid-motion. His eyes drift off-axis. He swallows. He resumes."

Extracted rules inside block: NONE

## a044984168bb84e1 — video/references/role-modes.md:98-98 (heading)

## 3. Editor mode

Extracted rules inside block: NONE

## 7ce9eef43cf14b6e — video/references/role-modes.md:100-100 (heading)

### Trigger

Extracted rules inside block: NONE
