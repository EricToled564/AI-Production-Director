# Source coverage review 130/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 8e303c6131a6eea1 — video/references/animatic-keyframes.md:87-87 (heading)

## 4. Composing a still that reads as MOTION

Extracted rules inside block: NONE

## b3232bbae9b66e01 — video/references/animatic-keyframes.md:89-89 (paragraph)

A keyframe cannot ramp, cut, or whip. Each missing move resolves into one of **six frozen cues**. Never write "motion" — write the artifact motion leaves behind. State the cue in the card's *Motion-as-still* field and again in the prompt's camera/light clause; models default to over-clean stabilization and will sand the speed off unless told (§7).

Extracted rules inside block: c6f3eefbfcb5

## 5bdf379bde5363a9 — video/references/animatic-keyframes.md:91-91 (table_row)

| Cue | What it is in a still | Renders the implied move |

Extracted rules inside block: NONE

## 9f1258c2aecdada2 — video/references/animatic-keyframes.md:93-93 (table_row)

| **Directional motion-blur smear** | Background streaked along the travel axis, subject sharp. Guardrail, lane stripes, tree lamps pulled into horizontal light-rods. | tracking pass, POV launch, the whip-pan aftermath |

Extracted rules inside block: NONE

## c31a8ce6b4c955f9 — video/references/animatic-keyframes.md:94-94 (table_row)

| **Frozen partial blur** | One moving element blurred (tyre sidewall, smoke bloom, shift hand mid-throw) while the anchor stays crisp — proof of a single arrested instant. | speed-ramp peak, launch, shift |

Extracted rules inside block: NONE

## 9a55c4a282902cd7 — video/references/animatic-keyframes.md:95-95 (table_row)

| **Streak-frame (implied whip)** | The whole panel raked into motion-streaks with one readable shape surviving (a wheel arc, the shifter) — a "between two shots" blur panel. | whip pan, transition beat |

Extracted rules inside block: NONE

## 76fdeb9afc766798 — video/references/animatic-keyframes.md:96-96 (table_row)

| **Posture / trajectory vector** | A body or car locked in a pose that can only resolve forward — wrist cocked over the shifter, front wheels lifting, weight slung onto the rear axle. The eye finishes the move. | charged pose, freeze frame, launch |

Extracted rules inside block: NONE

## 6f69a4f94dfb66f2 — video/references/animatic-keyframes.md:97-97 (table_row)

| **Sharp-subject / blurred-field separation** | Shallow-DOF macro: knuckle, needle, latch razor-sharp, everything else dissolved. Isolation = the cut-to-detail frozen. | insert chain, crash-zoom arrival, hip-hop CU |

Extracted rules inside block: 7c93611f93b4

## de10e3dc7ae1db9b — video/references/animatic-keyframes.md:98-98 (table_row)

| **Freeze-frame stillness** | Deliberately *zero* blur, hard edges, held breath — reads as a stopped clock against the blurred panels around it. | the pre-launch held beat, the loaded spring |

Extracted rules inside block: NONE

## 2ef74141fcd155b0 — video/references/animatic-keyframes.md:100-100 (paragraph)

Per-technique kit (triad + the still application):

Extracted rules inside block: NONE

## 1b559155cc0604b4 — video/references/animatic-keyframes.md:102-102 (list_item)

- **Frozen motion blur** — what it does to emotion: differential blur reads as velocity made tactile, the world torn past a steady subject — where seen: Dod Mantle whip-panned every overtake in *Rush* so the background dissolves. — *in a keyframe* [Shift/Impact]: hero car tack-sharp, entire background raked into horizontal streaks, foreground objects elongated into light-rods. The most powerful single-panel speed trick: **sharp hero + fully smeared world.** Equal blur everywhere = soft photo; differential blur = speed.

Extracted rules inside block: NONE

## e5bb23109cbb3df8 — video/references/animatic-keyframes.md:103-103 (list_item)

- **Tyre wrinkle / partial blur** — emotion: physics you can feel, force arrested at its peak — seen: Goodyear's deliberately silent slow-mo of the slick sidewall folding; Ritchie's speed-ramp as the exclamation mark. — *in a keyframe* [Detail/Reaction]: macro into the rear sidewall, the wrinkle caught at its deepest fold, smoke just blooming at the contact patch, everything else crisp. One arrested ten-thousandth of a second. The hero detail to *hold*.

Extracted rules inside block: NONE

## e0eb4aa1d9c25989 — video/references/animatic-keyframes.md:104-104 (list_item)

- **Smoke / debris / spray shape** — emotion: force given a visible body, dread made airborne — seen: NHRA burnout-cam, "a wall of smoke" backlit at ground level. — *in a keyframe* [Pressure/Power]: backlit tyre smoke as a luminous wall (front-lit smoke is dead gray nothing); water-box spray frozen as a constellation of specular droplets, each rimmed on its leading edge. Atmosphere only reads when light passes through it (§5).

Extracted rules inside block: NONE

## a2156260301befb5 — video/references/animatic-keyframes.md:105-105 (list_item)

- **Posture / lean vector** — emotion: a stillness that can only resolve forward; the eye does the launching — seen: Vaughn's charged poses (*Kingsman*, *Layer Cake*) — every frame loaded with a trajectory. — *in a keyframe* [Power/Shift]: **no neutral panels.** Car at idle = front wheels micro-lifting, body slung onto the rear axle. Hand on wheel = fingers mid-clench. Compose the negative space *ahead* of the subject, the direction it is about to fire into.

Extracted rules inside block: NONE

## 37dbf5d60094f740 — video/references/animatic-keyframes.md:106-106 (list_item)

- **Leading lines / light streak** — emotion: a rail for the eye that also encodes direction and speed — seen: Papamichael's asphalt-in-frame (*Ford v Ferrari*), the road as the speedometer. — *in a keyframe* [Power/Impact]: lane centerline raking to a vanishing point, sodium/mercury practicals smeared as long reflections down wet asphalt. Keep the texture (chevrons, tar seams, rubber marks) so the streak has something to streak.

Extracted rules inside block: NONE

## f5882d84610d18d2 — video/references/animatic-keyframes.md:107-107 (list_item)

- **Off-balance dutch** — emotion: imbalance, loss of grip, threat — seen: Raimi's canted attack frames (*Evil Dead II*). — *in a keyframe* [Impact]: cant the horizon hard at the one loss-of-traction beat — tyre breaking away, car stepping sideways. Reserve it for a single instability beat so it stays loud; dutch as wallpaper reads as bad framing.

Extracted rules inside block: NONE

## 84a6ef678032768d — video/references/animatic-keyframes.md:109-109 (paragraph)

**The speed-budget rule** (from the race-truth school): a still sells velocity when **at least three of five coexist in one frame** — (a) camera at/below bumper height, (b) asphalt streaking the lower frame, (c) a near foreground reference passing the edge, (d) sharp hero against motion-blurred background, (e) a mechanical-vibration cue (trembling mirror, doubled needle, smeared rim). One cue is a car photo. Three is velocity. If a "fast" panel cannot name three, reframe lower, drag the camera to the asphalt, throw a cone or barrier into the foreground.

Extracted rules inside block: NONE

## fbfafcc245b3bcc5 — video/references/animatic-keyframes.md:113-113 (heading)

## 5. Emotion without faces in a still

Extracted rules inside block: NONE

## 84227a48eb347dfa — video/references/animatic-keyframes.md:115-115 (paragraph)

A face does four jobs: shows the feeling, shows where it looks, shows the cost, shows the decision. Faces banned, redistribute: **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space** (§6 and `dramaturgy.md` §2). Assign one job per panel and tag it. The emotion must already be frozen *inside the object* — a still cannot let motion blur do the emotional work for it.

Extracted rules inside block: c5bfac276e64

## 7e6473584e4c0f6d — video/references/animatic-keyframes.md:117-117 (paragraph)

Two load-bearing rules:

Extracted rules inside block: NONE

## e66065c43f9f31c5 — video/references/animatic-keyframes.md:119-119 (list_item)

- **Anatomy only on a decision.** A hand at rest is filler; a hand *deciding* is a shot. Before drawing any hand/foot panel, name the verb — grip / latch / shift / preload / release. No verb, no panel. Render tendons raised, glove leather creasing, one hard side-light carving knuckle texture, the rest in shadow (Leone's hands-before-the-draw; Nike *Take It to the Next Level*, first-person, no hero face).

Extracted rules inside block: NONE

## e974a1735dbe51cd — video/references/animatic-keyframes.md:120-120 (list_item)

- **Objects only when they change state.** A static gear-lever says "car stuff" and flatlines. Board the **after** state of a threshold-crossing; the before is implied (Honda *Cog*: every object does something irreversible). Tach pinned in the red, not idling. Ignition lamp blooming live, not dark. Slick caught mid-fold.

Extracted rules inside block: NONE

## 9ab855b18c2bec34 — video/references/animatic-keyframes.md:122-122 (paragraph)

Use the substitution table as the core deliverable — when the script wants an emotion and no face is available, render this object at this crop. Cold palette throughout.

Extracted rules inside block: 6d159be1c0d1

## 43d836bf0f42d6bf — video/references/animatic-keyframes.md:124-124 (table_row)

| Emotion (a face would show) | Object substitute | Crop | Render note (the still) | Label / tag |

Extracted rules inside block: NONE

## 124da8235e820db0 — video/references/animatic-keyframes.md:126-126 (table_row)

| **Fear / dread** | sweat bead on knuckle; tremor in the mirror reflection (not eyes) | macro / ECU | one hard specular highlight on the bead, cold rim, deep black around it; mirror edge doubled to imply vibration | setup → Pressure |

Extracted rules inside block: NONE

## a20f624157922409 — video/references/animatic-keyframes.md:127-127 (table_row)

| **Resolve / commitment** | knuckles whitening on wheel or shifter; foot pinning throttle | CU / MCU | tendons raised, glove leather creasing, grip at maximum; one side-light, cabin in shadow | commitment → Shift |

Extracted rules inside block: NONE

## 003af9dbf52fa846 — video/references/animatic-keyframes.md:128-128 (table_row)

| **Focus / lock-in** | start-lights reflected in lacquer / headlight glass (not a human eye) | MCU | staging bulbs mirrored as cold points on paint or chrome; tight, centered, still | setup → Detail |

Extracted rules inside block: NONE

## 95924ca04eef6f9f — video/references/animatic-keyframes.md:129-129 (table_row)

| **Strain (machine at limit)** | tach needle pinned in red arc; slick sidewall wrinkling; exhaust flame | ECU / CU | needle hard against redline, motion-still but unmistakably max; sidewall at deepest fold | proof-of-speed → Pressure |

Extracted rules inside block: NONE

## 0aab30329d521cfc — video/references/animatic-keyframes.md:130-130 (table_row)

| **Mistake / panic** | tyre shake (sidewall "goes square"), wheel kicking back, revs over-flared | CU | sidewall deformed wrong, blur direction fighting the lane; tach spiked past the band | mistake → Impact |

Extracted rules inside block: NONE

## bbd9ec2e63b996a5 — video/references/animatic-keyframes.md:131-131 (table_row)

| **Triumph / release** | grip relaxing; chute blooming; one nose past the stripe; smoke through headlight beams | CU → WS | fingers unfurling off the wheel; or distant clean geometry of the win, cold backlight through smoke | result → Aftermath / Exit |

Extracted rules inside block: NONE
