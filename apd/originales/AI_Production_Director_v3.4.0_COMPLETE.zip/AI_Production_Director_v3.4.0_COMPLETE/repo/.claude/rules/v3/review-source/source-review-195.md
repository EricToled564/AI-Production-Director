# Source coverage review 195/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## b88dc08ee7fc0c0f — visual-asset-critic/tools/README.md:76-82 (code)

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

Extracted rules inside block: NONE

## 2aad504fb6a42886 — visual-asset-critic/tools/README.md:84-86 (paragraph)

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

Extracted rules inside block: 6c90ae89af76

## 4b0f4fb63e3bad2a — visual-asset-critic/tools/README.md:88-88 (heading)

## Project checks

Extracted rules inside block: NONE

## 08f20591506de940 — visual-asset-critic/tools/README.md:90-90 (paragraph)

These run against a project's output directory, not the repo.

Extracted rules inside block: NONE

## 64b25a53dd4b5b46 — visual-asset-critic/tools/README.md:92-92 (heading)

### `validate_shots.py`

Extracted rules inside block: NONE

## 67906dc9aae86fbf — visual-asset-critic/tools/README.md:94-98 (paragraph)

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

Extracted rules inside block: NONE

## c97dbc55d9850494 — visual-asset-critic/tools/README.md:100-105 (code)

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Extracted rules inside block: NONE

## 500c9b799dce6505 — visual-asset-critic/tools/README.md:107-108 (paragraph)

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

Extracted rules inside block: NONE

## 00dc7b0ec73cea5d — visual-asset-critic/tools/README.md:110-110 (heading)

### `validate_prompts.py`

Extracted rules inside block: NONE

## 874534e906c26547 — visual-asset-critic/tools/README.md:112-116 (paragraph)

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

Extracted rules inside block: NONE

## 49f4db132af5427c — visual-asset-critic/tools/README.md:118-123 (code)

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

Extracted rules inside block: NONE

## 4983a2b4367f44f1 — visual-asset-critic/tools/README.md:125-129 (paragraph)

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

Extracted rules inside block: NONE

## eaf5fc5725af2379 — visual-asset-critic/tools/README.md:131-132 (paragraph)

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

Extracted rules inside block: NONE

## fdea347d356df38b — visual-asset-critic/tools/README.md:134-134 (heading)

### `validate_critique.py`

Extracted rules inside block: NONE

## 5136c9da0569fb6d — visual-asset-critic/tools/README.md:136-137 (paragraph)

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

Extracted rules inside block: NONE

## 03e1f4f50ae53d47 — visual-asset-critic/tools/README.md:139-140 (paragraph)

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

Extracted rules inside block: NONE

## 615407b51add4a7a — visual-asset-critic/tools/README.md:142-144 (paragraph)

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

Extracted rules inside block: 8d72bc4279f2

## ab89a631cf4a7792 — visual-asset-critic/tools/README.md:146-151 (code)

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Extracted rules inside block: NONE

## 7e5c198c8c05caef — visual-asset-critic/tools/README.md:153-154 (paragraph)

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

Extracted rules inside block: NONE

## a44b9e03ae4d0397 — visual-asset-critic/tools/README.md:156-156 (heading)

### `validate_provenance.py`

Extracted rules inside block: NONE

## f0a99db55466dc50 — visual-asset-critic/tools/README.md:158-159 (paragraph)

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

Extracted rules inside block: NONE

## 41205c0228d5a7ad — visual-asset-critic/tools/README.md:161-166 (code)

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

Extracted rules inside block: NONE

## f675ed4a4d9ff3e1 — visual-asset-critic/tools/README.md:168-168 (paragraph)

It catches, with a selftest for each:

Extracted rules inside block: NONE

## 2e235af818533ec8 — visual-asset-critic/tools/README.md:170-170 (list_item)

- a frame regenerated after its critique (`image_sha256` no longer matches)

Extracted rules inside block: NONE

## 9f817dadfa48e804 — visual-asset-critic/tools/README.md:171-171 (list_item)

- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)

Extracted rules inside block: NONE

## 025129b1fe2eba47 — visual-asset-critic/tools/README.md:172-172 (list_item)

- a frame on disk with no critique for its round, never reviewed at all

Extracted rules inside block: cd20eddcd98e

## 7ab1bb187b2d656c — visual-asset-critic/tools/README.md:173-173 (list_item)

- two critiques for the same shot in the same round, two operators colliding

Extracted rules inside block: NONE

## 553ea4f1ef35ab82 — visual-asset-critic/tools/README.md:174-174 (list_item)

- rounds that skip a number, or a critique whose `run_id` belongs to another run

Extracted rules inside block: NONE

## 265a03f3ffbccfb0 — visual-asset-critic/tools/README.md:176-177 (paragraph)

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

Extracted rules inside block: NONE

## d9dd5c74e8d33c54 — visual-asset-critic/tools/README.md:179-179 (heading)

## Rendering

Extracted rules inside block: NONE
