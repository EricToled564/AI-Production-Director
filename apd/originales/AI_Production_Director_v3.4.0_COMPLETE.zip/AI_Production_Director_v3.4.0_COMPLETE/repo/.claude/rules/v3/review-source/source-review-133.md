# Source coverage review 133/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 226db3858071e65a — video/references/camera-lighting-vocabulary.md:8-8 (list_item)

2. Camera movement

Extracted rules inside block: 5c3e03321fa0

## 01098fd3e98c9c83 — video/references/camera-lighting-vocabulary.md:9-9 (list_item)

3. Lens language

Extracted rules inside block: 957ceed645fa

## 17bbc796affd1c90 — video/references/camera-lighting-vocabulary.md:10-10 (list_item)

4. Light sources

Extracted rules inside block: 89f544625d1a

## f3d69ac8d2355b14 — video/references/camera-lighting-vocabulary.md:11-11 (list_item)

5. Light direction

Extracted rules inside block: 34173409a1d1

## 7c959521d3ed93b9 — video/references/camera-lighting-vocabulary.md:12-12 (list_item)

6. Light quality

Extracted rules inside block: 007e8995e64b

## a846f1ea1b182ed3 — video/references/camera-lighting-vocabulary.md:13-13 (list_item)

7. Color discipline

Extracted rules inside block: 7cdd52709bc2

## 79471e4b295bc2f4 — video/references/camera-lighting-vocabulary.md:14-14 (list_item)

8. Sound categories

Extracted rules inside block: f06f964ce392

## b8426ce30a332d61 — video/references/camera-lighting-vocabulary.md:15-15 (list_item)

9. Blocking language

Extracted rules inside block: 54bc1eb81fdf

## 4b6b429f7d12dd8c — video/references/camera-lighting-vocabulary.md:16-16 (list_item)

10. Translating uncommon terms

Extracted rules inside block: cccb8ca7a598

## 80862a60db297a3b — video/references/camera-lighting-vocabulary.md:17-17 (list_item)

11. Transition vocabulary

Extracted rules inside block: aaf8974dd19b

## 086cd2f89ef7d21f — video/references/camera-lighting-vocabulary.md:21-21 (heading)

## 1. Framing

Extracted rules inside block: NONE

## b19a9cb7deb00350 — video/references/camera-lighting-vocabulary.md:23-23 (list_item)

- extreme wide shot

Extracted rules inside block: NONE

## e2886d6b2414b2d9 — video/references/camera-lighting-vocabulary.md:24-24 (list_item)

- wide shot

Extracted rules inside block: NONE

## fcd1925a86af1da0 — video/references/camera-lighting-vocabulary.md:25-25 (list_item)

- medium wide

Extracted rules inside block: NONE

## 71a95011f8b42a5b — video/references/camera-lighting-vocabulary.md:26-26 (list_item)

- medium shot

Extracted rules inside block: NONE

## 7798f1b6343374f7 — video/references/camera-lighting-vocabulary.md:27-27 (list_item)

- medium close-up

Extracted rules inside block: NONE

## 29988caa0bfe8d79 — video/references/camera-lighting-vocabulary.md:28-28 (list_item)

- close-up

Extracted rules inside block: NONE

## 77f5a0861ee64e1f — video/references/camera-lighting-vocabulary.md:29-29 (list_item)

- extreme close-up

Extracted rules inside block: NONE

## 5cccff291c77bf9d — video/references/camera-lighting-vocabulary.md:30-30 (list_item)

- macro insert

Extracted rules inside block: NONE

## 6f8731a5c33babbc — video/references/camera-lighting-vocabulary.md:31-31 (list_item)

- over-the-shoulder

Extracted rules inside block: 9d79a9d36df8

## a4d2138273b4d30c — video/references/camera-lighting-vocabulary.md:32-32 (list_item)

- POV

Extracted rules inside block: NONE

## af97b504dd8cbd86 — video/references/camera-lighting-vocabulary.md:33-33 (list_item)

- profile

Extracted rules inside block: NONE

## 9fa15f203de3356a — video/references/camera-lighting-vocabulary.md:34-34 (list_item)

- silhouette

Extracted rules inside block: NONE

## df5c2a1a47f1f71d — video/references/camera-lighting-vocabulary.md:35-35 (list_item)

- low angle

Extracted rules inside block: NONE

## d6a20d2eeee4dbe9 — video/references/camera-lighting-vocabulary.md:36-36 (list_item)

- high angle

Extracted rules inside block: NONE

## 44fde3ac7f14c6a7 — video/references/camera-lighting-vocabulary.md:37-37 (list_item)

- top-down

Extracted rules inside block: NONE

## 6992f37f9a796391 — video/references/camera-lighting-vocabulary.md:38-38 (list_item)

- dutch angle

Extracted rules inside block: NONE

## 5f991dde2359f02e — video/references/camera-lighting-vocabulary.md:39-39 (list_item)

- locked-off frame

Extracted rules inside block: NONE

## e44f9291c24e4f39 — video/references/camera-lighting-vocabulary.md:41-41 (heading)

## 2. Camera movement

Extracted rules inside block: NONE

## 1ea6929219c0e451 — video/references/camera-lighting-vocabulary.md:43-43 (list_item)

- static camera

Extracted rules inside block: NONE
