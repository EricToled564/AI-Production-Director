# Source coverage review 110/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2f6b99b127505af7 — storyboard-architect/examples/shotkit-explainer/storyboard.md:14-14 (list_item)

> exactly the kind of drift this repo exists to prevent. See `CHANGELOG.md` for the adapter

Extracted rules inside block: NONE

## f2726398dacf19bf — storyboard-architect/examples/shotkit-explainer/storyboard.md:15-15 (list_item)

> change.

Extracted rules inside block: NONE

## 141b371820cd14a5 — storyboard-architect/examples/shotkit-explainer/storyboard.md:17-17 (heading)

## Brief

Extracted rules inside block: NONE

## 97118edc1f15b175 — storyboard-architect/examples/shotkit-explainer/storyboard.md:19-19 (paragraph)

90-second explainer for shotkit. Targets founder-led brands at $500K to $5M ARR who run their own content and feel the prompt-engineering tax. Walks through the diagnosis (vague brief plus model-roulette equals brand drift), the methodology (five-layer prompt anatomy), the build moment (brief in, files out), the proof (rendered preview from a real shotkit run), and the install command. Lives at the top of the shotkit blog post on whystrohm.com.

Extracted rules inside block: NONE

## 2afc6e6c4a995f60 — storyboard-architect/examples/shotkit-explainer/storyboard.md:21-21 (heading)

## Series lock

Extracted rules inside block: NONE

## 1eb8ba7c9c83f25f — storyboard-architect/examples/shotkit-explainer/storyboard.md:23-23 (table_row)

| Field | Value |

Extracted rules inside block: NONE

## 307ec7095cf2aaed — storyboard-architect/examples/shotkit-explainer/storyboard.md:25-25 (table_row)

| **Character** | No human subject. Typography-driven explainer with document-control aesthetic. |

Extracted rules inside block: NONE

## 9337d549fabd9681 — storyboard-architect/examples/shotkit-explainer/storyboard.md:26-26 (table_row)

| **Environment** | Operator-grade dashboard. Cream canvas, JetBrains Mono headers, Inter body, single coral accent per beat. |

Extracted rules inside block: NONE

## df953605b07b441d — storyboard-architect/examples/shotkit-explainer/storyboard.md:27-27 (table_row)

| **Lighting** | Even diffuse. No shadow rolloff. Flat operator-doc grading throughout. |

Extracted rules inside block: NONE

## 51e94ef3c2f98dfc — storyboard-architect/examples/shotkit-explainer/storyboard.md:28-28 (table_row)

| **Color grade** | Cream highlights (#F5F0E8), ink shadows (#2A2A32), coral (#D94F3A) reserved for signature beats. No saturation drift. |

Extracted rules inside block: NONE

## 7a08fb746010688b — storyboard-architect/examples/shotkit-explainer/storyboard.md:30-30 (heading)

## Shots

Extracted rules inside block: NONE

## aaf1bbbac51b30c5 — storyboard-architect/examples/shotkit-explainer/storyboard.md:32-32 (heading)

### shot_01: 0.0 to 12.0s. WS. eye-level. static.

Extracted rules inside block: NONE

## 67323e13d24127f6 — storyboard-architect/examples/shotkit-explainer/storyboard.md:34-36 (paragraph)

**Beat:** pain. **Subject:** vague founder brief types into the left panel in JetBrains Mono. Cursor blinks. Then a chaos cut shows four image generators producing slightly off-brand outputs in a 2x2 grid. Each tile renders the same shot with a different palette, framing, font.
**On-screen text:** "You don't have a content problem. You have a pre-production problem." (Inter Black 900, center, fade)
**Rationale:** Cold open names the failure mode every founder recognizes. Vague brief plus model-roulette equals brand drift. The 2x2 grid does the work text cannot.

Extracted rules inside block: 190fa55ff4ac

## 484f76e46fe9724c — storyboard-architect/examples/shotkit-explainer/storyboard.md:38-38 (heading)

### shot_02: 12.0 to 30.0s. MS. eye-level. static.

Extracted rules inside block: NONE

## caa28729795b2c8e — storyboard-architect/examples/shotkit-explainer/storyboard.md:40-42 (paragraph)

**Beat:** reframe. **Subject:** Five horizontal layers stack from top to bottom. Each labeled in JetBrains Mono caps with 0.08em letter-spacing: brand lock, series lock, shot spec, text layer, generator adapter. Each layer slides in from below on a 6-frame stagger. Coral dot lands on brand lock as it appears.
**On-screen text:** "Five layers. Locked top to bottom." (Inter Black 900, upper-third, type-on)
**Rationale:** Architecture beat. The reader needs to see the layers exist before any claim about composability lands. Stack layout is the diagram doing the explanation.

Extracted rules inside block: NONE

## 954f8beb7510e0e3 — storyboard-architect/examples/shotkit-explainer/storyboard.md:44-44 (heading)

### shot_03: 30.0 to 50.0s. MS. eye-level. push.

Extracted rules inside block: NONE

## 17e406cc077a8687 — storyboard-architect/examples/shotkit-explainer/storyboard.md:46-48 (paragraph)

**Beat:** proof-1. **Subject:** Split panel. Left BRIEF column types out a brief slowly. Right OUTPUT column starts empty with a pulsing waiting dot, then file tree assembles row by row in JetBrains Mono Regular 16pt. storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md, prompts/ directory with seven adapter files, preview.html. Coral dot lands on preview.html on completion.
**On-screen text:** "Brief in. Storyboard out. Audit trail included." (Inter Medium 500, upper-third, fade)
**Rationale:** The build moment is the centerpiece. Brief in, structured files out. Same animation language as the social demo so brand consistency reads across both surfaces.

Extracted rules inside block: NONE

## e6b3a9a45eb0c290 — storyboard-architect/examples/shotkit-explainer/storyboard.md:50-50 (heading)

### shot_04: 50.0 to 65.0s. MCU. eye-level. push.

Extracted rules inside block: NONE

## 668073feec2e65be — storyboard-architect/examples/shotkit-explainer/storyboard.md:52-54 (paragraph)

**Beat:** proof-2. **Subject:** Coral wipe expands radially from the preview.html dot. Wipe reveals the rendered preview iframe scrolling vertically. The reader sees actual shot cards from the 30-second example pass through frame, including framing, angle, motion, color-grade rows. Subtle 10% vignette on edges.
**On-screen text:** "Files. Not panels. Not a SaaS dashboard." (Inter Black 900, lower-third, type-on)
**Rationale:** Reveal beat. The reader has now seen the methodology and the file outputs. The iframe shows the actual deliverable, not a mock.

Extracted rules inside block: NONE

## 6da6ada812e90594 — storyboard-architect/examples/shotkit-explainer/storyboard.md:56-56 (heading)

### shot_05: 65.0 to 80.0s. MS. eye-level. static.

Extracted rules inside block: NONE

## 864de1d8f727f832 — storyboard-architect/examples/shotkit-explainer/storyboard.md:58-60 (paragraph)

**Beat:** proof-3. **Subject:** Single shot description card sits center-frame. Seven generator adapter labels fan out radially around it. Midjourney, Flux, Ideogram, GPT Image, Nano Banana, Seedream, Runway/Sora. Lines connect center card to each adapter in 1px ink. Each adapter shows its prompt syntax appearing as a typewriter pass running simultaneously.
**On-screen text:** "One shot. Seven generators. One spec." (Inter Black 900, upper-third, fade)
**Rationale:** Cross-generator demonstration. Same shot description compiles to seven different prompt syntaxes simultaneously. The visual proves model-agnosticism is structural, not aspirational.

Extracted rules inside block: NONE

## 48f151b2258147f5 — storyboard-architect/examples/shotkit-explainer/storyboard.md:62-62 (heading)

### shot_06: 80.0 to 90.0s. WS. eye-level. static.

Extracted rules inside block: NONE

## a56ea1e2d0119ed3 — storyboard-architect/examples/shotkit-explainer/storyboard.md:64-66 (paragraph)

**Beat:** promise. **Subject:** Full-frame typography. Install command appears via type-on in JetBrains Mono Regular at 22pt. Below it the project tagline in Inter italic 500 18pt, color muted. Coral period on the signature beat. Standard footer chrome holds.
**On-screen text:** "git clone github.com/whystrohm/shotkit / cd shotkit && ./install.sh" (JetBrains Mono, center, type-on) plus tagline "Pre-production for founder-led video at scale." (Inter italic 500, lower-third, fade).
**Rationale:** Promise beat. The viewer has the diagnosis, the architecture, the artifact, and the proof. The CTA is one paste-into-terminal command. No friction surface.

Extracted rules inside block: NONE

## e3a03c984dc714cd — storyboard-architect/examples/shotkit-explainer/storyboard.md:68-68 (heading)

## Audit trail

Extracted rules inside block: NONE

## 49d0be39fe55c437 — storyboard-architect/examples/shotkit-explainer/storyboard.md:70-70 (list_item)

- Brief, this document, scoped from the shotkit blog launch sequence.

Extracted rules inside block: NONE

## 422517947db39fb1 — storyboard-architect/examples/shotkit-explainer/storyboard.md:71-71 (list_item)

- Brand-lock snapshotted from `brand-packs/whystrohm.md` on 2026-05-08.

Extracted rules inside block: NONE

## 5b34e1671bc300cd — storyboard-architect/examples/shotkit-explainer/storyboard.md:72-72 (list_item)

- Shot list designed to compose with the existing ShotkitDemo composition (same chrome, complementary content, longer arc).

Extracted rules inside block: NONE

## cdcc0eb2a40e3103 — storyboard-architect/examples/shotkit-explainer/storyboard.md:73-73 (list_item)

- Render shipped at [whystrohm.com/blog/you-dont-have-a-content-problem](https://whystrohm.com/blog/you-dont-have-a-content-problem) as the "we used shotkit to make this video" dogfood reveal.

Extracted rules inside block: NONE

## d26feb142d8e7dc6 — storyboard-architect/examples/shotkit-explainer/storyboard.md:74-74 (list_item)

- Landscape MP4 served from the blog: `/media/shotkit-explainer/shotkit-explainer.mp4`.

Extracted rules inside block: NONE

## 17ea6a31828bc3d6 — storyboard-architect/references/beat-frameworks.md:1-1 (heading)

# Beat Frameworks

Extracted rules inside block: NONE
