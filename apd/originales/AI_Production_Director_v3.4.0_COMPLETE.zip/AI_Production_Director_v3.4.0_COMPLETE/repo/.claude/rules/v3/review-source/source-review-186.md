# Source coverage review 186/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## baf54ca0f9320ebc — visual-asset-critic/SKILL.md:31-31 (paragraph)

The markdown critique uses these sections:

Extracted rules inside block: NONE

## 9b11d91c0be3c7b8 — visual-asset-critic/SKILL.md:33-51 (code)

```
## Verdict
ACCEPT / REVISE / REJECT, one line

## What's working
2–4 specific positives. Concrete observations, not flattery.

## What's not working
2–5 specific issues. Each one cites a layer. Brand Lock, Series Lock, Shot Spec, Composition, Technical, or Continuity.

## Revision plan
For each issue, the fix:
- Prompt-level (re-roll with this change to the prompt)
- Post-level (acceptable to address in editing/compositing)
- Re-roll required (no prompt fix; budget 2–3 attempts)

## Confidence
HIGH / MEDIUM / LOW, how sure you are about the verdict
```

Extracted rules inside block: NONE

## 5f2fbbf57c112f84 — visual-asset-critic/SKILL.md:53-53 (heading)

## Inputs

Extracted rules inside block: NONE

## 6a1bec777bf067b9 — visual-asset-critic/SKILL.md:55-55 (paragraph)

You need:

Extracted rules inside block: NONE

## 8bb6dba00dd7de63 — visual-asset-critic/SKILL.md:57-57 (table_row)

| Input | Required? | Default if absent |

Extracted rules inside block: 9b9850ad026d

## 0bdafd2223a53535 — visual-asset-critic/SKILL.md:59-59 (table_row)

| The generated image | Yes | Cannot critique without it |

Extracted rules inside block: NONE

## a3b1b7825b9bdddb — visual-asset-critic/SKILL.md:60-60 (table_row)

| Shot ID + shots.json | Recommended | If absent, ask for shot intent in a sentence |

Extracted rules inside block: ebe24ae336c9

## 630c27f543b6ddb3 — visual-asset-critic/SKILL.md:61-61 (table_row)

| brand-lock.snapshot.md | Recommended | If absent, critique only on technical merits |

Extracted rules inside block: 6480d1a0f109

## c45923a376ec7dcc — visual-asset-critic/SKILL.md:62-62 (table_row)

| The original prompt used | Helpful | If absent, infer from intent |

Extracted rules inside block: NONE

## 64283c9418ec51f9 — visual-asset-critic/SKILL.md:64-64 (paragraph)

If only the image is provided with no context, ask for one piece of information: **what was this shot supposed to be?** A single sentence is enough to anchor the critique.

Extracted rules inside block: NONE

## 1e672bb95e42bba1 — visual-asset-critic/SKILL.md:66-66 (heading)

## Workflow

Extracted rules inside block: NONE

## fdb66ec9445cb0d0 — visual-asset-critic/SKILL.md:68-68 (heading)

### Step 1. Establish intent

Extracted rules inside block: NONE

## 564cc9c5e5a80ad6 — visual-asset-critic/SKILL.md:70-70 (paragraph)

What was this shot supposed to do? Pull from:

Extracted rules inside block: NONE

## eac689f831d75676 — visual-asset-critic/SKILL.md:72-72 (list_item)

- Shot's `rationale` field (if shots.json provided)

Extracted rules inside block: NONE

## 8e2f40503c855952 — visual-asset-critic/SKILL.md:73-73 (list_item)

- Shot's `subject`, `framing`, `angle`, `motion` fields

Extracted rules inside block: NONE

## 76c44a9f4f1fcbaf — visual-asset-critic/SKILL.md:74-74 (list_item)

- User's stated intent (if no shots.json)

Extracted rules inside block: NONE

## 8199bedae5cc2fa7 — visual-asset-critic/SKILL.md:75-75 (list_item)

- The beat this shot serves

Extracted rules inside block: NONE

## 7830c6443b8b0bf7 — visual-asset-critic/SKILL.md:77-77 (paragraph)

If you can't establish intent in one sentence, ask. Don't critique blind.

Extracted rules inside block: a70b73cef603

## 03fab924774ee964 — visual-asset-critic/SKILL.md:79-79 (heading)

### Step 2. Critique by layer

Extracted rules inside block: NONE

## 5e30bf114f478bba — visual-asset-critic/SKILL.md:81-81 (paragraph)

Read `references/critique-rubric.md` for the full rubric. Quick version, check the image against:

Extracted rules inside block: NONE

## a7bb0a6a0e7f3a12 — visual-asset-critic/SKILL.md:83-83 (list_item)

1. **Brand Lock**, does it respect palette, mood, "never" list?

Extracted rules inside block: 8f1cbae0338d

## 08b84ecddbe646e9 — visual-asset-critic/SKILL.md:84-84 (list_item)

2. **Series Lock**, does it match character/environment/lighting anchors?

Extracted rules inside block: 1f39471f95e9

## 4dd1050e6477a6c3 — visual-asset-critic/SKILL.md:85-85 (list_item)

3. **Shot Spec**, does framing/angle/composition match the spec?

Extracted rules inside block: 6a19a645d31b

## 5aa8f483c778af4f — visual-asset-critic/SKILL.md:86-86 (list_item)

4. **Composition**, does it reserve space for on-screen text if applicable?

Extracted rules inside block: 0feac8cdb201

## d23c0faef84b7e85 — visual-asset-critic/SKILL.md:87-87 (list_item)

5. **Technical**, skin texture, hands, eyes, anatomy, AI artifacts?

Extracted rules inside block: 855b344e5b69

## 029b7f1da9f52528 — visual-asset-critic/SKILL.md:88-88 (list_item)

6. **Continuity**, if previous shots in the series are available, does it match?

Extracted rules inside block: 0201f6202dcf

## 4b640f1d0fa54b93 — visual-asset-critic/SKILL.md:90-90 (paragraph)

For each layer, note: pass / soft fail / hard fail. The verdict aggregates these.

Extracted rules inside block: NONE

## 92b13069ada9ec6f — visual-asset-critic/SKILL.md:92-92 (heading)

### Step 3. Map issues to fixes

Extracted rules inside block: NONE

## d6147f68c69faba7 — visual-asset-critic/SKILL.md:94-94 (paragraph)

For every "not working" point, the critique must say what to do about it. Three buckets:

Extracted rules inside block: 71ef9b9c049a

## ec975ed4649a9f91 — visual-asset-critic/SKILL.md:96-97 (paragraph)

**Prompt-level fix**, change the prompt and re-roll. Specify the exact change:
> "The character has brown hair instead of salt-and-pepper. Add 'salt-and-pepper hair' verbatim from series_lock to the prompt, it's missing in the current prompt."

Extracted rules inside block: NONE
