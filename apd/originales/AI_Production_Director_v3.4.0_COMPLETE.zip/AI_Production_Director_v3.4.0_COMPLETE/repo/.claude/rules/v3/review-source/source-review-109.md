# Source coverage review 109/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 7ed2ec5526a47bff — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:61-61 (list_item)

- 1:1, feed posts, podcast covers

Extracted rules inside block: NONE

## 808b558df000813f — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:62-62 (list_item)

- 4:5. Instagram feed alternative

Extracted rules inside block: NONE

## f353f1037a725eea — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:64-64 (heading)

## Color grade direction

Extracted rules inside block: NONE

## 3ca00345e239adb3 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:66-66 (paragraph)

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup. Skin tones warm but not orange. Greens kept slightly desaturated to push focus to subject.

Extracted rules inside block: eb2e36b0f664

## 252fb29243c92038 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:68-68 (heading)

## Motion language

Extracted rules inside block: NONE

## e9c65bf025503392 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:70-70 (paragraph)

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only, no fancy wipes, no zooms.

Extracted rules inside block: 1c35cb73c43f

## 6ff958f9504e62c4 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:72-72 (paragraph)

For kinetic typography content (the Content Spiral pattern): pacing accelerates inward, each zoom 1.5–2x faster than the previous. Snap-back to wide claim is a hard cut.

Extracted rules inside block: NONE

## f33351c7bd6d1b8a — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:74-74 (heading)

## Voice rules

Extracted rules inside block: NONE

## 70a8bad4cd7da429 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:76-76 (list_item)

- no em dashes

Extracted rules inside block: NONE

## 616c4c26569158f9 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:77-77 (list_item)

- no emojis in body copy

Extracted rules inside block: NONE

## 4d1dea918f420334 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:78-78 (list_item)

- no exclamation points in headlines

Extracted rules inside block: NONE

## 818fe1260256556f — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:79-79 (list_item)

- no hype words ("game-changing", "revolutionary", "comprehensive", "next-level", "leverage")

Extracted rules inside block: NONE

## d5d5641a918aac82 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:80-80 (list_item)

- no clichéd business metaphors ("move the needle", "drink the kool-aid", "low-hanging fruit")

Extracted rules inside block: NONE

## c169bf42ec60a936 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:81-81 (list_item)

- no qualifiers in declarative copy ("perhaps", "maybe", "kind of")

Extracted rules inside block: NONE

## a4bebbf2f164245e — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:82-82 (list_item)

- prefer specific numbers over vague claims ("48 hours" not "fast", "30 minutes a week" not "a little time")

Extracted rules inside block: 50878f3f21c9

## 0e086a132090971a — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:83-83 (list_item)

- prefer present-tense over future-tense

Extracted rules inside block: 8bd0c488c1de

## afa75d4bcbda1c9d — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:84-84 (list_item)

- prefer "operator" over "creator", "infrastructure" over "agency", "system" over "service"

Extracted rules inside block: a3dd0f92205b

## 0f5c9ae781a27592 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:85-85 (list_item)

- coral period (`.`) on signature lines is a typography choice, not punctuation, apply at end of hero phrases only

Extracted rules inside block: NONE

## d8371a29fc39c3a7 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:87-87 (heading)

## Reference materials

Extracted rules inside block: NONE

## c59e098d46b1ed71 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:89-89 (list_item)

- Site: https://whystrohm.com

Extracted rules inside block: NONE

## 3988a8fe652dab94 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:90-90 (list_item)

- Brand voice extractor: https://github.com/whystrohm/media-tsunami

Extracted rules inside block: NONE

## a3a81275401f86e4 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:91-91 (list_item)

- Past hero films: see `/results` page

Extracted rules inside block: NONE

## bc33a82fcdda3bc4 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:92-92 (list_item)

- Content Spiral pattern: documented in WhyStrohm production bible v3 (internal)

Extracted rules inside block: NONE

## a787d8a253070239 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:96-98 (paragraph)

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0

Extracted rules inside block: NONE

## aa0f78637cf4c4b6 — storyboard-architect/examples/shotkit-explainer/storyboard.md:1-1 (heading)

# shotkit. The Explainer.

Extracted rules inside block: NONE

## 75655958b3dde38f — storyboard-architect/examples/shotkit-explainer/storyboard.md:3-8 (paragraph)

**Project:** shotkit explainer film
**Duration:** 90 seconds
**Aspect:** 16:9 (1280x720 hero render, 1080x1920 vertical cut for socials)
**Framework:** founder-explainer
**Brand-lock:** [brand-lock.snapshot.md](./brand-lock.snapshot.md) snapshotted 2026-05-08T14:34:24Z
**Generated:** 2026-05-08

Extracted rules inside block: NONE

## e9d1286139ca2901 — storyboard-architect/examples/shotkit-explainer/storyboard.md:10-10 (list_item)

> This storyboard is the record of the v0.1.0 explainer film as it was actually rendered, so

Extracted rules inside block: NONE

## c7aff26a3cd46cfb — storyboard-architect/examples/shotkit-explainer/storyboard.md:11-11 (list_item)

> shot_05 still names seven adapters including Runway/Sora. Sora was discontinued and the

Extracted rules inside block: NONE

## f8ec3ccea829bbfc — storyboard-architect/examples/shotkit-explainer/storyboard.md:12-12 (list_item)

> motion lane moved to Kling, Veo, Seedance, and Hailuo. The storyboard is deliberately left

Extracted rules inside block: NONE

## a0723b84c5e61622 — storyboard-architect/examples/shotkit-explainer/storyboard.md:13-13 (list_item)

> matching the artifact it produced: editing it to describe a video that was never made is

Extracted rules inside block: 4497defa79cb
