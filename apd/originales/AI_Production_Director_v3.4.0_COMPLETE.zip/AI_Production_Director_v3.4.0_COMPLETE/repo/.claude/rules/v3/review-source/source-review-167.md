# Source coverage review 167/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 1b972bf6a60b36bd — video/references/role-modes.md:102-102 (paragraph)

User asks to "собери монтаж", "задай ритм", "сделай динамично", "разбей на склейки", "как смонтировать", "сколько кадров в 5 секундах."

Extracted rules inside block: NONE

## df40194cf8f2befc — video/references/role-modes.md:104-104 (heading)

### Mindset

Extracted rules inside block: NONE

## 3851993c0b804d9d — video/references/role-modes.md:106-106 (paragraph)

Dynamic montage is built through structure, not speed. Random fast cuts create visual soup. Readable fast cuts create propulsion.

Extracted rules inside block: NONE

## 7adbece5be1ac176 — video/references/role-modes.md:108-108 (heading)

### Rules

Extracted rules inside block: NONE

## 5a030f41f708e66a — video/references/role-modes.md:110-110 (list_item)

- Clear shot function per cut.

Extracted rules inside block: NONE

## 597baf40c916d1d1 — video/references/role-modes.md:111-111 (list_item)

- Escalating frame tightness (wide -> medium -> close).

Extracted rules inside block: NONE

## b42f50e0d34d64b8 — video/references/role-modes.md:112-112 (list_item)

- Different camera angles per cut.

Extracted rules inside block: NONE

## d6da90d10e9b7026 — video/references/role-modes.md:113-113 (list_item)

- Motivated cuts (sound event, action beat, emotional shift).

Extracted rules inside block: NONE

## 9145949ba6441ff6 — video/references/role-modes.md:114-114 (list_item)

- Contrast speed and pause.

Extracted rules inside block: NONE

## 655b02373b9598d3 — video/references/role-modes.md:115-115 (list_item)

- Sound-driven transitions.

Extracted rules inside block: NONE

## 1aff9d3b8489776a — video/references/role-modes.md:116-116 (list_item)

- One silence or stillness moment before a major impact.

Extracted rules inside block: NONE

## 5295380461e2bb0d — video/references/role-modes.md:118-118 (heading)

### Output format. Timecoded beat sheet

Extracted rules inside block: NONE

## 936d0cdebf0339b5 — video/references/role-modes.md:120-124 (code)

```text
00.0-00.8. [shot function] - [framing] - [camera] - [sound cue]
00.8-01.6. [shot function] - [framing] - [camera] - [sound cue]
...
```

Extracted rules inside block: NONE

## 9d04ae8cf31dc3b3 — video/references/role-modes.md:126-126 (heading)

### Density

Extracted rules inside block: NONE

## a2afa91cfcc5d580 — video/references/role-modes.md:128-128 (list_item)

- Emotional drama. 3-4 beats per 5s.

Extracted rules inside block: NONE

## 829de20092bd71e0 — video/references/role-modes.md:129-129 (list_item)

- Standard narrative. 4-7 beats per 5s.

Extracted rules inside block: NONE

## b8717a4b92ebaf85 — video/references/role-modes.md:130-130 (list_item)

- Fast montage. 6-9 beats per 5s.

Extracted rules inside block: NONE

## 0a8aa6abc0b475e4 — video/references/role-modes.md:132-132 (paragraph)

More than 9 beats in 5s creates incoherent motion regardless of model.

Extracted rules inside block: NONE

## e2ad1147e6064c3b — video/references/role-modes.md:136-136 (heading)

## 4. Shot function taxonomy

Extracted rules inside block: NONE

## c5e3b772edbda3a0 — video/references/role-modes.md:138-138 (paragraph)

Every beat should carry at least one function tag. This is the editor's grammar.

Extracted rules inside block: 5b90694c544e

## e9a9f04b437a8028 — video/references/role-modes.md:140-140 (list_item)

- **Establish.** Where we are. Wide or master shot. Sets geography.

Extracted rules inside block: NONE

## ee01d845bf42d982 — video/references/role-modes.md:141-141 (list_item)

- **Reveal.** What appears. New information enters frame.

Extracted rules inside block: NONE

## 5fe772d47eb9e341 — video/references/role-modes.md:142-142 (list_item)

- **Power.** Who controls the scene right now. Staging reveals the hierarchy before dialogue does.

Extracted rules inside block: NONE

## c315a4baad493545 — video/references/role-modes.md:143-143 (list_item)

- **Pressure.** Tension builds. Movement toward threat or decision. Environment can carry this (flickering light, rain, steam, a tight corridor).

Extracted rules inside block: NONE

## 6dc2b680a0233a3e — video/references/role-modes.md:144-144 (list_item)

- **Detail.** Important object, hand, eye, texture, gesture. Macro or close-up. The anchor object often lives here.

Extracted rules inside block: NONE

## ad52d59de40e0025 — video/references/role-modes.md:145-145 (list_item)

- **Reaction.** Emotional consequence. Face response to a beat.

Extracted rules inside block: NONE

## 0fcab265025ddcc0 — video/references/role-modes.md:146-146 (list_item)

- **Shift.** Inner change. Body language turning point. The moment before the decision becomes visible.

Extracted rules inside block: NONE

## 2fc7f1c56b05f9c6 — video/references/role-modes.md:147-147 (list_item)

- **Impact.** Decisive visual event. The drop. The hit. The break.

Extracted rules inside block: NONE

## 94e7d756e499709f — video/references/role-modes.md:148-148 (list_item)

- **Aftermath.** Emotional residue. Stillness after impact.

Extracted rules inside block: NONE

## 64eafa0ae29b7e61 — video/references/role-modes.md:149-149 (list_item)

- **Exit.** Final state. The image the viewer leaves with.

Extracted rules inside block: NONE
