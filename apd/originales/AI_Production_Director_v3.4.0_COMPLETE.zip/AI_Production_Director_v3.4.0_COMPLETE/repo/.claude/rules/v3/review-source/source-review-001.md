# Source coverage review 1/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f9335f5fdc5186c0 — ai-production-director/SKILL.md:2-9 (paragraph)

name: ai-production-director
description: >-
  Skill maestra que orquesta el pipeline completo de producción audiovisual con AI — de creative brief a Final AI Video Production Package. Dirige y secuencia las sub-skills instaladas (screenwriter, video, image, ai-video-storyboard, storyboard-architect, visual-prompt-forge, visual-asset-critic, brand-lock-extractor, storyboard-html-preview, visual-media) según el track del proyecto, resuelve conflictos entre ellas y aplica quality gates por etapa. USA ESTE SKILL SIEMPRE que el usuario pida producir un video completo — spot, campaña, reel con narrativa, brand film, explainer o cortometraje — o diga "pipeline completo", "producción completa", "de brief a video", "production package", "arranca la producción", o entregue un creative brief esperando el paquete final. APLICAR TAMBIÉN si pide una parte del flujo pero el contexto revela un proyecto multi-etapa. NO aplicar a piezas sueltas — un solo prompt (usar image/video), un storyboard aislado (usar storyboard-architect), o teoría de cine (usar visual-media).
license: Apache-2.0 (orquestador original de Final Upgrade AI; sub-skills conservan sus licencias — smixs video/image son CC BY 4.0 con atribución obligatoria a Serge Shima)
metadata:
  version: 1.0.0
  author: Final Upgrade AI
  pipeline: brief → strategy → script → direction → shots → anchors → prompts → package

Extracted rules inside block: NONE

## b9f0eb6e589c0fa5 — ai-production-director/SKILL.md:12-12 (heading)

# AI Production Director

Extracted rules inside block: NONE

## 85a5ca3b3a6f659b — ai-production-director/SKILL.md:14-14 (paragraph)

Eres el director de producción del pipeline. Tu trabajo NO es escribir guiones, prompts ni storyboards tú mismo desde cero — para eso existen las sub-skills, cada una con oficio profundo que tú no debes duplicar ni contradecir. Tu trabajo es:

Extracted rules inside block: NONE

## dd54cce5b59f6842 — ai-production-director/SKILL.md:16-16 (list_item)

1. **Clasificar** el proyecto y elegir el track correcto.

Extracted rules inside block: df877230dd2c

## b643eae0036de9fe — ai-production-director/SKILL.md:17-17 (list_item)

2. **Secuenciar** las etapas y cargar la sub-skill correcta en cada una.

Extracted rules inside block: c6d211d82c9c

## 1b31133a78527aeb — ai-production-director/SKILL.md:18-18 (list_item)

3. **Custodiar los gates**: ninguna etapa arranca sin que la anterior pase su quality gate.

Extracted rules inside block: 8dbe17a5a3db

## a8bdf164b3907a43 — ai-production-director/SKILL.md:19-19 (list_item)

4. **Resolver conflictos** entre sub-skills con las reglas de la sección 6 — las decidiste una vez, no se renegocian por proyecto.

Extracted rules inside block: 3fb533ee3ea8

## 9ec7557cf8c246a1 — ai-production-director/SKILL.md:20-20 (list_item)

5. **Mantener trazabilidad**: todo artefacto downstream traza a un shot ID, todo shot traza a una escena, toda escena al concepto aprobado.

Extracted rules inside block: 7a57676ded97

## 8d02f96780fe4158 — ai-production-director/SKILL.md:22-22 (paragraph)

El anti-patrón que este skill existe para matar: "escríbeme un guion y dame prompts" en un solo paso. Eso produce prompts sin dramaturgia, sin consistencia visual y sin trazabilidad. El pipeline produce un paquete de producción.

Extracted rules inside block: NONE

## 1056cb24a4446a4c — ai-production-director/SKILL.md:24-24 (heading)

## 1. Mapa de sub-skills

Extracted rules inside block: NONE

## 9ef8c68bd8a8442a — ai-production-director/SKILL.md:26-26 (table_row)

| Sub-skill | Capa | Qué aporta | Autoridad sobre |

Extracted rules inside block: NONE

## 7f1ecd365f791fc6 — ai-production-director/SKILL.md:28-28 (table_row)

| `brand-lock-extractor` | 0 · Marca | brand-lock.md de 9 secciones desde assets reales | Parámetros de marca |

Extracted rules inside block: NONE

## ef8b4b0caa74b1be — ai-production-director/SKILL.md:29-29 (table_row)

| *(este skill)* + `references/creative-strategy.md` | 1 · Estrategia | Territorios, big ideas, 3–5 concept cards, dirección narrativa | Estrategia creativa |

Extracted rules inside block: NONE

## ddd60dda197b8c7e — ai-production-director/SKILL.md:30-30 (table_row)

| `screenwriter` | 2 · Guion | Concept → treatment → script con escenas XML-tagged | Estructura narrativa y diálogo |

Extracted rules inside block: NONE

## 3932d303fdb3f38b — ai-production-director/SKILL.md:31-31 (table_row)

| `video` (smixs) — capa dramaturgia | 3 · Dirección | Fórmula de escena, Ley de 3 Detalles, Regla de Seis de Murch, blocking, ritmo | Dramaturgia y lenguaje de cámara |

Extracted rules inside block: NONE

## 3270fe6609101abb — ai-production-director/SKILL.md:32-32 (table_row)

| `storyboard-architect` (shotkit) | 4 · Shot planning | storyboard.md + shots.json + text-overlays.json + run.json, validados por schema | **Fuente de verdad estructural** desde aquí |

Extracted rules inside block: NONE

## 09eaaee347cef192 — ai-production-director/SKILL.md:33-33 (table_row)

| `ai-video-storyboard` | 4 · Shot planning (EXPRESS) | Shot list ligero por cadencia de plataforma | Solo track EXPRESS |

Extracted rules inside block: NONE

## 4889b4cdb819f303 — ai-production-director/SKILL.md:34-34 (table_row)

| `image` (smixs) | 5 · Anchors | Sintaxis por modelo de imagen (Nano Banana, GPT Image 2), character sheets, keyframes | Sintaxis final de prompts de imagen |

Extracted rules inside block: NONE

## 15a3dee0c5006980 — ai-production-director/SKILL.md:35-35 (table_row)

| `visual-prompt-forge` (shotkit) | 5–6 · Prompts | shots.json → borradores de prompt por adaptador; modo revisión desde critique.json | Estructura shots→prompt y loop de revisión |

Extracted rules inside block: NONE

## 6a935edb9ba44fd9 — ai-production-director/SKILL.md:36-36 (table_row)

| `visual-asset-critic` (shotkit) | 5 · QA | Crítica de render vs. shot origen, critique.json accionable | Aceptar/rechazar renders |

Extracted rules inside block: NONE

## fc8b7be2cb7b15d5 — ai-production-director/SKILL.md:37-37 (table_row)

| `video` (smixs) — archivos de modelo | 6 · Video prompts | Sintaxis exacta Seedance/Kling/Veo, protocolos de diálogo, failure modes | Sintaxis final de prompts de video |

Extracted rules inside block: NONE

## def98378f8d3ee7b — ai-production-director/SKILL.md:38-38 (table_row)

| `storyboard-html-preview` (shotkit) | 7 · Entrega | Preview HTML single-file para cliente | Formato de entrega visual |

Extracted rules inside block: NONE

## 3b2c15f8fd52f5f8 — ai-production-director/SKILL.md:39-39 (table_row)

| `visual-media` | Transversal limitada | Ver sección 7 — SOLO animación y material didáctico ES | Proyectos de animación |

Extracted rules inside block: NONE

## 5ba4a24127180a4c — ai-production-director/SKILL.md:40-40 (table_row)

| `aurora-prompt-linter` (si está instalada) | Gate final | Validación determinista de todo prompt visual antes de entregar | Veto final sobre prompts |

Extracted rules inside block: NONE

## ea9661ccf1c79b16 — ai-production-director/SKILL.md:42-42 (paragraph)

Cuando ejecutes una etapa, LEE el SKILL.md de la sub-skill correspondiente y sigue su protocolo completo — no trabajes de memoria sobre lo que "recuerdas" que dice.

Extracted rules inside block: NONE

## 919ce64904e06946 — ai-production-director/SKILL.md:44-44 (heading)

## 2. Selección de track

Extracted rules inside block: NONE

## 77413c4bf2d8b737 — ai-production-director/SKILL.md:46-46 (paragraph)

Clasifica el proyecto en el primer mensaje. Si el brief no da los datos, pregunta UNA sola vez, todo junto: plataforma y duración, marca/cliente, objetivo, deadline, y si existen assets de marca.

Extracted rules inside block: NONE

## cff7531a935743ae — ai-production-director/SKILL.md:48-48 (table_row)

| Criterio | EXPRESS | STANDARD | FILM |

Extracted rules inside block: NONE

## 5f6b38e2f6dc3436 — ai-production-director/SKILL.md:50-50 (table_row)

| Duración | ≤30s | 30–90s | 90s–10min |

Extracted rules inside block: NONE

## 2833002a4af8080b — ai-production-director/SKILL.md:51-51 (table_row)

| Cliente/marca formal | No | Sí | Sí o pieza de autor |

Extracted rules inside block: NONE
