# Source coverage review 11/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## b38951bedfbd97a1 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:136-136 (list_item)

- [ ] Apply a consistent warm LUT — **Kodak Portra 400** emulation or **"Teal & Orange: Warm"** works well

Extracted rules inside block: NONE

## 9054229f31a44c1d — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:137-137 (list_item)

- [ ] Add 0.3-0.4s **dissolve transitions** between Shots 1→2, 2→3, 4→5. Use a **hard cut** for Shot 3→4 (energy shift) and Shot 5→6 (CTA impact)

Extracted rules inside block: 4e8a1e343c5c

## 5b7a75a7a7d73403 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:138-138 (list_item)

- [ ] Layer **BGM**: single acoustic guitar track at ~85 BPM, free from Artlist/Epidemic Sound. Something like "Morning Coffee" or "Slow Brew" genre keywords

Extracted rules inside block: NONE

## bfdc5791056dd659 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:139-139 (list_item)

- [ ] Add **text overlays**:

Extracted rules inside block: NONE

## 64cc92e54735a4af — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:140-140 (list_item)

  - 0-1s: "Slow morning ☕️" (bottom center)

Extracted rules inside block: NONE

## 5bfc2887d3cbaab3 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:141-141 (list_item)

  - 25-30s: "Opening Saturday · @yourshop" (bold, centered)

Extracted rules inside block: NONE

## 5acbfbad46666c24 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:142-142 (list_item)

- [ ] Export: **9:16, 1080×1920, 30fps, H.264, target bitrate 12 Mbps**

Extracted rules inside block: NONE

## 53434f57ad7c8e06 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:143-143 (list_item)

- [ ] Upload to TikTok with hashtags: `#coffeeshop #specialtycoffee #openingsoon #grandopening #coffeelover`

Extracted rules inside block: NONE

## cf08ecf88f6bee31 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:147-147 (heading)

## Why This Works

Extracted rules inside block: NONE

## 25dafb4d09f68f0b — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:149-149 (paragraph)

**Structure:** Hook (1) → Setting (2) → Human (3) → Detail (4) → Atmosphere (5) → CTA (6). This is the classic TikTok cadence adapted for brand storytelling: a sensory hook to stop the scroll, a human face to build empathy, craft details to signal quality, an aspirational moment, then a clean CTA. No shot is wasted.

Extracted rules inside block: NONE

## 766198a1f59e603d — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:151-151 (paragraph)

**Visual consistency:** Every shot shares the same color palette (espresso/cream/amber/sage), the same lighting temperature (warm 3200K with motivated window light), the same lens character (shallow DOF, 35mm), and the same film look (subtle 16mm grain). Even if the 6 shots are generated in separate runs, they will edit together as if shot by the same cinematographer in the same session.

Extracted rules inside block: f4acdaf29b9c

## c6ca78dbdb8fe0e9 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:153-153 (paragraph)

**Pacing:** 5 seconds per shot matches the average scroll-dwell time on TikTok. Long enough to land the idea, short enough to maintain momentum. The 30s total is the sweet spot for completion-rate-optimized Reels.

Extracted rules inside block: NONE

## 9cd44aa5c5cb68f0 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:155-155 (paragraph)

**Emotion arc:** Shot 1 is sensory (hot water, steam), Shot 3 is emotional (barista's smile), Shot 5 is aspirational (customer enjoying the moment). This gives the viewer a reason to care beyond "coffee exists here".

Extracted rules inside block: NONE

## 86cc2be9477acef4 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:157-157 (paragraph)

**Why the prompts work:** They lean heavily on concrete cinematic vocabulary (shallow DOF, rim light, warm backlight, film grain) — specifics that modern AI video models can actually execute. The synchronized audio direction means each shot arrives with ambient café sounds pre-baked, dramatically reducing post-production sound design time.

Extracted rules inside block: 070c0aed570a

## a7063e15791bc05b — aurora-prompt-linter/SKILL.md:2-3 (paragraph)

name: aurora-prompt-linter
description: "Gate determinista que valida prompts de generación visual AI (imagen/video) antes de entregar. Detecta 3 capas: redundancia con refs por categoría P/O/L/PR/S, secciones requeridas por plataforma+caso (Kling 3.0/Veo 3.1/Sora 2/GPT Image 2/Nano Banana Pro/Midjourney), y estructura (word count, negative prompt, vocab baneado). USA ESTE SKILL antes de entregar cualquier prompt visual al usuario — gate obligatorio del skill prompt-production-protocol Step 5b. Override solo con sintaxis expresa OVERRIDE: término-o-categoría - razón, válido únicamente en turno actual."

Extracted rules inside block: NONE

## 653232f481e9590b — aurora-prompt-linter/SKILL.md:6-6 (heading)

# Aurora Prompt Linter

Extracted rules inside block: NONE

## 1319618712aed850 — aurora-prompt-linter/SKILL.md:8-8 (paragraph)

Gate determinista entre el drafting del prompt y la entrega al usuario. Mueve la regla "no redescribir lo que está en los refs" de memoria del agente a código ejecutable.

Extracted rules inside block: NONE

## 9aa9834da1a6178f — aurora-prompt-linter/SKILL.md:10-10 (heading)

## Por qué existe

Extracted rules inside block: NONE

## aaef4c4ae0df23a4 — aurora-prompt-linter/SKILL.md:12-12 (paragraph)

El agente olvida la regla v6.0 §5.4 ("menos descripción de lo que HAY, más de cómo EVOLUCIONA") bajo presión de iteración rápida. Documentado empíricamente en sesión 2026-05-27: 4 errores repetidos de over-description en el mismo flujo. La memoria del agente falla, el código no.

Extracted rules inside block: NONE

## 5ca6d7bfad85d8b0 — aurora-prompt-linter/SKILL.md:14-14 (heading)

## Cuándo usarlo

Extracted rules inside block: NONE

## 0fc919b2280bbf50 — aurora-prompt-linter/SKILL.md:16-16 (paragraph)

**Obligatorio** para:

Extracted rules inside block: 4c57ad823e88

## e70f117cdb5014ec — aurora-prompt-linter/SKILL.md:17-17 (list_item)

- Casos 3a/3b/3c (I2V con FF/LF refs) — donde la redundancia es la falla más común

Extracted rules inside block: NONE

## 88275ba5be135ba7 — aurora-prompt-linter/SKILL.md:19-19 (paragraph)

**Recomendado** para:

Extracted rules inside block: NONE

## fcd06b3c13259321 — aurora-prompt-linter/SKILL.md:20-20 (list_item)

- Caso 1 (Génesis text-to-image)

Extracted rules inside block: NONE

## 3555251d8dc0e665 — aurora-prompt-linter/SKILL.md:21-21 (list_item)

- Caso 2 (Ancla con refs parciales)

Extracted rules inside block: NONE

## a099868ccadff52a — aurora-prompt-linter/SKILL.md:22-22 (list_item)

- Caso 4 (Video con diálogo)

Extracted rules inside block: NONE

## fdf6377a72299e1f — aurora-prompt-linter/SKILL.md:24-24 (paragraph)

**El agente lo invoca automáticamente** al final de Step 4 (drafting) del skill `prompt-production-protocol`, antes de Step 6 (delivery). Si la Regla 28 está activa en el system prompt, es bloqueante.

Extracted rules inside block: NONE

## 8d51902234a35f2d — aurora-prompt-linter/SKILL.md:26-26 (heading)

## Cómo invocarlo

Extracted rules inside block: NONE

## 3f4261af41c97292 — aurora-prompt-linter/SKILL.md:28-28 (paragraph)

Antes de entregar el prompt al usuario:

Extracted rules inside block: NONE

## 2ffea0cbbb5904cf — aurora-prompt-linter/SKILL.md:30-30 (list_item)

1. **Etiquetar los refs por categoría.** Cada ref carga 0 o más de: P (sujeto), O (outfit), L (locación), PR (prop), S (estilo). Mapea a IDs system v6.0 §7. Ejemplo de refs.yaml:

Extracted rules inside block: 1850362564ca
