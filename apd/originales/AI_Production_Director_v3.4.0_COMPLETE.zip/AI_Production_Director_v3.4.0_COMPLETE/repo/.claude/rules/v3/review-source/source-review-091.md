# Source coverage review 91/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c3a812ac24df97e8 — screenwriter/references/pipeline-integration.md:118-118 (heading)

## Character Consistency Tracking

Extracted rules inside block: NONE

## 02b199e9d7a5d7c0 — screenwriter/references/pipeline-integration.md:120-120 (heading)

### First Appearance Template

Extracted rules inside block: NONE

## 9a119083be80f43e — screenwriter/references/pipeline-integration.md:122-122 (paragraph)

Establish complete visual identity on first appearance:

Extracted rules inside block: NONE

## e9ad1abd901f7ce8 — screenwriter/references/pipeline-integration.md:124-126 (code)

```
CHARACTER NAME (age if relevant, defining physical trait, primary wardrobe)
```

Extracted rules inside block: NONE

## 4fb851803ae989ed — screenwriter/references/pipeline-integration.md:128-128 (paragraph)

**Examples:**

Extracted rules inside block: NONE

## 7f20ec69086d5071 — screenwriter/references/pipeline-integration.md:129-133 (code)

```
MAYA (early 30s, kind eyes, wearing a faded denim jacket and cargo pants)
COMMANDER REED (50s, grizzled with close-cropped gray hair, military uniform with rank insignia)
THE STRANGER (tall figure in a long black coat, face obscured by wide-brimmed hat)
```

Extracted rules inside block: NONE

## 0a07c0de50d6fe4f — screenwriter/references/pipeline-integration.md:135-135 (heading)

### Subsequent References

Extracted rules inside block: NONE

## 38f07f0706d0d037 — screenwriter/references/pipeline-integration.md:137-137 (paragraph)

After first appearance, use consistent identifiers:

Extracted rules inside block: 3d230d2482c7

## 8a15527609cc9f9c — screenwriter/references/pipeline-integration.md:139-139 (paragraph)

**Preferred Pattern:**

Extracted rules inside block: 0abe95a29fef

## 4e4bbce3eefedca0 — screenwriter/references/pipeline-integration.md:140-140 (list_item)

- Use character name only: "Maya checks her phone"

Extracted rules inside block: b94728dd2bbe

## 08d34672a8a9cd56 — screenwriter/references/pipeline-integration.md:141-141 (list_item)

- Add action-relevant details: "Maya pulls her jacket tighter against the wind"

Extracted rules inside block: NONE

## b6f86298a1c07a74 — screenwriter/references/pipeline-integration.md:143-143 (paragraph)

**Avoid:**

Extracted rules inside block: NONE

## 71f844193f1dc4d7 — screenwriter/references/pipeline-integration.md:144-144 (list_item)

- Re-describing appearance: "Maya, the woman in the denim jacket..."

Extracted rules inside block: NONE

## 924ff30c4a70486c — screenwriter/references/pipeline-integration.md:145-145 (list_item)

- Changing character names: "Maya" → "the woman" → "she"

Extracted rules inside block: NONE

## 4187cfa0a4689b14 — screenwriter/references/pipeline-integration.md:147-147 (heading)

### Character Tracking Checklist

Extracted rules inside block: NONE

## d4a9238de2d76c51 — screenwriter/references/pipeline-integration.md:149-149 (paragraph)

For each character, track:

Extracted rules inside block: NONE

## ad31899ebf9ddb70 — screenwriter/references/pipeline-integration.md:150-150 (list_item)

- [ ] Full name and any aliases

Extracted rules inside block: NONE

## e5d370ebb0c0742a — screenwriter/references/pipeline-integration.md:151-151 (list_item)

- [ ] Age or age range

Extracted rules inside block: NONE

## b75a9a8a40462702 — screenwriter/references/pipeline-integration.md:152-152 (list_item)

- [ ] Key physical identifiers (height, build, distinctive features)

Extracted rules inside block: NONE

## 3033159477a017fc — screenwriter/references/pipeline-integration.md:153-153 (list_item)

- [ ] Primary wardrobe (consistent across scenes unless story requires change)

Extracted rules inside block: NONE

## 8d159cfe22c5d911 — screenwriter/references/pipeline-integration.md:154-154 (list_item)

- [ ] Unique mannerisms or movement style

Extracted rules inside block: NONE

## 596cccc45d4af232 — screenwriter/references/pipeline-integration.md:158-158 (heading)

## Scene Numbering Conventions

Extracted rules inside block: NONE

## 567006afe55a4914 — screenwriter/references/pipeline-integration.md:160-160 (heading)

### Sequential Numbering

Extracted rules inside block: NONE

## 7fb46e2853f599de — screenwriter/references/pipeline-integration.md:162-162 (paragraph)

Number scenes sequentially from 1 to N:

Extracted rules inside block: NONE

## c84e86c373c94198 — screenwriter/references/pipeline-integration.md:163-167 (code)

```xml
<scene number="1" ...>
<scene number="2" ...>
<scene number="3" ...>
```

Extracted rules inside block: NONE

## 0acf1c077bba0bef — screenwriter/references/pipeline-integration.md:169-169 (paragraph)

**No Scene 0:** Start at 1, not 0 (industry standard)

Extracted rules inside block: NONE

## 7f20254c65a3ec53 — screenwriter/references/pipeline-integration.md:171-171 (heading)

### Scene Splits and Inserts

Extracted rules inside block: NONE

## 516a54d0abc507ee — screenwriter/references/pipeline-integration.md:173-173 (paragraph)

If a scene needs to be split or inserted during revision:

Extracted rules inside block: NONE

## 503067012de0826e — screenwriter/references/pipeline-integration.md:174-174 (list_item)

- Option A: Renumber all subsequent scenes

Extracted rules inside block: NONE

## 2f29011aca8284fe — screenwriter/references/pipeline-integration.md:175-175 (list_item)

- Option B: Use fractional numbering (1, 2, 2A, 3...)

Extracted rules inside block: 41a4959a6bb1
