# Rule classification review 14/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## d47eef584353 — storyboard-architect/brand-packs/README.md:21

**Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d47eef584353",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## 668412122538 — storyboard-architect/brand-packs/README.md:29

**`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "668412122538",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## b12c8ee34f41 — storyboard-architect/brand-packs/README.md:36

Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "b12c8ee34f41",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "subject.hands_visible",
        "value": true
      }
    ]
  }
}
```

## 751950af1fe7 — storyboard-architect/brand-packs/_template.md:17

Role | Hex | Use

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "751950af1fe7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## 08931603660c — storyboard-architect/brand-packs/_template.md:25

Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "08931603660c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## d966d89c7b90 — storyboard-architect/brand-packs/_template.md:49

What this brand never does, visually or tonally. Be specific.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d966d89c7b90",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## ebb1065ba6a5 — storyboard-architect/brand-packs/_template.md:51

never use stock photo aesthetic

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "ebb1065ba6a5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## d2d9fe8212a8 — storyboard-architect/brand-packs/_template.md:52

never use AI uncanny faces

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d2d9fe8212a8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## 671cc3f9bb8b — storyboard-architect/brand-packs/_template.md:53

never over-saturate

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "671cc3f9bb8b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## a0d0f54e8cec — storyboard-architect/brand-packs/_template.md:54

never shout in copy

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "a0d0f54e8cec",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## 39334acdbd3d — storyboard-architect/brand-packs/_template.md:55

never use clip-art icons

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "39334acdbd3d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## 083e7f152f6b — storyboard-architect/brand-packs/_template.md:64

How footage and generated images should be graded. One sentence.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "083e7f152f6b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## 73a660ab6755 — storyboard-architect/brand-packs/_template.md:72

> e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "73a660ab6755",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "storyboard",
      "shot"
    ]
  }
}
```

## 4a31ef7199d8 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:15

Role | Hex | Use

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "4a31ef7199d8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 982d5ec72424 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:40

never use stock photo aesthetic

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "982d5ec72424",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 569d35d98f04 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:41

never use AI uncanny faces

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "569d35d98f04",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 8d681e58df86 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:42

never over-saturate the cream background

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "8d681e58df86",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 6bc5ff54b80d — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:43

never use coral as a flood color (only as accent or signature periods)

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "6bc5ff54b80d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 63a6a2e47824 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:44

never use em dashes in copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "63a6a2e47824",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 5a3fa15bee1f — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:45

never use emojis in body copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "5a3fa15bee1f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## f27805b9aea8 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:46

never use bullet points in narrative copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "f27805b9aea8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 8d0acf3cef10 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:47

never use clip-art or generic icon sets

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "8d0acf3cef10",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 16f1cded5d12 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:48

never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "16f1cded5d12",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## d26bf6b9faf2 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:49

never use exclamation points in headlines

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "d26bf6b9faf2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 272a136d36c6 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:50

never default to dark mode, light mode hybrid is the brand

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "272a136d36c6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 20bab6ba688f — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:51

never animate text with bouncing or wobbling, type-on, fade, or hard cut only

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "20bab6ba688f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## c1bba522f6a4 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:62

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "c1bba522f6a4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 7888cba625ef — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:66

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "7888cba625ef",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 3af93a2dffdd — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:74

prefer specific numbers over vague claims

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "3af93a2dffdd",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 5b0daac77e37 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:75

prefer present-tense over future-tense

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "5b0daac77e37",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## c3bb383ba372 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:76

prefer "operator" over "creator", "infrastructure" over "agency"

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "c3bb383ba372",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 25af2b632520 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:34

**Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "25af2b632520",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## d5fc64ec46f8 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:56

**Subject:** founder at laptop, scrolling social feed, content tiles glowing on screen, slight slump in shoulders, mug of coffee mid-distance

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "d5fc64ec46f8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 1294de980a93 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:82

**On-screen text:** "You don't have a content problem. / You have an infrastructure problem." (Inter Black 900, coral, center, type-on at 11.5s)

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "1294de980a93",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 76d743fa8798 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:15

Role | Hex | Use

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "76d743fa8798",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```
