# Source coverage review 42/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 61be30eede3adb1c — image/references/golden-rules.md:93-93 (paragraph)

Multi-image вход: **NB до 14**, **GPT Image 2 до 16**. Индексируй с ролью каждой картинки.

Extracted rules inside block: NONE

## 763c626447edc954 — image/references/golden-rules.md:95-95 (paragraph)

Используй для:

Extracted rules inside block: 08d66623ebff

## a2a54d82e28d566e — image/references/golden-rules.md:97-97 (paragraph)

**Вписать в существующий дизайн:**

Extracted rules inside block: NONE

## 5f66ab2224d9f179 — image/references/golden-rules.md:98-103 (code)

```
[Attach design/layout image]
Create content following this exact layout and style.
Replace [ELEMENT] with [NEW CONTENT].
Keep colors, typography, composition.
```

Extracted rules inside block: NONE

## 6f3f0d494252bb5b — image/references/golden-rules.md:105-105 (paragraph)

**Лицо/персонаж как референс:**

Extracted rules inside block: NONE

## 02518cef78a636f3 — image/references/golden-rules.md:106-110 (code)

```
[Attach portrait]
Use this person's face. Keep features exactly the same.
Change: [expression/pose/setting]
```

Extracted rules inside block: NONE

## 36fc62fae8cfad43 — image/references/golden-rules.md:112-112 (paragraph)

**Продукт/объект как референс:**

Extracted rules inside block: NONE

## 616d2cf3558d9b9d — image/references/golden-rules.md:113-117 (code)

```
[Attach product photo]
Place this product in [NEW CONTEXT].
Match lighting and perspective.
```

Extracted rules inside block: NONE

## ab7ed33d019212ab — image/references/golden-rules.md:119-119 (paragraph)

**Стиль как референс:**

Extracted rules inside block: NONE

## 4cf87bf593672f08 — image/references/golden-rules.md:120-124 (code)

```
[Attach style reference]
Create [NEW CONTENT] in this exact visual style.
Match colors, textures, mood.
```

Extracted rules inside block: NONE

## 363e0705085b8267 — image/references/golden-rules.md:126-126 (paragraph)

**Несколько референсов сразу:**

Extracted rules inside block: NONE

## 2b88d087b3a26408 — image/references/golden-rules.md:127-132 (code)

```
[Attach Image 1 - face]
[Attach Image 2 - outfit]
[Attach Image 3 - background]
Combine: face from Image 1, outfit style from Image 2, setting from Image 3.
```

Extracted rules inside block: NONE

## d0db55f07796c490 — image/references/golden-rules.md:134-134 (heading)

## World Knowledge Anchors

Extracted rules inside block: NONE

## 3c0bf00d11ac4f89 — image/references/golden-rules.md:136-136 (paragraph)

GPT Image 2 обладает глубокими знаниями о культуре, эпохах и визуальных стилях. Вместо описания каждой детали — дай модели культурный/временной/жанровый якорь, и она сама заполнит аутентичные детали.

Extracted rules inside block: NONE

## f86ed97a108b9904 — image/references/golden-rules.md:138-138 (heading)

### Три типа якорей

Extracted rules inside block: NONE

## 06983a2eb302a630 — image/references/golden-rules.md:140-140 (paragraph)

**Era anchors** — временной и географический маркер, который вызывает целый визуальный мир:

Extracted rules inside block: NONE

## a4c83e7ceb5b9c8b — image/references/golden-rules.md:141-141 (list_item)

- "Bethel, NY, August 1969" → Woodstock aesthetic без необходимости описывать тай-дай, грязь, сцены

Extracted rules inside block: NONE

## 4fd0d04de5524153 — image/references/golden-rules.md:142-142 (list_item)

- "Berlin, November 1989" → падение стены, толпы, граффити, эйфория

Extracted rules inside block: NONE

## 50c7ddb8ee511572 — image/references/golden-rules.md:143-143 (list_item)

- "Tokyo, 1982" → неоновый Shinjuku, аналоговая электроника, ранний cyberpunk

Extracted rules inside block: NONE

## 91d49e48aea55775 — image/references/golden-rules.md:145-145 (paragraph)

**Cultural anchors** — перенос визуального языка одного культурного объекта на другой контекст:

Extracted rules inside block: NONE

## 4c17ffc8961207da — image/references/golden-rules.md:146-146 (list_item)

- "{game_title} in {real_city}" → автоматически применяет визуальный стиль игры к реальной локации (GTA style, Persona style, и т.д.)

Extracted rules inside block: NONE

## f7da8d0117b0985f — image/references/golden-rules.md:147-147 (list_item)

- "Soviet constructivism poster about {modern_topic}" → стиль Родченко/Эль Лисицкого на современную тему

Extracted rules inside block: NONE

## cf6fa3a092f922a1 — image/references/golden-rules.md:148-148 (list_item)

- "Ukiyo-e print of {modern_scene}" → японская гравюра с современным содержанием

Extracted rules inside block: NONE

## e215907679d80fbd — image/references/golden-rules.md:150-150 (paragraph)

**Genre anchors** — режиссёр/фотограф/движение как линза:

Extracted rules inside block: NONE

## b485bbffc3f73aee — image/references/golden-rules.md:151-151 (list_item)

- "Peter Lindbergh influence" → сильный Ч/Б, минимальная ретушь, raw editorial

Extracted rules inside block: NONE

## 58318d00be743eeb — image/references/golden-rules.md:152-152 (list_item)

- "Wes Anderson palette" → симметричный кадр, пастельная палитра, центрированная композиция

Extracted rules inside block: NONE

## 5d756493647ed275 — image/references/golden-rules.md:153-153 (list_item)

- "Studio Ghibli mood" → мягкое акварельное небо, зелёная листва, тёплый ностальгический свет

Extracted rules inside block: NONE

## 43df442c8bdf767b — image/references/golden-rules.md:154-154 (list_item)

- "Roger Deakins lighting" → натуральный свет, глубокие тени, кинематографичный объём

Extracted rules inside block: NONE

## 42ab144dd3f578d5 — image/references/golden-rules.md:156-156 (heading)

### Правила использования

Extracted rules inside block: NONE

## 71ead9775f1d797a — image/references/golden-rules.md:158-158 (list_item)

1. **Используй как HIGH-LEVEL steering** — якорь задаёт настроение и эстетику, а не заменяет весь промпт

Extracted rules inside block: a991c6ed5280
