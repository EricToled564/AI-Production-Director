# Source coverage review 26/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 74d2c2ee88b0d4b2 — brand-lock-extractor/brand-packs/examples/saas-clean.md:67-67 (list_item)

- no em dashes

Extracted rules inside block: NONE

## 70d0afcd6e727f62 — brand-lock-extractor/brand-packs/examples/saas-clean.md:68-68 (list_item)

- no exclamation points

Extracted rules inside block: NONE

## ca0b5702b5ee166f — brand-lock-extractor/brand-packs/examples/saas-clean.md:69-69 (list_item)

- no hype words

Extracted rules inside block: NONE

## ae2664238e6c90ee — brand-lock-extractor/brand-packs/examples/saas-clean.md:70-70 (list_item)

- prefer specific numbers ("40% reduction in 90 days" not "significant improvement")

Extracted rules inside block: 9b81d2c474e2

## 8cb533b14281ee1b — brand-lock-extractor/brand-packs/examples/saas-clean.md:71-71 (list_item)

- prefer "we" and "you" over "the company" and "the user"

Extracted rules inside block: 43e1c6267db0

## 73267b64cfd52951 — brand-lock-extractor/brand-packs/examples/saas-clean.md:72-72 (list_item)

- prefer present-tense

Extracted rules inside block: 08008c9a018e

## 737b0e7d925d33a4 — brand-lock-extractor/brand-packs/examples/saas-clean.md:73-73 (list_item)

- never start a sentence with "Just" or "Simply"

Extracted rules inside block: 81325a38d881

## db4893a2966de330 — brand-lock-extractor/brand-packs/examples/saas-clean.md:74-74 (list_item)

- avoid corporate hedge language ("seek to", "look to", "aim to")

Extracted rules inside block: 3c45f75a8756

## 6c5f3e2b1cd12e3f — brand-lock-extractor/brand-packs/examples/saas-clean.md:76-76 (heading)

## Reference materials

Extracted rules inside block: NONE

## a41b5a1c07559982 — brand-lock-extractor/brand-packs/examples/saas-clean.md:78-78 (list_item)

- Vercel marketing, design language reference

Extracted rules inside block: NONE

## 732e844da307d82e — brand-lock-extractor/brand-packs/examples/saas-clean.md:79-79 (list_item)

- Linear marketing, voice and pacing reference

Extracted rules inside block: NONE

## ca60ed76ce67b777 — brand-lock-extractor/brand-packs/examples/saas-clean.md:80-80 (list_item)

- Stripe Press, typography and density reference

Extracted rules inside block: NONE

## dec4d82bc97f8b37 — brand-lock-extractor/brand-packs/examples/saas-clean.md:84-86 (paragraph)

**Last updated:** 2026-05-07
**Owner:** Example
**Version:** 1.0

Extracted rules inside block: NONE

## 1796659d276b4a2d — brand-lock-extractor/examples/brand-lock.md:1-1 (heading)

# Brand Lock: Northwind Coffee Roasters

Extracted rules inside block: NONE

## 674f1c1172911be4 — brand-lock-extractor/examples/brand-lock.md:3-3 (heading)

## Identity

Extracted rules inside block: NONE

## ebfdd79ef7f799b7 — brand-lock-extractor/examples/brand-lock.md:5-8 (paragraph)

**Brand:** Northwind Coffee Roasters
**One-line description:** Small-batch coffee, roasted and shipped the same morning, with full origin transparency, for people who want real coffee and no subscription to babysit.
**Archetype:** Maker, with a Rebel edge against pretension (frames the category's problem as cheap beans hidden behind burnt roasts and luxury pricing).
**Voice posture:** Plainspoken and confident. Short declaratives, dry, no decoration.

Extracted rules inside block: NONE

## 766ab427cd791243 — brand-lock-extractor/examples/brand-lock.md:10-10 (heading)

## Palette

Extracted rules inside block: NONE

## 8df52a9754993ec5 — brand-lock-extractor/examples/brand-lock.md:12-12 (paragraph)

Every hex value here is allowed. Anything outside this list is not.

Extracted rules inside block: NONE

## 97ef6f9952b9c5e1 — brand-lock-extractor/examples/brand-lock.md:14-14 (table_row)

| Role | Hex | Use |

Extracted rules inside block: 6c25ef1475f6

## 0bb3adf8848ac867 — brand-lock-extractor/examples/brand-lock.md:16-16 (table_row)

| Background | `#F4EFE6` | Paper cream, primary canvas |

Extracted rules inside block: NONE

## ddfa4107dd6e875c — brand-lock-extractor/examples/brand-lock.md:17-17 (table_row)

| Ink | `#2B2018` | Espresso brown, primary text and dark elements |

Extracted rules inside block: NONE

## f2708742573fc3b3 — brand-lock-extractor/examples/brand-lock.md:18-18 (table_row)

| Accent | `#C5562B` | Ember, highlights and CTAs |

Extracted rules inside block: NONE

## 1a9ed2a20bb2f92a — brand-lock-extractor/examples/brand-lock.md:19-19 (table_row)

| Muted | `#8A8076` | Stone, secondary text and captions |

Extracted rules inside block: NONE

## 10bb597c245fd127 — brand-lock-extractor/examples/brand-lock.md:20-20 (table_row)

| Rule | `#DCD3C4` | Borders and dividers |

Extracted rules inside block: NONE

## 6f4d25388fac787c — brand-lock-extractor/examples/brand-lock.md:22-22 (heading)

## Typography

Extracted rules inside block: NONE

## be0a19c8ff804cb7 — brand-lock-extractor/examples/brand-lock.md:24-25 (paragraph)

**Display font:** `Tiempos Headline Semibold`, serif
**Body font:** `Söhne Regular`, sans-serif, Medium for emphasis

Extracted rules inside block: NONE

## 3958d0d1e553ea1a — brand-lock-extractor/examples/brand-lock.md:27-27 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## feea7ad6c6675963 — brand-lock-extractor/examples/brand-lock.md:29-29 (list_item)

- plainspoken, not precious

Extracted rules inside block: NONE

## 8f7a6f007c3e5806 — brand-lock-extractor/examples/brand-lock.md:30-30 (list_item)

- warm, not cozy-cute

Extracted rules inside block: NONE

## c899299f42855dfe — brand-lock-extractor/examples/brand-lock.md:31-31 (list_item)

- honest about origin

Extracted rules inside block: NONE
