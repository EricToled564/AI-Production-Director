# Source coverage review 52/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 539de656a5b09628 — image/references/nano-banana.md:11-11 (heading)

## Стиль промпта

Extracted rules inside block: NONE

## 1f9298bc239c3edf — image/references/nano-banana.md:13-14 (paragraph)

Натуральный язык, 1-2 параграфа. Структура свободная, но порядок помогает:
**Subject + Action + Location/context + Composition + Style**

Extracted rules inside block: NONE

## 61422c2720c43917 — image/references/nano-banana.md:16-20 (code)

```
A cinematic wide shot of a futuristic sports car speeding through a rainy
Tokyo street at night. Neon signs reflect off wet pavement and metallic
chassis. Format: 16:9.
```

Extracted rules inside block: NONE

## 419de28ea31f3c70 — image/references/nano-banana.md:22-22 (heading)

## Что НЕ указывать

Extracted rules inside block: NONE

## 0f79d102f4726208 — image/references/nano-banana.md:24-24 (list_item)

- Числовые параметры объектива: **50mm, 85mm, f/2.8, ISO 400** — NB игнорит. Используй описание: «shallow depth of field», «wide-angle distortion».

Extracted rules inside block: 01542139be03

## 82eacbd660466480 — image/references/nano-banana.md:25-25 (list_item)

- Tag-soup: «cool, modern, 4k, cinematic» — пишет связным предложением.

Extracted rules inside block: NONE

## 8a28de2a6fcb9623 — image/references/nano-banana.md:27-27 (heading)

## Уникальные возможности

Extracted rules inside block: NONE

## 6f5271817574d654 — image/references/nano-banana.md:29-29 (heading)

### Image Grounding (NB2 only)

Extracted rules inside block: NONE

## 2042c010bc23b580 — image/references/nano-banana.md:30-30 (paragraph)

NB2 ищет реальные изображения в интернете до генерации. Архитектурно точные конкретные локации, корректные виды животных/растений.

Extracted rules inside block: NONE

## 9866d73d5bf5a30c — image/references/nano-banana.md:32-36 (code)

```
Generate a cinematic, golden-hour photograph of [SPECIFIC REAL PLACE].
Ensure the architectural details, the spire, the surrounding square, and
the landscape are accurate to reality.
```

Extracted rules inside block: NONE

## 74e9ba0b039ebbc5 — image/references/nano-banana.md:38-39 (paragraph)

**Работает:** здания, мосты, площади, виды животных, виды растений, насекомые.
**Не работает:** конкретные люди.

Extracted rules inside block: NONE

## 5cab061f7d3bd5c8 — image/references/nano-banana.md:41-41 (heading)

### Extreme Aspect Ratios (NB2 only)

Extracted rules inside block: NONE

## 393b3cfc0a716c4e — image/references/nano-banana.md:43-43 (paragraph)

1:8, 8:1, 1:4, 4:1 — для баннеров, скроллов, комикс-стрипов.

Extracted rules inside block: NONE

## 9007b7f89ea472a1 — image/references/nano-banana.md:45-49 (code)

```
Create a 4-panel horizontal comic strip (aspect ratio 4:1).
The story follows [CHARACTER] doing [ACTION] that ends with a twist.
Use a vibrant comic book style. Keep character design consistent.
```

Extracted rules inside block: NONE

## cfee8338e702ae46 — image/references/nano-banana.md:51-51 (paragraph)

Стандартные: 1:1, 3:2, 2:3, 3:4, 4:3, 4:5, 5:4, 9:16, 16:9, 21:9.

Extracted rules inside block: NONE

## 68474e26d69d2d2e — image/references/nano-banana.md:53-53 (heading)

### Thinking Mode

Extracted rules inside block: NONE

## 081fcb3e8bd83b63 — image/references/nano-banana.md:55-55 (paragraph)

Включён по умолчанию; у NBP отключить нельзя (модель рисует до 2 «thought images» в бэкенде, они не тарифицируются как картинки, но thinking-токены платные). У NB2 есть рычаг `thinking_level: minimal | high` (default `minimal`) — поднимай до `high` для:

Extracted rules inside block: c7134d178923

## 3ec2adee41114c64 — image/references/nano-banana.md:56-56 (list_item)

- Невнятных результатов, требующих reasoning

Extracted rules inside block: NONE

## ad09de42535a8ec0 — image/references/nano-banana.md:57-57 (list_item)

- Сложных инфографик со spatial logic

Extracted rules inside block: NONE

## 21733a4141a45172 — image/references/nano-banana.md:58-58 (list_item)

- Grounding + spatial reasoning одновременно

Extracted rules inside block: NONE

## 7dc13ff98308528b — image/references/nano-banana.md:60-60 (heading)

### Multi-Reference (лимиты по тирам)

Extracted rules inside block: NONE

## 5111a05947c4de80 — image/references/nano-banana.md:62-62 (table_row)

| | NB2 Lite | NB2 | NBP |

Extracted rules inside block: NONE

## b643e7cc8330b087 — image/references/nano-banana.md:64-64 (table_row)

| High-fidelity объекты | до 14 | до 10 | до 6 |

Extracted rules inside block: NONE

## cde66426cbb40146 — image/references/nano-banana.md:65-65 (table_row)

| Character-consistency рефы | нет | до 4 | до 5 |

Extracted rules inside block: NONE

## bf751031ebe3bf55 — image/references/nano-banana.md:66-66 (table_row)

| Style рефы | нет | нет | до 3 |

Extracted rules inside block: NONE

## 7a5d446614fc5cd4 — image/references/nano-banana.md:68-74 (code)

```
[Image 1: face]
[Image 2: outfit]
[Image 3: background]
Combine: face from Image 1, outfit style from Image 2, setting from Image 3.
Match lighting and perspective.
```

Extracted rules inside block: NONE

## 5f5dda2b54d3d037 — image/references/nano-banana.md:76-76 (heading)

### JSON для сложных сцен (5+ элементов)

Extracted rules inside block: NONE

## 91d7afe9d0581a3d — image/references/nano-banana.md:78-84 (code)

```json
{
  "subject": {"description": "main subject", "expression": "emotion/pose"},
  "photography": {"angle": "eye-level", "shot_type": "waist-up", "aspect_ratio": "16:9"},
  "background": {"setting": "location", "lighting": "soft natural"}
}
```

Extracted rules inside block: NONE

## 400bbb4613116192 — image/references/nano-banana.md:86-86 (heading)

## Editing у Nano Banana

Extracted rules inside block: NONE

## 55a7a77f74b0e546 — image/references/nano-banana.md:88-88 (paragraph)

Conversational, без масок:

Extracted rules inside block: NONE
