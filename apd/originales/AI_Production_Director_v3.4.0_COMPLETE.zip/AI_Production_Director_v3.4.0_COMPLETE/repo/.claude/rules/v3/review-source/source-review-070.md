# Source coverage review 70/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## af0843ba9ec07c14 — image/references/slides.md:256-256 (paragraph)

**Prompt:**

Extracted rules inside block: NONE

## 205191d7ca05c6ef — image/references/slides.md:257-261 (code)

```
Layout: split-screen [RATIO]
Left: [CONTENT], Right: [CONTENT]
Divider: [sharp / gradient / none]
```

Extracted rules inside block: NONE

## ade8ee0b950afc9e — image/references/slides.md:265-265 (heading)

### Brutalist

Extracted rules inside block: NONE

## 67c300599d38fc25 — image/references/slides.md:267-267 (paragraph)

Сырая эстетика, огромные шрифты, яркие цвета.

Extracted rules inside block: NONE

## ca531b3b3dc31ba7 — image/references/slides.md:269-269 (paragraph)

**Rules:**

Extracted rules inside block: NONE

## 63f7671cb849efb2 — image/references/slides.md:270-270 (list_item)

- Сохраняй чёткую навигацию и иерархию

Extracted rules inside block: NONE

## c1f082c000967faa — image/references/slides.md:271-271 (list_item)

- Читабельность > экспрессия

Extracted rules inside block: NONE

## 73d676425da8e2f8 — image/references/slides.md:272-272 (list_item)

- Применяй селективно: яркие цвета ИЛИ огромные шрифты

Extracted rules inside block: NONE

## e4e26b53e6e4b8cd — image/references/slides.md:274-275 (paragraph)

**Применять:** портфолио художников, fashion, стартапы
**НЕ применять:** e-commerce, корпораты, образование, финтех

Extracted rules inside block: NONE

## 9c718674671a03e2 — image/references/slides.md:277-277 (paragraph)

**Prompt:**

Extracted rules inside block: NONE

## a40a2d55b181aba6 — image/references/slides.md:278-283 (code)

```
Style: brutalist design
Typography: massive, raw
Colors: high contrast, bold
Hierarchy: clear despite unconventional styling
```

Extracted rules inside block: NONE

## 92c19d48d0d611e7 — image/references/slides.md:287-287 (heading)

## Futuristic / SaaS Style

Extracted rules inside block: NONE

## f12b581a3deb4d7b — image/references/slides.md:289-289 (paragraph)

Apple Keynote minimalism + glassmorphism + 3D objects.

Extracted rules inside block: NONE

## 450a52ee637b942c — image/references/slides.md:291-291 (heading)

### Visual Language

Extracted rules inside block: NONE

## b2b8bad9c306ebd0 — image/references/slides.md:292-298 (code)

```
Style: Apple Keynote + SaaS + glassmorphism
Mood: premium, immersive, clean, breathable
Lighting: volumetric, ray-traced reflections, ambient occlusion
Base: deep void black OR pure ceramic white
Accents: aurora gradients (neon purple, electric blue, coral, cyan)
```

Extracted rules inside block: NONE

## d01f5f46d65d4dcc — image/references/slides.md:300-300 (heading)

### Glassmorphism Cards

Extracted rules inside block: NONE

## a8270d1a5e841802 — image/references/slides.md:301-306 (code)

```
Material: frosted glass with blur
Edges: delicate white borders
Shadow: soft, diffused
Spacing: generous internal whitespace
```

Extracted rules inside block: NONE

## 037c712fae127da7 — image/references/slides.md:308-308 (heading)

### 3D Visual Anchors

Extracted rules inside block: NONE

## b2d774b9eb2480ef — image/references/slides.md:309-314 (code)

```
Purpose: abstract 3D artifacts as focal points
Materials: polished metal, iridescent acrylic, transparent glass, soft silicone
Shapes: capsules, spheres, shields, Möbius strips, fluid waves
Quality: looks like expensive collectibles
```

Extracted rules inside block: NONE

## c5bfeec798d87b24 — image/references/slides.md:316-316 (heading)

### Composition by Type

Extracted rules inside block: NONE

## 333107021334311c — image/references/slides.md:318-320 (paragraph)

**Cover:** huge 3D glass object center + bold title + aurora background
**Content:** bento grid + 3D icons in small cards + text in large cards  
**Data:** split-screen (text left, glowing 3D chart right)

Extracted rules inside block: NONE

## 0c0f9a0e3bf31878 — image/references/slides.md:322-322 (heading)

### Charts Style

Extracted rules inside block: NONE

## 6f36bf52daeff5fe — image/references/slides.md:323-328 (code)

```
3D donut charts, glowing
Capsule-shaped progress bars
Floating numbers with neon glow
Style: looks like glowing neon toys
```

Extracted rules inside block: NONE

## 36fdf1a143815e7e — image/references/slides.md:330-330 (heading)

### Example Prompt

Extracted rules inside block: NONE

## e3f18b132e41836b — image/references/slides.md:331-345 (code)

```
Create a futuristic SaaS slide for product presentation.

Style: Apple Keynote + glassmorphism.
Mood: premium, immersive, clean.
Background: void black with aurora gradient (purple → cyan).

Layout: bento grid, 6 blocks.
Cards: frosted glass, blur, white edges, soft shadows.
Hero block: floating iridescent sphere.
Data blocks: glowing 3D donut chart, neon metrics.

Typography: clean sans-serif, high contrast white.
Format: 16:9
```

Extracted rules inside block: NONE

## 6a0e3b637f73ee84 — image/references/slides.md:349-349 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 354ebaa4903f75a8 — image/references/storyboards.md:1-1 (heading)

# Storyboards & Sequential Art

Extracted rules inside block: NONE

## 39802c4af02ee14d — image/references/storyboards.md:3-3 (paragraph)

One-shot narrative sequences. Concept art. Consistent across frames.

Extracted rules inside block: NONE

## 7a8df43f43a63d6d — image/references/storyboards.md:5-5 (heading)

## Story Sequence

Extracted rules inside block: NONE

## 41ab289a3a65f1d3 — image/references/storyboards.md:7-18 (code)

```
Create [NUMBER]-part story with [NUMBER] images.

Characters: [DESCRIPTION]
Setting: [LOCATION/CONTEXT]
Story arc: [NARRATIVE with emotional highs/lows]

Identity: Characters and attire consistent throughout.
Variation: Different angles, distances, expressions.
Generate: One image at a time.
Format: [ASPECT RATIO] per image.
```

Extracted rules inside block: NONE
