# Source coverage review 46/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 34684d0710c88095 — image/references/gpt-image.md:182-182 (heading)

## Migration from Older GPT-Image

Extracted rules inside block: NONE

## 23be32b3fd39de82 — image/references/gpt-image.md:184-184 (list_item)

- Промпты в основном переносятся как есть.

Extracted rules inside block: NONE

## ff9af59707f94020 — image/references/gpt-image.md:185-185 (list_item)

- После переноса — посмотри качество, latency, retry-rate; ретюнь.

Extracted rules inside block: NONE

## db7041d0c45ae646 — image/references/gpt-image.md:186-186 (list_item)

- `gpt-image-1-mini` — только если главное снизить цену batch'а на низкорисковых задачах.

Extracted rules inside block: NONE

## 07b256049f72914e — image/references/gpt-image.md:190-190 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 7b4ce63b633ab642 — image/references/models.md:1-1 (heading)

# Model Selection — Nano Banana vs GPT Image 2

Extracted rules inside block: NONE

## 61165e943482e4bf — image/references/models.md:3-3 (paragraph)

Skill пишет промпты под две семьи моделей. Они мыслят по-разному — выбор модели меняет структуру промпта.

Extracted rules inside block: NONE

## c0e18f2974caf465 — image/references/models.md:5-5 (heading)

## TL;DR

Extracted rules inside block: NONE

## 4d34dc5d3f82510f — image/references/models.md:7-7 (table_row)

| Задача | Модель |

Extracted rules inside block: NONE

## 0e362870b5d75e65 — image/references/models.md:9-9 (table_row)

| Реальное место/объект (с грунтингом) | **Nano Banana** (NB2/NBP) |

Extracted rules inside block: NONE

## e8b13f2f6cc8387b — image/references/models.md:10-10 (table_row)

| Сложная сцена с физикой/композицией | **Nano Banana Pro** |

Extracted rules inside block: NONE

## 1fbbc8fe5deef52b — image/references/models.md:11-11 (table_row)

| Длинные горизонтальные/вертикальные форматы (1:8, 8:1, 4:1) | **Nano Banana** (только NB поддерживает экстрим) |

Extracted rules inside block: NONE

## b4ee98784817c8fa — image/references/models.md:12-12 (table_row)

| Дешёвая массовая генерация | **Nano Banana 2 Lite** или **gpt-image-1-mini** |

Extracted rules inside block: NONE

## b02ac5f1bb22eb91 — image/references/models.md:13-13 (table_row)

| Фотореализм с тонкой типографикой/UI | **GPT Image 2** |

Extracted rules inside block: NONE

## 4d576e3f68d39519 — image/references/models.md:14-14 (table_row)

| Точное editing с preservation (try-on, swap, weather) | **GPT Image 2** (в editing у него лучшая identity-preservation) |

Extracted rules inside block: NONE

## 873706bd2095485c — image/references/models.md:15-15 (table_row)

| Маленький плотный текст в кадре | **GPT Image 2** (`quality: high`) |

Extracted rules inside block: NONE

## 3a7cdc153ba8c77d — image/references/models.md:16-16 (table_row)

| Брендовая полиграфия / постеры с EXACT TEXT | **GPT Image 2** |

Extracted rules inside block: NONE

## 62180a687593b7d9 — image/references/models.md:17-17 (table_row)

| Сториборды, комиксы (последовательность) | **Nano Banana** (extreme ratios + thinking) |

Extracted rules inside block: NONE

## 4d8e3458b579dbfa — image/references/models.md:18-18 (table_row)

| Storyboard с фокусом на типографике | **GPT Image 2** |

Extracted rules inside block: NONE

## 976f411cc0253223 — image/references/models.md:19-19 (table_row)

| Style transfer без упоминаемых референс-картинок | **GPT Image 2** (concrete visual targets) |

Extracted rules inside block: NONE

## 25df7f065b3e12c8 — image/references/models.md:20-20 (table_row)

| Рендер из 14+ референсов | **Nano Banana Pro** (до 14) или **GPT Image 2** (до 16) |

Extracted rules inside block: NONE

## e58ae9cedd8e75de — image/references/models.md:22-22 (heading)

## Когда что выигрывает

Extracted rules inside block: NONE

## e401f87a7d84fa94 — image/references/models.md:24-24 (heading)

### Nano Banana выигрывает в

Extracted rules inside block: NONE

## 7dfcdfec242f4ce8 — image/references/models.md:25-25 (list_item)

- **Image grounding.** NB2 ищет реальные изображения в интернете перед генерацией — точная архитектура конкретного храма, моста, площади; конкретные виды животных, растений. GPT Image 2 этого не делает.

Extracted rules inside block: NONE

## dc01974065aaeb59 — image/references/models.md:26-26 (list_item)

- **Экстремальные пропорции.** 1:8, 8:1, 1:4, 4:1 — баннеры, скроллы, комикс-стрипы. У GPT Image 2 max 3:1.

Extracted rules inside block: NONE

## ddadaecd6c487300 — image/references/models.md:27-27 (list_item)

- **«Thinking» режим.** Сложные инфографики со spatial logic.

Extracted rules inside block: NONE

## 7140234f8dbd0067 — image/references/models.md:28-28 (list_item)

- **Цена/скорость.** NB2 = $0.04/img.

Extracted rules inside block: NONE

## 8f3a72878dfcce15 — image/references/models.md:30-30 (heading)

### GPT Image 2 выигрывает в

Extracted rules inside block: NONE

## 84e86bce0f5c551c — image/references/models.md:31-31 (list_item)

- **Identity preservation в edit.** Меняешь одежду / погоду / фон — лицо, поза, геометрия не плывут. Двухколоночная логика (change / preserve) работает как контракт.

Extracted rules inside block: NONE

## 4793e67e889165ff — image/references/models.md:32-32 (list_item)

- **Тонкий текст в кадре.** Маленькие подписи, легенды, footnotes, multi-font layouts. На `quality: high` рендерит чётче.

Extracted rules inside block: NONE
