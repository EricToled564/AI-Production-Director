# Source coverage review 35/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 8ca65a633979b943 — image/references/characters.md:66-66 (list_item)

- "Standing with arms crossed"

Extracted rules inside block: NONE

## dc861890740d5286 — image/references/characters.md:67-67 (list_item)

- "Mid-stride, dynamic motion"

Extracted rules inside block: NONE

## a01d3a19fa0626e6 — image/references/characters.md:68-68 (list_item)

- "Seated, leaning forward"

Extracted rules inside block: NONE

## 30512f26f619c226 — image/references/characters.md:70-70 (heading)

## Attire Changes

Extracted rules inside block: NONE

## e0a49d1336188d89 — image/references/characters.md:72-72 (list_item)

- "Same person, but wearing [NEW OUTFIT]"

Extracted rules inside block: NONE

## 3425a1364fc2ac9a — image/references/characters.md:73-73 (list_item)

- "Keep face, change to formal business attire"

Extracted rules inside block: NONE

## ffea0b44bcb11699 — image/references/characters.md:74-74 (list_item)

- "Maintain identity, add [ACCESSORY]"

Extracted rules inside block: NONE

## 93b11b2cb53cc346 — image/references/characters.md:76-76 (heading)

## Environment Swaps

Extracted rules inside block: NONE

## bdd170cbff6e5911 — image/references/characters.md:78-78 (list_item)

- "Same person in [NEW SETTING]"

Extracted rules inside block: NONE

## 3a8c0769e6bc4c45 — image/references/characters.md:79-79 (list_item)

- "Transport to [LOCATION], keep identity"

Extracted rules inside block: NONE

## 00deacf2718762ab — image/references/characters.md:80-80 (list_item)

- "Change background to [SCENE], maintain lighting on face"

Extracted rules inside block: NONE

## d3531e62acbd523d — image/references/characters.md:84-84 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 7e1d46b3f646289e — image/references/creative-direction.md:1-1 (heading)

# Creative Direction

Extracted rules inside block: NONE

## 14c00130610b94d2 — image/references/creative-direction.md:3-3 (paragraph)

Studio-quality controls for lighting, camera, color, and materiality.

Extracted rules inside block: NONE

## 5b0bc355062fa940 — image/references/creative-direction.md:5-5 (heading)

## Lighting Design

Extracted rules inside block: NONE

## 9710f9b1c6eeaf62 — image/references/creative-direction.md:7-7 (paragraph)

Tell the model exactly how the scene is illuminated.

Extracted rules inside block: NONE

## 3d3f97c3a3364452 — image/references/creative-direction.md:9-9 (paragraph)

**Studio setups:**

Extracted rules inside block: NONE

## da3f20869737c98e — image/references/creative-direction.md:10-10 (list_item)

- "Three-point softbox setup" — even product/portrait lighting

Extracted rules inside block: NONE

## 1fa72706c5ce25d8 — image/references/creative-direction.md:11-11 (list_item)

- "Single key light from upper left" — dramatic shadow

Extracted rules inside block: NONE

## e2d493fa1033e96e — image/references/creative-direction.md:12-12 (list_item)

- "Ring light, frontal" — beauty/fashion, flat lighting

Extracted rules inside block: NONE

## ce250a77591c6905 — image/references/creative-direction.md:14-14 (paragraph)

**Dramatic effects:**

Extracted rules inside block: NONE

## 941f22ffde7570ab — image/references/creative-direction.md:15-15 (list_item)

- "Chiaroscuro lighting with harsh, high contrast"

Extracted rules inside block: NONE

## 2673ddb60a006936 — image/references/creative-direction.md:16-16 (list_item)

- "Golden hour backlighting creating long shadows"

Extracted rules inside block: NONE

## c73ca22265f5d846 — image/references/creative-direction.md:17-17 (list_item)

- "Rim lighting, subject silhouetted against bright background"

Extracted rules inside block: NONE

## 29b474ffb2cf1b82 — image/references/creative-direction.md:18-18 (list_item)

- "Volumetric god rays through window"

Extracted rules inside block: NONE

## 4716a7b24b037853 — image/references/creative-direction.md:19-19 (list_item)

- "Neon underglow, cyberpunk street"

Extracted rules inside block: NONE

## 2d08d561e53ce0df — image/references/creative-direction.md:21-21 (paragraph)

**Natural:**

Extracted rules inside block: NONE

## 937f515553afa311 — image/references/creative-direction.md:22-22 (list_item)

- "Soft overcast daylight, even diffusion"

Extracted rules inside block: NONE

## c606749c538a78bf — image/references/creative-direction.md:23-23 (list_item)

- "Dappled sunlight through trees"

Extracted rules inside block: NONE

## f65bb2fa25fa30f9 — image/references/creative-direction.md:24-24 (list_item)

- "Blue hour, cold ambient light"

Extracted rules inside block: NONE
