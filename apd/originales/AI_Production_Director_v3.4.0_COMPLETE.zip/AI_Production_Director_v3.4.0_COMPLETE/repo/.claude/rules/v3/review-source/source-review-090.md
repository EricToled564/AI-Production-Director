# Source coverage review 90/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 6c134e36bb981e82 — screenwriter/references/pipeline-integration.md:51-51 (list_item)

- Avoid: "the character feels anxious" (this describes internal state, not mood)

Extracted rules inside block: 92ff35c80322

## 6f310cb90cc1c733 — screenwriter/references/pipeline-integration.md:53-53 (paragraph)

**Character Lists:**

Extracted rules inside block: NONE

## f94f40610a69cf41 — screenwriter/references/pipeline-integration.md:54-60 (code)

```xml
<!-- Single character -->
<characters>Unit-7</characters>

<!-- Multiple characters -->
<characters>Sarah, Marcus, Tech-Bot</characters>
```

Extracted rules inside block: NONE

## 6f24694ffc9a25ea — screenwriter/references/pipeline-integration.md:64-64 (heading)

## Imagine-Ready Visual Descriptions

Extracted rules inside block: NONE

## 1db7ee63ff6a69c3 — screenwriter/references/pipeline-integration.md:66-66 (heading)

### Visual Element Extraction

Extracted rules inside block: NONE

## 41d4e58f9427c260 — screenwriter/references/pipeline-integration.md:68-68 (paragraph)

The `key_visuals` array should contain discrete, image-generation-friendly descriptions:

Extracted rules inside block: 92adcfb1eaaf

## 31753acfbca20f39 — screenwriter/references/pipeline-integration.md:70-70 (paragraph)

**Example Scene Action:**

Extracted rules inside block: NONE

## 45e06b72a7bb0a6e — screenwriter/references/pipeline-integration.md:71-73 (code)

```
A BOXY ROBOT (Unit-7, weathered chrome with a single blue optical sensor) rolls through fog-shrouded streets. Neon signs flicker overhead, casting pink and cyan reflections on wet pavement.
```

Extracted rules inside block: NONE

## 6d8e9c630c7a43ad — screenwriter/references/pipeline-integration.md:75-75 (paragraph)

**Extracted key_visuals:**

Extracted rules inside block: NONE

## 684ef5ad70f773c8 — screenwriter/references/pipeline-integration.md:76-82 (code)

```xml
<key_visuals>
  <visual>boxy robot with weathered chrome body and single blue optical sensor</visual>
  <visual>fog-shrouded cyberpunk street with flickering neon signs</visual>
  <visual>pink and cyan neon reflections on wet pavement</visual>
</key_visuals>
```

Extracted rules inside block: NONE

## 68d81c1902882be9 — screenwriter/references/pipeline-integration.md:84-84 (heading)

### Visual Description Best Practices

Extracted rules inside block: NONE

## 87e8299a02ac963a — screenwriter/references/pipeline-integration.md:86-86 (paragraph)

**Composition Elements:**

Extracted rules inside block: NONE

## 5f0c61363399af11 — screenwriter/references/pipeline-integration.md:87-87 (list_item)

- Subject: Main focus (character, object)

Extracted rules inside block: NONE

## e17f065aeb07bf69 — screenwriter/references/pipeline-integration.md:88-88 (list_item)

- Setting: Environment and background

Extracted rules inside block: NONE

## ce6b4eeec45da1a4 — screenwriter/references/pipeline-integration.md:89-89 (list_item)

- Lighting: Light quality, direction, color

Extracted rules inside block: NONE

## 762b78d97f6d643d — screenwriter/references/pipeline-integration.md:90-90 (list_item)

- Atmosphere: Weather, air quality, mood

Extracted rules inside block: NONE

## 4531360ea68a6834 — screenwriter/references/pipeline-integration.md:91-91 (list_item)

- Details: Significant props or textures

Extracted rules inside block: NONE

## aed4091e200703c2 — screenwriter/references/pipeline-integration.md:93-93 (paragraph)

**Example - Layered Visual:**

Extracted rules inside block: NONE

## 3f662288139ad3cd — screenwriter/references/pipeline-integration.md:94-100 (code)

```
Subject: "weathered robot with blue optical sensor"
Setting: "abandoned industrial warehouse, broken windows"
Lighting: "harsh afternoon sunlight streaming through gaps"
Atmosphere: "dust particles floating in light beams"
Details: "rusted machinery, scattered tools"
```

Extracted rules inside block: NONE

## 7ac0774488f4c4ee — screenwriter/references/pipeline-integration.md:102-102 (heading)

### Color and Lighting Vocabulary

Extracted rules inside block: NONE

## 2be48c7b5bdd535d — screenwriter/references/pipeline-integration.md:104-104 (paragraph)

**Color Descriptors:**

Extracted rules inside block: NONE

## 84a3a5d0c24acd43 — screenwriter/references/pipeline-integration.md:105-105 (list_item)

- Warm: amber, golden, crimson, burnt orange

Extracted rules inside block: NONE

## ee339b799eaa4ec6 — screenwriter/references/pipeline-integration.md:106-106 (list_item)

- Cool: azure, ice blue, slate gray, mint

Extracted rules inside block: NONE

## c389f4d0f3673cef — screenwriter/references/pipeline-integration.md:107-107 (list_item)

- Neon: electric pink, cyan, magenta, lime

Extracted rules inside block: NONE

## 11a49e877c36569c — screenwriter/references/pipeline-integration.md:108-108 (list_item)

- Natural: earth tones, moss green, sand, clay

Extracted rules inside block: NONE

## 75a5786072776941 — screenwriter/references/pipeline-integration.md:110-110 (paragraph)

**Lighting Descriptors:**

Extracted rules inside block: NONE

## 20d2e66daaf02cd2 — screenwriter/references/pipeline-integration.md:111-111 (list_item)

- Quality: soft, harsh, diffused, dappled, dramatic

Extracted rules inside block: NONE

## c5c3d8ac9291bb62 — screenwriter/references/pipeline-integration.md:112-112 (list_item)

- Direction: overhead, backlighting, side-lit, rim light

Extracted rules inside block: NONE

## f0563b483c64911b — screenwriter/references/pipeline-integration.md:113-113 (list_item)

- Color: warm glow, cool blue, golden hour, neon-lit

Extracted rules inside block: NONE

## a3741997c5566e8f — screenwriter/references/pipeline-integration.md:114-114 (list_item)

- Intensity: dim, bright, shadowy, high-contrast

Extracted rules inside block: NONE
