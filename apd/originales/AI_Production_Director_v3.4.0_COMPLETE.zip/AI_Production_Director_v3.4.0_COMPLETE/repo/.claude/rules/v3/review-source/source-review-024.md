# Source coverage review 24/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 40ae908c06a134c0 — brand-lock-extractor/brand-packs/_template.md:62-62 (heading)

## Color grade direction

Extracted rules inside block: NONE

## 6fdb9de5d47ef98d — brand-lock-extractor/brand-packs/_template.md:64-64 (paragraph)

How footage and generated images should be graded. One sentence.

Extracted rules inside block: 1c4e1a34a49b

## b18b2c0b33fe78b5 — brand-lock-extractor/brand-packs/_template.md:66-66 (list_item)

> e.g. "Warm filmic, muted teal shadows, slight grain. Reminiscent of Kodak Portra 400."

Extracted rules inside block: NONE

## bc32227510e5b8a0 — brand-lock-extractor/brand-packs/_template.md:68-68 (heading)

## Motion language

Extracted rules inside block: NONE

## a87c6053e8e78fa3 — brand-lock-extractor/brand-packs/_template.md:70-70 (paragraph)

How motion behaves in this brand's content. One paragraph.

Extracted rules inside block: NONE

## decac514e68d994d — brand-lock-extractor/brand-packs/_template.md:72-72 (list_item)

> e.g. "Camera moves are minimal and deliberate. Static or slow-push. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling text."

Extracted rules inside block: 4d6b16d72e53

## 7bf906728720e799 — brand-lock-extractor/brand-packs/_template.md:74-74 (heading)

## Voice rules

Extracted rules inside block: NONE

## 9a6dae25e2a184ac — brand-lock-extractor/brand-packs/_template.md:76-76 (paragraph)

Copy-level rules that apply to VO and on-screen text.

Extracted rules inside block: NONE

## 8b8fb8045e1bdd96 — brand-lock-extractor/brand-packs/_template.md:78-78 (list_item)

- e.g. no em dashes

Extracted rules inside block: NONE

## f4146da07efc4a6f — brand-lock-extractor/brand-packs/_template.md:79-79 (list_item)

- no emojis in body copy

Extracted rules inside block: NONE

## f993408ec00bf771 — brand-lock-extractor/brand-packs/_template.md:80-80 (list_item)

- no exclamation points in headlines

Extracted rules inside block: NONE

## 748eaaa6218f5872 — brand-lock-extractor/brand-packs/_template.md:81-81 (list_item)

- no clichéd metaphors ("game-changing", "revolutionary", "next-level")

Extracted rules inside block: NONE

## f9a40cde798216c2 — brand-lock-extractor/brand-packs/_template.md:82-82 (list_item)

- no hype words

Extracted rules inside block: NONE

## c02646cf4ab716c8 — brand-lock-extractor/brand-packs/_template.md:84-84 (heading)

## Reference materials

Extracted rules inside block: NONE

## ba9081210a6a7cd5 — brand-lock-extractor/brand-packs/_template.md:86-86 (paragraph)

Optional. Links to past work, mood boards, or style guides that further define the brand.

Extracted rules inside block: NONE

## e5caa48c7115b3a4 — brand-lock-extractor/brand-packs/_template.md:88-88 (list_item)

- Link to brand guide

Extracted rules inside block: NONE

## a39f9fa981b11aee — brand-lock-extractor/brand-packs/_template.md:89-89 (list_item)

- Link to past hero film

Extracted rules inside block: NONE

## 3420a5d9ae3b6d8b — brand-lock-extractor/brand-packs/_template.md:90-90 (list_item)

- Link to mood board

Extracted rules inside block: NONE

## 1d2849b60e837aed — brand-lock-extractor/brand-packs/_template.md:94-96 (paragraph)

**Last updated:** YYYY-MM-DD
**Owner:** name / role
**Version:** 1.0

Extracted rules inside block: NONE

## 10849184ad0dd1ab — brand-lock-extractor/brand-packs/examples/saas-clean.md:1-1 (heading)

# Brand Lock: Acme SaaS (Example)

Extracted rules inside block: NONE

## 2685c35e3085026c — brand-lock-extractor/brand-packs/examples/saas-clean.md:3-3 (list_item)

> Reference example for B2B SaaS brands. Restrained, professional, single-accent palette.

Extracted rules inside block: NONE

## 98de6e93d1b983c3 — brand-lock-extractor/brand-packs/examples/saas-clean.md:5-5 (heading)

## Identity

Extracted rules inside block: NONE

## 1ff8baae333a6ef0 — brand-lock-extractor/brand-packs/examples/saas-clean.md:7-10 (paragraph)

**Brand:** Acme SaaS
**One-line description:** B2B platform that helps SaaS teams cut churn 40% in 90 days through customer health scoring and intervention workflows.
**Archetype:** Sage
**Voice posture:** Confident, data-driven, peer-to-peer (not vendor-to-buyer)

Extracted rules inside block: NONE

## a62f7babcd254c74 — brand-lock-extractor/brand-packs/examples/saas-clean.md:12-12 (heading)

## Palette

Extracted rules inside block: NONE

## 42dd96fbeb343288 — brand-lock-extractor/brand-packs/examples/saas-clean.md:14-14 (table_row)

| Role | Hex | Use |

Extracted rules inside block: 341af56c8857

## 57364f9211aa16d6 — brand-lock-extractor/brand-packs/examples/saas-clean.md:16-16 (table_row)

| Background | `#FFFFFF` | Pure white, primary canvas |

Extracted rules inside block: NONE

## 341980f93f37884e — brand-lock-extractor/brand-packs/examples/saas-clean.md:17-17 (table_row)

| Ink | `#0F1F3A` | Deep navy, primary text |

Extracted rules inside block: NONE

## 6250796d996bd2a5 — brand-lock-extractor/brand-packs/examples/saas-clean.md:18-18 (table_row)

| Accent | `#3B82F6` | Bright blue. CTAs, data highlights |

Extracted rules inside block: NONE

## 4fd6a666b94c1330 — brand-lock-extractor/brand-packs/examples/saas-clean.md:19-19 (table_row)

| Muted | `#64748B` | Slate, secondary text, captions |

Extracted rules inside block: NONE

## 65cad210bbdcdd69 — brand-lock-extractor/brand-packs/examples/saas-clean.md:20-20 (table_row)

| Rule | `#E2E8F0` | Light gray, borders, dividers |

Extracted rules inside block: NONE
