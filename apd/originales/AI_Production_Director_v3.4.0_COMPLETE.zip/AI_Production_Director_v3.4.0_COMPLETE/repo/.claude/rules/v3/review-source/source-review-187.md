# Source coverage review 187/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 13b7e4f4f1bfa418 — visual-asset-critic/SKILL.md:99-100 (paragraph)

**Post-level fix**, acceptable to address in compositing. Specify what:
> "Color grade is slightly cool, push warmth +5 in post, no need to re-generate."

Extracted rules inside block: cfffb23bc07e

## 72f13f75d7bd6bd1 — visual-asset-critic/SKILL.md:102-103 (paragraph)

**Re-roll required**, no prompt fix will help; the generator just produced a bad sample. Budget 2–3 attempts:
> "Hands are mangled. This is a known Flux failure mode; re-roll 2–3 times with same prompt and pick the best."

Extracted rules inside block: a190951526cc

## 61039a1e142115c7 — visual-asset-critic/SKILL.md:105-105 (heading)

### Step 4. Verdict

Extracted rules inside block: NONE

## 98e8f6ac674c9789 — visual-asset-critic/SKILL.md:107-107 (table_row)

| Verdict | When |

Extracted rules inside block: NONE

## 6ce82b7904b802c4 — visual-asset-critic/SKILL.md:109-109 (table_row)

| ACCEPT | All layers pass or soft-fail in ways post can fix |

Extracted rules inside block: NONE

## 1f5588018136a0de — visual-asset-critic/SKILL.md:110-110 (table_row)

| REVISE | One or two layers hard-fail; clear fix path |

Extracted rules inside block: NONE

## cae3f4275ef267d2 — visual-asset-critic/SKILL.md:111-111 (table_row)

| REJECT | Three+ layers fail or one critical layer (Brand Lock, Series Lock) hard-fails with no clear fix |

Extracted rules inside block: NONE

## 2c11f68debe98b9b — visual-asset-critic/SKILL.md:113-113 (heading)

### Step 5. Confidence

Extracted rules inside block: NONE

## 71af8a3d437077d4 — visual-asset-critic/SKILL.md:115-115 (paragraph)

Be honest about uncertainty:

Extracted rules inside block: NONE

## 9bfedf1e56f7b519 — visual-asset-critic/SKILL.md:117-117 (table_row)

| Confidence | When |

Extracted rules inside block: NONE

## 17f82f9205f4a602 — visual-asset-critic/SKILL.md:119-119 (table_row)

| HIGH | Storyboard reference + brand-lock + prompt all available, clear assessment |

Extracted rules inside block: NONE

## bb0d3be7f3c6894b — visual-asset-critic/SKILL.md:120-120 (table_row)

| MEDIUM | Some references missing but core intent is clear |

Extracted rules inside block: NONE

## 760fd0368e031d5c — visual-asset-critic/SKILL.md:121-121 (table_row)

| LOW | Only the image, intent is inferred; verdict is your best guess |

Extracted rules inside block: NONE

## 2a57fddd0999882c — visual-asset-critic/SKILL.md:123-126 (paragraph)

HIGH is a factual claim about what you had, not a mood. `tools/validate_critique.py`
rejects a `1.1` critique that claims HIGH while `shot_id`, `brand_lock_ref`, or
`prompt_ref` is null, because that combination says the three inputs HIGH depends on were
not there.

Extracted rules inside block: NONE

## 9b20e40fbdb29584 — visual-asset-critic/SKILL.md:128-128 (heading)

### Step 6. Emit structured output (critique JSON)

Extracted rules inside block: NONE

## 1fa0c411177b3f8a — visual-asset-critic/SKILL.md:130-134 (paragraph)

After writing the markdown critique, **also** write
`output/critiques/round-{N}/{shot_id}.critique.json` conforming to
`templates/critique.schema.json` at version `1.1`. Same review, two surfaces. The markdown
is for the human; the JSON is so an automated QA loop (e.g. `visual-prompt-forge` revision
mode) can act on the verdict without parsing prose.

Extracted rules inside block: NONE

## ad3f7bfeb170ac24 — visual-asset-critic/SKILL.md:136-136 (paragraph)

**Map the markdown to the schema, section for section:**

Extracted rules inside block: NONE

## 46c15e00657edae8 — visual-asset-critic/SKILL.md:138-138 (table_row)

| Markdown | JSON field |

Extracted rules inside block: NONE

## 874e9df9d4331a59 — visual-asset-critic/SKILL.md:140-140 (table_row)

| `## Verdict` | `verdict` (`ACCEPT` / `REVISE` / `REJECT`) |

Extracted rules inside block: NONE

## 1c1773c465f15721 — visual-asset-critic/SKILL.md:141-141 (table_row)

| `## What's working` bullets | `working[]` (one string each) |

Extracted rules inside block: NONE

## ed77ddeff4a31fcb — visual-asset-critic/SKILL.md:142-142 (table_row)

| `## What's not working` + `## Revision plan` | `issues[]`, merge them: each issue carries its layer/note from "what's not working" and its `fix_type`/`fix` from the matching revision-plan line |

Extracted rules inside block: NONE

## 41e687f71ffa154e — visual-asset-critic/SKILL.md:143-143 (table_row)

| `## Confidence` | `confidence` (`HIGH` / `MEDIUM` / `LOW`) |

Extracted rules inside block: NONE

## 9b5037193d3c1612 — visual-asset-critic/SKILL.md:145-146 (paragraph)

**Provenance, all of it required at 1.1.** A verdict is a claim about specific bytes. Name
them, and hash them:

Extracted rules inside block: 683d4c48df4b

## 75891ecfa2516761 — visual-asset-critic/SKILL.md:148-148 (table_row)

| Field | Value |

Extracted rules inside block: NONE

## b9178cf961d3191f — visual-asset-critic/SKILL.md:150-150 (table_row)

| `run_id`, `round` | from `run.json` and the round directory you are writing into |

Extracted rules inside block: NONE

## 5d930673059d5cc2 — visual-asset-critic/SKILL.md:151-151 (table_row)

| `created_at` | UTC instant, `YYYY-MM-DDThh:mm:ssZ` |

Extracted rules inside block: NONE

## f8641e09240b9540 — visual-asset-critic/SKILL.md:152-152 (table_row)

| `shot_id` | the shot, or `null` for a standalone image with no storyboard |

Extracted rules inside block: NONE

## 54395a72b8d403be — visual-asset-critic/SKILL.md:153-153 (table_row)

| `image_ref`, `image_sha256` | the frame you reviewed, and its SHA-256 |

Extracted rules inside block: NONE

## 6d7882ef5ad875db — visual-asset-critic/SKILL.md:154-154 (table_row)

| `prompt_ref`, `prompt_sha256` | the prompt file it came from, and its SHA-256 |

Extracted rules inside block: NONE

## 5190c0f58e63ad52 — visual-asset-critic/SKILL.md:155-155 (table_row)

| `brand_lock_ref`, `brand_lock_sha256` | the snapshot you judged against, and its SHA-256 |

Extracted rules inside block: NONE
