# Source coverage review 142/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0f00390c6f807e9d — video/references/dramaturgy.md:138-138 (paragraph)

Fincher rule. Every camera movement answers "what changed?" If the answer is nothing, the camera is static.

Extracted rules inside block: NONE

## b08162f3a4de5f63 — video/references/dramaturgy.md:140-140 (paragraph)

Reasons for camera movement.

Extracted rules inside block: NONE

## f91e9feeeaac7c36 — video/references/dramaturgy.md:142-142 (list_item)

- A character made a decision and the camera follows the shift.

Extracted rules inside block: NONE

## e70739506359c665 — video/references/dramaturgy.md:143-143 (list_item)

- New information arrived in the frame.

Extracted rules inside block: NONE

## 6934731627d8caf5 — video/references/dramaturgy.md:144-144 (list_item)

- Pressure escalated and the camera tightens.

Extracted rules inside block: NONE

## 87053168e0eacfb5 — video/references/dramaturgy.md:145-145 (list_item)

- The character looked, and the camera reveals what they saw.

Extracted rules inside block: NONE

## ce777bf53788ee6b — video/references/dramaturgy.md:146-146 (list_item)

- A gesture pulled focus, and the camera rack-focused.

Extracted rules inside block: NONE

## 51c6253ce8b172a5 — video/references/dramaturgy.md:147-147 (list_item)

- The space changed (door opened, someone entered).

Extracted rules inside block: NONE

## 47c575880fb2fc0f — video/references/dramaturgy.md:149-150 (paragraph)

Bad. "Cinematic gliding camera movement."
Good. "Push-in starts on 'I don't know' and stops on her jaw locking."

Extracted rules inside block: 7613c1e6effb

## dc44540e8be583ce — video/references/dramaturgy.md:152-152 (heading)

## 8. Spatial clarity beats montage hysteria

Extracted rules inside block: NONE

## dcaf26f720415471 — video/references/dramaturgy.md:154-154 (paragraph)

Spielberg principle. Even in chaos, the viewer must know.

Extracted rules inside block: 7de7e7ac22e5

## 99c8d6e0622973ac — video/references/dramaturgy.md:156-156 (list_item)

- Where the hero is.

Extracted rules inside block: NONE

## c47fb7a41316118c — video/references/dramaturgy.md:157-157 (list_item)

- Where the threat is.

Extracted rules inside block: NONE

## 8fc00089ea731e68 — video/references/dramaturgy.md:158-158 (list_item)

- Which direction is escape.

Extracted rules inside block: NONE

## 8892098b8fc2c89f — video/references/dramaturgy.md:159-159 (list_item)

- Which direction is decision.

Extracted rules inside block: NONE

## 00fa89db40a1865a — video/references/dramaturgy.md:161-161 (paragraph)

High craft means fast, nervous, and still readable. Random whip-pans and strobe cuts without geography destroy drama. The fastest action scenes in cinema (Spielberg, Miller, early Bay) are built on a clear geometric map maintained through every cut.

Extracted rules inside block: NONE

## b1fe3d707e3554e4 — video/references/dramaturgy.md:163-163 (paragraph)

Before writing a fast-cut sequence, sketch the geography in one sentence. "Hero moves left-to-right. Threat enters from the top of the frame. Exit is off-camera right."

Extracted rules inside block: NONE

## 16d9639ebc67470d — video/references/dramaturgy.md:165-165 (heading)

## 9. Environment plays

Extracted rules inside block: NONE

## 9e4e4fc4a0afefce — video/references/dramaturgy.md:167-167 (paragraph)

Kurosawa principle. Weather and environment are characters. They amplify state.

Extracted rules inside block: NONE

## 9324c7667be8516d — video/references/dramaturgy.md:169-169 (paragraph)

Translate this to a short video by leaning on one environmental pressure.

Extracted rules inside block: NONE

## 8facbbb808ff32b7 — video/references/dramaturgy.md:171-171 (list_item)

- Flickering fluorescent light signals decay, bureaucracy, dread.

Extracted rules inside block: NONE

## a26cf0d7ce8b141c — video/references/dramaturgy.md:172-172 (list_item)

- Rain on a window signals grief withheld.

Extracted rules inside block: NONE

## c1df9b39117b9032 — video/references/dramaturgy.md:173-173 (list_item)

- Steam from a kettle signals suppressed anger.

Extracted rules inside block: NONE

## 4d7d9238fb1144ca — video/references/dramaturgy.md:174-174 (list_item)

- A buzzing air conditioner signals dissociation.

Extracted rules inside block: NONE

## c346a499fa7228f0 — video/references/dramaturgy.md:175-175 (list_item)

- Wet asphalt at night signals guilt.

Extracted rules inside block: NONE

## b88e20c3fff0ecb5 — video/references/dramaturgy.md:176-176 (list_item)

- A tight corridor signals the walls closing in.

Extracted rules inside block: NONE

## 52471852fea7adbd — video/references/dramaturgy.md:177-177 (list_item)

- A mirror or glass surface signals self-reckoning.

Extracted rules inside block: NONE

## b7e37cefa7913011 — video/references/dramaturgy.md:178-178 (list_item)

- Overhead cold office light signals judgment.

Extracted rules inside block: NONE

## 3e821b5a11f9fe83 — video/references/dramaturgy.md:180-180 (paragraph)

Pick one environmental pressure per scene and let it carry the emotion.

Extracted rules inside block: NONE

## edd497e333a39288 — video/references/dramaturgy.md:182-182 (heading)

## 10. Three-layer storyboard method

Extracted rules inside block: NONE
