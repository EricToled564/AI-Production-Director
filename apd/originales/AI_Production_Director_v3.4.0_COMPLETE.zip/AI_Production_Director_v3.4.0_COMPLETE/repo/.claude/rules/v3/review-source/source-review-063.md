# Source coverage review 63/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5fc460efddc0b1a6 — image/references/patterns/ui-social.md:114-114 (heading)

## Personal Color Analysis Board

Extracted rules inside block: NONE

## 5e8f3071bd930d86 — image/references/patterns/ui-social.md:116-116 (paragraph)

Use to create a visual color analysis graphic from a portrait — seasonal palette classification, clothing color comparisons, and accessory recommendations in an organized layout.

Extracted rules inside block: 381db006a47d

## b362d3fe4a259b4d — image/references/patterns/ui-social.md:118-118 (paragraph)

<!-- Source concept: personal color analysis / seasonal color palette board with side-by-side comparisons -->

Extracted rules inside block: NONE

## 97f89ac7bd6c54f2 — image/references/patterns/ui-social.md:120-131 (code)

```
Scene: white background, organized multi-section layout with thin #E0E0E0 divider lines, clean editorial formatting
Subject: personal color analysis board for {subject_description}
Important Details:
  Section 1 — Portrait & Season (top, full width): {subject_description} portrait photo (head and shoulders, natural lighting, neutral expression) on the left. To the right: season classification "{season_type}" in medium bold text, with a 4x3 grid of small color swatches showing the {num_palette} best colors for this season type ({palette_colors}), each swatch labeled with its name in tiny text below
  Section 2 — Clothing Comparison (middle): two side-by-side panels. Left panel "{good_label}": the subject wearing a top in {flattering_color} — skin looks healthy, face appears lifted and bright. Right panel "{bad_label}": the same subject wearing a top in {unflattering_color} — skin appears washed out or sallow. Small caption under each explaining the effect in 5-8 words
  Section 3 — Recommendations (bottom): horizontal strip with {num_recs} small squares — each showing a recommended item ({rec_items}) in one of the palette colors, with a one-word label below (e.g. "Scarf", "Blazer", "Lipstick", "Frames")
  Visual-first design — images and swatches dominate, text is short labels only
  Clean editorial feel, no decorative flourishes
Use Case: personal styling consultation, color analysis service deliverable, fashion content
Constraints: same person in all panels showing the subject, swatches must be solid flat color (no gradients), labels are short (1-3 words max), no paragraphs of body text, layout must feel organized and scannable, no overlapping sections
```

Extracted rules inside block: NONE

## 0232c23947f60cb2 — image/references/patterns/ui-social.md:133-133 (paragraph)

**Key levers:** `{subject_description}` (age, skin tone, hair color, eye color — needed for accurate seasonal analysis), `{season_type}` (Warm Spring, Cool Summer, Warm Autumn, Cool Winter — or sub-seasons like Soft Autumn, Bright Winter), `{palette_colors}` (12 hex values matching the season, e.g. Warm Autumn: rust #B7410E, olive #708238, mustard #E1AD01, burgundy #722F37...), `{num_palette}` (12), `{flattering_color}` / `{unflattering_color}` (specific colors with hex), `{good_label}` / `{bad_label}` (e.g. "Warm Coral" / "Cool Pink"), `{num_recs}` (4-6), `{rec_items}` (scarf in olive, blazer in navy, lipstick in warm rose, eyeglass frames in tortoise)

Extracted rules inside block: b0d6b216d567

## dd7a68b2688ae3c2 — image/references/patterns/ui-social.md:135-135 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — color accuracy of palette swatches is critical, plus small text labels throughout

Extracted rules inside block: f20fd2bd8bec

## 16098e19d97b1384 — image/references/patterns/ui-social.md:137-137 (heading)

### Nano Banana version:

Extracted rules inside block: NONE

## cd5f8b5305fd4608 — image/references/patterns/ui-social.md:139-141 (code)

```
A personal color analysis board on a white background for {subject_description}. Top section: portrait of the subject on the left, seasonal classification "{season_type}" on the right with a grid of {num_palette} color palette swatches ({palette_colors}). Middle section: side-by-side comparison — left shows the subject in a {flattering_color} top looking healthy and bright ("{good_label}"), right shows the same subject in {unflattering_color} looking washed out ("{bad_label}"). Bottom strip: {num_recs} recommended items ({rec_items}) each in a palette color with one-word labels. Clean editorial layout, visual-first with minimal text, thin gray dividers between sections. Format: 3:4.
```

Extracted rules inside block: NONE

## 5dc8a9457e7107c5 — image/references/patterns/ui-social.md:145-145 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## a24ed243cfc56aaf — image/references/prompt-framework.md:1-1 (heading)

# Prompt Framework

Extracted rules inside block: NONE

## 42dd1d797affc67d — image/references/prompt-framework.md:3-3 (paragraph)

Универсальный чеклист для построения промпта. Применим к **обеим** семьям моделей. Для отличий смотри:

Extracted rules inside block: NONE

## ec805def40b3480f — image/references/prompt-framework.md:4-4 (list_item)

- [nano-banana.md](nano-banana.md) — NB-специфика (grounding, extreme ratios, thinking mode, JSON)

Extracted rules inside block: NONE

## edf305c5f8353bdd — image/references/prompt-framework.md:5-5 (list_item)

- [gpt-image.md](gpt-image.md) — GPT Image 2 (5-slot template, anti-slop, quality settings)

Extracted rules inside block: NONE

## 219dad99a67e7fa5 — image/references/prompt-framework.md:6-6 (list_item)

- [models.md](models.md) — какую модель когда выбрать

Extracted rules inside block: NONE

## 8490044160b28f2b — image/references/prompt-framework.md:8-8 (heading)

## Task Types (Навыки)

Extracted rules inside block: NONE

## 6f638208ec8623cd — image/references/prompt-framework.md:10-10 (paragraph)

Определи тип задачи - это задаёт стратегию промпта:

Extracted rules inside block: NONE

## 98c94aeeac21d344 — image/references/prompt-framework.md:12-12 (table_row)

| Type | Когда использовать | Ключевые элементы |

Extracted rules inside block: NONE

## 3184d9ba19d5ef6b — image/references/prompt-framework.md:14-14 (table_row)

| **Photorealistic** | Фото людей, продуктов, сцен | Освещение, материалы, атмосфера |

Extracted rules inside block: NONE

## 5b533df6ef2e9f19 — image/references/prompt-framework.md:15-15 (table_row)

| **Illustration** | Стикеры, иконки, арт | Стиль, контуры, палитра |

Extracted rules inside block: NONE

## bc663da3d1fb6030 — image/references/prompt-framework.md:16-16 (table_row)

| **Product/Commercial** | Продуктовая съёмка | Поверхность, отражения, композиция |

Extracted rules inside block: NONE

## 1c209e500f75e64c — image/references/prompt-framework.md:17-17 (table_row)

| **Minimalist** | Негативное пространство | Что убрать важнее чем что добавить |

Extracted rules inside block: NONE

## e521e5d0ea6909a9 — image/references/prompt-framework.md:18-18 (table_row)

| **Sequential** | Комиксы, сториборды | Панели, переходы, нарратив |

Extracted rules inside block: NONE

## d9ea6f20860bf137 — image/references/prompt-framework.md:19-19 (table_row)

| **Editing** | Изменение существующего | Конкретные инструкции что менять |

Extracted rules inside block: NONE

## b7409f1edd7319d4 — image/references/prompt-framework.md:20-20 (table_row)

| **Style Transfer** | Перенос стиля | Референс + новый контент |

Extracted rules inside block: NONE

## 18eb82d067cfc57f — image/references/prompt-framework.md:21-21 (table_row)

| **Composite** | Объединение элементов | Связность, освещение, масштаб |

Extracted rules inside block: NONE

## 10d18d54b3585909 — image/references/prompt-framework.md:22-22 (table_row)

| **Text Rendering** | Текст в изображении | Точные кавычки, позиция, вес |

Extracted rules inside block: NONE

## 7d7331f3df8b8d2a — image/references/prompt-framework.md:24-24 (heading)

## Universal Elements (Чеклист)

Extracted rules inside block: NONE

## b6737380d2ea9a81 — image/references/prompt-framework.md:26-26 (paragraph)

Пройдись по списку - не всё нужно указывать, но полезно проверить:

Extracted rules inside block: NONE

## 9fa36572b1025768 — image/references/prompt-framework.md:28-28 (paragraph)

**Обязательные:**

Extracted rules inside block: 227ebee5af66

## 7a0e77626529b5f7 — image/references/prompt-framework.md:29-29 (list_item)

- **Субъект** - кто/что в центре внимания

Extracted rules inside block: NONE
