# Source coverage review 39/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 6239053580b35e46 — image/references/editing.md:1-1 (heading)

# Image Editing

Extracted rules inside block: NONE

## 1c7c615a8a926005 — image/references/editing.md:3-3 (paragraph)

Универсальные паттерны. Логика edit'а различается по моделям:

Extracted rules inside block: NONE

## 94065df64152dcf7 — image/references/editing.md:5-5 (list_item)

- **Nano Banana:** conversational, без масок. «Keep X same, change Y». Хорошо понимает физику и материалы.

Extracted rules inside block: NONE

## ae5c2bd8800c84a5 — image/references/editing.md:6-6 (list_item)

- **GPT Image 2:** двухколоночная логика **Change / Preserve / Constraints**. Preserve list повторять каждую итерацию, иначе drift. Опционально `mask_image_url` для точечных edit'ов. Лучшая identity preservation. См. [gpt-image.md](gpt-image.md#editing--двухколоночная-логика).

Extracted rules inside block: NONE

## a2e7f6ea9c152625 — image/references/editing.md:8-8 (paragraph)

Общее правило: **один edit за итерацию**, не пытайся менять всё разом.

Extracted rules inside block: NONE

## 4383f1f0e2ec7697 — image/references/editing.md:10-10 (heading)

## Object Removal

Extracted rules inside block: NONE

## 4fe3c691fc170f4b — image/references/editing.md:11-15 (code)

```
Remove [OBJECT] from this image.
Fill with [LOGICAL REPLACEMENT] matching surroundings.
Keep [PRESERVED ELEMENTS] exactly the same.
```

Extracted rules inside block: NONE

## 731ebf60d43ba40f — image/references/editing.md:17-17 (paragraph)

Examples:

Extracted rules inside block: NONE

## ec7ac68ddf002d61 — image/references/editing.md:18-18 (list_item)

- "Remove tourists, fill with cobblestones"

Extracted rules inside block: NONE

## 60e9fe951429dbb9 — image/references/editing.md:19-19 (list_item)

- "Remove car, extend street naturally"

Extracted rules inside block: NONE

## e9208995990fcd70 — image/references/editing.md:21-21 (heading)

## Object Addition

Extracted rules inside block: NONE

## 36d999a182c18703 — image/references/editing.md:22-27 (code)

```
Add [OBJECT] to this image.
Position: [LOCATION]
Style: matching existing lighting
Scale: [RELATIVE SIZE]
```

Extracted rules inside block: NONE

## 4b304e8ef0e2faa9 — image/references/editing.md:29-29 (heading)

## Lighting Control

Extracted rules inside block: NONE

## 8b308b039bb8a307 — image/references/editing.md:30-33 (code)

```
Change lighting to [NEW LIGHTING].
Keep subject and composition same.
```

Extracted rules inside block: NONE

## 9421d43ea0d26b5e — image/references/editing.md:35-35 (paragraph)

Vocabulary:

Extracted rules inside block: NONE

## aaaa855fe62c12c4 — image/references/editing.md:36-36 (list_item)

- Golden hour / sunset / warm backlight

Extracted rules inside block: NONE

## b1b7dc8445a05ab1 — image/references/editing.md:37-37 (list_item)

- Overcast / soft / diffused

Extracted rules inside block: NONE

## ee063e336a3dd9a7 — image/references/editing.md:38-38 (list_item)

- Night / dramatic / single source

Extracted rules inside block: NONE

## a7e905e7c323d45f — image/references/editing.md:39-39 (list_item)

- Rim lighting / silhouette

Extracted rules inside block: NONE

## b4dd4e6a9cb4f18a — image/references/editing.md:41-41 (heading)

## Seasonal/Weather

Extracted rules inside block: NONE

## e99318246a0cbcc5 — image/references/editing.md:42-46 (code)

```
Turn scene into [SEASON/WEATHER].
Keep architecture exactly same.
Adjust: [snow/leaves/reflections/sky]
```

Extracted rules inside block: NONE

## f6a507062eafba77 — image/references/editing.md:48-48 (heading)

## Colorization

Extracted rules inside block: NONE

## 7112399718c433d7 — image/references/editing.md:50-50 (paragraph)

**Photo:**

Extracted rules inside block: NONE

## fabfd0eaa1741ce8 — image/references/editing.md:51-55 (code)

```
Colorize this B&W photograph.
Era-appropriate colors for [DECADE].
Skin tones: natural, realistic
```

Extracted rules inside block: NONE

## 16915204f889febf — image/references/editing.md:57-57 (paragraph)

**Manga:**

Extracted rules inside block: NONE

## 15b14e16fad91245 — image/references/editing.md:58-63 (code)

```
Colorize this manga panel.
Style: [vibrant anime / muted realistic]
Effects: [glowing/neon] for energy elements
Maintain: line art integrity
```

Extracted rules inside block: NONE

## 6d851610624477df — image/references/editing.md:65-65 (heading)

## Restoration

Extracted rules inside block: NONE

## 718bdc602156609c — image/references/editing.md:66-71 (code)

```
Restore this damaged photograph.
Fix: [tears/scratches/fading/stains]
Enhance: sharpness, contrast
Preserve: original character and grain
```

Extracted rules inside block: NONE

## 11e8bb0bcd0fe900 — image/references/editing.md:73-73 (heading)

## Localization

Extracted rules inside block: NONE

## eaab1e32bdb224af — image/references/editing.md:74-78 (code)

```
Translate all [SOURCE] text to [TARGET].
Keep everything else same.
Maintain: font style, sizing, position
```

Extracted rules inside block: NONE
