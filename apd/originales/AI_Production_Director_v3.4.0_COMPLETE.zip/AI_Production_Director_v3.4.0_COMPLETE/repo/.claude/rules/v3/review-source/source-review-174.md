# Source coverage review 174/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 9c2af4bec50aafa8 — video/references/seedance-25.md:345-384 (code)

```text
29-Second One-Shot (Ancient Costume Woman's Riverside Farewell)

[Global Scene Setting] Early morning by the river, a blurred small boat in the
background, a lonely farewell. Quiet, restrained. Cinematic, shallow depth of
field, soft natural light. The camera holds a close-up of the woman, imitating
the subjective POV of "him" standing opposite her. Subtle handheld breathing,
one continuous shot with no fast cuts.

[Character Styling] [Age/Ethnicity] 22-year-old East Asian woman, classical
gentle cinematic face. [Skin] Cool-toned fair skin, delicate and moist,
retaining realistic fine pores and natural skin texture. [Facial Features]
Slender elegant eyes (slightly moist), relaxed brows, delicate straight nose
bridge, full lips with a faint gentle smile, soft jawline. [Eyes/Soul] Deeply
affectionate gaze, eyes shimmering like spring water. [Hair] Jet-black hair in
a casual classical low bun, a plain jade hairpin. [Clothing] Minimalist pure
white cross-collar Hanfu. [Physique/Aura] Slender, delicate narrow shoulders,
gentle classical romantic aura.

[Core Performance] Restrained and nuanced. Capture the shifting gaze, the rise
and fall of breathing, slight lip trembling, subtle brow movements, nostril
changes, throat swallowing, and the natural process of a tear sliding down.

[Negative Prompts] No exaggerated crying, no fast cuts, no large body
movements, no extra dialogue, no BGM, no runny nose, no premature dropping
of tears.

[Emotion and Action Storyboard]
Stage 1: 0-3s [Questioning]. She looks directly into the lens, lips slightly
parted, and whispers: {Are you really leaving?} Emotion analysis: she is not
complaining — she is waiting for him to confirm an answer she already guessed.
Stage 2: 3-10s [Resignation] — swallowing the bitterness. ...
Stage 3: 11-17s [Remembering] — a 0.5-second dead-silent pause; her lips twitch
then press together, jaw tightens, throat swallows.
Stage 4: 18-23s [Regret] — she lowers her eyes, and only then do the tears
begin to fall. She shakes her head slightly, almost imperceptibly.
Stage 5: 24-29s [Letting Go] — extreme close-up. She forms a gentle smile and
says in a barely audible but steadied voice: {You can go.} (On the word "go"
there is a faint tremble, forcefully suppressed.)
```

Extracted rules inside block: NONE

## df7d429f85761d34 — video/references/seedance-25.md:386-386 (paragraph)

Every stage: one state change, physical directives, emotional subtext, and the bans list names the exact collapse modes of *this* scene.

Extracted rules inside block: NONE

## b9f3ebc4686d43bf — video/references/seedance-25.md:388-388 (heading)

### B. Physics and prohibitions — sci-fi mecha chase (30s one-shot)

Extracted rules inside block: NONE

## 4a2eccf1bac060ea — video/references/seedance-25.md:390-418 (code)

```text
30-Second One-Shot (Sci-Fi Mecha Chase and Transformation)

[Global Setting] A cyberpunk cross-sea bridge in 2077, heavy rain. Emphasize
extreme, realistic physical textures: rain reflections on metal, water
splashed by tires, and the specular refraction of exhaust flames must strictly
obey real-world physics. Hardcore sci-fi cinematic feel, high-contrast neon
(cyber-pink and icy blue), high-speed shutter. High-speed drone POV, one
continuous shot. Subject: a silver-and-black concept mecha motorcycle.

[Negative Prompts] No soft-body or mollusk-like twisting/clipping of the mecha
structure during movement (must maintain metallic rigidity); no human
entities; strictly remove irrelevant subtitles; force mute / no default BGM;
avoid copyrighted IP elements like Transformers or Tron.

[Timestamp Storyboard]
[00:00-00:08] [Extreme Speed] The camera skims the waterlogged road; the
spinning wide tires kick up massive water curtains meters high. Camera
subtext: convey speed through the physical interaction of rain, puddle
reflections and engine flames.
[00:09-00:16] [Evasion] The tires grind the road, sparking orange friction
sparks, executing a tight "S" curve.
[00:17-00:24] [Mid-Air Reassembly] During slow-mo hang time the armor flips,
deconstructs, and reassembles — strictly rejecting "noodle-like" soft-body
transformation.
[00:25-00:30] [Heavy Landing] The tonnage impact shatters the bridge surface
into a spider-web pattern; the shockwave blows the surrounding rain away in
an expanding ring. A frozen "superhero landing" as the final image.
```

Extracted rules inside block: NONE

## 9d8fa3afef9457ee — video/references/seedance-25.md:420-420 (paragraph)

Physics regime declared up front, every beat narrates a consequence, and each ban targets a known failure of exactly this material.

Extracted rules inside block: NONE

## b1712a2ee6b6285c — video/references/seedance-25.md:422-422 (heading)

### C. Reference orchestration — museum heist one-take (17 refs, translated from the Jimeng manual cases)

Extracted rules inside block: NONE

## 4b116a1025747720 — video/references/seedance-25.md:424-449 (code)

```text
Photoreal suspense-film texture. Set at the museum charity gala of @Image 10;
main hall structure, twin staircases and central exhibit stay consistent
throughout; sub-spaces reference @Image 11 and @Image 12; lighting and
materials reference @Image 15 and @Image 17. Follow the camera route in
@Image 16; smart auto-cutting, cinema-grade camera moves.

[0-4s] Camera advances behind the shoulder of the @Image 4 waiter carrying
the @Image 14 silver champagne tray through the main hall; the @Image 5
curator greets guests at the staircase; the @Image 6 reporter raises a
camera. The @Image 1 blue-diamond necklace sits in its glass case.
[4-8s] The @Image 7 woman in red brushes past the @Image 8 magician in black
tails, who smiles faintly at the lens; the @Image 9 security chief watches
beside the case.
[8-11s] The chandelier dies; the hall snaps to the crimson emergency lighting
of @Image 13; the crowd falls silent; <a soft clink from the case>, then
<a short alarm>. (Low strings and heartbeat stop together) — keep only an
inhale, the glass clink and the alarm.
[11-16s] Close-ups in sequence: the curator frozen, the reporter raising the
camera, the woman in red stepping back. Lights return to warm gold; cut back
to the case — glass intact, the @Image 1 diamond gone.
[16-20s] Slow push toward the magician's lowered right hand; a tiny blue
glint inside his silver cuff; he lifts his eyes to the lens and smiles.

No subtitles, no logo, no watermark.
```

Extracted rules inside block: NONE

## 6023f6f63197e222 — video/references/seedance-25.md:451-451 (paragraph)

Seventeen references, every one role-bound per scene; the camera choreography is supplied as a route diagram (@Image 16), not prose; sound is designed per beat with the `< >` and `( )` markers.

Extracted rules inside block: NONE

## 2032c4fd8273e841 — video/references/seedance-25.md:455-455 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 394a96b7b4f8dfc8 — video/references/seedance.md:1-1 (heading)

# Seedance reference (ByteDance)

Extracted rules inside block: NONE

## c7cd89909bf33de3 — video/references/seedance.md:3-3 (heading)

## Contents

Extracted rules inside block: NONE

## 1b57bc018ca3f77c — video/references/seedance.md:5-5 (list_item)

1. What Seedance is

Extracted rules inside block: a9a3fe5e1ddb

## ca6d6becbb1d5879 — video/references/seedance.md:6-6 (list_item)

2. Versions and specs

Extracted rules inside block: 449f4491638f

## 76114a1327daee84 — video/references/seedance.md:7-7 (list_item)

3. CLI parameters (1.x / 2.0 only)

Extracted rules inside block: ca0cb66d30d8

## c1e5cb5d5f063d1b — video/references/seedance.md:8-8 (list_item)

4. The Details Law (read first)

Extracted rules inside block: 0edcf9e9b618

## 47ec094cd306b8c1 — video/references/seedance.md:9-9 (list_item)

5. 6-step prompt formula (quick)

Extracted rules inside block: 0587a57a1414

## 9a4ced6fb883d19c — video/references/seedance.md:10-10 (list_item)

6. Production-grade skeleton (11 blocks) — for dramatic / multi-shot work

Extracted rules inside block: 1c49a8c5d208

## 2ae2896866683eb4 — video/references/seedance.md:11-11 (list_item)

7. The 5-second shot timeline (rhythm template)

Extracted rules inside block: 3b7c886ae6b9

## bb3f9bbeefc9bf70 — video/references/seedance.md:12-12 (list_item)

8. Multi-shot syntax (unique capability)

Extracted rules inside block: c8a8117656c4

## 61d3a432199aace3 — video/references/seedance.md:13-13 (list_item)

9. Anti-mush guard block (when Seedance smears the cuts)

Extracted rules inside block: 794483a4c325

## 92195ed3f27042ed — video/references/seedance.md:14-14 (list_item)

10. `@img1` character reference syntax

Extracted rules inside block: 2e681b0457dc

## ec52eac463772089 — video/references/seedance.md:15-15 (list_item)

11. Camera movements (9 presets)

Extracted rules inside block: 1ae3dffe23e1

## 5e7a292a8000f8d8 — video/references/seedance.md:16-16 (list_item)

12. Negative prompts handling

Extracted rules inside block: 63872f3f9e36

## 74f5604914e7efeb — video/references/seedance.md:17-17 (list_item)

13. Image-to-video rule

Extracted rules inside block: e7251cfdd13a

## 8abf5bdc5c47abe9 — video/references/seedance.md:18-18 (list_item)

14. Audio (1.5+)

Extracted rules inside block: 307195dc626d

## d7b0322b6d85638d — video/references/seedance.md:19-19 (list_item)

15. Failure modes and fixes

Extracted rules inside block: 9ba02b39ec68

## 5ef29d1fdce9e77d — video/references/seedance.md:20-20 (list_item)

16. Worked example. 15-second tragicomedy as 3 × 5s clips

Extracted rules inside block: 72c7a844ede3

## d719b617c761f0e9 — video/references/seedance.md:21-21 (list_item)

17. Seedance 2.5 → read `seedance-25.md`

Extracted rules inside block: 0014c9c1c4bc

## 69bedaa5ab0df753 — video/references/seedance.md:25-25 (heading)

## 1. What Seedance is

Extracted rules inside block: NONE

## 80d6a999f2b3d460 — video/references/seedance.md:27-27 (paragraph)

A ByteDance video model with the UNIQUE ability to generate several distinct shots in ONE generation. The only major model that can pack a mini-montage inside a single 5-10s clip. Good cinematic motion, strong at ads and short narrative.

Extracted rules inside block: NONE
