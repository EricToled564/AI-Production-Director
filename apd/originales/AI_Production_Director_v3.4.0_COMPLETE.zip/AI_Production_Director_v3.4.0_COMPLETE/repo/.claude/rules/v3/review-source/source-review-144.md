# Source coverage review 144/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## a0ef414360c65eb6 — video/references/dramaturgy.md:239-239 (heading)

## 11. Shot card template

Extracted rules inside block: NONE

## 1705e021c20c41b6 — video/references/dramaturgy.md:241-241 (paragraph)

For each shot in a storyboard, fill every field. Missing fields reveal missing direction.

Extracted rules inside block: NONE

## f32ffcbd040a32c9 — video/references/dramaturgy.md:243-243 (list_item)

- **Shot ID.** 01, 02, 03

Extracted rules inside block: NONE

## 9e7a7782bf04cbe2 — video/references/dramaturgy.md:244-244 (list_item)

- **Beat.** What changes in the story here.

Extracted rules inside block: NONE

## 5eebb8a205fb8ec4 — video/references/dramaturgy.md:245-245 (list_item)

- **Emotion.** Fear, shame, anger, guilt, resolve, relief, etc.

Extracted rules inside block: NONE

## 160c33069be4cd4e — video/references/dramaturgy.md:246-246 (list_item)

- **Frame.** wide / medium / close-up / macro insert

Extracted rules inside block: NONE

## 5655b4fafcc6bb11 — video/references/dramaturgy.md:247-247 (list_item)

- **Composition.** Center, edge, negative space, reflection, silhouette, foreground obstruction.

Extracted rules inside block: NONE

## 2974e6b2f4866cb9 — video/references/dramaturgy.md:248-248 (list_item)

- **Camera.** Static, push-in, handheld, tracking, whip-pan.

Extracted rules inside block: NONE

## 14e294017c233bfe — video/references/dramaturgy.md:249-249 (list_item)

- **Movement reason.** Why the camera moves here. Answer "what changed?"

Extracted rules inside block: NONE

## 03a2080c5b52c16f — video/references/dramaturgy.md:250-250 (list_item)

- **Action.** Exact physical event.

Extracted rules inside block: NONE

## defce353df10c0d8 — video/references/dramaturgy.md:251-251 (list_item)

- **Eye trace.** Where the viewer's gaze should land in the first 0.3s.

Extracted rules inside block: 0aa809e5b218

## 53c5b18f35411c11 — video/references/dramaturgy.md:252-252 (list_item)

- **Duration.** 0.5s, 1s, 3s.

Extracted rules inside block: NONE

## f22bb60558412bd9 — video/references/dramaturgy.md:253-253 (list_item)

- **Cut type.** match cut, smash cut, cut on action, J-cut, L-cut.

Extracted rules inside block: NONE

## 3167878cfa0ef117 — video/references/dramaturgy.md:254-254 (list_item)

- **Sound.** Breath, bass hit, street noise, phone ring, silence.

Extracted rules inside block: NONE

## ab3965d39656a40a — video/references/dramaturgy.md:255-255 (list_item)

- **Light / color.** Cold, contrast, flicker, shadow, specific palette.

Extracted rules inside block: NONE

## 71770f7d95643d46 — video/references/dramaturgy.md:256-256 (list_item)

- **Production note.** Prop, location, actor direction.

Extracted rules inside block: NONE

## 042f7a623c5bb08e — video/references/dramaturgy.md:258-258 (paragraph)

If a shot card has empty fields, fill them or drop the shot.

Extracted rules inside block: NONE

## 7735e9fac13a7009 — video/references/dramaturgy.md:260-260 (heading)

## 12. Rhythm ladder

Extracted rules inside block: NONE

## 4c81ee51bc96454f — video/references/dramaturgy.md:262-262 (paragraph)

Drama rhythm is not uniform. It is stepped.

Extracted rules inside block: NONE

## 627feeabcadfab4e — video/references/dramaturgy.md:264-264 (heading)

### Slow-burn drama

Extracted rules inside block: NONE

## fde4ccb589a25c06 — video/references/dramaturgy.md:265-265 (paragraph)

4s, 4s, 3s, 2s, 1s, pause, 2s.

Extracted rules inside block: NONE

## 574dcab62d46021a — video/references/dramaturgy.md:267-267 (heading)

### Commercial product arc

Extracted rules inside block: NONE

## f9ea7ef66a356477 — video/references/dramaturgy.md:268-268 (paragraph)

3s, 2s, 1.5s, 1s, 0.5s (product macro), 2s (hero shot).

Extracted rules inside block: NONE

## 6f8ca3d605752df6 — video/references/dramaturgy.md:270-270 (heading)

### Anxiety build

Extracted rules inside block: NONE

## a4a70eff0fbd1b19 — video/references/dramaturgy.md:271-271 (paragraph)

2s, 1s, 1s, 0.5s, 0.5s, 0.3s, pause, 1s.

Extracted rules inside block: NONE

## acbd942c9418068b — video/references/dramaturgy.md:273-273 (heading)

### Impact scene

Extracted rules inside block: NONE

## 171f3bbf4e459b9c — video/references/dramaturgy.md:274-274 (paragraph)

pause, 0.2s (flash), 2s (aftermath in stillness).

Extracted rules inside block: NONE

## 0aaf35d9be890aa1 — video/references/dramaturgy.md:276-276 (paragraph)

Always insert at least one pause before the biggest cut.

Extracted rules inside block: 168d0b1ee5ee

## c13fedc408112f21 — video/references/dramaturgy.md:278-278 (heading)

## 13. One-anchor principle

Extracted rules inside block: NONE

## 181b5e0a10d6db9b — video/references/dramaturgy.md:280-280 (paragraph)

For any short dramatic piece, commit to exactly five anchors. No more.

Extracted rules inside block: NONE
