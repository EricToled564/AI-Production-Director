# Source coverage review 72/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2859c673999c846c — image/references/structural.md:17-17 (heading)

## Wireframe → Mockup

Extracted rules inside block: NONE

## c6c8683a7db3d1ee — image/references/structural.md:19-25 (code)

```
Generate [MOCKUP TYPE] following these wireframes.

Layout: Match wireframe structure precisely
Content: [placeholder / realistic]
Style: [UI style / brand guidelines]
```

Extracted rules inside block: NONE

## 96110652292e6972 — image/references/structural.md:27-27 (paragraph)

UI/UX designs from rough wireframes.

Extracted rules inside block: NONE

## fc89298e5248975e — image/references/structural.md:29-29 (heading)

## Grid-Based Assets

Extracted rules inside block: NONE

## d5929377c8de4217 — image/references/structural.md:31-35 (code)

```
Generate [ASSET] fitting this [SIZE] grid.
Each cell: [CONTENT]
Consistency: Uniform style across cells
```

Extracted rules inside block: NONE

## f67ad22a4baf93eb — image/references/structural.md:37-37 (paragraph)

Use cases:

Extracted rules inside block: NONE

## df181a74121d5e08 — image/references/structural.md:38-38 (list_item)

- Sprite sheets for games

Extracted rules inside block: NONE

## 2abf33c09d8c5430 — image/references/structural.md:39-39 (list_item)

- LED display content

Extracted rules inside block: NONE

## 44a6cb3711e611d5 — image/references/structural.md:40-40 (list_item)

- Tile-based graphics

Extracted rules inside block: NONE

## ba13d7efaaba74b2 — image/references/structural.md:42-42 (heading)

## Pixel Art

Extracted rules inside block: NONE

## 436ab098b50b3b7a — image/references/structural.md:44-48 (code)

```
Generate pixel art [SUBJECT] fitting [SIZE] grid.
Colors: high contrast
Style: [retro / modern pixel]
```

Extracted rules inside block: NONE

## 2207c1e6673dd98b — image/references/structural.md:50-50 (paragraph)

Tip: Extract cell colors programmatically for LED matrices.

Extracted rules inside block: NONE

## 9733b2281dc3ec18 — image/references/structural.md:52-52 (heading)

## Layout Guidance

Extracted rules inside block: NONE

## aad61a2f52b5dd95 — image/references/structural.md:54-54 (paragraph)

Reference images can control:

Extracted rules inside block: NONE

## 185dcd425602e7e5 — image/references/structural.md:55-55 (list_item)

- **Where** elements sit

Extracted rules inside block: NONE

## 2a211126e1f134ef — image/references/structural.md:56-56 (list_item)

- **What** proportions to use

Extracted rules inside block: b12f56e38728

## bb755d5cf44f07b8 — image/references/structural.md:57-57 (list_item)

- **How** text flows

Extracted rules inside block: NONE

## 28e0757a0e959384 — image/references/structural.md:58-58 (list_item)

- **Which** areas get emphasis

Extracted rules inside block: NONE

## 6d76e8fb509920fe — image/references/structural.md:60-60 (heading)

## Brand Identity Systems

Extracted rules inside block: NONE

## 1185e05c0ee1530c — image/references/structural.md:62-80 (code)

```
[Input: logo sketch or design]
Create identity system using this logo.

Generate one at a time:
1. Logo refinement
2. Business card mockup
3. Letterhead
4. Billboard application
5. Product packaging
6. Digital banner
7. Social media avatar
8. App icon
9. Signage
10. Merchandise

Format: 16:9 each
Maintain: brand consistency across all
```

Extracted rules inside block: NONE

## 430efabc795670f6 — image/references/structural.md:82-82 (heading)

## Composition Templates

Extracted rules inside block: NONE

## 9b26b57e4a909ecf — image/references/structural.md:84-84 (paragraph)

Use reference for:

Extracted rules inside block: 13778242909e

## 58c96f7e142fe92f — image/references/structural.md:85-85 (list_item)

- Magazine layouts

Extracted rules inside block: NONE

## 38fa2350b668684f — image/references/structural.md:86-86 (list_item)

- Poster compositions

Extracted rules inside block: NONE

## 8655d9a6e5fa39e2 — image/references/structural.md:87-87 (list_item)

- Social media templates

Extracted rules inside block: NONE

## 9c21736f6df039a7 — image/references/structural.md:88-88 (list_item)

- Presentation structures

Extracted rules inside block: NONE

## 3d60334106de1ecc — image/references/structural.md:90-94 (code)

```
Follow the composition of reference image.
Replace: [ELEMENTS] with [NEW CONTENT]
Maintain: proportions, visual hierarchy
```

Extracted rules inside block: NONE

## d3abb11523b309d8 — image/references/structural.md:96-96 (heading)

## Precision Control

Extracted rules inside block: NONE

## 493e1e1b52cee66e — image/references/structural.md:98-98 (list_item)

- "Position text exactly where sketch indicates"

Extracted rules inside block: NONE

## 4b1111736d1951de — image/references/structural.md:99-99 (list_item)

- "Follow grid structure exactly"

Extracted rules inside block: NONE
