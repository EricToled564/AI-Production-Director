# Source coverage review 212/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## fd68916baa6ee6db — visual-prompt-forge/adapters/kling.md:49-49 (table_row)

| `tilt-up` / `tilt-down` | "Camera tilts upward / downward." |

Extracted rules inside block: NONE

## e3ecc057e1ca0fc0 — visual-prompt-forge/adapters/kling.md:50-50 (table_row)

| `handheld` | "Handheld camera, subtle organic movement, documentary feel." |

Extracted rules inside block: NONE

## 975d165c06da1804 — visual-prompt-forge/adapters/kling.md:51-51 (table_row)

| `orbit` | "Camera orbits the subject in a slow circle." |

Extracted rules inside block: NONE

## 1f7c52941c654f3b — visual-prompt-forge/adapters/kling.md:52-52 (table_row)

| `whip` | "Fast whip pan with motion blur." |

Extracted rules inside block: NONE

## 6cb0e9b3a55a37aa — visual-prompt-forge/adapters/kling.md:53-53 (table_row)

| `rack` | "Rack focus shifts from foreground to background mid-shot." |

Extracted rules inside block: NONE

## 4c196bc8aa37a714 — visual-prompt-forge/adapters/kling.md:55-55 (heading)

## Subject motion

Extracted rules inside block: NONE

## 1ddf4162489ba74c — visual-prompt-forge/adapters/kling.md:57-57 (paragraph)

Beyond the camera, describe what the subject does over the duration:

Extracted rules inside block: NONE

## 5a68db7376469a62 — visual-prompt-forge/adapters/kling.md:59-59 (list_item)

> "Over the course of the shot the founder leans slightly forward and turns his face toward the window light off-camera left."

Extracted rules inside block: NONE

## 6dcaf180a880a9d4 — visual-prompt-forge/adapters/kling.md:61-61 (paragraph)

Static composition is not enough for video. This is what separates a video prompt from an image prompt.

Extracted rules inside block: NONE

## 2d2bd37dfabbc644 — visual-prompt-forge/adapters/kling.md:63-63 (heading)

## Example

Extracted rules inside block: NONE

## 014f24063f4013d7 — visual-prompt-forge/adapters/kling.md:65-65 (paragraph)

**Same shot data as the image-adapter examples, with `motion = "push"`.**

Extracted rules inside block: NONE

## 82e23c6e4e33a961 — visual-prompt-forge/adapters/kling.md:67-69 (code)

```
Camera dollies forward slowly into the scene at a steady pace. A founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck, sits at his laptop in a minimalist home office; over the shot he leans slightly forward and his face turns toward window light off-camera left, holding negative space on the right of frame throughout. Soft natural side-light from a large window, warm afternoon golden hour. Shot on a 50mm prime equivalent, shallow depth of field. Warm filmic color grade with muted teal shadows. Calm, considered, operator mood.
```

Extracted rules inside block: NONE

## 7ae52df079733a28 — visual-prompt-forge/adapters/kling.md:71-71 (heading)

## Continuity across shots

Extracted rules inside block: NONE

## a98985b5ff17b14f — visual-prompt-forge/adapters/kling.md:73-73 (list_item)

- Use `start_image` from the previous shot's accepted final frame to chain a sequence.

Extracted rules inside block: ecdd25e57ae8

## 7fcb23e615fbc9c1 — visual-prompt-forge/adapters/kling.md:74-74 (list_item)

- Repeat the series_lock character anchor verbatim in every prompt.

Extracted rules inside block: NONE

## b9d564d2857c6c16 — visual-prompt-forge/adapters/kling.md:75-75 (list_item)

- Do not flip lighting direction between consecutive shots (window-left stays window-left).

Extracted rules inside block: c980bc88fe2f

## 74d805a29da461a7 — visual-prompt-forge/adapters/kling.md:76-76 (list_item)

- Even with start-frame locking, each clip is a fresh generation. Plan for an editorial pass.

Extracted rules inside block: NONE

## 00d83811fee9f764 — visual-prompt-forge/adapters/kling.md:78-78 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 9b9dbf23c02dc0ee — visual-prompt-forge/adapters/kling.md:80-80 (list_item)

- **Don't put camera motion at the end.** Kling parses motion best as the leading instruction.

Extracted rules inside block: d119a91eb4da

## 92cdba6378ad45a5 — visual-prompt-forge/adapters/kling.md:81-81 (list_item)

- **Don't request multiple camera moves in one shot.** Pick one; compound moves break.

Extracted rules inside block: 17f1e0e985f1

## 1b735883f93832aa — visual-prompt-forge/adapters/kling.md:82-82 (list_item)

- **Don't describe motion faster than the duration allows.** A slow dolly over 5s is plausible; over 1s it is jitter.

Extracted rules inside block: 1f484f032e34

## 3d05c1c6a5e9ab42 — visual-prompt-forge/adapters/kling.md:83-83 (list_item)

- **Don't include text content.** Video text rendering is unreliable; composite or animate text in post.

Extracted rules inside block: 2990335b6104

## 0d5a445a8c674806 — visual-prompt-forge/adapters/kling.md:84-84 (list_item)

- **Don't expect frame-perfect character match between clips.** Budget editorial cleanup.

Extracted rules inside block: 43a5c5255db1

## 20a31583561dd1cf — visual-prompt-forge/adapters/kling.md:86-86 (heading)

## Output handoff

Extracted rules inside block: NONE

## 56484715c424236f — visual-prompt-forge/adapters/kling.md:88-88 (paragraph)

Generated clips are raw material, not deliverable. After generation they still need: editorial assembly to storyboard timing, text-overlay compositing from `text-overlays.json`, a color-grade pass, and audio (VO, music, sound design). Say this in handoff.

Extracted rules inside block: NONE

## 434d198a9d3ec880 — visual-prompt-forge/adapters/midjourney.md:1-1 (heading)

# Adapter: Midjourney (v7)

Extracted rules inside block: NONE

## dd5bdc423368a276 — visual-prompt-forge/adapters/midjourney.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: 44ca5e7fd558

## f43b89b812fc274d — visual-prompt-forge/adapters/midjourney.md:5-5 (paragraph)

Midjourney rewards short, high-signal prompts with strong adjective stacking and cinematic vocabulary. Long descriptive paragraphs underperform, the model interprets them as competing weights and produces muddled output.

Extracted rules inside block: NONE

## ff2f13eb5e7ee5cd — visual-prompt-forge/adapters/midjourney.md:7-7 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## 227910f40c21dbdc — visual-prompt-forge/adapters/midjourney.md:9-11 (code)

```
{subject}, {action}, {composition}, {environment}, {lighting}, {color/mood}, {style modifiers} --ar {ratio} --style {style} --s {stylize} {extras}
```

Extracted rules inside block: NONE
