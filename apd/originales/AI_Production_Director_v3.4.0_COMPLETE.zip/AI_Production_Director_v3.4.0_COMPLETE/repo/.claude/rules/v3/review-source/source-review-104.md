# Source coverage review 104/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5ef777e6f580b54a — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:94-94 (paragraph)

**On-screen text:** "Voice extracted. Brand locked. System runs." (Inter Medium 500, upper-third, slide-up at 16.4s)

Extracted rules inside block: NONE

## 4bce928479633e9e — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:96-96 (paragraph)

**Rationale:** Proof beat, show the system, not the result. The kanban metaphor is recognizable to operators. Subject right-weighted, text upper-third.

Extracted rules inside block: NONE

## 18538dc403a88ccc — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:100-100 (heading)

### shot_06 · 20.0–26.0s · MCU · static

Extracted rules inside block: NONE

## f749f29828056eb0 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:102-102 (paragraph)

**Beat:** promise

Extracted rules inside block: NONE

## 0e453ce8990f8935 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:104-104 (paragraph)

**Subject:** founder, calm composed posture, fully present, slight smile, hands folded on desk

Extracted rules inside block: NONE

## 554258bad2af4390 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:106-106 (paragraph)

**On-screen text:** "30 minutes a week. / 48-hour content cycles." (Inter Black 900, lower-third, type-on at 20.5s)

Extracted rules inside block: NONE

## 47d055ddfe99d83f — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:108-108 (paragraph)

**Rationale:** Promise beat, the after-state is the same person, just calmer. Static frame holds the moment. Text carries the specific commitment.

Extracted rules inside block: NONE

## 3e5f055ad256b82d — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:112-112 (heading)

### shot_07 · 26.0–30.0s · MS · static

Extracted rules inside block: NONE

## cede1b7bcb510b02 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:114-114 (paragraph)

**Beat:** cta

Extracted rules inside block: NONE

## 74eaa3766d25e1d2 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:116-116 (paragraph)

**Subject:** founder, neutral posture, room visible behind, calm presence, gentle eye contact with camera

Extracted rules inside block: NONE

## 139edf27be416079 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:118-118 (paragraph)

**On-screen text:** "whystrohm.com/scan" (Inter Black 900, coral, lower-third, type-on at 26.4s)

Extracted rules inside block: NONE

## 9cc0effad6157938 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:120-120 (paragraph)

**Rationale:** CTA beat. Pulled out to MS to give text the breathing room. Subject centered, text lower-third with URL. No motion, let it land.

Extracted rules inside block: NONE

## 47202c64a238d13e — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:124-124 (heading)

## Handoff notes

Extracted rules inside block: NONE

## 40a44ff9bbe4a831 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:126-126 (list_item)

- **For image generation:** run `visual-prompt-forge` against `shots.json`

Extracted rules inside block: NONE

## c490843ab8b4e733 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:127-127 (list_item)

- **For HTML preview:** run `storyboard-html-preview` against this folder

Extracted rules inside block: NONE

## bba81fb7ab638696 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:128-128 (list_item)

- **For QA on generated frames:** run `visual-asset-critic` with the generated image and the shot ID

Extracted rules inside block: NONE

## 64e98b71af8999d9 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:130-130 (heading)

## Audit trail

Extracted rules inside block: NONE

## 3c135eccdc1b8351 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:132-132 (paragraph)

This storyboard was generated against `brand-lock.snapshot.md` (frozen at 2026-05-07T14:23:00Z, source `brand-packs/whystrohm.md`). If the brand-lock changes after this date, re-run to pick up the new state.

Extracted rules inside block: NONE

## 9ae758a99b91ea87 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:1-2 (paragraph)

<!-- snapshot taken: 2026-05-07T14:23:00Z -->
<!-- source: brand-packs/whystrohm.md -->

Extracted rules inside block: NONE

## e87dcd1cc0ddd29b — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:4-4 (heading)

# Brand Lock: WhyStrohm

Extracted rules inside block: NONE

## 378ba4f3f982fd33 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:6-6 (heading)

## Identity

Extracted rules inside block: NONE

## 40f0dc0ea26824db — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:8-11 (paragraph)

**Brand:** WhyStrohm
**One-line description:** Managed content infrastructure for founder-led brands. Voice extraction, brand guardrails encoded in code, programmatic video, automated publishing. 30 minutes a week of founder time, 48-hour content cycles.
**Archetype:** Operator
**Voice posture:** Calm, considered, confident without shouting

Extracted rules inside block: NONE

## e4f858ee5c665f4b — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:13-13 (heading)

## Palette

Extracted rules inside block: NONE

## 4a7bf560fe4b735f — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:15-15 (table_row)

| Role | Hex | Use |

Extracted rules inside block: 76d743fa8798

## 9e77024e223e5f61 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:17-17 (table_row)

| Background | `#F5F0E8` | Cream, primary canvas |

Extracted rules inside block: NONE

## 4d08efbb3c734f5a — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:18-18 (table_row)

| Ink | `#2A2A32` | Near-black, primary text and dark elements |

Extracted rules inside block: NONE

## 84d22fb28ddd4412 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:19-19 (table_row)

| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |

Extracted rules inside block: NONE

## 2b938a3caa2beeb5 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:20-20 (table_row)

| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |

Extracted rules inside block: NONE

## 78f65d2e550af6bf — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:21-21 (table_row)

| Muted | `#7A7580` | Secondary text, captions |

Extracted rules inside block: NONE

## b2ec20cae40379c7 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:22-22 (table_row)

| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

Extracted rules inside block: NONE
