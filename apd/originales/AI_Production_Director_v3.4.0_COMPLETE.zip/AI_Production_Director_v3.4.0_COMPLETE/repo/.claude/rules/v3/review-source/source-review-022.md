# Source coverage review 22/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 586714c969a99ae3 — brand-lock-extractor/brand-packs/README.md:3-3 (paragraph)

A brand pack is a single Markdown file that locks in palette, typography, voice, and visual rules for a project. The skills in this pack consume it. Every storyboard, every prompt, every generated frame inherits from it.

Extracted rules inside block: NONE

## e772e6ee3737e457 — brand-lock-extractor/brand-packs/README.md:5-5 (heading)

## How to use

Extracted rules inside block: NONE

## 22cb3fd03f94774c — brand-lock-extractor/brand-packs/README.md:7-7 (list_item)

1. Copy `_template.md` to a new file (e.g. `acme.md`)

Extracted rules inside block: 3a049fb85a6b

## dd38fdd08b239e58 — brand-lock-extractor/brand-packs/README.md:8-8 (list_item)

2. Fill in every field. No placeholders left behind.

Extracted rules inside block: 055e3983e17e

## ba245c1a5040f462 — brand-lock-extractor/brand-packs/README.md:9-9 (list_item)

3. Reference it from your storyboard requests:

Extracted rules inside block: 00c429d4741a

## 379f8609862046a6 — brand-lock-extractor/brand-packs/README.md:11-11 (list_item)

   > "30-second founder explainer. Use `brand-packs/acme.md` as the brand lock."

Extracted rules inside block: 63bc88687f69

## cebd994a3a2ab6a3 — brand-lock-extractor/brand-packs/README.md:13-13 (list_item)

4. The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.

Extracted rules inside block: edcfdf72486a

## 4e57eb59c9e64e80 — brand-lock-extractor/brand-packs/README.md:15-15 (heading)

## How to write a good one

Extracted rules inside block: NONE

## 597e63d3c8a86bcc — brand-lock-extractor/brand-packs/README.md:17-17 (paragraph)

The template is a checklist, not a creative-writing exercise. Three rules:

Extracted rules inside block: NONE

## dc8aa87a0465e2f9 — brand-lock-extractor/brand-packs/README.md:19-19 (paragraph)

**Be specific.** "Modern, clean, professional" is not a brand. "Calm, considered, operator energy, confident without shouting" is.

Extracted rules inside block: NONE

## 15365638b63baed6 — brand-lock-extractor/brand-packs/README.md:21-21 (paragraph)

**Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.

Extracted rules inside block: e2e810a4492f

## d567e5cd351feb4b — brand-lock-extractor/brand-packs/README.md:23-23 (paragraph)

**Be hex-precise.** Every color is a hex value. Every font is named. The skills consume structured data; vagueness here cascades into bad prompts later.

Extracted rules inside block: NONE

## 583987c901622407 — brand-lock-extractor/brand-packs/README.md:25-25 (heading)

## Examples

Extracted rules inside block: NONE

## a32764d824f0937e — brand-lock-extractor/brand-packs/README.md:27-27 (paragraph)

The pack ships with two reference brand packs:

Extracted rules inside block: NONE

## 72e61d18ef5cd8f7 — brand-lock-extractor/brand-packs/README.md:29-29 (list_item)

- **`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.

Extracted rules inside block: fac90d12086b

## a6b96e2200f56be2 — brand-lock-extractor/brand-packs/README.md:30-30 (list_item)

- **`examples/saas-clean.md`**. B2B SaaS, restrained, professional. Light backgrounds, single accent. Inter type stack. A neutral counterpoint to the WhyStrohm flagship.

Extracted rules inside block: NONE

## 127b1e2466254579 — brand-lock-extractor/brand-packs/README.md:32-32 (paragraph)

More example brand packs will land in v2.0.0. PRs welcome.

Extracted rules inside block: NONE

## cd03c9a3eeb1dc45 — brand-lock-extractor/brand-packs/README.md:34-34 (heading)

## Generating a brand pack from existing assets

Extracted rules inside block: NONE

## 3bd6efe6f924eaa0 — brand-lock-extractor/brand-packs/README.md:36-36 (paragraph)

Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

Extracted rules inside block: b98efaf4637c

## fadbdd4554703b25 — brand-lock-extractor/brand-packs/README.md:38-38 (list_item)

> "Extract a brand-lock from acme.com" or "build a brand pack from this brand book PDF."

Extracted rules inside block: NONE

## 4565a9e261dcea96 — brand-lock-extractor/brand-packs/README.md:40-40 (paragraph)

For bulk or programmatic extraction across many URLs, [media-tsunami](https://github.com/whystrohm/media-tsunami) (WhyStrohm's open-source brand voice extractor) scrapes URLs and produces a `brand-lock.md` in the same format.

Extracted rules inside block: NONE

## ef6bd519f1c94496 — brand-lock-extractor/brand-packs/README.md:42-42 (heading)

## Versioning

Extracted rules inside block: NONE

## 03a3de48dff60e08 — brand-lock-extractor/brand-packs/README.md:44-44 (paragraph)

Every storyboard run snapshots the brand pack it was built against. If you update `acme.md` later, previous storyboards still reference the version they were built on. This is intentional, the audit trail tells you exactly what brand state any given piece of content was built against.

Extracted rules inside block: NONE

## d83804daaacfebd0 — brand-lock-extractor/brand-packs/README.md:46-46 (paragraph)

When you make a brand-pack revision that materially changes look or voice, bump the `Version:` field at the bottom and note the change. e.g.:

Extracted rules inside block: NONE

## 11f602e418c75d2a — brand-lock-extractor/brand-packs/README.md:48-50 (code)

```
Version: 1.1 (2026-05-12: switched accent from #D94F3A coral to #C44233 deeper coral)
```

Extracted rules inside block: NONE

## 5a64fc2f4e0a1af2 — brand-lock-extractor/brand-packs/README.md:52-52 (heading)

## Contributing examples

Extracted rules inside block: NONE

## 98650773f577d805 — brand-lock-extractor/brand-packs/README.md:54-54 (paragraph)

PRs welcome for new brand-pack examples that fill gaps in the current set. Open an issue with the `brand-pack-request` template before submitting.

Extracted rules inside block: NONE

## 4569e1b046c5d135 — brand-lock-extractor/brand-packs/_template.md:1-1 (heading)

# Brand Lock: {{BRAND_NAME}}

Extracted rules inside block: NONE

## 6da0569d551fab20 — brand-lock-extractor/brand-packs/_template.md:3-3 (list_item)

> Replace placeholders. Delete this blockquote when you're done.

Extracted rules inside block: NONE

## 3c9c84d859fb89de — brand-lock-extractor/brand-packs/_template.md:4-4 (list_item)

> Every field below feeds into the storyboard pipeline. Be specific.

Extracted rules inside block: NONE
