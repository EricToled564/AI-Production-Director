# Source coverage review 204/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 45f69ead8845603c — visual-prompt-forge/SKILL.md:335-335 (heading)

## Quality bar

Extracted rules inside block: NONE

## 9137d83cc21fb4be — visual-prompt-forge/SKILL.md:337-337 (paragraph)

Run the validator. Do not eyeball this list.

Extracted rules inside block: 50a95ba441bc

## 02f6ba0dfa716a0e — visual-prompt-forge/SKILL.md:339-342 (code)

```bash
python tools/validate_prompts.py output/
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
```

Extracted rules inside block: NONE

## dcdaafe8f399cc9d — visual-prompt-forge/SKILL.md:344-345 (paragraph)

`validate_prompts.py` checks the mechanical half, which is everything that used to be a
checkbox here:

Extracted rules inside block: NONE

## c0adcb2d197fd8b0 — visual-prompt-forge/SKILL.md:347-347 (list_item)

- the header names the storyboard, generator, aspect, brand-lock, run, and round

Extracted rules inside block: NONE

## bfb8379dbf7844e3 — visual-prompt-forge/SKILL.md:348-348 (list_item)

- the generator is a real id in `_capabilities.json`

Extracted rules inside block: NONE

## c89dd2331b51bc30 — visual-prompt-forge/SKILL.md:349-349 (list_item)

- the header aspect matches `project.aspect`

Extracted rules inside block: NONE

## 43eaad28abc8c31a — visual-prompt-forge/SKILL.md:350-350 (list_item)

- no prompt exceeds that generator's `max_prompt_words` ceiling

Extracted rules inside block: NONE

## 3e08b8a547a210fc — visual-prompt-forge/SKILL.md:351-351 (list_item)

- a full pass covers every shot; a revision file covers a subset of real shots

Extracted rules inside block: NONE

## a7b1725dd3a26c19 — visual-prompt-forge/SKILL.md:352-352 (list_item)

- no shot block is duplicated, and none has a header with no body

Extracted rules inside block: NONE

## 32d53be1b4633a94 — visual-prompt-forge/SKILL.md:353-353 (list_item)

- **Rule 1**: no on-screen text copy appears in any prompt

Extracted rules inside block: NONE

## 8ce45658bec80df4 — visual-prompt-forge/SKILL.md:354-355 (list_item)

- **Rule 3**: `environment`, `lighting`, and `color_grade` appear verbatim, with the
  character anchor as a warning

Extracted rules inside block: NONE

## 6ccd4bb73be4ce5e — visual-prompt-forge/SKILL.md:356-358 (list_item)

- **Rule 6**: every shot states which third of the frame the body occupies, its point of
  view and its direction of travel; no scale contradictions, no two people at the same
  frame edge, no unnamed handedness in a two-person contact, no brand marks in frame

Extracted rules inside block: NONE

## f17b52d2758f03d0 — visual-prompt-forge/SKILL.md:360-360 (paragraph)

What it cannot check, and you still have to:

Extracted rules inside block: NONE

## 214723d8617d31b0 — visual-prompt-forge/SKILL.md:362-362 (list_item)

- [ ] One output file per requested generator

Extracted rules inside block: NONE

## 165e6896a7d60a67 — visual-prompt-forge/SKILL.md:363-364 (list_item)

- [ ] On a revision pass, the shots you left out are accounted for as ACCEPT, post-only,
      or rejected, and you said which is which

Extracted rules inside block: NONE

## 3d4b5617fd143583 — visual-prompt-forge/SKILL.md:365-365 (list_item)

- [ ] Generator-specific parameters are right for the surface the user will paste into

Extracted rules inside block: NONE

## 63b26052bf168f40 — visual-prompt-forge/SKILL.md:366-366 (list_item)

- [ ] The round is appended to `run.json` with a hash per prompt file

Extracted rules inside block: NONE

## 88364796fcfc207a — visual-prompt-forge/SKILL.md:367-367 (list_item)

- [ ] The prompt actually describes the shot, which is the part no validator will ever do

Extracted rules inside block: NONE

## ec26cad6c4b1c735 — visual-prompt-forge/SKILL.md:369-369 (heading)

## Examples

Extracted rules inside block: NONE

## 1f419bb4c40735df — visual-prompt-forge/SKILL.md:371-374 (paragraph)

`examples/one-shot-all-adapters/` contains a single shot rendered across seven adapters
side-by-side: the six stills generators plus Kling. Use it to calibrate output quality.
The three remaining motion adapters (Veo, Seedance, Hailuo) have no worked example yet;
their `.md` files carry a worked prompt each in the meantime.

Extracted rules inside block: adce84610c11

## f323b386b4add5f8 — visual-prompt-forge/SKILL.md:376-377 (paragraph)

For a complete two-round output tree, prompts and frames and critiques together, see
`../visual-asset-critic/examples/worked-run/`.

Extracted rules inside block: NONE

## ab8c00dd8e98afa5 — visual-prompt-forge/adapters/flux.md:1-1 (heading)

# Adapter: Flux (Flux 2 Pro / Flux 1.1 Pro / Flux Dev)

Extracted rules inside block: NONE

## ffde70befc1fcbab — visual-prompt-forge/adapters/flux.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: ca81bbe9878b

## a4f664d77fbe26e9 — visual-prompt-forge/adapters/flux.md:5-5 (paragraph)

Flux rewards natural-language prompts that read like a competent photographer briefing themselves. It interprets full sentences accurately and handles spatial relationships better than Midjourney. It's the photorealism leader as of Q2 2026, choose Flux over Midjourney when the brief calls for "looks like a real photograph" rather than "looks designed."

Extracted rules inside block: NONE

## a0881a42fa6d94e3 — visual-prompt-forge/adapters/flux.md:7-7 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## 9025ba705ee88bb6 — visual-prompt-forge/adapters/flux.md:9-11 (code)

```
{One or two natural-language sentences describing the subject and action}. {Sentence describing environment and lighting}. {Sentence describing technical/photographic specs}. {Brand mood line.}
```

Extracted rules inside block: NONE

## 9fe27d21c49a92fd — visual-prompt-forge/adapters/flux.md:13-13 (paragraph)

Periods separate beats. Each sentence does one job. No bracket weights, no `--` flags. Flux is parameterless on most APIs (fal.ai, Replicate, BFL direct).

Extracted rules inside block: NONE

## db5d9bab4101c8f8 — visual-prompt-forge/adapters/flux.md:15-15 (heading)

## Where parameters go

Extracted rules inside block: NONE

## 0beecdb1110bb747 — visual-prompt-forge/adapters/flux.md:17-17 (paragraph)

Flux parameters are typically passed alongside the prompt, not inside it:

Extracted rules inside block: NONE
