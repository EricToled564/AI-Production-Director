# Source coverage review 217/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 76dabac6c61efd75 — visual-prompt-forge/adapters/seedance.md:28-28 (table_row)

| `shots` | 1 | Number of cuts in the sequence when using multi-shot mode |

Extracted rules inside block: NONE

## 5903fe8b8c616635 — visual-prompt-forge/adapters/seedance.md:30-33 (code)

```
# shot_02-shot_04. Seedance 2.0: ar=9:16, shots=3, multi-shot sequence
{prompt}
```

Extracted rules inside block: NONE

## a6ad6e00a8b1f874 — visual-prompt-forge/adapters/seedance.md:35-35 (heading)

## Length

Extracted rules inside block: NONE

## ac0bd07b0a48c60e — visual-prompt-forge/adapters/seedance.md:37-37 (paragraph)

Seedance handles **80–150 words**. In multi-shot mode, keep each shot clause short, one camera move and one action per cut.

Extracted rules inside block: NONE

## 78b6a2e352274dbc — visual-prompt-forge/adapters/seedance.md:39-39 (heading)

## When to use multi-shot vs single

Extracted rules inside block: NONE

## 005af166900d1b31 — visual-prompt-forge/adapters/seedance.md:41-41 (table_row)

| Situation | Mode |

Extracted rules inside block: NONE

## 0a5c60486c22ace4 — visual-prompt-forge/adapters/seedance.md:43-43 (table_row)

| One beat, one frame | Single shot (or use Kling) |

Extracted rules inside block: 1d0075533417

## e4dcc0e8963a0a40 — visual-prompt-forge/adapters/seedance.md:44-44 (table_row)

| 2–4 consecutive beats, same subject, want continuity | Multi-shot sequence |

Extracted rules inside block: NONE

## 9c00593c8da60370 — visual-prompt-forge/adapters/seedance.md:45-45 (table_row)

| Beats with different subjects/locations | Separate generations, assemble in edit |

Extracted rules inside block: NONE

## 0dd86909c2e2e4ce — visual-prompt-forge/adapters/seedance.md:47-47 (paragraph)

Map consecutive `shots.json` entries that share a subject into one Seedance multi-shot prompt; reference them by id range in the comment.

Extracted rules inside block: NONE

## 3c92f2498ee8c18e — visual-prompt-forge/adapters/seedance.md:49-49 (heading)

## Motion vocabulary

Extracted rules inside block: NONE

## 8e8154f045e1c183 — visual-prompt-forge/adapters/seedance.md:51-51 (paragraph)

The shot grammar `motion` field maps directly. One move per cut.

Extracted rules inside block: NONE

## ba1374f9a6ba4960 — visual-prompt-forge/adapters/seedance.md:53-53 (table_row)

| `motion` | Video prompt phrase |

Extracted rules inside block: NONE

## 0d1696e99b8303f7 — visual-prompt-forge/adapters/seedance.md:55-55 (table_row)

| `static` | "Static camera, locked off." |

Extracted rules inside block: NONE

## a6f60f8831e571d6 — visual-prompt-forge/adapters/seedance.md:56-56 (table_row)

| `push` / `pull` | "Camera dollies forward / backward slowly." |

Extracted rules inside block: NONE

## 4f6e720784315a2c — visual-prompt-forge/adapters/seedance.md:57-57 (table_row)

| `pan-left` / `pan-right` | "Camera pans smoothly left / right." |

Extracted rules inside block: NONE

## b74c96550527d586 — visual-prompt-forge/adapters/seedance.md:58-58 (table_row)

| `tilt-up` / `tilt-down` | "Camera tilts up / down." |

Extracted rules inside block: NONE

## f20954ed3909a1fe — visual-prompt-forge/adapters/seedance.md:59-59 (table_row)

| `handheld` | "Handheld camera, subtle organic movement." |

Extracted rules inside block: NONE

## 582d194c53ace260 — visual-prompt-forge/adapters/seedance.md:60-60 (table_row)

| `orbit` | "Camera orbits the subject slowly." |

Extracted rules inside block: NONE

## 85d2885cf846fd7f — visual-prompt-forge/adapters/seedance.md:61-61 (table_row)

| `whip` | "Fast whip pan with motion blur." |

Extracted rules inside block: NONE

## 73159c1bd7d1175f — visual-prompt-forge/adapters/seedance.md:62-62 (table_row)

| `rack` | "Rack focus from foreground to background." |

Extracted rules inside block: NONE

## 693e4394c274ffef — visual-prompt-forge/adapters/seedance.md:64-64 (heading)

## Example

Extracted rules inside block: NONE

## 899bb96a7a35bcb7 — visual-prompt-forge/adapters/seedance.md:66-66 (paragraph)

**Three consecutive beats of the same founder, mapped to one sequence.**

Extracted rules inside block: NONE

## 990b5d6ecc9308da — visual-prompt-forge/adapters/seedance.md:68-70 (code)

```
Shot 1: static eye-level, the founder closes his laptop and exhales. Shot 2: slow push toward his face as he looks toward the window. Shot 3: handheld over-the-shoulder as he stands and crosses the room. Consistent subject throughout: a founder in his mid-thirties with salt-and-pepper hair, navy crewneck. Minimalist home office, white walls, oak desk, soft natural side-light from a large window on the left, warm afternoon golden hour. Warm filmic color grade with muted teal shadows. Calm, considered, operator mood.
```

Extracted rules inside block: NONE

## 6ca8e07c3f068e82 — visual-prompt-forge/adapters/seedance.md:72-72 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 4eda167cdaa7cd4d — visual-prompt-forge/adapters/seedance.md:74-74 (list_item)

- **Don't force unrelated beats into one sequence.** Multi-shot is for shots that genuinely belong to one take.

Extracted rules inside block: 809c2ad96fb5

## 863689e44811a130 — visual-prompt-forge/adapters/seedance.md:75-75 (list_item)

- **Don't write more than ~4 cuts per generation.** Consistency degrades past that; split and assemble in edit.

Extracted rules inside block: 048f897b25c5

## e85f64d95a4e1845 — visual-prompt-forge/adapters/seedance.md:76-76 (list_item)

- **Don't vary the character anchor between cuts.** Restate it once for the whole sequence, verbatim.

Extracted rules inside block: 76a577ed1882

## e6d89d13e582cc2e — visual-prompt-forge/adapters/seedance.md:77-77 (list_item)

- **Don't include text content.** Composite captions from `text-overlays.json` in post.

Extracted rules inside block: 1e69aea69fe9

## f5dd897b93f9ca8d — visual-prompt-forge/adapters/seedance.md:78-78 (list_item)

- **Don't stack two camera moves inside one cut.** One move per cut.

Extracted rules inside block: 88e3343e529d
