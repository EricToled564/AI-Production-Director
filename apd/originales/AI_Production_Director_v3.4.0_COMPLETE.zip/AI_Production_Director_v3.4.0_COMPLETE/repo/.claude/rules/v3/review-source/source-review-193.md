# Source coverage review 193/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5711f6e34c481772 — visual-asset-critic/references/critique-rubric.md:56-56 (table_row)

| Anatomy | Correct | Minor weirdness | Major anatomy errors |

Extracted rules inside block: NONE

## aa4f8fb6e983384b — visual-asset-critic/references/critique-rubric.md:57-57 (table_row)

| Background artifacts | Clean | Minor weirdness | Distorted text, melted objects, impossible geometry |

Extracted rules inside block: NONE

## 8d881f3ad4d47067 — visual-asset-critic/references/critique-rubric.md:59-59 (paragraph)

Technical hard fails are almost always **re-roll required**. The prompt was probably fine; the generator just produced a bad sample. Budget 2–3 re-rolls.

Extracted rules inside block: 666f8ca49e65

## e7eb332312b45bcd — visual-asset-critic/references/critique-rubric.md:61-61 (heading)

## Layer 6. Continuity check (if previous shots available)

Extracted rules inside block: NONE

## 8b6732af40687f64 — visual-asset-critic/references/critique-rubric.md:63-63 (table_row)

| Check | Pass | Soft fail | Hard fail |

Extracted rules inside block: NONE

## 68b1fe66f1109c19 — visual-asset-critic/references/critique-rubric.md:65-65 (table_row)

| Character match | Same person, same look | Slight drift | Clearly different person |

Extracted rules inside block: NONE

## e10ab3bc0851fccd — visual-asset-critic/references/critique-rubric.md:66-66 (table_row)

| Lighting continuity | Same direction, time of day | Subtle shift | Direction reversed, time of day jumped |

Extracted rules inside block: NONE

## 4bac4afc37864d35 — visual-asset-critic/references/critique-rubric.md:67-67 (table_row)

| Environment continuity | Same space | Slight environment drift | Different space |

Extracted rules inside block: NONE

## fd003897e2e5d0cb — visual-asset-critic/references/critique-rubric.md:68-68 (table_row)

| Color grade match | Identical | Subtle shift | Visibly different |

Extracted rules inside block: NONE

## 8257e5cfb02aceb7 — visual-asset-critic/references/critique-rubric.md:70-70 (paragraph)

Continuity hard fails break the storyboard. REVISE with verbatim-anchor checks on the prompt.

Extracted rules inside block: NONE

## 190fcc60eef80f04 — visual-asset-critic/references/critique-rubric.md:72-72 (heading)

## From pass/fail to severity

Extracted rules inside block: NONE

## 54d8f5629b189706 — visual-asset-critic/references/critique-rubric.md:74-76 (paragraph)

The tables above grade each check as pass, soft fail, or hard fail. The JSON critique
records a severity instead, and the verdict is derived from those severities. Map them
this way, and only this way:

Extracted rules inside block: NONE

## 3cf4ce30c771c632 — visual-asset-critic/references/critique-rubric.md:78-78 (table_row)

| Rubric result | Severity | Why |

Extracted rules inside block: NONE

## 8672aaaff69b34d7 — visual-asset-critic/references/critique-rubric.md:80-80 (table_row)

| Soft fail on any layer | `minor` | Post can absorb it. `fix_type` is usually `post-level` |

Extracted rules inside block: NONE

## abf45e8319d4161a — visual-asset-critic/references/critique-rubric.md:81-81 (table_row)

| Hard fail **with** a clear fix path | `major` | A prompt change or a re-roll resolves it |

Extracted rules inside block: NONE

## 96dfd2d274c5f8df — visual-asset-critic/references/critique-rubric.md:82-82 (table_row)

| Hard fail on Brand Lock or Series Lock **with no** fix path | `blocking` | Nothing downstream recovers this |

Extracted rules inside block: NONE

## cc9a46234595c706 — visual-asset-critic/references/critique-rubric.md:83-83 (table_row)

| Any defect that makes the asset unusable | `blocking` | Same, regardless of layer |

Extracted rules inside block: NONE

## e98e764e283df9b4 — visual-asset-critic/references/critique-rubric.md:85-85 (heading)

## Aggregating verdict

Extracted rules inside block: NONE

## 5cec77c0ae3d6953 — visual-asset-critic/references/critique-rubric.md:87-87 (paragraph)

The verdict follows from the severities. It is not a separate judgement:

Extracted rules inside block: NONE

## c05d14e0495e0a74 — visual-asset-critic/references/critique-rubric.md:89-89 (table_row)

| Severities present | Verdict |

Extracted rules inside block: NONE

## cafbbccaa6df1c8d — visual-asset-critic/references/critique-rubric.md:91-91 (table_row)

| any `blocking` | REJECT |

Extracted rules inside block: NONE

## bac12ca3a4a97348 — visual-asset-critic/references/critique-rubric.md:92-92 (table_row)

| three or more `major` | REJECT |

Extracted rules inside block: NONE

## 90c83d13e4cc0ddf — visual-asset-critic/references/critique-rubric.md:93-93 (table_row)

| one or two `major` | REVISE |

Extracted rules inside block: NONE

## aa69f35eba1eb36d — visual-asset-critic/references/critique-rubric.md:94-94 (table_row)

| only `minor`, or none | ACCEPT (with post notes) |

Extracted rules inside block: NONE

## 8f89dd1e1762cf3d — visual-asset-critic/references/critique-rubric.md:96-99 (paragraph)

`tools/validate_critique.py` enforces exactly this table, so a critique that disagrees with
it fails rather than shipping. Earlier versions of this file counted hard fails and called
3+ a REJECT while the skill said "escalate at your discretion." Those two rules disagreed,
and the disagreement is the reason the threshold is now a number.

Extracted rules inside block: NONE

## bdb444be7aa8fba2 — visual-asset-critic/references/critique-rubric.md:101-103 (paragraph)

Soft fails are noted but don't change the verdict on their own. If you have three or more of
them, look again: a cluster of soft fails usually means one of them is really a hard fail
you talked yourself out of.

Extracted rules inside block: 129f383f5d5b

## e516b1e0fc14b529 — visual-asset-critic/references/critique-rubric.md:105-105 (heading)

## Speed bumps to remember

Extracted rules inside block: NONE

## fcee3a5f018bb977 — visual-asset-critic/references/critique-rubric.md:107-107 (list_item)

- **Don't critique what wasn't asked**, if the spec didn't call for cinematic mood, don't say "could be more cinematic"

Extracted rules inside block: d1eff8b1d346

## 6779826143457fff — visual-asset-critic/references/critique-rubric.md:108-108 (list_item)

- **Don't pile-on once verdict is set**, if you're rejecting, list the issues that drive the rejection; don't list every cosmetic concern

Extracted rules inside block: faba6eeb358a

## 53899815031b041f — visual-asset-critic/references/critique-rubric.md:109-109 (list_item)

- **Be specific, always**, "lighting is off" is not a critique; "key light is camera-right but series_lock says camera-left" is

Extracted rules inside block: 081a4d70df12
