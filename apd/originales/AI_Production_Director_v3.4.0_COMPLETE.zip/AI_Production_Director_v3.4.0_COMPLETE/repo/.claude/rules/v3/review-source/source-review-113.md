# Source coverage review 113/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 93f3903ea570a203 — storyboard-architect/references/on-screen-text.md:32-32 (paragraph)

This goes into the shot's rationale: "MCU left-third subject, reserves right-third for `text_03`."

Extracted rules inside block: NONE

## 9ad3d38a1315fa2d — storyboard-architect/references/on-screen-text.md:34-34 (heading)

### Positions

Extracted rules inside block: NONE

## cad0e568b89e309b — storyboard-architect/references/on-screen-text.md:36-36 (table_row)

| Position | Use when |

Extracted rules inside block: e9db5f8c373c

## d3dbe3c9d79bf5d5 — storyboard-architect/references/on-screen-text.md:38-38 (table_row)

| `center` | Display headline, single concept, hard cut in/out |

Extracted rules inside block: NONE

## 3738728f1f5a3e98 — storyboard-architect/references/on-screen-text.md:39-39 (table_row)

| `lower-third` | Caption / VO substitute, persistent across shots |

Extracted rules inside block: NONE

## 851171736398fc0b — storyboard-architect/references/on-screen-text.md:40-40 (table_row)

| `upper-third` | Stat callout, secondary information |

Extracted rules inside block: NONE

## 4879e5b63710332e — storyboard-architect/references/on-screen-text.md:41-41 (table_row)

| `left-third` | Subject is right-weighted in frame |

Extracted rules inside block: NONE

## 71620999b9f3d6b7 — storyboard-architect/references/on-screen-text.md:42-42 (table_row)

| `right-third` | Subject is left-weighted in frame |

Extracted rules inside block: NONE

## 8430d0fce21d4278 — storyboard-architect/references/on-screen-text.md:43-43 (table_row)

| `{x: %, y: %}` | Custom, only when the standard positions don't fit |

Extracted rules inside block: 920a20ec8466

## 9b023e74e457c3cf — storyboard-architect/references/on-screen-text.md:45-45 (heading)

### Sizes

Extracted rules inside block: NONE

## d2daf65d465f735a — storyboard-architect/references/on-screen-text.md:47-47 (table_row)

| Size | Pixel approx (1080p) | Use for |

Extracted rules inside block: 1fc6569ab6e6

## 491257dc000a9e76 — storyboard-architect/references/on-screen-text.md:49-49 (table_row)

| `display` | 96–144 px | Hero/hook beats |

Extracted rules inside block: NONE

## 5614c5895546a932 — storyboard-architect/references/on-screen-text.md:50-50 (table_row)

| `headline` | 56–80 px | Reframe beats |

Extracted rules inside block: NONE

## e433cc254036c691 — storyboard-architect/references/on-screen-text.md:51-51 (table_row)

| `body` | 32–48 px | Caption-style, persistent |

Extracted rules inside block: NONE

## a555b32df26a7f46 — storyboard-architect/references/on-screen-text.md:52-52 (table_row)

| `caption` | 20–28 px | Disclaimers, attribution |

Extracted rules inside block: NONE

## 1993c0cca5a56a59 — storyboard-architect/references/on-screen-text.md:54-54 (heading)

### Animation

Extracted rules inside block: NONE

## 7108350be367d31b — storyboard-architect/references/on-screen-text.md:56-56 (paragraph)

Default to clean, not flashy:

Extracted rules inside block: NONE

## 768eacc509c8d3ab — storyboard-architect/references/on-screen-text.md:58-58 (list_item)

- Hook beats → `hard-cut` in, `hard-cut` out (no fade)

Extracted rules inside block: NONE

## f013b7f0b2d6968e — storyboard-architect/references/on-screen-text.md:59-59 (list_item)

- Reframe beats → `fade-in` 0.2s, `fade-out` 0.2s

Extracted rules inside block: NONE

## e1381c36aa198e13 — storyboard-architect/references/on-screen-text.md:60-60 (list_item)

- Persistent captions → `slide-up` in, `slide-down` out

Extracted rules inside block: NONE

## 89b0bd62cc2df952 — storyboard-architect/references/on-screen-text.md:61-61 (list_item)

- CTA → `type-on` for a typewriter effect, or `slide-up`

Extracted rules inside block: NONE

## 665d844096785c5a — storyboard-architect/references/on-screen-text.md:63-63 (paragraph)

Avoid stacking animations. Pick one per overlay.

Extracted rules inside block: b8de26203616

## 956b729ae97046a1 — storyboard-architect/references/on-screen-text.md:65-65 (heading)

## Color rules

Extracted rules inside block: NONE

## 5e0ae6a74e4cfc41 — storyboard-architect/references/on-screen-text.md:67-67 (paragraph)

The `color` field of every text overlay must be a hex value that exists in the brand-lock palette. If you find yourself wanting a color that's not in the palette, the answer is not to add it, the answer is to pick a different overlay style or shot composition.

Extracted rules inside block: 4d38c07f31bc

## b6428b67f6b148fa — storyboard-architect/references/on-screen-text.md:69-69 (heading)

## Typography rules

Extracted rules inside block: NONE

## 75229b343f615c5d — storyboard-architect/references/on-screen-text.md:71-71 (paragraph)

Same: every `font` field must reference a font defined in brand-lock typography. Two fonts max per project (display + body). More than that and the brand stops being recognizable.

Extracted rules inside block: a02af067c0d7

## ba6a7faa71729e57 — storyboard-architect/references/on-screen-text.md:73-73 (heading)

## The "read twice" rule

Extracted rules inside block: NONE

## 996e9c82d72d332e — storyboard-architect/references/on-screen-text.md:75-75 (paragraph)

Already covered in timing-rules.md but worth repeating: text needs to be on screen long enough for someone to read it twice. Calculate, then verify. Don't eyeball.

Extracted rules inside block: d12c201a1b38

## b8e8775195d9dcea — storyboard-architect/references/on-screen-text.md:77-77 (heading)

## Stacking text across shots

Extracted rules inside block: NONE

## a95a2f94ab8bc05e — storyboard-architect/references/on-screen-text.md:79-79 (paragraph)

Text can persist across consecutive shots. This is useful when:

Extracted rules inside block: NONE
