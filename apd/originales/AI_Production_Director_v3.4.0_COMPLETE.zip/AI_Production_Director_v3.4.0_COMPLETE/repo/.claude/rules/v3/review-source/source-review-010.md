# Source coverage review 10/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 269dc835abb3e330 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:52-52 (paragraph)

**Prompt to copy:**

Extracted rules inside block: NONE

## 3318bbada15cab1c — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:54-54 (list_item)

> Medium wide shot slow dolly forward into a cozy specialty coffee shop interior, warm morning sunlight streaming through large windows on the left, reclaimed dark wood counter in sharp focus with shelves of handmade ceramic mugs blurred in background, dust motes visible in sun rays, muted sage green wall accents, shallow depth of field, 35mm full-frame look, subtle film grain, warm 3200K color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

Extracted rules inside block: 77dae376706d

## 434ad275bda6f8bb — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:56-56 (paragraph)

**Audio direction:** Acoustic guitar strum begins, layered with distant morning street sounds (birds, footsteps).

Extracted rules inside block: NONE

## 8167fc6854a4910c — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:60-60 (heading)

## Shot 3 (10-15s) — Human: The Barista

Extracted rules inside block: NONE

## 32189d8a183092f9 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:62-62 (paragraph)

**Purpose:** Add a human face. Empathy trigger. This is the emotional center.

Extracted rules inside block: NONE

## 4421ab44b1ad7221 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:64-68 (paragraph)

**Composition:** Medium close-up (MCU), slightly low angle (~10° up)
**Camera move:** Locked off
**Lighting:** Window light as key from camera-left, warm practical from counter lamp as fill
**Subject:** A female barista in her late 20s, wavy auburn hair tied back loosely, wearing a denim apron over a cream linen shirt
**Action:** She looks down at a pour-over in her hands, then looks up toward camera with a small, genuine smile

Extracted rules inside block: NONE

## 6c576ccaabb7f808 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:70-70 (paragraph)

**Prompt to copy:**

Extracted rules inside block: NONE

## c8946231e3585e47 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:72-72 (list_item)

> Medium close-up slightly low angle of a female barista in her late twenties with wavy auburn hair tied back, wearing a denim apron over cream linen shirt, standing behind a dark wood café counter, soft window light from the left creating warm rim light on her hair, she looks down at a pour-over coffee in her hands then slowly looks up at camera with a genuine small smile, shallow depth of field, 35mm full-frame look, subtle 16mm film grain, warm color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

Extracted rules inside block: 5a47044d4f05

## 432719e7ac56c73d — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:74-74 (paragraph)

**Audio direction:** Guitar melody crescendo, ambient café sounds swell subtly. No voice-over needed — her expression carries the emotion.

Extracted rules inside block: NONE

## c24c4d1189849e79 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:78-78 (heading)

## Shot 4 (15-20s) — Detail: The Beans

Extracted rules inside block: NONE

## 9f0b053852248f40 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:80-80 (paragraph)

**Purpose:** Tactile close-up. Signals craft and quality.

Extracted rules inside block: NONE

## 1635ecefe750f7b0 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:82-86 (paragraph)

**Composition:** Extreme close-up (ECU), macro-style
**Camera move:** Micro zoom in
**Lighting:** Warm directional light from upper right, strong shadows
**Subject:** Hand scooping whole coffee beans from a burlap sack into a wooden measuring cup
**Action:** Slow-motion bean cascade as hand tips the scoop

Extracted rules inside block: NONE

## 19be25cb3c203ea8 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:88-88 (paragraph)

**Prompt to copy:**

Extracted rules inside block: NONE

## 5193e1051e35845b — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:90-90 (list_item)

> Macro extreme close-up of a hand scooping whole dark roasted coffee beans from a burlap sack into a small wooden measuring cup, slow motion cascade of beans spilling out as the hand tips the scoop, warm directional window light from upper right creating strong shadow depth, individual beans visible in sharp detail, shallow depth of field, deep espresso brown and burlap cream palette, subtle 16mm film grain, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

Extracted rules inside block: c8f0207d430c

## d778ed3cfcf0c904 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:92-92 (paragraph)

**Audio direction:** Sound of beans tumbling, slightly rhythmic, quantized to the guitar beat. Guitar is now in full swing.

Extracted rules inside block: NONE

## a29f2108acf4524d — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:96-96 (heading)

## Shot 5 (20-25s) — Atmosphere: The Customer Moment

Extracted rules inside block: NONE

## 6ea2db6f5fd123f8 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:98-98 (paragraph)

**Purpose:** Show the space in use. Aspirational — "this could be you."

Extracted rules inside block: 1219f5e0d9b2

## f223cf3782576ce1 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:100-104 (paragraph)

**Composition:** Medium shot (MS), over-the-shoulder angle (OTS)
**Camera move:** Slow pedestal down (~0.5x speed feeling)
**Lighting:** Window backlight creating gentle rim on the customer, warm amber spill from interior
**Subject:** A young customer sitting at a wooden window counter, laptop open, ceramic cup in hand
**Action:** She takes a slow sip, closes eyes briefly, sets cup down

Extracted rules inside block: 2902addca8bc

## fe3a554682db3fbd — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:106-106 (paragraph)

**Prompt to copy:**

Extracted rules inside block: NONE

## e1f509f33f1ef4a0 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:108-108 (list_item)

> Over-the-shoulder medium shot of a young female customer sitting at a wooden window counter inside a coffee shop, her laptop open in soft focus, a handmade ceramic coffee cup in her hand, warm window backlight creating gentle rim light on her silhouette, amber interior lamps in background blur, she slowly takes a sip of coffee and briefly closes her eyes in appreciation, slow pedestal camera move downward, shallow depth of field, 35mm full-frame look, subtle film grain, warm 3200K color temperature, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

Extracted rules inside block: 2fa4d2c7b81a

## eabb6b8ad5183415 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:110-110 (paragraph)

**Audio direction:** Guitar continues, ambient café sounds (gentle chatter, page turning), the soft clink of cup on saucer at the end.

Extracted rules inside block: NONE

## a13a92bb20e16699 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:114-114 (heading)

## Shot 6 (25-30s) — CTA: Opening Reveal

Extracted rules inside block: NONE

## c2cbaed40993db4f — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:116-116 (paragraph)

**Purpose:** Clear, confident call to action. Brand reveal.

Extracted rules inside block: NONE

## 9b4204f23a3efef5 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:118-122 (paragraph)

**Composition:** Medium wide shot (MWS), straight-on eye level
**Camera move:** Locked off, zero movement (intentional stop to read text)
**Lighting:** Soft even morning light
**Subject:** The café's hand-painted wooden sign on the front door, "Opening Saturday" chalk text visible below
**Action:** Minimal — a hand hanging an "OPEN" wooden sign on the door handle

Extracted rules inside block: NONE

## 13d1dc321d3c785b — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:124-124 (paragraph)

**Prompt to copy:**

Extracted rules inside block: NONE

## 01151b6c2209a207 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:126-126 (list_item)

> Medium wide locked-off shot of a hand-painted wooden shop sign above a dark-framed café door, below it a small chalkboard reading "Opening Saturday", a hand reaches in frame to hang a wooden "OPEN" sign on the door handle, soft even morning light, sage green accent wall visible, warm muted palette, shallow depth of field on the door, 35mm full-frame look, subtle film grain, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

Extracted rules inside block: 187b454cbab2

## 239a5b96f004b652 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:128-128 (paragraph)

**Audio direction:** Guitar resolves to final note, café ambience fades down. Sound of the wooden sign clacking against the door.

Extracted rules inside block: NONE

## 53abe0c23a0d5a5f — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:132-132 (heading)

## Post-Production Checklist

Extracted rules inside block: NONE

## b29a2648fa0d4c22 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:134-134 (list_item)

- [ ] Generate all 6 shots with your preferred AI video tool

Extracted rules inside block: 9a4dc616b79a

## 40ca9e8fa78059b2 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:135-135 (list_item)

- [ ] Stitch in **CapCut** or **Descript** (simplest for TikTok workflow)

Extracted rules inside block: NONE
