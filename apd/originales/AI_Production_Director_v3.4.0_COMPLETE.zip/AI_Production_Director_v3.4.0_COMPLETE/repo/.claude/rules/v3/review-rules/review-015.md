# Rule classification review 15/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## a3a914e3cc76 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:40

never use stock photo aesthetic

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "a3a914e3cc76",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 27106589325a — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:41

never use AI uncanny faces

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "27106589325a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## e36e4e915e22 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:42

never over-saturate the cream background

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "e36e4e915e22",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## e332bd9ab5e4 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:43

never use coral as a flood color (only as accent or signature periods)

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "e332bd9ab5e4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 8872811db986 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:44

never use em dashes in copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "8872811db986",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 238d45333621 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:45

never use emojis in body copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "238d45333621",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 2c4049036a1c — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:46

never use bullet points in narrative copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "2c4049036a1c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## a395c22dcc78 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:47

never use clip-art or generic icon sets

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "a395c22dcc78",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 00995a3683fc — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:48

never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "00995a3683fc",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## b8ecf738aef4 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:49

never use exclamation points in headlines

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "b8ecf738aef4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 6c29ef0b91ea — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:50

never default to dark mode, light mode hybrid is the brand

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "6c29ef0b91ea",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 2fffe09d9421 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:51

never animate text with bouncing or wobbling, type-on, fade, or hard cut only

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "2fffe09d9421",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 3360a984540d — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:62

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "3360a984540d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 16757b9fc180 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:66

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "16757b9fc180",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 1e60c3c96fdf — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:74

prefer specific numbers over vague claims

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "1e60c3c96fdf",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 316b66acea7f — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:75

prefer present-tense over future-tense

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "316b66acea7f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## db8af09c10ce — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:76

prefer "operator" over "creator", "infrastructure" over "agency"

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "db8af09c10ce",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 1cfd332fc36c — storyboard-architect/examples/60s-founder-explainer/storyboard.md:34

**Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "1cfd332fc36c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 6b0bd36bc2b5 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:62

**Beat:** insight · **VO:** "Every brand has a voice. Most founders never extract it. So every post starts from scratch."

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "6b0bd36bc2b5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 02f8afcf0321 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:16

Role | Hex | Use

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "02f8afcf0321",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 7c6a0590780e — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:43

never use stock photo aesthetic

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "7c6a0590780e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## a33095e83db8 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:44

never use AI uncanny faces

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "a33095e83db8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 6532d54d8d55 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:45

never over-saturate the cream background

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "6532d54d8d55",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 60b48c2a87a8 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:46

never use coral as a flood color (only as accent or signature periods)

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "60b48c2a87a8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 5dd089fbd405 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:47

never use em dashes in copy (only periods, commas, semicolons)

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "5dd089fbd405",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## ad5d969ec6c6 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:48

never use emojis in body copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "ad5d969ec6c6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 96ba276c90e0 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:49

never use bullet points in narrative copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "96ba276c90e0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## e611bf62b644 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:50

never use clip-art or generic icon sets

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "e611bf62b644",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 26da66b6aae8 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:51

never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "26da66b6aae8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 3e41ac1a76e4 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:52

never use exclamation points in headlines

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "3e41ac1a76e4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## dabc9c235d86 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:53

never default to dark mode, light mode hybrid is the brand

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "dabc9c235d86",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 1243aa3d2453 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:54

never animate text with bouncing or wobbling, type-on, fade, or hard cut only

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "1243aa3d2453",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 8369a4d99e3a — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:55

never break the eye line between subject and the implied "operator perspective"

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "8369a4d99e3a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## eb2e36b0f664 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:66

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup. Skin tones warm but not orange. Greens kept slightly desaturated to push focus to subject.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "eb2e36b0f664",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 1c35cb73c43f — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:70

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only, no fancy wipes, no zooms.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "1c35cb73c43f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```
