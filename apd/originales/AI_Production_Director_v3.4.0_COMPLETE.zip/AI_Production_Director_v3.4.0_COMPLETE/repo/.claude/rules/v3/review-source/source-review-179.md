# Source coverage review 179/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4bd072cf5fecfba0 — video/references/seedance.md:401-401 (paragraph)

For dramatic, multi-shot, character-locked, or stitched-clip work — always use the 11-block production-grade skeleton from section 6.

Extracted rules inside block: b0ad1c8a9841

## 36e1d94db0548251 — video/references/seedance.md:403-403 (heading)

## 17. Seedance 2.5 → read `seedance-25.md`

Extracted rules inside block: NONE

## 7dc1dec72ecdee6c — video/references/seedance.md:405-405 (paragraph)

2.5 changes the workflow: a 15-30s narrative that used to be 3-6 stitched clips is now one generation with one continuous arc, extendable to 60s, with a separate Ultra Long mode to 180s. The dramaturgy does not change — the beat map from `dramaturgy.md` §10 moves inside a single prompt.

Extracted rules inside block: NONE

## 8c91c89670d5a241 — video/references/seedance.md:407-407 (paragraph)

Everything 2.5-specific lives in **`seedance-25.md`**: the official prompt formulas, the `( ) < > { } 【 】` markers, the 50-slot reference discipline, stages + end states, video editing, extension, Ultra Long, blockout/green-screen pipeline, and the official worked examples. For any 2.5 production task, read that file before writing the prompt.

Extracted rules inside block: NONE

## d1d0bf72eca18833 — video/references/seedance.md:411-411 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 0a456ed9ede0772d — video/references/universal-rules.md:1-1 (heading)

# Universal rules — apply to every video model

Extracted rules inside block: NONE

## 7eaf24d023918d49 — video/references/universal-rules.md:3-3 (paragraph)

These rules apply to Seedance, Kling, Veo, and any other AI video generator. They exist because all current video models share a common failure mode. They reward concrete physical direction. They punish abstraction, contradictions, and keyword spam. Ignoring these produces muddy generations regardless of which model you target.

Extracted rules inside block: NONE

## 983d798a6875bfbf — video/references/universal-rules.md:5-5 (paragraph)

Read this file after `dramaturgy.md` and before any model-specific file. The model-specific syntax sits on top of these rules — it does not replace them.

Extracted rules inside block: NONE

## afb4f292f0892ef7 — video/references/universal-rules.md:7-7 (heading)

## Contents

Extracted rules inside block: NONE

## 5a883d77e1273e59 — video/references/universal-rules.md:9-9 (list_item)

1. The non-negotiable. Details intensify emotion (Details Law)

Extracted rules inside block: 0c19077fcce6

## 9e5e772a8b45d355 — video/references/universal-rules.md:10-10 (list_item)

2. U1. Universal prompt skeleton

Extracted rules inside block: e8489acd8e2d

## 30132bdab06d68c7 — video/references/universal-rules.md:11-11 (list_item)

3. U2. Weight-at-start

Extracted rules inside block: 998e8f6285da

## 8aacc89a14061609 — video/references/universal-rules.md:12-12 (list_item)

4. U3. Show don't tell

Extracted rules inside block: c2552fc8f2f4

## ac0e44d4f85b3c46 — video/references/universal-rules.md:13-13 (list_item)

5. U4. Natural language beats tag spam

Extracted rules inside block: 61bb46d9c591

## 5eae2f7466f7e1cc — video/references/universal-rules.md:14-14 (list_item)

6. U5. One primary camera move per shot

Extracted rules inside block: 8b7910e2698e

## 4d9dd0e5b1d700e0 — video/references/universal-rules.md:15-15 (list_item)

7. U6. Precise lens language

Extracted rules inside block: f8f7b1430406

## 781098b58fbe0e8e — video/references/universal-rules.md:16-16 (list_item)

8. U7. Character consistency anchor

Extracted rules inside block: 756e85208393

## b4042a049f42b2c8 — video/references/universal-rules.md:17-17 (list_item)

9. U8. No contradictions

Extracted rules inside block: f858fe7239f1

## cee8098d26bc1125 — video/references/universal-rules.md:18-18 (list_item)

10. U9. Concrete physical detail over abstract concept

Extracted rules inside block: e577be08718f

## 0a2a365ecc1edc86 — video/references/universal-rules.md:19-19 (list_item)

11. U10. Duration discipline

Extracted rules inside block: 21e9fc4291c0

## 171b443ae3898264 — video/references/universal-rules.md:20-20 (list_item)

12. U11. The final image rule

Extracted rules inside block: 3b20f5ef9586

## ca1d5a9ff0ffd1eb — video/references/universal-rules.md:21-21 (list_item)

13. U12. The three-detail check (audit before sending)

Extracted rules inside block: 83fe6d139450

## 42d1c97a3224163b — video/references/universal-rules.md:22-22 (list_item)

14. U13. Reference role discipline

Extracted rules inside block: fddd218ba636

## 7b7c375d55303be6 — video/references/universal-rules.md:23-23 (list_item)

15. U14. Priority declaration

Extracted rules inside block: 3e731209c85c

## 6ffdb0240a3c8591 — video/references/universal-rules.md:27-27 (heading)

## 1. The non-negotiable. Details intensify emotion. Laziness kills the prompt.

Extracted rules inside block: NONE

## 4c91b30917519f0c — video/references/universal-rules.md:29-29 (paragraph)

This is the most violated rule in AI video, and the one reason most multi-shot prompts fail. The dramaturgy is fine — the writer just got lazy on a single shot, and that one thin shot drags the whole sequence into mush.

Extracted rules inside block: NONE

## 6d2fa58548748ba6 — video/references/universal-rules.md:31-31 (paragraph)

Every shot in every prompt owns at least three concrete physical details:

Extracted rules inside block: NONE

## 2dc9d20251116e2e — video/references/universal-rules.md:33-33 (list_item)

1. **One environmental pressure.** Cold blue refrigerator light. Steam off boiling water. Wet asphalt. Flickering fluorescent. Dripping tap. Curtain breathing in the AC. (Kurosawa: weather is a character. See `dramaturgy.md` §9.)

Extracted rules inside block: 0fe09cc53f0d

## 0340eb8a700278dd — video/references/universal-rules.md:34-34 (list_item)

2. **One physical micro-action.** Jaw locks. Knuckles whiten on the fork. Lips press into a line. He swallows hard. Fingers curl against the doorframe. (Show, not tell — the body is the only place where feelings render.)

Extracted rules inside block: d19bf3dcacbe

## 7cdad96cd0c83532 — video/references/universal-rules.md:35-35 (list_item)

3. **One sound anchor or visual motif.** Stomach growl at 2.3s. Reflection in a darkened phone screen. Rain on the same windowpane. A single fluorescent flicker before each cut.

Extracted rules inside block: 58f5073b3796
