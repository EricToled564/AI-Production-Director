# Source coverage review 141/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 8372eed574966109 — video/references/dramaturgy.md:93-93 (list_item)

1. **Emotion (51%).** Does the cut honor the emotional truth of the moment. What does the viewer feel now vs. what they should feel next.

Extracted rules inside block: 674f79d5da56

## 1b527af7523f0352 — video/references/dramaturgy.md:94-94 (list_item)

2. **Story (23%).** Does the cut advance story or reveal character.

Extracted rules inside block: d8a7429de47c

## 1baf69a9f67dbbe5 — video/references/dramaturgy.md:95-95 (list_item)

3. **Rhythm (10%).** Does the cut fall on a musical beat of the scene.

Extracted rules inside block: d8dab8a1cdca

## 361ff9dfedb15916 — video/references/dramaturgy.md:96-96 (list_item)

4. **Eye-trace (7%).** Where is the viewer's gaze at the moment of the cut. Does the new shot receive that gaze naturally.

Extracted rules inside block: 644d83a21997

## 545b046e7633fdea — video/references/dramaturgy.md:97-97 (list_item)

5. **2D plane (5%).** Does the cut respect the axis of screen direction.

Extracted rules inside block: 753af23aa89c

## 41c447aba0998afb — video/references/dramaturgy.md:98-98 (list_item)

6. **3D space (4%).** Does the cut respect the geometry of the real location.

Extracted rules inside block: ac8452f1e1b0

## c72026dbd3480966 — video/references/dramaturgy.md:100-100 (paragraph)

Practical consequence. Cutting for "динамика" (pace for its own sake) sits at item 3. If you cut there without serving items 1 and 2, the result is TikTok-ad for the attention-deficit.

Extracted rules inside block: NONE

## d8c9d5c18e1ab51c — video/references/dramaturgy.md:102-102 (heading)

## 5. Blocking as choreography of desire

Extracted rules inside block: NONE

## 06bb3a0aa524a98c — video/references/dramaturgy.md:104-104 (paragraph)

Blocking is not "where the actor stands." Blocking is a visual answer to "what does the character want and from whom."

Extracted rules inside block: NONE

## 809a0f5d6e2ea073 — video/references/dramaturgy.md:106-106 (paragraph)

For every character in the scene, name.

Extracted rules inside block: NONE

## 0b059b946d3e2951 — video/references/dramaturgy.md:108-108 (list_item)

- What they want now.

Extracted rules inside block: NONE

## ea6ca4f9eb5ad814 — video/references/dramaturgy.md:109-109 (list_item)

- Who or what they move toward.

Extracted rules inside block: NONE

## 370df10d08086c05 — video/references/dramaturgy.md:110-110 (list_item)

- Who or what they move away from.

Extracted rules inside block: NONE

## 32d48cadb6f803f4 — video/references/dramaturgy.md:111-111 (list_item)

- Whom they corner.

Extracted rules inside block: NONE

## 8981c4586263073a — video/references/dramaturgy.md:112-112 (list_item)

- To whom they yield space.

Extracted rules inside block: NONE

## 0015b26cc1aa71c2 — video/references/dramaturgy.md:113-113 (list_item)

- What gesture reveals the hidden desire.

Extracted rules inside block: NONE

## 92ef42a46af12d7b — video/references/dramaturgy.md:115-116 (paragraph)

Bad. "He stands near the window."
Good. "He edges toward the window but his shoulder stays angled back toward her, as if the conversation still holds him."

Extracted rules inside block: d262a36afb53

## 30e6dfb12fe56497 — video/references/dramaturgy.md:118-118 (heading)

## 6. Staging controls subtext

Extracted rules inside block: NONE

## 55bb36746a42481c — video/references/dramaturgy.md:120-120 (paragraph)

Staging is the arrangement of people, objects, and camera inside the frame. Before dialogue, staging already tells the conflict.

Extracted rules inside block: NONE

## f23a59cac9a23a6a — video/references/dramaturgy.md:122-122 (paragraph)

Power signals in staging.

Extracted rules inside block: NONE

## a725cf69874e534c — video/references/dramaturgy.md:124-124 (list_item)

- The standing character dominates the seated one.

Extracted rules inside block: NONE

## 161d613aae40e1c2 — video/references/dramaturgy.md:125-125 (list_item)

- The character in the doorway controls the room.

Extracted rules inside block: NONE

## 100715e6ed628702 — video/references/dramaturgy.md:126-126 (list_item)

- The character behind glass or in reflection is psychologically distant.

Extracted rules inside block: NONE

## 569b1a7444a9451f — video/references/dramaturgy.md:127-127 (list_item)

- The character in shadow carries threat or grief.

Extracted rules inside block: NONE

## 10d7d4821c0f3bbf — video/references/dramaturgy.md:128-128 (list_item)

- Negative space around a character signals isolation.

Extracted rules inside block: NONE

## 38147d7673a97cc0 — video/references/dramaturgy.md:129-129 (list_item)

- Tight framing signals suffocation.

Extracted rules inside block: NONE

## be1eed5af847a837 — video/references/dramaturgy.md:130-130 (list_item)

- Shared frame without eye contact signals broken intimacy.

Extracted rules inside block: NONE

## 3c6a4c0a0e81f1d8 — video/references/dramaturgy.md:132-132 (paragraph)

Spielberg, Kubrick, Iñárritu often build entire scenes where the staging states the conflict before a line is spoken.

Extracted rules inside block: NONE

## 1e65d4ccbece67cf — video/references/dramaturgy.md:134-134 (paragraph)

Before writing a prompt, name the power dynamic the staging reveals.

Extracted rules inside block: NONE

## 70c1a2722185770d — video/references/dramaturgy.md:136-136 (heading)

## 7. Camera must have a reason

Extracted rules inside block: NONE
