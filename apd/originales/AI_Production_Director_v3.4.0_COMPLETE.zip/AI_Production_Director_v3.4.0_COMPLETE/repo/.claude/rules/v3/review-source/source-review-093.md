# Source coverage review 93/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 45b06543ccdf1c4c — screenwriter/references/pipeline-integration.md:237-241 (code)

```xml
<scene number="1">
  <action>Text here</action>
</scene>
```

Extracted rules inside block: NONE

## 134b3e90747cbb7c — screenwriter/references/pipeline-integration.md:243-243 (paragraph)

**❌ Unescaped special characters:**

Extracted rules inside block: 736496ed383a

## 3489310ede12b31b — screenwriter/references/pipeline-integration.md:244-246 (code)

```xml
<action>She thinks: "I'm < 10 years old"</action>
```

Extracted rules inside block: NONE

## d8aacdaec2d1f372 — screenwriter/references/pipeline-integration.md:248-248 (paragraph)

**✅ Properly escaped:**

Extracted rules inside block: 799c41b4e570

## 10093c612b2215c1 — screenwriter/references/pipeline-integration.md:249-251 (code)

```xml
<action>She thinks: "I'm &lt; 10 years old"</action>
```

Extracted rules inside block: NONE

## dc6c2a83d90442bd — screenwriter/references/pipeline-integration.md:255-255 (heading)

## Pipeline Handoff Checklist

Extracted rules inside block: NONE

## 9c97a513d72c4dfa — screenwriter/references/pipeline-integration.md:257-257 (paragraph)

Before passing screenplay to next pipeline stage:

Extracted rules inside block: NONE

## 29a0d8c5bf33764f — screenwriter/references/pipeline-integration.md:259-259 (list_item)

- [ ] All scenes have complete metadata

Extracted rules inside block: NONE

## 2f04d6efc8dabbbf — screenwriter/references/pipeline-integration.md:260-260 (list_item)

- [ ] key_visuals array populated (3-5 per scene)

Extracted rules inside block: NONE

## 218b32102df009ed — screenwriter/references/pipeline-integration.md:261-261 (list_item)

- [ ] Character names consistent throughout

Extracted rules inside block: NONE

## cd78346cb80915a0 — screenwriter/references/pipeline-integration.md:262-262 (list_item)

- [ ] XML well-formed and parseable

Extracted rules inside block: NONE

## 67bdefadcf9de82b — screenwriter/references/pipeline-integration.md:263-263 (list_item)

- [ ] Total duration within target range (5-10 min)

Extracted rules inside block: NONE

## b4e8735facf9cfc3 — screenwriter/references/pipeline-integration.md:264-264 (list_item)

- [ ] Scene numbers sequential with no gaps

Extracted rules inside block: NONE

## 68bd10ad440c1517 — screenwriter/references/pipeline-integration.md:265-265 (list_item)

- [ ] Visual descriptions rich and specific

Extracted rules inside block: NONE

## 3ece0354acb85291 — screenwriter/references/pipeline-integration.md:266-266 (list_item)

- [ ] No technical camera directions (use visual descriptions instead)

Extracted rules inside block: b66b53810c50

## 5c20d222b23e4fb4 — storyboard-architect/SKILL.md:2-3 (paragraph)

name: storyboard-architect
description: Turn a creative brief into a production-grade storyboard with shot specs, timing, on-screen text, and per-shot rationale. Use when the user describes a video brief, plans a video, references shots or beats, scripts a social video, or hands over a creative concept to break into scenes. Produces run.json, storyboard.md, shots.json, text-overlays.json, and brand-lock.snapshot.md. Pairs with visual-prompt-forge, visual-asset-critic, storyboard-html-preview.

Extracted rules inside block: NONE

## c46a0363785b8e3b — storyboard-architect/SKILL.md:6-6 (heading)

# Storyboard Architect

Extracted rules inside block: NONE

## b9aa777649869d17 — storyboard-architect/SKILL.md:8-8 (paragraph)

You are turning a creative brief into a deterministic storyboard. The output is a set of files an editor, agency, or developer can act on without asking follow-up questions.

Extracted rules inside block: NONE

## 89ffca0a80d3b323 — storyboard-architect/SKILL.md:10-10 (paragraph)

This is not a creative-writing exercise. The output is a spec.

Extracted rules inside block: NONE

## 1db660927ef21d60 — storyboard-architect/SKILL.md:12-12 (heading)

## When to use

Extracted rules inside block: NONE

## 287df22863c64b67 — storyboard-architect/SKILL.md:14-14 (paragraph)

Trigger this skill when the user:

Extracted rules inside block: NONE

## dcf23214bf2767b2 — storyboard-architect/SKILL.md:16-16 (list_item)

- Describes a video they want to make ("30-second explainer for...", "TikTok ad about...")

Extracted rules inside block: NONE

## 78daf947a709ccdf — storyboard-architect/SKILL.md:17-17 (list_item)

- Asks to storyboard, plan shots, break out beats, write a shot list

Extracted rules inside block: NONE

## 51b1180ec67c0611 — storyboard-architect/SKILL.md:18-18 (list_item)

- Hands over a script, brief, or concept document expecting structured pre-production output

Extracted rules inside block: NONE

## 7e4c521168e71bb7 — storyboard-architect/SKILL.md:19-19 (list_item)

- Mentions a beat framework by name (Hero Trilogy, Pain-Proof-Promise, etc.)

Extracted rules inside block: NONE

## 4f035bc075220dfd — storyboard-architect/SKILL.md:20-20 (list_item)

- References an existing brand-lock file or pack

Extracted rules inside block: NONE

## af74bed0903912c8 — storyboard-architect/SKILL.md:22-22 (paragraph)

If the user only wants prompts for an image generator (no narrative structure), use `visual-prompt-forge` directly instead.

Extracted rules inside block: 34e34a703266

## 55918b9d5dceafff — storyboard-architect/SKILL.md:24-24 (heading)

## What you produce

Extracted rules inside block: NONE

## 676d7ab65fde3880 — storyboard-architect/SKILL.md:26-26 (paragraph)

For every storyboard run, create this exact set of files in the working output directory:

Extracted rules inside block: NONE

## a7984d63effbf341 — storyboard-architect/SKILL.md:28-35 (code)

```
output/
├── run.json                   # Run identity + every input pinned by content hash
├── storyboard.md              # Human-readable, structured per shot
├── shots.json                 # Machine-readable, schema in templates/shots.schema.json
├── text-overlays.json         # On-screen text + timing
└── brand-lock.snapshot.md     # Frozen copy of the brand-lock used (audit trail)
```

Extracted rules inside block: NONE
