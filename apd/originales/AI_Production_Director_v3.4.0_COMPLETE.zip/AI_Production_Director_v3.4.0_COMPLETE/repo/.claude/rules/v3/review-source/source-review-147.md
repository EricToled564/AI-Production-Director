# Source coverage review 147/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 85e06a0703cbe869 — video/references/fixes-and-skeletons.md:8-8 (list_item)

4. Default negative constraints

Extracted rules inside block: c77e0d1915c6

## 3b8091f6c3eee2fd — video/references/fixes-and-skeletons.md:9-9 (list_item)

5. Prompt compression order

Extracted rules inside block: cc2a29991e14

## baf52cb96f85df76 — video/references/fixes-and-skeletons.md:10-10 (list_item)

6. Output format templates

Extracted rules inside block: 05ed624eab84

## 744001becab1fa22 — video/references/fixes-and-skeletons.md:14-14 (heading)

## 1. Continuity checklist

Extracted rules inside block: NONE

## 650a69f17f82c7b1 — video/references/fixes-and-skeletons.md:16-16 (paragraph)

Before sending a prompt to the user, verify.

Extracted rules inside block: NONE

## d5f3a2b16622244b — video/references/fixes-and-skeletons.md:18-18 (list_item)

- Same character across shots (face, body, hair).

Extracted rules inside block: NONE

## 92ff788bc7ea086a — video/references/fixes-and-skeletons.md:19-19 (list_item)

- Same clothes across shots, exactly named.

Extracted rules inside block: NONE

## 18b2bb425d38eba2 — video/references/fixes-and-skeletons.md:20-20 (list_item)

- Consistent location logic.

Extracted rules inside block: NONE

## edf1f3db828bc7ef — video/references/fixes-and-skeletons.md:21-21 (list_item)

- Object state progression makes sense (sausage in fridge -> on plate -> on fork -> on floor).

Extracted rules inside block: NONE

## bb39a715b22e2691 — video/references/fixes-and-skeletons.md:22-22 (list_item)

- No unwanted extra characters.

Extracted rules inside block: NONE

## 8dcfc15c3395fa1e — video/references/fixes-and-skeletons.md:23-23 (list_item)

- No unwanted text or subtitles.

Extracted rules inside block: NONE

## f4db01c1d5e09d2e — video/references/fixes-and-skeletons.md:24-24 (list_item)

- No unwanted logos.

Extracted rules inside block: NONE

## 742e482c1a624bc3 — video/references/fixes-and-skeletons.md:25-25 (list_item)

- Consistent age / body / face.

Extracted rules inside block: NONE

## ecbcf8ba7230b795 — video/references/fixes-and-skeletons.md:26-26 (list_item)

- No impossible hand-object action.

Extracted rules inside block: NONE

## f3bcd2c4e50dfef7 — video/references/fixes-and-skeletons.md:27-27 (list_item)

- No vague camera instructions ("cinematic camera").

Extracted rules inside block: NONE

## c4ec994119a3510b — video/references/fixes-and-skeletons.md:28-28 (list_item)

- No vague lighting instructions ("beautiful light").

Extracted rules inside block: NONE

## 60078b78219ba2fb — video/references/fixes-and-skeletons.md:29-29 (list_item)

- No random stacking of director references.

Extracted rules inside block: NONE

## 603e2667313d0592 — video/references/fixes-and-skeletons.md:30-30 (list_item)

- No contradictions.

Extracted rules inside block: NONE

## 9bd3201e871e3bf7 — video/references/fixes-and-skeletons.md:31-31 (list_item)

- Palette is defined with concrete colors.

Extracted rules inside block: NONE

## f3a5cdb595a5999d — video/references/fixes-and-skeletons.md:32-32 (list_item)

- Final image is explicitly stated.

Extracted rules inside block: NONE

## 624509b386bffca7 — video/references/fixes-and-skeletons.md:34-34 (paragraph)

If any item is missing, fix before sending.

Extracted rules inside block: NONE

## 55a494d4bde39796 — video/references/fixes-and-skeletons.md:38-38 (heading)

## 2. Common failures and fixes

Extracted rules inside block: NONE

## d514c3f4a41ef011 — video/references/fixes-and-skeletons.md:40-40 (heading)

### One continuous take instead of montage

Extracted rules inside block: NONE

## e0873df030d95cc3 — video/references/fixes-and-skeletons.md:42-42 (paragraph)

Fix.

Extracted rules inside block: NONE

## 4dac50b7eeeb1717 — video/references/fixes-and-skeletons.md:44-46 (code)

```text
This must be a multi-shot sequence with visible hard cuts. Do not generate a single continuous take. Each beat uses a different angle and framing.
```

Extracted rules inside block: NONE

## 10fcdf7f1db2ee6b — video/references/fixes-and-skeletons.md:48-48 (paragraph)

For Seedance specifically, add explicit `Cut to.` or `Camera cut to.` markers in the prompt body.

Extracted rules inside block: NONE

## 5963a83818caa833 — video/references/fixes-and-skeletons.md:50-50 (heading)

### Character face changes between shots

Extracted rules inside block: NONE

## 405cb928d755472f — video/references/fixes-and-skeletons.md:52-52 (paragraph)

Fix.

Extracted rules inside block: NONE

## 9bdb6cc630a27d99 — video/references/fixes-and-skeletons.md:54-56 (code)

```text
Preserve the exact character in every shot. Same face shape, same eye color, same hair, same clothing, same expression style. [repeat the full identity block]
```

Extracted rules inside block: NONE

## 4ff36f3b9d857b29 — video/references/fixes-and-skeletons.md:58-58 (paragraph)

For Kling. Use Element Binding with 3-4 reference images (front, side, three-quarter).

Extracted rules inside block: eda89c8db080
