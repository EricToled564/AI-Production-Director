# Source coverage review 77/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## cb76d5009a97958f — image/references/vision-decomposer.md:32-32 (heading)

### 2. Environment — geometry and structure of space

Extracted rules inside block: NONE

## 8c8b5f2423e7152e — image/references/vision-decomposer.md:34-34 (list_item)

- **Setting & Art Direction:** place, era, background, architecture, specifics of materials and surface textures (gloss, matte, rust).

Extracted rules inside block: NONE

## 5a6b791899a552aa — image/references/vision-decomposer.md:35-35 (list_item)

- **Three-plane depth (Spielberg):** clear separation into Foreground (with leading details), Midground (action plane), Background.

Extracted rules inside block: NONE

## 58085eaef2ada4a5 — image/references/vision-decomposer.md:36-36 (list_item)

- **Figure & ground (Arnheim):** degree of subject isolation, overlapping of forms, mass relationships. Use of reflections (mirrors, windows) to expand context.

Extracted rules inside block: 7a2eab3d9d5b

## 227f98782d66f7a1 — image/references/vision-decomposer.md:37-37 (list_item)

- **Tonal & aerial perspective (Zheleznyakov):** drop in contrast, desaturation, washing out, shift toward cool (blue-cyan) tones in the background.

Extracted rules inside block: NONE

## 77a8be9fe99b9725 — image/references/vision-decomposer.md:38-38 (list_item)

- **Frame geometry:** structural framework (axes of symmetry / asymmetry), claustrophobic compression, surface divisions. Illusion of depth via Foreground framing.

Extracted rules inside block: NONE

## fbac5123f44c07ac — image/references/vision-decomposer.md:40-40 (heading)

### 3. Lighting — chiaroscuro, color and contrast

Extracted rules inside block: NONE

## f688ae2de3cae2e6 — image/references/vision-decomposer.md:42-42 (list_item)

- **Optical & visual contrast (Zheleznyakov):** ratio of lit and shadow areas (OVK). Depth and density of shadows. Exact local color vs. color modified by lighting (valeurs).

Extracted rules inside block: NONE

## 0e8010966db5f18e — image/references/vision-decomposer.md:43-43 (list_item)

- **Lighting scheme:** Key, Fill, Backlight / Rim, Modeling. Rembrandt lighting, Chiaroscuro. Height, hardness (Hard / Soft) and type of source.

Extracted rules inside block: NONE

## 020fbec638a03ebb — image/references/vision-decomposer.md:44-44 (list_item)

- **Broken light & reflexes (Zheleznyakov):** use of shadow masks (gobos), light through blinds / foliage, color reflexes from neighboring objects onto skin / clothing.

Extracted rules inside block: 766f3ac1c6a6

## f908021248351775 — image/references/vision-decomposer.md:45-45 (list_item)

- **Tonality & color:** light key (High-key / Low-key). Threshold Silhouette. Itten's 7 contrasts. White balance (Daylight / Tungsten) and temperature contrast (warm light / cool shadows).

Extracted rules inside block: NONE

## 866b5a27f581c5c7 — image/references/vision-decomposer.md:47-47 (heading)

### 4. Tech & Cinematography — optics, filters and film texture

Extracted rules inside block: NONE

## 9c493b7b0d99b709 — image/references/vision-decomposer.md:49-49 (list_item)

- **Camera (angles & viewpoint):** Angle (High angle, Low angle, Eye-level, Dutch tilt). Objective camera, Subjective, POV, Over-the-shoulder (OTS). Movement imitation (Push-in, Tracking shot).

Extracted rules inside block: 217af555708d

## 72cb8488dd7ae5f6 — image/references/vision-decomposer.md:50-50 (list_item)

- **Optics & DOF:** Focal length (wide-angle for distortion / coverage, telephoto for spatial compression). Depth of field. Rack focus, bokeh.

Extracted rules inside block: NONE

## 8cd67698d229f55b — image/references/vision-decomposer.md:51-51 (list_item)

- **Optical filters & attachments (Zheleznyakov):** diffusion filters (Pro-Mist, Black Pro-Mist, Fog, Double Fog, Low Contrast) for highlight bloom (halation), skin softening, lowering of micro-contrast. Polarizers (cutting reflections).

Extracted rules inside block: NONE

## 051ed455418c5ef2 — image/references/vision-decomposer.md:52-52 (list_item)

- **Effects & texture:** Frame format (70mm, 35mm, IMAX). Exposure (motion blur). Stylization (Bleach Bypass). Film Grain, chromatic aberration.

Extracted rules inside block: NONE

## 8e7c60e791483b55 — image/references/vision-decomposer.md:56-56 (heading)

## STEP 2 — PROMPT SYNTHESIS

Extracted rules inside block: NONE

## 7a5ab1fd367bdef9 — image/references/vision-decomposer.md:58-58 (paragraph)

Assemble the final prompt from Step 1 data.

Extracted rules inside block: NONE

## 067d7e9109f0d721 — image/references/vision-decomposer.md:60-60 (paragraph)

Rules:

Extracted rules inside block: NONE

## bde166edd7aece49 — image/references/vision-decomposer.md:61-61 (list_item)

- Write **only keywords separated by commas, in English**.

Extracted rules inside block: NONE

## ff0d17069bac8d0c — image/references/vision-decomposer.md:62-62 (list_item)

- Describe **strictly what you see**. Do not invent new objects.

Extracted rules inside block: b6de40f5a911

## c3f62dbc2a34eda0 — image/references/vision-decomposer.md:63-63 (list_item)

- **No filler.** Never write "The image shows...", "A picture of...", "I can see...".

Extracted rules inside block: f74beaeba044

## 766437e8bb9e3795 — image/references/vision-decomposer.md:64-64 (list_item)

- **Strict word order** (this formula is non-negotiable):

Extracted rules inside block: NONE

## 42c034741eec3043 — image/references/vision-decomposer.md:66-68 (code)

```
[Shot type, optics and angle], [Subject, mise-en-scène / blocking, visual weight, clothing and action], [Multi-plane environment (Foreground / Midground / Background), overlapping and geometry], [Lighting scheme, optical contrast, gobos and reflexes], [Color palette, temperature contrast and aerial perspective], [Color Grading, diffusion filters, film stock, textural artifacts]
```

Extracted rules inside block: NONE

## d30cbb0321ed68d1 — image/references/vision-decomposer.md:72-72 (heading)

## OUTPUT PROTOCOL

Extracted rules inside block: NONE

## e5875124b28f3060 — image/references/vision-decomposer.md:74-74 (paragraph)

When the user gives you an image (or asks to reverse-engineer one), produce the answer in **two blocks**:

Extracted rules inside block: NONE

## 24e19457433a2623 — image/references/vision-decomposer.md:76-76 (heading)

### Block 1 — Brief Analysis Log

Extracted rules inside block: NONE

## 7fc9c0d11c68762f — image/references/vision-decomposer.md:78-83 (code)

```
Subject & Blocking: ...
Environment & Depth: ...
Lighting & Contrast: ...
Tech & Optics: ...
```

Extracted rules inside block: NONE

## bbfb062dda8641f5 — image/references/vision-decomposer.md:85-85 (paragraph)

Each line: 1-2 sentences max. Just the extracted parameters.

Extracted rules inside block: NONE

## 942c033e4daa25d8 — image/references/vision-decomposer.md:87-87 (heading)

### Block 2 — Final Prompt

Extracted rules inside block: NONE
