# Source coverage review 16/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5ceb13cbb1aea6e2 — aurora-prompt-linter/references/README.md:105-105 (list_item)

- **Vision check**: linter no ve las imágenes, depende de los tags. Si tageo mal, falla en silencio. Mitigación: review humano del tag antes de correr.

Extracted rules inside block: NONE

## 91dbb6643b00831b — aurora-prompt-linter/references/README.md:107-107 (heading)

## Integración con skill

Extracted rules inside block: NONE

## 6edb28b87732cf53 — aurora-prompt-linter/references/README.md:109-109 (paragraph)

El linter NO corre solo. El skill `prompt-production-protocol` Step 5 debe invocarlo como item crítico. Ver `skill_update_step5.md` para la edit propuesta.

Extracted rules inside block: NONE

## 22591d628ae8f6f1 — aurora-prompt-linter/references/README.md:111-111 (paragraph)

System prompt v6.1 (propuesta): nueva Regla 28 forzando llamada al linter antes de Step 6 delivery. Ver `system_prompt_v6_1_rule28.md`.

Extracted rules inside block: NONE

## 7bce05d721fb35b9 — aurora-prompt-linter/references/README.md:113-113 (heading)

## Archivos del paquete

Extracted rules inside block: NONE

## 5a3a23ec90dc9201 — aurora-prompt-linter/references/README.md:115-126 (code)

```
aurora-linter/
├── prompt_linter.py        # Script ejecutable
├── vocabularies.yaml       # Vocabulary lists por categoría
├── README.md               # Este archivo
├── skill_update_step5.md   # Edit propuesta al skill Step 5
├── system_prompt_v6_1_rule28.md  # Edit propuesta al system prompt
├── test_refs_session.yaml  # Test fixture
├── test_prompt_BAD.txt     # Test: prompt con 27 violaciones
├── test_prompt_GOOD.txt    # Test: prompt limpio
└── test_override_msg.txt   # Test: mensaje con overrides válidos
```

Extracted rules inside block: NONE

## aa68603252a585b7 — aurora-prompt-linter/references/README.md:128-128 (heading)

## Versión

Extracted rules inside block: NONE

## 23b2e81d47529d71 — aurora-prompt-linter/references/README.md:130-132 (paragraph)

v1.0 — 2026-05-27
Built by: Final Upgrade AI / Eric Toledano
Fuente: retrospectiva F7 sesión 2026-05-27

Extracted rules inside block: NONE

## 619a1fab1b356feb — aurora-prompt-linter/references/skill_update_step5.md:1-1 (heading)

# Edit propuesta al skill `prompt-production-protocol` — Step 5

Extracted rules inside block: NONE

## 9dda771d1a66d04e — aurora-prompt-linter/references/skill_update_step5.md:3-5 (paragraph)

**Fecha:** 2026-05-27
**Origen:** Retrospectiva F7 sesión 2026-05-27 (errores repetidos de redundancia con refs).
**Tipo:** MAYOR — añade gate determinista al proceso.

Extracted rules inside block: NONE

## 7f8860b4bb38b0e2 — aurora-prompt-linter/references/skill_update_step5.md:7-7 (heading)

## Sección afectada

Extracted rules inside block: NONE

## 7ae84603d6186edc — aurora-prompt-linter/references/skill_update_step5.md:9-9 (paragraph)

`protocol/05_self_audit.md` (Step 5 del proceso de 6 pasos).

Extracted rules inside block: NONE

## 25c5bd222249c7bc — aurora-prompt-linter/references/skill_update_step5.md:11-11 (heading)

## Edit concreta

Extracted rules inside block: NONE

## f416dbee98a76fcd — aurora-prompt-linter/references/skill_update_step5.md:13-13 (heading)

### ANTES (texto actual)

Extracted rules inside block: NONE

## cafa370c0ba77bb6 — aurora-prompt-linter/references/skill_update_step5.md:15-15 (list_item)

> ### Step 5 — Self-audit VISIBLE

Extracted rules inside block: NONE

## 02ff709fb162f610 — aurora-prompt-linter/references/skill_update_step5.md:16-16 (list_item)

> Leer: `protocol/05_self_audit.md`

Extracted rules inside block: NONE

## 7afcb39c61e33a48 — aurora-prompt-linter/references/skill_update_step5.md:17-17 (list_item)

> - Ejecutar checklist específico del caso

Extracted rules inside block: NONE

## 01b4e2a70f27d0e5 — aurora-prompt-linter/references/skill_update_step5.md:18-18 (list_item)

> - Marcar cada item Pass/Fail en el output

Extracted rules inside block: NONE

## 96343cf13752bee1 — aurora-prompt-linter/references/skill_update_step5.md:19-19 (list_item)

> - **Si algún item crítico es Fail → revisar el draft y re-auditar. No entregar hasta pasar.**

Extracted rules inside block: NONE

## f5465f2aac4613d7 — aurora-prompt-linter/references/skill_update_step5.md:21-21 (heading)

### DESPUÉS (texto propuesto)

Extracted rules inside block: NONE

## 05f35d997fcadfa1 — aurora-prompt-linter/references/skill_update_step5.md:23-23 (list_item)

> ### Step 5 — Self-audit VISIBLE + Linter determinista

Extracted rules inside block: NONE

## 20db13daace0c241 — aurora-prompt-linter/references/skill_update_step5.md:24-24 (list_item)

> Leer: `protocol/05_self_audit.md`

Extracted rules inside block: NONE

## ea75eb2ca8dbb17b — aurora-prompt-linter/references/skill_update_step5.md:25-25 (list_item)

>

Extracted rules inside block: NONE

## b7b6a795e148fe64 — aurora-prompt-linter/references/skill_update_step5.md:26-26 (list_item)

> **Step 5a — Self-audit cualitativo (igual que antes):**

Extracted rules inside block: NONE

## 81d318f5d57df2b2 — aurora-prompt-linter/references/skill_update_step5.md:27-27 (list_item)

> - Ejecutar checklist específico del caso

Extracted rules inside block: NONE

## 777b8255dee37c1d — aurora-prompt-linter/references/skill_update_step5.md:28-28 (list_item)

> - Marcar cada item Pass/Fail en el output

Extracted rules inside block: NONE

## c1c8c105c8849ae0 — aurora-prompt-linter/references/skill_update_step5.md:29-29 (list_item)

> - Si algún item crítico es Fail → revisar el draft y re-auditar

Extracted rules inside block: NONE

## a9a787834f5a389b — aurora-prompt-linter/references/skill_update_step5.md:30-30 (list_item)

>

Extracted rules inside block: NONE

## 2a4e0c633f517fbc — aurora-prompt-linter/references/skill_update_step5.md:31-31 (list_item)

> **Step 5b — Linter determinista (NUEVO, obligatorio para casos 3a/3b/3c — recomendado para 1/2/4):**

Extracted rules inside block: a5ae02a3009f

## 969fa5d703536666 — aurora-prompt-linter/references/skill_update_step5.md:32-32 (list_item)

> - Invocar `aurora-linter/prompt_linter.py` con: prompt, refs (con tags por categoría), case_type, mensaje del usuario (para parsear OVERRIDEs).

Extracted rules inside block: NONE
