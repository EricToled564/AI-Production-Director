# Source coverage review 185/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f2f29b430763cdd9 — video/references/veo.md:209-209 (heading)

### Camera direction ignored

Extracted rules inside block: NONE

## 22ee7815e5d85e94 — video/references/veo.md:211-211 (paragraph)

Fix. Lead the prompt with camera. "Wide aerial shot" at the start beats "cinematic camera work" in the middle.

Extracted rules inside block: NONE

## dad3cdfc29655206 — video/references/veo.md:213-213 (heading)

### Character color changes when mood words are added

Extracted rules inside block: NONE

## 1c146edd5fe24218 — video/references/veo.md:215-215 (paragraph)

Fix. Switch to JSON prompt. Lock the character description in the continuity block. Keep mood in global_style where it cannot bleed into object colors.

Extracted rules inside block: NONE

## 2eadb72cb0afdc75 — video/references/veo.md:217-217 (heading)

### Lip-sync off

Extracted rules inside block: NONE

## 28720a2c98d36bf0 — video/references/veo.md:219-219 (paragraph)

Fix. Check the lead-in verb. "She says, ..." outperforms just quoted speech alone. Colon form often more reliable than comma.

Extracted rules inside block: NONE

## 27cb3e3d1aa19727 — video/references/veo.md:221-221 (heading)

### Prompt too long, model cherry-picks

Extracted rules inside block: NONE

## 8b5c4dbcdae8e791 — video/references/veo.md:223-223 (paragraph)

Fix. Compress to the 50-100 word range. Or switch to JSON which handles length better because of structural separation.

Extracted rules inside block: NONE

## 4a7123aa46830223 — video/references/veo.md:225-225 (heading)

## 10. Skeleton

Extracted rules inside block: NONE

## 333d2786c3f04d53 — video/references/veo.md:227-227 (heading)

### Prose version

Extracted rules inside block: NONE

## 8fd490bea036ff9f — video/references/veo.md:229-237 (code)

```text
[Subject performing action] in [environment]. [Camera framing + lens + movement]. [Lighting direction + color temperature]. [Style + mood + palette].

Audio: [ambient sounds, SFX, music texture].
Says: [character] says, "[dialogue, max 8 seconds of speech]."
SFX: [punctual sound events].

Duration: [4 / 6 / 8] seconds.
```

Extracted rules inside block: NONE

## 5363f217be8a0d60 — video/references/veo.md:239-239 (heading)

### JSON version

Extracted rules inside block: NONE

## 1b759fd417484528 — video/references/veo.md:241-241 (paragraph)

See section 6. Copy the schema and fill in.

Extracted rules inside block: NONE

## e0eb93918ec1acc1 — video/references/veo.md:243-243 (heading)

### Worked example. Commercial hero shot

Extracted rules inside block: NONE

## 84493ff43e7c26b3 — video/references/veo.md:245-253 (code)

```text
A woman in a cream silk blouse stands in front of a morning window, lifting a ceramic coffee cup to her lips. Medium close-up, 85mm, slow push-in. Warm window key from frame-left, soft bounce fill from frame-right. Cinematic naturalism, creamy palette, shallow depth of field.

Audio: distant city ambience, ceramic clink, one slow breath.
Says: She whispers to herself, "One more minute."
SFX: (spoon tapping ceramic at 2 seconds).

Duration: 6 seconds.
```

Extracted rules inside block: NONE

## 04906a87349b0411 — video/references/veo.md:257-257 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 89705364d62c5450 — visual-asset-critic/SKILL.md:2-3 (paragraph)

name: visual-asset-critic
description: Critique a generated image against its source storyboard shot and prompt, producing revision notes. Use when the user has generated an image and wants feedback before committing. Triggers on "does this match the brief", "review this render", "is this on-brand", "what should I change", or uploading an image alongside a shot ID. The QA loop for AI visuals. Works even without a storyboard-architect run. Pairs with storyboard-architect upstream, visual-prompt-forge sibling.

Extracted rules inside block: NONE

## 83606dd2b143116f — visual-asset-critic/SKILL.md:6-6 (heading)

# Visual Asset Critic

Extracted rules inside block: NONE

## 1387fa9e9f3f115d — visual-asset-critic/SKILL.md:8-8 (paragraph)

You are the editorial second-eye on AI-generated images. Most teams don't have one, they generate, glance, accept, and ship. This skill is the structured review pass that catches what a tired creator misses.

Extracted rules inside block: 976c26a4aa87

## ad0fd497d457239b — visual-asset-critic/SKILL.md:10-10 (paragraph)

The output is a critique with concrete, actionable revision notes. Not vibes. Not "looks good." Specific, prompt-level or post-level fixes.

Extracted rules inside block: NONE

## e50a0c6ef02e0389 — visual-asset-critic/SKILL.md:12-12 (heading)

## When to use

Extracted rules inside block: NONE

## 1246498b0b3dff27 — visual-asset-critic/SKILL.md:14-14 (paragraph)

Trigger when the user:

Extracted rules inside block: NONE

## 415186588f7bb817 — visual-asset-critic/SKILL.md:16-16 (list_item)

- Uploads or links a generated image with a question about quality

Extracted rules inside block: NONE

## dc9df2605cbbe95c — visual-asset-critic/SKILL.md:17-17 (list_item)

- Asks "does this match the storyboard"

Extracted rules inside block: NONE

## 65023f388eb2b8d7 — visual-asset-critic/SKILL.md:18-18 (list_item)

- Says "review this render", "is this on-brand", "what should I change"

Extracted rules inside block: 508d934cd5ae

## aab392373d279bf1 — visual-asset-critic/SKILL.md:19-19 (list_item)

- Has a generated image and a `shots.json` shot reference and wants QA

Extracted rules inside block: NONE

## 50e93102c92aad5c — visual-asset-critic/SKILL.md:20-20 (list_item)

- Has a generated image and just wants editorial feedback (no storyboard reference)

Extracted rules inside block: NONE

## 03b1127a9c534dd8 — visual-asset-critic/SKILL.md:22-22 (heading)

## What you produce

Extracted rules inside block: NONE

## 018047e4aff9cd30 — visual-asset-critic/SKILL.md:24-24 (paragraph)

**Two artifacts from every review, always both:** a human-readable markdown critique (the primary surface) and a machine-readable critique JSON (so a pipeline can gate on the verdict instead of parsing prose). The JSON is detailed in Step 6; it never replaces the markdown.

Extracted rules inside block: 26d2946386d3

## e3d41e3d14e150de — visual-asset-critic/SKILL.md:26-29 (paragraph)

The JSON goes to `output/critiques/round-{N}/{shot_id}.critique.json`. One file per shot
per round, never a shared filename. A 12-shot project reviewed over three rounds writes 36
critiques; when they all went to `output/critique.json` it kept one, and which one depended
on review order.

Extracted rules inside block: 9b0c445c92b5
