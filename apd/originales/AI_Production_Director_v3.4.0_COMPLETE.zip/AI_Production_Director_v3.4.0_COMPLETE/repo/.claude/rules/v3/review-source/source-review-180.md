# Source coverage review 180/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 06e5566847cafd0d — video/references/universal-rules.md:37-37 (paragraph)

If a shot has none of these — it is filler. Delete it or rewrite it. No exceptions for "establishing", "transition", or "hero product" shots — those are exactly the shots that go lazy first.

Extracted rules inside block: NONE

## 84fae833c89d6c0d — video/references/universal-rules.md:39-39 (paragraph)

Words that do not render and mark the writer being lazy:

Extracted rules inside block: fe87bc2b0d61

## 3166c642b85a6559 — video/references/universal-rules.md:41-41 (list_item)

- "cinematic", "professional", "high quality", "masterpiece", "stunning", "epic", "amazing"

Extracted rules inside block: NONE

## 60014a466f805ca3 — video/references/universal-rules.md:42-42 (list_item)

- "beautiful lighting", "dynamic camera", "intense moment", "powerful scene"

Extracted rules inside block: NONE

## 52ef0524136e25bf — video/references/universal-rules.md:43-43 (list_item)

- "he is sad", "she is angry", "he is afraid" — emotions named without a body

Extracted rules inside block: NONE

## 6c00d254e199021b — video/references/universal-rules.md:45-45 (paragraph)

Replace each with concrete physical facts. The full theory of why this works lives in `dramaturgy.md` §2 (Second law).

Extracted rules inside block: NONE

## ed5f42a4e19b8d80 — video/references/universal-rules.md:47-47 (heading)

## 2. U1. Universal prompt skeleton

Extracted rules inside block: NONE

## f5f77c39e09684c9 — video/references/universal-rules.md:49-49 (paragraph)

Build every prompt from these layers, roughly in this order:

Extracted rules inside block: NONE

## b8fe9ba45f84aa5f — video/references/universal-rules.md:51-62 (code)

```text
[Subject / Character]
[Action / Motion]
[Scene / Environment]
[Camera / Shot / Lens]
[Lighting / Atmosphere]
[Style / Mood / Palette]
[Sound / Audio]
[Duration / Aspect ratio / Resolution]
[Continuity rules]
[Negative constraints — only if the model supports them]
```

Extracted rules inside block: NONE

## cebb9c1e9b8e7372 — video/references/universal-rules.md:64-64 (paragraph)

Model-specific skeletons live in their reference files (`seedance.md`, `kling.md`, `veo.md`). For dramatic / multi-shot / character-locked Seedance work, the production-grade 11-block skeleton in `seedance.md` §6 supersedes this generic skeleton.

Extracted rules inside block: NONE

## 5716d141ae14c3cb — video/references/universal-rules.md:66-66 (heading)

## 3. U2. Weight-at-start

Extracted rules inside block: NONE

## e37d84f8acd4b8b2 — video/references/universal-rules.md:68-68 (paragraph)

Generators put more attention on the first 30-40% of tokens. Lead with subject and action. Style modifiers go at the end. Camera, lighting, and environment live in the middle.

Extracted rules inside block: NONE

## 7bc6ee1c78d5142e — video/references/universal-rules.md:70-70 (heading)

## 4. U3. Show don't tell

Extracted rules inside block: NONE

## 1f9f01d98a285c84 — video/references/universal-rules.md:72-72 (paragraph)

The model cannot render feelings. It renders bodies. Translate every emotion into a physical action.

Extracted rules inside block: NONE

## 09a04b3df188a252 — video/references/universal-rules.md:74-74 (list_item)

- Bad. "He is scared."

Extracted rules inside block: NONE

## 2abd715310e87501 — video/references/universal-rules.md:75-75 (list_item)

- Good. "His jaw locks. He stops breathing for one beat. His fingers curl against the doorframe."

Extracted rules inside block: NONE

## 505dea3888800bdb — video/references/universal-rules.md:77-77 (paragraph)

Calibration: for one emotional transition, **2-4 observable cues** (eye movement, brow tension, mouth, breathing, throat swallow, hands) are enough. Fewer leaves the model guessing; more reads as overacting.

Extracted rules inside block: NONE

## d152df034401b164 — video/references/universal-rules.md:79-79 (heading)

## 5. U4. Natural language beats tag spam

Extracted rules inside block: NONE

## 29805cf8a040d699 — video/references/universal-rules.md:81-81 (paragraph)

Video models are not image models. Tag stuffing like "masterpiece, 4k, cinematic, beautiful" fails. Write in full cinematic sentences as if briefing a human DOP.

Extracted rules inside block: NONE

## 2eeb2ca7d4b14abd — video/references/universal-rules.md:83-83 (heading)

## 6. U5. One primary camera move per shot

Extracted rules inside block: NONE

## bc92c4791e9b7367 — video/references/universal-rules.md:85-85 (paragraph)

Do not stack three camera moves in a 5-second clip. Pick one dominant move (dolly-in, pan, tracking, static). Layer a subtle micro-adjustment if needed (slight handheld shake, gentle rack focus). More than that produces visual chaos.

Extracted rules inside block: 6373d84dd6bb

## 2398b0c61d1d876c — video/references/universal-rules.md:87-87 (heading)

## 7. U6. Precise lens language

Extracted rules inside block: NONE

## e71b6f8796a190ec — video/references/universal-rules.md:89-89 (paragraph)

State the lens. "Shot on 50mm" works across all major models. Quick map:

Extracted rules inside block: NONE

## 5fffd7d2fa9e7e49 — video/references/universal-rules.md:91-91 (list_item)

- 24mm. wide, immersive, exaggerated space

Extracted rules inside block: NONE

## 496a9b56c7f0920d — video/references/universal-rules.md:92-92 (list_item)

- 35mm. natural documentary

Extracted rules inside block: NONE

## a15779073191de2f — video/references/universal-rules.md:93-93 (list_item)

- 50mm. intimate, human perspective

Extracted rules inside block: NONE

## f687ec1b7c6bc921 — video/references/universal-rules.md:94-94 (list_item)

- 85mm. portrait, compressed background

Extracted rules inside block: NONE

## 2022a83623dfa975 — video/references/universal-rules.md:95-95 (list_item)

- 100mm macro. texture, detail

Extracted rules inside block: NONE

## d06593c900194c27 — video/references/universal-rules.md:96-96 (list_item)

- anamorphic 40mm. cinematic widescreen

Extracted rules inside block: NONE

## 8e45b9655e191cb6 — video/references/universal-rules.md:98-98 (paragraph)

Full vocabulary in `camera-lighting-vocabulary.md`.

Extracted rules inside block: NONE
