# Source coverage review 114/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 34649fc6dd28a175 — storyboard-architect/references/on-screen-text.md:81-81 (list_item)

- The text takes longer to read than a single shot's duration

Extracted rules inside block: NONE

## 916b0b4fa1a99bf2 — storyboard-architect/references/on-screen-text.md:82-82 (list_item)

- You want text to feel anchored while visuals change underneath

Extracted rules inside block: NONE

## 15ebaff41c823738 — storyboard-architect/references/on-screen-text.md:84-84 (paragraph)

To stack, both shots reference the same `on_screen_text` ID. The overlay's `enter.at` aligns to the first shot's start, `exit.at` aligns to the second shot's end.

Extracted rules inside block: NONE

## 48d307a308b78cd3 — storyboard-architect/references/on-screen-text.md:86-86 (paragraph)

In `shots.json`:

Extracted rules inside block: NONE

## b9ea2ce32e31e9f1 — storyboard-architect/references/on-screen-text.md:88-91 (code)

```json
{ "id": "shot_03", "on_screen_text": "text_02", ... },
{ "id": "shot_04", "on_screen_text": "text_02", ... }
```

Extracted rules inside block: NONE

## b75509e6421a31ef — storyboard-architect/references/on-screen-text.md:93-93 (paragraph)

In `text-overlays.json`:

Extracted rules inside block: NONE

## db97c22097bf3284 — storyboard-architect/references/on-screen-text.md:95-101 (code)

```json
{
  "id": "text_02",
  "shot_id": ["shot_03", "shot_04"],
  ...
}
```

Extracted rules inside block: NONE

## f96b51a84ab57f57 — storyboard-architect/references/on-screen-text.md:103-103 (paragraph)

Document this in rationale: "text persists across shot 3-4 to give 4.8s read-time for 16-word reframe."

Extracted rules inside block: NONE

## b7c90b362ec5b214 — storyboard-architect/references/shot-grammar.md:1-1 (heading)

# Shot Grammar

Extracted rules inside block: NONE

## 3b31be66304e9d2a — storyboard-architect/references/shot-grammar.md:3-3 (paragraph)

Controlled vocabulary. Use these exact terms in `shots.json`. Generators interpret loose language inconsistently, locked vocabulary survives translation.

Extracted rules inside block: 7c5f5a183b49

## bcec5da39463a8c7 — storyboard-architect/references/shot-grammar.md:5-5 (heading)

## Framing (subject size in frame)

Extracted rules inside block: NONE

## 020322a87408eb97 — storyboard-architect/references/shot-grammar.md:7-7 (table_row)

| Code | Name | What it shows |

Extracted rules inside block: NONE

## 9e85b01154df99f9 — storyboard-architect/references/shot-grammar.md:9-9 (table_row)

| `ECU` | Extreme close-up | Eyes, hands, single detail |

Extracted rules inside block: NONE

## c638d0d5d50811a2 — storyboard-architect/references/shot-grammar.md:10-10 (table_row)

| `CU` | Close-up | Head, or full hand-on-object |

Extracted rules inside block: NONE

## 0ce04042818f3e27 — storyboard-architect/references/shot-grammar.md:11-11 (table_row)

| `MCU` | Medium close-up | Head and shoulders |

Extracted rules inside block: d6f57d2d9cf3

## 845512bd40fe15d3 — storyboard-architect/references/shot-grammar.md:12-12 (table_row)

| `MS` | Medium shot | Waist up |

Extracted rules inside block: NONE

## 330ee1e7e8c4e740 — storyboard-architect/references/shot-grammar.md:13-13 (table_row)

| `MLS` | Medium long shot | Full body, environment minimal |

Extracted rules inside block: NONE

## a60bcdc71d6ca364 — storyboard-architect/references/shot-grammar.md:14-14 (table_row)

| `WS` | Wide shot | Full body, environment present |

Extracted rules inside block: NONE

## fc821445d172ca07 — storyboard-architect/references/shot-grammar.md:15-15 (table_row)

| `EWS` | Extreme wide shot | Subject small in environment |

Extracted rules inside block: NONE

## a3f1b58f174d6e31 — storyboard-architect/references/shot-grammar.md:17-17 (paragraph)

Default to MCU and MS for talking-head founder content. ECU and CU for product detail and emotion. WS and EWS for context-setting.

Extracted rules inside block: NONE

## 10fb4b3aa657bb10 — storyboard-architect/references/shot-grammar.md:19-19 (heading)

## Angle (camera vertical position)

Extracted rules inside block: NONE

## 36ad420b0fdbf25f — storyboard-architect/references/shot-grammar.md:21-21 (table_row)

| Code | Effect |

Extracted rules inside block: NONE

## 9959f57eb0f3ff16 — storyboard-architect/references/shot-grammar.md:23-23 (table_row)

| `eye-level` | Neutral, default |

Extracted rules inside block: NONE

## da361f4dbb57bfd5 — storyboard-architect/references/shot-grammar.md:24-24 (table_row)

| `high` | Subject feels smaller, vulnerable |

Extracted rules inside block: NONE

## 6f445416605d392a — storyboard-architect/references/shot-grammar.md:25-25 (table_row)

| `low` | Subject feels powerful, dominant |

Extracted rules inside block: NONE

## 9a754f942c9c0c5e — storyboard-architect/references/shot-grammar.md:26-26 (table_row)

| `overhead` | Detached, schematic, instructional |

Extracted rules inside block: NONE

## bfec30db64c9a624 — storyboard-architect/references/shot-grammar.md:27-27 (table_row)

| `dutch` | Tilted, tension, unease |

Extracted rules inside block: NONE

## 06a0631f53fe5a09 — storyboard-architect/references/shot-grammar.md:29-29 (paragraph)

Default to eye-level. Use the others deliberately, not for variety.

Extracted rules inside block: 4feef29dcf25

## 9f221855d5575a49 — storyboard-architect/references/shot-grammar.md:31-31 (heading)

## Motion (camera movement)

Extracted rules inside block: NONE

## 3aedfa007b5546a0 — storyboard-architect/references/shot-grammar.md:33-33 (table_row)

| Code | Effect | Use when |

Extracted rules inside block: 15c99afb2343
