# Source coverage review 183/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 9235d7481d2eae87 — video/references/veo.md:10-10 (list_item)

6. JSON prompts (powerful, unique)

Extracted rules inside block: 86cc26cbf505

## 31f491ecef75fdeb — video/references/veo.md:11-11 (list_item)

7. Image-to-video (Veo 3.1)

Extracted rules inside block: 6f127a89c77c

## af77c5cde2af284d — video/references/veo.md:12-12 (list_item)

8. Reference ingredients (3.1)

Extracted rules inside block: 1875ad491d81

## e1344087b1fb28aa — video/references/veo.md:13-13 (list_item)

9. Failure modes and fixes

Extracted rules inside block: 6df787097160

## acf028177937af04 — video/references/veo.md:14-14 (list_item)

10. Skeleton and example

Extracted rules inside block: 69785a97561f

## 9e22fdda5360bdd9 — video/references/veo.md:18-18 (heading)

## 1. What Veo is

Extracted rules inside block: NONE

## 2542aab8abf9bfea — video/references/veo.md:20-20 (paragraph)

Google's cinematic video model with NATIVE synchronized audio. The only major generator that creates dialogue, SFX, and music in sync with the video and does lip-sync natively. Best for commercial polish, narrative with dialogue, and cinematic audio.

Extracted rules inside block: NONE

## 0d8cc169feddaef0 — video/references/veo.md:22-22 (heading)

## 2. Versions and specs

Extracted rules inside block: NONE

## 46f6d716bd03a76e — video/references/veo.md:24-24 (list_item)

- Veo 3. Text-to-video, native audio, 4 / 6 / 8 second clips.

Extracted rules inside block: NONE

## 322be95902051c37 — video/references/veo.md:25-25 (list_item)

- Veo 3.1. Adds image-to-video with First Frame, improved audio, reference ingredients, stronger motion coherence.

Extracted rules inside block: NONE

## 4569fa50f74d5721 — video/references/veo.md:27-28 (paragraph)

Duration. 4, 6, or 8 seconds.
Dialogue budget. Max 8 seconds of spoken audio per clip.

Extracted rules inside block: NONE

## 7d3623e2d37aae44 — video/references/veo.md:30-30 (heading)

## 3. Prompt structure and length

Extracted rules inside block: NONE

## c3b46e314c5e711e — video/references/veo.md:32-32 (paragraph)

Order matters. Lead with subject and camera. Quality modifiers go at the end.

Extracted rules inside block: NONE

## c60d195927fb8c68 — video/references/veo.md:34-42 (code)

```text
[Subject / Action]
+ [Environment / Setting]
+ [Camera / Shot Type / Lens]
+ [Lighting / Atmosphere]
+ [Style / Quality]
+ [Audio]
+ [Duration]
```

Extracted rules inside block: NONE

## b3b90af11d4b4dea — video/references/veo.md:44-44 (paragraph)

Sweet spot. 50-200 words.

Extracted rules inside block: NONE

## 64a234f0684de003 — video/references/veo.md:46-46 (list_item)

- Shorter prompts = more creative latitude, less control.

Extracted rules inside block: NONE

## 3b004d6795a42f78 — video/references/veo.md:47-47 (list_item)

- Longer prompts = tighter control, higher risk of contradictions.

Extracted rules inside block: NONE

## db2c0fe13634cbd6 — video/references/veo.md:49-49 (heading)

## 4. Dialogue syntax (critical)

Extracted rules inside block: NONE

## 441152bcf7b463bd — video/references/veo.md:51-51 (paragraph)

Veo is the only model that renders synced lip movement and voice. The syntax matters.

Extracted rules inside block: NONE

## 01377237e7263812 — video/references/veo.md:53-53 (heading)

### Required format

Extracted rules inside block: NONE

## f7257fce7b9260a0 — video/references/veo.md:55-55 (paragraph)

Double quotes + lead-in verb (says, whispers, shouts, mutters, asks).

Extracted rules inside block: NONE

## ddab12e5b473440a — video/references/veo.md:57-61 (code)

```text
A woman says, "Welcome to the future."
He whispers, "Don't move."
She shouts, "Get out!"
```

Extracted rules inside block: NONE

## cf00c9121c15d981 — video/references/veo.md:63-63 (paragraph)

Colon after the lead-in verb works too and is often more reliable.

Extracted rules inside block: NONE

## f2ddb628308430bd — video/references/veo.md:65-67 (code)

```text
A woman says: "Welcome to the future."
```

Extracted rules inside block: NONE

## 1bf5f498ef4e6397 — video/references/veo.md:69-69 (heading)

### Voice character modifiers

Extracted rules inside block: NONE

## 06906b15d980d61f — video/references/veo.md:71-71 (paragraph)

Place modifiers before the lead-in verb.

Extracted rules inside block: NONE

## 6844bc7c484d0919 — video/references/veo.md:73-77 (code)

```text
He says in a weary voice, "We are fine. We are fine."
She whispers nervously, "I don't want to be here."
He shouts excitedly, "We did it!"
```

Extracted rules inside block: NONE

## eda69ad42d7f40e5 — video/references/veo.md:79-79 (heading)

### Timing rule

Extracted rules inside block: NONE

## 191d5804eb1d97a3 — video/references/veo.md:81-81 (paragraph)

Maximum 8 seconds of spoken audio. Cram too many words into a 5s clip and the delivery speeds up unnaturally. Cut the line until it fits.

Extracted rules inside block: NONE

## 84f630949fe14eaf — video/references/veo.md:83-83 (heading)

## 5. SFX syntax

Extracted rules inside block: NONE
