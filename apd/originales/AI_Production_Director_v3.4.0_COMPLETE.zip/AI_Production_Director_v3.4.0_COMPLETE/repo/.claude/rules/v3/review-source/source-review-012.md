# Source coverage review 12/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 48d22609a42dac64 — aurora-prompt-linter/SKILL.md:31-38 (code)

   ```yaml
   - file: "img_ciclista_ff.jpg"
     role: "FF"
     tags: ["P1", "O1", "L1", "PR1"]
   - file: "img_climbing_wall_lf.jpg"
     role: "LF"
     tags: ["L2", "PR1"]
   ```

Extracted rules inside block: NONE

## 4faede73da5571a0 — aurora-prompt-linter/SKILL.md:40-40 (list_item)

2. **Escribir el draft del prompt** (incluyendo negative prompt) a un archivo de texto.

Extracted rules inside block: 56ce83c22bf0

## 03a1cbd32c3bc1b8 — aurora-prompt-linter/SKILL.md:42-42 (list_item)

3. **Capturar el mensaje del usuario** del turno actual a un archivo de texto (para parsear OVERRIDEs).

Extracted rules inside block: e873759cd7ab

## 343146f52d664b7e — aurora-prompt-linter/SKILL.md:44-44 (list_item)

4. **Ejecutar el linter:**

Extracted rules inside block: 21913bafdc19

## 442322f4db86d03a — aurora-prompt-linter/SKILL.md:45-52 (code)

   ```bash
   python3 scripts/prompt_linter.py \
     --prompt /tmp/draft.txt \
     --refs /tmp/refs.yaml \
     --case 3b \
     --overrides /tmp/user_msg.txt \
     --sports-broadcast
   ```

Extracted rules inside block: NONE

## 18dd51d94c6967a3 — aurora-prompt-linter/SKILL.md:54-54 (list_item)

5. **Interpretar el resultado:**

Extracted rules inside block: b2bbc75550ad

## 34bc3c9d7e1b1345 — aurora-prompt-linter/SKILL.md:55-55 (list_item)

   - Exit 0 → STATUS=PASS → entregar al usuario + incluir reporte del linter en el output para trazabilidad.

Extracted rules inside block: NONE

## 6b0759693d31196a — aurora-prompt-linter/SKILL.md:56-56 (list_item)

   - Exit 1 → STATUS=FAIL → NO entregar. Iterar el draft basándose en las violaciones listadas. Repetir hasta PASS.

Extracted rules inside block: NONE

## 52c986a343a1f540 — aurora-prompt-linter/SKILL.md:58-58 (heading)

## Categorías que detecta

Extracted rules inside block: NONE

## 71e77ed9285997ee — aurora-prompt-linter/SKILL.md:60-60 (table_row)

| Categoría | Qué cubre | Cuándo se banea en MAIN |

Extracted rules inside block: NONE

## c0c19fe264341ffd — aurora-prompt-linter/SKILL.md:62-62 (table_row)

| **P** | Sujeto: cara, cuerpo, edad, build, cabello, expresión, identidad | Si ref carga P |

Extracted rules inside block: NONE

## 620a80bdd23503a2 — aurora-prompt-linter/SKILL.md:63-63 (table_row)

| **O** | Outfit: prendas, colores, accesorios | Si ref carga O |

Extracted rules inside block: NONE

## 9fc1160898619a09 — aurora-prompt-linter/SKILL.md:64-64 (table_row)

| **L** | Locación: piso, paredes, ventanas, lighting, ambiente | Si ref carga L |

Extracted rules inside block: NONE

## 027f341abd11e0a1 — aurora-prompt-linter/SKILL.md:65-65 (table_row)

| **PR** | Prop: balón, objeto interactuado | Si ref carga PR |

Extracted rules inside block: NONE

## d34056ea53260634 — aurora-prompt-linter/SKILL.md:66-66 (table_row)

| **S** | Estilo: render, paleta, aesthetic | Si ref carga S |

Extracted rules inside block: NONE

## 33a7e5522e4cd3e8 — aurora-prompt-linter/SKILL.md:67-67 (table_row)

| **BANNED** | Cross-platform: `slow motion`, `cartoon`, `anime`, `3D render`, `perfume ad`, `dreamlike` | SIEMPRE en MAIN (deben ir en NEGATIVE) |

Extracted rules inside block: 4cc6a28a3ac6

## 258871c99d49153c — aurora-prompt-linter/SKILL.md:68-68 (table_row)

| **STRUCTURE** | Word count, presencia de negative prompt | Siempre |

Extracted rules inside block: 29640fdcd35c

## 1def423bff1c23c3 — aurora-prompt-linter/SKILL.md:69-69 (table_row)

| **REQUIRED** | `60fps`, `broadcast realism` (con flag --sports-broadcast) | Cuando aplica Regla 26 v6.0 |

Extracted rules inside block: bdbfe3825e8c

## d06dd9ab845776f2 — aurora-prompt-linter/SKILL.md:71-71 (heading)

## Exenciones automáticas

Extracted rules inside block: NONE

## f8f0b3f890240d2a — aurora-prompt-linter/SKILL.md:73-73 (paragraph)

El linter NO flaggea cuando el término aparece en:

Extracted rules inside block: NONE

## 6f6fa71a20be7bd0 — aurora-prompt-linter/SKILL.md:75-75 (list_item)

- **Contexto de motion/cámara**: `camera arcs through the studio` — "studio" exento porque sigue a "camera".

Extracted rules inside block: NONE

## 98781dde3e2354c6 — aurora-prompt-linter/SKILL.md:76-76 (list_item)

- **Anchor direccional**: `away from her face`, `across the climbing wall`, `over his head` — preposiciones direccionales (`away from`, `toward`, `off`, `over`, `behind`, `across`, `past`, `onto`, `into`, `above`, `below`, `beside`) seguidas opcionalmente de `her/his/the` exentan el término que sigue.

Extracted rules inside block: NONE

## 22a7518d8bd952d5 — aurora-prompt-linter/SKILL.md:78-78 (paragraph)

Esto distingue descriptor estático ("warm tungsten studio") de uso funcional ("ball passes through the studio").

Extracted rules inside block: NONE

## 721c11c4fed93c90 — aurora-prompt-linter/SKILL.md:80-80 (heading)

## Mecanismo de override

Extracted rules inside block: NONE

## 9bcaae91dd42ddb9 — aurora-prompt-linter/SKILL.md:82-82 (paragraph)

Si una violación detectada es legítima en el caso actual, el usuario puede autorizarla **expresamente por escrito en el turno actual**.

Extracted rules inside block: NONE

## f863a1ed6ede4b8f — aurora-prompt-linter/SKILL.md:84-84 (paragraph)

Sintaxis válida:

Extracted rules inside block: NONE

## 25fbfe8c8ac7b9b2 — aurora-prompt-linter/SKILL.md:85-87 (code)

```
OVERRIDE: <término-o-categoría> - <razón>
```

Extracted rules inside block: NONE

## 88724752ab8c1ace — aurora-prompt-linter/SKILL.md:89-89 (paragraph)

Ejemplos válidos:

Extracted rules inside block: NONE

## b87f6ed1d48d3d0b — aurora-prompt-linter/SKILL.md:90-90 (list_item)

- `OVERRIDE: red performance tank - necesito reforzar el color porque seeds previas lo pierden`

Extracted rules inside block: NONE

## 2d398d294db7ff53 — aurora-prompt-linter/SKILL.md:91-91 (list_item)

- `OVERRIDE: L - autorizo describir locación porque la ref está muy oscura`

Extracted rules inside block: NONE
