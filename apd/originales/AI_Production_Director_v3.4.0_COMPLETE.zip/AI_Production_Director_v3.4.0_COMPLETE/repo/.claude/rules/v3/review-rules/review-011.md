# Rule classification review 11/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## 5932b40618b8 — produccion-visual-sw30/SKILL.md:83

`production-package/template_engine.py` es OBLIGATORIO para construir cualquier prompt visual.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "5932b40618b8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## be1fdee5e6f0 — produccion-visual-sw30/SKILL.md:84

Un prompt no se escribe: se INSTANCIA con `build(tipo, ..., notes=...)`. El motor lanza

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "be1fdee5e6f0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 3166a8f4f0a8 — produccion-visual-sw30/SKILL.md:97

**PROHIBIDO editar el texto de un brief individual.** Eso es parchar: arregla una cosa y rompe otra, y es la causa raíz de los ciclos de tres reescrituras.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "3166a8f4f0a8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 0e349eb3d601 — produccion-visual-sw30/SKILL.md:116

Un solo trabajo por generación. Con dos personajes: un sujeto por generación, o técnica de colocación probada; nunca "a ver si sale".

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "0e349eb3d601",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## c141b7d36f7f — produccion-visual-sw30/SKILL.md:118

Posición SIEMPRE por ancla legible de la propia imagen (letterforms del mundo: "his back level with the letter L of WORLD"). Prohibido "left half", "centre", "just left of X".

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "c141b7d36f7f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 22a58fe6bad7 — produccion-visual-sw30/SKILL.md:120

El editor no tiene memoria: solo verbos operativos (Move/Replace/Add/Remove/Swap), cero narrativa ("has become", "again").

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "22a58fe6bad7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 49df7a8c190f — produccion-visual-sw30/SKILL.md:122

Autocontención: toda comparación ("same X") exige ambos referentes adjuntos en ESE prompt.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "49df7a8c190f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 9795f4039ac2 — produccion-visual-sw30/SKILL.md:123

Herencia mínima: "same face and clothes" + solo los deltas. Cero re-descripción de lo que la referencia ya muestra.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "9795f4039ac2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "in",
            "path": "media",
            "value": [
              "image",
              "video"
            ]
          },
          {
            "op": "in",
            "path": "stage",
            "value": [
              "asset",
              "prompt",
              "generation",
              "qa"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 28fa75d7e21f — produccion-visual-sw30/SKILL.md:125

Swap de identidad = última operación, sola: "Replace X with Y — same position, same pose, same scale".

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "28fa75d7e21f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "in",
            "path": "media",
            "value": [
              "image",
              "video"
            ]
          },
          {
            "op": "in",
            "path": "stage",
            "value": [
              "asset",
              "prompt",
              "generation",
              "qa"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 1b509854dab2 — produccion-visual-sw30/SKILL.md:127

Mundos por dos pasos: placa vacía primero; insert con "use only the person from image N, ignore its setting" + "keep the world of image 1 untouched".

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "1b509854dab2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 765066b04741 — produccion-visual-sw30/SKILL.md:129

Stills en instante congelado ("frozen mid-stride"); nada de movimiento en imagen fija.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "765066b04741",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 3d87c28794d7 — produccion-visual-sw30/SKILL.md:130

Contactos entre personas: "a natural high five" — la anatomía la fija el keyframe aprobado, nunca la asignación de manos por texto.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "3d87c28794d7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "in",
            "path": "media",
            "value": [
              "image",
              "video"
            ]
          },
          {
            "op": "in",
            "path": "stage",
            "value": [
              "asset",
              "prompt",
              "generation",
              "qa"
            ]
          }
        ]
      },
      {
        "op": "eq",
        "path": "subject.hands_visible",
        "value": true
      },
      {
        "op": "eq",
        "path": "subject.human_contact",
        "value": true
      }
    ]
  }
}
```

## 1f65681e2725 — produccion-visual-sw30/SKILL.md:132

Logos solo heredados de asset aprobado o descripción canónica del brand-lock; los cuerpos nunca tapan logo ni lettering en frames congelados.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "1f65681e2725",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 31f5b0456b3a — produccion-visual-sw30/SKILL.md:134

Lo aprobado se canoniza con hash y se EDITA desde ahí; lo caro nunca se regenera.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "31f5b0456b3a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 0da4ba63e69d — produccion-visual-sw30/SKILL.md:135

"Edit, don't re-roll": resultado ≥80% correcto → cambio puntual (hasta 3 ediciones apiladas), nunca re-tirar.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "0da4ba63e69d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 71e73c3bfcd2 — produccion-visual-sw30/SKILL.md:137

Máximo 2 intentos por método. A la 2ª falla: cambio de método con causa declarada, o alto y consulta. Nunca tercera vuelta de lo mismo.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "71e73c3bfcd2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## d5fd08bdb869 — produccion-visual-sw30/SKILL.md:139

Validadores del paquete y techos de palabras en verde antes de entregar; inspección visual propia (zooms 100% de rostros y manos) antes de presentar. Si algo falla: no se entrega, se repite — y se dice qué falló en una línea.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "d5fd08bdb869",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "in",
            "path": "media",
            "value": [
              "image",
              "video"
            ]
          },
          {
            "op": "in",
            "path": "stage",
            "value": [
              "asset",
              "prompt",
              "generation",
              "qa"
            ]
          }
        ]
      },
      {
        "op": "eq",
        "path": "subject.hands_visible",
        "value": true
      }
    ]
  }
}
```

## 1f9a9b8de3ca — produccion-visual-sw30/SKILL.md:142

shots.json es la fuente de verdad: todo cambio entra ahí primero y se propaga.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "1f9a9b8de3ca",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 084f0c4f151a — produccion-visual-sw30/SKILL.md:143

Clips: solo Preserve-cues, roles de start/tail ("The tail image defines X — inherit exactly"), movimiento puro, imagen final nombrada; negativos sin "no X", ≤8 ítems.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "084f0c4f151a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## f52348820e6f — produccion-visual-sw30/SKILL.md:145

Entregas en unidades chicas con OK de dirección; se entrega el delta, no el paquete. Una regla nueva de dirección se aplica a TODOS los prompts, no a la mitad.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "f52348820e6f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 16c17b8e1acd — produccion-visual-sw30/SKILL.md:147

Respuestas: el dato o entregable en la primera línea. Cero adulación y cero evaluación de las acciones de Eric salvo que la pida. Error = una línea de corrección, sin disculpas.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "16c17b8e1acd",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 408bd188d7f5 — produccion-visual-sw30/SKILL.md:149

Prohibido afirmar capacidades, límites o hechos de plataforma sin verificarlos en este turno (leer la fuente o buscar); lo no verificado se etiqueta como inferencia.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "408bd188d7f5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 76c1dbf51899 — produccion-visual-sw30/SKILL.md:151

/research solo para problemas genuinamente nuevos; /briefing solo al retomar tras días fuera; /handoff al cerrar sesión. Ninguno por default.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "76c1dbf51899",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 4db660049421 — screenwriter/SKILL.md:77

Always use ALL CAPS for sluglines

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "4db660049421",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## f96b07c9012c — screenwriter/SKILL.md:78

Use hyphens to separate elements

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "f96b07c9012c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## bf1cbe557267 — screenwriter/SKILL.md:80

Time should suggest lighting/mood

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "bf1cbe557267",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## a47b1dad9f74 — screenwriter/SKILL.md:87

**Show, Don't Tell:** Write what's visible, not internal thoughts

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "a47b1dad9f74",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## dc38b896011a — screenwriter/SKILL.md:88

**Sensory Details:** Include lighting, atmosphere, textures, colors

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "dc38b896011a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## eef66473e3c7 — screenwriter/SKILL.md:89

**Present Tense:** Always write in present tense

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "eef66473e3c7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## e7dd1d22c84d — screenwriter/SKILL.md:90

**Active Voice:** Use strong, active verbs

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "e7dd1d22c84d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## d7a31373b0bc — screenwriter/SKILL.md:91

**Specific Props:** Name objects that matter visually

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "d7a31373b0bc",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## cebc0f2d5d3b — screenwriter/SKILL.md:92

**Atmosphere:** Set mood through environmental details

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "cebc0f2d5d3b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## 586416c651f7 — screenwriter/SKILL.md:128

Avoid excessive detail—just enough for visual consistency

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "586416c651f7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## c543a651cf13 — screenwriter/SKILL.md:140

Use dialogue ONLY when essential to story

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "c543a651cf13",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```

## e8ccbb618ba3 — screenwriter/SKILL.md:157

`CUT TO:` - Scene change (usually implied, use for emphasis)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "e8ccbb618ba3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "in",
    "path": "stage",
    "value": [
      "script",
      "scene"
    ]
  }
}
```
