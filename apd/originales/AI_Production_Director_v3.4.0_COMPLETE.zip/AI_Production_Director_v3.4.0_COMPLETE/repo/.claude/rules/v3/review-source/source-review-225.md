# Source coverage review 225/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## bf7128f071b844e3 — visual-prompt-forge/references/failure-modes.md:32-32 (list_item)

- Too few features described in character anchor (gives generator too much room)

Extracted rules inside block: NONE

## f4018272da75173c — visual-prompt-forge/references/failure-modes.md:34-34 (paragraph)

**Prompt-level fixes:**

Extracted rules inside block: NONE

## d2c4586d867675ed — visual-prompt-forge/references/failure-modes.md:35-35 (list_item)

- Verify character string is verbatim across every prompt

Extracted rules inside block: NONE

## 6eb2351eaf190186 — visual-prompt-forge/references/failure-modes.md:36-36 (list_item)

- Add 1–2 more specific features ("small scar above left eyebrow", "black wireframe glasses")

Extracted rules inside block: NONE

## f0bc451eff48fae1 — visual-prompt-forge/references/failure-modes.md:37-37 (list_item)

- Use reference image after the first successful shot

Extracted rules inside block: aada37d743da

## 9244f3fefd837f49 — visual-prompt-forge/references/failure-modes.md:38-38 (list_item)

- Lock seed at storyboard level

Extracted rules inside block: NONE

## 6e39a30b1bdb87b1 — visual-prompt-forge/references/failure-modes.md:39-39 (list_item)

- For Midjourney, use `--cref` with `--cw 50`

Extracted rules inside block: 3d08083cf84c

## 7d12999f5718fde3 — visual-prompt-forge/references/failure-modes.md:41-41 (paragraph)

**Accept editorially when:** character consistency is genuinely impossible to lock. Budget re-rolls, typically 2–3× per problematic shot.

Extracted rules inside block: NONE

## 235c54c60e2068fe — visual-prompt-forge/references/failure-modes.md:43-43 (heading)

## Failure 3. Text in image looks bad

Extracted rules inside block: NONE

## eb3a2d77e9ba4726 — visual-prompt-forge/references/failure-modes.md:45-45 (paragraph)

**Symptoms:** text is misspelled, kerning is off, font is wrong, multiple text elements compete.

Extracted rules inside block: NONE

## 519571629491557d — visual-prompt-forge/references/failure-modes.md:47-47 (paragraph)

**Causes:**

Extracted rules inside block: NONE

## b69ec0c013e393ba — visual-prompt-forge/references/failure-modes.md:48-48 (list_item)

- Text was put in the image prompt instead of being composited

Extracted rules inside block: NONE

## ed94a12dc7f8c45e — visual-prompt-forge/references/failure-modes.md:49-49 (list_item)

- Wrong generator chosen (using Midjourney for text-heavy work)

Extracted rules inside block: NONE

## 736e3120f3725498 — visual-prompt-forge/references/failure-modes.md:50-50 (list_item)

- Multiple text elements in one prompt

Extracted rules inside block: NONE

## 1dc39f1c4edd6004 — visual-prompt-forge/references/failure-modes.md:52-52 (paragraph)

**Prompt-level fixes:**

Extracted rules inside block: NONE

## fa096e2e7876f508 — visual-prompt-forge/references/failure-modes.md:53-53 (list_item)

- The right answer is almost always: **don't put text in the prompt**. Composite separately from `text-overlays.json`.

Extracted rules inside block: 034e657259a2

## 59714887cb0b9258 — visual-prompt-forge/references/failure-modes.md:54-54 (list_item)

- If text must be in-image (poster work), use Ideogram v3 with explicit override flag

Extracted rules inside block: 680241b62a60

## 8fa6178f83cee0a0 — visual-prompt-forge/references/failure-modes.md:55-55 (list_item)

- Limit to one text element per prompt

Extracted rules inside block: NONE

## d6dce4b9b36a9be4 — visual-prompt-forge/references/failure-modes.md:56-56 (list_item)

- Use simple fonts (sans-serif, clean serif), cursive and decorative fonts fail even on Ideogram

Extracted rules inside block: 5c6209516d60

## 5090b2afa69c2063 — visual-prompt-forge/references/failure-modes.md:58-58 (paragraph)

**Accept editorially when:** the deliverable genuinely requires baked-in text and Ideogram's output is close enough to retouch.

Extracted rules inside block: NONE

## deb632c36312d96f — visual-prompt-forge/references/failure-modes.md:60-60 (heading)

## Failure 4. Lighting direction inconsistency

Extracted rules inside block: NONE

## 7075156b2ed8d714 — visual-prompt-forge/references/failure-modes.md:62-62 (paragraph)

**Symptoms:** shot 3 has light from window-left, shot 4 has light from window-right, they cut together as a continuity error.

Extracted rules inside block: NONE

## 04bb42eb4bb9025c — visual-prompt-forge/references/failure-modes.md:64-64 (paragraph)

**Causes:**

Extracted rules inside block: NONE

## f6e42a5e712b8004 — visual-prompt-forge/references/failure-modes.md:65-65 (list_item)

- Lighting language paraphrased rather than verbatim from series_lock

Extracted rules inside block: NONE

## e208b72895e9cf6c — visual-prompt-forge/references/failure-modes.md:66-66 (list_item)

- Reverse-angle shots not flagged in rationale

Extracted rules inside block: NONE

## 13d759575a22973f — visual-prompt-forge/references/failure-modes.md:67-67 (list_item)

- Generator interpreting lighting ambiguously

Extracted rules inside block: NONE

## 267a5b43f8268a03 — visual-prompt-forge/references/failure-modes.md:69-69 (paragraph)

**Prompt-level fixes:**

Extracted rules inside block: NONE

## 00ec8adb77543403 — visual-prompt-forge/references/failure-modes.md:70-70 (list_item)

- Verify lighting string is verbatim across prompts

Extracted rules inside block: NONE

## adc14bd8978aadd2 — visual-prompt-forge/references/failure-modes.md:71-71 (list_item)

- Be explicit about direction: "from camera-left" not "from one side"

Extracted rules inside block: NONE

## 2f97c9fa6318ba42 — visual-prompt-forge/references/failure-modes.md:72-72 (list_item)

- For reverse-angle shots, flag in rationale and update lighting language for that shot only

Extracted rules inside block: NONE
