# Source coverage review 98/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 21028a8f963acbc4 — storyboard-architect/SKILL.md:299-299 (paragraph)

After producing the five files, tell the user what's in `output/` and offer the obvious next steps:

Extracted rules inside block: NONE

## d2470336d91b50e0 — storyboard-architect/SKILL.md:301-301 (list_item)

- "Want image prompts? I'll run `visual-prompt-forge` on `shots.json`."

Extracted rules inside block: NONE

## 9c7c2d43ba7b93e5 — storyboard-architect/SKILL.md:302-302 (list_item)

- "Want a shareable HTML preview? I'll run `storyboard-html-preview`."

Extracted rules inside block: NONE

## 04ebd5d2d7c8c467 — storyboard-architect/SKILL.md:303-303 (list_item)

- "Want to QA a generated image against this storyboard? I'll run `visual-asset-critic`."

Extracted rules inside block: NONE

## 5accff36663ba9ea — storyboard-architect/SKILL.md:305-305 (paragraph)

Don't run those automatically. The user picks.

Extracted rules inside block: 403fb209717b

## f524b157a141d66c — storyboard-architect/brand-packs/README.md:1-1 (heading)

# Brand Packs

Extracted rules inside block: NONE

## 1d01bb795762f6a1 — storyboard-architect/brand-packs/README.md:3-3 (paragraph)

A brand pack is a single Markdown file that locks in palette, typography, voice, and visual rules for a project. The skills in this pack consume it. Every storyboard, every prompt, every generated frame inherits from it.

Extracted rules inside block: NONE

## 5924c585fba84918 — storyboard-architect/brand-packs/README.md:5-5 (heading)

## How to use

Extracted rules inside block: NONE

## c014be4c78ad6e6a — storyboard-architect/brand-packs/README.md:7-7 (list_item)

1. Copy `_template.md` to a new file (e.g. `acme.md`)

Extracted rules inside block: 447eeb5122e5

## daf3ab7a24849cef — storyboard-architect/brand-packs/README.md:8-8 (list_item)

2. Fill in every field. No placeholders left behind.

Extracted rules inside block: 97bb97eae461

## 2da9b39b357140bd — storyboard-architect/brand-packs/README.md:9-9 (list_item)

3. Reference it from your storyboard requests:

Extracted rules inside block: 4d80edc45e81

## 9763f82fa26cc337 — storyboard-architect/brand-packs/README.md:11-11 (list_item)

   > "30-second founder explainer. Use `brand-packs/acme.md` as the brand lock."

Extracted rules inside block: c78bc11879db

## 4862ed711cd49444 — storyboard-architect/brand-packs/README.md:13-13 (list_item)

4. The skill reads it, snapshots it into the output as `brand-lock.snapshot.md`, and applies it through the pipeline.

Extracted rules inside block: d20463c33677

## b46dd5a5f24a613a — storyboard-architect/brand-packs/README.md:15-15 (heading)

## How to write a good one

Extracted rules inside block: NONE

## 6cdf97e199e15223 — storyboard-architect/brand-packs/README.md:17-17 (paragraph)

The template is a checklist, not a creative-writing exercise. Three rules:

Extracted rules inside block: NONE

## 1e1a7632ad36e459 — storyboard-architect/brand-packs/README.md:19-19 (paragraph)

**Be specific.** "Modern, clean, professional" is not a brand. "Calm, considered, operator energy, confident without shouting" is.

Extracted rules inside block: NONE

## 1d9e90844e9574b8 — storyboard-architect/brand-packs/README.md:21-21 (paragraph)

**Be exclusive.** The "never" list is more valuable than the "always" list. Listing what the brand will not do narrows the generator's space and produces tighter output.

Extracted rules inside block: d47eef584353

## 8081e1f3aa561179 — storyboard-architect/brand-packs/README.md:23-23 (paragraph)

**Be hex-precise.** Every color is a hex value. Every font is named. The skills consume structured data; vagueness here cascades into bad prompts later.

Extracted rules inside block: NONE

## d23afa64e7f20bd3 — storyboard-architect/brand-packs/README.md:25-25 (heading)

## Examples

Extracted rules inside block: NONE

## a9895fda82688081 — storyboard-architect/brand-packs/README.md:27-27 (paragraph)

The pack ships with two reference brand packs:

Extracted rules inside block: NONE

## d372314cae72e757 — storyboard-architect/brand-packs/README.md:29-29 (list_item)

- **`whystrohm.md`** (flagship). The actual brand pack WhyStrohm uses on its own content. Real palette, real voice rules, real "never" list. Use this as the reference for the level of specificity production work requires.

Extracted rules inside block: 668412122538

## 5a575d83e608054f — storyboard-architect/brand-packs/README.md:30-30 (list_item)

- **`examples/saas-clean.md`**. B2B SaaS, restrained, professional. Light backgrounds, single accent. Inter type stack. A neutral counterpoint to the WhyStrohm flagship.

Extracted rules inside block: NONE

## 08ae565f28839edc — storyboard-architect/brand-packs/README.md:32-32 (paragraph)

More example brand packs will land in v2.0.0. PRs welcome.

Extracted rules inside block: NONE

## f8ddea8e7a07c60b — storyboard-architect/brand-packs/README.md:34-34 (heading)

## Generating a brand pack from existing assets

Extracted rules inside block: NONE

## 344b07d1844771ef — storyboard-architect/brand-packs/README.md:36-36 (paragraph)

Don't hand-author from scratch if the brand already exists. The **`brand-lock-extractor`** skill (ships in this repo at `skills/brand-lock-extractor/`) takes a website URL, a brand book PDF, screenshots, or a written description and produces a `brand-lock.md` in this exact format, with a confidence and source noted for every value:

Extracted rules inside block: b12c8ee34f41

## 904dd019b9700e74 — storyboard-architect/brand-packs/README.md:38-38 (list_item)

> "Extract a brand-lock from acme.com" or "build a brand pack from this brand book PDF."

Extracted rules inside block: NONE

## 77abeb837c46b527 — storyboard-architect/brand-packs/README.md:40-40 (paragraph)

For bulk or programmatic extraction across many URLs, [media-tsunami](https://github.com/whystrohm/media-tsunami) (WhyStrohm's open-source brand voice extractor) scrapes URLs and produces a `brand-lock.md` in the same format.

Extracted rules inside block: NONE

## f1335c24af6cfa9f — storyboard-architect/brand-packs/README.md:42-42 (heading)

## Versioning

Extracted rules inside block: NONE

## d6cf07d0b2b43c78 — storyboard-architect/brand-packs/README.md:44-44 (paragraph)

Every storyboard run snapshots the brand pack it was built against. If you update `acme.md` later, previous storyboards still reference the version they were built on. This is intentional, the audit trail tells you exactly what brand state any given piece of content was built against.

Extracted rules inside block: NONE

## 5ce7bee93c1c9a93 — storyboard-architect/brand-packs/README.md:46-46 (paragraph)

When you make a brand-pack revision that materially changes look or voice, bump the `Version:` field at the bottom and note the change. e.g.:

Extracted rules inside block: NONE
