# Source coverage review 97/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## afcc7662c467762c — storyboard-architect/SKILL.md:237-237 (heading)

## Quality bar

Extracted rules inside block: NONE

## 67a3a4e3a7b2340c — storyboard-architect/SKILL.md:239-239 (paragraph)

Run the validator. Do not eyeball this list.

Extracted rules inside block: 0f4fad80e063

## 5dc11bcfa9eb45c6 — storyboard-architect/SKILL.md:241-245 (code)

```bash
python tools/validate_shots.py output/
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_provenance.py output/
```

Extracted rules inside block: NONE

## 32a561b0dc870484 — storyboard-architect/SKILL.md:247-248 (paragraph)

`validate_shots.py` checks every mechanical rule that used to live here as a checkbox,
because a checkbox is a rule enforced by remembering to look:

Extracted rules inside block: NONE

## 9a996f1d44fa2cfd — storyboard-architect/SKILL.md:250-250 (list_item)

- shots.json and text-overlays.json validate against their schemas

Extracted rules inside block: NONE

## 2a150f73255d8407 — storyboard-architect/SKILL.md:251-252 (list_item)

- `end` is after `start`, no duplicate ids, no gaps, no overlaps, and the covered span
  matches `project.duration_s` within 0.1s

Extracted rules inside block: NONE

## c5c5bdf815d44156 — storyboard-architect/SKILL.md:253-254 (list_item)

- every `on_screen_text` resolves to an overlay, every `overlay.shot_id` resolves to a
  shot, and every overlay is reachable from at least one shot

Extracted rules inside block: NONE

## 63d26556fe76e62d — storyboard-architect/SKILL.md:255-255 (list_item)

- every overlay's timing sits inside its shot window, and exit is after enter

Extracted rules inside block: NONE

## 11c8460b29ff73f9 — storyboard-architect/SKILL.md:256-256 (list_item)

- every overlay color appears in the brand-lock palette

Extracted rules inside block: NONE

## 160796e1e5c7ad4b — storyboard-architect/SKILL.md:257-257 (list_item)

- `brand_lock_ref` resolves on disk

Extracted rules inside block: NONE

## 7e43b663d8ae0b6f — storyboard-architect/SKILL.md:259-261 (paragraph)

It warns, rather than fails, on judgement calls worth a second look: overlay copy
repeated inside a shot subject, a raw hex in a subject, shot ids out of chronological
order, an overlay font the brand-lock does not declare.

Extracted rules inside block: NONE

## bee21ac1915816ae — storyboard-architect/SKILL.md:263-263 (paragraph)

What the validator cannot check, and you still have to:

Extracted rules inside block: NONE

## 65974304b46df102 — storyboard-architect/SKILL.md:265-265 (list_item)

- [ ] Every rationale says *why this shot at this moment*, not what the shot contains

Extracted rules inside block: NONE

## 9d616739e5411d98 — storyboard-architect/SKILL.md:266-266 (list_item)

- [ ] `series_lock` anchors are specific enough to reproduce (not "a person in a room")

Extracted rules inside block: NONE

## 7a391be78d337663 — storyboard-architect/SKILL.md:267-267 (list_item)

- [ ] The beat structure actually matches the brief's argument

Extracted rules inside block: NONE

## 2ed0c76d940c966a — storyboard-architect/SKILL.md:268-268 (list_item)

- [ ] `run.json` is written and its hashes are the files as shipped

Extracted rules inside block: NONE

## 43c3d49579ba750d — storyboard-architect/SKILL.md:270-271 (paragraph)

If the validator fails, fix it before declaring done. A green validator plus an unread
rationale is not a finished storyboard.

Extracted rules inside block: NONE

## 2d69ac184ae55eb8 — storyboard-architect/SKILL.md:273-273 (heading)

## Reference files

Extracted rules inside block: NONE

## 0bd6709b7bb86dd2 — storyboard-architect/SKILL.md:275-275 (paragraph)

Load these as needed:

Extracted rules inside block: NONE

## 9df320d568203122 — storyboard-architect/SKILL.md:277-277 (list_item)

- `references/beat-frameworks.md`, the beat structures

Extracted rules inside block: NONE

## 0263d86347a25c85 — storyboard-architect/SKILL.md:278-278 (list_item)

- `references/shot-grammar.md`, controlled vocabulary for framing/angle/motion

Extracted rules inside block: NONE

## 33d7c63c605eed1b — storyboard-architect/SKILL.md:279-279 (list_item)

- `references/timing-rules.md`, pacing math

Extracted rules inside block: NONE

## 172f51ea7ab53f20 — storyboard-architect/SKILL.md:280-280 (list_item)

- `references/on-screen-text.md`, when on-screen text earns its keep

Extracted rules inside block: NONE

## 5a8c2c1cda6d5db8 — storyboard-architect/SKILL.md:282-282 (heading)

## Examples

Extracted rules inside block: NONE

## 6f1111427991388e — storyboard-architect/SKILL.md:284-284 (list_item)

- `examples/30s-pain-proof-promise/`, full output set for a 30-second conversion ad

Extracted rules inside block: NONE

## 264586a5a6837f56 — storyboard-architect/SKILL.md:285-285 (list_item)

- `examples/60s-founder-explainer/`, full output set for a founder explainer

Extracted rules inside block: NONE

## 13a44ec30d09660b — storyboard-architect/SKILL.md:286-287 (list_item)

- `examples/shotkit-explainer/`, the 90-second explainer, including a shot that carries
  two overlays

Extracted rules inside block: NONE

## 776d204c466fb4b0 — storyboard-architect/SKILL.md:289-291 (paragraph)

Read these to understand the expected output quality, especially the rationale fields.
All three validate clean under `tools/validate_shots.py --examples`, so they are also
the reference for what a passing file looks like.

Extracted rules inside block: NONE

## 13e903e74bdf1956 — storyboard-architect/SKILL.md:293-295 (paragraph)

For what the output tree looks like after generation and review, see
`../visual-asset-critic/examples/worked-run/`: two shots through two rounds, with real
hashes, per-round prompts and frames, and one critique per shot per round.

Extracted rules inside block: NONE

## 650c443b3cae0fa8 — storyboard-architect/SKILL.md:297-297 (heading)

## Handoff

Extracted rules inside block: NONE
