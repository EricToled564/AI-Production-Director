# Source coverage review 214/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0cb953ad5df84f17 — visual-prompt-forge/adapters/midjourney.md:56-56 (paragraph)

Pull verbatim from `series_lock.lighting`.

Extracted rules inside block: NONE

## 67d23684d51c78e4 — visual-prompt-forge/adapters/midjourney.md:58-58 (heading)

## Composition pattern

Extracted rules inside block: NONE

## 1804424b735cbc7f — visual-prompt-forge/adapters/midjourney.md:60-62 (code)

```
{framing} of {subject character_anchor}, {action}, {compositional note}, {environment from series_lock}, {lighting from series_lock}, {color_grade}, cinematic photography, {brand mood adjectives} --ar {aspect} --style raw --s 50
```

Extracted rules inside block: NONE

## 9f30a46bccbf2dad — visual-prompt-forge/adapters/midjourney.md:64-64 (heading)

## Example

Extracted rules inside block: NONE

## bc99056cf304d585 — visual-prompt-forge/adapters/midjourney.md:66-66 (paragraph)

**Shot data:**

Extracted rules inside block: NONE

## 9c86c296f3a0a078 — visual-prompt-forge/adapters/midjourney.md:67-76 (code)

```json
{
  "id": "shot_03",
  "framing": "MS",
  "angle": "eye-level",
  "motion": "static",
  "subject": "Founder mid-thirties, leaning forward at laptop, face partially turned to window",
  "rationale": "MS framing leaves negative space right for text overlay"
}
```

Extracted rules inside block: NONE

## 5534ba451b48ea96 — visual-prompt-forge/adapters/midjourney.md:78-78 (paragraph)

**Series lock:**

Extracted rules inside block: NONE

## cc47abede91a3f10 — visual-prompt-forge/adapters/midjourney.md:79-84 (code)

```
character: founder, mid-thirties, salt-and-pepper hair, navy crewneck
environment: minimalist home office, white walls, oak desk
lighting: soft natural side-light, large window left, warm afternoon
color_grade: warm filmic, muted teal shadows
```

Extracted rules inside block: NONE

## 47e41b989eb0d1f1 — visual-prompt-forge/adapters/midjourney.md:86-86 (paragraph)

**Brand lock palette:** `#0F1F3A navy`, `#F5F0E8 cream`, `#D94F3A coral`

Extracted rules inside block: NONE

## 89ac18c25b4d7d7f — visual-prompt-forge/adapters/midjourney.md:88-88 (paragraph)

**Brand mood:** `calm, considered, operator, not creator`

Extracted rules inside block: NONE

## 6c3f9ebd1c22e313 — visual-prompt-forge/adapters/midjourney.md:90-90 (paragraph)

**Output prompt:**

Extracted rules inside block: NONE

## a85f4dc22ff64c35 — visual-prompt-forge/adapters/midjourney.md:91-93 (code)

```
medium shot of founder mid-thirties, salt-and-pepper hair, navy crewneck, leaning forward at laptop, face partially turned to window light, negative space right of frame, minimalist home office, white walls, oak desk, soft natural side-light large window left, warm afternoon golden hour, warm filmic color grade, muted teal shadows, cinematic photography, calm considered operator mood --ar 9:16 --style raw --s 50
```

Extracted rules inside block: NONE

## 21fc7034a4064c4b — visual-prompt-forge/adapters/midjourney.md:95-95 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 352a967e7103e6c9 — visual-prompt-forge/adapters/midjourney.md:97-97 (list_item)

- **Don't use "AI" or "rendered"**, produces stylized outputs that look generated

Extracted rules inside block: 0e74583e51d6

## ae5440f7d5151b4f — visual-prompt-forge/adapters/midjourney.md:98-98 (list_item)

- **Don't over-stack adjectives**, three adjectives per noun phrase max

Extracted rules inside block: a4bcaa489903

## 47d37f4d0d3f8267 — visual-prompt-forge/adapters/midjourney.md:99-99 (list_item)

- **Don't include text content**, even if the shot has `on_screen_text`, leave it out. Composited separately.

Extracted rules inside block: eb4ca17e9715

## 5e0458d1cdd04c0a — visual-prompt-forge/adapters/midjourney.md:100-100 (list_item)

- **Don't use `--c` for series work**, chaos kills consistency

Extracted rules inside block: 149b2ccce82a

## 0f7ba503c0fe3e25 — visual-prompt-forge/adapters/midjourney.md:101-101 (list_item)

- **Don't change `--seed` mid-storyboard**, set once at series_lock level

Extracted rules inside block: b5165b607997

## c0715870c5ed1250 — visual-prompt-forge/adapters/midjourney.md:103-103 (heading)

## API access note

Extracted rules inside block: NONE

## da63f07a9fdb9b30 — visual-prompt-forge/adapters/midjourney.md:105-105 (paragraph)

Midjourney still has limited API access as of Q2 2026. For programmatic workflows, the prompts in `midjourney.txt` are designed to be pasted into Discord or the web UI. Some teams use third-party wrappers (PiAPI, Useapi.net), those generally accept the same prompt syntax.

Extracted rules inside block: 9832346eb9f4

## b6de5df3121bc263 — visual-prompt-forge/adapters/nano-banana.md:1-1 (heading)

# Adapter: Nano Banana (Gemini 2.5 Flash Image)

Extracted rules inside block: NONE

## 0d9bad1fdfa94d0d — visual-prompt-forge/adapters/nano-banana.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: acaf6c8fcbbf

## d60b7ea3e5198996 — visual-prompt-forge/adapters/nano-banana.md:5-5 (paragraph)

Google's Nano Banana model (`gemini-2.5-flash-image`) is the edit-and-iterate champion. Where other generators are best for first-frame creation, Nano Banana excels at variations, inpainting, and reference-based modification. The 2026 production pattern is to generate hero frames in Midjourney or Flux, then use Nano Banana for variants.

Extracted rules inside block: 9e29e2774dcd

## 378869fa13834549 — visual-prompt-forge/adapters/nano-banana.md:7-7 (paragraph)

For storyboard work, Nano Banana is the right choice when you need **many variations of a single concept** or you're feeding generated images back through for refinement.

Extracted rules inside block: NONE

## 50f09ef52413fd52 — visual-prompt-forge/adapters/nano-banana.md:9-9 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## 87bb6a1bb3a82407 — visual-prompt-forge/adapters/nano-banana.md:11-11 (paragraph)

Nano Banana takes natural-language prompts plus optional reference images. For text-to-image:

Extracted rules inside block: NONE

## 3ff43a9b0d1f9264 — visual-prompt-forge/adapters/nano-banana.md:13-15 (code)

```
{Subject and action}. {Environment and lighting}. {Photographic specs and mood}.
```

Extracted rules inside block: NONE

## d7c22005da1c8f4f — visual-prompt-forge/adapters/nano-banana.md:17-17 (paragraph)

For image-to-image (the strength), the prompt describes the modification:

Extracted rules inside block: NONE

## a00d7fdca143febf — visual-prompt-forge/adapters/nano-banana.md:19-21 (code)

```
{Modification description}. Keep {what to preserve}. Change {what to vary}.
```

Extracted rules inside block: NONE

## 6fa04076a3b5b95d — visual-prompt-forge/adapters/nano-banana.md:23-23 (heading)

## Parameters

Extracted rules inside block: NONE
