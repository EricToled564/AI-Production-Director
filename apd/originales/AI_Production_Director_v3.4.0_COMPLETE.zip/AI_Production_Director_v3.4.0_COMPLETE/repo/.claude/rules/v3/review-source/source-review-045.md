# Source coverage review 45/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## feb037122826ecf3 — image/references/gpt-image.md:89-89 (list_item)

- **Surgical edits:** явно перечисли что НЕ трогать (saturation, contrast, layout, arrows, labels, camera angle).

Extracted rules inside block: NONE

## c024cadba00cd464 — image/references/gpt-image.md:90-90 (list_item)

- Опционально: `mask_image_url` для точечных edits.

Extracted rules inside block: NONE

## b6b5da6b91dbb388 — image/references/gpt-image.md:92-92 (heading)

### Edit-паттерны

Extracted rules inside block: NONE

## d7b54e4f9712be27 — image/references/gpt-image.md:94-94 (paragraph)

**Virtual try-on:** «Change garments only. Preserve exact face, body shape, pose, hair, expression, background, camera angle. Match lighting/shadows so outfit looks naturally worn.»

Extracted rules inside block: NONE

## 956c0d5c787b973e — image/references/gpt-image.md:96-96 (paragraph)

**Object removal:** «Remove [X]. Do not change anything else. Use `input_fidelity: high` to maintain surrounding context» (только gpt-image-1.5/1, в gpt-image-2 high-fidelity по умолчанию).

Extracted rules inside block: fb4253457fd1

## fb51a812c3931d20 — image/references/gpt-image.md:98-98 (paragraph)

**Lighting/weather swap:** «Change ONLY environmental conditions: lighting direction/quality, shadows, atmosphere, precipitation. Preserve identity, geometry, camera angle, object placement.»

Extracted rules inside block: NONE

## 041bb2ffb2bec095 — image/references/gpt-image.md:100-100 (paragraph)

**Interior swap:** «Swap [furniture]. Preserve camera angle, lighting, shadows, surrounding context. Photorealistic contact shadows.»

Extracted rules inside block: NONE

## c100d868decf1480 — image/references/gpt-image.md:102-102 (heading)

## Multi-Image — до 16 рефов

Extracted rules inside block: NONE

## 884d72284c3186fd — image/references/gpt-image.md:104-104 (paragraph)

Индексируй с **ролью**, не только номером:

Extracted rules inside block: NONE

## ad811ff6adfca9ac — image/references/gpt-image.md:105-109 (code)

```
Image 1: base scene
Image 2: jacket reference (apply only the jacket fabric/cut to subject in Image 1)
Image 3: lighting reference (apply golden-hour quality from Image 3)
```

Extracted rules inside block: NONE

## c5306af954037b6a — image/references/gpt-image.md:111-111 (heading)

## Style Transfer

Extracted rules inside block: NONE

## 22122ef2f4fad3c7 — image/references/gpt-image.md:113-113 (paragraph)

Не пиши абстрактно («minimalist», «editorial»). Назови конкретные визуальные свойства референса: палитра, edge treatment, силуэт, обработка теней, plane логика.

Extracted rules inside block: NONE

## db918bac9a5a781c — image/references/gpt-image.md:115-115 (heading)

## World Knowledge

Extracted rules inside block: NONE

## c1c32c7e2ed3c6bc — image/references/gpt-image.md:117-117 (paragraph)

GPT Image 2 умеет домысливать контекст: «Bethel, NY, August 1969» → выведет Woodstock-эстетику. Используй: дай исторический/культурный анкер, не расписывай каждую деталь.

Extracted rules inside block: 262074c5d4a4

## f7dde83775e7d9b9 — image/references/gpt-image.md:119-119 (heading)

## Iteration Strategy

Extracted rules inside block: NONE

## c080c8599eab8bfa — image/references/gpt-image.md:121-121 (list_item)

- Стартуй с **чистого** базового промпта.

Extracted rules inside block: NONE

## 9d0e4c8736a679a4 — image/references/gpt-image.md:122-122 (list_item)

- Один change за раунд. «Make lighting warmer», «remove extra tree», «restore original background».

Extracted rules inside block: NONE

## 15b243c6dd2e32e8 — image/references/gpt-image.md:123-123 (list_item)

- При drift — перечисли invariants заново.

Extracted rules inside block: NONE

## e98db3a118db5308 — image/references/gpt-image.md:124-124 (list_item)

- Для длинных промптов — labeled sections, не одна простыня.

Extracted rules inside block: NONE

## bde475f71136904c — image/references/gpt-image.md:126-126 (heading)

## Use-Case Templates

Extracted rules inside block: NONE

## 9e9697ff796808a1 — image/references/gpt-image.md:128-128 (heading)

### Photoreal Editorial

Extracted rules inside block: NONE

## 060bddb19bb08d98 — image/references/gpt-image.md:129-135 (code)

```
Scene: [location, time, weather]
Subject: [who, action, framing]
Important Details: [lens feel, light source, surface wear, imperfections, real texture]
Use Case: editorial photograph, looks like a real photo
Constraints: no glamorization, no heavy retouching, no studio gloss
```

Extracted rules inside block: NONE

## ea68dc74252783b8 — image/references/gpt-image.md:137-137 (heading)

### Product Mockup (Clean Background)

Extracted rules inside block: NONE

## 4927ec807c954543 — image/references/gpt-image.md:138-145 (code)

```
Scene: plain white opaque background
Subject: [product] centered
Important Details: crisp silhouette, no halos/fringing, light contact shadow,
  preserve label legibility exactly, preserve geometry
Use Case: product mockup
Constraints: no restyling, only background removal + light polish
```

Extracted rules inside block: NONE

## 517eb255a8ddabd4 — image/references/gpt-image.md:147-147 (heading)

### UI Mockup

Extracted rules inside block: NONE

## 3699c5ec0e4661e1 — image/references/gpt-image.md:148-156 (code)

```
Scene: [device frame, e.g. iPhone 15 Pro]
Subject: [screen/app name] — describe AS IF IT EXISTS, not concept art
Important Details: layout, hierarchy, real interface elements, exact copy in quotes,
  typography behavior, spacing, state
Use Case: shipped product screenshot
Constraints: no sketch language, no placeholder text, no Lorem Ipsum
Quality: high (for small UI text)
```

Extracted rules inside block: NONE

## 2f869b7fc2ba3361 — image/references/gpt-image.md:158-158 (heading)

### Marketing Creative with Text

Extracted rules inside block: NONE

## f882e40f38f600c6 — image/references/gpt-image.md:159-168 (code)

```
Scene: [environment]
Subject: [hero element]
Important Details: [composition, palette, mood]
Use Case: ad creative for [audience]
Text: "EXACT HEADLINE" in [font style], [color], [position]
      "exact subhead" in [font style], [color], [position]
Constraints: no extra text, no duplicate text, no watermarks, no unrelated logos
Quality: high
```

Extracted rules inside block: NONE

## 4ea1c7994789bf0d — image/references/gpt-image.md:170-170 (heading)

### Infographic / Diagram

Extracted rules inside block: NONE

## b47144522ac29931 — image/references/gpt-image.md:171-180 (code)

```
Title: "[TITLE]"
Content flow: [step 1] → [step 2] → [step 3]
Visual format: [layout type — flowchart, pyramid, isometric, etc.]
Use Case: educational infographic for [audience]
Constraints: readable labels at all sizes, clear hierarchy, no clutter,
  no decorative noise, ample whitespace
Quality: high
Size: 1536×1024
```

Extracted rules inside block: NONE
