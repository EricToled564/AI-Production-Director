# Source coverage review 203/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 91ee027d1e428bcc — visual-prompt-forge/SKILL.md:290-291 (paragraph)

It exists because a careful authoring pass over a seven-shot storyboard drifted on these
anchors in all seven shots while every other validator stayed green.

Extracted rules inside block: NONE

## a7c02f29e43b5a7e — visual-prompt-forge/SKILL.md:293-293 (heading)

### Rule 4. Adapters are the source of truth on syntax

Extracted rules inside block: NONE

## 4846e894d173d800 — visual-prompt-forge/SKILL.md:295-295 (paragraph)

If your training data says Midjourney uses `--style 4a` and the adapter file says `--style raw`, the adapter wins. Image-gen syntax changes monthly. The adapter is current; your training is not.

Extracted rules inside block: NONE

## 0a2c1e8c24a6ad65 — visual-prompt-forge/SKILL.md:297-297 (heading)

### Rule 6. Shot logic before shot poetry

Extracted rules inside block: NONE

## f24909c554b4faaf — visual-prompt-forge/SKILL.md:299-299 (paragraph)

A prompt can be beautifully written and still be impossible to shoot. Every prompt declares, before anything else:

Extracted rules inside block: NONE

## c9f34973dad6d563 — visual-prompt-forge/SKILL.md:301-301 (list_item)

- **Where the body sits in frame.** Which third it occupies. On a piece that composites two eras with a vertical mask, a body sitting on the centre line gets split in half and no amount of post fixes it. This is the single most expensive failure in the kit, and it is invisible until the mask goes on.

Extracted rules inside block: NONE

## 89b014401c5f7527 — visual-prompt-forge/SKILL.md:302-302 (list_item)

- **The point of view.** Profile, frontal, side, rear. "A man walking" is not a shot.

Extracted rules inside block: NONE

## b7ffee341584820e — visual-prompt-forge/SKILL.md:303-303 (list_item)

- **The direction of travel.** Left to right, right to left, toward camera. Without it the generator picks, and consecutive shots stop matching.

Extracted rules inside block: NONE

## 5a70e445c8816374 — visual-prompt-forge/SKILL.md:304-304 (list_item)

- **Nothing that contradicts the camera.** A subject who walks away from camera cannot also keep the same size in frame.

Extracted rules inside block: NONE

## b9df7f51bf69ff62 — visual-prompt-forge/SKILL.md:305-305 (list_item)

- **Handedness in any two-person contact.** If one raises a hand, name which one, or you get two right hands meeting.

Extracted rules inside block: NONE

## 965097dedf59e9a1 — visual-prompt-forge/SKILL.md:306-306 (list_item)

- **No brand marks.** Logos and lettering are composited in post. Generators deform them.

Extracted rules inside block: NONE

## ed8525a582dbfa8e — visual-prompt-forge/SKILL.md:308-308 (heading)

### Rule 5. Prompts must be reproducible

Extracted rules inside block: NONE

## e2986084f1879ae9 — visual-prompt-forge/SKILL.md:310-310 (paragraph)

Every prompt is composed from the same inputs the same way. If two consecutive runs produce different prompts for the same shot, the skill is broken. Determinism is the whole point.

Extracted rules inside block: NONE

## d62ff39b9bd9fdae — visual-prompt-forge/SKILL.md:312-312 (heading)

## Reference files

Extracted rules inside block: NONE

## 7e6fc9ad19b3e874 — visual-prompt-forge/SKILL.md:314-314 (list_item)

- `references/prompt-anatomy.md`, the five-layer model in depth

Extracted rules inside block: NONE

## e2b575838ed8fe72 — visual-prompt-forge/SKILL.md:315-315 (list_item)

- `references/consistency-locks.md`, how series_lock prevents shot drift

Extracted rules inside block: NONE

## 0780f33152250bbf — visual-prompt-forge/SKILL.md:316-316 (list_item)

- `references/failure-modes.md`, common image-gen failures and their prompt-side fixes

Extracted rules inside block: NONE

## 1819995ddbb9ec8d — visual-prompt-forge/SKILL.md:318-318 (heading)

## Adapters

Extracted rules inside block: NONE

## 65f9286e271f90e7 — visual-prompt-forge/SKILL.md:320-320 (paragraph)

One file per generator. Read these on demand, only for the generators being targeted.

Extracted rules inside block: NONE

## 6d45012f02fa1e74 — visual-prompt-forge/SKILL.md:322-322 (table_row)

| File | Generator | Strength |

Extracted rules inside block: NONE

## bec3fb13ab78a64b — visual-prompt-forge/SKILL.md:324-324 (table_row)

| `adapters/midjourney.md` | Midjourney v7+ | Aesthetic, cinematic |

Extracted rules inside block: NONE

## 6e27c44d317fc4ea — visual-prompt-forge/SKILL.md:325-325 (table_row)

| `adapters/flux.md` | Flux 2 / Flux 1.1 Pro | Photorealism |

Extracted rules inside block: NONE

## 39ddb37d997f18ba — visual-prompt-forge/SKILL.md:326-326 (table_row)

| `adapters/ideogram.md` | Ideogram v3 | Text in image (override only) |

Extracted rules inside block: NONE

## 2c29a57fa99720a4 — visual-prompt-forge/SKILL.md:327-327 (table_row)

| `adapters/gpt-image.md` | GPT Image 1.5 / 2 | Prompt accuracy, spatial reasoning |

Extracted rules inside block: NONE

## f2ee335e88734998 — visual-prompt-forge/SKILL.md:328-328 (table_row)

| `adapters/nano-banana.md` | Gemini 2.5 Flash Image | Edit fidelity, inpainting |

Extracted rules inside block: NONE

## dee9e889f9addd90 — visual-prompt-forge/SKILL.md:329-329 (table_row)

| `adapters/seedream.md` | Seedream 4.5 | High-volume, cost-efficient |

Extracted rules inside block: NONE

## 7f373644e5eb0d6c — visual-prompt-forge/SKILL.md:330-330 (table_row)

| `adapters/kling.md` | Kling 3.0 | Motion video, default (best camera motion per dollar) |

Extracted rules inside block: NONE

## d2acf3208f01c582 — visual-prompt-forge/SKILL.md:331-331 (table_row)

| `adapters/veo.md` | Veo 3 | Motion video, dialogue/lipsync + native audio |

Extracted rules inside block: NONE

## 3efc36896f6970fa — visual-prompt-forge/SKILL.md:332-332 (table_row)

| `adapters/seedance.md` | Seedance 2.0 | Motion video, multi-shot sequences |

Extracted rules inside block: NONE

## 61345690349997cb — visual-prompt-forge/SKILL.md:333-333 (table_row)

| `adapters/hailuo.md` | Hailuo 02 Pro | Motion video, budget iteration |

Extracted rules inside block: NONE
