# Source coverage review 191/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## b60dd3300b4f3808 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:45-45 (list_item)

- never use emojis in body copy

Extracted rules inside block: 8a3af20c94a2

## eea47ddc675b4be0 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:46-46 (list_item)

- never use bullet points in narrative copy

Extracted rules inside block: f71306dddfda

## 0d157d2a14312e65 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:47-47 (list_item)

- never use clip-art or generic icon sets

Extracted rules inside block: 0abada1c8680

## 2057980250148aa7 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:48-48 (list_item)

- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")

Extracted rules inside block: 0874db08f762

## 3ca30ba819fffe5c — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:49-49 (list_item)

- never use exclamation points in headlines

Extracted rules inside block: a698f9a12031

## 1b093745ab8bf8dd — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:50-50 (list_item)

- never default to dark mode, light mode hybrid is the brand

Extracted rules inside block: 8ecff3da9d7b

## ad63254ff22c73d3 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:51-51 (list_item)

- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

Extracted rules inside block: 4196946138e1

## 222d87797c13f469 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:53-53 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## afdb6d5c8c8a0b43 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:55-55 (list_item)

- 9:16, primary for short-form social

Extracted rules inside block: NONE

## 4e6379cd451a33a6 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:56-56 (list_item)

- 16:9, long-form, hero films, web embeds

Extracted rules inside block: NONE

## 16dc8cdee0b81a90 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:57-57 (list_item)

- 1:1, feed posts, podcast covers

Extracted rules inside block: NONE

## 54122ae86aff556d — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:58-58 (list_item)

- 4:5. Instagram feed alternative

Extracted rules inside block: NONE

## 9317ebac3d045fac — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:60-60 (heading)

## Color grade direction

Extracted rules inside block: NONE

## 36b69323ec72fdf7 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:62-62 (paragraph)

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

Extracted rules inside block: 65fd20bb5eb4

## 1f0037f088c5e86a — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:64-64 (heading)

## Motion language

Extracted rules inside block: NONE

## 88ab0bea3196e286 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:66-66 (paragraph)

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

Extracted rules inside block: 9397132aa9d5

## 63a2de9a4b5b136c — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:68-68 (heading)

## Voice rules

Extracted rules inside block: NONE

## 8c0fc8cf64666daa — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:70-70 (list_item)

- no em dashes

Extracted rules inside block: NONE

## 0bfe203cbbab5ccd — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:71-71 (list_item)

- no emojis in body copy

Extracted rules inside block: NONE

## aa9a258e3e25b1e6 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:72-72 (list_item)

- no exclamation points in headlines

Extracted rules inside block: NONE

## f105c44259f81a9b — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:73-73 (list_item)

- no hype words

Extracted rules inside block: NONE

## 0f3d890c9f10a88c — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:74-74 (list_item)

- prefer specific numbers over vague claims

Extracted rules inside block: 7c71fe0f7996

## 8e4154f2c2c92fc7 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:75-75 (list_item)

- prefer present-tense over future-tense

Extracted rules inside block: b88369a23709

## 5771c466f2a7809c — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:76-76 (list_item)

- prefer "operator" over "creator", "infrastructure" over "agency"

Extracted rules inside block: 54830ed3fdcd

## 2ea98ec0ff4a4fa7 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:80-82 (paragraph)

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0

Extracted rules inside block: NONE

## 9a5cfee4a05f08ef — visual-asset-critic/references/critique-rubric.md:1-1 (heading)

# Critique Rubric

Extracted rules inside block: NONE

## 9fa399c1c124716b — visual-asset-critic/references/critique-rubric.md:3-3 (paragraph)

The structured layer-by-layer pass. Use this as the checklist when reviewing a generated image.

Extracted rules inside block: 5a47e2a4eab4

## 5adeffec216d1495 — visual-asset-critic/references/critique-rubric.md:5-5 (heading)

## Layer 1. Brand Lock check

Extracted rules inside block: NONE

## 88ba03c7e46f43de — visual-asset-critic/references/critique-rubric.md:7-7 (table_row)

| Check | Pass | Soft fail | Hard fail |

Extracted rules inside block: NONE

## a353112f8686bd01 — visual-asset-critic/references/critique-rubric.md:9-9 (table_row)

| Palette | Image colors come from brand-lock palette | Colors close but slightly off | Colors not in palette at all |

Extracted rules inside block: NONE
