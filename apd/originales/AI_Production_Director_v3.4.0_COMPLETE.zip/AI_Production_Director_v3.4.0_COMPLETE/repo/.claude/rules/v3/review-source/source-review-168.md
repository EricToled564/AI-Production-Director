# Source coverage review 168/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## a467cf7e2cdb3156 — video/references/role-modes.md:151-151 (paragraph)

A full scene usually moves. Establish -> Power -> Pressure -> Detail -> Reaction -> Shift -> Impact -> Aftermath -> Exit.

Extracted rules inside block: NONE

## 03b20390972ab9a4 — video/references/role-modes.md:153-153 (paragraph)

A montage sequence can compress or loop. Use function tags to keep the structure readable even at high speed.

Extracted rules inside block: 69adec2b8bb4

## ecddd273d4b9ecb2 — video/references/role-modes.md:155-155 (paragraph)

Each tag is also a question the shot must answer. Establish. Where. Power. Who commands. Pressure. What pushes. Detail. What to notice. Reaction. What it cost. Shift. What changed inside. Impact. The moment. Aftermath. The residue. Exit. The image carried out.

Extracted rules inside block: 6b561c99afcf

## 260b8fcfd8b43329 — video/references/role-modes.md:159-159 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 06a93793f887b462 — video/references/seedance-25.md:1-1 (heading)

# Seedance 2.5 — production reference (ByteDance, official guides of 2026-07-31)

Extracted rules inside block: NONE

## a0949a4a4d7b9281 — video/references/seedance-25.md:3-3 (paragraph)

Read `seedance.md` first for the family basics (Details Law, multi-shot syntax, 11-block skeleton). This file covers what 2.5 adds: the official prompt formulas, the 50-slot reference system, video editing, extension, ultra-long mode, and the blockout pipeline. Sources: the official Dreamina/Jimeng User Guide and Prompt Guide (both published 2026-07-31), verified against practitioner tests from the first launch week.

Extracted rules inside block: NONE

## 4686c26ebf7a4aff — video/references/seedance-25.md:5-5 (heading)

## Contents

Extracted rules inside block: NONE

## 55de66622454c98e — video/references/seedance-25.md:7-7 (list_item)

1. What 2.5 changes

Extracted rules inside block: 166a69462a58

## d9a7c9e4e47e8c3e — video/references/seedance-25.md:8-8 (list_item)

2. Specs and hard limits

Extracted rules inside block: 1375f5e31741

## 49259d99f291b2c6 — video/references/seedance-25.md:9-9 (list_item)

3. Official prompt formula

Extracted rules inside block: 7766baadcba7

## 8075fdfe8d5fe276 — video/references/seedance-25.md:10-10 (list_item)

4. Syntax markers for audio, dialogue and text

Extracted rules inside block: e3e911676c0f

## c828fea5ab8719e8 — video/references/seedance-25.md:11-11 (list_item)

5. Reference discipline (the 50-slot system)

Extracted rules inside block: 25322d381c24

## 4762eab5a4eaa19e — video/references/seedance-25.md:12-12 (list_item)

6. The 30-second structure: stages and end states

Extracted rules inside block: b5c4d7ec8af4

## 64917b2dd1516c3a — video/references/seedance-25.md:13-13 (list_item)

7. The anti-collapse skeleton (3 modules)

Extracted rules inside block: 7ffca59db332

## eddc419d51d8730b — video/references/seedance-25.md:14-14 (list_item)

8. Realistic human formula (anti-AI-face)

Extracted rules inside block: a04a00c5249a

## d24295e7ab467a8a — video/references/seedance-25.md:15-15 (list_item)

9. Camera language

Extracted rules inside block: a93b345fe16b

## 99bd8022ba860929 — video/references/seedance-25.md:16-16 (list_item)

10. Transitions

Extracted rules inside block: NONE

## b4ec469d70a668d4 — video/references/seedance-25.md:17-17 (list_item)

11. Physics through consequences and triggers

Extracted rules inside block: 0feb4e258143

## 1869833ca1b862de — video/references/seedance-25.md:18-18 (list_item)

12. Video editing (partial re-render)

Extracted rules inside block: c118d8f2cc6a

## 6c5abf511396c2eb — video/references/seedance-25.md:19-19 (list_item)

13. Video extension

Extracted rules inside block: 250a667b0435

## 0c534e09b2d16b5e — video/references/seedance-25.md:20-20 (list_item)

14. Ultra Long mode (30-180s)

Extracted rules inside block: 562081cb3461

## 551f8d918fbfe299 — video/references/seedance-25.md:21-21 (list_item)

15. Blockout and green screen

Extracted rules inside block: 4d89a6d1e243

## 48a49c9b6f68036e — video/references/seedance-25.md:22-22 (list_item)

16. Storyboard grids and keyframes

Extracted rules inside block: 26058ec10383

## 3bd9cf85d6cac8a6 — video/references/seedance-25.md:23-23 (list_item)

17. Failure modes and fixes

Extracted rules inside block: 06500cb07135

## e89e8cb0fa3f4470 — video/references/seedance-25.md:24-24 (list_item)

18. Economics and model choice

Extracted rules inside block: 029e705aa73d

## 96df0b3714724c89 — video/references/seedance-25.md:25-25 (list_item)

19. Worked examples (official, verbatim)

Extracted rules inside block: 22562cd88d6a

## 9c134ca7e03e791a — video/references/seedance-25.md:29-29 (heading)

## 1. What 2.5 changes

Extracted rules inside block: NONE

## ce6f9acbb255be66 — video/references/seedance-25.md:31-31 (list_item)

- **30-second native single-pass clip.** One generation, one continuous arc, no stitching. Extension pushes it to 60s; a separate Ultra Long mode goes to 180s (see sections 13-14).

Extracted rules inside block: NONE

## 0370a3baac4e2cdd — video/references/seedance-25.md:32-32 (list_item)

- **50 multimodal references** (30 images + 10 videos + 10 audio) with per-asset role binding. The model understands which asset is responsible for character, scene, prop, camera move, or rhythm — if you tell it.

Extracted rules inside block: NONE

## ffc281de4cbd543c — video/references/seedance-25.md:33-33 (list_item)

- **Realistic humans are a headline feature**, not a liability: real skin pores, restrained micro-acting, multilingual lip-sync in 11 languages. The 2.0-era face caution does not apply.

Extracted rules inside block: NONE
