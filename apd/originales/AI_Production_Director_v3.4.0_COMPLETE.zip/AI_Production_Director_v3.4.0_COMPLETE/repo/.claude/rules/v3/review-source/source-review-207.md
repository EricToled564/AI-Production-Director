# Source coverage review 207/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 10a47f4b6fa275fd — visual-prompt-forge/adapters/gpt-image.md:23-23 (table_row)

| Parameter | Default for storyboard work | Notes |

Extracted rules inside block: NONE

## 28fc471b4b1ae4b4 — visual-prompt-forge/adapters/gpt-image.md:25-25 (table_row)

| `size` | `1024x1792` for 9:16, `1792x1024` for 16:9, `1024x1024` for 1:1 | Native aspect ratios |

Extracted rules inside block: NONE

## 192c0de09e7da109 — visual-prompt-forge/adapters/gpt-image.md:26-26 (table_row)

| `quality` | `high` for hero shots, `medium` for series | |

Extracted rules inside block: NONE

## ee575f8865c23eab — visual-prompt-forge/adapters/gpt-image.md:27-27 (table_row)

| `style` | `natural` for photoreal, `vivid` for stylized | |

Extracted rules inside block: NONE

## 55faf3b0dd2acb20 — visual-prompt-forge/adapters/gpt-image.md:28-28 (table_row)

| `model` | `gpt-image-1.5` (or `gpt-image-2` if available) | |

Extracted rules inside block: NONE

## 36f2b82abb3e8558 — visual-prompt-forge/adapters/gpt-image.md:30-30 (paragraph)

Document in comment:

Extracted rules inside block: NONE

## 6c0377a017e4eb95 — visual-prompt-forge/adapters/gpt-image.md:31-34 (code)

```
# shot_01, params: size=1024x1792, quality=high, style=natural, model=gpt-image-1.5
{prompt}
```

Extracted rules inside block: NONE

## 286a3f7e93f90709 — visual-prompt-forge/adapters/gpt-image.md:36-36 (heading)

## Length

Extracted rules inside block: NONE

## 87e1cfa80545bb82 — visual-prompt-forge/adapters/gpt-image.md:38-38 (paragraph)

GPT Image handles **150–300 words** comfortably. Longer than other generators. Use the headroom for explicit spatial descriptions.

Extracted rules inside block: 3c424545135a

## 771c557a4136d219 — visual-prompt-forge/adapters/gpt-image.md:40-40 (heading)

## Spatial language strength

Extracted rules inside block: NONE

## 9771efa76ff2edfa — visual-prompt-forge/adapters/gpt-image.md:42-42 (paragraph)

GPT Image's distinctive capability, describe spatial relationships explicitly:

Extracted rules inside block: NONE

## 25c6f7568636ed58 — visual-prompt-forge/adapters/gpt-image.md:44-44 (list_item)

- "The founder is positioned in the left third of the frame, leaving the right two-thirds open."

Extracted rules inside block: NONE

## e15070e4f36211cf — visual-prompt-forge/adapters/gpt-image.md:45-45 (list_item)

- "A laptop sits on the desk in the foreground, a window with afternoon light is visible in the background."

Extracted rules inside block: NONE

## 2ec33b86cda3f277 — visual-prompt-forge/adapters/gpt-image.md:46-46 (list_item)

- "The subject's shoulders are angled 30 degrees toward the camera, face turned to look at the off-frame light source."

Extracted rules inside block: 9aa187a75eae

## e79028f77bcf632d — visual-prompt-forge/adapters/gpt-image.md:48-48 (paragraph)

Use this when the shot's composition is load-bearing.

Extracted rules inside block: 00c605e050f0

## 169bb52485d4f053 — visual-prompt-forge/adapters/gpt-image.md:50-50 (heading)

## Composition pattern

Extracted rules inside block: NONE

## 62a4cd43ffcafc74 — visual-prompt-forge/adapters/gpt-image.md:52-58 (code)

```
{Subject paragraph: who is in the frame, what they're doing, where they are positioned in the composition. Reference series_lock character anchor verbatim.}

{Environment paragraph: setting, props, contextual elements. Pull from series_lock environment.}

{Technical paragraph: lighting from series_lock, photographic spec, color grade from brand_lock, mood. Close with "natural skin texture, no AI rendering artifacts" if photoreal.}
```

Extracted rules inside block: NONE

## ffa6c2e838dbb3fd — visual-prompt-forge/adapters/gpt-image.md:60-60 (heading)

## Example

Extracted rules inside block: NONE

## ce211a455eb07a5f — visual-prompt-forge/adapters/gpt-image.md:62-62 (paragraph)

**Same shot data as previous examples.**

Extracted rules inside block: NONE

## 7f8ff7bbe727b655 — visual-prompt-forge/adapters/gpt-image.md:64-64 (paragraph)

**Output prompt:**

Extracted rules inside block: NONE

## 171583cf5fa884b5 — visual-prompt-forge/adapters/gpt-image.md:65-71 (code)

```
A founder in his mid-thirties with salt-and-pepper hair, wearing a navy crewneck sweater, leans forward at his laptop. He is positioned in the left third of the frame, his face turned partially toward the window light off-camera left. The composition deliberately reserves the right two-thirds of the frame as negative space.

The setting is a minimalist home office. White walls, an oak desk in the immediate foreground, the laptop screen partially visible. A large window is implied off-frame to the left, source of the natural light. No clutter, no decorative objects.

Soft natural side-light from the window left, warm afternoon golden hour temperature, gentle shadow rolloff. Shot on a 50mm prime lens at f/2.0, shallow depth of field with the background softly out of focus. Warm filmic color grade with muted teal shadows. The mood is calm and considered, operator energy, not creator energy. Natural skin texture, no AI rendering artifacts.
```

Extracted rules inside block: NONE

## 996841c07bb19c70 — visual-prompt-forge/adapters/gpt-image.md:73-73 (heading)

## Text rendering

Extracted rules inside block: NONE

## 9225f7b4e2d17718 — visual-prompt-forge/adapters/gpt-image.md:75-75 (paragraph)

GPT Image handles text-in-image at roughly 95% accuracy, second only to Ideogram. When text is required:

Extracted rules inside block: d728c6c12b29

## fa96265ca893be5a — visual-prompt-forge/adapters/gpt-image.md:77-77 (list_item)

- Put the exact text in straight double-quotes within the prompt

Extracted rules inside block: NONE

## 6274a9f9e725de6e — visual-prompt-forge/adapters/gpt-image.md:78-78 (list_item)

- Specify position explicitly ("centered in the lower third")

Extracted rules inside block: NONE

## 8b25df7818f0cbce — visual-prompt-forge/adapters/gpt-image.md:79-79 (list_item)

- Specify approximate typeface character ("bold sans-serif", "elegant serif")

Extracted rules inside block: NONE

## a53dafe4a25e97a3 — visual-prompt-forge/adapters/gpt-image.md:80-80 (list_item)

- Limit to one text element per prompt for reliability

Extracted rules inside block: NONE

## 1a11a4ee1302efa5 — visual-prompt-forge/adapters/gpt-image.md:82-82 (paragraph)

Default for storyboard work is still composited text, keep the override flag pattern from the Ideogram adapter.

Extracted rules inside block: NONE

## d1d61d4b9b07180b — visual-prompt-forge/adapters/gpt-image.md:84-84 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 5231cb84c60ad30f — visual-prompt-forge/adapters/gpt-image.md:86-86 (list_item)

- **Don't write Midjourney-style comma stacks**. GPT Image parses them as a list of disconnected concepts

Extracted rules inside block: 29b7759c9d19
