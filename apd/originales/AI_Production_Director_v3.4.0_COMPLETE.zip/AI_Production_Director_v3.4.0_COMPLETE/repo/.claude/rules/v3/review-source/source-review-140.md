# Source coverage review 140/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0d9c5bd988a7c945 — video/references/dramaturgy.md:41-41 (paragraph)

Before writing a prompt, name each of these in one sentence. If you cannot, the scene is not ready.

Extracted rules inside block: NONE

## 04dafb114e98ac69 — video/references/dramaturgy.md:43-43 (heading)

## 2. Second law. Details intensify emotion. Laziness kills the prompt.

Extracted rules inside block: NONE

## 9eba16e2c125e5ee — video/references/dramaturgy.md:45-45 (paragraph)

The scene formula tells you **what a scene is**. The Details Law tells you **how every shot must be written**. Skip it and even a perfect dramaturgical structure produces mush on screen.

Extracted rules inside block: cbf2a756fd6e

## 93cafb54b386a461 — video/references/dramaturgy.md:47-47 (list_item)

> Every shot owns three concrete physical details: one environmental pressure, one physical micro-action, one sound or visual motif anchor.

Extracted rules inside block: NONE

## b96a291f65591f63 — video/references/dramaturgy.md:49-49 (heading)

### The three-detail rule

Extracted rules inside block: NONE

## a0bdd128b30df794 — video/references/dramaturgy.md:51-51 (paragraph)

For each shot in the storyboard or prompt, before it is sent, the writer commits to:

Extracted rules inside block: NONE

## 84d65724d1724a20 — video/references/dramaturgy.md:53-53 (list_item)

1. **Environmental pressure.** A physical fact about the space that carries the emotion. Cold refrigerator light. Wet asphalt. Flickering ceiling tube. Steam from the kettle. Rain on one specific windowpane. A buzzing AC unit. Tight corridor walls. Mirror reflection. (See §9 — Environment plays.)

Extracted rules inside block: 7d3f54d67069

## 7fe3a579bc65b387 — video/references/dramaturgy.md:54-54 (list_item)

2. **Physical micro-action on the body.** The emotion translated into the actor's body. Jaw locks. Knuckles whiten. Lips press flat. Eyes drop a quarter-inch. He swallows hard. Fingers curl against the doorframe. The actor's body is the only place where feelings render — names of feelings do not.

Extracted rules inside block: 0e88ae42f887

## 1b4ab1a1e56e9745 — video/references/dramaturgy.md:55-55 (list_item)

3. **Sound anchor or visual motif.** A recurring perceptual hook tied to the spine of the piece. Stomach growl repeated three times. Reflection in dark glass on every transition. The same musical sting at every Crack beat. The clock's second hand. Footsteps in an empty corridor.

Extracted rules inside block: e96d487a1ca3

## 63717f07a452eaf7 — video/references/dramaturgy.md:57-57 (paragraph)

A shot with zero of these is filler. A shot with one is thin. Strong shots carry all three. The writer's job is to do this work — the model cannot infer it.

Extracted rules inside block: NONE

## a813b2bba83bcdad — video/references/dramaturgy.md:59-59 (heading)

### What is banned

Extracted rules inside block: NONE

## 6142672a6ea2fada — video/references/dramaturgy.md:61-61 (paragraph)

Words that mark a writer being lazy. Each one is a placeholder for absent detail.

Extracted rules inside block: NONE

## e78c5fd86a88bf13 — video/references/dramaturgy.md:63-63 (list_item)

- "cinematic", "professional", "high quality", "masterpiece", "stunning", "epic", "amazing"

Extracted rules inside block: NONE

## 2e7c91616aba1254 — video/references/dramaturgy.md:64-64 (list_item)

- "beautiful lighting", "dynamic camera", "intense moment", "powerful scene"

Extracted rules inside block: NONE

## 6c86645f6c672065 — video/references/dramaturgy.md:65-65 (list_item)

- "he is sad", "she is angry", "he is afraid" — emotions named without a body

Extracted rules inside block: NONE

## 9e39d1e33c4d5e5e — video/references/dramaturgy.md:67-67 (paragraph)

Replace each with concrete physical facts. If a writer cannot do that, the scene is not yet thought through.

Extracted rules inside block: NONE

## 233a3a7d3eb4122b — video/references/dramaturgy.md:69-69 (heading)

### How details map to dramaturgy

Extracted rules inside block: NONE

## 38308fa4f4b78adf — video/references/dramaturgy.md:71-71 (paragraph)

Each layer of dramaturgy has a default detail register:

Extracted rules inside block: NONE

## f111a67b1f402db9 — video/references/dramaturgy.md:73-73 (list_item)

- Scene formula → environmental pressure (the geometry and atmosphere of the obstacle).

Extracted rules inside block: NONE

## 601c7f8dd1682be2 — video/references/dramaturgy.md:74-74 (list_item)

- Three-jobs rule → physical micro-action (the body shifts when emotion / action / pressure shifts).

Extracted rules inside block: NONE

## 09d82f7ef6ed92aa — video/references/dramaturgy.md:75-75 (list_item)

- Five anchors → sound and visual motif (the motif is the anchor, the final image carries the motif).

Extracted rules inside block: NONE

## 6d7d5169d2999430 — video/references/dramaturgy.md:77-77 (paragraph)

If a shot's detail set does not match its dramaturgical function, the function will not land on screen.

Extracted rules inside block: NONE

## 1d24053289ee1955 — video/references/dramaturgy.md:79-79 (heading)

## 3. The three-jobs rule

Extracted rules inside block: NONE

## ddcfdc3c2e726491 — video/references/dramaturgy.md:81-81 (paragraph)

Every shot must do at least one of three things. If it does none, delete it.

Extracted rules inside block: 3ba97ba6f534

## fbf12be0c033fe50 — video/references/dramaturgy.md:83-83 (list_item)

- Change emotion (in hero, viewer, or the dynamic between characters).

Extracted rules inside block: NONE

## 5071ba9da1f81a66 — video/references/dramaturgy.md:84-84 (list_item)

- Advance action (new physical event, new information, new position).

Extracted rules inside block: NONE

## 2b536c3d5a66b230 — video/references/dramaturgy.md:85-85 (list_item)

- Increase pressure (stakes rise, clock ticks, space tightens, witness appears).

Extracted rules inside block: NONE

## 17b84abf7ac065f1 — video/references/dramaturgy.md:87-87 (paragraph)

"Beautiful establishing shot" is not a job. "Beautiful hero shot of product" is not a job. Either the frame works for one of these three, or it is a fantik (wrapper without candy).

Extracted rules inside block: NONE

## 3de28862c8955099 — video/references/dramaturgy.md:89-89 (heading)

## 4. Walter Murch Rule of Six

Extracted rules inside block: NONE

## 4cd4d3b5a4b0ce03 — video/references/dramaturgy.md:91-91 (paragraph)

From the editor of Apocalypse Now, The Godfather Part II, and The English Patient. The priority order when deciding where to cut. Each item is weighted heavier than the sum of everything below it.

Extracted rules inside block: NONE
