# Source coverage review 85/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 1b5bf4fa980fd14e — screenwriter/SKILL.md:225-225 (list_item)

- Development, obstacles, rising tension

Extracted rules inside block: NONE

## d0b877b34bd8ca9a — screenwriter/SKILL.md:226-226 (list_item)

- Midpoint twist or escalation

Extracted rules inside block: NONE

## 080273a97ca0a207 — screenwriter/SKILL.md:228-228 (paragraph)

**Act 3 - Resolution (20-25%):** 2-3 scenes

Extracted rules inside block: NONE

## 8d2d5f6ffa99642a — screenwriter/SKILL.md:229-229 (list_item)

- Climax and resolution

Extracted rules inside block: NONE

## fd6fd9b8190b5480 — screenwriter/SKILL.md:230-230 (list_item)

- Emotional payoff

Extracted rules inside block: NONE

## 8a9a6757f265688e — screenwriter/SKILL.md:232-232 (heading)

### Pacing Tips

Extracted rules inside block: NONE

## 9a0cd8a912f5f83a — screenwriter/SKILL.md:233-233 (list_item)

- **Open strong:** Hook audience in first 10-15 seconds

Extracted rules inside block: NONE

## a5be0b1e93d443f3 — screenwriter/SKILL.md:234-234 (list_item)

- **Visual variety:** Alternate between wide/close, action/stillness

Extracted rules inside block: NONE

## 50672cc8216f65a7 — screenwriter/SKILL.md:235-235 (list_item)

- **Emotional beats:** Each scene should shift emotional state

Extracted rules inside block: 9dca3c7f4308

## f664994d6b80be7b — screenwriter/SKILL.md:236-236 (list_item)

- **Build tension:** Escalate stakes scene-by-scene

Extracted rules inside block: NONE

## 6d7c0a0e56e2f115 — screenwriter/SKILL.md:237-237 (list_item)

- **Satisfying end:** Clear resolution, even if bittersweet

Extracted rules inside block: NONE

## d3f3742637e6178a — screenwriter/SKILL.md:241-241 (heading)

## Best Practices

Extracted rules inside block: NONE

## 972e7b3078a98e31 — screenwriter/SKILL.md:243-243 (heading)

### For Pipeline Integration

Extracted rules inside block: NONE

## 3287bd72814a9085 — screenwriter/SKILL.md:244-244 (list_item)

- **Consistent naming:** Use same character names throughout

Extracted rules inside block: 647cb669873f

## d92a8f46430c518a — screenwriter/SKILL.md:245-245 (list_item)

- **Rich visuals:** Every scene needs 3-5 key_visuals for image generation

Extracted rules inside block: NONE

## 3477fc30d9edaeb3 — screenwriter/SKILL.md:246-246 (list_item)

- **Parseable format:** Maintain strict XML structure

Extracted rules inside block: NONE

## 6e9a71fbd19f69df — screenwriter/SKILL.md:247-247 (list_item)

- **Duration estimates:** Help pipeline plan total video length

Extracted rules inside block: NONE

## e18ad9563d2450cc — screenwriter/SKILL.md:249-249 (heading)

### For Quality Output

Extracted rules inside block: NONE

## ca52a82ebe3eecf3 — screenwriter/SKILL.md:250-250 (list_item)

- **Visual storytelling:** Show emotions through actions, not dialogue

Extracted rules inside block: NONE

## 57517e7c5c6b1fc2 — screenwriter/SKILL.md:251-251 (list_item)

- **Specific details:** "weathered chrome" beats "old metal"

Extracted rules inside block: NONE

## 66f01752390e4a54 — screenwriter/SKILL.md:252-252 (list_item)

- **Atmospheric writing:** Set mood through environment

Extracted rules inside block: NONE

## 0a49054d3a4a39eb — screenwriter/SKILL.md:253-253 (list_item)

- **Lean prose:** Each word should serve the image

Extracted rules inside block: 21ed652cfe43

## 658d0acc9497bccb — screenwriter/SKILL.md:255-255 (heading)

### Common Pitfalls to Avoid

Extracted rules inside block: NONE

## 162c3bacc67be676 — screenwriter/SKILL.md:256-256 (list_item)

- ❌ **Vague descriptions:** "A person walks" → ✅ "A weathered woman in her 50s trudges through snow"

Extracted rules inside block: 64d0e9eb7e12

## f7523f270ab8b683 — screenwriter/SKILL.md:257-257 (list_item)

- ❌ **Telling emotions:** "She feels sad" → ✅ "Tears streak her dusty cheeks"

Extracted rules inside block: a16943caea6d

## 19e8a275f32d6bce — screenwriter/SKILL.md:258-258 (list_item)

- ❌ **Camera directions:** "CLOSE UP ON" → ✅ "The crack in the glass spreads"

Extracted rules inside block: 18c48351d07b

## fe442e3ba61b7732 — screenwriter/SKILL.md:259-259 (list_item)

- ❌ **Over-dialogue:** Short films need visual storytelling

Extracted rules inside block: 9780d36aefca

## 1840cff6e94bbc85 — screenwriter/SKILL.md:260-260 (list_item)

- ❌ **Inconsistent character names:** Stick to ONE name per character

Extracted rules inside block: dc9f652df4b9

## acfdd2b15d7308cf — screenwriter/SKILL.md:264-264 (heading)

## Additional Resources

Extracted rules inside block: NONE

## acac7e72806db89b — screenwriter/SKILL.md:266-266 (heading)

### Pipeline Integration Guide

Extracted rules inside block: NONE
