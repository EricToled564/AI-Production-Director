# Source coverage review 173/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 31b64c0a98743f36 — video/references/seedance-25.md:299-299 (list_item)

- Blender/Maya plugins ("Clay Renderer" / 白模渲染上传器) render the blockout and upload straight to Jimeng as the reference video. Blender ≥3.6 works; no C4D/3ds Max. Color-coding blockout objects is unreliable — disambiguate primitives via prompt text, not material colors.

Extracted rules inside block: NONE

## 9bf977791181ec71 — video/references/seedance-25.md:300-300 (list_item)

- No 3D package? Xiaoyunque's 3D director stage reconstructs a blockout from a concept image, offers action/camera/prop libraries, and lets you **drag-draw the camera path in the viewport**, then renders the previz clip for you.

Extracted rules inside block: NONE

## eec7de01b5ad5417 — video/references/seedance-25.md:301-301 (list_item)

- A **camera-path diagram works as an image reference** too: supply a top-down route sketch as @Image N and write "follow the camera route in @Image N".

Extracted rules inside block: NONE

## f4f17e03f43ef5ed — video/references/seedance-25.md:302-302 (list_item)

- **Green screen, both directions**: upload green-screen footage + scene refs ("composite the person naturally into the classroom from @Image 2"), or convert an existing video's background *into* green screen for downstream comps ("Change all the white backgrounds into green screen backgrounds. Remove the sound, keep it muted.").

Extracted rules inside block: NONE

## 5ce8b78840c45e34 — video/references/seedance-25.md:304-304 (heading)

## 16. Storyboard grids and keyframes

Extracted rules inside block: NONE

## c8d4c869356d3ad0 — video/references/seedance-25.md:306-306 (list_item)

- **Storyboard grid as input**: one image, ≤15 panels official (practitioners have pushed 50), clean line art, minimal text. Declare the reading order and exclude the style: "@Image 1 provides a 12-panel storyboard grid for shot order and approximate composition. Read it left to right, top to bottom. Do not use the grid's line-art style, text labels, or placeholder characters." Then `Shot 1: ... Shot N: ...`

Extracted rules inside block: 893e2d347a31

## 8c5729fbbf032634 — video/references/seedance-25.md:307-307 (list_item)

- **Multi-keyframe sequences**: "Use @Image 1 through @Image N as keyframes in this order", one key state per image. Independent images align better than a grid. Keyframes control stage order and key states, not exact frames.

Extracted rules inside block: d3b4e6971ed6

## 2c7f3664d0fb0f06 — video/references/seedance-25.md:308-308 (list_item)

- **First + last frame** works inside omni-reference mode — declare each anchor separately ("@Image 1 is the first frame... @Image 2 is the last frame..."), never jointly. Same aspect ratio required.

Extracted rules inside block: c06c27cd2911

## 5bc57aba636eb676 — video/references/seedance-25.md:309-309 (list_item)

- This is where the `image` skill chains in: character sheets and keyframes from `animatic-keyframes.md` become the reference kit.

Extracted rules inside block: NONE

## 75cadf52a3564589 — video/references/seedance-25.md:311-311 (heading)

## 17. Failure modes and fixes

Extracted rules inside block: NONE

## 9f6f06d463efeeb6 — video/references/seedance-25.md:313-313 (heading)

### Twins / face-blending in multi-person scenes

Extracted rules inside block: NONE

## 716c54dd262a5e2e — video/references/seedance-25.md:314-314 (paragraph)

Fix. Per-subject binding (section 5) + explicit differentiation: "Their movements are not synchronized. Clothing colors, hairstyles, and facial features must all be distinct. No identical clones in the background."

Extracted rules inside block: 616be69e8f83

## ea9c6cb91abba378 — video/references/seedance-25.md:316-316 (heading)

### Same character in two states appears at the wrong time

Extracted rules inside block: NONE

## 4f45e20e4063fab9 — video/references/seedance-25.md:317-317 (paragraph)

Pre/post-transformation slots confuse the model. Fix. Bind each state to its time range explicitly; budget re-rolls — this is the flakiest binding in 2.5.

Extracted rules inside block: NONE

## ac98c9b6bab21ab2 — video/references/seedance-25.md:319-319 (heading)

### Random subtitles or unwanted BGM

Extracted rules inside block: NONE

## 00a1241b5dafc2ab — video/references/seedance-25.md:320-320 (paragraph)

Fix. "Pure video, no subtitles, no background music" — reliable in 2.5. Repeat in the global tail.

Extracted rules inside block: NONE

## 50a31a0f6ee54ad4 — video/references/seedance-25.md:322-322 (heading)

### Plastic AI skin

Extracted rules inside block: NONE

## a61f49b2421291fb — video/references/seedance-25.md:323-323 (paragraph)

Fix. "Retaining real fine pores and skin texture" + production language instead of "hyperrealistic 8k".

Extracted rules inside block: NONE

## 546c0dfb9739312a — video/references/seedance-25.md:325-325 (heading)

### Long-context plausibility slips

Extracted rules inside block: NONE

## d017347e13af961a — video/references/seedance-25.md:326-326 (paragraph)

Over 30s the model can place a plausible object in an impossible spot (a freighter on dry concrete). Fix. State the world's hard constraints in the global tail; verify the full timeline before shipping — errors hide in the back half.

Extracted rules inside block: NONE

## eb2778136f201c54 — video/references/seedance-25.md:328-328 (heading)

### The one-take that refuses to stay one take

Extracted rules inside block: NONE

## 41207da1f1f5b97f — video/references/seedance-25.md:329-329 (paragraph)

2.5 errs by commission: it completes more instructions than rivals but may cut freely even when told "one continuous take". Fix. "One continuous shot, no cuts of any kind" + a camera path that never motivates a cut; if montage keeps leaking in, drop to a 10-15s window where one-takes are stable.

Extracted rules inside block: efa731d94000

## eac7e01a44b4e104 — video/references/seedance-25.md:331-331 (heading)

### Edit mode stalls or ignores the instruction

Extracted rules inside block: NONE

## 416371a6770db7c9 — video/references/seedance-25.md:332-332 (paragraph)

Fix. Source ≤20s (slice first); name @Video 1 as "the sole editing master"; one edit target per pass.

Extracted rules inside block: NONE

## c42dc399064d023a — video/references/seedance-25.md:334-334 (heading)

## 18. Economics and model choice

Extracted rules inside block: NONE

## b5ab81bc273d8127 — video/references/seedance-25.md:336-336 (list_item)

- Costs are real: a 30s/720p generation on Jimeng runs ~500-700 credits. Production budgets must assume re-rolls, extensions and segment reshoots — fix with edit/extend/reshoot instead of full regeneration whenever possible. Draft at 480p, finish at 720p.

Extracted rules inside block: dec3743f7bea

## e2384984e54451a1 — video/references/seedance-25.md:337-337 (list_item)

- Versus Minimax H3 (the other frontier model of this launch window): **H3 errs by omission, Seedance 2.5 errs by commission** — H3 delivers a more filmic whole but drops shots from the list; 2.5 executes nearly every instruction but may misuse a reference or break a global constraint. Pick 2.5 for timestamp precision, dense shot choreography, 50-reference kits and the editing/blockout toolchain; pick H3 (or Kling/Veo) when overall cinematic coherence per credit matters more than instruction compliance.

Extracted rules inside block: NONE

## 65bfbc878e68f41f — video/references/seedance-25.md:339-339 (heading)

## 19. Worked examples (official, verbatim)

Extracted rules inside block: NONE

## b11521e22234eb9d — video/references/seedance-25.md:341-341 (heading)

### A. Restrained micro-acting — "Riverside Farewell" (29s one-shot)

Extracted rules inside block: NONE

## 5243642ba3328055 — video/references/seedance-25.md:343-343 (paragraph)

The flagship official example for emotional performance. Abridged; the structure is what to copy:

Extracted rules inside block: NONE
