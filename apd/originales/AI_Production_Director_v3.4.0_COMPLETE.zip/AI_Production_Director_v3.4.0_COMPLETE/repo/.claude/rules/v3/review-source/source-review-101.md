# Source coverage review 101/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## aae1318e73e64336 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:15-15 (table_row)

| Role | Hex | Use |

Extracted rules inside block: 4a31ef7199d8

## cd7d82fd2e74d945 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:17-17 (table_row)

| Background | `#F5F0E8` | Cream, primary canvas |

Extracted rules inside block: NONE

## 56e789dfa38803e4 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:18-18 (table_row)

| Ink | `#2A2A32` | Near-black, primary text and dark elements |

Extracted rules inside block: NONE

## 9e5441d2a21e6cff — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:19-19 (table_row)

| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |

Extracted rules inside block: NONE

## 69530326f36a975e — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:20-20 (table_row)

| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |

Extracted rules inside block: NONE

## 6c86797ecb2675ca — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:21-21 (table_row)

| Muted | `#7A7580` | Secondary text, captions |

Extracted rules inside block: NONE

## c1372a0bac36993d — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:22-22 (table_row)

| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

Extracted rules inside block: NONE

## 284796e56adf948d — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:24-24 (heading)

## Typography

Extracted rules inside block: NONE

## 1141c7365be568c7 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:26-28 (paragraph)

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

Extracted rules inside block: NONE

## cc9ec83c99ab65b2 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:30-30 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## 80e28efaf586cd27 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:32-32 (list_item)

- operator (not creator)

Extracted rules inside block: NONE

## ea122d860727fb0d — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:33-33 (list_item)

- considered (not reactive)

Extracted rules inside block: NONE

## c302bf87e95efec1 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:34-34 (list_item)

- deterministic (not vibes-based)

Extracted rules inside block: NONE

## 3b365064255eed87 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:35-35 (list_item)

- confident (without volume)

Extracted rules inside block: NONE

## 84c43f889e90d873 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:36-36 (list_item)

- defense-grade (not fragile)

Extracted rules inside block: NONE

## e3184ca703271c6b — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:38-38 (heading)

## Never list

Extracted rules inside block: NONE

## 17f1272b343ffcfc — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:40-40 (list_item)

- never use stock photo aesthetic

Extracted rules inside block: 982d5ec72424

## a8da603be847b544 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:41-41 (list_item)

- never use AI uncanny faces

Extracted rules inside block: 569d35d98f04

## 3b5333b0e196d009 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:42-42 (list_item)

- never over-saturate the cream background

Extracted rules inside block: 8d681e58df86

## 51acb947e3c709f6 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:43-43 (list_item)

- never use coral as a flood color (only as accent or signature periods)

Extracted rules inside block: 6bc5ff54b80d

## 133b84a9e53cfa00 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:44-44 (list_item)

- never use em dashes in copy

Extracted rules inside block: 63a6a2e47824

## 662cf8c2465e3346 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:45-45 (list_item)

- never use emojis in body copy

Extracted rules inside block: 5a3fa15bee1f

## 28b65efeedabca4a — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:46-46 (list_item)

- never use bullet points in narrative copy

Extracted rules inside block: f27805b9aea8

## 39b447ca9379d604 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:47-47 (list_item)

- never use clip-art or generic icon sets

Extracted rules inside block: 8d0acf3cef10

## 096b248ec0a378a0 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:48-48 (list_item)

- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")

Extracted rules inside block: 16f1cded5d12

## eb5799d1a498ea9e — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:49-49 (list_item)

- never use exclamation points in headlines

Extracted rules inside block: d26bf6b9faf2

## 4ed443875c244a8a — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:50-50 (list_item)

- never default to dark mode, light mode hybrid is the brand

Extracted rules inside block: 272a136d36c6

## 9fe9e8fb1dc1c208 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:51-51 (list_item)

- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

Extracted rules inside block: 20bab6ba688f

## 35848d00396ad454 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:53-53 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## 5eea048122aab397 — storyboard-architect/examples/30s-pain-proof-promise/brand-lock.snapshot.md:55-55 (list_item)

- 9:16, primary for short-form social

Extracted rules inside block: NONE
