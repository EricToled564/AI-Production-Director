# Source coverage review 126/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 3857037475ee738c — storyboard-html-preview/tools/README.md:172-172 (list_item)

- a frame on disk with no critique for its round, never reviewed at all

Extracted rules inside block: 503664e3011f

## de58430ef3b029b5 — storyboard-html-preview/tools/README.md:173-173 (list_item)

- two critiques for the same shot in the same round, two operators colliding

Extracted rules inside block: NONE

## ca6caefd37098e10 — storyboard-html-preview/tools/README.md:174-174 (list_item)

- rounds that skip a number, or a critique whose `run_id` belongs to another run

Extracted rules inside block: NONE

## 809c5e20769e1b74 — storyboard-html-preview/tools/README.md:176-177 (paragraph)

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

Extracted rules inside block: NONE

## d85f386e1fb0cd6e — storyboard-html-preview/tools/README.md:179-179 (heading)

## Rendering

Extracted rules inside block: NONE

## 2d28221d112d0586 — storyboard-html-preview/tools/README.md:181-181 (heading)

### `shots-to-html.py`

Extracted rules inside block: NONE

## 5ab17bd4bad88dd4 — storyboard-html-preview/tools/README.md:183-183 (paragraph)

Renders an output folder into a single `preview.html`.

Extracted rules inside block: NONE

## 9025e5478454dcce — storyboard-html-preview/tools/README.md:185-191 (code)

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

Extracted rules inside block: NONE

## 2d1cbabdaa448f41 — storyboard-html-preview/tools/README.md:193-196 (paragraph)

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Extracted rules inside block: 7feedf0ca1cb

## dd3d3dd93596983d — storyboard-html-preview/tools/README.md:198-199 (paragraph)

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

Extracted rules inside block: NONE

## 1ab02e502a74b241 — storyboard-html-preview/tools/README.md:201-202 (paragraph)

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

Extracted rules inside block: NONE

## efbfb0d7cec0418b — storyboard-html-preview/tools/README.md:204-205 (paragraph)

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

Extracted rules inside block: NONE

## 5bff01629159f1ef — storyboard-html-preview/tools/README.md:207-207 (heading)

### `copy-prompt.py`

Extracted rules inside block: NONE

## d1030d7f587764e7 — storyboard-html-preview/tools/README.md:209-210 (paragraph)

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

Extracted rules inside block: NONE

## 316c4f27a3aa6023 — storyboard-html-preview/tools/README.md:212-217 (code)

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Extracted rules inside block: NONE

## 9f47b6e28ae37cbf — storyboard-html-preview/tools/README.md:219-222 (paragraph)

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Extracted rules inside block: f48734849f50

## b7b3bffec1b17957 — storyboard-html-preview/tools/README.md:224-224 (paragraph)

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

Extracted rules inside block: NONE

## 5d8353cc19d706ef — storyboard-html-preview/tools/README.md:226-226 (heading)

## Internal modules

Extracted rules inside block: NONE

## b169f0586e0f5f48 — storyboard-html-preview/tools/README.md:228-228 (paragraph)

Not entry points. Imported by the tools above.

Extracted rules inside block: NONE

## 8fcf33261ca3f3a6 — storyboard-html-preview/tools/README.md:230-231 (list_item)

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.

Extracted rules inside block: NONE

## 2e171d22a18ff0e5 — storyboard-html-preview/tools/README.md:232-233 (list_item)

- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

Extracted rules inside block: NONE

## 68b71eeb72016094 — storyboard-html-preview/tools/README.md:235-235 (heading)

## Adding new tools

Extracted rules inside block: NONE

## 366a275274f748c4 — storyboard-html-preview/tools/README.md:237-237 (list_item)

- Make it executable (`chmod +x`)

Extracted rules inside block: NONE

## 614883ed238f9f2f — storyboard-html-preview/tools/README.md:238-238 (list_item)

- Add a usage docstring at the top of the file

Extracted rules inside block: NONE

## 7be636756ab9a5ae — storyboard-html-preview/tools/README.md:239-239 (list_item)

- Give it a `--selftest` that proves the check fires

Extracted rules inside block: NONE

## 5ef2b58ef86808d1 — storyboard-html-preview/tools/README.md:240-240 (list_item)

- Document it in this README

Extracted rules inside block: NONE

## e46b31bfac8c07b4 — storyboard-html-preview/tools/README.md:241-241 (list_item)

- Wire it into `tools/check.sh`, which is what CI calls

Extracted rules inside block: NONE

## bfc8ad56c1b5dafd — storyboard-html-preview/tools/README.md:243-243 (paragraph)

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

Extracted rules inside block: NONE

## e06be566c0a49036 — video/SKILL.md:2-4 (paragraph)

name: video
license: CC-BY-4.0 (attribution required — Serge Shima, github.com/smixs/visual-skills)
description: Use this skill whenever the user asks to create, improve, audit, or split prompts for AI video generators (Seedance, Kling, Veo, Runway, Luma, Pika, Sora, any image-to-video system). The skill also covers storyboards, shot lists, director treatments, dynamic montage, multi-clip story structure, camera direction, lighting, blocking, pacing, character continuity, dialogue, and sound design. Trigger even when the user says things like "придумай сцену для видео", "разбей на склейки", "сделай раскадровку", "улучши промпт для Kling", "переведи сценарий в промпты", "как снять X в AI-видео", or shares a prompt and asks to fix it.

Extracted rules inside block: NONE

## 5642e7dc30056085 — video/SKILL.md:7-7 (heading)

# AI Director, Screenwriter & Editor

Extracted rules inside block: NONE
