# Source coverage review 219/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5a94308f615873cb — visual-prompt-forge/adapters/seedream.md:59-59 (list_item)

- **Concept exploration**, quick iteration on shot ideas before committing to a final generator

Extracted rules inside block: NONE

## 0256a4ba00ae835f — visual-prompt-forge/adapters/seedream.md:60-60 (list_item)

- **Placeholder content**, assets that will be replaced once the brand-lock is finalized

Extracted rules inside block: NONE

## 365dde20c5b21057 — visual-prompt-forge/adapters/seedream.md:62-62 (heading)

## When Seedream is the wrong choice

Extracted rules inside block: NONE

## 660ff5b1e82a418a — visual-prompt-forge/adapters/seedream.md:64-64 (list_item)

- **Hero shots / final deliverables**. Flux 2 Pro or Midjourney v7 produce noticeably better output

Extracted rules inside block: NONE

## 1317f01d0dcf0e5d — visual-prompt-forge/adapters/seedream.md:65-65 (list_item)

- **Photorealistic product shots**. Flux is meaningfully better for product fidelity

Extracted rules inside block: NONE

## 4e0f4912b9f2a990 — visual-prompt-forge/adapters/seedream.md:66-66 (list_item)

- **Text-heavy designs**. Ideogram or GPT Image

Extracted rules inside block: NONE

## aac1a7d45877171d — visual-prompt-forge/adapters/seedream.md:67-67 (list_item)

- **Cinematic mood pieces**. Midjourney is the move

Extracted rules inside block: NONE

## 65e8ca2f94dbe217 — visual-prompt-forge/adapters/seedream.md:69-69 (heading)

## Series consistency

Extracted rules inside block: NONE

## 76afc7bda3e6fe75 — visual-prompt-forge/adapters/seedream.md:71-71 (paragraph)

Seedream's character consistency is weaker than Midjourney `--cref` or Ideogram omni-reference. To compensate:

Extracted rules inside block: NONE

## 12fb0075d54e66b2 — visual-prompt-forge/adapters/seedream.md:73-73 (list_item)

- **Lock the seed** at the storyboard level (same seed across all shots in a series)

Extracted rules inside block: NONE

## 03378e1ac84be632 — visual-prompt-forge/adapters/seedream.md:74-74 (list_item)

- **Verbatim repeat** the character anchor string from series_lock in every prompt

Extracted rules inside block: NONE

## dc1231d7ba2f489a — visual-prompt-forge/adapters/seedream.md:75-75 (list_item)

- **Don't vary** the lighting language between shots, series_lock string in, no paraphrasing

Extracted rules inside block: df529c9e4562

## d7e35d8cdffb7b15 — visual-prompt-forge/adapters/seedream.md:76-76 (list_item)

- **Accept** that some shots will need re-rolls; budget for it

Extracted rules inside block: NONE

## ac9979112d493b18 — visual-prompt-forge/adapters/seedream.md:78-78 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 2a2e988ad2e86ef8 — visual-prompt-forge/adapters/seedream.md:80-80 (list_item)

- **Don't write paragraphs**. Seedream wants comma-separated phrases

Extracted rules inside block: 2b980155a316

## 3532c00e9fceb2c0 — visual-prompt-forge/adapters/seedream.md:81-81 (list_item)

- **Don't use `--ar` syntax**, pass aspect_ratio as a parameter

Extracted rules inside block: cf97312c16f6

## a9efebcb358b50fb — visual-prompt-forge/adapters/seedream.md:82-82 (list_item)

- **Don't include text content**, text rendering is poor; composite separately

Extracted rules inside block: 6d4af2b1c810

## 3547a9bc9ce33866 — visual-prompt-forge/adapters/seedream.md:83-83 (list_item)

- **Don't expect Midjourney aesthetic**. Seedream produces clean but less art-directed output

Extracted rules inside block: bed0b0adba27

## ffd995ee496f05ef — visual-prompt-forge/adapters/seedream.md:84-84 (list_item)

- **Don't skip the seed lock for series work**, without it, character consistency breaks

Extracted rules inside block: e44a4828f32f

## 44f39f6c82cf40c2 — visual-prompt-forge/adapters/seedream.md:86-86 (heading)

## API access

Extracted rules inside block: NONE

## 620d1a415115b38f — visual-prompt-forge/adapters/seedream.md:88-88 (list_item)

- **fal.ai**, `bytedance/seedream-4.5` and `bytedance/seedream-4.0`

Extracted rules inside block: NONE

## 80f94710908eb7f4 — visual-prompt-forge/adapters/seedream.md:89-89 (list_item)

- **Replicate**, `bytedance/seedream-4.5`

Extracted rules inside block: NONE

## 42c27bfb9d4e634a — visual-prompt-forge/adapters/seedream.md:90-90 (list_item)

- **BytePlus**, direct API, requires their account

Extracted rules inside block: NONE

## bba4d224cdf1096e — visual-prompt-forge/adapters/seedream.md:92-92 (paragraph)

Same prompt syntax across surfaces.

Extracted rules inside block: NONE

## 1d15e990bc0894f9 — visual-prompt-forge/adapters/veo.md:1-1 (heading)

# Adapter: Veo 3 (motion-aware video, native audio)

Extracted rules inside block: NONE

## 04d25362146c7216 — visual-prompt-forge/adapters/veo.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: b1877986517b

## dac10d573624fbd3 — visual-prompt-forge/adapters/veo.md:5-5 (paragraph)

Veo 3 is the dialogue and lipsync model. It is the only adapter that generates **synchronised native audio**, speech, ambience, and sound effects, in the same pass as the video. It also has the strongest prompt adherence and physical realism of the four motion models. It is the most expensive, so reserve it for shots that actually need spoken dialogue, lipsync, or audio baked in. For silent B-roll and camera moves, Kling is the cheaper default.

Extracted rules inside block: NONE

## c3341415b0949db7 — visual-prompt-forge/adapters/veo.md:7-7 (paragraph)

With video the **camera motion is load-bearing**. When the shot has dialogue, the **spoken line is also load-bearing** and is written into the prompt (this is the one place where text belongs in a prompt, it is audio, not on-screen text).

Extracted rules inside block: NONE

## 27cf2bda8fb30967 — visual-prompt-forge/adapters/veo.md:9-9 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## 9569d32ae52343ec — visual-prompt-forge/adapters/veo.md:11-13 (code)

```
{Camera motion sentence, leading.} {Subject and action over the duration.} {Dialogue line, in quotes, if any.} {Environment and lighting from series_lock.} {Audio direction.} {Color grade and mood from brand_lock.}
```

Extracted rules inside block: NONE
