# Source coverage review 5/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 6b0fac7c8984e595 — ai-production-director/references/creative-strategy.md:53-53 (heading)

## 4. Matriz de selección

Extracted rules inside block: NONE

## 79b448efaa2b79e6 — ai-production-director/references/creative-strategy.md:55-55 (paragraph)

Presenta los conceptos en una matriz 1–5, sin promediar a ciegas — el usuario pondera:

Extracted rules inside block: NONE

## f8d11db2ddd6ed11 — ai-production-director/references/creative-strategy.md:57-57 (table_row)

| Concepto | Fuerza del insight | Distintividad vs. categoría | Fit de marca | Claridad de la proposición | Viabilidad AI | Riesgo |

Extracted rules inside block: NONE

## 92508d670d7b548c — ai-production-director/references/creative-strategy.md:60-60 (paragraph)

Debajo de la matriz, tu recomendación argumentada en un párrafo: cuál elegirías y por qué, nombrando el trade-off que implica. Recomendar es parte del trabajo; decidir es del usuario.

Extracted rules inside block: NONE

## c9d4ea7a394d5895 — ai-production-director/references/creative-strategy.md:62-62 (paragraph)

**Gate de la etapa:** el usuario selecciona un concepto (puede pedir un híbrido — trátalo como concepto nuevo con su propia card antes de avanzar).

Extracted rules inside block: NONE

## ccf543d40f9f29d3 — ai-production-director/references/creative-strategy.md:64-64 (heading)

## 5. Dirección narrativa del concepto ganador

Extracted rules inside block: NONE

## 80084ebb0e8e70d5 — ai-production-director/references/creative-strategy.md:66-66 (paragraph)

Puente hacia `screenwriter`. Media página que fija, para el concepto elegido:

Extracted rules inside block: NONE

## 415957f798dbfb30 — ai-production-director/references/creative-strategy.md:68-68 (list_item)

- **Estructura**: nº de escenas/actos y función de cada una (usar la three-jobs rule como criterio: cada escena cambia emoción, avanza acción o sube presión)

Extracted rules inside block: NONE

## 1b688f3b92fc40e3 — ai-production-director/references/creative-strategy.md:69-69 (list_item)

- **Punto de vista**: desde quién se cuenta y por qué

Extracted rules inside block: NONE

## ab59a080eb665d81 — ai-production-director/references/creative-strategy.md:70-70 (list_item)

- **Los 5 anclas preliminares** (se refinan en Etapa 3): una emoción dominante, un motivo recurrente, un objeto, un quiebre, una imagen final

Extracted rules inside block: NONE

## 49081c5080233523 — ai-production-director/references/creative-strategy.md:71-71 (list_item)

- **Reglas del mundo**: qué existe y qué no en esta pieza (época, lugar, nivel de realismo, presencia del producto)

Extracted rules inside block: NONE

## 80f11a77952f6b6a — ai-production-director/references/creative-strategy.md:72-72 (list_item)

- **Duración objetivo y densidad**: cuántos segundos por beat, dónde vive la pausa

Extracted rules inside block: NONE

## 593ef1039301bbe5 — ai-production-director/references/creative-strategy.md:74-74 (paragraph)

Este documento + la concept card son la entrada completa de la Etapa 2. Si `screenwriter` tuviera que preguntar algo estructural, esta etapa quedó corta — corrígela aquí.

Extracted rules inside block: NONE

## 150b1ea6d59bf5fd — ai-production-director/references/production-package.md:1-1 (heading)

# Etapa 7 — Final AI Video Production Package

Extracted rules inside block: NONE

## e0d0cfecc8925727 — ai-production-director/references/production-package.md:3-3 (paragraph)

Spec del entregable final del pipeline. El paquete debe permitir que un editor, una agencia o el propio usuario dentro de tres meses produzca el video sin hacer una sola pregunta de contexto.

Extracted rules inside block: NONE

## a340c03cac6da836 — ai-production-director/references/production-package.md:5-5 (heading)

## 1. Estructura del paquete

Extracted rules inside block: NONE

## e0922a1283a2efaf — ai-production-director/references/production-package.md:7-38 (code)

```
production-package/
├── 00-README.md                  # Índice, track usado, resumen de decisiones, créditos
├── 01-strategy/
│   ├── brief.md                  # Brief original o su reconstrucción
│   ├── territories.md            # Territorios explorados (STANDARD/FILM)
│   ├── concept-cards.md          # Todas las cards + matriz + concepto seleccionado marcado
│   └── narrative-direction.md
├── 02-script/
│   ├── treatment.md              # Solo FILM
│   └── script.md                 # Escenas XML-tagged de screenwriter
├── 03-direction/
│   └── cinematic-direction.md    # Blocking, cámara, luz, color, 5 anclas, por escena
├── 04-shots/
│   ├── storyboard.md
│   ├── shots.json                # FUENTE DE VERDAD
│   ├── text-overlays.json
│   ├── run.json
│   └── brand-lock.snapshot.md
├── 05-anchors/
│   ├── anchor-plan.md            # Qué refs se necesitan y para qué shots
│   ├── prompts/round-N/          # Prompts de imagen por modelo, por ronda
│   ├── frames/round-N/           # Renders aprobados/evaluados
│   └── critiques/round-N/        # critique.json por shot evaluado
├── 06-video-prompts/
│   ├── prompts/                  # Un archivo por shot: shot_NN.<modelo>.txt
│   └── continuity-notes.md       # Bloques de continuidad entre clips
├── 07-delivery/
│   ├── preview.html              # storyboard-html-preview, single-file
│   └── post-production.md        # Checklist de post (ver §3)
└── brand-lock.md                 # Si existió Etapa 0
```

Extracted rules inside block: NONE

## e0f117c41faa8612 — ai-production-director/references/production-package.md:40-40 (paragraph)

En EXPRESS el paquete se comprime a: README, shot list, prompts y checklist de post — misma trazabilidad, menos carpetas.

Extracted rules inside block: NONE

## a7b771c0c60520c1 — ai-production-director/references/production-package.md:42-42 (heading)

## 2. Reglas de trazabilidad

Extracted rules inside block: NONE

## c0381c57f66b49b1 — ai-production-director/references/production-package.md:44-44 (list_item)

1. Todo prompt (imagen o video) lleva en comentario su `shot_id`.

Extracted rules inside block: a708e29a625b

## a58cb8ba7edaddb6 — ai-production-director/references/production-package.md:45-45 (list_item)

2. Todo shot en shots.json referencia su escena del script (`scene` field o nota).

Extracted rules inside block: 65e8026ad2b5

## 3501cbcc6b336488 — ai-production-director/references/production-package.md:46-46 (list_item)

3. El script referencia la concept card ganadora en su encabezado.

Extracted rules inside block: 82b2e0db377d

## 4794adaae1000fe1 — ai-production-director/references/production-package.md:47-47 (list_item)

4. Cambios: si un prompt necesita cambiar algo que su shot fija (encuadre, acción, luz), el cambio se hace en shots.json y se regenera hacia abajo. El paquete nunca contiene un prompt que contradiga su shot.

Extracted rules inside block: d1c709080fc1

## ee239a7a6bf6000e — ai-production-director/references/production-package.md:48-48 (list_item)

5. Verificación de cierre: muestrea 3 prompts al azar y traza la cadena prompt → shot → escena → concepto. Si un eslabón falta, el paquete no se entrega.

Extracted rules inside block: f4b95af8ea47

## 6282f05bf2b2f08d — ai-production-director/references/production-package.md:50-50 (heading)

## 3. Checklist de post-producción (07-delivery/post-production.md)

Extracted rules inside block: NONE

## 10e51205de386caa — ai-production-director/references/production-package.md:52-52 (paragraph)

Adaptar al proyecto, con specs concretos — no placeholders:

Extracted rules inside block: NONE

## 58b084b6b2827864 — ai-production-director/references/production-package.md:54-64 (code)

```
- [ ] Generar los N shots en [modelo(s)] con los prompts de 06-video-prompts/
- [ ] Verificar cada clip contra su shot card (encuadre, acción, luz) antes de editar
- [ ] Ensamblar en [NLE] siguiendo el orden y duraciones de shots.json
- [ ] Aplicar grade de consistencia: [referencia de color del brand-lock o Visual Theme]
- [ ] Transiciones: [tipo y duración definidos en dirección, no "al gusto"]
- [ ] Audio: [música género/BPM/posición de beats + VO + ambientes según dirección de audio por shot]
- [ ] Overlays de texto según text-overlays.json (tipografía del brand-lock)
- [ ] Export: [resolución, aspect ratio, fps, códec, loudness según plataforma destino]
- [ ] QA final contra los 5 anclas: ¿la pieza terminada conserva emoción, motivo, objeto, quiebre e imagen final?
```

Extracted rules inside block: NONE

## d475813b4cf294cb — ai-production-director/references/production-package.md:66-66 (heading)

## 4. Checklist maestro del pipeline (gate de la Etapa 7)

Extracted rules inside block: NONE

## 4df0c266baa49404 — ai-production-director/references/production-package.md:68-68 (list_item)

- [ ] Concepto seleccionado por el usuario documentado en 01-strategy

Extracted rules inside block: NONE

## 47cd7967a5ff640c — ai-production-director/references/production-package.md:69-69 (list_item)

- [ ] Cada escena del script pasa fórmula de escena + three-jobs rule

Extracted rules inside block: NONE
