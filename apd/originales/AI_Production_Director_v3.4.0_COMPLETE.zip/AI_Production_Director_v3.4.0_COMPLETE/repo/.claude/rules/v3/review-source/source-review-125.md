# Source coverage review 125/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## adbeb1d010ef0768 — storyboard-html-preview/tools/README.md:60-60 (list_item)

- warns when the matrix or an entry is past its 120-day freshness window

Extracted rules inside block: NONE

## 13398c05b7c76ec6 — storyboard-html-preview/tools/README.md:62-65 (code)

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

Extracted rules inside block: NONE

## b6335fd3accb74b1 — storyboard-html-preview/tools/README.md:67-68 (paragraph)

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

Extracted rules inside block: NONE

## 914e01df88614378 — storyboard-html-preview/tools/README.md:70-70 (heading)

### `validate_brand_lock.py`

Extracted rules inside block: NONE

## 5d64b2ff8a549844 — storyboard-html-preview/tools/README.md:72-74 (paragraph)

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

Extracted rules inside block: 42ef699b8caf

## 6ad799436bd6f7c3 — storyboard-html-preview/tools/README.md:76-82 (code)

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

Extracted rules inside block: NONE

## c1f5e758eb0589c9 — storyboard-html-preview/tools/README.md:84-86 (paragraph)

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

Extracted rules inside block: 5c287e27d7fb

## 14a22f1d7306f8b1 — storyboard-html-preview/tools/README.md:88-88 (heading)

## Project checks

Extracted rules inside block: NONE

## 31e7d71186d399a0 — storyboard-html-preview/tools/README.md:90-90 (paragraph)

These run against a project's output directory, not the repo.

Extracted rules inside block: NONE

## 08e468f830334584 — storyboard-html-preview/tools/README.md:92-92 (heading)

### `validate_shots.py`

Extracted rules inside block: NONE

## 037cd2c55bcfe218 — storyboard-html-preview/tools/README.md:94-98 (paragraph)

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

Extracted rules inside block: NONE

## fee8179188b83a16 — storyboard-html-preview/tools/README.md:100-105 (code)

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Extracted rules inside block: NONE

## a45e09467a27eae0 — storyboard-html-preview/tools/README.md:107-108 (paragraph)

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

Extracted rules inside block: NONE

## ba74bd6a6120d88f — storyboard-html-preview/tools/README.md:110-110 (heading)

### `validate_prompts.py`

Extracted rules inside block: NONE

## 062c1f4e83ffb823 — storyboard-html-preview/tools/README.md:112-116 (paragraph)

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

Extracted rules inside block: NONE

## e8d9bd7094eeaa0b — storyboard-html-preview/tools/README.md:118-123 (code)

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

Extracted rules inside block: NONE

## 869aa76db4694b6a — storyboard-html-preview/tools/README.md:125-129 (paragraph)

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

Extracted rules inside block: NONE

## 6f2214f48910aa6b — storyboard-html-preview/tools/README.md:131-132 (paragraph)

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

Extracted rules inside block: NONE

## 5dd4bfb37aa8c2fb — storyboard-html-preview/tools/README.md:134-134 (heading)

### `validate_critique.py`

Extracted rules inside block: NONE

## aa53705caf9d85de — storyboard-html-preview/tools/README.md:136-137 (paragraph)

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

Extracted rules inside block: NONE

## 1a3f120d18bf58bb — storyboard-html-preview/tools/README.md:139-140 (paragraph)

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

Extracted rules inside block: NONE

## d62850471fb218b9 — storyboard-html-preview/tools/README.md:142-144 (paragraph)

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

Extracted rules inside block: 982c01ba4186

## ca85121e4dd6987f — storyboard-html-preview/tools/README.md:146-151 (code)

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Extracted rules inside block: NONE

## ddf2ee131fcfec83 — storyboard-html-preview/tools/README.md:153-154 (paragraph)

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

Extracted rules inside block: NONE

## 3ae3bccc7aad2400 — storyboard-html-preview/tools/README.md:156-156 (heading)

### `validate_provenance.py`

Extracted rules inside block: NONE

## e50f356e16b17a9a — storyboard-html-preview/tools/README.md:158-159 (paragraph)

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

Extracted rules inside block: NONE

## 7ff33e9ffafce135 — storyboard-html-preview/tools/README.md:161-166 (code)

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

Extracted rules inside block: NONE

## b9c6fa3362904f92 — storyboard-html-preview/tools/README.md:168-168 (paragraph)

It catches, with a selftest for each:

Extracted rules inside block: NONE

## 3c9dc1cb5f0f8aa3 — storyboard-html-preview/tools/README.md:170-170 (list_item)

- a frame regenerated after its critique (`image_sha256` no longer matches)

Extracted rules inside block: NONE

## 78f24c57f62d72cf — storyboard-html-preview/tools/README.md:171-171 (list_item)

- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)

Extracted rules inside block: NONE
