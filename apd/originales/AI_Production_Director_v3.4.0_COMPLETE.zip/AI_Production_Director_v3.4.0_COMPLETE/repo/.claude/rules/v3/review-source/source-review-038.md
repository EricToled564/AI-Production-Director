# Source coverage review 38/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 560f3d0ada6b6225 — image/references/creative-direction.md:120-125 (code)

```
A child's crayon drawing on white lined notebook paper of [SUBJECT].
Use chunky wax-crayon strokes, wobbly outlines, bold colors that overflow
the lines. Visible pressure marks, waxy smudges, uneven scribble shading.
Joyful, naive art style.
```

Extracted rules inside block: NONE

## 8e46ae999abe2a06 — image/references/creative-direction.md:127-127 (paragraph)

**Fashion Editorial:**

Extracted rules inside block: NONE

## 66c5d4339f09090c — image/references/creative-direction.md:128-133 (code)

```
[Subject description]. [Action/pose]. [Setting].
Medium-full shot, center-framed.
Fashion magazine style editorial, shot on medium-format analog film,
pronounced grain, high saturation, cinematic lighting effect.
```

Extracted rules inside block: NONE

## 2c2a55de088b3742 — image/references/creative-direction.md:137-137 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 13bb6bfc275e23a4 — image/references/dimensional.md:1-1 (heading)

# Dimensional Translation

Extracted rules inside block: NONE

## c28b63d93f4eaaf7 — image/references/dimensional.md:3-3 (paragraph)

2D↔3D conversions. Floor plans to renders, memes to 3D.

Extracted rules inside block: NONE

## bcb79403d7d3580e — image/references/dimensional.md:5-5 (heading)

## 2D Floor Plan → 3D

Extracted rules inside block: NONE

## 22e8bbf3345e2515 — image/references/dimensional.md:7-18 (code)

```
Based on this 2D floor plan, generate interior visualization.

Layout: Design board format
Main image: Wide-angle [ROOM] perspective (top 60%)
Below: 3 smaller renders - [ROOM A], [ROOM B], [ROOM C]

Style: [Modern minimalist / Scandinavian / Industrial]
Materials: [flooring], [walls], [textiles]
Lighting: Soft natural light, large windows
Quality: Photorealistic rendering
```

Extracted rules inside block: NONE

## 5448c36c79461040 — image/references/dimensional.md:20-20 (heading)

## Sketch → 3D Concept

Extracted rules inside block: NONE

## 54ff99696504ef4d — image/references/dimensional.md:22-27 (code)

```
Convert this sketch into [STYLE] visualization.
Perspective: [CAMERA ANGLE]
Lighting: [SETUP]
Quality: [photorealistic / stylized / rendered]
```

Extracted rules inside block: NONE

## f8e39d6b881ca7f3 — image/references/dimensional.md:29-29 (heading)

## 3D → 2D Technical

Extracted rules inside block: NONE

## 104f3966a97c716b — image/references/dimensional.md:31-36 (code)

```
Flatten this 3D scene into [STYLE].
Views: [plan / elevation / section]
Labels: [ANNOTATIONS]
Line work: technical, precise
```

Extracted rules inside block: NONE

## 5c6438e058f56209 — image/references/dimensional.md:38-38 (heading)

## Meme Conversion

Extracted rules inside block: NONE

## 9805477469b561ea — image/references/dimensional.md:40-45 (code)

```
Turn "[MEME NAME]" meme into [NEW STYLE].
Keep composition identical.
Character: [plush toy / realistic / cartoon]
Environment: [realistic flames / stylized / etc]
```

Extracted rules inside block: NONE

## cc0433ee34297faa — image/references/dimensional.md:47-47 (paragraph)

Example:

Extracted rules inside block: NONE

## 9a03c2897d930189 — image/references/dimensional.md:48-48 (list_item)

- "Turn 'This is Fine' dog into photorealistic 3D render"

Extracted rules inside block: NONE

## be35eb76af5d3961 — image/references/dimensional.md:49-49 (list_item)

- "Make the dog look like plush toy, fire realistic"

Extracted rules inside block: NONE

## b49be19b218637e8 — image/references/dimensional.md:51-51 (heading)

## Architectural Visualization

Extracted rules inside block: NONE

## ff5267b808733256 — image/references/dimensional.md:53-53 (paragraph)

**Exterior:**

Extracted rules inside block: NONE

## 39ea990bf7b5f026 — image/references/dimensional.md:54-59 (code)

```
Generate exterior visualization from this elevation.
Time: [dawn / midday / dusk / night]
Weather: [clear / overcast / dramatic clouds]
Context: [landscaping / street / aerial view]
```

Extracted rules inside block: NONE

## bc69726c442bc422 — image/references/dimensional.md:61-61 (paragraph)

**Interior:**

Extracted rules inside block: NONE

## 2a7ee1f4f09ff41c — image/references/dimensional.md:62-68 (code)

```
Generate interior from this plan.
View: [living area / kitchen / bedroom]
Style: [AESTHETIC]
Lighting: [natural / artificial / mixed]
Props: [furniture / decor / people]
```

Extracted rules inside block: NONE

## 340d8aec13f9583d — image/references/dimensional.md:70-70 (heading)

## Product 2D → 3D

Extracted rules inside block: NONE

## 5c23364270001030 — image/references/dimensional.md:72-77 (code)

```
Convert this flat design into 3D product mockup.
Material: [plastic / metal / fabric / glass]
Lighting: [studio / environmental]
Angle: [front / 3-quarter / top-down]
```

Extracted rules inside block: NONE

## 25baa403f13bd46d — image/references/dimensional.md:79-79 (heading)

## Quality Levels

Extracted rules inside block: NONE

## d8ba79f8e0078b56 — image/references/dimensional.md:81-81 (list_item)

- "Sketch quality" - rough, conceptual

Extracted rules inside block: NONE

## bc1af9884ebeb05a — image/references/dimensional.md:82-82 (list_item)

- "Presentation quality" - clean, professional

Extracted rules inside block: NONE

## 05bf9a6dc93151f9 — image/references/dimensional.md:83-83 (list_item)

- "Photorealistic" - indistinguishable from photo

Extracted rules inside block: NONE

## 275993bd603aee32 — image/references/dimensional.md:84-84 (list_item)

- "Stylized render" - artistic interpretation

Extracted rules inside block: NONE

## f8617b3c20ae67b1 — image/references/dimensional.md:88-88 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE
