# Source coverage review 17/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## ef7eab0b94f16712 — aurora-prompt-linter/references/skill_update_step5.md:33-33 (list_item)

> - El linter chequea: redundancia por categoría, word count, negative prompt, vocabulario baneado, keywords requeridos.

Extracted rules inside block: NONE

## 07c1e2705baddbe3 — aurora-prompt-linter/references/skill_update_step5.md:34-34 (list_item)

> - Si STATUS=PASS → proceder a Step 6.

Extracted rules inside block: NONE

## 70bfd49d40179a25 — aurora-prompt-linter/references/skill_update_step5.md:35-35 (list_item)

> - Si STATUS=FAIL sin override válido → NO entregar. Iterar el draft. NO se permite entregar al usuario con FAIL del linter.

Extracted rules inside block: 81e601ada119

## 34c6000ad596c8be — aurora-prompt-linter/references/skill_update_step5.md:36-36 (list_item)

> - Si STATUS=FAIL con overrides aceptados que cubren todas las violaciones → proceder a Step 6, declarando los overrides en el output del prompt.

Extracted rules inside block: NONE

## 09d907023f262a8a — aurora-prompt-linter/references/skill_update_step5.md:37-37 (list_item)

> - Si STATUS=FAIL con overrides parciales (algunas violaciones overrideadas, otras no) → iterar el draft hasta limpiar las no-overrideadas.

Extracted rules inside block: NONE

## 366a9a9456fd5467 — aurora-prompt-linter/references/skill_update_step5.md:38-38 (list_item)

>

Extracted rules inside block: NONE

## bcf78007bb0a694a — aurora-prompt-linter/references/skill_update_step5.md:39-39 (list_item)

> **Step 5c — Reporte del linter visible al usuario:**

Extracted rules inside block: NONE

## 6f7567f0ce9d24bc — aurora-prompt-linter/references/skill_update_step5.md:40-40 (list_item)

> Incluir en el output del prompt el resumen del linter:

Extracted rules inside block: NONE

## 340308a219444a81 — aurora-prompt-linter/references/skill_update_step5.md:41-41 (list_item)

> ```

Extracted rules inside block: NONE

## 64a9a6e7b0a44b4a — aurora-prompt-linter/references/skill_update_step5.md:42-42 (list_item)

> LINTER: PASS (o FAIL con overrides)

Extracted rules inside block: NONE

## 5aeab0c308bd72c4 — aurora-prompt-linter/references/skill_update_step5.md:43-43 (list_item)

> Violaciones detectadas: N

Extracted rules inside block: NONE

## f38519a1563850c6 — aurora-prompt-linter/references/skill_update_step5.md:44-44 (list_item)

> Overrides aceptados: M

Extracted rules inside block: NONE

## bee2ec34b9dab8dc — aurora-prompt-linter/references/skill_update_step5.md:45-45 (list_item)

> Categorías cubiertas por refs: [...]

Extracted rules inside block: NONE

## f745edd5a683abd7 — aurora-prompt-linter/references/skill_update_step5.md:46-46 (list_item)

> ```

Extracted rules inside block: NONE

## 64abdc81592e5e2b — aurora-prompt-linter/references/skill_update_step5.md:47-47 (list_item)

>

Extracted rules inside block: NONE

## 1ee5deffcb69b8f6 — aurora-prompt-linter/references/skill_update_step5.md:48-48 (list_item)

> Esto da trazabilidad y permite al usuario confirmar que el linter corrió antes de la entrega.

Extracted rules inside block: NONE

## 58313f9d10c5522a — aurora-prompt-linter/references/skill_update_step5.md:50-50 (heading)

## Razón del cambio

Extracted rules inside block: NONE

## 01b63c041a7ad431 — aurora-prompt-linter/references/skill_update_step5.md:52-52 (paragraph)

Sesión 2026-05-27 documentó 4 errores repetidos de over-description en I2V — la regla v6.0 §5.4 existe pero el agente la olvida bajo presión de iteración rápida. El linter mueve enforcement de memoria a código.

Extracted rules inside block: NONE

## e1dfd847e6214dd7 — aurora-prompt-linter/references/skill_update_step5.md:54-54 (paragraph)

Beneficio adicional: el override mechanism preserva flexibilidad cuando un caso edge justifica violar la regla, sin permitir abuso (requiere expresión escrita específica del usuario en el turno actual).

Extracted rules inside block: NONE

## 1c672276b519e59e — aurora-prompt-linter/references/skill_update_step5.md:56-56 (heading)

## Impacto en flujo

Extracted rules inside block: NONE

## 91b1d7f6a25137a2 — aurora-prompt-linter/references/skill_update_step5.md:58-58 (paragraph)

Sin linter: agente entrega → usuario corrige error en turno N+1 → agente reescribe → ciclo. Costo: ~3-4 turnos por iteración.

Extracted rules inside block: NONE

## a3f1590a287ec26f — aurora-prompt-linter/references/skill_update_step5.md:60-60 (paragraph)

Con linter: agente intenta entregar → linter FAIL → agente reescribe ANTES de mostrar al usuario → entrega clean. Costo: ~0 turnos adicionales para el usuario.

Extracted rules inside block: NONE

## 332849d112f0fd4e — aurora-prompt-linter/references/skill_update_step5.md:62-62 (heading)

## Cómo se invoca

Extracted rules inside block: NONE

## 0b6ec5d07001bf48 — aurora-prompt-linter/references/skill_update_step5.md:64-64 (paragraph)

Desde el agente al final del Step 4 drafting:

Extracted rules inside block: NONE

## e39c166701f8dd18 — aurora-prompt-linter/references/skill_update_step5.md:66-88 (code)

```python
# Pseudocódigo del agente
draft = "..."          # el prompt construido
refs = [...]           # tags por ref
case = "3b"            # caso clasificado en Step 0
user_msg = "..."       # mensaje completo del usuario en el turno actual

# Escribir a temp files
write("/tmp/draft.txt", draft)
write("/tmp/refs.yaml", refs_yaml)
write("/tmp/user.txt", user_msg)

# Correr linter
result = bash(f"python3 aurora-linter/prompt_linter.py --prompt /tmp/draft.txt --refs /tmp/refs.yaml --case {case} --overrides /tmp/user.txt")

if result.exit_code == 0:
    # PASS, proceder a Step 6
    deliver(draft, linter_report=result.stdout)
else:
    # FAIL, iterar
    new_draft = revise_based_on_report(draft, result.stdout)
    # vuelve a Step 4 hasta PASS
```

Extracted rules inside block: NONE

## 30f0f3b366a3d76e — aurora-prompt-linter/references/skill_update_step5.md:90-90 (heading)

## Aprobación requerida

Extracted rules inside block: NONE

## 44347bff3d7d2773 — aurora-prompt-linter/references/skill_update_step5.md:92-92 (list_item)

- [ ] Aprueba la edit a Step 5

Extracted rules inside block: NONE

## 2ade9acad6e5888a — aurora-prompt-linter/references/skill_update_step5.md:93-93 (list_item)

- [ ] Modificar (especificar qué)

Extracted rules inside block: NONE

## 0d68d4ce06db3579 — aurora-prompt-linter/references/skill_update_step5.md:94-94 (list_item)

- [ ] Rechazar (sin cambios, linter queda como herramienta opcional)

Extracted rules inside block: NONE

## cb7bbfb8e28409cb — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:1-1 (heading)

# Edit propuesta al system prompt v6.0 — Regla 28 + ajustes

Extracted rules inside block: NONE
