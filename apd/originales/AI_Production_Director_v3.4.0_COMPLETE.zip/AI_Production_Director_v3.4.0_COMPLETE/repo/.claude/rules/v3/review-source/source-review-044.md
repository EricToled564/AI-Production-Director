# Source coverage review 44/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 403e6230bb39f2c0 — image/references/gpt-image.md:43-43 (table_row)

| Setting | Когда |

Extracted rules inside block: NONE

## d4e56f5a58856708 — image/references/gpt-image.md:45-45 (table_row)

| `quality: low` | High-volume, превью, exploratory, latency-sensitive, draft |

Extracted rules inside block: NONE

## 381242b4709df53d — image/references/gpt-image.md:46-46 (table_row)

| `quality: medium` | **Default starting point** |

Extracted rules inside block: NONE

## 95607b173884503f — image/references/gpt-image.md:47-47 (table_row)

| `quality: high` | Маленький/плотный текст, infographics, портреты, identity-sensitive edits, brand assets |

Extracted rules inside block: NONE

## 8ce5aac008885131 — image/references/gpt-image.md:49-49 (paragraph)

Стартуй с `low`, апгрейди по необходимости. Часто `low` уже достаточно.

Extracted rules inside block: NONE

## e8f35cd8ff342ad5 — image/references/gpt-image.md:51-51 (heading)

## Размеры (gpt-image-2)

Extracted rules inside block: NONE

## 55bc8adb03f997e6 — image/references/gpt-image.md:53-53 (list_item)

- Max edge: <3840px

Extracted rules inside block: NONE

## 900498f868398f57 — image/references/gpt-image.md:54-54 (list_item)

- Обе стороны: кратны 16

Extracted rules inside block: NONE

## 854b41a06e07b712 — image/references/gpt-image.md:55-55 (list_item)

- Aspect ratio: max 3:1 (long:short)

Extracted rules inside block: NONE

## 79214999141b84c7 — image/references/gpt-image.md:56-56 (list_item)

- Total pixels: 655 360 – 8 294 400

Extracted rules inside block: NONE

## 3474810bf8e80b91 — image/references/gpt-image.md:57-57 (list_item)

- Reliable upper bound: 2560×1440

Extracted rules inside block: NONE

## d0107df355528370 — image/references/gpt-image.md:59-59 (paragraph)

**Ходовые:**

Extracted rules inside block: NONE

## c327917fde377628 — image/references/gpt-image.md:60-60 (list_item)

- Portrait 1024×1536

Extracted rules inside block: NONE

## a79ba83baf812dab — image/references/gpt-image.md:61-61 (list_item)

- Landscape 1536×1024

Extracted rules inside block: NONE

## 5d7deceb0aff6245 — image/references/gpt-image.md:62-62 (list_item)

- Square 1024×1024

Extracted rules inside block: NONE

## ae4b0133fb7e8857 — image/references/gpt-image.md:63-63 (list_item)

- 2K 2560×1440

Extracted rules inside block: NONE

## 4105e1f12aa3d695 — image/references/gpt-image.md:65-65 (list_item)

> Экстрим вроде 1:8 / 8:1 GPT Image 2 НЕ умеет — иди в Nano Banana.

Extracted rules inside block: NONE

## da1e62671b167cce — image/references/gpt-image.md:67-67 (heading)

## Text in Image

Extracted rules inside block: NONE

## c5027294690038f6 — image/references/gpt-image.md:69-69 (list_item)

- Литеральный текст в `"..."` или ALL CAPS.

Extracted rules inside block: NONE

## 3c9eaa2919ca850a — image/references/gpt-image.md:70-70 (list_item)

- Шрифт, размер, цвет, позиция — явно.

Extracted rules inside block: NONE

## cac5aa9080310844 — image/references/gpt-image.md:71-71 (list_item)

- Сложные слова и бренды: спеллинг по буквам.

Extracted rules inside block: NONE

## 1106e892c3464b3f — image/references/gpt-image.md:72-72 (list_item)

- Защита от мусора: «**no extra words, no duplicate text, no watermarks**».

Extracted rules inside block: NONE

## 7d66fafb1f471dca — image/references/gpt-image.md:73-73 (list_item)

- Для нечитаемого мелкого текста: «**100 percent readable and physically believable**».

Extracted rules inside block: NONE

## dc8807af1348de4c — image/references/gpt-image.md:74-74 (list_item)

- Маленький/плотный/multi-font → `quality: high` обязательно.

Extracted rules inside block: bef49d90fb3f

## 4693542d6ad473bd — image/references/gpt-image.md:76-76 (heading)

## Editing — двухколоночная логика

Extracted rules inside block: NONE

## 2c453c2950d9bf3d — image/references/gpt-image.md:78-78 (paragraph)

Endpoint: `openai/gpt-image-2/edit` (на fal.ai) или соответствующий через OpenAI API.

Extracted rules inside block: NONE

## 1a1613a66023d4d1 — image/references/gpt-image.md:80-84 (code)

```
Change: [single concrete change]
Preserve: face, identity, pose, lighting, framing, background, geometry, text, layout
Constraints: no extra objects, no redesign, no drift
```

Extracted rules inside block: NONE

## 9444db3e539d17d2 — image/references/gpt-image.md:86-86 (paragraph)

**Правила edit:**

Extracted rules inside block: NONE

## 892f0a04ef18dddd — image/references/gpt-image.md:87-87 (list_item)

- **Один edit за итерацию.** Не пытайся менять всё разом.

Extracted rules inside block: NONE

## f6308b9b137d409b — image/references/gpt-image.md:88-88 (list_item)

- **Preserve list повторять каждую итерацию.** Иначе дрейф.

Extracted rules inside block: NONE
