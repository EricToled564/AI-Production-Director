# Source coverage review 71/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## bf9207fca826cf4b — image/references/storyboards.md:20-20 (heading)

## Commercial Storyboard

Extracted rules inside block: NONE

## a9d65481bba3ee69 — image/references/storyboards.md:22-34 (code)

```
Create [NUMBER]-part story for [PRODUCT] commercial.

Characters: [man and woman / family / solo]
Product: [DESCRIPTION]
Story: [EMOTIONAL ARC]
Ending: Elegant shot with [LOGO/PRODUCT]

Identity and attire consistent throughout.
Vary angles and distances.
Generate one at a time.
Format: 16:9 landscape.
```

Extracted rules inside block: NONE

## 438d9a305059423c — image/references/storyboards.md:36-36 (heading)

## Film Storyboard

Extracted rules inside block: NONE

## 5c72aaba916246f5 — image/references/storyboards.md:38-49 (code)

```
Create storyboard for this scene.

Shots:
1. Establishing shot - [DESCRIPTION]
2. Medium shot - [ACTION]
3. Close-up - [DETAIL]
4. POV shot - [PERSPECTIVE]

Style: [B&W sketch / color / cinematic]
Annotations: [CAMERA MOVES / NOTES]
```

Extracted rules inside block: NONE

## 19e734b3bd215e4a — image/references/storyboards.md:51-51 (heading)

## Concept Art Series

Extracted rules inside block: NONE

## e6522d02cbb53d39 — image/references/storyboards.md:53-62 (code)

```
Create concept art series for [PROJECT].

Subjects: [CHARACTERS / ENVIRONMENTS / PROPS]
Style: [AESTHETIC]
Mood: [TONE]

Consistency: Design language across all pieces.
Generate one at a time.
```

Extracted rules inside block: NONE

## 8397a268ca8cf718 — image/references/storyboards.md:64-64 (heading)

## Sprite Sheets

Extracted rules inside block: NONE

## 208bfcc4dc28eab2 — image/references/storyboards.md:66-72 (code)

```
Sprite sheet of [CHARACTER] doing [ACTION].
Grid: [3x3 / 4x4]
Sequence: frame by frame animation
Format: square aspect ratio
Follow reference grid structure exactly.
```

Extracted rules inside block: NONE

## 56c5c2b9d516bd17 — image/references/storyboards.md:74-74 (paragraph)

Tip: Extract cells to make GIF.

Extracted rules inside block: NONE

## f30275c194940e6f — image/references/storyboards.md:76-76 (heading)

## Consistency Rules

Extracted rules inside block: NONE

## 6eba7e5c471b48f1 — image/references/storyboards.md:78-78 (list_item)

- "Identity must stay consistent throughout"

Extracted rules inside block: d71c38a7ced6

## 837731fa21e3626f — image/references/storyboards.md:79-79 (list_item)

- "Attire same across all images"

Extracted rules inside block: NONE

## 0c38b34ecc25145c — image/references/storyboards.md:80-80 (list_item)

- "Can be seen from different angles and distances"

Extracted rules inside block: NONE

## 32df2dae247ad502 — image/references/storyboards.md:81-81 (list_item)

- "Expressions and poses should vary"

Extracted rules inside block: 104dab30e16d

## c320f1dba618a909 — image/references/storyboards.md:82-82 (list_item)

- "Only one of each character per image"

Extracted rules inside block: NONE

## 2214232330ccd670 — image/references/storyboards.md:84-84 (heading)

## Narrative Pacing

Extracted rules inside block: NONE

## 2bcec1952a75ae0b — image/references/storyboards.md:86-86 (list_item)

- "Story is thrilling with emotional highs and lows"

Extracted rules inside block: NONE

## 97bb492a1570012f — image/references/storyboards.md:87-87 (list_item)

- "Ends on [happy / dramatic / mysterious] moment"

Extracted rules inside block: NONE

## a39f2bacf57bae22 — image/references/storyboards.md:88-88 (list_item)

- "Build tension through first [N] images"

Extracted rules inside block: NONE

## c0daae2880d70960 — image/references/storyboards.md:89-89 (list_item)

- "Climax in image [N], resolution in final"

Extracted rules inside block: NONE

## 248e50869b6fa145 — image/references/storyboards.md:91-91 (heading)

## Output Control

Extracted rules inside block: NONE

## ba5e732b89b507ab — image/references/storyboards.md:93-93 (list_item)

- "Generate images one at a time"

Extracted rules inside block: NONE

## c11c4bf3a00074cc — image/references/storyboards.md:94-94 (list_item)

- "Make sure every image is [ASPECT RATIO]"

Extracted rules inside block: NONE

## b1f8ce83a5611730 — image/references/storyboards.md:95-95 (list_item)

- "Please generate [NUMBER] images, one at a time"

Extracted rules inside block: NONE

## 5eac2bbd313619b9 — image/references/storyboards.md:99-99 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 89945b64144453cb — image/references/structural.md:1-1 (heading)

# Structural Control

Extracted rules inside block: NONE

## c7c48320ccda8a44 — image/references/structural.md:3-3 (paragraph)

Input images control composition. Sketch→final, wireframes, grids.

Extracted rules inside block: NONE

## ae3db29ab1451445 — image/references/structural.md:5-5 (heading)

## Sketch → Final

Extracted rules inside block: NONE

## 64dc45ad2f35691c — image/references/structural.md:7-13 (code)

```
Create [ASSET TYPE] following this sketch exactly.

Sketch defines: composition, element placement, text position
Quality: [polished / professional / specified style]
Text: Render "[EXACT TEXT]" where indicated
```

Extracted rules inside block: NONE

## 5dd20197f1611c79 — image/references/structural.md:15-15 (paragraph)

Hand-drawn layouts become polished assets.

Extracted rules inside block: NONE
