# Source coverage review 149/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 1ebf65ea7e3ebd10 — video/references/fixes-and-skeletons.md:137-137 (heading)

### Objects or characters appear too early in an extension

Extracted rules inside block: NONE

## f030f259e4f4e56a — video/references/fixes-and-skeletons.md:139-139 (paragraph)

When extending a clip backward (prepending a beginning), elements that belong to the source video leak into the past.

Extracted rules inside block: NONE

## edc7ba74ffaa4e6b — video/references/fixes-and-skeletons.md:141-141 (paragraph)

Fix. Flag them explicitly.

Extracted rules inside block: NONE

## f5c1174b934ab83d — video/references/fixes-and-skeletons.md:143-145 (code)

```text
<Materials that should appear only after the source video begins> must not appear early in the backward extension.
```

Extracted rules inside block: NONE

## 4c53d37189681d3d — video/references/fixes-and-skeletons.md:147-147 (paragraph)

For forward extensions, the standard clause: "prohibit rigid cutting, prohibit objects appearing out of thin air."

Extracted rules inside block: 9188842c45d0

## 082d36c15648b78c — video/references/fixes-and-skeletons.md:149-149 (heading)

### Random subtitles or unwanted background music

Extracted rules inside block: NONE

## 0b30c244d8cf6952 — video/references/fixes-and-skeletons.md:151-151 (paragraph)

Fix. Ban directly and repeat the ban at the end of the prompt.

Extracted rules inside block: NONE

## 97ab727bb26baffb — video/references/fixes-and-skeletons.md:153-155 (code)

```text
Pure video, no subtitles, no background music.
```

Extracted rules inside block: NONE

## cf1596185d0d21f5 — video/references/fixes-and-skeletons.md:157-157 (paragraph)

On Seedance 2.5 and Veo this is reliable. On Seedance 1.x/2.0 and Kling, also avoid mentioning any on-screen text or score you do not want — mentions summon them.

Extracted rules inside block: 2e0c40c120ab

## bb6c2e76d5b47504 — video/references/fixes-and-skeletons.md:161-161 (heading)

## 3. Cross-model prompt skeletons

Extracted rules inside block: NONE

## bf73b0edeb8ea99a — video/references/fixes-and-skeletons.md:163-163 (heading)

### Seedance

Extracted rules inside block: NONE

## 5cfbd13571de3995 — video/references/fixes-and-skeletons.md:165-176 (code)

```text
Subject. [identity block].
Motion. [one clear present-tense action].
Camera. Shot 1. [framing, lens, movement]. Cut to. Shot 2. [framing, lens, movement]. Cut to. Shot 3. [framing, lens, movement].
Environment. [location, time, props].
Lighting. [source, direction, quality, color].
Style. [realism level, genre reference].
Audio. [ambient, SFX]. (1.5+ only)
Continuity. [what must remain constant].

--resolution 1080p --duration 5 --camerafixed false
```

Extracted rules inside block: NONE

## 231bd550c2720d57 — video/references/fixes-and-skeletons.md:178-178 (heading)

### Kling text-to-video

Extracted rules inside block: NONE

## 7817dee3b4e9a5d4 — video/references/fixes-and-skeletons.md:180-184 (code)

```text
[Subject with identity anchor]. [Subject movement]. Scene. [3-5 environment elements]. Camera. [one movement + lens]. Lighting. [source + quality]. Atmosphere. [mood].

Negative field. blurry, distorted hands, extra fingers, melted face, watermark, subtitles, jitter.
```

Extracted rules inside block: NONE

## 8731c6c6efdca7df — video/references/fixes-and-skeletons.md:186-186 (heading)

### Kling image-to-video

Extracted rules inside block: NONE

## df426a92331c9c56 — video/references/fixes-and-skeletons.md:188-192 (code)

```text
Preserve [silhouette / feature / label]. [Camera movement, one lens]. [One or two motion verbs]. [Atmospheric cue, light change].

Negative field. blurry, distorted hands, melted face, jitter.
```

Extracted rules inside block: NONE

## 2a76b0f8a267597f — video/references/fixes-and-skeletons.md:194-194 (heading)

### Veo prose

Extracted rules inside block: NONE

## aabc10f4d56987ba — video/references/fixes-and-skeletons.md:196-204 (code)

```text
[Subject performing action] in [environment]. [Camera framing + lens + movement]. [Lighting direction + color]. [Style + mood + palette].

Audio: [ambient, SFX, music texture].
Says: [character] says, "[dialogue, max 8s of speech]."
SFX: [punctual sound events].

Duration: [4 / 6 / 8] seconds.
```

Extracted rules inside block: NONE

## 2b8254b6865008fa — video/references/fixes-and-skeletons.md:206-206 (heading)

### Veo JSON

Extracted rules inside block: NONE

## f582c6fa26aecd69 — video/references/fixes-and-skeletons.md:208-208 (paragraph)

See `references/veo.md` section 6 for full schema.

Extracted rules inside block: NONE

## 6e3a2c60dceab264 — video/references/fixes-and-skeletons.md:212-212 (heading)

## 4. Default negative constraints

Extracted rules inside block: NONE

## 88f436a24960e335 — video/references/fixes-and-skeletons.md:214-214 (paragraph)

Where negatives are supported (Kling field, Veo body text, Seedance 2.0 fragile).

Extracted rules inside block: NONE

## b2b0530b3e1c684c — video/references/fixes-and-skeletons.md:216-218 (code)

```text
No subtitles. No on-screen text. No extra characters. No changing clothes. No changing face. No logos. No cartoon physics unless requested. No warm yellow tones unless requested. No random camera drift. No single-take when multi-shot is requested. No distorted hands. No extra fingers.
```

Extracted rules inside block: NONE

## f33e8278af53f18d — video/references/fixes-and-skeletons.md:220-220 (paragraph)

For Kling field. Rewrite as positive entities. "distorted hands, extra fingers, subtitles, logos, cartoon physics, random camera drift."

Extracted rules inside block: NONE

## 0d1bb97612b08e9c — video/references/fixes-and-skeletons.md:222-222 (paragraph)

For Seedance 1.0. Invert all negatives to positive phrasings in the prompt body.

Extracted rules inside block: NONE

## d946f1d166e29891 — video/references/fixes-and-skeletons.md:226-226 (heading)

## 5. Prompt compression order

Extracted rules inside block: NONE

## d09626cf63230db1 — video/references/fixes-and-skeletons.md:228-228 (paragraph)

When a model performs better with shorter prompts (Kling 2.5 Turbo, Kling 1.6, any image-to-video), cut in this order.

Extracted rules inside block: NONE

## 07661d488b1ad9c0 — video/references/fixes-and-skeletons.md:230-230 (list_item)

1. Keep character continuity.

Extracted rules inside block: 1dd8feeb2240

## 1318df47af22c7b7 — video/references/fixes-and-skeletons.md:231-231 (list_item)

2. Keep story action.

Extracted rules inside block: 328ac9b21bba

## 2801578afa5005df — video/references/fixes-and-skeletons.md:232-232 (list_item)

3. Keep shot timecodes (where relevant).

Extracted rules inside block: de685aa7d454
