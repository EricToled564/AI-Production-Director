# Source coverage review 49/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5c33e7e2f8a963bf — image/references/multi-panel.md:94-94 (paragraph)

**When to use:** Hero shot + close-up + action for a campaign visual — horizontal or vertical triptych.

Extracted rules inside block: c62949165832

## f05ef852e4a01fa5 — image/references/multi-panel.md:96-96 (heading)

### Template (5-slot format)

Extracted rules inside block: NONE

## 68f4097a941fb65b — image/references/multi-panel.md:98-113 (code)

```
Scene: Three-panel {orientation} collage for {brand_name} campaign. Panels separated by thin white lines.

Subject: {model_description} showcasing {product_description}.

Important Details:
Panel 1 (left/top): Hero wide shot — full figure of model with product, environmental context, lifestyle setting
Panel 2 (center/middle): Close-up product detail — {product_detail_description}, tactile textures, sharp focus
Panel 3 (right/bottom): Action shot — model using/wearing/interacting with product, candid energy, slight motion blur on extremities

Consistent warm golden-hour lighting across all panels. Same model identity throughout.
{typography_instruction}

Use Case: social media campaign visual, brand lookbook
Constraints: same person across all panels, consistent color grading, no stock-photo stiffness, {product_name} must be visible in every panel
```

Extracted rules inside block: NONE

## d763c816c33af578 — image/references/multi-panel.md:115-115 (paragraph)

**Variables:**

Extracted rules inside block: NONE

## ac14bc1c679a2672 — image/references/multi-panel.md:116-116 (list_item)

- `{orientation}` — "horizontal" (side by side) or "vertical" (stacked)

Extracted rules inside block: NONE

## e92994748df804f1 — image/references/multi-panel.md:117-117 (list_item)

- `{brand_name}`, `{product_name}`, `{product_description}` — brand context

Extracted rules inside block: NONE

## 928ae856e7b36294 — image/references/multi-panel.md:118-118 (list_item)

- `{model_description}` — who appears

Extracted rules inside block: NONE

## a265781282b7ce3c — image/references/multi-panel.md:119-119 (list_item)

- `{product_detail_description}` — what the close-up shows

Extracted rules inside block: NONE

## 47dee6f73ed86db5 — image/references/multi-panel.md:120-120 (list_item)

- `{typography_instruction}` — e.g., `Text: "{HEADLINE}" in bold condensed white, overlaid on Panel 1 lower third` or omit for no text

Extracted rules inside block: NONE

## c1eb08f6754bf52e — image/references/multi-panel.md:122-124 (paragraph)

**Recommended size:** 1536x1024 (horizontal triptych) or 1024x1536 (vertical triptych)
**Model:** GPT Image 2 `quality: medium` — if text overlay needed, use `quality: high`
**Common pitfalls:**

Extracted rules inside block: 2120cf320e71, f73c22848c72

## 66117ce8b8439da4 — image/references/multi-panel.md:125-125 (list_item)

- Not specifying panel order — "hero, close-up, action" without left/center/right assignment

Extracted rules inside block: NONE

## aa41223ce6973ef3 — image/references/multi-panel.md:126-126 (list_item)

- Lighting inconsistency when mixing indoor close-up with outdoor hero shot — specify unified lighting

Extracted rules inside block: NONE

## 32ba9fa539e712a3 — image/references/multi-panel.md:127-127 (list_item)

- Forgetting to mention subject consistency causes three different models

Extracted rules inside block: NONE

## b65f5388959b10e4 — image/references/multi-panel.md:131-131 (heading)

## 4. 4x3 Borderless Grid

Extracted rules inside block: NONE

## 6b554abd7376849a — image/references/multi-panel.md:133-133 (paragraph)

**When to use:** 12 panels telling a story or showing moods — no gaps between panels, seamless mosaic feel.

Extracted rules inside block: 22e10fd1c5d9

## 067553f5a2d56d45 — image/references/multi-panel.md:135-135 (heading)

### Template (5-slot format)

Extracted rules inside block: NONE

## 6ad1214e57e781a5 — image/references/multi-panel.md:137-153 (code)

```
Scene: 4x3 borderless grid (4 columns, 3 rows) where each of the 12 panels is an independent image but panels share no borders, gaps, or dividers — edges touch seamlessly. Overall theme: {theme}.

Subject: {subject_description} — maintain strong subject consistency across all 12 panels.

Important Details:
Row 1: {panel_1}, {panel_2}, {panel_3}, {panel_4}
Row 2: {panel_5}, {panel_6}, {panel_7}, {panel_8}
Row 3: {panel_9}, {panel_10}, {panel_11}, {panel_12}

Style: {style_description}
Mood progression: {mood_arc}
Each panel is an independent composition but the overall grid reads as a unified artwork.

Use Case: mood board, editorial spread, social media carousel preview, album artwork
Constraints: borderless — no white lines, no black borders, no gaps between panels. Same subject identity across all panels. No text in panels.
```

Extracted rules inside block: NONE

## 4e5f2f03d3579f25 — image/references/multi-panel.md:155-155 (paragraph)

**Variables:**

Extracted rules inside block: NONE

## 7560b5b2ba5fed07 — image/references/multi-panel.md:156-156 (list_item)

- `{subject_description}` — who/what appears across panels

Extracted rules inside block: NONE

## e99a63deacdbab01 — image/references/multi-panel.md:157-157 (list_item)

- `{theme}` — overarching concept (e.g., "solitude in a city", "four seasons of a garden")

Extracted rules inside block: NONE

## a68d2dad6a75eab1 — image/references/multi-panel.md:158-158 (list_item)

- `{panel_1}` through `{panel_12}` — brief shot description per cell

Extracted rules inside block: NONE

## 642f53bcd268385f — image/references/multi-panel.md:159-159 (list_item)

- `{style_description}` — visual style (e.g., "35mm film grain, desaturated palette")

Extracted rules inside block: NONE

## 7b02101532b548c6 — image/references/multi-panel.md:160-160 (list_item)

- `{mood_arc}` — how energy changes across the grid (e.g., "calm morning to chaotic night")

Extracted rules inside block: NONE

## 512d7af8046fb499 — image/references/multi-panel.md:162-164 (paragraph)

**Recommended size:** 1536x1024 (landscape) — gives each cell enough resolution
**Model:** Nano Banana Pro (handles complex multi-element compositions with thinking mode; no text needed)
**Common pitfalls:**

Extracted rules inside block: 389cf7e3ff24

## 216d102aa6562572 — image/references/multi-panel.md:165-165 (list_item)

- Saying "borderless" is not enough — explicitly state "no white lines, no black borders, no gaps"

Extracted rules inside block: NONE

## e257cc4a56c58507 — image/references/multi-panel.md:166-166 (list_item)

- 12 panels in one image pushes detail limits — keep per-panel descriptions short and visually distinct

Extracted rules inside block: NONE

## 6f7ce8456c8a3843 — image/references/multi-panel.md:167-167 (list_item)

- Without explicit subject consistency instructions, each panel may feature a different person/object

Extracted rules inside block: NONE

## de3bd3f343a1bdd7 — image/references/multi-panel.md:171-171 (heading)

## 5. 6-Frame Cinematic Sequence

Extracted rules inside block: NONE

## 8ae152ed13ec586b — image/references/multi-panel.md:173-173 (paragraph)

**When to use:** Fashion editorial or film-style sequence — multiple camera angles of the same scene in one image.

Extracted rules inside block: 6881a6be17e2

## 071e14037cdd4ca3 — image/references/multi-panel.md:175-175 (heading)

### Template (5-slot format)

Extracted rules inside block: NONE
