# Source coverage review 119/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 99336398674d801c — storyboard-architect/tools/README.md:112-116 (paragraph)

Validates the prompt files `visual-prompt-forge` writes, against `shots.json` and the
capability matrix. Header completeness, generator id, aspect agreement, the
`max_prompt_words` ceiling, shot coverage, duplicate blocks, and the forge's two hard
rules: no on-screen text copy inside a prompt, and `environment` / `lighting` /
`color_grade` appearing verbatim.

Extracted rules inside block: NONE

## 86f037a82274d486 — storyboard-architect/tools/README.md:118-123 (code)

```bash
python tools/validate_prompts.py output/
python tools/validate_prompts.py output/prompts/round-1/flux.txt
python tools/validate_prompts.py --examples
python tools/validate_prompts.py --selftest
```

Extracted rules inside block: NONE

## 7fc0d5c3524a8836 — storyboard-architect/tools/README.md:125-129 (paragraph)

The verbatim check is the reason this file exists. Series consistency depends on the
series_lock anchors landing unedited in every prompt, and that is the single easiest rule
in the kit to break, because paraphrasing an anchor is what writing good prose feels like.
A careful authoring pass over a seven-shot storyboard drifted on it seven times out of
seven with every other validator green, and so did the worked-run fixture in this repo.

Extracted rules inside block: NONE

## 3755d74325cd8b03 — storyboard-architect/tools/README.md:131-132 (paragraph)

The character anchor is a warning rather than an error: a shot with no person in it can
legitimately omit it, and the message says so, so you can confirm rather than guess.

Extracted rules inside block: NONE

## 6f71ca91f17fd4fc — storyboard-architect/tools/README.md:134-134 (heading)

### `validate_critique.py`

Extracted rules inside block: NONE

## b40f45011b4522a0 — storyboard-architect/tools/README.md:136-137 (paragraph)

Validates a critique against `critique.schema.json` **and** the two invariants the schema
cannot hold.

Extracted rules inside block: NONE

## bc86e3c4a2ed08d0 — storyboard-architect/tools/README.md:139-140 (paragraph)

The gate: any `blocking` issue forces `REJECT`, three or more `major` issues force `REJECT`,
one or two `major` forbid `ACCEPT`.

Extracted rules inside block: NONE

## 93873d6562bb50da — storyboard-architect/tools/README.md:142-144 (paragraph)

The provenance rules, from schema version `1.1`: a hash without its path is not a reference,
`image_ref` may not be null, `HIGH` confidence requires the shot, brand-lock, and prompt all
to be identified, and a named generator has to exist in the capability matrix.

Extracted rules inside block: a7fbacf02bd6

## dd26e3fb71567219 — storyboard-architect/tools/README.md:146-151 (code)

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
python tools/validate_critique.py output/          # every critique in the tree
python tools/validate_critique.py --examples
python tools/validate_critique.py --selftest
```

Extracted rules inside block: NONE

## 878df52758d56473 — storyboard-architect/tools/README.md:153-154 (paragraph)

Version `1.0` critiques still pass, with a warning: they carry a verdict and no way to tie it
to the bytes it reviewed.

Extracted rules inside block: NONE

## 75f3a6e362322c89 — storyboard-architect/tools/README.md:156-156 (heading)

### `validate_provenance.py`

Extracted rules inside block: NONE

## d4fde87597513bfa — storyboard-architect/tools/README.md:158-159 (paragraph)

Walks an output tree and recomputes every recorded hash. This is the tool that answers "does
this verdict still describe the file it reviewed."

Extracted rules inside block: NONE

## 24492f3111b84721 — storyboard-architect/tools/README.md:161-166 (code)

```bash
python tools/validate_provenance.py output/
python tools/validate_provenance.py output/ --require-accept
python tools/validate_provenance.py output/ --json
python tools/validate_provenance.py --selftest
```

Extracted rules inside block: NONE

## 0cc3a6b5d4e3f894 — storyboard-architect/tools/README.md:168-168 (paragraph)

It catches, with a selftest for each:

Extracted rules inside block: NONE

## 3923773849f53be5 — storyboard-architect/tools/README.md:170-170 (list_item)

- a frame regenerated after its critique (`image_sha256` no longer matches)

Extracted rules inside block: NONE

## 6c569b1f7e18616d — storyboard-architect/tools/README.md:171-171 (list_item)

- a brand-lock edited mid-project (`brand_lock_sha256` no longer matches `run.json`)

Extracted rules inside block: NONE

## 43999a0fdd6ebe84 — storyboard-architect/tools/README.md:172-172 (list_item)

- a frame on disk with no critique for its round, never reviewed at all

Extracted rules inside block: d2b2e18be3a6

## ccaa53b405d5db06 — storyboard-architect/tools/README.md:173-173 (list_item)

- two critiques for the same shot in the same round, two operators colliding

Extracted rules inside block: NONE

## 08a5580aefcec9bf — storyboard-architect/tools/README.md:174-174 (list_item)

- rounds that skip a number, or a critique whose `run_id` belongs to another run

Extracted rules inside block: NONE

## 504b41cf63a168b6 — storyboard-architect/tools/README.md:176-177 (paragraph)

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

Extracted rules inside block: NONE

## af7c29fa0685afa0 — storyboard-architect/tools/README.md:179-179 (heading)

## Rendering

Extracted rules inside block: NONE

## 8122e6551982c979 — storyboard-architect/tools/README.md:181-181 (heading)

### `shots-to-html.py`

Extracted rules inside block: NONE

## 6135ae6e99712bfa — storyboard-architect/tools/README.md:183-183 (paragraph)

Renders an output folder into a single `preview.html`.

Extracted rules inside block: NONE

## ccedb5f45ab6543c — storyboard-architect/tools/README.md:185-191 (code)

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

Extracted rules inside block: NONE

## b2f67108d426237a — storyboard-architect/tools/README.md:193-196 (paragraph)

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Extracted rules inside block: 4b5c92ae6749

## 7450bad4c5919179 — storyboard-architect/tools/README.md:198-199 (paragraph)

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

Extracted rules inside block: NONE

## e704dde53f2fc2d7 — storyboard-architect/tools/README.md:201-202 (paragraph)

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

Extracted rules inside block: NONE

## 69c5215e9d3fe1df — storyboard-architect/tools/README.md:204-205 (paragraph)

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

Extracted rules inside block: NONE

## 7f8508208f9062e1 — storyboard-architect/tools/README.md:207-207 (heading)

### `copy-prompt.py`

Extracted rules inside block: NONE

## d774a639ef8ba39d — storyboard-architect/tools/README.md:209-210 (paragraph)

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

Extracted rules inside block: NONE
