# Source coverage review 6/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## ce154468cd09c8c3 — ai-production-director/references/production-package.md:70-70 (list_item)

- [ ] Dirección cinematográfica sin vocabulario prohibido

Extracted rules inside block: ba0279909a12

## 3b36c6eb476a6e5c — ai-production-director/references/production-package.md:71-71 (list_item)

- [ ] shots.json validado (`validate_shots.py` limpio) y auditoría de 3 detalles por shot

Extracted rules inside block: NONE

## 3de9a1d606c7a53b — ai-production-director/references/production-package.md:72-72 (list_item)

- [ ] Anchors críticos con critique ACCEPT (≤2 rondas)

Extracted rules inside block: NONE

## 44c8d87a3cba2703 — ai-production-director/references/production-package.md:73-73 (list_item)

- [ ] Prompts de video en sintaxis del modelo destino, con los dos checks de `video` pasados

Extracted rules inside block: NONE

## f1b0334ff4d7526d — ai-production-director/references/production-package.md:74-74 (list_item)

- [ ] `aurora-prompt-linter` limpio sobre todos los prompts (si está instalada)

Extracted rules inside block: NONE

## 96976cbc5c509260 — ai-production-director/references/production-package.md:75-75 (list_item)

- [ ] Trazabilidad muestreada (§2.5)

Extracted rules inside block: NONE

## e1eef4a230cbf53f — ai-production-director/references/production-package.md:76-76 (list_item)

- [ ] preview.html abre offline y refleja el estado final

Extracted rules inside block: NONE

## a617513fdc7a0a9f — ai-production-director/references/production-package.md:77-77 (list_item)

- [ ] Créditos en 00-README.md: atribución *Serge Shima — github.com/smixs/visual-skills* si se usó la capa smixs; licencias de sub-skills anotadas

Extracted rules inside block: NONE

## fdefeb7d5c4e22c7 — ai-production-director/references/production-package.md:78-78 (list_item)

- [ ] 00-README.md explica en ≤1 página qué es el proyecto, qué track se usó y dónde está cada cosa

Extracted rules inside block: NONE

## d3f1a1990eb06ca5 — ai-video-storyboard/SKILL.md:2-3 (paragraph)

name: ai-video-storyboard
description: Use when planning a multi-shot AI video (TikTok Reel, Instagram Ad, YouTube Shorts, product explainer) where the target duration exceeds what a single AI generation can produce (over 15 seconds), and you need a coordinated shot list with visually consistent prompts for each segment

Extracted rules inside block: NONE

## 652a8a0b22b85d4d — ai-video-storyboard/SKILL.md:6-6 (heading)

# AI Video Storyboard Generator

Extracted rules inside block: NONE

## ceb7548f2c69c8af — ai-video-storyboard/SKILL.md:8-8 (heading)

## Overview

Extracted rules inside block: NONE

## 54823f6b6e3a1768 — ai-video-storyboard/SKILL.md:10-10 (paragraph)

AI video generators produce 5–15 second clips. Real-world videos are longer: 30s TikToks, 60s ads, 90s explainers. This skill bridges that gap by producing a complete **shot-list storyboard** — a coordinated sequence of per-shot prompts with shared visual language, so the assembled final video looks like one intentional piece of work rather than six disconnected clips.

Extracted rules inside block: NONE

## da8f0db312382fc5 — ai-video-storyboard/SKILL.md:12-12 (paragraph)

**Core insight:** Visual consistency across shots matters more than any single shot being perfect. A mediocre but consistent set of shots edits together; six gorgeous but mismatched shots do not.

Extracted rules inside block: a58b66163524

## d6fc1fc44002826a — ai-video-storyboard/SKILL.md:14-14 (heading)

## When to Use

Extracted rules inside block: NONE

## 3456cfc851bfaafb — ai-video-storyboard/SKILL.md:16-16 (list_item)

- User wants a video longer than 15 seconds

Extracted rules inside block: NONE

## 81a9599c9d5a955e — ai-video-storyboard/SKILL.md:17-17 (list_item)

- User wants a TikTok / Reel / Short / ad / explainer / B-roll sequence

Extracted rules inside block: NONE

## b67ea4cca85759b0 — ai-video-storyboard/SKILL.md:18-18 (list_item)

- User says "help me make a video about X" and has no shot list

Extracted rules inside block: NONE

## 630d2af52254115f — ai-video-storyboard/SKILL.md:19-19 (list_item)

- User is about to generate multiple clips and needs a plan

Extracted rules inside block: NONE

## c0ab818a12d01f41 — ai-video-storyboard/SKILL.md:21-21 (paragraph)

**Do NOT use for:**

Extracted rules inside block: d47c863b3c5c

## 61a63c9750718811 — ai-video-storyboard/SKILL.md:22-22 (list_item)

- Single-shot generation (just help with one prompt instead)

Extracted rules inside block: NONE

## e6a37bcb0e28fa6c — ai-video-storyboard/SKILL.md:23-23 (list_item)

- Static image generation

Extracted rules inside block: NONE

## d4f883116efb649d — ai-video-storyboard/SKILL.md:24-24 (list_item)

- Video editing advice after clips are generated (that's a separate concern)

Extracted rules inside block: NONE

## 216bf898de5ebc8a — ai-video-storyboard/SKILL.md:26-26 (heading)

## Workflow

Extracted rules inside block: NONE

## dc1b09cb95a86d5f — ai-video-storyboard/SKILL.md:28-28 (heading)

### Step 1 — Brief Intake

Extracted rules inside block: NONE

## f097b9249538489f — ai-video-storyboard/SKILL.md:30-30 (paragraph)

Ask the user these questions in a single message. Accept short answers:

Extracted rules inside block: NONE

## 9551ba8667898728 — ai-video-storyboard/SKILL.md:32-32 (list_item)

1. **Goal platform and duration?** (TikTok 30s / Reel 15-60s / YouTube Short / Instagram Ad / explainer)

Extracted rules inside block: e04773925989

## df2a0ec427445e88 — ai-video-storyboard/SKILL.md:33-33 (list_item)

2. **What is the video about?** (subject, story, product)

Extracted rules inside block: 67d38a7b6dfb

## 183eb2f3fe3148ba — ai-video-storyboard/SKILL.md:34-34 (list_item)

3. **Brand vibe / tone?** (cozy, energetic, premium, minimalist, playful, cinematic, etc.)

Extracted rules inside block: 235fb6985a11

## 3eaa3c6036645444 — ai-video-storyboard/SKILL.md:35-35 (list_item)

4. **Call to action at the end?** (visit website, buy product, follow channel, etc.)

Extracted rules inside block: f55b9c32aa03
