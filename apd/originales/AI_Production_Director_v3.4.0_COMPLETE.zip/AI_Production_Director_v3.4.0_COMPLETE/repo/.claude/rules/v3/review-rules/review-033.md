# Rule classification review 33/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## af35f9995402 — visual-prompt-forge/adapters/kling.md:26

`negative_prompt` | per series | Supported. Use to suppress drift, e.g. `extra fingers, warped face`

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "af35f9995402",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "kling"
      }
    ]
  }
}
```

## e4ce642461b9 — visual-prompt-forge/adapters/kling.md:37

Kling handles **80–150 words** comfortably. Motion description adds a beat over a still prompt; do not pad past it.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "e4ce642461b9",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "kling"
      }
    ]
  }
}
```

## ecdd25e57ae8 — visual-prompt-forge/adapters/kling.md:73

Use `start_image` from the previous shot's accepted final frame to chain a sequence.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "ecdd25e57ae8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "kling"
      }
    ]
  }
}
```

## c980bc88fe2f — visual-prompt-forge/adapters/kling.md:75

Do not flip lighting direction between consecutive shots (window-left stays window-left).

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "c980bc88fe2f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "kling"
      }
    ]
  }
}
```

## d119a91eb4da — visual-prompt-forge/adapters/kling.md:80

**Don't put camera motion at the end.** Kling parses motion best as the leading instruction.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d119a91eb4da",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "kling"
      }
    ]
  }
}
```

## 17f1e0e985f1 — visual-prompt-forge/adapters/kling.md:81

**Don't request multiple camera moves in one shot.** Pick one; compound moves break.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "17f1e0e985f1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "kling"
      }
    ]
  }
}
```

## 1f484f032e34 — visual-prompt-forge/adapters/kling.md:82

**Don't describe motion faster than the duration allows.** A slow dolly over 5s is plausible; over 1s it is jitter.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "1f484f032e34",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "kling"
      }
    ]
  }
}
```

## 2990335b6104 — visual-prompt-forge/adapters/kling.md:83

**Don't include text content.** Video text rendering is unreliable; composite or animate text in post.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "2990335b6104",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "kling"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 43a5c5255db1 — visual-prompt-forge/adapters/kling.md:84

**Don't expect frame-perfect character match between clips.** Budget editorial cleanup.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "43a5c5255db1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "kling"
      }
    ]
  }
}
```

## 44ca5e7fd558 — visual-prompt-forge/adapters/midjourney.md:3

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "44ca5e7fd558",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "midjourney"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## e44be687a773 — visual-prompt-forge/adapters/midjourney.md:17

Param | Values | Default to use | Notes

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "e44be687a773",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "midjourney"
      }
    ]
  }
}
```

## 24176401572f — visual-prompt-forge/adapters/midjourney.md:22

`--c` | 0–100 | omit | Chaos. Use only when exploring variations

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "24176401572f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "midjourney"
      }
    ]
  }
}
```

## b0e02b79237d — visual-prompt-forge/adapters/midjourney.md:24

`--cref` | image URL | use when character anchor exists | Character reference. Pair with `--cw`

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "b0e02b79237d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "midjourney"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## e0387c3e5469 — visual-prompt-forge/adapters/midjourney.md:26

`--sref` | image URL | use when style anchor exists | Style reference

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "e0387c3e5469",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "midjourney"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## fbaaf26aa19d — visual-prompt-forge/adapters/midjourney.md:43

`shallow DOF` | `shallow depth of field, f/1.8, bokeh background`

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "fbaaf26aa19d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "midjourney"
      }
    ]
  }
}
```

## 0e74583e51d6 — visual-prompt-forge/adapters/midjourney.md:97

**Don't use "AI" or "rendered"**, produces stylized outputs that look generated

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "0e74583e51d6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "midjourney"
      }
    ]
  }
}
```

## a4bcaa489903 — visual-prompt-forge/adapters/midjourney.md:98

**Don't over-stack adjectives**, three adjectives per noun phrase max

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "a4bcaa489903",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "midjourney"
      }
    ]
  }
}
```

## eb4ca17e9715 — visual-prompt-forge/adapters/midjourney.md:99

**Don't include text content**, even if the shot has `on_screen_text`, leave it out. Composited separately.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "eb4ca17e9715",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "midjourney"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 149b2ccce82a — visual-prompt-forge/adapters/midjourney.md:100

**Don't use `--c` for series work**, chaos kills consistency

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "149b2ccce82a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "midjourney"
      }
    ]
  }
}
```

## b5165b607997 — visual-prompt-forge/adapters/midjourney.md:101

**Don't change `--seed` mid-storyboard**, set once at series_lock level

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "b5165b607997",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "midjourney"
      }
    ]
  }
}
```

## 9832346eb9f4 — visual-prompt-forge/adapters/midjourney.md:105

Midjourney still has limited API access as of Q2 2026. For programmatic workflows, the prompts in `midjourney.txt` are designed to be pasted into Discord or the web UI. Some teams use third-party wrappers (PiAPI, Useapi.net), those generally accept the same prompt syntax.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "9832346eb9f4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "midjourney"
      }
    ]
  }
}
```

## acaf6c8fcbbf — visual-prompt-forge/adapters/nano-banana.md:3

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "acaf6c8fcbbf",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "nano_banana"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 9e29e2774dcd — visual-prompt-forge/adapters/nano-banana.md:5

Google's Nano Banana model (`gemini-2.5-flash-image`) is the edit-and-iterate champion. Where other generators are best for first-frame creation, Nano Banana excels at variations, inpainting, and reference-based modification. The 2026 production pattern is to generate hero frames in Midjourney or Flux, then use Nano Banana for variants.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "9e29e2774dcd",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "nano_banana"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 908dfc533de5 — visual-prompt-forge/adapters/nano-banana.md:69

**Use case:** generated `shot_03` in Flux, want a variant where the founder is looking directly at camera

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "908dfc533de5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 29960d0fa551 — visual-prompt-forge/adapters/nano-banana.md:80

Generate hero shot in Midjourney or Flux (one prompt → one image)

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "29960d0fa551",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 60179dcf24ec — visual-prompt-forge/adapters/nano-banana.md:81

Feed that image to Nano Banana with variation prompts

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "60179dcf24ec",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 416f3b7ab854 — visual-prompt-forge/adapters/nano-banana.md:82

Get 4–8 variants of the same shot for editorial selection

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "416f3b7ab854",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 557b754e72e7 — visual-prompt-forge/adapters/nano-banana.md:83

Composite text on the chosen variant

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "557b754e72e7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "nano_banana"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 31a65699308b — visual-prompt-forge/adapters/nano-banana.md:88

A modification template comment showing how to use the result for variants:

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "31a65699308b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 468653f75140 — visual-prompt-forge/adapters/nano-banana.md:101

**Don't use Midjourney-style flag syntax**. Nano Banana ignores `--ar`, expects `aspectRatio` parameter

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "468653f75140",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## f795b44d5d19 — visual-prompt-forge/adapters/nano-banana.md:102

**Don't expect Midjourney-level aesthetic by default**. Nano Banana is a workhorse, not a stylist. Stack mood adjectives explicitly

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "f795b44d5d19",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 9a7a4569d7d4 — visual-prompt-forge/adapters/nano-banana.md:103

**Don't pile multiple modifications in one image-to-image prompt**, one change per pass produces cleaner results

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "9a7a4569d7d4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## c9cfe10ba5a7 — visual-prompt-forge/adapters/nano-banana.md:104

**Don't forget the "preserve" clause in image-to-image**, without it, Nano Banana treats the reference as loose inspiration and drifts

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "c9cfe10ba5a7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "nano_banana"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## f140dceba074 — visual-prompt-forge/adapters/nano-banana.md:105

**Don't include text content in image prompts**, composite separately; text rendering is mediocre

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "f140dceba074",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "nano_banana"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 6f11bad3f095 — visual-prompt-forge/adapters/seedance.md:3

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the tw

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "6f11bad3f095",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "stage",
            "value": "prompt"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "seedance"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```
