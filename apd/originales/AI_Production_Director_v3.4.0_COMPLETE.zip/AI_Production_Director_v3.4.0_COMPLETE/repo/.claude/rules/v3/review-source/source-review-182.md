# Source coverage review 182/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## a818e3b22793cdae — video/references/universal-rules.md:148-148 (list_item)

- "Ends on his face frozen in the blue refrigerator light" beats "he stands there sadly."

Extracted rules inside block: NONE

## c1ee3293805d3aeb — video/references/universal-rules.md:150-150 (paragraph)

The final image is also one of the five anchors (see `dramaturgy.md` §13). Naming it is non-negotiable.

Extracted rules inside block: NONE

## d82717ac1d5836ce — video/references/universal-rules.md:152-152 (heading)

## 13. U12. The three-detail check (audit before sending)

Extracted rules inside block: NONE

## 80af23e6c6521495 — video/references/universal-rules.md:154-154 (paragraph)

Before returning the final prompt to the user, audit every shot. Each shot must carry at least one of each:

Extracted rules inside block: a456f58cceb1

## c4a38a4ce39651e4 — video/references/universal-rules.md:156-156 (list_item)

1. Environmental pressure (lighting, weather, surface, sound of the room).

Extracted rules inside block: 9bbbba9c169b

## bae2861afeb64356 — video/references/universal-rules.md:157-157 (list_item)

2. Physical micro-action on the body (jaw, hand, breath, eye, gesture).

Extracted rules inside block: 2e4c3ddce4f4

## 345a81d474a02522 — video/references/universal-rules.md:158-158 (list_item)

3. Sound anchor or recurring visual motif tied to the emotional spine.

Extracted rules inside block: 5c7f7a14d776

## eabc2481ae83a425 — video/references/universal-rules.md:160-160 (paragraph)

If a shot has zero, fix it before sending. If a shot has only one, ask whether you can make it two without bloat. The strongest prompts in this skill's worked examples always have all three.

Extracted rules inside block: e1c3494d28e1

## 107f1e1d1369bbf2 — video/references/universal-rules.md:162-162 (paragraph)

Empty descriptors that fail this check: "establishing wide shot", "beautiful lighting", "dynamic camera move", "cinematic look", "intense moment", "dramatic close-up". Replace each with three concrete physical facts.

Extracted rules inside block: NONE

## 9708fe80b8cd0b21 — video/references/universal-rules.md:164-164 (heading)

## 14. U13. Reference role discipline

Extracted rules inside block: NONE

## 1bed61f69e3169f3 — video/references/universal-rules.md:166-166 (paragraph)

Wherever a model accepts reference assets (Seedance `@Image/@Video/@Audio`, Kling Element Binding and Omni references, Veo ingredients), **every asset gets an explicit role written in the prompt**: what it defines (appearance, motion, voice, scene, camera path) and what to ignore ("Do not use the image background", "Do not use the people in the image").

Extracted rules inside block: ac9249e40b1b

## efbda4fd85505c8f — video/references/universal-rules.md:168-168 (list_item)

- Bind each subject individually: "<Character A> corresponds to @Image 1 — use only the appearance, hairstyle, and clothing." Never the collective form "@Images 1 through 4 define four characters respectively" — it does not state which is which.

Extracted rules inside block: 7b2b085fe6e3

## aae1faeb14194fa0 — video/references/universal-rules.md:169-169 (list_item)

- Do not restate what a reference already defines. If a video reference carries the motion, name only the attributes to inherit; re-describing every action fights the reference.

Extracted rules inside block: bc8d7e32c52d

## 35b9b6278644c26b — video/references/universal-rules.md:170-170 (list_item)

- More assets is not more control. Control comes from role clarity; unassigned assets bleed into the frame.

Extracted rules inside block: NONE

## f5da1bc51aed477f — video/references/universal-rules.md:172-172 (paragraph)

Model-specific limits and templates live in the model files (`seedance-25.md` §5 has the fullest system).

Extracted rules inside block: NONE

## 68316dab69f623f3 — video/references/universal-rules.md:174-174 (heading)

## 15. U14. Priority declaration

Extracted rules inside block: NONE

## 20df777f827db4b1 — video/references/universal-rules.md:176-176 (paragraph)

When a prompt is overloaded (10+ scenes, many subjects, spatial tricks), adding more description makes it worse. Instead, declare priorities — the model cannot know what matters most unless told what to protect and what to sacrifice:

Extracted rules inside block: NONE

## 22410c385e28729f — video/references/universal-rules.md:178-178 (list_item)

1. The core subject that must survive every shot.

Extracted rules inside block: 2f7eab68841b

## ba2662be90ee8db7 — video/references/universal-rules.md:179-179 (list_item)

2. The key shots that must appear.

Extracted rules inside block: 0348af1beb35

## b2e3d824e95a0ebc — video/references/universal-rules.md:180-180 (list_item)

3. The transitions where the model may freestyle.

Extracted rules inside block: 607c6a3be096

## ee56e7c782244521 — video/references/universal-rules.md:181-181 (list_item)

4. The mandatory final frame.

Extracted rules inside block: 7503bd83569f

## e66e273b71631300 — video/references/universal-rules.md:183-183 (paragraph)

This ranks above prompt-length discipline: a shorter prompt with declared priorities beats a longer one without them.

Extracted rules inside block: NONE

## 2055bd1636a677bc — video/references/universal-rules.md:187-187 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 541e9e8f52dea242 — video/references/veo.md:1-1 (heading)

# Veo reference (Google)

Extracted rules inside block: NONE

## e0be1a279cca6d55 — video/references/veo.md:3-3 (heading)

## Contents

Extracted rules inside block: NONE

## ae82f51911130262 — video/references/veo.md:5-5 (list_item)

1. What Veo is

Extracted rules inside block: NONE

## 70ea9fb497bc7288 — video/references/veo.md:6-6 (list_item)

2. Versions and specs

Extracted rules inside block: 491e314764cf

## cae1c2c9c0c0d44f — video/references/veo.md:7-7 (list_item)

3. Prompt structure and length

Extracted rules inside block: b99a6bf078f0

## 742f8d6cc3a08636 — video/references/veo.md:8-8 (list_item)

4. Dialogue syntax (critical, unique)

Extracted rules inside block: f67af642ce3c

## 3a2b9489fcfe2591 — video/references/veo.md:9-9 (list_item)

5. SFX syntax

Extracted rules inside block: NONE
