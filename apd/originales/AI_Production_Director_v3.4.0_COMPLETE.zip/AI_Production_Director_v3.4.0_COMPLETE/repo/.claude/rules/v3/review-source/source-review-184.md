# Source coverage review 184/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 1384415e9d589c6a — video/references/veo.md:85-85 (paragraph)

Three supported formats. Mix as needed.

Extracted rules inside block: NONE

## 35b45bf85b2e5704 — video/references/veo.md:87-93 (code)

```text
SFX: thunder cracks in the distance
Audio: rain on tin roof, distant traffic, one slow breath
(a loud thunderclap)
(key turning in a lock)
(wet footsteps on concrete)
```

Extracted rules inside block: NONE

## 4c67a4c73557892d — video/references/veo.md:95-95 (paragraph)

Use labels `Audio:`, `Says:`, `SFX:` to separate sound direction from visual direction. The model needs an explicit signal that audio should be generated.

Extracted rules inside block: 0969d42b5ba5

## 834a12414744e32f — video/references/veo.md:97-97 (heading)

## 6. JSON prompts (powerful, unique)

Extracted rules inside block: NONE

## 200483166e94ec73 — video/references/veo.md:99-99 (paragraph)

Veo parses structured JSON. This prevents "concept bleed" where describing mood accidentally changes object colors. Use JSON for complex scenes with strict continuity needs.

Extracted rules inside block: d7e4c650f352

## e0e71b1043fbe983 — video/references/veo.md:101-101 (heading)

### Full schema

Extracted rules inside block: NONE

## b39dd409c33bd8ef — video/references/veo.md:103-159 (code)

```json
{
  "version": "veo-3.1",
  "output": {
    "duration_sec": 8,
    "fps": 24,
    "resolution": "1080p",
    "aspect_ratio": "16:9"
  },
  "global_style": {
    "look": "cinematic naturalism",
    "color": "cold blue-gray palette, desaturated skin",
    "mood": "quiet domestic tragedy",
    "reference": "Fincher-style motivated camera"
  },
  "continuity": {
    "characters": [
      {
        "id": "man",
        "description": "40s, tired eyes, stubble, dark blue t-shirt, grey sweatpants, barefoot"
      }
    ],
    "props": ["empty refrigerator", "single sausage", "chipped white plate"],
    "lighting_constant": "cold fridge light as key"
  },
  "scenes": [
    {
      "id": "01",
      "start": "0.0",
      "end": "3.0",
      "shot": {
        "type": "medium close-up",
        "framing": "eye-level, slightly offset",
        "camera": "slow push-in, 50mm"
      },
      "action": "He opens the fridge. His face catches the cold light. His eyes stop on the empty shelf.",
      "environment": "small kitchen, 3am, rain outside window",
      "lighting": "cold fridge light as key, warm window spill as rim",
      "audio": "fridge hum, distant rain, one stomach growl"
    },
    {
      "id": "02",
      "start": "3.0",
      "end": "8.0",
      "shot": {
        "type": "extreme close-up",
        "framing": "macro insert on hand",
        "camera": "static, 100mm macro"
      },
      "action": "His hand hovers over a single sausage. He picks it up slowly, exhales.",
      "environment": "inside the fridge",
      "lighting": "cold fridge light, high contrast",
      "audio": "quiet breath, soft plastic crinkle"
    }
  ]
}
```

Extracted rules inside block: NONE

## e62e0e0c4a4161c4 — video/references/veo.md:161-161 (heading)

### When to use JSON

Extracted rules inside block: NONE

## ebffa6438b6f1c11 — video/references/veo.md:163-163 (list_item)

- Multiple scenes in one generation.

Extracted rules inside block: NONE

## 8d1ce348db9d26b7 — video/references/veo.md:164-164 (list_item)

- Strict character continuity across shots.

Extracted rules inside block: NONE

## df54e338eb097115 — video/references/veo.md:165-165 (list_item)

- Complex props that must stay the same color and size.

Extracted rules inside block: 9ce91ea633ed

## 764b082852554674 — video/references/veo.md:166-166 (list_item)

- When a prose prompt kept changing subject colors when you added mood words.

Extracted rules inside block: NONE

## 87fc5a5421e92b13 — video/references/veo.md:168-168 (paragraph)

Not every Veo prompt needs JSON. For simple clips, prose is faster and often better.

Extracted rules inside block: NONE

## 433b760d6a6e5572 — video/references/veo.md:170-170 (heading)

## 7. Image-to-video (Veo 3.1)

Extracted rules inside block: NONE

## 91cf7464f785e982 — video/references/veo.md:172-172 (paragraph)

Uses the static image as First Frame. Prompt guides motion and sound.

Extracted rules inside block: NONE

## cbaa1513d8dfaa1e — video/references/veo.md:174-174 (paragraph)

Rules.

Extracted rules inside block: NONE

## 7998f74d170a4b2b — video/references/veo.md:176-176 (list_item)

- Do not re-describe static elements.

Extracted rules inside block: e0e07e208a4d

## f1dcf12793ac34da — video/references/veo.md:177-177 (list_item)

- Describe only motion, camera, light change, and audio.

Extracted rules inside block: NONE

## c709473bce5d9912 — video/references/veo.md:178-178 (list_item)

- Add "maintain the subject from the first frame" to protect identity.

Extracted rules inside block: NONE

## 46ba3fada884f9db — video/references/veo.md:180-180 (paragraph)

Example.

Extracted rules inside block: NONE

## 0c9db5416ee25039 — video/references/veo.md:182-187 (code)

```text
Maintain the subject from the first frame. Slow push-in, 50mm. She exhales, her eyes shift to the left, one strand of hair falls across her forehead. Warm rim light grows stronger.

Audio: soft breath, distant traffic, one door closing in the next room.
Duration: 6 seconds.
```

Extracted rules inside block: NONE

## 109c42a32ff775fd — video/references/veo.md:189-189 (heading)

## 8. Reference ingredients (3.1)

Extracted rules inside block: NONE

## 69625a5bd398f448 — video/references/veo.md:191-191 (paragraph)

Upload multiple reference images (character, location, prop) and tag them in the prompt.

Extracted rules inside block: NONE

## 8a5eca9cf959affc — video/references/veo.md:193-195 (code)

```text
The character from reference_1 walks into the location from reference_2 holding the object from reference_3.
```

Extracted rules inside block: NONE

## ca395b660c0b626c — video/references/veo.md:197-197 (paragraph)

Use when you need a specific character in a specific place with a specific object.

Extracted rules inside block: 33f03210e633

## 1a244379cf5f566c — video/references/veo.md:199-199 (heading)

## 9. Failure modes and fixes

Extracted rules inside block: NONE

## b6e2645d6e209dd3 — video/references/veo.md:201-201 (heading)

### Dialogue speeds up unnaturally

Extracted rules inside block: NONE

## fbd2673e1e6da9ef — video/references/veo.md:203-203 (paragraph)

Fix. Cut the line to fit 8 seconds of natural speech. Test by reading aloud.

Extracted rules inside block: NONE

## ded848ae6db7bfb4 — video/references/veo.md:205-205 (heading)

### Audio missing from output

Extracted rules inside block: NONE

## a713ac85b82a1a3c — video/references/veo.md:207-207 (paragraph)

Fix. Add explicit `Audio:`, `SFX:`, or `Says:` labels. Do not assume the model will infer audio from visual description.

Extracted rules inside block: 346d483199ed
