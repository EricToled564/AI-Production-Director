# Source coverage review 138/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0a231d894a0eaacf — video/references/camera-lighting-vocabulary.md:189-191 (paragraph)

For Veo, wrap sound in syntax. `Audio:`, `SFX:`, or `(parenthetical description)`.
For Seedance 1.5+, include sound in the prompt body.
For Kling, sound descriptions help rhythm planning but audio is not generated.

Extracted rules inside block: NONE

## 4c9335a265e17264 — video/references/camera-lighting-vocabulary.md:193-193 (heading)

## 9. Blocking language

Extracted rules inside block: NONE

## a6fb4d4ad1a9423d — video/references/camera-lighting-vocabulary.md:195-195 (paragraph)

Describe physical movement with six inputs.

Extracted rules inside block: NONE

## 0407fa37d3252c2a — video/references/camera-lighting-vocabulary.md:197-197 (list_item)

- Who moves.

Extracted rules inside block: NONE

## 8c97857743b74bfd — video/references/camera-lighting-vocabulary.md:198-198 (list_item)

- Where they start.

Extracted rules inside block: NONE

## 51453f2106f0dcd1 — video/references/camera-lighting-vocabulary.md:199-199 (list_item)

- Where they end.

Extracted rules inside block: NONE

## 81462d66a17d91c4 — video/references/camera-lighting-vocabulary.md:200-200 (list_item)

- What object they touch.

Extracted rules inside block: NONE

## a63461dc1f6f6f74 — video/references/camera-lighting-vocabulary.md:201-201 (list_item)

- What they look at.

Extracted rules inside block: NONE

## f98932b98b117933 — video/references/camera-lighting-vocabulary.md:202-202 (list_item)

- What their body reveals emotionally.

Extracted rules inside block: NONE

## 13d735f0c5087c2d — video/references/camera-lighting-vocabulary.md:204-204 (paragraph)

Example.

Extracted rules inside block: NONE

## 20f705ef8e202a20 — video/references/camera-lighting-vocabulary.md:206-208 (code)

```text
The man stands in the kitchen doorway, shoulders collapsed. He slowly approaches the refrigerator, opens it with hesitation, leans into the cold light, then freezes when he sees the empty shelves.
```

Extracted rules inside block: NONE

## f10aac458d11ab1b — video/references/camera-lighting-vocabulary.md:210-210 (paragraph)

This beats "a sad man goes to the fridge" because it is playable by the model frame by frame.

Extracted rules inside block: NONE

## ae442b39561febdb — video/references/camera-lighting-vocabulary.md:212-212 (heading)

## 10. Translating uncommon terms

Extracted rules inside block: NONE

## b4f5397d82849414 — video/references/camera-lighting-vocabulary.md:214-214 (paragraph)

Common terms (section 2) work by name. For rarer cinematography terms, keep the term **and** translate it into observable change, or the model guesses:

Extracted rules inside block: NONE

## 1a5fc821c1091510 — video/references/camera-lighting-vocabulary.md:216-218 (code)

```text
Term + target subject + visual change + foreground/background relationship + direction or speed
```

Extracted rules inside block: NONE

## 429f1bb51551916b — video/references/camera-lighting-vocabulary.md:220-220 (paragraph)

Example.

Extracted rules inside block: NONE

## ff173f6fcc184dc8 — video/references/camera-lighting-vocabulary.md:222-226 (code)

```text
Rack focus: shift focus smoothly from the leaves in the foreground to the person
in the background. The leaves gradually blur while the person's face changes
from soft to sharp.
```

Extracted rules inside block: NONE

## fec242bbebeb4b80 — video/references/camera-lighting-vocabulary.md:228-228 (paragraph)

Same pattern for snorricam, contra-zoom variants, tilt-shift, split diopter, speed ramps with specific curves. Numeric aperture and focal-length values are allowed, but the intended visible result phrased in words is what actually steers the model.

Extracted rules inside block: NONE

## f146b0bd6316738f — video/references/camera-lighting-vocabulary.md:230-230 (heading)

## 11. Transition vocabulary

Extracted rules inside block: NONE

## adefdd11606fb386 — video/references/camera-lighting-vocabulary.md:232-232 (paragraph)

Named transitions every current model understands to some degree (Seedance 2.5 honors them explicitly — templates in `seedance-25.md` §10):

Extracted rules inside block: NONE

## 8e80deb0eab2afaf — video/references/camera-lighting-vocabulary.md:234-234 (list_item)

- **natural cut** — plain edit point, model picks the framing change

Extracted rules inside block: NONE

## 68e6bb7c4ce63fe1 — video/references/camera-lighting-vocabulary.md:235-235 (list_item)

- **fade in / fade out** — to or from black

Extracted rules inside block: NONE

## 13701cdf3549270f — video/references/camera-lighting-vocabulary.md:236-236 (list_item)

- **dissolve** — cross-fade, 1-2 seconds of overlap

Extracted rules inside block: NONE

## 390e93419ccb7abd — video/references/camera-lighting-vocabulary.md:237-237 (list_item)

- **white flash / black flash** — one-frame blast, impact punctuation

Extracted rules inside block: NONE

## 44d68e646a38a82f — video/references/camera-lighting-vocabulary.md:238-238 (list_item)

- **wipe** — new frame pushes the old one off

Extracted rules inside block: NONE

## af27875358ed9d4f — video/references/camera-lighting-vocabulary.md:239-239 (list_item)

- **occlusion mask** — a foreground object covers the lens, the new scene is revealed behind it

Extracted rules inside block: NONE

## c4051cd5285ee8f0 — video/references/camera-lighting-vocabulary.md:240-240 (list_item)

- **match cut** — similar shape or motion bridges two scenes (moon → latte)

Extracted rules inside block: NONE

## e467570fbd356a71 — video/references/camera-lighting-vocabulary.md:241-241 (list_item)

- **action cut / whip pan** — cut hidden inside fast motion with motion blur

Extracted rules inside block: NONE

## 743377edc3c24688 — video/references/camera-lighting-vocabulary.md:242-242 (list_item)

- **motion relay** — subject exits frame A mid-move and lands in frame B continuing it

Extracted rules inside block: NONE

## a6d51f0336b0428a — video/references/camera-lighting-vocabulary.md:243-243 (list_item)

- **zoom-through** — camera dives through a pupil, keyhole or window into the next scene

Extracted rules inside block: NONE
