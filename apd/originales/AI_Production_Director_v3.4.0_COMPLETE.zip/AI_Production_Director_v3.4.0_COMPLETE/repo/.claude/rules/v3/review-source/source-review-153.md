# Source coverage review 153/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## e1115ed2737f7d12 — video/references/kling.md:99-99 (paragraph)

**P1. Structured naming.** Use unique identifiers per character.

Extracted rules inside block: 59ffc548d80b

## 5c600bc19ae69249 — video/references/kling.md:100-100 (list_item)

- ✓ `[Character A: Black-suited Agent]` and `[Character B: Female Assistant]`

Extracted rules inside block: NONE

## 68280940074cdbbb — video/references/kling.md:101-101 (list_item)

- ✗ "[Agent] says... Then, he says..."

Extracted rules inside block: NONE

## 21c99b37b21b0f41 — video/references/kling.md:103-103 (paragraph)

**P2. Visual anchoring before dialogue.** Bind dialogue to a unique action first.

Extracted rules inside block: NONE

## 4c7db76aa599dfd1 — video/references/kling.md:104-104 (list_item)

- ✓ "Character A pulls a folded note from his pocket and reads aloud: 'It's not what you think.'"

Extracted rules inside block: NONE

## 9a0a1b65e34763d8 — video/references/kling.md:105-105 (list_item)

- ✗ "Character A says 'It's not what you think.'" (no visual anchor → lip-sync drifts)

Extracted rules inside block: NONE

## 7c8777d7b79a8143 — video/references/kling.md:107-107 (paragraph)

**P3. Voice tone in the tag.** Assign emotion / texture inline.

Extracted rules inside block: NONE

## 65e16333e14fda94 — video/references/kling.md:108-108 (list_item)

- ✓ `[Character A, raspy deep voice]: "We're out of time."`

Extracted rules inside block: NONE

## 542d457aed5bbc6e — video/references/kling.md:109-109 (list_item)

- ✓ `[Character B, clear fearful voice]: "Don't open it."`

Extracted rules inside block: da0fc68e8dd9

## 9065158a9fe4ed6a — video/references/kling.md:110-110 (list_item)

- ✗ `[Man]: "We're out of time."` (vague — model picks a generic voice)

Extracted rules inside block: NONE

## 8705b39022b611b8 — video/references/kling.md:112-112 (paragraph)

**P4. Temporal control between lines.** Use linking words to prevent dialogue from merging.

Extracted rules inside block: dc85223a44fb

## a53f555c3ff568e8 — video/references/kling.md:113-113 (list_item)

- ✓ "Character A: 'I won't ask again.' **Immediately,** Character B: 'You don't have to.'"

Extracted rules inside block: a5d7577a0589

## 779df9232f8ff33c — video/references/kling.md:114-114 (list_item)

- ✗ Two consecutive `[Character X]: "..."` lines with no transition (model overlaps them)

Extracted rules inside block: NONE

## 1ced040487bda449 — video/references/kling.md:116-116 (heading)

### Image-to-video on 3.0 — lock first, then move

Extracted rules inside block: NONE

## 349d58dddc9841e5 — video/references/kling.md:118-118 (paragraph)

The input image serves as the anchor for identity, layout, and on-image text. Keep the prompt short and motion-focused. Describe **how the scene evolves from the image**, not what is in the image.

Extracted rules inside block: NONE

## a94ae4b41deb3f4d — video/references/kling.md:120-126 (code)

```text
Preserve identity, wardrobe, and the storefront sign exactly.
[Character A: same person from the image]
Shot 1 (0-2s). She turns her head toward camera, exhales.
Shot 2 (2-5s). Slow push-in to a tight close-up. Wind catches her hair.
Audio. Distant traffic, wind through awnings, a soft bell from inside the shop.
```

Extracted rules inside block: NONE

## bfa6e93a69ccc5c8 — video/references/kling.md:128-128 (heading)

### Cinematic vocabulary that 3.0 actually understands

Extracted rules inside block: NONE

## 5be03ef44717f716 — video/references/kling.md:130-130 (paragraph)

Use these terms directly — the model treats them as instructions, not flavor:

Extracted rules inside block: 6221f7167d75

## e5c6b8e61e8c7e28 — video/references/kling.md:132-132 (list_item)

- Framing: profile shot, three-quarter, macro insert, two-shot, OTS, POV, low angle, high angle, Dutch

Extracted rules inside block: NONE

## 6615c91da5d7ebcd — video/references/kling.md:133-133 (list_item)

- Edits: shot-reverse-shot, match cut, smash cut, J-cut, L-cut

Extracted rules inside block: NONE

## e87a05893f6dd0f5 — video/references/kling.md:134-134 (list_item)

- Camera moves: tracking, dolly, push-in, pull-out, whip pan, crane, handheld, orbital / 360 spin, Steadicam, drone-like aerial. Composites work: "pan right while tilting up".

Extracted rules inside block: NONE

## c601d2e5d379ecf7 — video/references/kling.md:135-135 (list_item)

- Lens feel: 35mm, 50mm, 85mm, 100mm macro, anamorphic 40mm

Extracted rules inside block: NONE

## bedd9a6a118428d9 — video/references/kling.md:136-136 (list_item)

- Tempo words the model obeys: "ultra-slow motion" (2-3s feel), "slow and deliberate" (5-8s), "moderate" (3-5s), "quick snap" (1-2s); exact timing works too ("5-second dolly zoom").

Extracted rules inside block: NONE

## 3c8cce6cafac2c19 — video/references/kling.md:137-137 (list_item)

- Angle carries emotion: low angle = dominance, high angle = vulnerability, eye-level = neutral. Pick per the power dynamic from `dramaturgy.md` §6, not at random.

Extracted rules inside block: NONE

## 37833bf11a62922a — video/references/kling.md:138-138 (list_item)

- In the Kling app, Master Shot presets ("Move Forward and Zoom Up" etc.) are more stable than hand-written camera prose and save credits — prefer them for standard moves, prose for motivated ones.

Extracted rules inside block: 9ac08058462a

## db6dbfff65b060d9 — video/references/kling.md:140-140 (heading)

### Default model choice

Extracted rules inside block: NONE

## 57fabc86003b5d52 — video/references/kling.md:142-142 (paragraph)

If the task hits any of these — **use Kling 3.0 over earlier Kling**:

Extracted rules inside block: 61061e45ea3b

## 5c62599a7d26dcea — video/references/kling.md:143-143 (list_item)

- Multi-shot dialogue scenes

Extracted rules inside block: NONE

## 52c0f896a672de48 — video/references/kling.md:144-144 (list_item)

- 10-15s continuous narrative

Extracted rules inside block: NONE

## a67780043b045eed — video/references/kling.md:145-145 (list_item)

- Lip-sync required

Extracted rules inside block: f901e5a78d6e
