# Source coverage review 112/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## b2dd3dcc2196b3b1 — storyboard-architect/references/beat-frameworks.md:54-54 (paragraph)

Use when: opinion videos, kinetic-type pieces, social-native commentary.

Extracted rules inside block: ba635bd0245c

## 6f2d5453ec3ab795 — storyboard-architect/references/beat-frameworks.md:56-56 (heading)

## Educational Demo

Extracted rules inside block: NONE

## a2da4ec3cbdf33c2 — storyboard-architect/references/beat-frameworks.md:58-58 (paragraph)

Default for how-to content. Four beats:

Extracted rules inside block: NONE

## f9560819ad849652 — storyboard-architect/references/beat-frameworks.md:60-60 (list_item)

1. **Problem state**, what someone is stuck on

Extracted rules inside block: 35fbbd15e1b3

## 7bd8b3f93575b7e9 — storyboard-architect/references/beat-frameworks.md:61-61 (list_item)

2. **Reveal**, the technique or trick

Extracted rules inside block: a9fb2aab621e

## 22e0ceeb15f05ee9 — storyboard-architect/references/beat-frameworks.md:62-62 (list_item)

3. **Walk-through**, apply it step by step

Extracted rules inside block: 8a0c08b65d5f

## 178d35af5a00512b — storyboard-architect/references/beat-frameworks.md:63-63 (list_item)

4. **Result**, the after-state, side-by-side with before

Extracted rules inside block: 6a20a14985f4

## 3e6416e42d0ebfd7 — storyboard-architect/references/beat-frameworks.md:65-65 (paragraph)

Use when: tutorials, demo videos, training content.

Extracted rules inside block: 687be98287e5

## 44783fd6d47cfd45 — storyboard-architect/references/beat-frameworks.md:67-67 (heading)

## Custom

Extracted rules inside block: NONE

## b4b856c7a71ef9ef — storyboard-architect/references/beat-frameworks.md:69-69 (paragraph)

If the brief doesn't fit, build a custom beat structure. Document in `storyboard.md`:

Extracted rules inside block: NONE

## 706f226570307b62 — storyboard-architect/references/beat-frameworks.md:71-79 (code)

```markdown
## Beat framework: Custom

**Why custom:** [one sentence, what made the standard frameworks insufficient]

**Beats:**
1. [name], [purpose], [duration]
2. ...
```

Extracted rules inside block: NONE

## b187fab7c3052695 — storyboard-architect/references/beat-frameworks.md:81-81 (paragraph)

Custom is a last resort, not a first move. The standard frameworks exist because they work.

Extracted rules inside block: NONE

## 420583381b2c4e3b — storyboard-architect/references/on-screen-text.md:1-1 (heading)

# On-Screen Text

Extracted rules inside block: NONE

## cf5d3144b3c7a0fd — storyboard-architect/references/on-screen-text.md:3-3 (paragraph)

Text on screen is a load-bearing decision. Most storyboards over-text. The default should be: **does this shot need text to land?** If the visual carries the meaning, text dilutes.

Extracted rules inside block: f9e5dcaaaa02

## dad8c2ff88e76075 — storyboard-architect/references/on-screen-text.md:5-5 (heading)

## When on-screen text earns its keep

Extracted rules inside block: NONE

## e50661524d9a1439 — storyboard-architect/references/on-screen-text.md:7-7 (list_item)

1. **Auto-play-mute environments.** Social feeds. Text replaces VO.

Extracted rules inside block: d2b2ebc73fa9

## 3b0f77efb807fee6 — storyboard-architect/references/on-screen-text.md:8-8 (list_item)

2. **Concept compression.** A short phrase lands harder than 4 seconds of narration.

Extracted rules inside block: 369445ef83f9

## 4f55e3fa9ba7ccc9 — storyboard-architect/references/on-screen-text.md:9-9 (list_item)

3. **Stat or proof point.** Numbers stick visually in a way they don't audibly.

Extracted rules inside block: e6c27fccb2b5

## 0283ad6c343cea79 — storyboard-architect/references/on-screen-text.md:10-10 (list_item)

4. **Beat punctuation.** A single word or phrase that lands on a music hit.

Extracted rules inside block: 9b8eb95e69af

## 79cf663bc09ce800 — storyboard-architect/references/on-screen-text.md:11-11 (list_item)

5. **CTA.** The action you want the viewer to take.

Extracted rules inside block: 64fc2fc12611

## fd4d3e8118f63a50 — storyboard-architect/references/on-screen-text.md:13-13 (heading)

## When on-screen text doesn't earn its keep

Extracted rules inside block: NONE

## fbff52d080c2a9cb — storyboard-architect/references/on-screen-text.md:15-15 (list_item)

1. **Restating the VO.** If the voice says it, the text is noise.

Extracted rules inside block: f55830225e9a

## e92610936c321bb0 — storyboard-architect/references/on-screen-text.md:16-16 (list_item)

2. **Decorative copy.** "Moments matter" floating over b-roll. Cut it.

Extracted rules inside block: e13b1d3fa429

## 46eb204be0ebee44 — storyboard-architect/references/on-screen-text.md:17-17 (list_item)

3. **Brand vibing.** Product names everywhere. Logo lockup in the CTA covers this.

Extracted rules inside block: fef02a2ade15

## 7afce519f80694b9 — storyboard-architect/references/on-screen-text.md:18-18 (list_item)

4. **Filler beats.** If the shot doesn't need text, leave it clean.

Extracted rules inside block: a228b38d9594

## 14ddf433106f417d — storyboard-architect/references/on-screen-text.md:20-20 (heading)

## Composition rules

Extracted rules inside block: NONE

## 05027cb3e887c5eb — storyboard-architect/references/on-screen-text.md:22-22 (paragraph)

These flow into the `position` field of each text overlay.

Extracted rules inside block: NONE

## 45c644311be0428e — storyboard-architect/references/on-screen-text.md:24-24 (heading)

### Negative-space-aware composition

Extracted rules inside block: NONE

## bb28a5e2e50b1a50 — storyboard-architect/references/on-screen-text.md:26-26 (paragraph)

When a shot has on-screen text, the **shot subject must reserve space for it**. This is enforced at storyboard time, not generation time.

Extracted rules inside block: 286174f4bd6c

## f3b799cd1abc06a0 — storyboard-architect/references/on-screen-text.md:28-30 (paragraph)

If text is in the right third → subject composition leaves the right third clear.
If text is lower third → subject upper two-thirds.
If text is centered → subject framed to negative space around center.

Extracted rules inside block: NONE
