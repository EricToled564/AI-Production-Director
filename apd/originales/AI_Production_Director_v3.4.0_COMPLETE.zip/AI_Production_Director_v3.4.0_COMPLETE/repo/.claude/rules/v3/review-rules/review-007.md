# Rule classification review 7/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## 6881a6be17e2 — image/references/multi-panel.md:173

**When to use:** Fashion editorial or film-style sequence — multiple camera angles of the same scene in one image.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "6881a6be17e2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "base_type",
            "value": "MULTI"
          }
        ]
      },
      {
        "op": "in",
        "path": "operation",
        "value": [
          "image_edit",
          "image_to_image"
        ]
      }
    ]
  }
}
```

## ee9b74f9a7d8 — image/references/multi-panel.md:205

**Recommended size:** 1536x1024 (landscape, 3x2 grid)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "ee9b74f9a7d8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## 8ecc3dab1066 — image/references/multi-panel.md:209

Top-down and low-angle in the same grid confuse the model if you don't anchor each frame to a grid position

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "8ecc3dab1066",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## c652d8fa20e4 — image/references/multi-panel.md:210

Motion blur instruction must be specific ("blur on hands and feet") or the model applies blur everywhere

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "c652d8fa20e4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "base_type",
            "value": "MULTI"
          }
        ]
      },
      {
        "op": "eq",
        "path": "subject.hands_visible",
        "value": true
      },
      {
        "op": "eq",
        "path": "subject.feet_visible",
        "value": true
      }
    ]
  }
}
```

## 38de28fc48d0 — image/references/multi-panel.md:216

**When to use:** Product transformation, makeover, time comparison, renovation — two states side by side.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "38de28fc48d0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## a5ca2f339c15 — image/references/multi-panel.md:243

**Recommended size:** 1536x1024 (landscape — gives each half a portrait-like proportion)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "a5ca2f339c15",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## a775b2d2ebbe — image/references/multi-panel.md:244

**Model:** GPT Image 2 `quality: medium` — for text labels ("BEFORE" / "AFTER"), use `quality: high`

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "a775b2d2ebbe",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "base_type",
            "value": "MULTI"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 81194a49b6d3 — image/references/multi-panel.md:248

Left/right assignment matters — always state which side is before and which is after

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "81194a49b6d3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## b5a69994600b — image/references/multi-panel.md:254

**When to use:** Full narrative in one image — 3x4 grid (3 columns, 4 rows) for animation or video pre-production.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "b5a69994600b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## 5d289ee91997 — image/references/multi-panel.md:294

**Recommended size:** 1024x1536 (portrait — 3 columns x 4 rows needs vertical space)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "5d289ee91997",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## 21c88671420c — image/references/multi-panel.md:295

**Model:** GPT Image 2 `quality: high` (text-heavy — scene numbers and captions must be readable)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "21c88671420c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "base_type",
            "value": "MULTI"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 4438718fde9a — image/references/multi-panel.md:300

Art style must be stated once and applied uniformly; mixing styles across panels produces visual chaos

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "4438718fde9a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## b9796e26aa95 — image/references/multi-panel.md:308

**Subject consistency:** Always include an explicit instruction: "same person / same character / same product across all panels." Repeat key identity markers (hair color, clothing, distinguishing features) rather than saying "same as before."

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "b9796e26aa95",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "base_type",
            "value": "MULTI"
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 79125e381338 — image/references/multi-panel.md:310

**Grid specification:** Always state the grid dimensions (e.g., "3x2 grid, 3 columns 2 rows"). Saying "6 panels" without layout instruction lets the model choose an unpredictable arrangement.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "79125e381338",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "MULTI"
      }
    ]
  }
}
```

## 01542139be03 — image/references/nano-banana.md:24

Числовые параметры объектива: **50mm, 85mm, f/2.8, ISO 400** — NB игнорит. Используй описание: «shallow depth of field», «wide-angle distortion».

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "01542139be03",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## c7134d178923 — image/references/nano-banana.md:55

Включён по умолчанию; у NBP отключить нельзя (модель рисует до 2 «thought images» в бэкенде, они не тарифицируются как картинки, но thinking-токены платные). У NB2 есть рычаг `thinking_level: minimal | high` (default `minimal`) — поднимай до `high` для:

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "c7134d178923",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 809e69697b9b — image/references/nano-banana.md:102

Interactions API держит контекст сессии — до 3 последовательных правок стэкаются без потери исходника. Правило «Edit, don't re-roll»: картинка верна на 80% — проси точечное изменение, а не новую генерацию.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "809e69697b9b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "generator.family",
            "value": "nano_banana"
          }
        ]
      },
      {
        "op": "in",
        "path": "operation",
        "value": [
          "image_edit",
          "image_to_image"
        ]
      }
    ]
  }
}
```

## eea69f6a6d4c — image/references/nano-banana.md:130

**Хэндофф в видеомодель — motion brief, не пересказ.** Движение камеры, движение субъекта, движение фона, длительность, framing lock, запрещённые изменения. Видео-промпт не переописывает то, что уже есть в кадре.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "eea69f6a6d4c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 26385a1bd97c — image/references/nano-banana.md:137

Инфографика может содержать фактически неверные данные — цифры проверять всегда, grounding помогает, но не гарантирует.

Seed:
```json
{
  "authority": "MODEL_ADAPTER",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "26385a1bd97c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "generator.family",
        "value": "nano_banana"
      }
    ]
  }
}
```

## 7a23a22739e1 — image/references/patterns/character-design.md:9

Use for game or animation pre-production — front, side, and back views of a character on a single white canvas with color callouts and height reference lines.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "7a23a22739e1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "subject.human",
            "value": true
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 050355e5f639 — image/references/patterns/character-design.md:23

**Recommended model:** GPT Image 2 (`quality: high`) — height reference lines and color callout text require precise rendering

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "050355e5f639",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "subject.human",
            "value": true
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## bb01b41e7ff5 — image/references/patterns/character-design.md:29

Use to produce a grid of 6–9 facial expressions for the same character — consistent head angle and art style, with emotion labels under each face.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "bb01b41e7ff5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.human",
        "value": true
      }
    ]
  }
}
```

## 5294f7e75e43 — image/references/patterns/character-design.md:52

**Recommended model:** GPT Image 2 (`quality: high`) — text labels and consistent facial identity across 9 cells need precise control

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "5294f7e75e43",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "subject.human",
            "value": true
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 0aa0d010db93 — image/references/patterns/character-design.md:58

Use to show one character in multiple outfits or costumes — for fashion exploration, game skin concepts, or wardrobe design.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "0aa0d010db93",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.human",
        "value": true
      }
    ]
  }
}
```

## 9dd0c4a077a6 — image/references/patterns/character-design.md:80

**Recommended model:** GPT Image 2 (`quality: medium`) — character consistency is the priority; `high` only if outfit labels need fine legibility

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "9dd0c4a077a6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "subject.human",
            "value": true
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## e8c2e6289fa8 — image/references/patterns/character-design.md:86

Use to transform a realistic character into a cute 3D collectible figurine — oversized head, compact body, multiple poses performing different activities.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "e8c2e6289fa8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.human",
        "value": true
      }
    ]
  }
}
```

## 6aa23a563673 — image/references/patterns/character-design.md:108

**Recommended model:** GPT Image 2 (`quality: medium`) — smooth 3D vinyl surfaces render well at medium; `high` for marketing-ready close-ups

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "6aa23a563673",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.human",
        "value": true
      }
    ]
  }
}
```

## 402eddb3d3df — image/references/patterns/character-design.md:120

Use for a full character reference card with portrait, full body, key items, and color palette — organized on a white background in a professional concept art layout.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": "vocabulary.visual_style_quality",
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "402eddb3d3df",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "subject.human",
            "value": true
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## d0c1944e5b00 — image/references/patterns/character-design.md:140

**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout with hex codes, labels, and stat block requires precise rendering

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "d0c1944e5b00",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "subject.human",
            "value": true
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 96013c252397 — image/references/patterns/ecommerce.md:9

Use when you need a playful, attention-grabbing product visual where tiny workers interact with an oversized product — ideal for social media ads and launch campaigns.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "96013c252397",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.product_present",
        "value": true
      }
    ]
  }
}
```

## 87cb543ee901 — image/references/patterns/ecommerce.md:23

**Recommended model:** GPT Image 2 (`quality: high`) — precise figurine detail and product label legibility

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "87cb543ee901",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.product_present",
        "value": true
      }
    ]
  }
}
```

## 3f5c274f1636 — image/references/patterns/ecommerce.md:29

Use for premium beauty or fragrance product photography — dark, moody, tactile surfaces with atmospheric effects.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "3f5c274f1636",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.product_present",
        "value": true
      }
    ]
  }
}
```

## cae7f3b213d2 — image/references/patterns/ecommerce.md:43

**Recommended model:** GPT Image 2 (`quality: high`) — surface materials and condensation detail

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "cae7f3b213d2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.product_present",
        "value": true
      }
    ]
  }
}
```

## 34aa7ddfcd1b — image/references/patterns/ecommerce.md:51

Use to present a product commercial shot breakdown in a single image — pitch decks, creative presentations, client approvals.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "34aa7ddfcd1b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.product_present",
        "value": true
      }
    ]
  }
}
```

## c4e793a8fa86 — image/references/patterns/ecommerce.md:74

**Recommended model:** GPT Image 2 (`quality: high`) — grid precision and text in panel 9

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "c4e793a8fa86",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "subject.product_present",
            "value": true
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```
