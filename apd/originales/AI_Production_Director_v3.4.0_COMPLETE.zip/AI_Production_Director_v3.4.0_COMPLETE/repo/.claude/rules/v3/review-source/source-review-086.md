# Source coverage review 86/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5096442b1ecf54af — screenwriter/SKILL.md:267-267 (paragraph)

For detailed guidance on metadata standards, visual optimization, and integration with imagine/arch-v:

Extracted rules inside block: NONE

## b26d0487c59ecd0a — screenwriter/SKILL.md:268-268 (list_item)

- [references/pipeline-integration.md](references/pipeline-integration.md)

Extracted rules inside block: NONE

## 1a86a4c2bf7f8f6f — screenwriter/SKILL.md:270-270 (heading)

### Advanced Techniques

Extracted rules inside block: NONE

## 28a50a9a88c9bc88 — screenwriter/SKILL.md:271-271 (paragraph)

For sophisticated screenwriting techniques, camera movement hints, and pacing optimization:

Extracted rules inside block: NONE

## 194b5411e184ba9d — screenwriter/SKILL.md:272-272 (list_item)

- [references/advanced-techniques.md](references/advanced-techniques.md)

Extracted rules inside block: NONE

## 55e7c58320a1fae3 — screenwriter/references/advanced-techniques.md:1-1 (heading)

# Advanced Screenwriting Techniques

Extracted rules inside block: NONE

## 73833fa59e748df8 — screenwriter/references/advanced-techniques.md:3-3 (paragraph)

This reference covers sophisticated techniques for elevating screenplay quality and preparing for downstream video generation (arch-v integration).

Extracted rules inside block: NONE

## 2df090712d34885c — screenwriter/references/advanced-techniques.md:5-5 (heading)

## Table of Contents

Extracted rules inside block: NONE

## 460c04bd6e36a398 — screenwriter/references/advanced-techniques.md:6-6 (list_item)

1. [Camera Movement Hints (For Arch-V)](#camera-movement-hints-for-arch-v)

Extracted rules inside block: f3952d0415bc

## 214ec762e4e289ad — screenwriter/references/advanced-techniques.md:7-7 (list_item)

2. [Dialogue Polish Techniques](#dialogue-polish-techniques)

Extracted rules inside block: 5e60fade8fba

## abaab57b4f52f9d9 — screenwriter/references/advanced-techniques.md:8-8 (list_item)

3. [Pacing Optimization](#pacing-optimization)

Extracted rules inside block: 22d1bcd8b1d1

## a8142d14c4681be4 — screenwriter/references/advanced-techniques.md:9-9 (list_item)

4. [Advanced Visual Storytelling](#advanced-visual-storytelling)

Extracted rules inside block: 1239221531c7

## ed647951e5d9d333 — screenwriter/references/advanced-techniques.md:10-10 (list_item)

5. [Short Film Specific Techniques](#short-film-specific-techniques)

Extracted rules inside block: cd91c50ed19f

## 3d007ee216ee4282 — screenwriter/references/advanced-techniques.md:14-14 (heading)

## Camera Movement Hints (For Arch-V)

Extracted rules inside block: NONE

## 10b48e276b649808 — screenwriter/references/advanced-techniques.md:16-16 (paragraph)

While avoiding technical camera directions in action lines, you can *suggest* camera movement through visual description and scene structure.

Extracted rules inside block: f1e4fdcf19a5

## ec54c35f1401da9a — screenwriter/references/advanced-techniques.md:18-18 (heading)

### Suggesting Camera Movement Through Description

Extracted rules inside block: NONE

## 024fea70dd39c7af — screenwriter/references/advanced-techniques.md:20-20 (paragraph)

**Wide Establishing → Close Detail:**

Extracted rules inside block: NONE

## 8bfea8f2498dbd5a — screenwriter/references/advanced-techniques.md:21-25 (code)

```
The city sprawls below—a concrete jungle of steel and glass.

At street level, a single red balloon floats past graffitied walls.
```

Extracted rules inside block: NONE

## e1665e33ddba3bb7 — screenwriter/references/advanced-techniques.md:26-26 (paragraph)

*Implies: Wide establishing shot → close-up detail*

Extracted rules inside block: NONE

## fc479813dd07f5e6 — screenwriter/references/advanced-techniques.md:28-28 (paragraph)

**Following Movement:**

Extracted rules inside block: NONE

## 109e12fe261c472f — screenwriter/references/advanced-techniques.md:29-31 (code)

```
Maya runs down the alley, her footsteps echoing off brick walls. Trash cans blur past. The exit ahead grows larger.
```

Extracted rules inside block: NONE

## 9e89d18a0f49af90 — screenwriter/references/advanced-techniques.md:32-32 (paragraph)

*Implies: Tracking shot following character*

Extracted rules inside block: NONE

## 0e46ca2968ccdb03 — screenwriter/references/advanced-techniques.md:34-34 (paragraph)

**Revealing Information:**

Extracted rules inside block: NONE

## 14cec9873eb2214f — screenwriter/references/advanced-techniques.md:35-39 (code)

```
The desk is empty. Coffee still steaming. Papers scattered.

The door stands ajar, revealing darkness beyond.
```

Extracted rules inside block: NONE

## a0b077c4661cfe62 — screenwriter/references/advanced-techniques.md:40-40 (paragraph)

*Implies: Pan from desk to door, revealing new information*

Extracted rules inside block: NONE

## 7bcf551ee0877040 — screenwriter/references/advanced-techniques.md:42-42 (heading)

### Scene Structure for Camera Flow

Extracted rules inside block: NONE

## ead7bf2ce9f609c7 — screenwriter/references/advanced-techniques.md:44-45 (paragraph)

**Short Paragraphs = Multiple Shots:**
Breaking action into short paragraphs suggests multiple camera setups:

Extracted rules inside block: NONE

## e274aba4526f6d66 — screenwriter/references/advanced-techniques.md:47-55 (code)

```
The warehouse is silent.

A shadow moves across the floor.

Sarah freezes, hand on her weapon.

The shadow stops.
```

Extracted rules inside block: NONE

## bb4b9446c1696707 — screenwriter/references/advanced-techniques.md:57-58 (paragraph)

**Continuous Paragraph = Single Shot:**
One paragraph suggests continuous camera movement:

Extracted rules inside block: NONE

## ba23355c3715d20c — screenwriter/references/advanced-techniques.md:60-62 (code)

```
Sarah enters the warehouse, weapon drawn. She moves along the wall, checking corners. The shadow crosses her path. She spins, aiming into darkness.
```

Extracted rules inside block: NONE
