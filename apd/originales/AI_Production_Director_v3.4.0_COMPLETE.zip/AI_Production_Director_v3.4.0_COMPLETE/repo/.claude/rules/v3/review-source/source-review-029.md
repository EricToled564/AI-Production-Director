# Source coverage review 29/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0111faa0aeab2428 — brand-lock-extractor/references/extraction-rubric.md:29-29 (paragraph)

A table of `#RRGGBB` by role: Background, Ink, Accent, Muted, Rule, plus any brand-specific roles. Up to 8; past that the brand stops being recognizable.

Extracted rules inside block: NONE

## 621d938e4e7cdde1 — brand-lock-extractor/references/extraction-rubric.md:31-31 (paragraph)

How to get real hex:

Extracted rules inside block: NONE

## 2806921324b0870a — brand-lock-extractor/references/extraction-rubric.md:32-32 (list_item)

- **Brand book PDF:** read the swatches directly. Highest confidence.

Extracted rules inside block: NONE

## 9c872b7f4638db2d — brand-lock-extractor/references/extraction-rubric.md:33-33 (list_item)

- **Website:** the CSS holds exact values (`background`, `color`, CSS custom properties like `--accent`). Highest confidence after a brand book.

Extracted rules inside block: NONE

## 583d6c3992e97e8f — brand-lock-extractor/references/extraction-rubric.md:34-34 (list_item)

- **Screenshots:** sample the dominant background, the text color, and the one or two accent colors. Compression shifts color slightly, so flag screenshot-sampled values `needs confirmation` unless they are clearly flat brand colors.

Extracted rules inside block: NONE

## 0e60ad508bb660eb — brand-lock-extractor/references/extraction-rubric.md:36-36 (paragraph)

**Never guess a hex.** If you cannot read or sample one, estimate, label it `needs confirmation`, and tell the user exactly which role to verify. (See SKILL.md Rule 1.)

Extracted rules inside block: bfca9c3046b9

## 02e54ef51efb39a2 — brand-lock-extractor/references/extraction-rubric.md:38-38 (heading)

## Typography

Extracted rules inside block: NONE

## 3539a29566455ff8 — brand-lock-extractor/references/extraction-rubric.md:40-40 (paragraph)

Display font, body font, optional mono, each with weight (`Inter Black 900`, not `Inter Bold`).

Extracted rules inside block: NONE

## 2b6b3f3d7c3ec253 — brand-lock-extractor/references/extraction-rubric.md:42-42 (list_item)

- **Website:** `font-family` declarations and loaded font files (`fonts.googleapis.com`, `@font-face`, `.woff2` names) name the fonts exactly. Weights come from `font-weight`.

Extracted rules inside block: NONE

## cdc2d4c0a9446e5d — brand-lock-extractor/references/extraction-rubric.md:43-43 (list_item)

- **Brand book:** named directly.

Extracted rules inside block: NONE

## bfe2297dc70fcd10 — brand-lock-extractor/references/extraction-rubric.md:44-44 (list_item)

- **Screenshots:** identify by eye only if confident; otherwise flag `needs confirmation`. Do not invent a plausible name (Rule 2).

Extracted rules inside block: 859f8b6618ba

## 47ed6e9cedcad787 — brand-lock-extractor/references/extraction-rubric.md:46-46 (paragraph)

Two fonts max; three only if one is mono for code/data.

Extracted rules inside block: NONE

## 41a6e1b014d88dad — brand-lock-extractor/references/extraction-rubric.md:48-48 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## 5c820e849a319733 — brand-lock-extractor/references/extraction-rubric.md:50-50 (paragraph)

3-5 adjectives, specific, contrast clauses preferred. Read tone from the body copy and the imagery together.

Extracted rules inside block: 0ddcf2544ddb

## 4513ad5870904deb — brand-lock-extractor/references/extraction-rubric.md:52-52 (paragraph)

Reject generic fillers ("professional, modern, clean"), they describe everything and constrain nothing. Push to contrast clauses that do work: "operator not creator", "warm not precious", "plainspoken not corporate". If the assets only support generic adjectives, flag `needs confirmation`. Cite the copy or image that supports each adjective.

Extracted rules inside block: NONE

## de3451efa8933ed8 — brand-lock-extractor/references/extraction-rubric.md:54-54 (heading)

## Never list

Extracted rules inside block: NONE

## 011d9f1c01845404 — brand-lock-extractor/references/extraction-rubric.md:56-56 (paragraph)

The hardest and most valuable section. Brands document what they do; you infer what they avoid from consistency across the assets.

Extracted rules inside block: af979316267e

## 9299ae464494f2c9 — brand-lock-extractor/references/extraction-rubric.md:58-58 (paragraph)

Method, look for what is conspicuously absent:

Extracted rules inside block: NONE

## a08502ffd958d4ad — brand-lock-extractor/references/extraction-rubric.md:59-59 (list_item)

- Imagery: no stock-photo gloss? no people? no gradients? no clip-art icons? Each absence is a never.

Extracted rules inside block: a441f1d7a7d8

## b7a1c5f82e990ef2 — brand-lock-extractor/references/extraction-rubric.md:60-60 (list_item)

- Copy: no exclamation points? no hype words ("revolutionary", "game-changing")? no emojis? no questions in headlines? Each pattern is a never.

Extracted rules inside block: be855705dd55

## 172b7255bf02e6f4 — brand-lock-extractor/references/extraction-rubric.md:61-61 (list_item)

- Color/layout: never full-bleed photography? never more than one accent? never centered body text?

Extracted rules inside block: 971c7f32e6be

## f261164c7284e244 — brand-lock-extractor/references/extraction-rubric.md:63-63 (paragraph)

Turn each observed constraint into a `never` line. Be specific: "never use stock-photo aesthetic" beats "keep it authentic". Aim for 5+. Never ship an empty list (Rule 4).

Extracted rules inside block: 3f31edc925bf

## 18a911f4e1352fcc — brand-lock-extractor/references/extraction-rubric.md:65-65 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## 22b9d94dac788652 — brand-lock-extractor/references/extraction-rubric.md:67-67 (paragraph)

The ratios the brand renders for. Default to `9:16, 16:9, 1:1, 4:5`. If the assets reveal a bias (a vertical-only social brand, a cinematic 21:9 site hero), reflect it and note the evidence.

Extracted rules inside block: NONE

## 5f7156776f798e82 — brand-lock-extractor/references/extraction-rubric.md:69-69 (heading)

## Color grade direction

Extracted rules inside block: NONE

## 4ce0c059c6d7c749 — brand-lock-extractor/references/extraction-rubric.md:71-71 (paragraph)

One sentence on how footage and generated images should be graded, with a reference point where possible (Kodak Portra 400, Apple keynote photography, A24 film grade). Infer from the existing photography's warmth, contrast, and saturation. If there is no photography to read, base it on the palette and flag `needs confirmation`.

Extracted rules inside block: 7bbf6d48abcc

## c680382780369cd0 — brand-lock-extractor/references/extraction-rubric.md:73-73 (heading)

## Motion language

Extracted rules inside block: NONE

## dfd48797ad531a3a — brand-lock-extractor/references/extraction-rubric.md:75-75 (paragraph)

One paragraph: camera moves, cut style, text animation, pacing. Read from any existing video or motion on the site; if there is none, infer a conservative default consistent with the voice posture (a Quiet/Authoritative brand -> minimal, slow, deliberate) and flag `needs confirmation`. Keep it to one coherent motion language, do not blend "minimal and deliberate" with "energetic whip pans".

Extracted rules inside block: d98eaed160fe

## 3e7630c32f0e63d5 — brand-lock-extractor/references/extraction-rubric.md:77-77 (heading)

## Voice rules

Extracted rules inside block: NONE

## 524f34aa5985e132 — brand-lock-extractor/references/extraction-rubric.md:79-79 (paragraph)

Copy-level constraints for VO and on-screen text. Many overlap the never-list but are phrased as authoring rules: "no em dashes", "sentences under 14 words", "prefer specific numbers over vague claims", "no exclamation points in headlines". Extract from observed copy patterns. These become prompt constraints downstream, so make them enforceable, not aspirational.

Extracted rules inside block: d46a58d6e6bc
