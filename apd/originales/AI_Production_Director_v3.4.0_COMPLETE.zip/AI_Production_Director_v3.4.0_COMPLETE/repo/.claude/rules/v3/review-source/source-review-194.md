# Source coverage review 194/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## e1fd46dd4856f8ae — visual-asset-critic/references/critique-rubric.md:110-110 (list_item)

- **Cite the layer**, every issue gets tagged with which layer it falls under. This makes the fix path obvious

Extracted rules inside block: NONE

## ee19438fbe215230 — visual-asset-critic/references/critique-rubric.md:111-111 (list_item)

- **Distinguish prompt failure from generator failure**, if the prompt was fine and the generator produced garbage hands, that's "re-roll required", not "fix the prompt"

Extracted rules inside block: 5e73d736d58f

## bfd0e48fa571a27f — visual-asset-critic/tools/README.md:1-1 (heading)

# Tools

Extracted rules inside block: NONE

## e5d2637fbc09b299 — visual-asset-critic/tools/README.md:3-4 (paragraph)

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

Extracted rules inside block: NONE

## 2ed2e1e23860618f — visual-asset-critic/tools/README.md:6-6 (heading)

## Requirements

Extracted rules inside block: NONE

## 2da313b9ac3734d7 — visual-asset-critic/tools/README.md:8-10 (code)

```bash
pip install pyyaml jsonschema
```

Extracted rules inside block: NONE

## 736c47fad3dfce63 — visual-asset-critic/tools/README.md:12-12 (paragraph)

Standard library otherwise. No pandas, no numpy.

Extracted rules inside block: NONE

## 31061436522617c0 — visual-asset-critic/tools/README.md:14-14 (heading)

## Run everything

Extracted rules inside block: NONE

## 19637261abd5a33d — visual-asset-critic/tools/README.md:16-20 (code)

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

Extracted rules inside block: NONE

## 085588970cf0efcf — visual-asset-critic/tools/README.md:22-22 (paragraph)

This is exactly what CI runs, so a green local run means a green PR.

Extracted rules inside block: NONE

## 55d04f9dbf0e0add — visual-asset-critic/tools/README.md:24-26 (paragraph)

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

Extracted rules inside block: NONE

## f4406e9c427ee0c3 — visual-asset-critic/tools/README.md:28-28 (heading)

## Repo checks

Extracted rules inside block: NONE

## 100455458043f6cd — visual-asset-critic/tools/README.md:30-30 (heading)

### `validate_skills.py`

Extracted rules inside block: NONE

## 4c035e4ac2cf6b97 — visual-asset-critic/tools/README.md:32-33 (paragraph)

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

Extracted rules inside block: ffb3b1468594

## 40aa1bc5b17fffbf — visual-asset-critic/tools/README.md:35-37 (code)

```bash
python tools/validate_skills.py
```

Extracted rules inside block: NONE

## 476752a501c7e239 — visual-asset-critic/tools/README.md:39-39 (heading)

### `validate_schemas.py`

Extracted rules inside block: NONE

## 951373b880588c70 — visual-asset-critic/tools/README.md:41-42 (paragraph)

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

Extracted rules inside block: NONE

## 0c1eadac3833d928 — visual-asset-critic/tools/README.md:44-46 (code)

```bash
python tools/validate_schemas.py
```

Extracted rules inside block: NONE

## ef1593424fa137af — visual-asset-critic/tools/README.md:48-48 (paragraph)

It validates schemas, not instances. For instances, see `validate_shots.py`.

Extracted rules inside block: NONE

## 04e03ef71ae915ca — visual-asset-critic/tools/README.md:50-50 (heading)

### `validate_capabilities.py`

Extracted rules inside block: NONE

## ef59170e6e6f8272 — visual-asset-critic/tools/README.md:52-54 (paragraph)

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

Extracted rules inside block: NONE

## fd79aa189c2622cc — visual-asset-critic/tools/README.md:56-56 (list_item)

- every generator id has an adapter `.md` and every adapter `.md` has an entry

Extracted rules inside block: NONE

## 81950b0aaa4b132c — visual-asset-critic/tools/README.md:57-57 (list_item)

- no adapter advertises more words than its own `max_prompt_words` ceiling

Extracted rules inside block: NONE

## e2ca41893de18aec — visual-asset-critic/tools/README.md:58-58 (list_item)

- every adapter documents the `aspect_param` the matrix says to send

Extracted rules inside block: NONE

## 8e9a7c43ddac5c18 — visual-asset-critic/tools/README.md:59-59 (list_item)

- no `notes` field cites a word count above its own ceiling

Extracted rules inside block: NONE

## faae39d48b7d7ad4 — visual-asset-critic/tools/README.md:60-60 (list_item)

- warns when the matrix or an entry is past its 120-day freshness window

Extracted rules inside block: NONE

## 4c03bfb3cfeb0b50 — visual-asset-critic/tools/README.md:62-65 (code)

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

Extracted rules inside block: NONE

## b42ef65fa87c7ee3 — visual-asset-critic/tools/README.md:67-68 (paragraph)

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

Extracted rules inside block: NONE

## b3d931558434dfbc — visual-asset-critic/tools/README.md:70-70 (heading)

### `validate_brand_lock.py`

Extracted rules inside block: NONE

## d0f37b66e51d4335 — visual-asset-critic/tools/README.md:72-74 (paragraph)

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

Extracted rules inside block: e2b7ad1d0c5a
