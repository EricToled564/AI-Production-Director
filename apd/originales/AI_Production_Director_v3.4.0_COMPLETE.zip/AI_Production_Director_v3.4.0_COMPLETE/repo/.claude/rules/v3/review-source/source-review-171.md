# Source coverage review 171/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 14d77c050bd7bab4 — video/references/seedance-25.md:161-161 (list_item)

- **One core action + one camera move per window.** Do not demand frequencies ("three actions in one second").

Extracted rules inside block: bb6aa2e36b78

## d2016e4269e630c1 — video/references/seedance-25.md:162-162 (list_item)

- Second-precision only where it matters: critical handoffs, entrances, transitions, beat hits. `At 5 seconds, the camera whip-pans left and completes the transition.` Relative triggers work too: `Three seconds after the character presses the button, the room lights turn off.`

Extracted rules inside block: NONE

## 216be8ef6474477b — video/references/seedance-25.md:163-163 (list_item)

- Too little content in a window = model freedom; too much = over-cutting and omissions. Match content volume to the budget.

Extracted rules inside block: NONE

## 3e87c829a2b25c03 — video/references/seedance-25.md:165-165 (heading)

## 7. The anti-collapse skeleton (3 modules)

Extracted rules inside block: NONE

## cd63816487430b0d — video/references/seedance-25.md:167-167 (paragraph)

The official structure for dramatic 30-second work. It maps onto our 11-block skeleton but is leaner:

Extracted rules inside block: NONE

## 5784a27c854dcb90 — video/references/seedance-25.md:169-187 (code)

```text
<One-line tone summary — the logline>

[Module 1 — Reference layer]
Strictly keep @Image 1's face and features consistent. Keep @Image 2's
composition / blockout / spatial relations. Strictly lock character blocking.

[Module 2 — Global settings ("worldview + anti-collapse")]
Base environment & texture (emphasize extreme, realistic physical texture).
Visual style (film look, depth of field, lighting).
Camera language.
Character styling (use the section 8 formula).
Performance core (the acting register for the whole piece).
Prohibitions: <sound bans> + <subtitle bans> + <behavior bans> + <known collapse points>.

[Module 3 — Timestamped storyboard]
[start-end s] [beat name] — physical directives (shot size, composition,
micro-actions) + emotional subtext.
```

Extracted rules inside block: NONE

## 3a70e0b4b23ab463 — video/references/seedance-25.md:189-189 (paragraph)

Two techniques carry this skeleton:

Extracted rules inside block: NONE

## 911131d41daea730 — video/references/seedance-25.md:191-191 (list_item)

- **The prohibition list is specific, not generic.** From the official farewell example: "No exaggerated crying, no fast cuts, no large body movements, no extra dialogue, no BGM, no runny nose, no premature dropping of tears." Ban the exact ways this scene can collapse.

Extracted rules inside block: 729b5c5b6d2e

## 7737cf70924d989a — video/references/seedance-25.md:192-192 (list_item)

- **Directive + subtext.** After the physical directive, explain to the model *why* the action happens: "Emotion analysis: she is not complaining — she is waiting for him to confirm an answer she already guessed." The model acts better when it knows the intent. This is the official guide's signature trick and it composes directly with our Details Law.

Extracted rules inside block: NONE

## e278d9e8ae08e13d — video/references/seedance-25.md:194-194 (heading)

## 8. Realistic human formula (anti-AI-face)

Extracted rules inside block: NONE

## d499908f406a1937 — video/references/seedance-25.md:196-200 (code)

```text
Character = [age / ethnicity] + [skin tone / skin texture] + [3-4 facial details]
          + [gaze / soul] + [hairstyle / hair color] + [clothing / fabric]
          + [build / emotion / aura]
```

Extracted rules inside block: NONE

## 4f03c9389fdf1db1 — video/references/seedance-25.md:202-202 (list_item)

- **Force-append the fidelity suffix:** "retaining real fine pores and skin texture" (optionally freckles, blemishes). This single clause is the official anti-plastic-skin fix.

Extracted rules inside block: NONE

## 215cc83ae6defbe8 — video/references/seedance-25.md:203-203 (list_item)

- Facial details need 3-4 concrete points: eye shape, brow bone, nose bridge, lips, jawline.

Extracted rules inside block: NONE

## b82188afaf476c95 — video/references/seedance-25.md:204-204 (list_item)

- Gaze/soul = the emotion the eyes carry, separate from the facial geometry.

Extracted rules inside block: NONE

## 5cb8fc45ec1c7edc — video/references/seedance-25.md:205-205 (list_item)

- Works for animated characters too — swap the texture register.

Extracted rules inside block: NONE

## 80e72597ba8421b5 — video/references/seedance-25.md:207-207 (paragraph)

For one emotional transition, **2-4 observable cues are enough** (eye movement, brow tension, mouth, breathing, throat swallow, hands). More reads as overacting; abstract emotion words leave too much room.

Extracted rules inside block: NONE

## d863fe4413e71939 — video/references/seedance-25.md:209-209 (heading)

## 9. Camera language

Extracted rules inside block: NONE

## dc0fd964266d8201 — video/references/seedance-25.md:211-211 (paragraph)

Officially understood without translation: extreme wide / wide / medium / close-up / extreme close-up; push in, pull out, pan, lateral move, follow shot, orbit, dive, dolly out, tilt, handheld shake; low angle, overhead, first-person; one-take shot, dolly zoom, aerial, FPV, bullet time, bounce speed ramp.

Extracted rules inside block: NONE

## dfd88f2cd2eaed42 — video/references/seedance-25.md:213-213 (paragraph)

For rarer terms, keep the term **and** translate it to observable change: `term + target subject + visual change + foreground/background relationship + direction or speed`. Full pattern and vocabulary in `camera-lighting-vocabulary.md` §10.

Extracted rules inside block: NONE

## dc513f1dc986ca9a — video/references/seedance-25.md:215-215 (paragraph)

Aperture and focal-length numbers are allowed, but the visible result phrased in words is what actually steers the model.

Extracted rules inside block: NONE

## effebb6046f59eaa — video/references/seedance-25.md:217-217 (heading)

## 10. Transitions

Extracted rules inside block: NONE

## 36539c229dff561d — video/references/seedance-25.md:219-219 (paragraph)

The transition vocabulary (natural cut, fade, dissolve, flash, wipe, occlusion mask, match cut, action/whip cut, motion-relay, zoom-through, ink-wash) lives in `camera-lighting-vocabulary.md` §11. Seedance-specific usage:

Extracted rules inside block: NONE

## 40950a3169bf2317 — video/references/seedance-25.md:221-223 (code)

```text
cut = [transition type] + [basic constraints] + [cut logic]
```

Extracted rules inside block: NONE

## b8fd32717c8d7de3 — video/references/seedance-25.md:225-225 (list_item)

- Always attach the incantation: **"prohibit rigid cutting, prohibit objects appearing out of thin air"** — it is the official anti-jump-cut clause, repeated in every transition template.

Extracted rules inside block: eff27022e95d

## f5e7f7e2be2b1d23 — video/references/seedance-25.md:226-226 (list_item)

- Transitions can be **delegated**: "From [natural cut / occlusion mask / ink-wash / match cut], choose the one that best fits the style of this film."

Extracted rules inside block: NONE

## b1a3b38ddd150cfb — video/references/seedance-25.md:227-227 (list_item)

- Order-gate effects that must not fire early: "The ink-wash effect must only appear AFTER 25 seconds, triggered by the 'click' sound — absolutely no premature appearance."

Extracted rules inside block: 962e1d91e5c3

## c768eb150db37edf — video/references/seedance-25.md:229-229 (heading)

## 11. Physics through consequences and triggers

Extracted rules inside block: NONE

## 7ce688ded298682b — video/references/seedance-25.md:231-231 (paragraph)

2.5 renders real physics and couples it with audio. Exploit this in four moves:

Extracted rules inside block: NONE

## de21f1c3cef20000 — video/references/seedance-25.md:233-233 (list_item)

1. **Declare the physics regime up front.** "Rain reflections on metal, water splashed by tires, and the specular refraction of exhaust flames must strictly obey real-world physics."

Extracted rules inside block: c41ed3524370

## 30edeba38b567f0d — video/references/seedance-25.md:234-234 (list_item)

2. **Narrate consequences, not just actions.** Tires kick up water curtains; the impact shatters the bridge into a spider-web pattern; the shockwave blows the rain away in a ring. Action chains where each step forces the next ("hand grips jar → lid actually unscrews") double as QA — a broken chain exposes a failed generation instantly.

Extracted rules inside block: 65dd1f52b454
