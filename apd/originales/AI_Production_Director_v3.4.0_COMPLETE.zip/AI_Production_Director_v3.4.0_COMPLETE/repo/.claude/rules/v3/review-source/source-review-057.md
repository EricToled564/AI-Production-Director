# Source coverage review 57/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## ad18cc1056a98a46 — image/references/patterns/fashion-editorial.md:33-33 (paragraph)

Use for model tests, casting cards, or editorial portfolio pages — four angles of the same person in a clean grid.

Extracted rules inside block: 766aa60fb5ff

## 2e52d17e5b6c8b6f — image/references/patterns/fashion-editorial.md:35-35 (paragraph)

<!-- Source concept: 2x2 fashion portrait grid — same model, four setups -->

Extracted rules inside block: NONE

## eeb67f35852d6f3c — image/references/patterns/fashion-editorial.md:37-48 (code)

```
Scene: 2x2 grid on white canvas, thin {divider_color} divider lines (2px), all four cells use the same {background_type} with slight variation in angle
Subject: {model_description}, same {outfit_description} in all four frames
Important Details:
  Top-left: straight-on headshot, neutral expression, eyes to camera, even butterfly lighting
  Top-right: three-quarter profile, chin slightly lifted, single key light from camera-left creating defined cheekbone shadow
  Bottom-left: full profile silhouette, rim light from behind outlining jaw and nose, {background_type} slightly darker
  Bottom-right: candid moment — mid-laugh or adjusting {accessory}, natural movement, softer light
  All frames: {film_stock} color science, consistent {skin_tone_handling}, no heavy skin smoothing — visible pores and natural texture, shallow depth of field in all four
Use Case: fashion editorial spread, model comp card, casting portfolio
Constraints: identical person in all four frames (bone structure, skin, hair must match exactly), no makeup changes between frames, no text, no watermarks, backgrounds must feel cohesive not random
```

Extracted rules inside block: NONE

## 673a187bae22f406 — image/references/patterns/fashion-editorial.md:50-50 (paragraph)

**Key levers:** `{model_description}`, `{outfit_description}` (black turtleneck, white linen shirt unbuttoned at collar), `{background_type}` (seamless medium gray, textured plaster wall, out-of-focus greenery), `{divider_color}` (#FFFFFF, #E0E0E0), `{film_stock}` (Kodak Portra 400, Fujifilm Pro 400H), `{skin_tone_handling}` (warm undertones preserved, cool-neutral rendering), `{accessory}` (earring, collar, watch)

Extracted rules inside block: NONE

## c5913cd882afd644 — image/references/patterns/fashion-editorial.md:52-52 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency critical across four frames

Extracted rules inside block: d23aa43e62f3

## 961c565a149eecb2 — image/references/patterns/fashion-editorial.md:56-56 (heading)

## Streetwear Poster with Oversized Typography

Extracted rules inside block: NONE

## a1b048626f274d5a — image/references/patterns/fashion-editorial.md:58-58 (paragraph)

Use for streetwear drops, limited edition launches, or urban fashion brand campaigns where bold type dominates the composition.

Extracted rules inside block: 5de253f2c166

## 964bedfc1e41ad9d — image/references/patterns/fashion-editorial.md:60-60 (paragraph)

<!-- Source concept: streetwear poster with model integrated into oversized typographic layout -->

Extracted rules inside block: NONE

## 87c9376661d43300 — image/references/patterns/fashion-editorial.md:62-69 (code)

```
Scene: solid {background_color} background, graphic poster composition, typography dominates 60% of visual space
Subject: {model_description} in {streetwear_outfit}, standing or crouching in a {pose_description}, positioned {model_position} — partially overlapping the text layers
Important Details: headline "{HEADLINE_TEXT}" in extra-bold condensed {font_style}, {text_color}, occupying upper two-thirds of frame — model breaks in front of some letters and behind others (depth interplay), secondary text "{SUBHEAD_TEXT}" in thin weight {subhead_color} near bottom edge, {lighting_type} on model creating {shadow_quality} shadows, grain overlay across entire image ({grain_intensity}), composition follows rule of thirds with model at {grid_position} intersection
Use Case: streetwear brand drop poster, social media announcement, lookbook cover
Constraints: text must be fully legible even where model overlaps, no extra text or watermarks, no decorative elements besides type and model, model does not obscure more than 30% of any single letter, "{HEADLINE_TEXT}" spelled exactly as provided
Quality: high
```

Extracted rules inside block: NONE

## 2da8d3a49198838d — image/references/patterns/fashion-editorial.md:71-71 (paragraph)

**Key levers:** `{HEADLINE_TEXT}` (brand name, drop name), `{SUBHEAD_TEXT}` (date, "LIMITED DROP", collection name), `{background_color}` (off-white #F5F1EB, concrete gray #8C8C8C, matte black #0D0D0D), `{text_color}` (#000000, #FF3333, #FFFFFF), `{font_style}` (sans-serif like Druk Wide, slab-serif, stencil), `{streetwear_outfit}`, `{model_position}` (center-left, right third), `{lighting_type}` (harsh direct flash, soft window light), `{grain_intensity}` (subtle film grain, heavy 35mm grain)

Extracted rules inside block: NONE

## fdf792e40800bbb0 — image/references/patterns/fashion-editorial.md:73-73 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — text rendering and model-type depth interplay

Extracted rules inside block: abe04ab820e8

## 6be6cb6f7eca53e4 — image/references/patterns/fashion-editorial.md:77-77 (heading)

## Retro Roller Skating Sportswear Campaign

Extracted rules inside block: NONE

## 50109921839d49d5 — image/references/patterns/fashion-editorial.md:79-79 (paragraph)

Use for playful, nostalgic sportswear or athleisure campaigns with 70s-80s visual language.

Extracted rules inside block: ab5c67ecd66b

## 657adefb77b116e4 — image/references/patterns/fashion-editorial.md:81-81 (paragraph)

<!-- Source concept: retro roller skating / sportswear campaign with analog film aesthetic -->

Extracted rules inside block: NONE

## e963e82583d7919c — image/references/patterns/fashion-editorial.md:83-83 (paragraph)

A sun-drenched wide shot of {model_description} roller skating along a {location_description}. They wear {outfit_description} — the fabric catches light as they move, one leg extended mid-glide, arms relaxed and swinging naturally. The ground is smooth asphalt with painted lane markings in faded {lane_color}. Background shows {background_elements} slightly out of focus through heat haze. Shot on {film_stock} with pronounced grain and slightly lifted shadows. Color palette centers on {palette_description}. Golden hour backlight creates a warm halo around the subject and long shadow stretching toward camera. Genuine movement energy — hair and loose fabric respond to speed. Format: {aspect_ratio}.

Extracted rules inside block: NONE

## 0662b5a19abf05dd — image/references/patterns/fashion-editorial.md:85-85 (paragraph)

**Key levers:** `{model_description}`, `{outfit_description}` (high-waisted terry shorts in coral, cropped zip-up in cream, tube socks with racing stripes), `{location_description}` (Venice Beach boardwalk, empty suburban tennis court, coastal promenade), `{film_stock}` (Kodak Gold 200, Fuji Superia 400), `{palette_description}` (terracotta #CC5533, cream #FFF5E1, sky blue #87CEEB, mustard #D4A017), `{lane_color}` (faded yellow, sun-bleached white), `{background_elements}` (palm trees and pastel buildings, chain-link fence and bleachers), `{aspect_ratio}` (3:2, 16:9)

Extracted rules inside block: 4ef8fa5c57ff

## f7262372e1817e9a — image/references/patterns/fashion-editorial.md:87-87 (paragraph)

**Recommended model:** NB2 — natural movement, analog film grain, atmospheric grounding

Extracted rules inside block: cc4eda9d1de0

## ee07fa6ee3a38d3b — image/references/patterns/fashion-editorial.md:91-91 (heading)

## Futuristic Sportswear Editorial with 3D Blob Shapes

Extracted rules inside block: NONE

## 9b9ddf7e34978d81 — image/references/patterns/fashion-editorial.md:93-93 (paragraph)

Use for forward-looking athletic or techwear editorials where abstract 3D forms create a surreal spatial environment around the model.

Extracted rules inside block: 344f8d2ab6e5

## 1245fbd5ff7ce50a — image/references/patterns/fashion-editorial.md:95-95 (paragraph)

<!-- Source concept: futuristic sportswear editorial with organic 3D blob/sphere shapes -->

Extracted rules inside block: NONE

## 87393f67c8ae87a4 — image/references/patterns/fashion-editorial.md:97-103 (code)

```
Scene: {studio_environment} studio space, matte {floor_color} floor extending to infinity, ambient fill light with no visible source, three to five large organic 3D blob shapes ({blob_color}, glossy smooth surface with environment reflections) floating at varying heights around the subject
Subject: {model_description} in {techwear_outfit}, posed in an athletic stance — {pose_detail}
Important Details: blobs range from basketball-sized to armchair-sized, each with smooth amoebic curves and a single specular highlight, they cast soft colored shadows onto the floor and the model's clothing, model lit by cool directional light from camera-right creating defined muscle/fabric contour, {fabric_detail} visible in the garment construction, one blob partially behind the model and one in front (spatial depth), color palette limited to {palette}, overall mood is clinical and aspirational
Use Case: sportswear lookbook, techwear campaign, editorial magazine spread
Constraints: blobs must look physically present (not composited), no text, no logos, no additional props, model remains the clear focal point despite the surrounding forms, blobs do not touch or intersect with the model's body, no motion blur
```

Extracted rules inside block: NONE

## 0492de3bca70afce — image/references/patterns/fashion-editorial.md:105-105 (paragraph)

**Key levers:** `{studio_environment}` (white void, concrete gray, deep navy), `{floor_color}` (light gray #D0D0D0, charcoal #333333), `{blob_color}` (chrome silver, translucent jade #00A86B, matte coral #FF6B6B), `{techwear_outfit}` (bonded seam track pants + compression top, oversized windbreaker + utility shorts), `{pose_detail}` (low lunge position, standing with one arm extended checking a wrist device, mid-jump), `{fabric_detail}` (visible bonded seams, reflective piping, mesh ventilation panels), `{palette}` (monochrome + single accent, earth tones + neon green #39FF14)

Extracted rules inside block: NONE

## 8d8113f6b1a9fe2a — image/references/patterns/fashion-editorial.md:107-107 (paragraph)

**Recommended model:** NBP — complex spatial reasoning for blob placement and reflections

Extracted rules inside block: cf2617fed234

## 580ab48d69e9e5b2 — image/references/patterns/fashion-editorial.md:109-109 (heading)

### Nano Banana version:

Extracted rules inside block: NONE

## a2232bf3a43f2b4e — image/references/patterns/fashion-editorial.md:111-113 (code)

```
A futuristic sportswear editorial photograph in a {studio_environment} studio space with a matte {floor_color} floor extending to infinity. {model_description} stands in an athletic {pose_detail}, wearing {techwear_outfit} with {fabric_detail}. Three to five large organic 3D blob shapes in {blob_color} with glossy smooth surfaces float at varying heights around the subject — the largest is armchair-sized, the smallest basketball-sized. Each blob has amoebic curves and casts soft colored shadows onto the floor and the model's clothes. Cool directional light from camera-right defines contour and fabric texture. One blob sits partially behind the model, one in front, creating depth. The model is the clear focal point. No text, no logos. Format: 4:5.
```

Extracted rules inside block: NONE

## 26f8ffc869b88b65 — image/references/patterns/fashion-editorial.md:117-117 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## db7da104ff7658b3 — image/references/patterns/food-beverage.md:1-1 (heading)

# Food & Beverage Patterns

Extracted rules inside block: NONE

## fe43295a7ac32aa0 — image/references/patterns/food-beverage.md:3-3 (paragraph)

Reusable prompt templates for food photography, beverage campaigns, and culinary illustration. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

Extracted rules inside block: NONE

## f9a9f9d915f52345 — image/references/patterns/food-beverage.md:7-7 (heading)

## Luxury Chocolate Brand Campaign

Extracted rules inside block: NONE

## 9cb87391ddce43da — image/references/patterns/food-beverage.md:9-9 (paragraph)

Use for premium chocolate or confectionery brand visuals — moody, textural, with controlled color and atmosphere. Adaptable across mood variants (dark indulgence, bright artisan, earthy origin-story).

Extracted rules inside block: 1d938c7cb8f3
