# Source coverage review 197/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5e78020e4cc0417c — visual-media/SKILL.md:20-20 (list_item)

- Flujo de producción de animación

Extracted rules inside block: NONE

## 22d467677e7af912 — visual-media/SKILL.md:21-21 (list_item)

- Edición y colorización en postproducción

Extracted rules inside block: NONE

## 52ba933a81c6a770 — visual-media/SKILL.md:23-23 (heading)

## Fundamentos de fotografía

Extracted rules inside block: NONE

## 894e6b50c06bd772 — visual-media/SKILL.md:25-25 (heading)

### Triángulo de exposición

Extracted rules inside block: NONE

## 111a506d205a7ff9 — visual-media/SKILL.md:27-54 (code)

```
┌─────────────────────────────────────────────────────────────────┐
│  Triángulo de exposición — Exposure Triangle                    │
│                                                                 │
│              Diafragma / Aperture                               │
│                 /\                                              │
│                /  \                                             │
│               /    \                                            │
│              /      \                                           │
│             /        \                                          │
│            /          \                                         │
│           /            \                                        │
│          /______________\                                       │
│    Obturador Shutter    ISO Sensibilidad                        │
│                                                                 │
│  Diafragma (f/1.4 – f/22)                                       │
│  ├─ Abierto (número bajo): poca profundidad, fondo desenfocado  │
│  └─ Cerrado (número alto): mucha profundidad, todo nítido       │
│                                                                 │
│  Obturador (1/4000s – 30s)                                      │
│  ├─ Alta velocidad: congela el movimiento                       │
│  └─ Baja velocidad: motion blur, estelas de luz                 │
│                                                                 │
│  ISO (100 – 12800+)                                             │
│  ├─ ISO bajo: imagen limpia y detallada                         │
│  └─ ISO alto: sirve en poca luz, pero introduce ruido           │
└─────────────────────────────────────────────────────────────────┘
```

Extracted rules inside block: NONE

## 51083c0373c5a9fc — visual-media/SKILL.md:56-56 (heading)

### Reglas de composición

Extracted rules inside block: NONE

## 5c71057550d46c25 — visual-media/SKILL.md:58-85 (code)

```markdown
## Composición básica

### Regla de tercios
- Divide el encuadre en una retícula de 3×3
- Coloca el sujeto en los puntos de intersección
- Sitúa el horizonte en la línea superior o inferior

### Líneas guía
- Usa líneas para conducir la mirada
- Caminos, ríos, barandales
- Que apunten al sujeto

### Encuadre dentro del encuadre
- Enmarca al sujeto con elementos del primer plano
- Marcos de puerta, ventanas, ramas
- Aporta capas y profundidad

### Simetría y equilibrio
- Simetría perfecta = estabilidad, solemnidad
- Asimetría = dinamismo, tensión
- Equilibra el peso visual

### Espacio negativo
- El vacío refuerza el punto focal
- Da "espacio para respirar" al sujeto
- Estética minimalista
```

Extracted rules inside block: NONE

## d9c134239772a56e — visual-media/SKILL.md:87-87 (heading)

### Uso de la luz

Extracted rules inside block: NONE

## 895f67202593dc25 — visual-media/SKILL.md:89-89 (table_row)

| Tipo de luz | Característica | Ideal para |

Extracted rules inside block: NONE

## 5737499c3862dfb9 — visual-media/SKILL.md:91-91 (table_row)

| **Luz frontal** | Plana, con pocas sombras | Registro, foto de documento |

Extracted rules inside block: NONE

## 7740685bc848d675 — visual-media/SKILL.md:92-92 (table_row)

| **Luz lateral** | Volumétrica, con sombras | Retrato, arquitectura |

Extracted rules inside block: NONE

## e3f0c1f136a33e41 — visual-media/SKILL.md:93-93 (table_row)

| **Contraluz** | Silueta, halo | Atmósfera, pieza artística |

Extracted rules inside block: NONE

## b85e8c6b434110b2 — visual-media/SKILL.md:94-94 (table_row)

| **Luz cenital** | Sombras duras | Evitar al mediodía |

Extracted rules inside block: NONE

## 84393ece481f3eba — visual-media/SKILL.md:95-95 (table_row)

| **Hora dorada** | Cálida y suave | Paisaje, retrato |

Extracted rules inside block: NONE

## e46c3c631f5a2972 — visual-media/SKILL.md:96-96 (table_row)

| **Hora azul** | Fría, enigmática | Ciudad, nocturnas |

Extracted rules inside block: NONE

## 9cf07327bbbf0b62 — visual-media/SKILL.md:98-98 (heading)

## Producción de video

Extracted rules inside block: NONE

## b84afb55c626e31c — visual-media/SKILL.md:100-100 (heading)

### Flujo de producción

Extracted rules inside block: NONE

## 3b70d7256cc34e7c — visual-media/SKILL.md:102-129 (code)

```
┌─────────────────────────────────────────────────────────────────┐
│  Las tres etapas de producción                                  │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Preproducción│  │   Rodaje     │  │Postproducción│          │
│  │  Pre-prod    │→ │  Production  │→ │  Post-prod   │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                 │
│  Preproducción (30%)                                            │
│  ├─ Guion / concepto                                            │
│  ├─ Storyboard                                                  │
│  ├─ Casting / scouting de locaciones                            │
│  └─ Equipo técnico y humano                                     │
│                                                                 │
│  Rodaje (20%)                                                   │
│  ├─ Dirección en set                                            │
│  ├─ Montaje de iluminación                                      │
│  ├─ Captura de audio                                            │
│  └─ Cobertura desde varios ángulos                              │
│                                                                 │
│  Postproducción (50%)                                           │
│  ├─ Edición                                                     │
│  ├─ Colorización                                                │
│  ├─ Diseño sonoro / musicalización                              │
│  └─ VFX y titulaje                                              │
└─────────────────────────────────────────────────────────────────┘
```

Extracted rules inside block: NONE

## 12c536dae294be87 — visual-media/SKILL.md:131-131 (heading)

### Movimientos de cámara

Extracted rules inside block: NONE

## e37d04c9e8c147dd — visual-media/SKILL.md:133-133 (table_row)

| Movimiento | Efecto | Cuándo usarlo |

Extracted rules inside block: NONE

## 26d3eaf951af0bf1 — visual-media/SKILL.md:135-135 (table_row)

| **Push in** | Énfasis, acercamiento | Revelar el punto clave |

Extracted rules inside block: NONE

## 1dc9159d389695cb — visual-media/SKILL.md:136-136 (table_row)

| **Pull out** | Revela el conjunto | Cierre, transición |

Extracted rules inside block: NONE

## 85ccf09a51671af0 — visual-media/SKILL.md:137-137 (table_row)

| **Pan** | Desplazamiento horizontal | Seguimiento, presentar el entorno |

Extracted rules inside block: NONE

## ce14360df15add15 — visual-media/SKILL.md:138-138 (table_row)

| **Tilt** | Desplazamiento vertical | Mostrar altura |

Extracted rules inside block: NONE

## 37004343cda71f3f — visual-media/SKILL.md:139-139 (table_row)

| **Track** | Acompaña al sujeto | Caminata, persecución |

Extracted rules inside block: NONE

## 8511cec68bf3d49c — visual-media/SKILL.md:140-140 (table_row)

| **Órbita** | Giro de 360° | Momento dramático |

Extracted rules inside block: NONE

## d0b0086ae3d909d5 — visual-media/SKILL.md:141-141 (table_row)

| **Cámara en mano** | Inmediatez, presencia | Documental, tensión |

Extracted rules inside block: NONE

## 7f6014a46f7e81d1 — visual-media/SKILL.md:143-143 (heading)

### Uso de los tipos de plano

Extracted rules inside block: NONE

## 16d39eeb0cf81dde — visual-media/SKILL.md:145-172 (code)

```markdown
## Tipos de plano — Shot Types

### Plano general (Wide Shot)
- Establece la escena
- Muestra el entorno
- El personaje se ve pequeño

### Plano entero (Full Shot)
- Cuerpo completo
- Acción legible
- Luce el vestuario

### Plano medio (Medium Shot)
- De la cintura hacia arriba
- Escenas de diálogo
- Gestualidad de manos

### Primer plano (Close-up)
- De los hombros hacia arriba
- Expresión emocional
- Línea de diálogo importante

### Primerísimo primer plano (Extreme Close-up)
- Detalle de ojos o manos
- Emoción intensa
- Detalle de objeto
```

Extracted rules inside block: NONE

## b831a51b62fc98ae — visual-media/SKILL.md:174-174 (heading)

## Contenido de formato corto

Extracted rules inside block: NONE
