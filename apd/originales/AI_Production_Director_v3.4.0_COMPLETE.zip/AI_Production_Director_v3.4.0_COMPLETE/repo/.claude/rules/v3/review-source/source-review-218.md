# Source coverage review 218/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## da5fcfe5e2d6221d — visual-prompt-forge/adapters/seedance.md:80-80 (heading)

## Output handoff

Extracted rules inside block: NONE

## eec67e1f371089c6 — visual-prompt-forge/adapters/seedance.md:82-82 (paragraph)

Seedance returns a sequence as a single clip (or a small set). It still needs: editorial trimming to exact storyboard timing, text-overlay compositing, a color-grade pass, and audio. Multi-shot output usually needs *less* assembly than stitched single clips, which is the point. Say so in handoff.

Extracted rules inside block: NONE

## dd3c32ecf86651bc — visual-prompt-forge/adapters/seedream.md:1-1 (heading)

# Adapter: Seedream (4.5 / 4.0)

Extracted rules inside block: NONE

## a65e4b4e650425ca — visual-prompt-forge/adapters/seedream.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: 7df5670c97b7

## c675c4235086829b — visual-prompt-forge/adapters/seedream.md:5-5 (paragraph)

ByteDance's Seedream models are the high-volume cost-efficient choice. Quality is below Flux 2 Pro and Midjourney v7 but above older mid-tier models, and the cost-per-image is roughly 5–10× lower. Choose Seedream when you're producing **many variations or doing rapid concept iteration**, not for hero/final assets.

Extracted rules inside block: NONE

## 2ce050790287285b — visual-prompt-forge/adapters/seedream.md:7-7 (paragraph)

For storyboard work, Seedream is useful for the storyboard preview pass: render every shot quickly to validate composition before committing to higher-cost generation for finals.

Extracted rules inside block: NONE

## 7465353b22733b04 — visual-prompt-forge/adapters/seedream.md:9-9 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## b851bff680a5576d — visual-prompt-forge/adapters/seedream.md:11-11 (paragraph)

Seedream rewards **short, precise prompts**. Long descriptive prompts underperform, the model interprets them as competing weights and produces mush. Closer to Midjourney's style than Flux's.

Extracted rules inside block: NONE

## 0b569fd05b063d0c — visual-prompt-forge/adapters/seedream.md:13-15 (code)

```
{Subject phrase}, {action}, {environment}, {lighting}, {mood/style}, {aspect note}
```

Extracted rules inside block: NONE

## de3c5e937bd23d05 — visual-prompt-forge/adapters/seedream.md:17-17 (paragraph)

Comma-separated, no full sentences.

Extracted rules inside block: NONE

## 04475e014b79a098 — visual-prompt-forge/adapters/seedream.md:19-19 (heading)

## Parameters

Extracted rules inside block: NONE

## b89585ef8b90172d — visual-prompt-forge/adapters/seedream.md:21-21 (paragraph)

Seedream is API-driven through fal.ai, Replicate, or BytePlus direct:

Extracted rules inside block: NONE

## 0290724febf50aee — visual-prompt-forge/adapters/seedream.md:23-23 (table_row)

| Parameter | Default | Notes |

Extracted rules inside block: NONE

## c48e5cbc59d2816a — visual-prompt-forge/adapters/seedream.md:25-25 (table_row)

| `aspect_ratio` | from `project.aspect` | |

Extracted rules inside block: NONE

## 786ef8e03792526a — visual-prompt-forge/adapters/seedream.md:26-26 (table_row)

| `seed` | per-storyboard | Critical for series consistency |

Extracted rules inside block: NONE

## 6b9d2e294ef80f3d — visual-prompt-forge/adapters/seedream.md:27-27 (table_row)

| `guidance_scale` | `4.5` | Lower = more creative, higher = more literal |

Extracted rules inside block: NONE

## 0dc8916d4b734961 — visual-prompt-forge/adapters/seedream.md:28-28 (table_row)

| `steps` | `28` | Default. Increase to 50 for higher quality at cost |

Extracted rules inside block: NONE

## f8ab44b487b91fab — visual-prompt-forge/adapters/seedream.md:30-30 (paragraph)

Document:

Extracted rules inside block: NONE

## b32bf7f4b8b1466d — visual-prompt-forge/adapters/seedream.md:31-34 (code)

```
# shot_01, params: ar=9:16, seed=2840193, guidance=4.5, steps=28
{prompt}
```

Extracted rules inside block: NONE

## 19b7da9afc0a7493 — visual-prompt-forge/adapters/seedream.md:36-36 (heading)

## Length

Extracted rules inside block: NONE

## 6e092f9a0c0c8c5a — visual-prompt-forge/adapters/seedream.md:38-38 (paragraph)

**40–70 words per prompt**. Shorter than most. Don't pad.

Extracted rules inside block: 20f17c8343ed

## 3ca7a6b1059a8242 — visual-prompt-forge/adapters/seedream.md:40-40 (heading)

## Composition pattern

Extracted rules inside block: NONE

## 27d9dcbebad30129 — visual-prompt-forge/adapters/seedream.md:42-44 (code)

```
{Framing} of {character anchor}, {action}, {environment from series_lock}, {lighting from series_lock}, {color grade from brand_lock}, {one mood adjective}, photorealistic
```

Extracted rules inside block: NONE

## f159bf11c76dc684 — visual-prompt-forge/adapters/seedream.md:46-46 (heading)

## Example

Extracted rules inside block: NONE

## 64312f83c70e9577 — visual-prompt-forge/adapters/seedream.md:48-48 (paragraph)

**Same shot data as previous examples.**

Extracted rules inside block: NONE

## 275a54f70a92d4d7 — visual-prompt-forge/adapters/seedream.md:50-50 (paragraph)

**Output prompt:**

Extracted rules inside block: NONE

## b30d90293584a38a — visual-prompt-forge/adapters/seedream.md:51-53 (code)

```
Medium shot of founder mid-thirties, salt-and-pepper hair, navy crewneck, leaning forward at laptop, face turned to window light, minimalist home office, oak desk, soft natural side-light from large window, warm afternoon, warm filmic color grade, muted teal shadows, calm operator mood, photorealistic
```

Extracted rules inside block: NONE

## d680e12c8b83a0e0 — visual-prompt-forge/adapters/seedream.md:55-55 (heading)

## When Seedream is the right choice

Extracted rules inside block: NONE

## fa65d0cfcf807e28 — visual-prompt-forge/adapters/seedream.md:57-57 (list_item)

- **Storyboard preview pass**, render all shots quickly at low cost to validate composition before final pass

Extracted rules inside block: NONE

## 172eb1c26caf3ecd — visual-prompt-forge/adapters/seedream.md:58-58 (list_item)

- **High-volume social content**, when you need 50+ images per day and the quality bar allows it

Extracted rules inside block: NONE
