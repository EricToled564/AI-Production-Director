# Source coverage review 163/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 50e4662c4230176e — video/references/race-and-speed.md:123-123 (paragraph)

Rotate among all five across the 30s — speed reads through *changing perspective*, not long takes. Each family has one job and a default composition.

Extracted rules inside block: NONE

## 1f54da376e672c29 — video/references/race-and-speed.md:125-125 (table_row)

| # | Family | Job (function) | Put in the still panel | Authenticity tell |

Extracted rules inside block: NONE

## bd1f4464e3352c95 — video/references/race-and-speed.md:127-127 (table_row)

| 1 | **Hostess-tray side profile** | Detail / Power | Side-mounted outside the door: hand on wheel/shifter, or rear-quarter wheel filling frame; asphalt streaking behind | door/window line anchors scale; rubber works in frame |

Extracted rules inside block: NONE

## e0f376924566e3ed — video/references/race-and-speed.md:128-128 (table_row)

| 2 | **Hood / bumper low forward POV** | Pressure / Impact | Predatory low forward look: asphalt rushing under the nose, cones/Tree/markers growing fast, lane stripe strobing; fisheye edge optional | road texture under the car = velocity |

Extracted rules inside block: NONE

## 71d576de4e583c42 — video/references/race-and-speed.md:129-129 (table_row)

| 3 | **Hard-mounted cabin shake** | Pressure / Reaction | Rigid interior mount: dash/needle/hands vibrating, mirror trembling, world shuddering through glass | visible micro-vibration; never perfectly stable |

Extracted rules inside block: f3273fd4c558

## 2951c364311117b5 — video/references/race-and-speed.md:130-130 (table_row)

| 4 | **Tracking / chase parallel + joust** | Power / Reveal | Camera car alongside (parallel) or closing head-on offset (joust); rival lane in frame, roadside lights as streaks | closing distance + streaked surroundings |

Extracted rules inside block: NONE

## 1ba05772e0765abd — video/references/race-and-speed.md:131-131 (table_row)

| 5 | **Distant proof shot** | Establish / Aftermath | Long locked lens: two cars as small hard shapes crossing huge space, smoke trail, barriers narrowing perspective | space covered brutally fast; one breath of stillness |

Extracted rules inside block: NONE

## 2c598c4f436a491d — video/references/race-and-speed.md:135-135 (heading)

## 6. Camera grammar for speed

Extracted rules inside block: NONE

## 3ee6b6479f5682f5 — video/references/race-and-speed.md:137-137 (paragraph)

The **six motion-as-still cues** (smear / partial blur / streak / vector / sharp-blur separation / held stillness) are catalogued in `animatic-keyframes.md` §4. This table is the complementary layer: the camera *move* the user names, resolved into one still composition. Format: technique — what it does to emotion — application in a keyframe/panel.

Extracted rules inside block: NONE

## 7fa356e5f6c258f7 — video/references/race-and-speed.md:139-139 (table_row)

| Technique | What it does to emotion | Keyframe application (the still) | Tag |

Extracted rules inside block: NONE

## 762a047282c84e7b — video/references/race-and-speed.md:141-141 (table_row)

| **Whip pan** | instant transfer of attention, reads as motion not a cut | Streak-frame between two clean panels: whole frame raked into horizontal streaks (Tree lamps, guardrail, lane stripes smeared), one shape barely surviving (a wheel arc, the shifter) | Shift |

Extracted rules inside block: NONE

## 80034bcda22d9114 — video/references/race-and-speed.md:142-142 (table_row)

| **Crash / snap zoom** | shock-shove into a detail; discovery, alarm | Aggressively tight macro of the trigger detail (needle slamming red, last amber bulb), faint radial/zoom-blur ring at edges, subject oversized dead-center | Detail / Impact |

Extracted rules inside block: NONE

## 7f9ff95b520fd352 — video/references/race-and-speed.md:143-143 (table_row)

| **Speed ramp** | punctuation: ramp = the breakout, freeze = exclamation mark | Frozen partial blur at the peak — sidewall wrinkle caught mid-deformation, smoke just blooming, everything else tack-sharp; one arrested ten-thousandth of a second | Impact |

Extracted rules inside block: NONE

## c4e11494a9f57e23 — video/references/race-and-speed.md:144-144 (table_row)

| **Freeze frame** | a held breath / a one-frame dossier on an object | Deliberately blur-free locked macro, hard edges, margin caption (knuckles whitening, *committed*); the symmetrical "exhale" amid kinetic panels | Detail / Pressure |

Extracted rules inside block: NONE

## 00e9e91bb5f47a72 — video/references/race-and-speed.md:145-145 (table_row)

| **POV (cockpit / impossible mount)** | identification; the viewer *is* in the car | Hands + wheel rim in hard foreground, cluster mid-ground, Tree/rival in blurred deep ground; 24mm exaggerated proximity; or genuinely impossible mount (wheel arch, exhaust mouth) | POV / Pressure |

Extracted rules inside block: NONE

## 57735dd585676a73 — video/references/race-and-speed.md:146-146 (table_row)

| **Joust** | closing-distance rate spikes the sense of speed | Near head-on, car offset to one side, a cone/marker huge and blurred on the opposite edge to mark the closing gap; reserve for the climax pass | Impact |

Extracted rules inside block: NONE

## 2d0627fd59f7116c — video/references/race-and-speed.md:147-147 (table_row)

| **Low macro (aggressor cam)** | the lens is a predator, the track attacks the frame | Bumper/grille-level skimming the asphalt, fisheye curvature at the edges, road lunging into the lens; or extreme CU under hard cold side-light — a knuckle becomes a ridge, the lever a weapon | Impact / POV / Detail |

Extracted rules inside block: NONE

## b0ee98d73ca31982 — video/references/race-and-speed.md:148-148 (table_row)

| **Restless / handheld cam** | the frame never settles; constant threat, physiological unease | Never a perfectly level, perfectly clean panel — bake in a 1–3° drift, edge smear, off-true horizon, a faint micro-shake artifact even in a "static" cockpit | Pressure |

Extracted rules inside block: 1a39e6dbf1cd

## 0cf81f8264ba70d4 — video/references/race-and-speed.md:149-149 (table_row)

| **Dutch angle** | imbalance, loss of grip | Cant the horizon hard at the one loss-of-traction beat only (tyre breaking away, car stepping sideways) — reserve it so it stays loud | Impact |

Extracted rules inside block: NONE

## 54add3ce3b04a682 — video/references/race-and-speed.md:151-151 (paragraph)

Ration aggression: one bumper-fisheye lunge, one crash-zoom, one dutch — at commitment beats, not as wallpaper. Per `camera-lighting-vocabulary.md` §2, the animatic prompt supplies one dominant move per clip; the keyframe is the locked first frame.

Extracted rules inside block: NONE

## b20ed1539800eee4 — video/references/race-and-speed.md:155-155 (heading)

## 7. Light & color for speed without faces

Extracted rules inside block: NONE

## 46ad1bc254933ae8 — video/references/race-and-speed.md:157-157 (paragraph)

Faces are banned, so light is the only actor left. It does not "set a mood" — it **rims a material** so a piece of metal, rubber or skin reports the emotion a face would. General light grammar (sources, direction, quality) is `camera-lighting-vocabulary.md` §4–7; the anti-sterile firewall is `animatic-keyframes.md` §7 + `universal-rules.md` U12. The race-specific governing law: *embrace the dark* (crush blacks, ~70% of the frame unlit), *one motivated practical per panel* (Tree lamp, headlight, sodium lamp, brake glow), *light is specular not ambient* (every panel needs ≥1 hard specular hit — no specular, no information).

Extracted rules inside block: 485c16909911

## 1c1b769871a9c206 — video/references/race-and-speed.md:159-159 (heading)

### The cold combative palette

Extracted rules inside block: NONE

## 6af0b4b41d8d476b — video/references/race-and-speed.md:161-161 (table_row)

| Color | Emotional job | Where it lives in the keyframe |

Extracted rules inside block: NONE

## e313dee1f0b72660 — video/references/race-and-speed.md:163-163 (table_row)

| Hard white / dirty mercury white | clinical pressure, the white-hot edge of commitment | top/side key on knuckles, metal lip; blown highlight on chrome |

Extracted rules inside block: NONE

## 9d00144018e74780 — video/references/race-and-speed.md:164-164 (table_row)

| Cyan / electric teal | cold adrenaline, machine-alive | backlight through burnout smoke; spill on wet asphalt; rim on rear-quarter |

Extracted rules inside block: NONE

## 3a4ac3d6c2b60309 — video/references/race-and-speed.md:165-165 (table_row)

| Steel blue | night base, isolation, the void | negative space, deep shadow body, the unlit 70% |

Extracted rules inside block: NONE

## c5ec4cdcf5cdc21c — video/references/race-and-speed.md:166-166 (table_row)

| Magenta / cold violet | aggression, neon menace | practical sign spill on roofline; reflection ribbon down wet lane |

Extracted rules inside block: NONE

## 6112032c82f44fec — video/references/race-and-speed.md:167-167 (table_row)

| **Red (accent only)** | danger, redline, point of no return | brake disc glow, tail-lights, Tree bulbs in lacquer, tach needle in the red |

Extracted rules inside block: NONE

## 980a7b9de10fa1dc — video/references/race-and-speed.md:168-168 (table_row)

| Green (accent only) | release, GO | the Tree's green bulb, its single reflection in a headlight lens or paint |

Extracted rules inside block: NONE
