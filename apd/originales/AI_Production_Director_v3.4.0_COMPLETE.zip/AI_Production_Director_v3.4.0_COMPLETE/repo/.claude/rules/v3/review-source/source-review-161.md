# Source coverage review 161/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 1883ccb5045d9d90 — video/references/race-and-speed.md:18-18 (list_item)

8. Sound & rhythm

Extracted rules inside block: 1c700f2ecf72

## 196a4c96e84c5d03 — video/references/race-and-speed.md:19-19 (list_item)

9. 30-second structure (beat map)

Extracted rules inside block: 7ad73ee6e675

## d28ca8843b172f4d — video/references/race-and-speed.md:20-20 (list_item)

10. Anti-fake guard

Extracted rules inside block: 998f82e3c08f

## f89fd4a15ef2bfab — video/references/race-and-speed.md:24-24 (heading)

## 1. Core laws (the non-negotiables)

Extracted rules inside block: NONE

## fb1df4ee1c3d93e9 — video/references/race-and-speed.md:26-26 (paragraph)

Six laws govern every race panel. Break one and the spot collapses to a car commercial.

Extracted rules inside block: NONE

## f70bfc099ee24f5f — video/references/race-and-speed.md:28-28 (list_item)

1. **Authentic speed, never CGI-clean or sped-up.** Build velocity into the static composition (§3); never lean on a ramp to rescue a dead frame. Over-crank, glass-smooth stabilization and post speed-ramps read subconsciously as "ad-speed" and drain all threat. Squat, lifted nose, slick wrinkle, smeared rim — the physics has to be visible in the still.

Extracted rules inside block: 74c43bb10240

## 3a561a72a6c5975a — video/references/race-and-speed.md:29-29 (list_item)

2. **Detail is the emotion.** Faces banned, feeling renders only on a knuckle, a needle, a pedal, smoke, or a sweat bead (`dramaturgy.md` §2; the full substitution method is `animatic-keyframes.md` §5). A hand mid-grip is the no-face equivalent of a close-up on the eyes. No abstract "motion", no named feeling.

Extracted rules inside block: 4cf79d596854

## 5ae34b29c07a78e8 — video/references/race-and-speed.md:30-30 (list_item)

3. **One governing visual promise per piece.** A 30s cut earns cohesion from a single conceit: everything through reflections in painted metal, or everything through circles (tach → headlight → bulb → wheel), or everything as machine-talks / no-music. Kon's "one visual principle". Name it before boarding.

Extracted rules inside block: 3efbc4db3b2f

## 12b3ed963802b32b — video/references/race-and-speed.md:31-31 (list_item)

4. **Beat-locked cutting.** Loudness in the audio = shot count on the board (§8; the density ladder itself is `animatic-keyframes.md` §3). Silence = one held panel. Bang = a burst of 4–8-frame micro-panels. Cut length is engine RPM made visual: idle = long panels, redline = collapsing panels toward the green.

Extracted rules inside block: b7b4a7111bbf

## ac6f0f88ce9d02af — video/references/race-and-speed.md:32-32 (list_item)

5. **Cold combative palette** (§7). Steel blue, cyan, magenta, dirty mercury-white; **red as danger accent only** (brake glow, redline, tail-lights, the Tree's bulbs). No warm cozy amber wash — warmth appears only as toxin. Steal Tony Scott's grain, contrast and overexposure; **discard his warm grade.**

Extracted rules inside block: f62e6ea4c161

## d1446ff8a470391f — video/references/race-and-speed.md:33-33 (list_item)

6. **Every insert is load-bearing.** Each detail panel must be captionable with one race label — *setup / commitment / mistake / recovery / proof-of-speed / result* (§4). If you cannot label it, it is a *fantik* (`dramaturgy.md` §3) — drop it. A board that is all proof-of-speed with no commitment/mistake/recovery is a reel, not a story.

Extracted rules inside block: ea7ec3a10b98

## 8112aacad681c3c4 — video/references/race-and-speed.md:37-37 (heading)

## 2. Four schools worth stealing

Extracted rules inside block: NONE

## 3d10aed208541d40 — video/references/race-and-speed.md:39-39 (paragraph)

Four traditions, compressed. Each ends in its one transferable rule.

Extracted rules inside block: NONE

## 2536328e8ea9bd4b — video/references/race-and-speed.md:41-42 (paragraph)

**Kinetic montage (Wright, Ritchie, Boyle, Scott, Vaughn, Raimi, Aronofsky).** Time is elastic, every prop is a trigger, prep is an event. A keyframe cannot ramp or whip — so each moving trick compresses into one frozen cue (the six cues are catalogued in `animatic-keyframes.md` §4). Aronofsky's hip-hop montage is the single most transferable engine for prep-without-faces: a 6–9-panel ultra-CU strip of the start ritual, each panel one beat with a locked sound cue, the cluster **repeated two-to-three times with escalation** (calm → strained → violent). Repetition is memory; memory is emotion.
→ **Rule:** never write "motion" — write the artifact motion leaves behind, and never board a neutral panel (every frame carries a forward vector, negative space ahead of the subject).

Extracted rules inside block: d8570df3aaa0

## 0af94c9583ebddf6 — video/references/race-and-speed.md:44-45 (paragraph)

**Race-truth (Frankenheimer, Lelouch, Mangold/Papamichael, Howard/Dod Mantle, Refn).** Speed is a fact you earn by putting the camera where a real rig could bolt — bumper, hood lip, hostess-tray, axle, cabin. Low, wide and close, hard-mounted without vibration isolation so "cheeks shake", asphalt streaking in frame as the speedometer, mini-cams next to pistons and swelling tires for "an electron-microscope view of the car at its limit". Refn's cocoon: silence and stillness inside the shell, chaos outside, so the launch detonates. Refuse the crank — *Grand Prix* oiled tires for real smoke rather than fake the burnout.
→ **Rule:** if the implied camera could not physically mount on the car, the panel reads as render — drop it to bumper height and bolt it on.

Extracted rules inside block: NONE

## 8a29d1a965b010a9 — video/references/race-and-speed.md:47-48 (paragraph)

**Loaded composition (Bong, Park, Anderson, Kon).** With no faces, geometry and the depth stack do the acting (the FG/MG/BG depth method is `animatic-keyframes.md` §6). One geometric spine (centerline or Christmas Tree as the axis); every object an evidence (Park: "each object is a clue") or it is cut. Symmetry is handwriting — one held symmetric "breath" frame says balanced rivalry; break it the instant one car noses ahead. Kon's graphic-match pairs compress time across two adjacent keyframes sharing a shape at the same size and screen position.
→ **Rule:** a panel answers one question in the first glance and rewards a second look — one focal point, one emotion, three depth layers, zero dead objects.

Extracted rules inside block: NONE

## aea4171936a35e47 — video/references/race-and-speed.md:50-51 (paragraph)

**Rule-based ad (Honda *Cog*, Audi Quattro, Nike/Ritchie, Goodyear).** The drama is pure mechanism: every object does something irreversible, "let the machine talk" (no music), the entire spot first-person with no hero face. Tension is "will it fire". A static fetish shot of a gear lever flatlines; an object crossing a threshold says a decision just happened.
→ **Rule:** objects carry feeling only when they visibly **change state** — board the "after" (needle pinned in the red, ignition lamp blooming live, slick caught mid-fold), the "before" is implied.

Extracted rules inside block: NONE

## 57d684f74027fda5 — video/references/race-and-speed.md:55-55 (heading)

## 3. Selling speed in a single frame

Extracted rules inside block: NONE

## 1c87899d55dcf163 — video/references/race-and-speed.md:57-57 (paragraph)

A still has no engine note and zero motion. It sells velocity through the **speed-budget rule** — a frame reads fast only when **≥3 of five cues coexist** (camera at/below bumper height · asphalt streaking the lower frame · a near foreground reference passing the edge · sharp hero against motion-blurred background · a mechanical-vibration cue). The full rule, with the anti-fake firewall, lives in `animatic-keyframes.md` §4; do not re-derive it. One cue is a car photo; three is velocity; five and even a parked car reads dangerous. If a "fast" panel can't name three, reframe lower, drag the camera to the asphalt, throw a barrier into the foreground.

Extracted rules inside block: 95f3210f1616

## 25c40ab9bf112077 — video/references/race-and-speed.md:59-59 (paragraph)

Two race-domain extensions the general file does not carry:

Extracted rules inside block: NONE

## b18de87b2749ee20 — video/references/race-and-speed.md:61-61 (paragraph)

**The foreground reference catalog** (cue *c*, the cheapest and strongest speed multiplier). Place the reference *near the lens* (so it smears most) and *passing the edge* (so it reads as transiting, not parked). Keep one near object tack-sharp so the brain measures the smear against it.

Extracted rules inside block: NONE

## 704ce5d9d0770f9f — video/references/race-and-speed.md:63-63 (table_row)

| Reference object | Where to place it | Speed it implies |

Extracted rules inside block: NONE

## 748b3edd76d864a7 — video/references/race-and-speed.md:65-65 (table_row)

| Cone / timing block | near edge, elongated/smeared | lane-level rush |

Extracted rules inside block: NONE

## f40c1d047bee6368 — video/references/race-and-speed.md:66-66 (table_row)

| Armco barrier / wall | scraping the near side, streaked | proximity + velocity |

Extracted rules inside block: NONE

## fe0c9f77ee4e1171 — video/references/race-and-speed.md:67-67 (table_row)

| Lane stripe / chevron | lower frame, smeared toward bottom | ground speed |

Extracted rules inside block: NONE

## a3a8a48b3cb56845 — video/references/race-and-speed.md:68-68 (table_row)

| Christmas-Tree pylon | foreground, sharp anchor; car blurred | launch reference + timer |

Extracted rules inside block: NONE

## b7ea1b7f165a52e2 — video/references/race-and-speed.md:69-69 (table_row)

| Tree / lamp post / grandstand | whipping past, motion-rod | open-road pace |

Extracted rules inside block: NONE

## 820a31b833e23b46 — video/references/race-and-speed.md:70-70 (table_row)

| Tire smoke / spray | raked by backlight across frame | force + air movement |

Extracted rules inside block: NONE

## 10b091327816059c — video/references/race-and-speed.md:71-71 (table_row)

| Marshal / crowd at periphery | blurred, fragmented | scale + danger |

Extracted rules inside block: NONE

## d2c9806d52f4b538 — video/references/race-and-speed.md:73-73 (paragraph)

**Long-lens compression** — the second speed register and the antidote to "only blur sells speed". Frankenheimer's 1000mm stacked distant cars onto the hero so closing distance reads as collapse. Pair compression panels with low-wide panels in the cut; never board the whole spot on one lens. In `seedance.md`/`veo.md` syntax name "motion blur, fast-shutter look on background, sharp subject" explicitly — models default to over-clean stabilization (the prompt skeleton is `animatic-keyframes.md` §7).

Extracted rules inside block: 389299b29763
