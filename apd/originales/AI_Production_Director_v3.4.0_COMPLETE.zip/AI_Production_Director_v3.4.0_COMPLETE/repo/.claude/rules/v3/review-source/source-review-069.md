# Source coverage review 69/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 522855765f3229dd — image/references/slides.md:182-182 (paragraph)

**Размеры:** широкие/плоские (hero) | узкие/высокие (списки) | квадратные (иконки)

Extracted rules inside block: NONE

## 43eb85cf561b2b42 — image/references/slides.md:184-184 (paragraph)

**Сетки:**

Extracted rules inside block: NONE

## f73a48e2119e82b1 — image/references/slides.md:185-192 (code)

```
3-block:           6-block:             9-block:
┌───────┬───┐     ┌───┬───┬───┐       ┌─────┬───┬───┐
│ HERO  │SEC│     │ S │ S │ S │       │HERO │MED│ S │
├───────┴───┤     ├───┴───┼───┤       ├──┬──┴───┼───┤
│  FOOTER   │     │ CHART │LST│       │S │ MED  │ S │
└───────────┘     └───────┴───┘       └──┴──────┴───┘
```

Extracted rules inside block: NONE

## f128fee8ac5d06cc — image/references/slides.md:194-194 (paragraph)

**Prompt:**

Extracted rules inside block: NONE

## 795b6dfb2029246b — image/references/slides.md:195-199 (code)

```
Layout: bento grid, [N] blocks
Hero block: [MAIN], Medium: [SECONDARY], Small: [ICONS]
Gaps: uniform spacing
```

Extracted rules inside block: NONE

## 3a14b1b75650e80e — image/references/slides.md:203-203 (heading)

### Asymmetric Grid

Extracted rules inside block: NONE

## 0909204c30362705 — image/references/slides.md:205-205 (paragraph)

Динамичные композиции с визуальным балансом.

Extracted rules inside block: NONE

## e88794f21fbf6306 — image/references/slides.md:207-207 (paragraph)

**Rules:**

Extracted rules inside block: NONE

## 123e3630e0cca938 — image/references/slides.md:208-208 (list_item)

- Начинай с базовой сетки, потом ломай осознанно

Extracted rules inside block: NONE

## ff33ac15d9c6fc7c — image/references/slides.md:209-209 (list_item)

- Балансируй вес: крупный элемент слева = несколько мелких справа

Extracted rules inside block: NONE

## 7306e078f43b9ebd — image/references/slides.md:210-210 (list_item)

- Rule of Thirds для естественного баланса

Extracted rules inside block: NONE

## 43b5b21dd12c4fb7 — image/references/slides.md:211-211 (list_item)

- Ключевые элементы выделяй размером и положением

Extracted rules inside block: NONE

## 811115f1dbfe8e63 — image/references/slides.md:213-214 (paragraph)

**Применять:** креативные презентации, портфолио, fashion, стартапы
**НЕ применять:** банки, госпорталы, B2B с большими данными, пожилая аудитория

Extracted rules inside block: NONE

## aa51d980c81be0b9 — image/references/slides.md:216-216 (paragraph)

**Prompt:**

Extracted rules inside block: NONE

## 422a898fce8e28fb — image/references/slides.md:217-222 (code)

```
Layout: asymmetric composition
Left: [LARGE - 60%], Right: [2-3 SMALLER stacked]
Balance: visual weight distributed
Rule of thirds positioning
```

Extracted rules inside block: NONE

## 4994f124b80fa200 — image/references/slides.md:226-226 (heading)

### Negative Space

Extracted rules inside block: NONE

## 4cc5ce137b4867b5 — image/references/slides.md:228-228 (paragraph)

Пространство как инструмент фокусировки.

Extracted rules inside block: NONE

## 7387b6c3d865ec45 — image/references/slides.md:230-230 (paragraph)

**Rules:**

Extracted rules inside block: NONE

## 037169509faaf4a2 — image/references/slides.md:231-231 (list_item)

- Структурирует, а не создаёт пустоту ради красоты

Extracted rules inside block: NONE

## 9f6fe8cca12af7de — image/references/slides.md:232-232 (list_item)

- Управляет вниманием, фокусирует на главном

Extracted rules inside block: NONE

## 7aa49e7a8fb9cd40 — image/references/slides.md:233-233 (list_item)

- Gestalt: элементы с пространством = отдельные, близко = связанные

Extracted rules inside block: NONE

## d95923773c7856c6 — image/references/slides.md:235-236 (paragraph)

**Применять:** премиальные бренды, минималистичные презентации, hero-секции
**НЕ применять:** новостные порталы, дашборды, мобильные версии

Extracted rules inside block: NONE

## 1a8387f03dacde9f — image/references/slides.md:238-238 (paragraph)

**Prompt:**

Extracted rules inside block: NONE

## 084a79f680d3aa81 — image/references/slides.md:239-243 (code)

```
Layout: generous whitespace
Focal point: [ELEMENT] with breathing room
Empty space: intentional, guides eye to [CTA]
```

Extracted rules inside block: NONE

## e91625987e4810fc — image/references/slides.md:247-247 (heading)

### Split Screen

Extracted rules inside block: NONE

## 764cd11aa4ce3766 — image/references/slides.md:249-249 (paragraph)

Двухколоночная композиция.

Extracted rules inside block: NONE

## 7cd2179b4de5381c — image/references/slides.md:251-251 (paragraph)

**Пропорции:**

Extracted rules inside block: NONE

## 31335ae294889da3 — image/references/slides.md:252-252 (list_item)

- 50/50 - равноценные элементы

Extracted rules inside block: NONE

## 0c37efde7de2cccd — image/references/slides.md:253-253 (list_item)

- 60/40 - акцент на одной стороне

Extracted rules inside block: NONE

## b35e7ae7c0ec6fb7 — image/references/slides.md:254-254 (list_item)

- 70/30 - явный герой + поддержка

Extracted rules inside block: NONE
