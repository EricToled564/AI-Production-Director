# Source coverage review 172/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f755cee85fd86730 — video/references/seedance-25.md:235-235 (list_item)

3. **Negatively constrain the known failure.** "No soft-body or mollusk-like twisting of the mecha structure (must maintain metallic rigidity)." "The amber stays attached to the palm and must not clip through the fingers."

Extracted rules inside block: abe8bb8a6287

## 03d08b35de1d2ba3 — video/references/seedance-25.md:236-236 (list_item)

4. **Gate events on triggers.** "Three seconds after she presses the button..." / "only when he says {now}..." — triggers beat raw seconds for anything tied to performance.

Extracted rules inside block: b915d97cff3f

## bf4dd3b645389d51 — video/references/seedance-25.md:238-238 (heading)

## 12. Video editing (partial re-render)

Extracted rules inside block: NONE

## 28202ae31089f3bb — video/references/seedance-25.md:240-240 (paragraph)

2.5 edits an existing video: replace a subject, swap a background, remove a watermark, change the spoken language — while everything else stays put. The canonical pattern:

Extracted rules inside block: NONE

## c48b8795bc9e4a68 — video/references/seedance-25.md:242-250 (code)

```text
[Edit Goal] Edit @Video 1. Within <entire video or time range>,
<add / remove / replace / adjust> <object, region, or audio category>.
[Source Video Role] @Video 1 is the sole editing master. It defines <characters,
scene, actions, composition, camera movement, occlusion, audio, and event order>.
[Target Material Role] @Image 1 defines <attributes of the replacement>.
[Edit Scope] Modify only <object, region, time range, or audio category>.
[Content to Preserve] Keep <everything that must not change> from @Video 1.
```

Extracted rules inside block: NONE

## c951624daa2b9640 — video/references/seedance-25.md:252-252 (list_item)

- **Subject replacement** adds a `[Timeline Inheritance]` block: "<Target> inherits every appearance, motion, occlusion, and exit of <original>, including timing, duration, path, and speed changes." Close with the catch-all: "Except for the object explicitly modified above, keep all other people, props, scene content, camera movements, cuts, and event order from @Video 1 unchanged."

Extracted rules inside block: NONE

## 8f7a1a2082581c5c — video/references/seedance-25.md:253-253 (list_item)

- **The preservation-clause opener.** For filmed footage, enumerate everything to keep before stating any change — down to focal length, aspect and floor perspective: "Fully preserve from @Video 1 the person's identity, face, hair, skin tone, lip movement, original voice, speech rhythm, expression, gestures, camera position, focal length, aspect ratio, wall and floor perspective, and total duration." The longer the keep-list, the less drift.

Extracted rules inside block: NONE

## 460b01b3ae886a1c — video/references/seedance-25.md:254-254 (list_item)

- **Anchor timing to speech, not seconds**, when the source has narration: "When they say {now look at my hand}, a golden amber appears in the palm." The voice is the timeline.

Extracted rules inside block: NONE

## beaae38b574a7f5b — video/references/seedance-25.md:255-255 (list_item)

- **Slice long sources first.** Editing works best on clips ≤20s; longer sources stall or fail.

Extracted rules inside block: NONE

## 5af87d69876d07c2 — video/references/seedance-25.md:256-256 (list_item)

- **Audio-only edits** work: "Remove only the original background music. Keep the dialogue, lip sync, ambience, and action sound effects; preserve the visuals and editing rhythm."

Extracted rules inside block: NONE

## 2e421110452209cb — video/references/seedance-25.md:257-257 (list_item)

- **Localization pattern** — shoot once, re-dub per market: "Replace the Chinese narration in @Video 1 with natural fluent Spanish, and replace the presenter with a Spanish woman. Keep the original camera movement, blocking, performance pacing, scene, and product; preserve the overall audio-visual rhythm."

Extracted rules inside block: NONE

## aa801d6540f42732 — video/references/seedance-25.md:258-258 (list_item)

- Background swap scope: "modify only the background outside the subject's silhouette."

Extracted rules inside block: NONE

## 41457faf49288874 — video/references/seedance-25.md:260-260 (heading)

## 13. Video extension

Extracted rules inside block: NONE

## 200f0e7faec8bfdc — video/references/seedance-25.md:262-262 (paragraph)

Any clip ≤30s extends by 4-30s per pass, nested repeatedly, **hard ceiling 60s**. The new prompt applies only to the appended segment; original frames are untouched. Required verbs: extend forward / extend backward / continue.

Extracted rules inside block: ea2e1dcd618b

## 37cacb1c669af429 — video/references/seedance-25.md:264-264 (paragraph)

Forward:

Extracted rules inside block: NONE

## e2dc4a07e3a0cfe4 — video/references/seedance-25.md:266-273 (code)

```text
Extend @Video 1 forward. The first frame of the extended segment directly
continues from the last frame of @Video 1. Maintain continuity in <pose,
prop position, background, camera position, lighting, motion direction>.
Then, <new content>.
Keep each subject as the same continuous instance throughout: do not duplicate
or split it, and keep the person's appearance stable.
```

Extracted rules inside block: NONE

## bc69c56802907ef5 — video/references/seedance-25.md:275-275 (paragraph)

Backward (prepend a beginning): describe the preceding events, then define @Video 1's **first frame as the extension's explicit end state**. Gotcha: materials that belong to the source video only must be flagged — "<X> must not appear early in the backward extension" — or later characters leak into the past.

Extracted rules inside block: b8b1647f0fec

## 92f52a38dc2e8de8 — video/references/seedance-25.md:277-277 (list_item)

- Boundary frames connect visually, not pixel-identically.

Extracted rules inside block: NONE

## f0ad7a7b8d0edfd7 — video/references/seedance-25.md:278-278 (list_item)

- Extensions hold character look, art style **and voice timbre** even without re-supplied references — plot-only extension prompts work.

Extracted rules inside block: NONE

## 401ddfaf969c06b5 — video/references/seedance-25.md:279-279 (list_item)

- Community-proven minimal extension prompt: "Extend the video. Keep character identity, facial structure, body proportions, lighting, art style, and the space fully unchanged. Only change camera movement; do not redesign character or action."

Extracted rules inside block: a7d91028cee6

## 43484cec01c13a03 — video/references/seedance-25.md:281-281 (heading)

## 14. Ultra Long mode (30-180s)

Extracted rules inside block: NONE

## 49a19c64983954dd — video/references/seedance-25.md:283-283 (paragraph)

A separate mode (not the same as extension): one submission, 30-180 seconds. Restate duration and aspect ratio at the top of the prompt. Two working registers:

Extracted rules inside block: NONE

## 4c2e56db9bf8cf81 — video/references/seedance-25.md:285-285 (list_item)

- **Timestamped** (1-minute ambient pieces): windowed beats with per-window bans — "0-20s (quiet opening): fixed camera... no shake, no characters enter, hard cuts prohibited."

Extracted rules inside block: b6561ce11e39

## fb5d87693d381056 — video/references/seedance-25.md:286-286 (list_item)

- **Narrative flow** (3-minute pieces): loose event chain with inline references — the official 3-minute example is a cat-waiter vlog listing a full day of beats with 12 image refs assigned by role, closed with "No subtitles throughout, no background music."

Extracted rules inside block: NONE

## f258014b84e574e0 — video/references/seedance-25.md:288-288 (paragraph)

Plan pacing in advance — without timestamps or a beat chain the back half drifts. Under the hood the pipeline generates segment-by-segment, carrying the **last ~3 seconds of each segment as the reference for the next** — which is why hand-offs are smooth and why a weak middle segment propagates forward. On Xiaoyunque the same mechanism powers chained extension to 90s plus **segment reshoot**: select a bad span on the timeline and regenerate only it, everything outside stays identical — the cheapest fix for pop-in objects and missed expressions.

Extracted rules inside block: NONE

## 61907a047a9c7cd9 — video/references/seedance-25.md:290-290 (heading)

## 15. Blockout and green screen

Extracted rules inside block: NONE

## 50828a3f8aaaad05 — video/references/seedance-25.md:292-292 (paragraph)

The controllability king: lock space, camera and staging in 3D first, let the model render materials and light. Two granularities:

Extracted rules inside block: NONE

## e2cdd647e3c66c52 — video/references/seedance-25.md:294-294 (list_item)

- **Coarse blockout** — primitive geometry as a "dynamic skeleton" (trajectories, blocking, camera path, cuts, light changes). **Map every primitive to a reference**: "The tall cylinder in @Video 1 corresponds to <Guide>. The rectangular block corresponds to <Display Cart>." Exclude the render style: "Do not use its gray geometry or empty scene." Best practice: **no limbed or winged models in coarse blockouts** — unless you write the full limb motion sequence, they go stiff.

Extracted rules inside block: 3c353235aa1d

## 4c8c9302d81ba4ca — video/references/seedance-25.md:295-295 (list_item)

- **Fine blockout** — complete 3D animation; the model re-renders materials, color and style only: "@Video 1 is a fine blockout reference. Preserve structure, action, spatial layout, camera position, camera movement, and cuts. Do not use its original gray materials or empty background. Re-render <subject> as <final subject>..." **Clean the viewport capture first**: remove path lines, coordinate axes, controllers and camera frustums. Coarse currently works better than fine.

Extracted rules inside block: c3c3a3f3860c

## 0410262a32508f13 — video/references/seedance-25.md:297-297 (paragraph)

Pipeline notes:

Extracted rules inside block: NONE
