# Source coverage review 165/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 279da9cb021eeede — video/references/race-and-speed.md:220-220 (paragraph)

The race-specific list of panels that kill credibility — do not draw. (The general per-panel earns-its-place checklist is `animatic-keyframes.md` §9; run that on every panel as well.)

Extracted rules inside block: d98fbbb32d52

## bcd28972c3fca9ec — video/references/race-and-speed.md:222-222 (list_item)

- [ ] No high, clean, "beauty" god-angle for action beats — drop to bumper height; low/wide/close beats polish.

Extracted rules inside block: NONE

## 020a73afea8f543a — video/references/race-and-speed.md:223-223 (list_item)

- [ ] No perfectly stable cabin — render visible vibration (trembling mirror, doubled needle, smeared rim); tilt 1–3°.

Extracted rules inside block: NONE

## e0164558088d697a — video/references/race-and-speed.md:224-224 (list_item)

- [ ] No long-lens speed panel without road texture or a passing reference object.

Extracted rules inside block: NONE

## 3746b315ce17ab92 — video/references/race-and-speed.md:225-225 (list_item)

- [ ] No panel that only works "when sped up" — build the speed into the static composition (squat, lifted nose, slick wrinkle).

Extracted rules inside block: NONE

## 8cbf6b2b8064b2c1 — video/references/race-and-speed.md:226-226 (list_item)

- [ ] No air around the car on a speed beat — crowd the near edge with barrier/rival/wall.

Extracted rules inside block: NONE

## 80aafa95faa87da9 — video/references/race-and-speed.md:227-227 (list_item)

- [ ] No sharp wheel rim on a moving car — smear the spokes into a disc.

Extracted rules inside block: NONE

## 9d069de4b22968ed — video/references/race-and-speed.md:228-228 (list_item)

- [ ] No shiny-bodywork beauty pass — shoot force transmission (tire load, chassis squat, exhaust flame).

Extracted rules inside block: NONE

## 3374e1d607fb86af — video/references/race-and-speed.md:229-229 (list_item)

- [ ] No ritual beat out of order or skipped (§5) — a knowing viewer reads the fake instantly.

Extracted rules inside block: NONE

## 70f02baa68c1cee0 — video/references/race-and-speed.md:230-230 (list_item)

- [ ] No warm cozy grade — cold palette, red as danger accent only, amber ≤15% and toxic (§7).

Extracted rules inside block: NONE

## 83c8f50f53eb591d — video/references/race-and-speed.md:231-231 (list_item)

- [ ] No banned panel: static fetish insert (lever/badge/wheel with no verb, no state-change); anatomy at rest; a detail you cannot caption with a §4 label; all-proof-of-speed board with no commitment/mistake/recovery; decorative dashboard clutter (keyring, dice, coffee cup — "each object is a clue"); warm wash without narrative function.

Extracted rules inside block: d69b1ed26e2c

## f8d6aac7ab021bfb — video/references/race-and-speed.md:233-233 (paragraph)

Before sending the board, run `animatic-keyframes.md` §9 (per-panel master checklist), `dramaturgy.md` §15 and `universal-rules.md` §13 over it. The most-violated step is the three-detail check — do not skip it.

Extracted rules inside block: 54fc383d3136

## be0f240d7a564d75 — video/references/race-and-speed.md:237-237 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 4f6e6dfc57970c0a — video/references/role-modes.md:1-1 (heading)

# Role modes

Extracted rules inside block: NONE

## a44fd94d0e227384 — video/references/role-modes.md:3-3 (paragraph)

This skill fuses three mindsets. Switch role based on the task stage. The dramaturgy layer sits underneath all three roles. For the full dramaturgy method (scene formula, Murch Rule of Six, blocking as choreography of desire, staging and subtext, three-layer storyboard, shot card template, rhythm ladder), load `references/dramaturgy.md`. Director mode leans heaviest on that file.

Extracted rules inside block: NONE

## 9bfa515d4aacef7b — video/references/role-modes.md:5-5 (heading)

## Contents

Extracted rules inside block: NONE

## 9f44f0ca89e93eca — video/references/role-modes.md:7-7 (list_item)

1. Director mode

Extracted rules inside block: cafc872ec70d

## 3338cf39b9ff9480 — video/references/role-modes.md:8-8 (list_item)

2. Screenwriter mode

Extracted rules inside block: a092f6e92a5a

## eed2fee1b6686f74 — video/references/role-modes.md:9-9 (list_item)

3. Editor mode

Extracted rules inside block: NONE

## 4a603268107d0cec — video/references/role-modes.md:10-10 (list_item)

4. Shot function taxonomy

Extracted rules inside block: 1db3d6f6a311

## 23e3bdddcb8f8313 — video/references/role-modes.md:14-14 (heading)

## 1. Director mode

Extracted rules inside block: NONE

## 7d841ecdf2de8c48 — video/references/role-modes.md:16-16 (heading)

### Trigger

Extracted rules inside block: NONE

## fc212c6f2ab8f573 — video/references/role-modes.md:18-18 (paragraph)

User asks to "придумать сцену", "разработать концепцию", "визуализировать идею", "сделай как Финчер", "предложи трактовку", "какой вайб", or shares a raw idea without structure.

Extracted rules inside block: NONE

## 20ebdf8ce8b2dee0 — video/references/role-modes.md:20-20 (heading)

### Mindset

Extracted rules inside block: NONE

## 90311abcd8d5ef4c — video/references/role-modes.md:22-22 (paragraph)

Every shot must answer at least one of these questions. If a shot answers none, delete it.

Extracted rules inside block: 326cf8d03185

## 4f88298e5f130ea0 — video/references/role-modes.md:24-24 (list_item)

- What changes emotionally?

Extracted rules inside block: NONE

## d4019b1fdce7f8a2 — video/references/role-modes.md:25-25 (list_item)

- What new information appears?

Extracted rules inside block: NONE

## 1b517e6e193880cb — video/references/role-modes.md:26-26 (list_item)

- What action moves the story?

Extracted rules inside block: NONE

## 340b6559996f1495 — video/references/role-modes.md:27-27 (list_item)

- What pressure increases?

Extracted rules inside block: NONE

## e5f3136e50c76a16 — video/references/role-modes.md:28-28 (list_item)

- What does the viewer need to notice?

Extracted rules inside block: 4ab25bb8abac
