# Source coverage review 36/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2605e0f1aaca2cae — image/references/creative-direction.md:26-26 (heading)

## Camera & Hardware

Extracted rules inside block: NONE

## 3b4b8b6280975aa9 — image/references/creative-direction.md:28-28 (paragraph)

Specify camera type to change the visual DNA of the image.

Extracted rules inside block: NONE

## 2d3baf62830f5deb — image/references/creative-direction.md:30-30 (paragraph)

**Hardware names that work:**

Extracted rules inside block: NONE

## a8486ad7d4461a4b — image/references/creative-direction.md:31-31 (list_item)

- GoPro — immersive, wide-angle distortion, action feel

Extracted rules inside block: NONE

## 4d5babe4fbc48659 — image/references/creative-direction.md:32-32 (list_item)

- Fujifilm — authentic color science, warm tones

Extracted rules inside block: NONE

## 5c2819ef8efadf8b — image/references/creative-direction.md:33-33 (list_item)

- Disposable camera — raw, nostalgic flash aesthetic, grain

Extracted rules inside block: NONE

## d856f65b8b6cd27d — image/references/creative-direction.md:34-34 (list_item)

- Hasselblad — medium format, shallow DOF, fashion/portrait

Extracted rules inside block: 947196a57881

## b1350874ca53ae41 — image/references/creative-direction.md:35-35 (list_item)

- iPhone — casual, smartphone aesthetic

Extracted rules inside block: NONE

## d57dd368ce4d25df — image/references/creative-direction.md:36-36 (list_item)

- Polaroid — instant film, white border, faded colors

Extracted rules inside block: NONE

## 2b7ca4a080fb75b1 — image/references/creative-direction.md:38-38 (paragraph)

**Angles:**

Extracted rules inside block: NONE

## 130ef6a60664c057 — image/references/creative-direction.md:39-39 (list_item)

- "Low angle" — power, drama

Extracted rules inside block: NONE

## 8a529b6b2ef5b3dc — image/references/creative-direction.md:40-40 (list_item)

- "Aerial view" / "bird's eye" — scale, pattern

Extracted rules inside block: NONE

## 454db2556c3dc26b — image/references/creative-direction.md:41-41 (list_item)

- "Eye-level" — neutral, relatable

Extracted rules inside block: NONE

## 9bd844a4d82cd15d — image/references/creative-direction.md:42-42 (list_item)

- "Dutch angle" — tension, unease

Extracted rules inside block: NONE

## 3e6edb5dd64abdbb — image/references/creative-direction.md:43-43 (list_item)

- "Worm's eye view" — extreme drama

Extracted rules inside block: NONE

## 073e262dbcf82884 — image/references/creative-direction.md:45-45 (paragraph)

**Shot types:**

Extracted rules inside block: NONE

## ec31823e38c4e6e2 — image/references/creative-direction.md:46-46 (list_item)

- Close-up, medium shot, wide shot, extreme close-up

Extracted rules inside block: NONE

## 0d79d756059779cd — image/references/creative-direction.md:47-47 (list_item)

- "Waist-up portrait", "full body", "over-the-shoulder"

Extracted rules inside block: ad50006e6370

## 8b3d6b46c456bf1e — image/references/creative-direction.md:49-49 (paragraph)

**Focus:**

Extracted rules inside block: NONE

## 16aeb5627fd9ee99 — image/references/creative-direction.md:50-50 (list_item)

- "Shallow depth of field" — blurred background

Extracted rules inside block: f0e8aa7f3324

## 100a801360ced0b7 — image/references/creative-direction.md:51-51 (list_item)

- "Deep focus" — everything sharp

Extracted rules inside block: NONE

## 09df8577bae41397 — image/references/creative-direction.md:52-52 (list_item)

- "Rack focus" — shift attention

Extracted rules inside block: NONE

## 0fff379ea6b635ca — image/references/creative-direction.md:53-53 (list_item)

- "Tilt-shift" — miniature effect

Extracted rules inside block: NONE

## 413b4ebe433c20c5 — image/references/creative-direction.md:55-55 (list_item)

> Note: Named lens parameters (50mm, f/2.8) are less reliable than

Extracted rules inside block: NONE

## d5ff2e64fd35a5a6 — image/references/creative-direction.md:56-56 (list_item)

> descriptive terms. Prefer "shallow depth of field" over "f/1.8".

Extracted rules inside block: 660027450936

## be7f64e4ec11875a — image/references/creative-direction.md:58-58 (heading)

## Color Grading & Film Stock

Extracted rules inside block: NONE

## 017a8a6b4a610d97 — image/references/creative-direction.md:60-60 (paragraph)

Set emotional tone through color and texture.

Extracted rules inside block: NONE

## 4d9b5c86f16c1ab6 — image/references/creative-direction.md:62-62 (paragraph)

**Film stocks:**

Extracted rules inside block: NONE

## 6046a618b25c9fb6 — image/references/creative-direction.md:63-63 (list_item)

- "Shot on 1980s color film, slightly grainy" — nostalgic

Extracted rules inside block: NONE

## bd63c482ebd91c57 — image/references/creative-direction.md:64-64 (list_item)

- "Kodak Portra 400" — warm skin tones, pastel highlights

Extracted rules inside block: NONE
