# Source coverage review 13/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 99e5319ea822a473 — aurora-prompt-linter/SKILL.md:92-92 (list_item)

- `OVERRIDE: slow motion - explícitamente quiero slow motion en este clip`

Extracted rules inside block: NONE

## f234eb535adcfa93 — aurora-prompt-linter/SKILL.md:94-94 (paragraph)

Frases que **NO** cuentan como override (genéricas, sin scope específico):

Extracted rules inside block: NONE

## 5dbbdcaf2c41ad5c — aurora-prompt-linter/SKILL.md:95-95 (list_item)

- "hazlo de todas formas"

Extracted rules inside block: NONE

## 3eac805e0afed8d7 — aurora-prompt-linter/SKILL.md:96-96 (list_item)

- "ya sé que está en la ref, déjalo"

Extracted rules inside block: NONE

## 8c66d41ab4d1bd97 — aurora-prompt-linter/SKILL.md:97-97 (list_item)

- "ready to copy paste"

Extracted rules inside block: NONE

## af72286690b79bf8 — aurora-prompt-linter/SKILL.md:98-98 (list_item)

- "dale"

Extracted rules inside block: NONE

## c63edd1a724d40d2 — aurora-prompt-linter/SKILL.md:100-100 (paragraph)

**Reglas críticas del override:**

Extracted rules inside block: NONE

## 8f86d792a7b21e04 — aurora-prompt-linter/SKILL.md:101-101 (list_item)

- Solo válido en el turno actual del usuario. Autorizaciones de turnos pasados NO persisten.

Extracted rules inside block: NONE

## c33142d89c7ac359 — aurora-prompt-linter/SKILL.md:102-102 (list_item)

- Cada prompt nuevo arranca STRICT (sin overrides activos).

Extracted rules inside block: NONE

## c4bb35bba356f70a — aurora-prompt-linter/SKILL.md:103-103 (list_item)

- Override de categoría completa (ej. `OVERRIDE: L`) cubre todos los términos de esa categoría.

Extracted rules inside block: NONE

## 25c2bc9a5ee1cfe7 — aurora-prompt-linter/SKILL.md:104-104 (list_item)

- Override de término específico (ej. `OVERRIDE: red performance tank`) solo cubre ese término.

Extracted rules inside block: NONE

## ebb8976a95e54865 — aurora-prompt-linter/SKILL.md:106-106 (heading)

## Word count por caso

Extracted rules inside block: NONE

## 4420bf0d34ee086e — aurora-prompt-linter/SKILL.md:108-108 (table_row)

| Case | Budget | Comportamiento |

Extracted rules inside block: NONE

## 3b34b888eaf3bff0 — aurora-prompt-linter/SKILL.md:110-110 (table_row)

| 1, 2 | 75-130 palabras | Max es HARD FAIL. Min es WARN no-bloqueante. |

Extracted rules inside block: NONE

## 8ad975d8449485bf — aurora-prompt-linter/SKILL.md:111-111 (table_row)

| 3a, 3b, 3c | 50-90 palabras | Max es HARD FAIL (Regla 10 v6.0). Min es WARN — compresión válida si intencional. |

Extracted rules inside block: NONE

## d7411b870be4ef35 — aurora-prompt-linter/SKILL.md:112-112 (table_row)

| 4 | 75-130 palabras | Same as 1/2. |

Extracted rules inside block: NONE

## 3f62c07e68f4978a — aurora-prompt-linter/SKILL.md:114-114 (paragraph)

El conteo se hace solo sobre MAIN (no incluye negative prompt block).

Extracted rules inside block: NONE

## 2b64d0ab4b5853dd — aurora-prompt-linter/SKILL.md:116-116 (heading)

## Output esperado

Extracted rules inside block: NONE

## e863a88a280c8364 — aurora-prompt-linter/SKILL.md:118-118 (paragraph)

Reporte de texto plano (o JSON con `--json`). Ejemplo de FAIL:

Extracted rules inside block: NONE

## c5ec084ee1899174 — aurora-prompt-linter/SKILL.md:120-147 (code)

```
============================================================
AURORA PROMPT LINTER REPORT v1.0
============================================================
Case: 3b (I2V FF + LF)
Word count (MAIN): 127 / budget (50, 90)
Negative prompt: present
Categories covered by refs: ['L', 'O', 'P', 'PR']
Sports broadcast mode: on

VIOLATIONS (27):
  FAIL [L] 'studio' - Static descriptor of category L (covered by refs)
  FAIL [L] 'concrete walls' - Static descriptor of category L (covered by refs)
  ...
  FAIL [STRUCTURE] 'word_count=127' - Above HARD MAX 90 (Regla 10 v6.0)

OVERRIDES ACCEPTED (1):
  OK 'red performance tank' - necesito reforzar color por seeds previas

SUGGESTIONS:
  -> Strip from MAIN: [...] (category L already covered by refs)
  -> Move to NEGATIVE block: [...]
  -> Fix structure: ['word_count=127']

STATUS: FAIL
Delivery BLOCKED. Iterate or grant OVERRIDE in current turn.
============================================================
```

Extracted rules inside block: NONE

## 9a61109c752324f2 — aurora-prompt-linter/SKILL.md:149-149 (paragraph)

Ejemplo de PASS:

Extracted rules inside block: NONE

## 0cc57039f84a0312 — aurora-prompt-linter/SKILL.md:150-153 (code)

```
STATUS: PASS
Delivery PERMITTED.
```

Extracted rules inside block: NONE

## aaad1ae77d0f6d6c — aurora-prompt-linter/SKILL.md:155-155 (heading)

## Limitaciones conocidas v1.0

Extracted rules inside block: NONE

## 6b5ebd41283fa9b9 — aurora-prompt-linter/SKILL.md:157-157 (list_item)

- **Sinónimos**: "tank top" en ref + "athletic shirt" en prompt no se detecta como redundante. Roadmap v1.1: tabla de sinónimos.

Extracted rules inside block: 0cf446f6b11a

## 4931a4fe09a1c114 — aurora-prompt-linter/SKILL.md:158-158 (list_item)

- **Sub-tags por categoría**: O.upper / O.lower / P.face / P.body no soportados — un ref tagueado como O cubre todo outfit. Si el ref solo muestra el torso pero el clip va a mostrar zapatos, hay falso positivo en "white sneakers". Roadmap v1.2.

Extracted rules inside block: NONE

## 212b594c7bd893fc — aurora-prompt-linter/SKILL.md:159-159 (list_item)

- **Vision check**: el linter no ve las imágenes, depende de los tags que el agente declara. Si tageo mal, falla en silencio. Mitigación: el agente debe re-verificar tags antes de invocar.

Extracted rules inside block: NONE

## cc84591085f7797c — aurora-prompt-linter/SKILL.md:160-160 (list_item)

- **Vocabulary base**: las listas en `scripts/vocabularies.yaml` están calibradas para casos típicos de Aurora (cycling, soccer, fitness). Si el proyecto usa otros dominios (cocina, automotriz, etc.) hay que expandir las listas.

Extracted rules inside block: 79b295934461

## 6638382305e9e728 — aurora-prompt-linter/SKILL.md:162-162 (heading)

## Integración con system prompt v6.1

Extracted rules inside block: NONE

## f5be989562df05a8 — aurora-prompt-linter/SKILL.md:164-164 (paragraph)

Si tu system prompt incluye Regla 28 (v6.1+), este linter es bloqueante — el agente NO entrega prompts sin pasar el linter o sin overrides válidos. Si tu system prompt es v6.0, el linter es opcional pero altamente recomendado.

Extracted rules inside block: NONE

## 409bcd99b36e7518 — aurora-prompt-linter/SKILL.md:166-167 (paragraph)

Ver `references/skill_update_step5.md` para la edit al skill prompt-production-protocol.
Ver `references/system_prompt_v6_1_rule28.md` para el bundle de 9 cambios que actualizan v6.0 → v6.1.

Extracted rules inside block: NONE
