# Source coverage review 196/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f6295eff9a553f98 — visual-asset-critic/tools/README.md:181-181 (heading)

### `shots-to-html.py`

Extracted rules inside block: NONE

## 8df4ba17a34f9b2a — visual-asset-critic/tools/README.md:183-183 (paragraph)

Renders an output folder into a single `preview.html`.

Extracted rules inside block: NONE

## 21207cca4994ab1e — visual-asset-critic/tools/README.md:185-191 (code)

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

Extracted rules inside block: NONE

## 904e7f13812e16e2 — visual-asset-critic/tools/README.md:193-196 (paragraph)

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Extracted rules inside block: 74cace178dee

## 001ab546ff2ed928 — visual-asset-critic/tools/README.md:198-199 (paragraph)

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

Extracted rules inside block: NONE

## 9667ccac4a1631c9 — visual-asset-critic/tools/README.md:201-202 (paragraph)

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

Extracted rules inside block: NONE

## c3672187bfeafe0b — visual-asset-critic/tools/README.md:204-205 (paragraph)

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

Extracted rules inside block: NONE

## 27e799f2fbf3adbc — visual-asset-critic/tools/README.md:207-207 (heading)

### `copy-prompt.py`

Extracted rules inside block: NONE

## 6a1dd2606965d47c — visual-asset-critic/tools/README.md:209-210 (paragraph)

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

Extracted rules inside block: NONE

## 18e99f788205f2c2 — visual-asset-critic/tools/README.md:212-217 (code)

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Extracted rules inside block: NONE

## d77073491f2dc57e — visual-asset-critic/tools/README.md:219-222 (paragraph)

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Extracted rules inside block: e3ad1bd8a607

## 0c173ec1c1ca8e35 — visual-asset-critic/tools/README.md:224-224 (paragraph)

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

Extracted rules inside block: NONE

## 5c66915fd845617a — visual-asset-critic/tools/README.md:226-226 (heading)

## Internal modules

Extracted rules inside block: NONE

## b6da144a5ff5228e — visual-asset-critic/tools/README.md:228-228 (paragraph)

Not entry points. Imported by the tools above.

Extracted rules inside block: NONE

## 683d1263d3f3d840 — visual-asset-critic/tools/README.md:230-231 (list_item)

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.

Extracted rules inside block: NONE

## 743ee625a5d28fe4 — visual-asset-critic/tools/README.md:232-233 (list_item)

- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

Extracted rules inside block: NONE

## 20855672c203012f — visual-asset-critic/tools/README.md:235-235 (heading)

## Adding new tools

Extracted rules inside block: NONE

## 2c3949cff53d837e — visual-asset-critic/tools/README.md:237-237 (list_item)

- Make it executable (`chmod +x`)

Extracted rules inside block: NONE

## 712902c2b8ae9bde — visual-asset-critic/tools/README.md:238-238 (list_item)

- Add a usage docstring at the top of the file

Extracted rules inside block: NONE

## afba908c1bd9bf7a — visual-asset-critic/tools/README.md:239-239 (list_item)

- Give it a `--selftest` that proves the check fires

Extracted rules inside block: NONE

## ef55ad9f585d00ef — visual-asset-critic/tools/README.md:240-240 (list_item)

- Document it in this README

Extracted rules inside block: NONE

## ad4387561c7bac02 — visual-asset-critic/tools/README.md:241-241 (list_item)

- Wire it into `tools/check.sh`, which is what CI calls

Extracted rules inside block: NONE

## 8308721de6c26a48 — visual-asset-critic/tools/README.md:243-243 (paragraph)

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

Extracted rules inside block: NONE

## 23142d52c12ce6f5 — visual-media/SKILL.md:2-9 (paragraph)

name: visual-media
description: Creación visual — fotografía, producción de video, animación, cine, contenido de formato corto (Reels/TikTok/Shorts) y postproducción. Cubre triángulo de exposición, reglas de composición, tipos de plano, movimientos de cámara, los 12 principios de animación de Disney, ritmo de edición, J-cut/L-cut, regla de los 180 grados y color grading. Usa este skill siempre que el usuario mencione fotografía, video, animación, cine, edición, postproducción, storyboard, guion técnico, encuadre, iluminación, plano, movimiento de cámara, colorización, Reels, TikTok, Shorts, photography, filmmaking, editing, color grading, 攝影, 影片, 動畫, 剪輯 o 短影音 — y también cuando pida un plan de rodaje, feedback sobre material grabado, storytelling visual, un flujo de producción audiovisual o decisiones de encuadre e iluminación, aunque nunca diga la palabra "skill". No aplicar a tareas de código, API o backend.
license: MIT
metadata:
  mcpmarket-version: 1.0.0
  source: mcpmarket-me plugin (knoxgraeme/mcpmarket-plugin)
  original-author: claude-domain-skills
  language: es-MX (traducido del original en chino tradicional)

Extracted rules inside block: NONE

## a8ab13163068ac25 — visual-media/SKILL.md:11-11 (heading)

# Creación Visual — Visual Media

Extracted rules inside block: NONE

## dc8ace2f2d663efd — visual-media/SKILL.md:13-13 (list_item)

> Contar historias con lenguaje visual y crear imágenes memorables.

Extracted rules inside block: NONE

## c0bd79ea74b68bf5 — visual-media/SKILL.md:15-15 (heading)

## Cuándo aplica

Extracted rules inside block: NONE

## e157635b66ad4378 — visual-media/SKILL.md:17-17 (list_item)

- Composición y técnica fotográfica

Extracted rules inside block: NONE

## a890b9512a7543b9 — visual-media/SKILL.md:18-18 (list_item)

- Planeación y producción de video

Extracted rules inside block: NONE

## 8665b09d0b233f03 — visual-media/SKILL.md:19-19 (list_item)

- Creación de contenido de formato corto

Extracted rules inside block: NONE
