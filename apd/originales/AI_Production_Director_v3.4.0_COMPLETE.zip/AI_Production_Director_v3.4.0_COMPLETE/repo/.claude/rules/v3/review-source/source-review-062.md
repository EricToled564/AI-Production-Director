# Source coverage review 62/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 903019567ad433c8 — image/references/patterns/poster-illustration.md:121-123 (code)

```
A symmetrical ornamental art print centered on a {peacock_variant} peacock in full tail display, viewed {view_angle}. Tail feathers fan into a perfect semicircle filling the upper two-thirds, each eye-spot rendered with iridescent {eye_colors} and fine barb texture. The peacock stands on a {base_element}. Flanking it symmetrically: {botanical_left} on the left mirrored by {botanical_right} on the right, stems and blossoms curving inward to frame the bird. {additional_fauna} near the upper corners. Background: {background_texture} in {background_color}. Style: {print_style} with visible {technique_marks} and slightly flattened color as from layered printing passes. Border: {border_style}. Palette: {palette}. Format: 3:4.
```

Extracted rules inside block: NONE

## 8627302138874846 — image/references/patterns/poster-illustration.md:127-127 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 46409742c27b8522 — image/references/patterns/ui-social.md:1-1 (heading)

# UI Mockups & Social Media Patterns

Extracted rules inside block: NONE

## 9126c46695ffc847 — image/references/patterns/ui-social.md:3-3 (paragraph)

Reusable prompt templates for social media ads, app store assets, dashboard mockups, and visual analysis boards. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

Extracted rules inside block: NONE

## a37ef41d51d1f020 — image/references/patterns/ui-social.md:7-7 (heading)

## Instagram Story Ad (9:16)

Extracted rules inside block: NONE

## a4c7cad5b282a1a7 — image/references/patterns/ui-social.md:9-9 (paragraph)

Use for vertical product or brand ads targeting Instagram Stories — hero product, bold headline, and swipe-up CTA zone at the bottom.

Extracted rules inside block: 04aa6cce32b4

## 2910fd6776482241 — image/references/patterns/ui-social.md:11-11 (paragraph)

<!-- Source concept: Instagram Story ad with glassmorphism elements and gradient background -->

Extracted rules inside block: NONE

## 3958c87640ede9d4 — image/references/patterns/ui-social.md:13-19 (code)

```
Scene: vertical 9:16 canvas, smooth gradient background from {gradient_top} to {gradient_bottom}, soft ambient glow behind the product
Subject: {product_name} — {product_description} — centered in the upper two-thirds of the frame, angled slightly for dimension
Important Details: two glassmorphism panels (frosted translucent white, 20% opacity, subtle border highlight at #FFFFFF30) flanking the product — one floating left, one floating right, slightly rotated, adding depth layers. Bold headline "{headline_text}" in {headline_font} at the top third, white or light-colored text with subtle drop shadow for readability. Small subtext "{subtext}" below the headline in lighter weight. Bottom 15% of canvas left as swipe-up CTA zone — thin upward-pointing chevron icon and "{cta_text}" in small caps, both in white. Product casts a soft colored shadow matching the gradient onto the background. Scattered {accent_elements} (glass spheres, soft bokeh circles, translucent geometric shapes) at 10-15% opacity for texture.
Use Case: Instagram Story ad, vertical social media placement, mobile-first brand campaign
Constraints: text must be legible on mobile screens (minimum visual weight), no text in the bottom 5% (system UI overlap zone), product must be the clear focal point, no more than 3 accent elements, glassmorphism panels must not obscure the product
```

Extracted rules inside block: NONE

## b9bc5bd59e5e557d — image/references/patterns/ui-social.md:21-21 (paragraph)

**Key levers:** `{product_name}`, `{product_description}` (shape, material, color), `{gradient_top}` / `{gradient_bottom}` (e.g. #6C3CE1 violet to #1A1A2E dark navy, #FF6B6B coral to #FFE66D warm yellow), `{headline_text}`, `{headline_font}` (bold condensed sans-serif, rounded geometric), `{subtext}`, `{cta_text}` (e.g. "Swipe Up", "Shop Now", "Learn More"), `{accent_elements}` (translucent spheres, soft light flares, floating geometric shards)

Extracted rules inside block: NONE

## 8631480aaf8fe1df — image/references/patterns/ui-social.md:23-23 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — headline text legibility and glassmorphism transparency effects need precision

Extracted rules inside block: 1c0709450969

## e37dbdf0c6a02909 — image/references/patterns/ui-social.md:27-27 (heading)

## Social Media Feed Post (1:1)

Extracted rules inside block: NONE

## 8bb74cb854e5986d — image/references/patterns/ui-social.md:29-29 (paragraph)

Use for square-format posts on Instagram or Facebook — quote cards, feature announcements, or product highlights with centered layout.

Extracted rules inside block: 7628b1e36afc

## 546da9380c7d4760 — image/references/patterns/ui-social.md:31-31 (paragraph)

<!-- Source concept: square social media post with brand color palette and centered typography -->

Extracted rules inside block: NONE

## c526756531036b16 — image/references/patterns/ui-social.md:33-45 (code)

```
Scene: square 1:1 canvas, solid or subtle textured background in {bg_color}, clean centered composition
Subject: {post_type} — {content_description}
Important Details:
  Background: {bg_treatment} (solid color, subtle noise texture at 3% opacity, or soft radial gradient from {bg_color} center to slightly darker edges)
  Primary text: "{primary_text}" in {primary_font}, {text_color}, centered horizontally, positioned in the upper half with comfortable margins (at least 10% padding from edges)
  Supporting element: {supporting_element} — positioned below the primary text, providing visual weight and context
  Brand strip: thin horizontal line or subtle divider in {accent_color} separating the primary content from a bottom section containing "{brand_name}" in small caps and {brand_mark} (logo mark or wordmark)
  Overall palette restricted to {palette} — no colors outside this set
  Text sized for legibility at phone-screen scale — primary text large enough to read in a thumbnail feed scroll
Use Case: Instagram feed post, Facebook post, LinkedIn visual, social media content calendar
Constraints: all text must remain legible at 320px display width, no decorative elements that compete with the message, centered balanced layout, no more than two type sizes (headline + body or headline + brand), background must not reduce text contrast below WCAG AA
```

Extracted rules inside block: NONE

## ac93ec09f7cc2aaf — image/references/patterns/ui-social.md:47-47 (paragraph)

**Key levers:** `{post_type}` (quote card, product feature, announcement, stat highlight), `{content_description}`, `{primary_text}`, `{primary_font}` (geometric sans-serif, modern serif, handwritten accent), `{text_color}` (#FFFFFF on dark, #1A1A1A on light), `{bg_color}` / `{bg_treatment}`, `{accent_color}`, `{brand_name}`, `{brand_mark}`, `{palette}` (e.g. navy #1B2A4A, gold #C9A84C, white #FFFFFF), `{supporting_element}` (product photo, icon illustration, data number in large type)

Extracted rules inside block: NONE

## 3690d565d5c3d9ce — image/references/patterns/ui-social.md:49-49 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — text-heavy layout; legibility at small sizes is critical

Extracted rules inside block: 992b4f13d91a

## 193d91865c96b936 — image/references/patterns/ui-social.md:53-53 (heading)

## App Store Screenshot

Extracted rules inside block: NONE

## c896e09f7c9c4ed9 — image/references/patterns/ui-social.md:55-55 (paragraph)

Use to create a polished App Store or Google Play listing screenshot — device frame with app UI inside, feature headline, and clean gradient background.

Extracted rules inside block: bedefd8aff7f

## ee23d1c5285c6a5d — image/references/patterns/ui-social.md:57-57 (paragraph)

<!-- Source concept: App Store marketing screenshot with iPhone device frame and feature callout -->

Extracted rules inside block: NONE

## 308b860709c06a0e — image/references/patterns/ui-social.md:59-71 (code)

```
Scene: vertical canvas, smooth gradient background from {gradient_top} to {gradient_bottom}, centered composition
Subject: {device_type} device frame displaying {app_name} UI — {screen_description}
Important Details:
  Device: realistic {device_type} bezel (space black / silver / natural titanium) with accurate corner radius and button placement, screen showing {screen_content} with proper iOS/Android status bar at top
  Headline: "{feature_headline}" in bold {headline_font}, positioned {headline_position} the device frame, {headline_color} text, 2-3 words maximum per line for impact
  Optional subheadline: "{subheadline}" in lighter weight below the headline, 60% opacity of headline color
  Device shadow: soft diffused shadow below the device, matching the gradient color (not pure black)
  Screen UI: {ui_description} — realistic interface elements with proper spacing, {ui_style} design system, readable text within the screen (even if small)
  Device centered vertically with equal breathing room above and below
Use Case: App Store product page, Google Play listing, app marketing material
Constraints: device bezel must look physically accurate (not a flat rectangle), screen content must be realistic and internally consistent UI (not random shapes), headline text must not overlap the device, gradient background only — no patterns or photos behind the device, one device only
```

Extracted rules inside block: NONE

## 6078fe146d106e07 — image/references/patterns/ui-social.md:73-73 (paragraph)

**Key levers:** `{device_type}` (iPhone 16 Pro, Pixel 9, Galaxy S25), `{app_name}`, `{screen_description}` (brief: what the screen shows), `{screen_content}` / `{ui_description}` (detailed: specific UI elements visible), `{ui_style}` (iOS native, Material 3, custom dark theme), `{feature_headline}`, `{headline_font}` (SF Pro Display, condensed geometric), `{headline_position}` (above, below), `{headline_color}`, `{subheadline}`, `{gradient_top}` / `{gradient_bottom}` (e.g. #1A1A2E to #0D0D1A for dark, #F0F4FF to #FFFFFF for light)

Extracted rules inside block: NONE

## c22b3459bbbfd4fb — image/references/patterns/ui-social.md:75-75 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — device bezel precision, small UI text, and headline legibility all demand high quality

Extracted rules inside block: 0a8b4c621dd6

## 3aa165d47cbefbf8 — image/references/patterns/ui-social.md:79-79 (heading)

## Dashboard Design Mockup

Extracted rules inside block: NONE

## c09de82661a25c6b — image/references/patterns/ui-social.md:81-81 (paragraph)

Use for realistic analytics dashboard mockups — dark or light theme with data visualizations, KPI cards, and sidebar navigation.

Extracted rules inside block: a63c22685af8

## 280eb90eef3d546a — image/references/patterns/ui-social.md:83-83 (paragraph)

<!-- Source concept: analytics dashboard UI mockup with charts, cards, and navigation -->

Extracted rules inside block: NONE

## d4bc775f028a15a9 — image/references/patterns/ui-social.md:85-100 (code)

```
Scene: full-screen desktop UI mockup, {theme_mode} theme, clean {design_system} design system
Subject: {dashboard_title} — analytics dashboard showing {data_domain} metrics
Important Details:
  Sidebar (left, 220px visual width): dark ({sidebar_bg}) vertical navigation with icon + label pairs for {nav_items}, active item highlighted with {accent_color} left border and slightly lighter background, collapsed user avatar and app logo at top
  Top bar: breadcrumb or page title "{page_title}" in medium weight, date range selector showing "{date_range}", notification bell icon with dot indicator
  KPI row (top of main area): {num_kpis} metric cards in a horizontal row — each card shows metric name in small caps, large number value, and a small trend indicator (green upward arrow or red downward arrow with percentage), card background {card_bg}
  Chart area (main): {chart_layout}
    Chart 1: {chart_1_type} showing {chart_1_data} — using {chart_1_colors}
    Chart 2: {chart_2_type} showing {chart_2_data} — using {chart_2_colors}
  Secondary section: {secondary_widget} (data table with alternating row colors, recent activity feed, or geographic heat map)
  Proper visual hierarchy — KPI numbers largest, chart labels smaller, navigation text smallest
  Realistic data values throughout — no placeholder "lorem ipsum" or obviously fake numbers
Use Case: SaaS product marketing, investor deck, UI/UX portfolio, feature specification
Constraints: data must look plausible (proper scales, reasonable percentages, formatted numbers), charts must use proper axes and labels, no overlapping UI elements, sidebar must not bleed into main content, {theme_mode} theme applied consistently — no mixing dark sidebar with light charts unless intentional
```

Extracted rules inside block: NONE

## 951ee3c3ded9607d — image/references/patterns/ui-social.md:102-102 (paragraph)

**Key levers:** `{theme_mode}` (dark / light), `{design_system}` (minimal flat, glassmorphism cards, shadowed Material), `{dashboard_title}`, `{data_domain}` (SaaS revenue, e-commerce orders, marketing campaign, IoT sensor monitoring), `{sidebar_bg}` (#0F1117 dark, #FFFFFF light), `{accent_color}` (#6366F1 indigo, #10B981 emerald, #F59E0B amber), `{nav_items}` (Dashboard, Analytics, Users, Settings, Reports), `{num_kpis}` (3-5), `{chart_1_type}` / `{chart_2_type}` (line chart, grouped bar chart, donut chart, area chart), `{chart_1_colors}` / `{chart_2_colors}` (hex values), `{card_bg}` (#1E1E2E dark card, #FFFFFF light card), `{secondary_widget}`

Extracted rules inside block: NONE

## a577ed9947d82402 — image/references/patterns/ui-social.md:104-104 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — dense text (labels, numbers, navigation), precise chart rendering, and small UI elements require high fidelity

Extracted rules inside block: 4fd613130265

## d1e5834b546f86d0 — image/references/patterns/ui-social.md:106-106 (heading)

### Nano Banana version:

Extracted rules inside block: NONE

## 76c038caba462e03 — image/references/patterns/ui-social.md:108-110 (code)

```
A {theme_mode}-themed analytics dashboard UI mockup for {dashboard_title}. Left sidebar ({sidebar_bg}) with navigation icons for {nav_items}, active item highlighted in {accent_color}. Top area: {num_kpis} KPI metric cards showing large numbers with trend arrows. Main area: {chart_1_type} visualizing {chart_1_data} in {chart_1_colors}, alongside a {chart_2_type} showing {chart_2_data}. Below: {secondary_widget}. Clean {design_system} design system, realistic plausible data values throughout, proper visual hierarchy. Desktop fullscreen layout. Format: 16:9.
```

Extracted rules inside block: NONE
