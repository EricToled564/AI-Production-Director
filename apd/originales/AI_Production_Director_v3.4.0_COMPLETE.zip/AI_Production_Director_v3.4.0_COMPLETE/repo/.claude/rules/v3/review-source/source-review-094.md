# Source coverage review 94/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4f7b4bcc9fc75fc7 — storyboard-architect/SKILL.md:37-40 (paragraph)

`run.json` is what makes the rest of the tree auditable later. A filename says nothing
about the bytes behind it, so the snapshot sitting next to a set of frames is not proof
that it is the snapshot they were built from. The hashes in `run.json` are that proof.
Write it once, at the end of the run, and never edit it.

Extracted rules inside block: 41309994e321

## 398d8e479fe39793 — storyboard-architect/SKILL.md:42-42 (paragraph)

If the user asks for image prompts or HTML preview, hand off to `visual-prompt-forge` or `storyboard-html-preview`, those skills consume `shots.json` directly. Don't try to do their job here.

Extracted rules inside block: 39e94b2bc769

## ef3668137e5567ee — storyboard-architect/SKILL.md:44-44 (heading)

## Inputs

Extracted rules inside block: NONE

## 9690b1e0032f1f6b — storyboard-architect/SKILL.md:46-46 (paragraph)

You need these. If any are missing, ask before drafting.

Extracted rules inside block: NONE

## 890b26567319cf87 — storyboard-architect/SKILL.md:48-48 (table_row)

| Input | Required? | Default if absent |

Extracted rules inside block: 205410f1a889

## 49a0062f5e0499eb — storyboard-architect/SKILL.md:50-50 (table_row)

| Brief (problem, audience, goal) | Yes | Ask |

Extracted rules inside block: NONE

## 903d8c0085f85771 — storyboard-architect/SKILL.md:51-51 (table_row)

| Total duration | Yes | Ask |

Extracted rules inside block: NONE

## b5baceb4c032f9bf — storyboard-architect/SKILL.md:52-52 (table_row)

| Aspect ratio | Yes | Ask (16:9, 9:16, 1:1) |

Extracted rules inside block: NONE

## ba9b019ef0a4933e — storyboard-architect/SKILL.md:53-53 (table_row)

| Beat framework | No | Suggest based on brief |

Extracted rules inside block: NONE

## 9eaf9062002201a7 — storyboard-architect/SKILL.md:54-54 (table_row)

| Brand-lock file path | No | Use `brand-packs/_template.md` and flag the gap |

Extracted rules inside block: 1d3c61a5ff91

## 7f004a09d1f35497 — storyboard-architect/SKILL.md:55-55 (table_row)

| Voiceover style (VO present, on-screen only, captions) | No | Ask if unclear |

Extracted rules inside block: NONE

## bd1e5c5d83665609 — storyboard-architect/SKILL.md:56-56 (table_row)

| Target generator(s) for downstream prompts | No | Note as "to be specified" |

Extracted rules inside block: NONE

## c69f7f8d4a5e7705 — storyboard-architect/SKILL.md:58-58 (heading)

## Workflow

Extracted rules inside block: NONE

## c967e700b33c25d2 — storyboard-architect/SKILL.md:60-60 (paragraph)

Follow this sequence. Don't skip steps even if the brief seems simple.

Extracted rules inside block: 3c026411e88c

## 282104c9e3acf590 — storyboard-architect/SKILL.md:62-62 (heading)

### Step 1. Read the brand-lock

Extracted rules inside block: NONE

## 4d9a63840191e6a7 — storyboard-architect/SKILL.md:64-64 (paragraph)

If a brand-lock file path is provided, read it first. Extract:

Extracted rules inside block: NONE

## 96de2b266c5b0502 — storyboard-architect/SKILL.md:66-66 (list_item)

- Palette (hex)

Extracted rules inside block: NONE

## 77b12984cf962536 — storyboard-architect/SKILL.md:67-67 (list_item)

- Typography

Extracted rules inside block: NONE

## ac8172128adc35c1 — storyboard-architect/SKILL.md:68-68 (list_item)

- Mood descriptors

Extracted rules inside block: NONE

## d228436022d89371 — storyboard-architect/SKILL.md:69-69 (list_item)

- "Never" list (what this brand will never do visually)

Extracted rules inside block: 1587ee9de988

## 7275353ce5efab0c — storyboard-architect/SKILL.md:70-70 (list_item)

- Motion language

Extracted rules inside block: NONE

## 366aa7ceb68acfd9 — storyboard-architect/SKILL.md:71-71 (list_item)

- Voice tone

Extracted rules inside block: NONE

## da0252d68bddf33c — storyboard-architect/SKILL.md:72-72 (list_item)

- Aspect-ratio preferences

Extracted rules inside block: 76d4bd134e39

## 5dcab8b3b3d63116 — storyboard-architect/SKILL.md:74-74 (paragraph)

If no brand-lock is provided, copy `brand-packs/_template.md` into the output as `brand-lock.snapshot.md` with a note: `# UNCONFIGURED, using template defaults. Recommend providing a real brand-lock for production work.`

Extracted rules inside block: 08a82c6e1ac9

## 201f15c50b03c396 — storyboard-architect/SKILL.md:76-76 (heading)

### Step 2. Pick the beat framework

Extracted rules inside block: NONE

## d3ea64834f3252dc — storyboard-architect/SKILL.md:78-78 (paragraph)

Read `references/beat-frameworks.md`. Pick the one that matches the brief. Common cases:

Extracted rules inside block: NONE

## db45f7ed69bc2d2a — storyboard-architect/SKILL.md:80-80 (list_item)

- Pain-reframe-promise → conversion content

Extracted rules inside block: NONE

## 98223eb7e80cc90f — storyboard-architect/SKILL.md:81-81 (list_item)

- Hero Trilogy → product hero films

Extracted rules inside block: NONE

## 4f6d313075570a03 — storyboard-architect/SKILL.md:82-82 (list_item)

- Founder Explainer → personal-brand content

Extracted rules inside block: NONE

## 1edc89a6222833ac — storyboard-architect/SKILL.md:83-83 (list_item)

- Content Spiral → kinetic typography / opinion pieces

Extracted rules inside block: NONE
