# Source coverage review 111/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c8bca124cb73224d — storyboard-architect/references/beat-frameworks.md:3-3 (paragraph)

Pick one. Don't invent a new one unless the brief genuinely doesn't fit. Document the choice in `storyboard.md`.

Extracted rules inside block: 2bc88674d62e

## 1eeca6c5c38f672a — storyboard-architect/references/beat-frameworks.md:5-5 (heading)

## Pain-Reframe-Promise (PRP)

Extracted rules inside block: NONE

## 8eb4be35c7584159 — storyboard-architect/references/beat-frameworks.md:7-7 (paragraph)

Default for conversion content. Three beats:

Extracted rules inside block: NONE

## eb283f47fec9ba94 — storyboard-architect/references/beat-frameworks.md:9-9 (list_item)

1. **Pain**, name the audience's actual problem in their actual language. Concrete, not abstract. "Your content feels random" not "marketing inefficiency."

Extracted rules inside block: f9d2c7e81b5b

## 46cc64ab050ccf15 — storyboard-architect/references/beat-frameworks.md:10-10 (list_item)

2. **Reframe**, flip the problem on its head. The point is *not* what they thought it was. "You don't have a content problem. You have an infrastructure problem."

Extracted rules inside block: 521e0c2da3cb

## c3fa1b2e7122f170 — storyboard-architect/references/beat-frameworks.md:11-11 (list_item)

3. **Promise**, what life looks like on the other side. Specific, verifiable, time-bound when possible.

Extracted rules inside block: 8a71279cfea7

## 1e400ac38741778c — storyboard-architect/references/beat-frameworks.md:13-14 (paragraph)

Timing for 30s: 0–8 / 8–22 / 22–30.
Timing for 60s: 0–15 / 15–45 / 45–60.

Extracted rules inside block: NONE

## 18a238ac47f288f2 — storyboard-architect/references/beat-frameworks.md:16-16 (paragraph)

Use when: ad creative, landing-page hero video, conversion-focused social.

Extracted rules inside block: 0ad6875e0c75

## 3e70f0e2872c60d6 — storyboard-architect/references/beat-frameworks.md:18-18 (heading)

## Hero Trilogy

Extracted rules inside block: NONE

## dcb7a4c7e6408069 — storyboard-architect/references/beat-frameworks.md:20-20 (paragraph)

Default for product films and brand films. Three beats:

Extracted rules inside block: NONE

## 59979cfc5dabbffb — storyboard-architect/references/beat-frameworks.md:22-22 (list_item)

1. **World**, set the context. Who lives in this world. What's broken about it.

Extracted rules inside block: c1d2e1e53a46

## 4ebf05db514bde1b — storyboard-architect/references/beat-frameworks.md:23-23 (list_item)

2. **Hero**, the product/founder/methodology arrives. Show what it does, not what it is.

Extracted rules inside block: d25a87a0209c

## ec083d8cc68554bc — storyboard-architect/references/beat-frameworks.md:24-24 (list_item)

3. **Transformation**, the world changes. Show before/after at scale.

Extracted rules inside block: 470dd96d5052

## 23e82d71ec740d95 — storyboard-architect/references/beat-frameworks.md:26-27 (paragraph)

Timing for 60s: 0–20 / 20–40 / 40–60.
Timing for 90s: 0–30 / 30–60 / 60–90.

Extracted rules inside block: NONE

## af94c9c76ea759ae — storyboard-architect/references/beat-frameworks.md:29-29 (paragraph)

Use when: product launches, brand films, anchor pieces.

Extracted rules inside block: 32ed2bd84d6c

## 145bde640ed1a2f2 — storyboard-architect/references/beat-frameworks.md:31-31 (heading)

## Founder Explainer

Extracted rules inside block: NONE

## fe70e0ffdb4d7edc — storyboard-architect/references/beat-frameworks.md:33-33 (paragraph)

Default for personal-brand video where a person speaks to camera. Five micro-beats:

Extracted rules inside block: NONE

## 559ef130b9bb2d85 — storyboard-architect/references/beat-frameworks.md:35-35 (list_item)

1. **Hook**, a one-line provocation (0–2s)

Extracted rules inside block: cab4e52dff0c

## 090b9f1d70ff3923 — storyboard-architect/references/beat-frameworks.md:36-36 (list_item)

2. **Stakes**, why this matters (2–8s)

Extracted rules inside block: e398871a98ae

## 6d207657ae927622 — storyboard-architect/references/beat-frameworks.md:37-37 (list_item)

3. **Insight**, the actual point (8–20s for 30s, 8–40s for 60s)

Extracted rules inside block: 8122fe00973e

## 330d5cb82af896e1 — storyboard-architect/references/beat-frameworks.md:38-38 (list_item)

4. **Proof**, one concrete example or data point

Extracted rules inside block: d2d9ae4a9608

## 46a191db62bfd02b — storyboard-architect/references/beat-frameworks.md:39-39 (list_item)

5. **CTA**, what to do next, narrow and specific

Extracted rules inside block: ffc3fd93bd1d

## 3caa7f32a29f8aa4 — storyboard-architect/references/beat-frameworks.md:41-41 (paragraph)

Use when: founder content, thought leadership, personal-brand pieces.

Extracted rules inside block: d8ef13aa426d

## a21e79d9011604eb — storyboard-architect/references/beat-frameworks.md:43-43 (heading)

## Content Spiral

Extracted rules inside block: NONE

## b0387b4b124f3b51 — storyboard-architect/references/beat-frameworks.md:45-45 (paragraph)

Default for kinetic typography or opinion content. The structure is recursive, each beat zooms in tighter:

Extracted rules inside block: NONE

## 0cdaa05b62062a81 — storyboard-architect/references/beat-frameworks.md:47-47 (list_item)

1. **Wide claim**, the headline take

Extracted rules inside block: 4e17f1dd8ce2

## 720d2f29e0a4e15e — storyboard-architect/references/beat-frameworks.md:48-48 (list_item)

2. **Zoom 1**, one layer of nuance

Extracted rules inside block: d9d177970d5b

## 36ce9021f7d24454 — storyboard-architect/references/beat-frameworks.md:49-49 (list_item)

3. **Zoom 2**, the layer underneath that

Extracted rules inside block: 393cce28b12e

## 69cb5fb9534d5e8c — storyboard-architect/references/beat-frameworks.md:50-50 (list_item)

4. **Snap-back**, return to the wide claim, now reframed by the zooms

Extracted rules inside block: 6c83e6473f99

## 10dc586823365933 — storyboard-architect/references/beat-frameworks.md:52-52 (paragraph)

Each zoom is 1.5–2x faster than the previous. Pacing accelerates inward.

Extracted rules inside block: NONE
