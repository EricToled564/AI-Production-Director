# Source coverage review 68/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 45525c8aeb15087a — image/references/slides.md:134-134 (list_item)

- Footer: "Minimal"

Extracted rules inside block: NONE

## 5c11fa7309a8c5d9 — image/references/slides.md:136-137 (paragraph)

**Weight:** thin | regular | medium | bold | extra bold
**Position:** "upper third", "left aligned 10% margin", "centered"

Extracted rules inside block: NONE

## a1caa5347715f742 — image/references/slides.md:139-139 (heading)

## Color Systems

Extracted rules inside block: NONE

## c0e7aae439931dd7 — image/references/slides.md:141-141 (paragraph)

**Dark palette:**

Extracted rules inside block: NONE

## 7151b551abbb69a0 — image/references/slides.md:142-142 (list_item)

- Near-black: #0a0a0a, #121212

Extracted rules inside block: NONE

## 40808bf2a9767492 — image/references/slides.md:143-143 (list_item)

- Deep tones: #0d3d2d, #1a2a3a

Extracted rules inside block: NONE

## a8f37c3ee34137db — image/references/slides.md:144-144 (list_item)

- Text: #ffffff, #e0e0e0

Extracted rules inside block: NONE

## 4e66c7a2545640e4 — image/references/slides.md:146-146 (paragraph)

**Light palette:**

Extracted rules inside block: NONE

## 9d6a0cd684d32071 — image/references/slides.md:147-147 (list_item)

- Off-white: #fafafa, #f8f9fa

Extracted rules inside block: NONE

## 425370571ddde2ef — image/references/slides.md:148-148 (list_item)

- Warm gray: #f5f5f4

Extracted rules inside block: NONE

## f39e08a20c7a00d2 — image/references/slides.md:149-149 (list_item)

- Text: #1a1a1a, #374151

Extracted rules inside block: NONE

## 3a145a29579b3f9c — image/references/slides.md:151-151 (paragraph)

**Data colors:**

Extracted rules inside block: NONE

## fbb48294699e60da — image/references/slides.md:152-152 (list_item)

- Positive: #22c55e

Extracted rules inside block: NONE

## 8a8edf5756141ee2 — image/references/slides.md:153-153 (list_item)

- Negative: #dc2626

Extracted rules inside block: NONE

## b5e854b43d0238c1 — image/references/slides.md:154-154 (list_item)

- Highlight: #3b82f6

Extracted rules inside block: NONE

## 364a53519a740315 — image/references/slides.md:156-156 (heading)

## Atmospheric Effects

Extracted rules inside block: NONE

## 6f4ae464a2c89bc3 — image/references/slides.md:158-158 (list_item)

- "Subtle gradient haze"

Extracted rules inside block: NONE

## a0bdc18bd43c766d — image/references/slides.md:159-159 (list_item)

- "White mist at ground level"

Extracted rules inside block: NONE

## 5338840d30d73427 — image/references/slides.md:160-160 (list_item)

- "Soft vignette darkening edges"

Extracted rules inside block: NONE

## 5278571048909545 — image/references/slides.md:161-161 (list_item)

- "Noise texture for premium feel"

Extracted rules inside block: NONE

## 8b1d0915138bb48b — image/references/slides.md:165-165 (heading)

## Layout Systems

Extracted rules inside block: NONE

## 3c26b5d4219a934a — image/references/slides.md:167-167 (paragraph)

Универсальные правила вёрстки. Работают с любым визуальным стилем.

Extracted rules inside block: NONE

## 74022bcfb8c9e0e1 — image/references/slides.md:171-171 (heading)

### Bento Grid

Extracted rules inside block: NONE

## a079b05f1ccb6158 — image/references/slides.md:173-173 (paragraph)

Модульная система из блоков разного размера.

Extracted rules inside block: NONE

## a19cb95aa90e8583 — image/references/slides.md:175-175 (paragraph)

**Core Rules:**

Extracted rules inside block: NONE

## 2eafc070f72da3f0 — image/references/slides.md:176-176 (list_item)

- Родительский контейнер с явными границами модулей

Extracted rules inside block: NONE

## 321207cf1ceed9c3 — image/references/slides.md:177-177 (list_item)

- Иерархия: важный контент → крупные блоки, второстепенный → мелкие

Extracted rules inside block: NONE

## 43cf27bda70b7b03 — image/references/slides.md:178-178 (list_item)

- Max 9 блоков (иначе перегруз)

Extracted rules inside block: NONE

## c58a27ffe5ed80b8 — image/references/slides.md:179-179 (list_item)

- Единообразные gaps (16px стандарт)

Extracted rules inside block: NONE

## dfcb546de1acf88c — image/references/slides.md:180-180 (list_item)

- Связанный контент группируется в одном блоке

Extracted rules inside block: NONE
