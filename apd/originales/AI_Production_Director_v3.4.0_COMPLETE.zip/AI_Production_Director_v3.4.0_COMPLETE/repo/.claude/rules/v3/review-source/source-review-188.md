# Source coverage review 188/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## b9c2357b8507c6f1 — visual-asset-critic/SKILL.md:156-156 (table_row)

| `generator`, `model_version` | the generator id from `_capabilities.json`, and its model version |

Extracted rules inside block: NONE

## d38f2d31f931dbcc — visual-asset-critic/SKILL.md:157-157 (table_row)

| `seed` | if the generator exposes one, else `null` |

Extracted rules inside block: NONE

## cbd5ac29389f3089 — visual-asset-critic/SKILL.md:159-163 (code)

```bash
shasum -a 256 output/frames/round-1/shot_03.png \
              output/prompts/round-1/flux.txt \
              output/brand-lock.snapshot.md
```

Extracted rules inside block: NONE

## e97690c02cc0c007 — visual-asset-critic/SKILL.md:165-168 (paragraph)

Every one of those fields is required, and every one is nullable. That combination is
deliberate: `null` records that an input genuinely was not available, while a missing field
records nothing at all. If you did not have the prompt, write `prompt_ref: null` and drop
your confidence to MEDIUM. Do not omit the key.

Extracted rules inside block: 5be8058e43e6, 9a4ae9206b4d

## 3866f1d08a9e33ca — visual-asset-critic/SKILL.md:170-172 (paragraph)

The hashes are the point. Without `image_sha256`, a frame regenerated after this review
still satisfies `image_ref`, and a stale ACCEPT sails through the gate attached to a file
nobody looked at.

Extracted rules inside block: NONE

## 249887bca962afa0 — visual-asset-critic/SKILL.md:174-174 (paragraph)

**Severity, assign one per issue.** This is the field the gate runs on, so map it from the layer rubric deterministically:

Extracted rules inside block: NONE

## a332c5fd49cf43ce — visual-asset-critic/SKILL.md:176-176 (table_row)

| Severity | Means | Maps from |

Extracted rules inside block: NONE

## 20b49b05966fcc0e — visual-asset-critic/SKILL.md:178-178 (table_row)

| `minor` | soft-fail, fixable in post | a soft-fail on any layer; `fix_type: post-level` |

Extracted rules inside block: NONE

## 0f29149db902ac99 — visual-asset-critic/SKILL.md:179-179 (table_row)

| `major` | hard-fail **with** a clear fix path | a hard-fail that a prompt change or re-roll fixes |

Extracted rules inside block: NONE

## 8e361b836309fdb5 — visual-asset-critic/SKILL.md:180-180 (table_row)

| `blocking` | hard-fail on a critical layer (Brand Lock / Series Lock) with **no** clear fix, or a defect that makes the asset unusable | an unrecoverable hard-fail |

Extracted rules inside block: NONE

## ba75b80ac79d4bd9 — visual-asset-critic/SKILL.md:182-182 (paragraph)

**Gating rule, the verdict is derived from severities, not chosen freely.** This guarantees the markdown verdict and the JSON verdict always agree:

Extracted rules inside block: 8b2233d57c2a

## 27eb1bf0693e0290 — visual-asset-critic/SKILL.md:184-184 (list_item)

- Any `blocking` issue ⇒ verdict is `REJECT`.

Extracted rules inside block: NONE

## a35924c8c459ae57 — visual-asset-critic/SKILL.md:185-185 (list_item)

- Three or more `major` issues ⇒ verdict is `REJECT`.

Extracted rules inside block: NONE

## 5426f1d533a0e90a — visual-asset-critic/SKILL.md:186-186 (list_item)

- One or two `major` issues (and no blocking) ⇒ verdict is `REVISE`.

Extracted rules inside block: NONE

## 8d4e804ee4c31930 — visual-asset-critic/SKILL.md:187-187 (list_item)

- Only `minor` issues, or none ⇒ verdict is `ACCEPT` (with post notes).

Extracted rules inside block: NONE

## d4b32e32af7c216a — visual-asset-critic/SKILL.md:189-191 (paragraph)

The three-major rule used to read "escalate to REJECT at your discretion." Discretion in a
gate is not a gate, and it disagreed with `references/critique-rubric.md`, which called
three hard fails a REJECT outright. It is now a threshold, and the validator enforces it.

Extracted rules inside block: NONE

## 37f0e6eec313d114 — visual-asset-critic/SKILL.md:193-193 (paragraph)

Pick the markdown `## Verdict` by this same rule.

Extracted rules inside block: NONE

## ed4930e767eddec2 — visual-asset-critic/SKILL.md:195-195 (heading)

### Step 7. Run the gate

Extracted rules inside block: NONE

## a56065358227e94a — visual-asset-critic/SKILL.md:197-197 (paragraph)

Writing a schema-valid critique is not the same as passing the gate. Run it:

Extracted rules inside block: NONE

## e4772e965c6c9b47 — visual-asset-critic/SKILL.md:199-201 (code)

```bash
python tools/validate_critique.py output/critiques/round-1/shot_03.critique.json
```

Extracted rules inside block: NONE

## bc171c6969ed0e8f — visual-asset-critic/SKILL.md:203-204 (paragraph)

Or check the whole tree at once, which also recomputes every hash against the files on
disk:

Extracted rules inside block: NONE

## 3b8bf7a2b7d19fef — visual-asset-critic/SKILL.md:206-208 (code)

```bash
python tools/validate_provenance.py output/
```

Extracted rules inside block: NONE

## bff852172729e05c — visual-asset-critic/SKILL.md:210-213 (paragraph)

This step is not optional and it is not someone else's job. A critique that says `ACCEPT`
while carrying a `major` issue is a bug, and the only reason to write a validator for that
bug is to actually run it. Before this step existed, the gate ran in CI against two
fixtures that ship in the repo and never once against a real client's critique.

Extracted rules inside block: 617eda9c61b2

## ca6244a08705984b — visual-asset-critic/SKILL.md:215-218 (paragraph)

Worked examples: `examples/critique.accept.json` and `examples/critique.revise.json` show
the shape at version `1.0`, which is still valid and carries no provenance.
`examples/worked-run/critiques/` shows version `1.1` with real hashes, two shots across two
rounds.

Extracted rules inside block: NONE

## 8f39ea289fa9e915 — visual-asset-critic/SKILL.md:220-220 (heading)

## Hard rules

Extracted rules inside block: NONE

## 1db9a2167bc7fbf0 — visual-asset-critic/SKILL.md:222-222 (heading)

### Rule 1. No vibes-based critique

Extracted rules inside block: NONE

## 710eeb65748fb16e — visual-asset-critic/SKILL.md:224-224 (paragraph)

"Looks great" / "feels off" without specifics is not a critique. Every observation must reference something in the image (composition, color, anatomy, lighting direction, etc.).

Extracted rules inside block: 65a4dc9ef74c

## 3367756ad1b8e010 — visual-asset-critic/SKILL.md:226-226 (heading)

### Rule 2. Prompt-level fixes must be specific

Extracted rules inside block: NONE

## 3f0653aa08a9b2ad — visual-asset-critic/SKILL.md:228-228 (paragraph)

"Change the prompt" is not a fix. "Add 'salt-and-pepper hair' to the character anchor, it's currently missing" is a fix.

Extracted rules inside block: NONE

## c6fe40208ab1d4a6 — visual-asset-critic/SKILL.md:230-230 (heading)

### Rule 3. Don't critique what wasn't asked

Extracted rules inside block: NONE
