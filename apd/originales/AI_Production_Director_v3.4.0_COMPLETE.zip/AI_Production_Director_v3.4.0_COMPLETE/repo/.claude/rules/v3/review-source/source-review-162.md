# Source coverage review 162/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4b144625f25b97c6 — video/references/race-and-speed.md:75-75 (paragraph)

(The full "what kills the speed" audit lives once, in §10.)

Extracted rules inside block: NONE

## 8915e8bc1c8e6713 — video/references/race-and-speed.md:79-79 (heading)

## 4. Storytelling without faces — the race captioning system

Extracted rules inside block: NONE

## 1ae58b9857b9ab79 — video/references/race-and-speed.md:81-81 (paragraph)

A face does four jobs: internal state, where it looks, the cost, the decision. Banned, those jobs redistribute — **decision → anatomy mid-action; internal state → an object crossing a threshold; looking/rivalry → space.** The mechanism, the EMOTION→OBJECT substitution table and the state-change cheat-sheet are owned by `animatic-keyframes.md` §5; do not duplicate them. Two filters before you draw: name the **verb** on any hand/foot panel (grip / latch / shift / preload / release — no verb, no panel), and board only the **after** state of any object threshold (Honda *Cog*). Pick ONE hero object and board it three times at rising intensity — beats twelve unrelated inserts (`dramaturgy.md` §13).

Extracted rules inside block: 4c0f78fc213e

## 7b6afc731916ced9 — video/references/race-and-speed.md:83-83 (paragraph)

What this file owns is the **race captioning system** — the margin label that proves an insert is load-bearing (Law 6). Every detail keyframe gets exactly one. If you cannot assign one, drop the panel.

Extracted rules inside block: NONE

## 56014ff2cfca617a — video/references/race-and-speed.md:85-85 (table_row)

| Label | Story job | Typical object / crop | Skill tag (`role-modes.md` §4) |

Extracted rules inside block: NONE

## e3a1ca3810d8c979 — video/references/race-and-speed.md:87-87 (table_row)

| **setup** | establishes capability / readiness | glove pull, harness latch, ignition dead | Establish / Detail |

Extracted rules inside block: NONE

## 4760a4ec36de4d63 — video/references/race-and-speed.md:88-88 (table_row)

| **commitment** | point of no return chosen | foot pins throttle, shifter rammed home, ignition live | Shift / Impact |

Extracted rules inside block: NONE

## e796df5a07a677ea — video/references/race-and-speed.md:89-89 (table_row)

| **mistake** | something slips / over-limit | tire shake, wheel fights back, revs flare wrong | Pressure / Impact |

Extracted rules inside block: NONE

## d598131ef897632c — video/references/race-and-speed.md:90-90 (table_row)

| **recovery** | control reclaimed | hand catches the correction, tach settles back into band | Shift |

Extracted rules inside block: NONE

## 66f1e0d7e164d328 — video/references/race-and-speed.md:91-91 (table_row)

| **proof-of-speed** | force is real, not staged | chassis squat, slick wrinkle, exhaust flame, asphalt streak | Power / Pressure |

Extracted rules inside block: NONE

## cd31452f0d673f5a — video/references/race-and-speed.md:92-92 (table_row)

| **result** | who won the inch | finish stripe, slicks ballooned at trap, one nose ahead, chute bloom | Impact / Aftermath |

Extracted rules inside block: NONE

## eb316970941cf0cd — video/references/race-and-speed.md:94-94 (paragraph)

(Banned panels are consolidated in §10.)

Extracted rules inside block: d8522c195f93

## 7eb19d059b2cefd8 — video/references/race-and-speed.md:98-98 (heading)

## 5. The race ritual (liturgy) + the 5 shot families

Extracted rules inside block: NONE

## 9c391521c6f0b4fd — video/references/race-and-speed.md:100-100 (paragraph)

The race is not a chase, it is a *liturgy*. Every phase is a legible, irreversible state-change a knowing viewer reads instantly — muddle the order and the spot dies. The countdown *tightens cut length toward the green*, then explodes: the drag-specific instance of the `dramaturgy.md` §12 rhythm staircase. Draw one anchor keyframe per beat. In a faceless spot **Reaction** is reassigned from a human face to the *machine's* face — the needle jumping, the slick wrinkling, the nose squatting. Gauges and rubber are the actor.

Extracted rules inside block: NONE

## 0b06b0d44c228ea0 — video/references/race-and-speed.md:102-102 (table_row)

| # | Ritual beat | Function | Keyframe to draw (still) | Light (cold) | Emotion |

Extracted rules inside block: NONE

## 7c0918589a99a222 — video/references/race-and-speed.md:104-104 (table_row)

| 1 | Water box entry | Establish | Front slick easing into mirror-still water, chalk/box edge in frame, bulbs reflected in the sheet | Steel-blue dusk, wet specular | coiled stillness |

Extracted rules inside block: NONE

## 9a6c384d220387cb — video/references/race-and-speed.md:105-105 (table_row)

| 2 | Burnout (white→blue) | Power | Ground-level wall of smoke off the rear, plume backlit; car straining on line-lock | Hard cyan backlight through smoke | barely-leashed force |

Extracted rules inside block: NONE

## 5aa7fbdd08e22113 — video/references/race-and-speed.md:106-106 (table_row)

| 3 | Reverse settle | Pressure | Rear rolling back through its own drifting smoke toward the beams, tail-lights bleeding red into haze | Smoke haze, low key, red tail wash | deliberate menace |

Extracted rules inside block: NONE

## 127a12828a490f7f — video/references/race-and-speed.md:107-107 (table_row)

| 4 | Pre-stage bulb | Pressure | Front tyre creeping, top blue bulb lit as anchor, beam line as a graphic spine on asphalt | Blue bulb glow on wet metal | held breath |

Extracted rules inside block: NONE

## b6ea8a4a5824df35 — video/references/race-and-speed.md:108-108 (table_row)

| 5 | Stage bulb | Pressure | Second blue bulb lit, tyre on the line, knuckles whitening on wheel/trans-brake (depth: bulb BG, hand FG) | Two blue bulbs, deep black | point of no return |

Extracted rules inside block: NONE

## d6748553175296ec — video/references/race-and-speed.md:109-109 (table_row)

| 6 | Amber countdown | Pressure→Shift | The Tree as timer — three ambers, sequential (see below) | Amber pulse (the only narrative warm light) | trigger tension |

Extracted rules inside block: NONE

## 7edccfc8b1a5c6fa — video/references/race-and-speed.md:110-110 (table_row)

| 7 | Green / launch | Impact | Both cars squatting on rear suspension, front wheels lifting, asphalt streaking back | Green flash + hard flare | release / violence |

Extracted rules inside block: NONE

## 6df497bfa3a1106b — video/references/race-and-speed.md:111-111 (table_row)

| 8 | Slick wrinkle (hero) | Detail/Reaction | Macro into rear sidewall folding/wrinkling as it hooks — *the* hero detail, the held/ramp beat | Hard side light, smoke bloom | physics made visible |

Extracted rules inside block: NONE

## 803a7c66eabd20f9 — video/references/race-and-speed.md:112-112 (table_row)

| 9 | Shift / exhaust flame | Detail | Hand slamming shifter with chassis twist, OR header pipe spitting flame | Flame as warm spark in cold frame | escalation |

Extracted rules inside block: NONE

## 5a84ec981b069ce0 — video/references/race-and-speed.md:113-113 (table_row)

| 10 | The pass | Power | Joust / parallel tracking, asphalt streaking, rival lane in frame | Streaked specular, motion-rod lights | duel |

Extracted rules inside block: NONE

## 1aecd8d680ea25ad — video/references/race-and-speed.md:114-114 (table_row)

| 11 | Finish | Impact | Top-end: slicks "blown up"/distorted, cars inches apart crossing the line, one nose ahead | Cold-white finish pool | margin |

Extracted rules inside block: NONE

## dbbbb0e5621eb266 — video/references/race-and-speed.md:115-115 (table_row)

| 12 | Chutes / aftermath | Aftermath/Exit | Parachutes blooming, smoke drifting through headlight beams, OR hand unclenching off the wheel | Falling light, residue haze | consequence |

Extracted rules inside block: NONE

## 924c7616842c9f3f — video/references/race-and-speed.md:117-117 (paragraph)

**Amber logic (decision point).** Choose the **Sportsman / full tree** for an ad: three ambers fire *sequentially 0.5s apart* — three drawable keyframes, a stretched drum-roll of dread with cut length collapsing toward the green. The Pro tree fires all three at once — one panel, brutal but no build. Draw the Sportsman stagger. Always leave on the **last amber, not the green** (holeshot): the launch keyframe precedes the green-lit panel by a frame, which makes it read as *anticipation*, not reaction.

Extracted rules inside block: 87864ef40db0

## d5cd48e22e3732c0 — video/references/race-and-speed.md:119-119 (paragraph)

**Drift adaptation — the slip-angle liturgy.** Drift swaps the countdown for a *continuous angle ritual*: **approach → entry → clutch-kick initiation → counter-steer hold → clipping point (wall proximity) → smoke wall → transition (flick) → exit.** The **counter-steer** replaces the slick-wrinkle as the "physics made visible" anchor — ECU/CU of hands wound into opposite lock, forearms crossed, wheel at full angle, cold side-light on knuckles, the steering angle drawn large and unmistakable. **Wall proximity** is danger without a face: barrier hard and sharp in the foreground layer, car door a hand's-width away, motion-streak on the wall texture — the gap *is* the emotion. The **transition flick** is yawed mid-switch, smoke crossing the frame diagonally, both exit directions readable.

Extracted rules inside block: NONE

## fbaea9120f965638 — video/references/race-and-speed.md:121-121 (heading)

### The 5 shot families

Extracted rules inside block: NONE
