# Source coverage review 2/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2c64f675cad9c6ab — ai-production-director/SKILL.md:52-52 (table_row)

| Narrativa | Un beat (hook→payoff) | Arco simple | Multi-escena, personajes |

Extracted rules inside block: NONE

## 382b8189d6c1c530 — ai-production-director/SKILL.md:53-53 (table_row)

| Revisiones esperadas | 0–1 | 1–2 rondas | Rondas formales |

Extracted rules inside block: NONE

## bd0508ff2f24317c — ai-production-director/SKILL.md:54-54 (table_row)

| Etapas | 4 → 5/6 comprimidas | 0–7 con estrategia ligera | 0–7 completas |

Extracted rules inside block: NONE

## 1abc14dbbffab1eb — ai-production-director/SKILL.md:55-55 (table_row)

| Ejemplo | Reel orgánico interno | Spot de campaña, brand film corto | Cortometraje, explainer largo, film de marca |

Extracted rules inside block: NONE

## 1392131aeb1bc358 — ai-production-director/SKILL.md:57-57 (list_item)

- **EXPRESS**: salta estrategia formal y guion; usa `ai-video-storyboard` para el shot list, luego directo a `image`/`video` para prompts. Sin shots.json ni loop de crítica salvo que el usuario lo pida.

Extracted rules inside block: NONE

## ab296c546c690ead — ai-production-director/SKILL.md:58-58 (list_item)

- **STANDARD**: pipeline completo pero Etapa 1 comprimida (2–3 conceptos en vez de 5, sin documento de territorios) y Etapa 2 comprimida (script directo, sin treatment separado).

Extracted rules inside block: NONE

## 90d4d3df5d6ae947 — ai-production-director/SKILL.md:59-59 (list_item)

- **FILM**: todas las etapas, todos los artefactos, todos los gates.

Extracted rules inside block: NONE

## f24ed1d911721769 — ai-production-director/SKILL.md:61-61 (paragraph)

Anuncia el track elegido y el plan de etapas en una línea antes de arrancar. Si el usuario ya trae artefactos de etapas previas (un script, un shots.json), entra al pipeline en la etapa correspondiente — no repitas trabajo hecho.

Extracted rules inside block: NONE

## c2b5488579503f85 — ai-production-director/SKILL.md:63-63 (heading)

## 3. Las etapas

Extracted rules inside block: NONE

## 7d356f4b37712799 — ai-production-director/SKILL.md:65-65 (paragraph)

Cada etapa declara: sub-skill, entradas, salidas, y gate. El gate se verifica ANTES de avanzar. Si falla, se corrige en la etapa actual — nunca se "arregla después".

Extracted rules inside block: 50760ee71d2c

## 19b6e66f8bb8acc9 — ai-production-director/SKILL.md:67-67 (heading)

### Etapa 0 — Brand Lock *(solo si hay marca/cliente)*

Extracted rules inside block: NONE

## 05c88232aa1908e0 — ai-production-director/SKILL.md:68-68 (list_item)

- **Skill:** `brand-lock-extractor`. Entrada: sitio web, brand book, screenshots o descripción.

Extracted rules inside block: NONE

## 6bd0d938024ae6cf — ai-production-director/SKILL.md:69-69 (list_item)

- **Salida:** `brand-lock.md` (9 secciones, cada valor con fuente y confianza).

Extracted rules inside block: NONE

## 9006ffcbe1bb83e6 — ai-production-director/SKILL.md:70-70 (list_item)

- **Gate:** el usuario confirma los valores flagged como estimados. Sin marca formal, usa el Visual Theme de la Etapa 3 como sustituto ligero.

Extracted rules inside block: NONE

## 270c6c876b0518c2 — ai-production-director/SKILL.md:72-72 (heading)

### Etapa 1 — Creative Strategy

Extracted rules inside block: NONE

## a94f2519210b7c3e — ai-production-director/SKILL.md:73-73 (list_item)

- **Módulo:** `references/creative-strategy.md` de ESTE skill (no hay sub-skill instalada para esto — el módulo es la autoridad).

Extracted rules inside block: NONE

## 61eee02a43597892 — ai-production-director/SKILL.md:74-74 (list_item)

- **Salida:** documento con territorios explorados, 3–5 concept cards, matriz de selección, y dirección narrativa del concepto ganador.

Extracted rules inside block: NONE

## 170c5d8f7b931b14 — ai-production-director/SKILL.md:75-75 (list_item)

- **Gate:** el usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto.

Extracted rules inside block: ee7d7475001f

## 47b2be5a2ba23b8e — ai-production-director/SKILL.md:77-77 (heading)

### Etapa 2 — Screenwriting

Extracted rules inside block: NONE

## 89b3bd057dd3f342 — ai-production-director/SKILL.md:78-78 (list_item)

- **Skill:** `screenwriter`. Entrada: concept card ganadora + dirección narrativa.

Extracted rules inside block: NONE

## 6aba43f59eed862e — ai-production-director/SKILL.md:79-79 (list_item)

- **Salida:** treatment (solo FILM) → script con escenas XML-tagged, sluglines, acción y diálogo.

Extracted rules inside block: NONE

## 57f7a89327b8c5f9 — ai-production-director/SKILL.md:80-80 (list_item)

- **Gate:** cada escena pasa la fórmula de escena de `video`/dramaturgy (deseo + obstáculo + geometría + mirada + ritmo) y la three-jobs rule: cada escena cambia emoción, avanza acción o sube presión. Escena que no hace ninguna de las tres se corta aquí, no en el shot list.

Extracted rules inside block: NONE

## dd51566b1db878f8 — ai-production-director/SKILL.md:82-82 (heading)

### Etapa 3 — Cinematic Direction

Extracted rules inside block: NONE

## 72b599e2e5781bb9 — ai-production-director/SKILL.md:83-83 (list_item)

- **Skill:** `video` (smixs), archivos `dramaturgy.md` y `universal-rules.md` + vocabulario de cámara/luz.

Extracted rules inside block: NONE

## 7a6131be6546fed4 — ai-production-director/SKILL.md:84-84 (list_item)

- **Salida:** documento de dirección por escena: blocking, composición, cámara motivada (cada movimiento responde "¿qué cambió?"), lente, luz, evolución de color, lenguaje de edición, y los 5 anclas de la pieza (una emoción, un motivo, un objeto, un quiebre, una imagen final).

Extracted rules inside block: NONE

## 400b6dab4dac9906 — ai-production-director/SKILL.md:85-85 (list_item)

- **Gate:** cero palabras del vocabulario prohibido (sección 6.1). Cada decisión de cámara tiene razón dramática escrita.

Extracted rules inside block: e6bbb19e24e4

## cb1cf6ed09ae79ea — ai-production-director/SKILL.md:87-87 (heading)

### Etapa 4 — Shot Planning

Extracted rules inside block: NONE

## 083caeb62ceea10e — ai-production-director/SKILL.md:88-88 (list_item)

- **Skill:** `storyboard-architect` (STANDARD/FILM) o `ai-video-storyboard` (EXPRESS).

Extracted rules inside block: NONE

## a644a31218ca77b4 — ai-production-director/SKILL.md:89-89 (list_item)

- **Entrada:** script + documento de dirección. **Salida:** `storyboard.md`, `shots.json`, `text-overlays.json`, `run.json`, `brand-lock.snapshot.md`.

Extracted rules inside block: NONE

## 50fd53704c83462e — ai-production-director/SKILL.md:90-90 (list_item)

- **Gate:** `tools/validate_shots.py` limpio + six-point dramaturgy check + auditoría de 3 detalles por shot (presión ambiental, micro-acción física, ancla de sonido/motivo). Un shot con cero detalles es filler y se elimina.

Extracted rules inside block: NONE
