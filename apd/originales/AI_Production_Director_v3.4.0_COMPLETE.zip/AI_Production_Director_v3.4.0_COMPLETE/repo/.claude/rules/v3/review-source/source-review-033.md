# Source coverage review 33/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 8190f429752d598b — image/SKILL.md:30-30 (paragraph)

Past attempts to write prompts directly from this skill body produced lazy, generic results. Each model has its own physics; common rules collapse into mush when applied without model-specific syntax. Read in this order before producing any prompt:

Extracted rules inside block: NONE

## fc379ca2aff53fff — image/SKILL.md:32-32 (heading)

### Step 1 — always read first → [models.md](references/models.md)

Extracted rules inside block: NONE

## 802284a7633871bf — image/SKILL.md:34-34 (paragraph)

Decide: Nano Banana (NB2 or NBP) or GPT Image 2. The choice changes the prompt syntax fundamentally — natural-language paragraphs vs. labeled 5-slot template, quality settings, which features exist (image grounding only on NB, EXACT TEXT discipline only on GPT Image, etc.).

Extracted rules inside block: NONE

## 347abf2f0c18b7eb — image/SKILL.md:36-36 (paragraph)

If the user named a model — confirm and proceed. If not — pick using the table in `models.md`, then state your choice in the output header.

Extracted rules inside block: NONE

## c8ace08bb39605ee — image/SKILL.md:38-38 (heading)

### Step 2 — read **one** model file (the one you picked)

Extracted rules inside block: NONE

## c4d4b2f44361cb56 — image/SKILL.md:40-41 (list_item)

- **Nano Banana** → [nano-banana.md](references/nano-banana.md)
  Image grounding for real locations. Extreme aspect ratios (1:8, 8:1, 4:1). Thinking mode. JSON for 5+ elements. Up to 14 reference images. Why you must NOT write `50mm / f-stop / ISO` numbers.

Extracted rules inside block: 885e51e17bff

## b93a8c870e2b7a38 — image/SKILL.md:43-44 (list_item)

- **GPT Image 2** → [gpt-image.md](references/gpt-image.md)
  5-slot template (Scene / Subject / Important Details / Use Case / Constraints). Anti-slop banned-words list. `quality: low / medium / high` as a deliberate fidelity lever. Size constraints (multiples of 16, max 3:1, up to 2560×1440). Two-column edit logic (Change / Preserve / Constraints). Up to 16 reference images with explicit roles.

Extracted rules inside block: a8c24be2cf59

## cd56c8d0e1c94ca4 — image/SKILL.md:46-46 (paragraph)

The model file is non-negotiable. Skipping it is the single biggest cause of weak prompts.

Extracted rules inside block: NONE

## eba31aaf6670a70a — image/SKILL.md:48-48 (heading)

### Step 3 — always read after the model file → [golden-rules.md](references/golden-rules.md)

Extracted rules inside block: NONE

## 2e01611aac55ca11 — image/SKILL.md:50-50 (paragraph)

Universal rules that apply to both models: start with a verb, positive framing, hex colors, quote text, edit don't re-roll, one change per iteration, reference images.

Extracted rules inside block: e2f77b957f37

## 155167374f775980 — image/SKILL.md:52-52 (heading)

### Step 4 — task-shaped reading (load only what matches the request)

Extracted rules inside block: NONE

## b8951e681a8f25aa — image/SKILL.md:54-54 (paragraph)

Pick zero or more, depending on what the user asked for:

Extracted rules inside block: NONE

## d562484d485d9e41 — image/SKILL.md:56-56 (list_item)

- Text in image, infographic, diagram, multilingual rendering → [text-rendering.md](references/text-rendering.md)

Extracted rules inside block: NONE

## 1f866f7e31451bfe — image/SKILL.md:57-57 (list_item)

- Edit existing image (object removal, lighting swap, colorization, restoration, localization) → [editing.md](references/editing.md)

Extracted rules inside block: NONE

## bc9b947c81f5d88a — image/SKILL.md:58-58 (list_item)

- Character continuity across multiple images / panels → [characters.md](references/characters.md)

Extracted rules inside block: NONE

## 2d60b041dc257889 — image/SKILL.md:59-59 (list_item)

- Presentation slides → [slides.md](references/slides.md)

Extracted rules inside block: NONE

## 4fde36ad936a6f1d — image/SKILL.md:60-60 (list_item)

- Sequential narrative (storyboard, comic, panel sequence) → [storyboards.md](references/storyboards.md)

Extracted rules inside block: NONE

## 39ea7301014baff1 — image/SKILL.md:61-61 (list_item)

- Sketch → final, wireframes, structural input → [structural.md](references/structural.md)

Extracted rules inside block: NONE

## 8dc672e9b732db44 — image/SKILL.md:62-62 (list_item)

- 2D → 3D, floor plans, isometric → [dimensional.md](references/dimensional.md)

Extracted rules inside block: NONE

## dc15483bb0d6240d — image/SKILL.md:63-63 (list_item)

- **Vision analysis / image-to-prompt / style transfer from a reference image** → [vision-decomposer.md](references/vision-decomposer.md). Load this whenever the user attaches an image and asks to recreate, match, decompose, or transfer its style.

Extracted rules inside block: NONE

## b8f6c411fd9ff6ce — image/SKILL.md:64-64 (list_item)

- **Multi-panel compositions** (grids, collages, storyboard sheets in ONE image) → [multi-panel.md](references/multi-panel.md). 9-cell TVC grids, 2x2 portrait grids, 3-panel campaign collages, 4x3 borderless grids, 6-frame cinematic sequences, before/after splits, 12-panel storyboard posters.

Extracted rules inside block: NONE

## 3e6b32a7b4443fa9 — image/SKILL.md:65-65 (list_item)

- **Industry pattern libraries** — proven prompt templates by vertical. Load the matching file:

Extracted rules inside block: NONE

## a7986f11653231f6 — image/SKILL.md:66-66 (list_item)

  - E-commerce product shots → [patterns/ecommerce.md](references/patterns/ecommerce.md)

Extracted rules inside block: NONE

## 9c543ea77c9934a5 — image/SKILL.md:67-67 (list_item)

  - Fashion editorial campaigns → [patterns/fashion-editorial.md](references/patterns/fashion-editorial.md)

Extracted rules inside block: NONE

## 765c2e3a6e1f2f32 — image/SKILL.md:68-68 (list_item)

  - Food & beverage advertising → [patterns/food-beverage.md](references/patterns/food-beverage.md)

Extracted rules inside block: NONE

## bd5cd8e8f3611e4c — image/SKILL.md:69-69 (list_item)

  - Cinematic portraits → [patterns/portrait-cinema.md](references/patterns/portrait-cinema.md)

Extracted rules inside block: NONE

## 10c8eb8e8e54d59c — image/SKILL.md:70-70 (list_item)

  - Posters & illustration → [patterns/poster-illustration.md](references/patterns/poster-illustration.md)

Extracted rules inside block: NONE

## 7db7aef60ed753cb — image/SKILL.md:71-71 (list_item)

  - Character design (turnarounds, expression sheets, outfit grids) → [patterns/character-design.md](references/patterns/character-design.md)

Extracted rules inside block: NONE

## e8198b4ce3d89f97 — image/SKILL.md:72-72 (list_item)

  - UI mockups & social media formats → [patterns/ui-social.md](references/patterns/ui-social.md)

Extracted rules inside block: NONE

## 5f8aa99e7af56ef4 — image/SKILL.md:74-74 (heading)

### Step 5 — read for production language → [creative-direction.md](references/creative-direction.md)

Extracted rules inside block: NONE
