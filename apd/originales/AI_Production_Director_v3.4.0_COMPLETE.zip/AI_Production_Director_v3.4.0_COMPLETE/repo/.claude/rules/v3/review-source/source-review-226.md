# Source coverage review 226/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## b87f4d457d0a3a35 — visual-prompt-forge/references/failure-modes.md:73-73 (list_item)

- For Flux and GPT Image, add the photographic spec ("key light camera-left at 45 degrees")

Extracted rules inside block: NONE

## afdd52df00579b4f — visual-prompt-forge/references/failure-modes.md:75-75 (paragraph)

**Accept editorially when:** lighting drift is subtle enough that color grading will fix it.

Extracted rules inside block: NONE

## 11d2eb4ee885c0db — visual-prompt-forge/references/failure-modes.md:77-77 (heading)

## Failure 5. Composition doesn't reserve space for text overlay

Extracted rules inside block: NONE

## 76247dd6b3b495b1 — visual-prompt-forge/references/failure-modes.md:79-79 (paragraph)

**Symptoms:** the storyboard says text goes in the right third, but the generated image has the subject filling the right third.

Extracted rules inside block: NONE

## fe4d3361ac255ef4 — visual-prompt-forge/references/failure-modes.md:81-81 (paragraph)

**Causes:**

Extracted rules inside block: NONE

## 708180f4fc082ef3 — visual-prompt-forge/references/failure-modes.md:82-82 (list_item)

- Shot subject didn't include negative-space note

Extracted rules inside block: NONE

## 71d8148d9dd37433 — visual-prompt-forge/references/failure-modes.md:83-83 (list_item)

- Generator interpreting "centered subject" by default

Extracted rules inside block: NONE

## 4748330a389ffcad — visual-prompt-forge/references/failure-modes.md:85-85 (paragraph)

**Prompt-level fixes:**

Extracted rules inside block: NONE

## a03ee3a95fa39f58 — visual-prompt-forge/references/failure-modes.md:86-86 (list_item)

- Add explicit composition note: "subject framed in left third, right two-thirds open for text overlay"

Extracted rules inside block: NONE

## 527a8abafd90f991 — visual-prompt-forge/references/failure-modes.md:87-87 (list_item)

- For GPT Image (best at spatial reasoning), use percentage references: "subject at left 30% of frame"

Extracted rules inside block: ddd438309be8

## 8622df25d8aeec0b — visual-prompt-forge/references/failure-modes.md:88-88 (list_item)

- Re-roll with explicit composition prompt, this often fixes on second try

Extracted rules inside block: NONE

## 345b50dca9c10060 — visual-prompt-forge/references/failure-modes.md:90-90 (paragraph)

**Accept editorially when:** image is otherwise great. Reposition text overlay to fit the actual composition.

Extracted rules inside block: NONE

## 35005bc3b290902a — visual-prompt-forge/references/failure-modes.md:92-92 (heading)

## Failure 6. Series feels "different" even with locks applied

Extracted rules inside block: NONE

## bbb7a90cf025c396 — visual-prompt-forge/references/failure-modes.md:94-94 (paragraph)

**Symptoms:** all locks are in place, prompts look right, but the storyboard feels disjointed when viewed end-to-end.

Extracted rules inside block: NONE

## c9ec5eb7e5e962b8 — visual-prompt-forge/references/failure-modes.md:96-96 (paragraph)

**Causes:**

Extracted rules inside block: NONE

## 0d408e811263687c — visual-prompt-forge/references/failure-modes.md:97-97 (list_item)

- Color grade language drifting between shots (one says "warm filmic", another says "cinematic")

Extracted rules inside block: NONE

## c99698fd22c08db2 — visual-prompt-forge/references/failure-modes.md:98-98 (list_item)

- Aspect ratio drift (some 9:16 generations are taller than others)

Extracted rules inside block: NONE

## e9ebf481e244d7d1 — visual-prompt-forge/references/failure-modes.md:99-99 (list_item)

- Mood adjectives shifting ("calm" in shot 1 vs "energetic" in shot 5 even though brief was uniform)

Extracted rules inside block: NONE

## bccd79c1722b7f05 — visual-prompt-forge/references/failure-modes.md:101-101 (paragraph)

**Prompt-level fixes:**

Extracted rules inside block: NONE

## 7789d1f713b78045 — visual-prompt-forge/references/failure-modes.md:102-102 (list_item)

- Audit every prompt against series_lock and brand-lock, verbatim check

Extracted rules inside block: NONE

## 20268793a0c4585b — visual-prompt-forge/references/failure-modes.md:103-103 (list_item)

- Verify aspect ratio is identical across all prompts

Extracted rules inside block: NONE

## 3c9f1e3b640603c3 — visual-prompt-forge/references/failure-modes.md:104-104 (list_item)

- Lock the brand mood adjectives, same set in every prompt

Extracted rules inside block: NONE

## e8b175d72ef6eb85 — visual-prompt-forge/references/failure-modes.md:106-106 (paragraph)

**Accept editorially when:** the disjoint feel is below the noise floor for the medium (e.g. fast-cut social where each shot is on screen <2s).

Extracted rules inside block: NONE

## 95378b352c939e4c — visual-prompt-forge/references/failure-modes.md:108-108 (heading)

## Failure 7, "Looks fine but doesn't match the brief"

Extracted rules inside block: NONE

## 26713b933e86ecc5 — visual-prompt-forge/references/failure-modes.md:110-110 (paragraph)

**Symptoms:** image is technically good but doesn't capture what the brief was actually about.

Extracted rules inside block: NONE

## 7197d89daec50683 — visual-prompt-forge/references/failure-modes.md:112-112 (paragraph)

**Causes:**

Extracted rules inside block: NONE

## 739f9c8aa9bb1564 — visual-prompt-forge/references/failure-modes.md:113-113 (list_item)

- The shot subject in `shots.json` was vague

Extracted rules inside block: NONE

## fb861920db98003a — visual-prompt-forge/references/failure-modes.md:114-114 (list_item)

- The brief context wasn't surfaced into the prompt

Extracted rules inside block: NONE

## 454322e40b32caab — visual-prompt-forge/references/failure-modes.md:115-115 (list_item)

- The generator is producing competent generic output rather than specific intent

Extracted rules inside block: NONE

## 9660ae7de20f30c3 — visual-prompt-forge/references/failure-modes.md:117-117 (paragraph)

**Prompt-level fixes:**

Extracted rules inside block: NONE
