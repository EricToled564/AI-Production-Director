# Source coverage review 82/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 6dea802d320ad837 — screenwriter/SKILL.md:55-55 (heading)

## Screenplay Format Standards

Extracted rules inside block: NONE

## 200e16ab23d970b8 — screenwriter/SKILL.md:57-57 (heading)

### Scene Structure (Master Scene Heading)

Extracted rules inside block: NONE

## cb7ad8e55cd70ef8 — screenwriter/SKILL.md:59-59 (paragraph)

**Slugline Format:**

Extracted rules inside block: NONE

## 3bddbb22d421719f — screenwriter/SKILL.md:60-62 (code)

```
INT/EXT. LOCATION - TIME
```

Extracted rules inside block: NONE

## c43b6b525cdb6da9 — screenwriter/SKILL.md:64-64 (paragraph)

**Components:**

Extracted rules inside block: NONE

## db49d95368d6bf7e — screenwriter/SKILL.md:65-65 (list_item)

- **INT/EXT:** Interior or Exterior

Extracted rules inside block: NONE

## 5ca71f48db591b4a — screenwriter/SKILL.md:66-66 (list_item)

- **LOCATION:** Specific place (be descriptive but concise)

Extracted rules inside block: NONE

## 984ba1bdbecbcef7 — screenwriter/SKILL.md:67-67 (list_item)

- **TIME:** DAY, NIGHT, DAWN, DUSK, CONTINUOUS

Extracted rules inside block: NONE

## c31edefffa1d02b4 — screenwriter/SKILL.md:69-69 (paragraph)

**Examples:**

Extracted rules inside block: NONE

## cabef2718c5d735f — screenwriter/SKILL.md:70-74 (code)

```
EXT. WASTELAND - DAWN
INT. ABANDONED SUBWAY STATION - NIGHT
EXT. ROOFTOP GARDEN - GOLDEN HOUR
```

Extracted rules inside block: NONE

## f10ec3630baad96c — screenwriter/SKILL.md:76-76 (paragraph)

**Guidelines:**

Extracted rules inside block: NONE

## 4a425be05ec44970 — screenwriter/SKILL.md:77-77 (list_item)

- Always use ALL CAPS for sluglines

Extracted rules inside block: 4db660049421

## f0531a40599d4afb — screenwriter/SKILL.md:78-78 (list_item)

- Use hyphens to separate elements

Extracted rules inside block: f96b07c9012c

## 9f353224396efadf — screenwriter/SKILL.md:79-79 (list_item)

- Be specific with locations (aids visual generation)

Extracted rules inside block: NONE

## 6bfa9f757a064811 — screenwriter/SKILL.md:80-80 (list_item)

- Time should suggest lighting/mood

Extracted rules inside block: bf1cbe557267

## f5caca726d0d8007 — screenwriter/SKILL.md:82-82 (heading)

### Action Lines (Visual Description)

Extracted rules inside block: NONE

## 66156ffc21d98866 — screenwriter/SKILL.md:84-84 (paragraph)

**Purpose:** Describe what the audience sees on screen. This is CRITICAL for image generation.

Extracted rules inside block: NONE

## a38ece53bfce2a5f — screenwriter/SKILL.md:86-86 (paragraph)

**Visual-Rich Writing Principles:**

Extracted rules inside block: NONE

## 645f3e3cf2b18f19 — screenwriter/SKILL.md:87-87 (list_item)

1. **Show, Don't Tell:** Write what's visible, not internal thoughts

Extracted rules inside block: a47b1dad9f74

## e46cc5b9ee8dacd5 — screenwriter/SKILL.md:88-88 (list_item)

2. **Sensory Details:** Include lighting, atmosphere, textures, colors

Extracted rules inside block: dc38b896011a

## f2f248cb392595b7 — screenwriter/SKILL.md:89-89 (list_item)

3. **Present Tense:** Always write in present tense

Extracted rules inside block: eef66473e3c7

## 3ec8327560c9ab06 — screenwriter/SKILL.md:90-90 (list_item)

4. **Active Voice:** Use strong, active verbs

Extracted rules inside block: e7dd1d22c84d

## c0c92cc56043ad40 — screenwriter/SKILL.md:91-91 (list_item)

5. **Specific Props:** Name objects that matter visually

Extracted rules inside block: d7a31373b0bc

## be28a092f21af202 — screenwriter/SKILL.md:92-92 (list_item)

6. **Atmosphere:** Set mood through environmental details

Extracted rules inside block: cebc0f2d5d3b

## aa4ac9d6098d51ae — screenwriter/SKILL.md:94-94 (paragraph)

**Example - Weak:**

Extracted rules inside block: NONE

## 7a1fe2806930f849 — screenwriter/SKILL.md:95-97 (code)

```
A robot walks through the city. It's sad.
```

Extracted rules inside block: NONE

## 6ec6cb4b9f311148 — screenwriter/SKILL.md:99-99 (paragraph)

**Example - Strong:**

Extracted rules inside block: NONE

## 4eb74cb4a1a599ea — screenwriter/SKILL.md:100-102 (code)

```
A BOXY ROBOT (Unit-7, weathered chrome with a single blue optical sensor) rolls through fog-shrouded streets. Neon signs flicker overhead, casting pink and cyan reflections on wet pavement. The robot's movements are slow, deliberate—almost hesitant.
```

Extracted rules inside block: NONE

## 94edf6795638eb6f — screenwriter/SKILL.md:104-104 (paragraph)

**Visual Enhancement Checklist:**

Extracted rules inside block: NONE

## f70d374510c38d2b — screenwriter/SKILL.md:105-105 (list_item)

- [ ] Lighting described (natural/artificial, quality, color)

Extracted rules inside block: NONE
