# Source coverage review 40/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 47facf5b5933d20b — image/references/editing.md:80-80 (paragraph)

Cultural adaptation:

Extracted rules inside block: NONE

## 87062442f8bdef00 — image/references/editing.md:81-86 (code)

```
Localize this [ORIGINAL] ad to [TARGET MARKET].
Background: [NEW LOCATION]
Translate: text to [LANGUAGE]
Keep: brand elements, core composition
```

Extracted rules inside block: NONE

## a79e6c8957dc50ec — image/references/editing.md:88-88 (heading)

## Physics-Aware

Extracted rules inside block: NONE

## a4cbb4c194642438 — image/references/editing.md:90-90 (paragraph)

NBP understands materials:

Extracted rules inside block: NONE

## bcc588c0da395e16 — image/references/editing.md:91-95 (code)

```
Fill this glass with [LIQUID].
Add: refraction, meniscus, condensation
Match: existing lighting
```

Extracted rules inside block: NONE

## bba48179fb97f9de — image/references/editing.md:97-100 (code)

```
Add [MATERIAL] texture to [SURFACE].
Properties: [matte/glossy], [rough/smooth]
```

Extracted rules inside block: NONE

## 10e3c5b1c82f4be4 — image/references/editing.md:102-102 (heading)

## Conversational Refinement

Extracted rules inside block: NONE

## 30dbae49bb8b4b49 — image/references/editing.md:104-104 (paragraph)

After initial edit:

Extracted rules inside block: NONE

## aab1cffe5409a99c — image/references/editing.md:105-105 (list_item)

- "Make it warmer"

Extracted rules inside block: NONE

## fc91919d3aae9936 — image/references/editing.md:106-106 (list_item)

- "Increase contrast"

Extracted rules inside block: NONE

## 2df7a53d35561419 — image/references/editing.md:107-107 (list_item)

- "Soften the edges"

Extracted rules inside block: NONE

## 2b72e2a0efe2bca5 — image/references/editing.md:108-108 (list_item)

- "Add more detail to shadows"

Extracted rules inside block: NONE

## 07013cd585e8df4d — image/references/editing.md:112-112 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 990f8e20dc814df7 — image/references/golden-rules.md:1-1 (heading)

# Golden Rules

Extracted rules inside block: NONE

## 94a6150572128e36 — image/references/golden-rules.md:3-4 (paragraph)

Универсальные принципы. Работают для **обеих** семей моделей (Nano Banana и GPT Image 2).
Для модельной специфики см. [nano-banana.md](nano-banana.md), [gpt-image.md](gpt-image.md).

Extracted rules inside block: NONE

## 44d8edeffee8552f — image/references/golden-rules.md:6-6 (heading)

## 1. Start with a Verb

Extracted rules inside block: NONE

## 5518d462562d9632 — image/references/golden-rules.md:8-8 (paragraph)

Tell the model the primary operation: "Create", "Generate", "Design", "Transform", "Convert", "Edit". This sets the intent before details.

Extracted rules inside block: NONE

## 670f468a644fa507 — image/references/golden-rules.md:10-10 (heading)

## 2. Positive Framing

Extracted rules inside block: NONE

## 5266c47df6433de4 — image/references/golden-rules.md:12-12 (paragraph)

Describe what you WANT, not what you don't want. The model understands presence better than absence.

Extracted rules inside block: 6abd7a792a1b

## 812026b61158d2c8 — image/references/golden-rules.md:14-14 (list_item)

- ✅ "empty street" → ❌ "street with no cars"

Extracted rules inside block: 3cc680ece87a

## 617d7434ecb39e89 — image/references/golden-rules.md:15-15 (list_item)

- ✅ "clean background" → ❌ "no clutter"  

Extracted rules inside block: 877008e60f14

## 7a210a5cf18ddd3e — image/references/golden-rules.md:16-16 (list_item)

- ✅ "solo portrait" → ❌ "no other people"

Extracted rules inside block: 7bbb082b04da

## 423340835091e6e5 — image/references/golden-rules.md:18-18 (heading)

## 3. Edit, Don't Re-roll

Extracted rules inside block: NONE

## 29401cdcd6de0292 — image/references/golden-rules.md:20-20 (paragraph)

Image 80% correct? Request specific change:

Extracted rules inside block: NONE

## fee00fa7e91c4267 — image/references/golden-rules.md:21-21 (list_item)

- "Change lighting to sunset"

Extracted rules inside block: NONE

## e00b584f9738a1a1 — image/references/golden-rules.md:22-22 (list_item)

- "Make text neon blue"

Extracted rules inside block: NONE

## 7212127fbbe437d2 — image/references/golden-rules.md:23-23 (list_item)

- "Move chart to right third"

Extracted rules inside block: NONE

## e1bd3eb6cca9efcc — image/references/golden-rules.md:25-25 (heading)

## 4. Natural Language

Extracted rules inside block: NONE

## 5caa68da9169c687 — image/references/golden-rules.md:27-28 (paragraph)

❌ Bad: "Cool car, neon, city, night, 8k"
✅ Good: "A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. Neon signs reflect off wet pavement and metallic chassis."

Extracted rules inside block: 2c2a2123bd6a, 1815772be3bf

## d8ddb7ac1e4abcb1 — image/references/golden-rules.md:30-30 (heading)

## 5. Be Specific

Extracted rules inside block: NONE
