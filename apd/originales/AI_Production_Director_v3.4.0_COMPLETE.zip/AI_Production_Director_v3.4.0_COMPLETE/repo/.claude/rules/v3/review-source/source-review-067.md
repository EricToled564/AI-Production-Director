# Source coverage review 67/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 3a27d079ff1c6894 — image/references/slides.md:26-26 (list_item)

- 3-4 цвета max (основной + 2-3 акцента)

Extracted rules inside block: NONE

## 25b5b6253f64273d — image/references/slides.md:27-27 (list_item)

- Один нейтральный фон (white/black/gray)

Extracted rules inside block: NONE

## 5a3898ade1457cfc — image/references/slides.md:28-28 (list_item)

- Контраст min 4.5:1

Extracted rules inside block: NONE

## 307020253c17541d — image/references/slides.md:29-29 (list_item)

- Избегай pure white #fff на чёрном - используй #f5f5f5

Extracted rules inside block: 5046d3da321a

## 206cc655a88894c3 — image/references/slides.md:31-31 (heading)

### Whitespace

Extracted rules inside block: NONE

## 823598c7e1d80d13 — image/references/slides.md:32-32 (list_item)

- Контент должен дышать

Extracted rules inside block: c9092b5ff8fe

## 8a207f5b09fc9b1e — image/references/slides.md:33-33 (list_item)

- Асимметричные макеты (2/3 + 1/3) динамичнее центрированных

Extracted rules inside block: NONE

## ee55f2fe8f7f9ffe — image/references/slides.md:34-34 (list_item)

- Если тесно - разбей на два слайда

Extracted rules inside block: NONE

## 0d2ac8c19bbeeab3 — image/references/slides.md:36-36 (heading)

### Visual Consistency

Extracted rules inside block: NONE

## 0a05a53885b78bb1 — image/references/slides.md:37-37 (list_item)

- Один стиль: фото ИЛИ иллюстрации ИЛИ минимал графика

Extracted rules inside block: NONE

## f0c2f06a8715eb0d — image/references/slides.md:38-38 (list_item)

- Смешивание = визуальный хаос

Extracted rules inside block: NONE

## 4005d146540fb049 — image/references/slides.md:39-39 (list_item)

- High-res only, каждый образ усиливает идею

Extracted rules inside block: NONE

## 7156aae6599cdd87 — image/references/slides.md:41-41 (heading)

### Checklist

Extracted rules inside block: NONE

## 105be6c2dec0f6d2 — image/references/slides.md:42-49 (code)

```
☐ Один слайд = одна идея
☐ Max 5 пунктов
☐ Заголовок 44-54pt, текст 18-24pt
☐ 3-4 цвета, высокий контраст
☐ Достаточно whitespace
☐ High-res визуалы, единый стиль
```

Extracted rules inside block: NONE

## 4dd7dea431127604 — image/references/slides.md:53-53 (heading)

## Slide Types

Extracted rules inside block: NONE

## 9b617dc5725ac6c9 — image/references/slides.md:55-55 (heading)

### Hero Title (Dark)

Extracted rules inside block: NONE

## b0acf987b2efab0d — image/references/slides.md:56-68 (code)

```
Create dramatic title slide for [CONTEXT] presentation.

Background: Gradient from [DARK hex] to #0a0a0a.
Atmospheric: subtle mist at lower edge.

Typography:
"[MAIN TITLE]" in extra bold, white, extremely large, upper third
"[SUBTITLE]" in thin, muted, 5x smaller, below

Mood: Confident, premium
Format: 16:9
```

Extracted rules inside block: NONE

## 395331a0df2bfe12 — image/references/slides.md:70-70 (heading)

### Data Visualization

Extracted rules inside block: NONE

## 0aa615c4a9d74bae — image/references/slides.md:71-84 (code)

```
Create data slide for [CONTEXT] presentation.

Background: Dark gradient [hex] to [hex].

Hero number: "[METRIC]" in bold, [ACCENT], center
Trend: [up/down arrow] in [green/red]
Supporting: 3-4 smaller metrics below

Chart: [TYPE] showing [DATA]

Mood: Analytical, impactful
Format: 16:9
```

Extracted rules inside block: NONE

## e8e34896731d3a85 — image/references/slides.md:86-86 (heading)

### Comparison (Light)

Extracted rules inside block: NONE

## 6f56e8f9466d08ce — image/references/slides.md:87-100 (code)

```
Create comparison slide for [CONTEXT].

Background: Off-white #fafafa to #f0efed.

Split layout:
Left: "[OPTION A]" with details
Right: "[OPTION B]" with details

Emphasis: Right side accent bar #3b82f6

Mood: Clear, objective
Format: 16:9
```

Extracted rules inside block: NONE

## e33543bd0f5338ad — image/references/slides.md:102-102 (heading)

### Insight/Problem

Extracted rules inside block: NONE

## cedd33ec3cd0f466 — image/references/slides.md:103-114 (code)

```
Create insight slide for [CONTEXT].

Background: Clean off-white.

Focal: "[KEY MESSAGE]" in bold, centered
Supporting: "[CONTEXT]" smaller, below
Emphasis bar: [ACCENT] strip with data point

Mood: Clarity, focus
Format: 16:9
```

Extracted rules inside block: NONE

## b0e23c1a3ee50100 — image/references/slides.md:116-116 (heading)

### Process/Timeline

Extracted rules inside block: NONE

## f1d776bc74574b2b — image/references/slides.md:117-126 (code)

```
Create process slide for [CONTEXT].

Flow: [HORIZONTAL/VERTICAL]
Stages: [1]→[2]→[3]→[4]
Each: icon + "[LABEL]" + description
Connectors: arrows in [ACCENT]

Format: 16:9
```

Extracted rules inside block: NONE

## 96a80e97f5f34faf — image/references/slides.md:128-128 (heading)

## Typography

Extracted rules inside block: NONE

## 476ef810e157cf85 — image/references/slides.md:130-130 (paragraph)

**Hierarchy:**

Extracted rules inside block: NONE

## 787a318876c405dd — image/references/slides.md:131-131 (list_item)

- Hero: "Extremely large, dominating upper third"

Extracted rules inside block: NONE

## 49ac93f1ecb6a0fa — image/references/slides.md:132-132 (list_item)

- Primary: "Large, commanding"

Extracted rules inside block: NONE

## da0e75f4356739f0 — image/references/slides.md:133-133 (list_item)

- Secondary: "3-5x smaller than hero"

Extracted rules inside block: NONE
