# Source coverage review 75/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## de487ab42f270dfe — image/references/text-rendering.md:82-82 (list_item)

- Anatomical Call-out: labeling parts of whole

Extracted rules inside block: NONE

## cc826d200f67fe5b — image/references/text-rendering.md:83-83 (list_item)

- Exploded View: parts hovering, showing assembly

Extracted rules inside block: NONE

## 03a4a5b808955d0a — image/references/text-rendering.md:85-85 (heading)

## Examples

Extracted rules inside block: NONE

## 4ea62ec234139c0a — image/references/text-rendering.md:87-87 (paragraph)

**Science - Water Cycle:**

Extracted rules inside block: NONE

## 572b2f9c79195d31 — image/references/text-rendering.md:88-94 (code)

```
Create educational infographic for Elementary Science.
Topic: The Water Cycle.
Content: Evaporation, Condensation, Precipitation, Collection.
Visual Style: Bright, colorful, 3D claymation style.
Layout: Circular flow diagram with arrows clockwise.
```

Extracted rules inside block: NONE

## edc9fa8601eb8b05 — image/references/text-rendering.md:96-96 (paragraph)

**History - Timeline:**

Extracted rules inside block: NONE

## da0c11df4ac7d494 — image/references/text-rendering.md:97-103 (code)

```
Create educational infographic for High School History.
Topic: Timeline of Ancient Egypt.
Content: Old Kingdom (Pyramids), Middle Kingdom (Arts), New Kingdom (Tutankhamun).
Visual Style: Papyrus texture, hieroglyphic icons, gold/sand palette.
Layout: S-curve roadmap flowing top to bottom.
```

Extracted rules inside block: NONE

## 506791b1c9dd7b5c — image/references/text-rendering.md:105-105 (paragraph)

**Literature - Iceberg:**

Extracted rules inside block: NONE

## b25727e3b3e8fe2c — image/references/text-rendering.md:106-112 (code)

```
Create educational infographic for Sociology class.
Topic: Surface Culture vs Deep Culture.
Content: Above water (Food, Flags, Festivals). Below water (Body Language, Beliefs, Etiquette).
Visual Style: Paper Cutout Style, textured construction paper.
Layout: Iceberg diagram, tip = 10%, submerged = 90%.
```

Extracted rules inside block: NONE

## 38e8f113b1d35b0f — image/references/text-rendering.md:114-114 (paragraph)

**Comparison - Matrix:**

Extracted rules inside block: NONE

## e9968dd3486898c0 — image/references/text-rendering.md:115-121 (code)

```
Create educational infographic for Elementary Science.
Topic: Inner vs Outer Planets.
Content: Compare across Surface Type, Size, Rings.
Visual Style: Kawaii/Cute Vector, pastel colors.
Layout: Comparison Matrix grid.
```

Extracted rules inside block: NONE

## 6468b86702967a53 — image/references/text-rendering.md:123-123 (heading)

## Text-First Hack

Extracted rules inside block: NONE

## b9af9868b26a7fb6 — image/references/text-rendering.md:125-125 (paragraph)

For complex text in images, generate text FIRST, then ask for the image:

Extracted rules inside block: NONE

## c8f7fc0b4b124d60 — image/references/text-rendering.md:126-126 (list_item)

1. Ask the model to write/refine the text content

Extracted rules inside block: cd0e5e833aa9

## 121f01e93d3eb5e0 — image/references/text-rendering.md:127-127 (list_item)

2. Then ask for an image with that exact text

Extracted rules inside block: d7f70ffc8321

## 714126c2be8a5a23 — image/references/text-rendering.md:129-129 (paragraph)

This produces sharper, more accurate typography than cramming everything in one prompt.

Extracted rules inside block: NONE

## 581ee03f827631d4 — image/references/text-rendering.md:131-131 (heading)

## Font Control

Extracted rules inside block: NONE

## efe3cc392432bd2f — image/references/text-rendering.md:133-133 (paragraph)

Describe typography style or name the font directly:

Extracted rules inside block: NONE

## 4c37b01ba097c794 — image/references/text-rendering.md:134-134 (list_item)

- "Bold, white, sans-serif font"

Extracted rules inside block: NONE

## 6475a54510ce13c8 — image/references/text-rendering.md:135-135 (list_item)

- "Century Gothic 12px font"

Extracted rules inside block: NONE

## 5497de78d4348f1c — image/references/text-rendering.md:136-136 (list_item)

- "Flowing, elegant Brush Script"

Extracted rules inside block: NONE

## 4c20ac7b775df167 — image/references/text-rendering.md:137-137 (list_item)

- "Heavy, blocky Impact font"

Extracted rules inside block: NONE

## 43a1c8de978f73af — image/references/text-rendering.md:138-138 (list_item)

- "Thin, minimalist Century Gothic"

Extracted rules inside block: NONE

## 4fb69284d07634ee — image/references/text-rendering.md:140-140 (heading)

## Multilingual / Localization

Extracted rules inside block: NONE

## f216eced3e0278f8 — image/references/text-rendering.md:142-142 (paragraph)

Supports 10+ languages. Two approaches:

Extracted rules inside block: NONE

## 716e86f69e9a9a42 — image/references/text-rendering.md:144-144 (paragraph)

**Direct:** Write prompt in target language, text renders in that language.

Extracted rules inside block: NONE

## 6838e834770d540b — image/references/text-rendering.md:146-146 (paragraph)

**Translate:** Write prompt in one language, specify target:

Extracted rules inside block: NONE

## 4da0957e575b797a — image/references/text-rendering.md:147-149 (code)

```
Create this product ad. Render all text in Korean.
```

Extracted rules inside block: NONE

## fa889309d8d27df6 — image/references/text-rendering.md:151-151 (paragraph)

**Multi-language in one image:**

Extracted rules inside block: NONE

## 562b5eb8a62030d2 — image/references/text-rendering.md:152-157 (code)

```
Line 1: "GLOW" in Brush Script
Line 2: "10% OFF" in Impact font
Line 3: "Your First Order" in Century Gothic
Then translate all text into Korean and Arabic.
```

Extracted rules inside block: NONE
