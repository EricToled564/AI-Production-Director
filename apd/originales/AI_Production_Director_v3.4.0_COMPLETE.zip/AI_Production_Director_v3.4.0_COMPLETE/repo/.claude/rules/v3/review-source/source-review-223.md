# Source coverage review 223/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 429d4905d9bbacf4 — visual-prompt-forge/references/consistency-locks.md:56-56 (paragraph)

For Midjourney v7, Ideogram v3, and Nano Banana, you can pass a reference image alongside the prompt to anchor character or style.

Extracted rules inside block: NONE

## 3d462abfac11a275 — visual-prompt-forge/references/consistency-locks.md:58-58 (paragraph)

**Workflow:**

Extracted rules inside block: NONE

## fc5b1becfe60d46b — visual-prompt-forge/references/consistency-locks.md:60-60 (list_item)

1. Generate the hero shot first (any shot, usually `shot_01` or whichever is most defining)

Extracted rules inside block: b462b8394f70

## 603bdb3f31bb1dda — visual-prompt-forge/references/consistency-locks.md:61-61 (list_item)

2. Use that image as the reference for every subsequent shot

Extracted rules inside block: 3935d4158c07

## 276f5c8f1f2eebe1 — visual-prompt-forge/references/consistency-locks.md:62-62 (list_item)

3. Each subsequent prompt has the verbatim character anchor PLUS the reference image link

Extracted rules inside block: 38f9f3067723

## 75b385e910c80d6a — visual-prompt-forge/references/consistency-locks.md:64-64 (paragraph)

For Midjourney: `--cref {url} --cw 50` (character weight 50 = features only, not clothing).

Extracted rules inside block: NONE

## 3982f050e3d61fba — visual-prompt-forge/references/consistency-locks.md:66-66 (paragraph)

For Ideogram: `omni-reference` parameter with the image.

Extracted rules inside block: NONE

## e591469350489f51 — visual-prompt-forge/references/consistency-locks.md:68-68 (paragraph)

For Nano Banana: `referenceImages` array.

Extracted rules inside block: NONE

## af972d66b0719930 — visual-prompt-forge/references/consistency-locks.md:70-70 (paragraph)

**This is the most effective lock for character consistency** in 2026. Use it whenever the storyboard features the same person across multiple shots.

Extracted rules inside block: 22d338e382a0

## c3f37cab4a76cce1 — visual-prompt-forge/references/consistency-locks.md:72-72 (heading)

## Lock 6. Style references

Extracted rules inside block: NONE

## 36cf33ccfabd0f7e — visual-prompt-forge/references/consistency-locks.md:74-74 (paragraph)

When the storyboard has a distinctive visual style (specific film stock, specific lighting school, specific color theory), use a style reference image:

Extracted rules inside block: bef0fed7f638

## 322f3db8099aeedf — visual-prompt-forge/references/consistency-locks.md:76-76 (list_item)

- Midjourney: `--sref {url}`

Extracted rules inside block: NONE

## 0599f4c129457bb8 — visual-prompt-forge/references/consistency-locks.md:77-77 (list_item)

- Ideogram: style reference parameter

Extracted rules inside block: NONE

## d03390f5ca17c61e — visual-prompt-forge/references/consistency-locks.md:78-78 (list_item)

- Flux: not directly supported; bake style language into prompt instead

Extracted rules inside block: NONE

## cdca46bd81fae94e — visual-prompt-forge/references/consistency-locks.md:80-80 (paragraph)

A consistent style reference across all shots produces aesthetic continuity even when characters or environments shift.

Extracted rules inside block: NONE

## 6985e383a95fe58a — visual-prompt-forge/references/consistency-locks.md:82-82 (heading)

## Lock 7. Lighting direction continuity

Extracted rules inside block: NONE

## 6272d131b4851956 — visual-prompt-forge/references/consistency-locks.md:84-84 (paragraph)

A subtle one that breaks scenes when violated. If `series_lock.lighting` says "soft natural side-light, large window LEFT", then every shot's lighting must respect that direction.

Extracted rules inside block: 78ffb0d37f72

## 194bed9779fe570e — visual-prompt-forge/references/consistency-locks.md:86-86 (paragraph)

When a shot reverses character orientation (e.g., over-the-shoulder reverse), update the rationale to acknowledge the lighting flip:

Extracted rules inside block: 76f3265ebf27

## d3ce7a730283d238 — visual-prompt-forge/references/consistency-locks.md:88-90 (code)

```
"rationale": "OTS reverse, light source now camera-right (matching scene continuity from window-left in master)"
```

Extracted rules inside block: NONE

## fb654655d506cc5a — visual-prompt-forge/references/consistency-locks.md:92-92 (paragraph)

If you find yourself flipping light direction without rationale, you're producing visual jump cuts.

Extracted rules inside block: NONE

## f32f5267b210a56c — visual-prompt-forge/references/consistency-locks.md:94-94 (heading)

## Lock 8. Color grade flow-through

Extracted rules inside block: NONE

## d344c9c7206fa650 — visual-prompt-forge/references/consistency-locks.md:96-96 (paragraph)

The `series_lock.color_grade` string flows into every prompt verbatim. Same as character/environment/lighting. If shot 1 is "warm filmic, muted teal shadows" and shot 7 is "cinematic teal and orange", the audience will read it as different scenes.

Extracted rules inside block: NONE

## 4bad1ffd14face7b — visual-prompt-forge/references/consistency-locks.md:98-98 (heading)

## Failure modes when locks are missing

Extracted rules inside block: NONE

## 9dd76f8f2f59d786 — visual-prompt-forge/references/consistency-locks.md:100-100 (table_row)

| Missing lock | Failure mode |

Extracted rules inside block: NONE

## 7fe4ad1e64b45cfd — visual-prompt-forge/references/consistency-locks.md:102-102 (table_row)

| Character | Different person every shot |

Extracted rules inside block: NONE

## 69e7e6b90c1954aa — visual-prompt-forge/references/consistency-locks.md:103-103 (table_row)

| Environment | Scene jumps |

Extracted rules inside block: NONE

## f41a0739e0f66328 — visual-prompt-forge/references/consistency-locks.md:104-104 (table_row)

| Lighting | Time-of-day jumps, eye-line breaks |

Extracted rules inside block: NONE

## 6b00b3615bc13d6c — visual-prompt-forge/references/consistency-locks.md:105-105 (table_row)

| Seed | Random feature drift |

Extracted rules inside block: NONE

## a59287db267f79f0 — visual-prompt-forge/references/consistency-locks.md:106-106 (table_row)

| Reference image | Loose character interpretation |

Extracted rules inside block: NONE

## 3a0b73b5dd159d42 — visual-prompt-forge/references/consistency-locks.md:107-107 (table_row)

| Color grade | Tonal whiplash |

Extracted rules inside block: NONE
