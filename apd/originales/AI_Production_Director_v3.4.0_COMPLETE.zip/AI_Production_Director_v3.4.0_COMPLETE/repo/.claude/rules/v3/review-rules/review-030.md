# Rule classification review 30/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## f71306dddfda — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:46

never use bullet points in narrative copy

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "f71306dddfda",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 0abada1c8680 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:47

never use clip-art or generic icon sets

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "0abada1c8680",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 0874db08f762 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:48

never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "0874db08f762",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## a698f9a12031 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:49

never use exclamation points in headlines

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "a698f9a12031",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 8ecff3da9d7b — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:50

never default to dark mode, light mode hybrid is the brand

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "8ecff3da9d7b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 4196946138e1 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:51

never animate text with bouncing or wobbling, type-on, fade, or hard cut only

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "4196946138e1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 65fd20bb5eb4 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:62

Warm filmic, muted teal shadows. Slight grain. Cream highlights, deep navy/charcoal shadows, never crushed. Reminiscent of Kodak Portra 400 with a slight digital cleanup.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "65fd20bb5eb4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 9397132aa9d5 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:66

Camera moves are minimal and deliberate. Default to static. When motion is used, slow push or slow pull only. Cuts on action, not on time. Type-on for emphasis, never bouncing or wobbling. Coral periods animate as a hard pop on signature beats. Transitions are hard cuts or 6-frame dissolves only.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "9397132aa9d5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 7c71fe0f7996 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:74

prefer specific numbers over vague claims

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "7c71fe0f7996",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## b88369a23709 — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:75

prefer present-tense over future-tense

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "b88369a23709",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 54830ed3fdcd — visual-asset-critic/examples/worked-run/brand-lock.snapshot.md:76

prefer "operator" over "creator", "infrastructure" over "agency"

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "54830ed3fdcd",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 5a47e2a4eab4 — visual-asset-critic/references/critique-rubric.md:3

The structured layer-by-layer pass. Use this as the checklist when reviewing a generated image.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "5a47e2a4eab4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 40bb01661724 — visual-asset-critic/references/critique-rubric.md:11

"Never" list | None of the items in the never list are present | One item in the never list shows softly | Multiple never-list violations

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "40bb01661724",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 66404602f287 — visual-asset-critic/references/critique-rubric.md:34

Depth of field | Matches if specified | Slight DOF variation | Deep when shallow was specified

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "66404602f287",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 666f8ca49e65 — visual-asset-critic/references/critique-rubric.md:59

Technical hard fails are almost always **re-roll required**. The prompt was probably fine; the generator just produced a bad sample. Budget 2–3 re-rolls.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "666f8ca49e65",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 129f383f5d5b — visual-asset-critic/references/critique-rubric.md:101

Soft fails are noted but don't change the verdict on their own. If you have three or more of

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "129f383f5d5b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## d1eff8b1d346 — visual-asset-critic/references/critique-rubric.md:107

**Don't critique what wasn't asked**, if the spec didn't call for cinematic mood, don't say "could be more cinematic"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": "vocabulary.visual_style_quality",
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d1eff8b1d346",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "lexical"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## faba6eeb358a — visual-asset-critic/references/critique-rubric.md:108

**Don't pile-on once verdict is set**, if you're rejecting, list the issues that drive the rejection; don't list every cosmetic concern

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "faba6eeb358a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 081a4d70df12 — visual-asset-critic/references/critique-rubric.md:109

**Be specific, always**, "lighting is off" is not a critique; "key light is camera-right but series_lock says camera-left" is

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "081a4d70df12",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 5e73d736d58f — visual-asset-critic/references/critique-rubric.md:111

**Distinguish prompt failure from generator failure**, if the prompt was fine and the generator produced garbage hands, that's "re-roll required", not "fix the prompt"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "5e73d736d58f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "qa"
      },
      {
        "op": "eq",
        "path": "subject.hands_visible",
        "value": true
      }
    ]
  }
}
```

## ffb3b1468594 — visual-asset-critic/tools/README.md:32

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "ffb3b1468594",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## e2b7ad1d0c5a — visual-asset-critic/tools/README.md:72

Checks a brand-lock has all required sections and Identity fields, that its palette declares

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "e2b7ad1d0c5a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "qa"
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 6c90ae89af76 — visual-asset-critic/tools/README.md:86

`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "6c90ae89af76",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 8d72bc4279f2 — visual-asset-critic/tools/README.md:144

to be identified, and a named generator has to exist in the capability matrix.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "8d72bc4279f2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## cd20eddcd98e — visual-asset-critic/tools/README.md:172

a frame on disk with no critique for its round, never reviewed at all

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "cd20eddcd98e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 74cace178dee — visual-asset-critic/tools/README.md:194

template the skill uses, through the small engine in `_template.py`. It did not always: the

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "74cace178dee",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## e3ad1bd8a607 — visual-asset-critic/tools/README.md:220

never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "e3ad1bd8a607",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "qa"
  }
}
```

## 7de160615e64 — visual-prompt-forge/SKILL.md:21

If the user wants to build a storyboard from scratch (no shots.json yet), use `storyboard-architect` first, then chain into this skill.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "7de160615e64",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 3693a52c164a — visual-prompt-forge/SKILL.md:53

**Brand Lock**, palette, type, mood, "never" list (constant across project)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "3693a52c164a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 698ce7b724a9 — visual-prompt-forge/SKILL.md:54

**Series Lock**, character/environment/lighting anchors (constant across storyboard)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "698ce7b724a9",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 4dbcd0c014f5 — visual-prompt-forge/SKILL.md:55

**Shot Spec**, framing, angle, motion, subject (per shot)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "4dbcd0c014f5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 4b54683cb02e — visual-prompt-forge/SKILL.md:56

**Text Layer**, **never in the prompt**, composited separately

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "4b54683cb02e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "stage",
        "value": "prompt"
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 24c390558ce1 — visual-prompt-forge/SKILL.md:57

**Generator Adapter**, model-specific syntax wrapper

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "24c390558ce1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 1bbd62ce94c3 — visual-prompt-forge/SKILL.md:67

`shots.json` (required), the structured shot list

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "1bbd62ce94c3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```

## 6dfc2c3bc0b1 — visual-prompt-forge/SKILL.md:68

`brand-lock.snapshot.md` (required), referenced from shots.json

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "6dfc2c3bc0b1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "stage",
    "value": "prompt"
  }
}
```
