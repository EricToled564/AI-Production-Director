# Source coverage review 178/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 42dfaa7b775017c7 — video/references/seedance.md:276-276 (list_item)

- Subtitles: describe the voiceover, then ask for "text along the bottom edge, timed to the voice".

Extracted rules inside block: NONE

## 0df5cbbe3ee4a5a9 — video/references/seedance.md:278-278 (heading)

## 15. Failure modes and fixes

Extracted rules inside block: NONE

## e7708279150a22b1 — video/references/seedance.md:280-280 (heading)

### One continuous take when multi-shot was requested

Extracted rules inside block: NONE

## 136df62530148490 — video/references/seedance.md:282-282 (paragraph)

Fix. Add explicit "Cut to" markers. Say "multi-shot sequence with visible hard cuts. Do not generate a single continuous take."

Extracted rules inside block: 0ce846aecd25

## 205551dc71a7b5db — video/references/seedance.md:284-284 (heading)

### Character drift across shots

Extracted rules inside block: NONE

## 8288a51b5929d475 — video/references/seedance.md:286-286 (paragraph)

Fix. Repeat the full identity block at each shot boundary inside the prompt.

Extracted rules inside block: NONE

## 61f25660ba93f08c — video/references/seedance.md:288-288 (heading)

### Motion ignored below 5 seconds

Extracted rules inside block: NONE

## 3edcc18b3a4986c3 — video/references/seedance.md:290-290 (paragraph)

Fix. Minimum duration 5s for any scene that has multiple actions or camera moves.

Extracted rules inside block: NONE

## fb4c50f8c282c395 — video/references/seedance.md:292-292 (heading)

### Negative phrasing ignored

Extracted rules inside block: NONE

## 2e832a0d0beb6b19 — video/references/seedance.md:294-294 (paragraph)

Fix. Use positive substitutes. Seedance 1.0 has no negative parser.

Extracted rules inside block: 165e22f2e45a

## 0a05d715708b9f38 — video/references/seedance.md:296-296 (heading)

### Multi-shot fails on 4+ shots in 5s

Extracted rules inside block: NONE

## 8f543dc7334a3675 — video/references/seedance.md:298-298 (paragraph)

Fix. Cap at 2-3 shots per 5-second clip for tight cinematic, or 4-5 short beats following the section 7 timeline. If more shots are needed, split into multiple generations.

Extracted rules inside block: NONE

## a27bd622f0ef1ebc — video/references/seedance.md:300-300 (heading)

### Mood smear / "everything looks the same"

Extracted rules inside block: NONE

## 325afdfe2a20a957 — video/references/seedance.md:302-302 (paragraph)

Fix. Each shot needs a distinct emotional function (Establish / Power / Pressure / Detail / Reaction / Shift / Impact / Aftermath — see dramaturgy.md §10, Layer 2). If two adjacent shots have the same function, the model averages them into the same frame. Vary function and framing in every cut.

Extracted rules inside block: NONE

## 642806d215127324 — video/references/seedance.md:304-304 (heading)

### Lazy abstract phrasing produces lifeless clips

Extracted rules inside block: NONE

## 61ea54906303609b — video/references/seedance.md:306-306 (paragraph)

Fix. Apply the Details Law (section 4). Audit your draft: every shot must have one environmental pressure, one micro-action, one sound or visual motif anchor. Replace adjectives like "dramatic", "intense", "beautiful" with concrete physical facts.

Extracted rules inside block: 24d9832be8f2

## 34097d0f110c0d3c — video/references/seedance.md:308-308 (heading)

### Human faces rejected or degraded (2.0)

Extracted rules inside block: NONE

## 86e5c2d0bf4b700b — video/references/seedance.md:310-310 (paragraph)

After the 2026 deepfake crackdown, 2.0 aggressively filters human faces, helmets, sunglasses, and anything resembling protected IP or celebrity likeness. Fix. Route face-heavy drama to Seedance 2.5 (realistic humans are its headline feature), 1.5 Pro, Kling, or Veo; keep 2.0 for scenes, architecture, product and montage work. Use only owned or synthetic character references — the IP/celebrity filter applies on 2.5 too.

Extracted rules inside block: d7c10646e7a6

## 8719958a5c06313c — video/references/seedance.md:312-312 (heading)

## 16. Worked example. 15-second tragicomedy as 3 × 5s clips

Extracted rules inside block: NONE

## 8b6fd90650845842 — video/references/seedance.md:314-314 (paragraph)

A 15s narrative is **never** one prompt. It is three self-contained 5-second prompts, each with the full character lock, the full visual style, the full audio block, and a different dramatic function. Stitch in the editor.

Extracted rules inside block: 4c9268247d4e

## efda43a937025989 — video/references/seedance.md:316-316 (heading)

### Story spine

Extracted rules inside block: NONE

## d56ae918273d3499 — video/references/seedance.md:317-317 (list_item)

- Beat 1 (Clip A, 0-5s). Hunger. Hero opens an almost empty fridge. Discovers one lonely sausage. Despair flips to hope.

Extracted rules inside block: NONE

## cf4f2bc0ced9e00b — video/references/seedance.md:318-318 (list_item)

- Beat 2 (Clip B, 5-10s). Cooking. Pot, water, fire, sausage, bubbling, anticipation, hero shot lifting the sausage with a fork.

Extracted rules inside block: NONE

## 822e3c8a1582ceac — video/references/seedance.md:319-319 (list_item)

- Beat 3 (Clip C, 10-15s). Catastrophe. Sausage slips, falls, wet thud. Window. Bedroom. Hungry sleep. Cut to black.

Extracted rules inside block: NONE

## 077b1001ae0d80b2 — video/references/seedance.md:321-321 (heading)

### Clip A. Hunger (production-grade skeleton applied)

Extracted rules inside block: NONE

## e3fe4fe382af1c10 — video/references/seedance.md:323-380 (code)

```text
Important direction:
This must be a clearly edited multi-shot sequence with visible cuts between shots.
Do not generate a single continuous take. Each shot must have a different camera angle
and different framing. Use rapid montage pacing.

Use @img1 as the main character reference and preserve the exact same man across the
whole clip: bald head, gray-green eyes, round expressive face, moustache, long black
braided goatee, short dark side hair tufts, slightly overweight build, tragicomic face.
Dress him in a dark oversized T-shirt and dark sweatpants. No nudity. No glasses.
No extra characters.

Generate a 5-second multi-shot tragicomic cinematic sequence with fast dynamic editing.

Story:
The man is hungry at night. He suddenly goes to the refrigerator, opens it, feels
disappointment because it is almost empty, then notices one lonely sausage and becomes
instantly hopeful.

Visual style:
Cold night kitchen. Blue-green refrigerator light. Desaturated colors. No warm yellow
tones. Slightly harsh LED reflections. Realistic cinematic look. High contrast but
natural skin texture. Subtle film grain. Realistic food detail.

Camera style:
Sony FX3 handheld look. 35mm and 50mm lenses for medium and close shots. 100mm macro
for inserts. Handheld micro-shake. Visible cuts between shots.

Editing style:
Fast montage with hard cuts. Each shot a different angle and framing. Tense rhythm,
escalating to the moment of discovery.

Audio:
Deep stomach growl, soft room tone, refrigerator hum, quiet footsteps, fridge door
sound. No dialogue. No subtitles. No on-screen text.

Shot 1, 0.0–0.8 sec. Extreme close-up of the man's eyes in darkness. He is awake,
hungry, tense. Static close shot, faint blue ambient light.
Shot 2, 0.8–1.6 sec. Medium handheld side shot. He sits up and walks fast to the
kitchen. Slight shake, push-in.
Shot 3, 1.6–2.6 sec. POV from inside the refrigerator. The door opens toward camera.
Cold blue-green light hits his face. Shelves almost empty. His face drops.
Shot 4, 2.6–3.5 sec. Rapid inserts: empty shelf, empty container, lonely sauce stain,
his sad eyes, his hand moving items aside.
Shot 5, 3.5–5.0 sec. Macro insert of one single sausage in the corner. Rack focus
from empty shelf to sausage. Smash cut to a slightly low-angle close-up of his face.
His eyes widen, despair flips to joy, tiny victorious smile.

Lighting:
Dark apartment, very low ambient fill. Main source is cold refrigerator light,
blue-green, top-front. Strong contrast. No warm kitchen light.

Composition:
Tight close-ups and inserts. Negative space inside the empty fridge. Final face shot
heroic and absurd.

--resolution 1080p --duration 5 --camerafixed false
```

Extracted rules inside block: NONE

## 9df62d14bb997793 — video/references/seedance.md:382-382 (paragraph)

Clips B and C follow the same structure with their own story paragraph, shot list, and final image. The character lock and visual style blocks are repeated **verbatim** in each clip — Seedance has no memory between generations.

Extracted rules inside block: NONE

## f65e253b339af8f6 — video/references/seedance.md:384-384 (heading)

### Older single-clip skeleton (kept for quick scenes)

Extracted rules inside block: NONE

## 5b8bb4f768c4383e — video/references/seedance.md:386-386 (paragraph)

For a single non-dramatic shot or a quick test, the original 6-step skeleton still works:

Extracted rules inside block: NONE

## bd8369850b495402 — video/references/seedance.md:388-399 (code)

```text
Subject. [identity block with face, hair, clothing, distinguishing features].
Motion. [one clear present-tense action for the scene].
Camera. Shot 1. [framing, lens, movement]. Cut to. Shot 2. [framing, lens, movement]. Cut to. Shot 3. [framing, lens, movement].
Environment. [location, time of day, props, weather].
Lighting. [dominant source, direction, quality, color].
Style. [realism level, genre reference, palette].
Audio. [ambient, SFX, silence moments]. (1.5+ only)
Continuity. [what must remain constant across shots].

--resolution 1080p --duration 5 --camerafixed false
```

Extracted rules inside block: NONE
