# Source coverage review 151/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 3cf64e228708ca5f — video/references/fixes-and-skeletons.md:283-283 (list_item)

- Core idea (one sentence)

Extracted rules inside block: NONE

## dc2375c19f70e120 — video/references/fixes-and-skeletons.md:284-284 (list_item)

- Emotional arc (three states)

Extracted rules inside block: NONE

## 9c0cc7d3ee7735ee — video/references/fixes-and-skeletons.md:285-285 (list_item)

- Visual motif (one recurring element)

Extracted rules inside block: NONE

## 008a2dbfbda50131 — video/references/fixes-and-skeletons.md:286-286 (list_item)

- Rhythm (pace logic)

Extracted rules inside block: NONE

## 613677f5f8635d46 — video/references/fixes-and-skeletons.md:287-287 (list_item)

- Camera language (dominant grammar)

Extracted rules inside block: NONE

## be600fee680ba724 — video/references/fixes-and-skeletons.md:288-288 (list_item)

- Lighting (dominant source)

Extracted rules inside block: NONE

## 48e025e7a8539229 — video/references/fixes-and-skeletons.md:289-289 (list_item)

- Sound (texture)

Extracted rules inside block: NONE

## 949991d14d93fd1d — video/references/fixes-and-skeletons.md:290-290 (list_item)

- Ending image (final frame)

Extracted rules inside block: NONE

## b1848d2bbff44f25 — video/references/fixes-and-skeletons.md:292-292 (heading)

### Format F. Veo JSON

Extracted rules inside block: NONE

## 014e97e0c90de1fc — video/references/fixes-and-skeletons.md:294-294 (paragraph)

Structured scene-by-scene JSON. Use for complex continuity. See `references/veo.md` section 6.

Extracted rules inside block: e6ed5a2e80ee

## be16d19824eeedb8 — video/references/fixes-and-skeletons.md:298-298 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 6490aec8939e4430 — video/references/kling.md:1-1 (heading)

# Kling reference (Kuaishou)

Extracted rules inside block: NONE

## cf41bedcebc4d2c9 — video/references/kling.md:3-3 (heading)

## Contents

Extracted rules inside block: NONE

## 508d2aad89088c17 — video/references/kling.md:5-5 (list_item)

1. What Kling is

Extracted rules inside block: 6800820a96a1

## c716a7db79b9d069 — video/references/kling.md:6-6 (list_item)

2. Versions and element limits

Extracted rules inside block: d5687edf167b

## 3116c12cadce1a71 — video/references/kling.md:7-7 (list_item)

3. **Kling 3.0 — multi-shot, native audio, 15s (read first if user is on 3.0)**

Extracted rules inside block: 1b3603af39c6

## d010d18df20fd141 — video/references/kling.md:8-8 (list_item)

4. Prompt formula (1.x – 2.x)

Extracted rules inside block: d7a30e1ada86

## f6981e913925f03e — video/references/kling.md:9-9 (list_item)

5. Prompt length by model

Extracted rules inside block: c315a4560a92

## 0a2e2deaa6e2506b — video/references/kling.md:10-10 (list_item)

6. Negative prompts (dedicated field, special rule)

Extracted rules inside block: 94efa6e9c00e

## 70aa059d34831cb2 — video/references/kling.md:11-11 (list_item)

7. Element Library and Element Binding (unique to 1.x – 2.x)

Extracted rules inside block: 84f5c1a1308a

## a96b2c1bdc8e00ed — video/references/kling.md:12-12 (list_item)

8. Motion Brush (unique)

Extracted rules inside block: 70a528ec897d

## 7ee0711fb464ac2e — video/references/kling.md:13-13 (list_item)

9. Motion Control (2.6 Pro, unique)

Extracted rules inside block: 2d4376f1672b

## 3986d8e20477172d — video/references/kling.md:14-14 (list_item)

10. Image-to-video rule

Extracted rules inside block: b68d06407082

## 944a7c921e67d80f — video/references/kling.md:15-15 (list_item)

11. Failure modes and fixes

Extracted rules inside block: 48a4be642fe9

## b8b5d2f8dabab505 — video/references/kling.md:16-16 (list_item)

12. Skeleton and example

Extracted rules inside block: dc8ab173ce8d

## 14a4a21c33bc38bd — video/references/kling.md:20-20 (heading)

## 1. What Kling is

Extracted rules inside block: NONE

## c98cb1a5268f1837 — video/references/kling.md:22-22 (paragraph)

Strong at realistic physics, character animation, and consistency through reference images. Fast generation. Best for social-ready clips and repeat-character scenes.

Extracted rules inside block: NONE

## 8e1fc334d293d3cb — video/references/kling.md:24-24 (paragraph)

**Kling 3.0** changed the model's positioning fundamentally — it now competes with Seedance on multi-shot output (up to 6 shots per generation) and with Veo on native dialogue and lip-sync. See section 3.

Extracted rules inside block: NONE

## 99dfe86d12da8b0d — video/references/kling.md:26-26 (heading)

## 2. Versions and element limits

Extracted rules inside block: NONE

## 4542f2781b68d16b — video/references/kling.md:28-28 (paragraph)

Kling models vary widely in how many distinct elements they can handle in a single prompt. Overstuffing produces melting faces, broken hands, or static motion.

Extracted rules inside block: NONE
