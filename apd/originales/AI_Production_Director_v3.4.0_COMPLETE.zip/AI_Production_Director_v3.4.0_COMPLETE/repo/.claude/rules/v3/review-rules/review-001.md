# Rule classification review 1/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## df877230dd2c — ai-production-director/SKILL.md:16

**Clasificar** el proyecto y elegir el track correcto.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "df877230dd2c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## c6d211d82c9c — ai-production-director/SKILL.md:17

**Secuenciar** las etapas y cargar la sub-skill correcta en cada una.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "c6d211d82c9c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 8dbe17a5a3db — ai-production-director/SKILL.md:18

**Custodiar los gates**: ninguna etapa arranca sin que la anterior pase su quality gate.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "8dbe17a5a3db",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 3fb533ee3ea8 — ai-production-director/SKILL.md:19

**Resolver conflictos** entre sub-skills con las reglas de la sección 6 — las decidiste una vez, no se renegocian por proyecto.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "3fb533ee3ea8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 7a57676ded97 — ai-production-director/SKILL.md:20

**Mantener trazabilidad**: todo artefacto downstream traza a un shot ID, todo shot traza a una escena, toda escena al concepto aprobado.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "7a57676ded97",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 50760ee71d2c — ai-production-director/SKILL.md:65

Cada etapa declara: sub-skill, entradas, salidas, y gate. El gate se verifica ANTES de avanzar. Si falla, se corrige en la etapa actual — nunca se "arregla después".

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "50760ee71d2c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## ee7d7475001f — ai-production-director/SKILL.md:75

**Gate:** el usuario selecciona UN concepto. No se escribe una línea de guion con concepto abierto.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "ee7d7475001f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## e6bbb19e24e4 — ai-production-director/SKILL.md:85

**Gate:** cero palabras del vocabulario prohibido (sección 6.1). Cada decisión de cámara tiene razón dramática escrita.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "e6bbb19e24e4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 0367132dbb79 — ai-production-director/SKILL.md:101

**Gate obligatorio:** los dos checks de `video` (dramaturgy check de 6 puntos + auditoría de 3 detalles) Y, si `aurora-prompt-linter` está instalada, el linter pasa limpio. Un prompt que falla cualquiera de los dos NO se entrega.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "0367132dbb79",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 45917b38bd15 — ai-production-director/SKILL.md:112

Nunca preguntes lo que el brief o los artefactos previos ya responden.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "45917b38bd15",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 77b7f55707a0 — ai-production-director/SKILL.md:123

El vocabulario prohibido de `video`/dramaturgy (+ `aurora-prompt-linter` si está) **gana siempre**: "cinematic", "epic", "stunning", "masterpiece", "beautiful lighting", "professional", "high quality", emociones nombradas sin cuerpo. Esto **anula explícitamente** la regla de `ai-video-storyboard` de cerrar cada prompt con "cinematic 1080p, synchronized audio". En su lugar: la resolución, aspect ra

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": "vocabulary.visual_style_quality",
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "77b7f55707a0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "lexical"
  },
  "when": {}
}
```

## c378595cfd38 — ai-production-director/SKILL.md:129

De la Etapa 4 en adelante: `shots.json`. Un cambio creativo se hace primero en shots.json y se propaga hacia abajo; nunca se parcha un prompt de forma que contradiga su shot.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "c378595cfd38",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## faad91016c5d — ai-production-director/SKILL.md:132

`visual-prompt-forge` es dueño del **flujo de datos** (shots.json → borrador, critique.json → revisión selectiva). `video`/`image` smixs son dueños del **texto final** del prompt. El borrador del forge se reescribe a sintaxis smixs; nunca al revés.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "faad91016c5d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## a85a4da9dbef — ai-production-director/SKILL.md:141

**Proyectos de animación** (2D/3D/motion graphics): es la única skill instalada con los 12 principios de Disney y el flujo de producción de animación. En un proyecto animado, su sección de animación se suma a la Etapa 3 como referencia de performance y timing.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "a85a4da9dbef",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 353ecf5d5ffa — ai-production-director/SKILL.md:142

**Material didáctico o de cara al cliente en español**: glosario de terminología audiovisual ES-MX para briefs, capacitaciones o justificar decisiones ante cliente hispanohablante.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "353ecf5d5ffa",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 70522638554f — ai-production-director/SKILL.md:150

`references/creative-strategy.md` — Protocolo completo de la Etapa 1: territorios, big ideas, concept cards, matriz de selección, dirección narrativa. Léelo SIEMPRE al ejecutar la Etapa 1.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "70522638554f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 74bf2653eee4 — ai-production-director/SKILL.md:151

`references/production-package.md` — Spec del Final AI Video Production Package, reglas de trazabilidad y checklist maestro. Léelo SIEMPRE al ejecutar la Etapa 7.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "74bf2653eee4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## c040d9ba5468 — ai-production-director/references/creative-strategy.md:17

Si el single-minded proposition no se puede escribir en una frase, la Etapa 1 no puede continuar. Resuélvelo con el usuario primero.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "c040d9ba5468",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## c7738d061b81 — ai-production-director/references/creative-strategy.md:37

De los territorios más fuertes, baja 3–5 conceptos (FILM) o 2–3 (STANDARD). Cada concepto es UNA película posible, no una variación de la anterior. Formato obligatorio:

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "c7738d061b81",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## a708e29a625b — ai-production-director/references/production-package.md:44

Todo prompt (imagen o video) lleva en comentario su `shot_id`.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "a708e29a625b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 65e8026ad2b5 — ai-production-director/references/production-package.md:45

Todo shot en shots.json referencia su escena del script (`scene` field o nota).

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "65e8026ad2b5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## 82b2e0db377d — ai-production-director/references/production-package.md:46

El script referencia la concept card ganadora en su encabezado.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 650,
  "rule_id": "82b2e0db377d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## d1c709080fc1 — ai-production-director/references/production-package.md:47

Cambios: si un prompt necesita cambiar algo que su shot fija (encuadre, acción, luz), el cambio se hace en shots.json y se regenera hacia abajo. El paquete nunca contiene un prompt que contradiga su shot.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "d1c709080fc1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## f4b95af8ea47 — ai-production-director/references/production-package.md:48

Verificación de cierre: muestrea 3 prompts al azar y traza la cadena prompt → shot → escena → concepto. Si un eslabón falta, el paquete no se entrega.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "f4b95af8ea47",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## ba0279909a12 — ai-production-director/references/production-package.md:70

[ ] Dirección cinematográfica sin vocabulario prohibido

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 650,
  "rule_id": "ba0279909a12",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {}
}
```

## a58b66163524 — ai-video-storyboard/SKILL.md:12

**Core insight:** Visual consistency across shots matters more than any single shot being perfect. A mediocre but consistent set of shots edits together; six gorgeous but mismatched shots do not.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "a58b66163524",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## d47c863b3c5c — ai-video-storyboard/SKILL.md:21

**Do NOT use for:**

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d47c863b3c5c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## e04773925989 — ai-video-storyboard/SKILL.md:32

**Goal platform and duration?** (TikTok 30s / Reel 15-60s / YouTube Short / Instagram Ad / explainer)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "e04773925989",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## 67d38a7b6dfb — ai-video-storyboard/SKILL.md:33

**What is the video about?** (subject, story, product)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "67d38a7b6dfb",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## 235fb6985a11 — ai-video-storyboard/SKILL.md:34

**Brand vibe / tone?** (cozy, energetic, premium, minimalist, playful, cinematic, etc.)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": "vocabulary.visual_style_quality",
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "235fb6985a11",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## f55b9c32aa03 — ai-video-storyboard/SKILL.md:35

**Call to action at the end?** (visit website, buy product, follow channel, etc.)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "f55b9c32aa03",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## 755080cbffc4 — ai-video-storyboard/SKILL.md:36

**Any hard constraints?** (must include logo, specific colors, locations, etc.)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "755080cbffc4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## 68e23996ad0c — ai-video-storyboard/SKILL.md:62

**Lens character** (shallow DOF / deep focus / wide angle distortion / macro)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "68e23996ad0c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## 401cc3c8e0a4 — ai-video-storyboard/SKILL.md:66

Write these as a **Visual Theme** block at the top of the output. Every shot's prompt must respect this block.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "401cc3c8e0a4",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```

## 9115162f73b5 — ai-video-storyboard/SKILL.md:89

**Always specify the shared visual language** in every prompt (color palette, lighting, lens character, film look). This is how you enforce consistency.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "9115162f73b5",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot"
        ]
      },
      {
        "op": "eq",
        "path": "track",
        "value": "QUICK"
      }
    ]
  }
}
```
