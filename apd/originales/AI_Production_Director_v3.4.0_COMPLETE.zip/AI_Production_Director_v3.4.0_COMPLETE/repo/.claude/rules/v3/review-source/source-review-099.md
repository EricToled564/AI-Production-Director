# Source coverage review 99/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## f4baff5f618fb2cf — storyboard-architect/brand-packs/README.md:48-50 (code)

```
Version: 1.1 (2026-05-12: switched accent from #D94F3A coral to #C44233 deeper coral)
```

Extracted rules inside block: NONE

## 5a46e6244a39420a — storyboard-architect/brand-packs/README.md:52-52 (heading)

## Contributing examples

Extracted rules inside block: NONE

## 2a0f4ea7ef219dab — storyboard-architect/brand-packs/README.md:54-54 (paragraph)

PRs welcome for new brand-pack examples that fill gaps in the current set. Open an issue with the `brand-pack-request` template before submitting.

Extracted rules inside block: NONE

## f562909117ed8667 — storyboard-architect/brand-packs/_template.md:1-1 (heading)

# Brand Lock: {{BRAND_NAME}}

Extracted rules inside block: NONE

## b828cc6122b6146d — storyboard-architect/brand-packs/_template.md:3-3 (list_item)

> Replace placeholders. Delete this blockquote when you're done.

Extracted rules inside block: NONE

## 0fd1f9cda3882318 — storyboard-architect/brand-packs/_template.md:4-4 (list_item)

> Every field below feeds into the storyboard pipeline. Be specific.

Extracted rules inside block: NONE

## 28dc71146023de4a — storyboard-architect/brand-packs/_template.md:6-6 (heading)

## Identity

Extracted rules inside block: NONE

## 78a1c1887fc1f9d7 — storyboard-architect/brand-packs/_template.md:8-11 (paragraph)

**Brand:** {{BRAND_NAME}}
**One-line description:** What this brand actually does, who for.
**Archetype:** Operator / Creator / Sage / Rebel / Caregiver / Other
**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative

Extracted rules inside block: NONE

## 7d70953f00ad8966 — storyboard-architect/brand-packs/_template.md:13-13 (heading)

## Palette

Extracted rules inside block: NONE

## 2517c34b64fe8a10 — storyboard-architect/brand-packs/_template.md:15-15 (paragraph)

Every hex value here is allowed. Anything outside this list is not.

Extracted rules inside block: NONE

## 24b8ae4899f25677 — storyboard-architect/brand-packs/_template.md:17-17 (table_row)

| Role | Hex | Use |

Extracted rules inside block: 751950af1fe7

## 73046411ddc501e8 — storyboard-architect/brand-packs/_template.md:19-19 (table_row)

| Background | `#______` | Primary canvas |

Extracted rules inside block: NONE

## 9a3c4cf553fc8af7 — storyboard-architect/brand-packs/_template.md:20-20 (table_row)

| Ink | `#______` | Primary text, dark elements |

Extracted rules inside block: NONE

## 01c8fac24a310a11 — storyboard-architect/brand-packs/_template.md:21-21 (table_row)

| Accent | `#______` | Highlights, CTAs, brand pop |

Extracted rules inside block: NONE

## d9f3f414ce524a59 — storyboard-architect/brand-packs/_template.md:22-22 (table_row)

| Muted | `#______` | Secondary text, captions |

Extracted rules inside block: NONE

## aab79245c392662d — storyboard-architect/brand-packs/_template.md:23-23 (table_row)

| Rule | `#______` | Borders, dividers, subtle UI |

Extracted rules inside block: NONE

## b3345c18c30b645b — storyboard-architect/brand-packs/_template.md:25-25 (paragraph)

Add more rows if the brand has more named colors. Don't add more than 8, past that, the brand stops being recognizable.

Extracted rules inside block: 08931603660c

## 09fc2ae00d411cd6 — storyboard-architect/brand-packs/_template.md:27-27 (heading)

## Typography

Extracted rules inside block: NONE

## a610f0de0522de27 — storyboard-architect/brand-packs/_template.md:29-31 (paragraph)

**Display font:** `______`
**Body font:** `______`
**Mono font (optional):** `______`

Extracted rules inside block: NONE

## 63142ede7d044848 — storyboard-architect/brand-packs/_template.md:33-35 (paragraph)

Put the font name and weight in backticks immediately after the label, e.g.
`` **Display font:** `Inter Black 900`, headlines and hooks ``. The HTML preview and
the overlay-font check read that backticked value; anything before it is prose.

Extracted rules inside block: NONE

## a8a5fd0e9c9e184e — storyboard-architect/brand-packs/_template.md:37-37 (paragraph)

Two fonts max for production work. Three only if one is reserved for code/data.

Extracted rules inside block: NONE

## c32487af16f4f94e — storyboard-architect/brand-packs/_template.md:39-39 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## 1452c300149e784a — storyboard-architect/brand-packs/_template.md:41-41 (paragraph)

Pick 3–5. These flow into prompts as the brand's emotional posture.

Extracted rules inside block: NONE

## 66ace2f0838c7c88 — storyboard-architect/brand-packs/_template.md:43-43 (list_item)

- adjective_1

Extracted rules inside block: NONE

## 983ab0734b11ff43 — storyboard-architect/brand-packs/_template.md:44-44 (list_item)

- adjective_2

Extracted rules inside block: NONE

## 842b7e7892a14742 — storyboard-architect/brand-packs/_template.md:45-45 (list_item)

- adjective_3

Extracted rules inside block: NONE

## 160da443100cc70f — storyboard-architect/brand-packs/_template.md:47-47 (heading)

## Never list

Extracted rules inside block: NONE

## c4c98570dd4603d0 — storyboard-architect/brand-packs/_template.md:49-49 (paragraph)

What this brand never does, visually or tonally. Be specific.

Extracted rules inside block: d966d89c7b90

## c718d732354d5a74 — storyboard-architect/brand-packs/_template.md:51-51 (list_item)

- never use stock photo aesthetic

Extracted rules inside block: ebb1065ba6a5

## 4c7e3c7e239e04e3 — storyboard-architect/brand-packs/_template.md:52-52 (list_item)

- never use AI uncanny faces

Extracted rules inside block: d2d9fe8212a8
