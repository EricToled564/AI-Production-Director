# Source coverage review 14/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 3cb59eca470bbaf1 — aurora-prompt-linter/SKILL.md:169-169 (heading)

## Archivos del paquete

Extracted rules inside block: NONE

## 4418248db557a5f2 — aurora-prompt-linter/SKILL.md:171-181 (code)

```
aurora-prompt-linter/
├── SKILL.md                       (este archivo)
├── scripts/
│   ├── prompt_linter.py           (CLI ejecutable)
│   └── vocabularies.yaml          (vocabulary lists base)
└── references/
    ├── README.md                  (uso detallado + tests)
    ├── skill_update_step5.md      (edit al skill prompt-production-protocol)
    └── system_prompt_v6_1_rule28.md (9 edits propuestas a system prompt v6.0)
```

Extracted rules inside block: NONE

## 4df3182758c865fd — aurora-prompt-linter/SKILL.md:183-183 (heading)

## Versión

Extracted rules inside block: NONE

## 3b0d185ad87b74ef — aurora-prompt-linter/SKILL.md:185-187 (paragraph)

v1.0 — 2026-05-27
Built by: Final Upgrade AI / Eric Toledano
Origen: Retrospectiva F7 sesión 2026-05-27

Extracted rules inside block: NONE

## f1a53cf0dbdf5dad — aurora-prompt-linter/references/README.md:1-1 (heading)

# Aurora Prompt Linter v1.0

Extracted rules inside block: NONE

## 4c2d7f292b2298cb — aurora-prompt-linter/references/README.md:3-3 (paragraph)

Linter determinista que bloquea entrega de prompts AI con redundancia respecto a refs, violaciones de estructura, vocabulario baneado o falta de keywords obligatorios. Integra con el skill `prompt-production-protocol` como gate obligatorio en Step 5.

Extracted rules inside block: 0571c5dbdc31

## 0383cc381804ea70 — aurora-prompt-linter/references/README.md:5-5 (heading)

## Por qué existe

Extracted rules inside block: NONE

## 1d608978c453a3b3 — aurora-prompt-linter/references/README.md:7-7 (paragraph)

Sesión 2026-05-27: el agente cometió el mismo error tres veces (describir en el prompt cosas ya visibles en los refs). v6.0 §5.4 lo prohíbe pero el agente lo olvida bajo presión. El linter mueve el enforcement de "memoria del agente" a "regla determinista en código".

Extracted rules inside block: NONE

## 2bc2540bcd73ebb7 — aurora-prompt-linter/references/README.md:9-9 (heading)

## Cobertura

Extracted rules inside block: NONE

## 4a889ec5d961cfb1 — aurora-prompt-linter/references/README.md:11-11 (table_row)

| Versión | Cobertura efectiva |

Extracted rules inside block: NONE

## aef1ce6b16535b98 — aurora-prompt-linter/references/README.md:13-13 (table_row)

| Solo memoria + skill | ~50% |

Extracted rules inside block: NONE

## 27c26eee67ecbe02 — aurora-prompt-linter/references/README.md:14-14 (table_row)

| Linter regex genérico | ~70% |

Extracted rules inside block: NONE

## 08ceec6c09fd3276 — aurora-prompt-linter/references/README.md:15-15 (table_row)

| **v1.0 (este) — tags por categoría + override** | **~92-94%** |

Extracted rules inside block: NONE

## 1e0b70b3ce5db8c2 — aurora-prompt-linter/references/README.md:17-17 (heading)

## Cómo se usa

Extracted rules inside block: NONE

## d390968e666276a0 — aurora-prompt-linter/references/README.md:19-26 (code)

```bash
python3 prompt_linter.py \
  --prompt path/to/prompt.txt \
  --refs path/to/refs.yaml \
  --case 3b \
  --overrides path/to/user_message.txt \
  --sports-broadcast
```

Extracted rules inside block: NONE

## 55d54dd7293da1d8 — aurora-prompt-linter/references/README.md:28-28 (paragraph)

Exit code:

Extracted rules inside block: NONE

## 1a27128b6309d860 — aurora-prompt-linter/references/README.md:29-29 (list_item)

- `0` → PASS, entrega permitida

Extracted rules inside block: NONE

## c2fadd73b18ed87c — aurora-prompt-linter/references/README.md:30-30 (list_item)

- `1` → FAIL, entrega bloqueada

Extracted rules inside block: NONE

## edc89a8dc59021b2 — aurora-prompt-linter/references/README.md:32-32 (heading)

## Formato de refs.yaml

Extracted rules inside block: NONE

## 3d24c5ccf9cde767 — aurora-prompt-linter/references/README.md:34-34 (paragraph)

Cada ref se etiqueta con las categorías que carga (mapea a IDs system v6.0 §7):

Extracted rules inside block: NONE

## de7a896d2862bfdb — aurora-prompt-linter/references/README.md:36-43 (code)

```yaml
- file: "img_ciclista_balon_aire.jpg"
  role: "FF"          # FF | LF | MR (motion ref)
  tags: ["P1", "O1", "L1", "PR1"]   # persona, outfit, locación, prop
- file: "img_climbing_wall.jpg"
  role: "LF"
  tags: ["L2", "PR1"]    # nueva locación + mismo prop
```

Extracted rules inside block: NONE

## 04df0a3360b2f5e6 — aurora-prompt-linter/references/README.md:45-45 (paragraph)

Categorías:

Extracted rules inside block: NONE

## 90cd92cff8f2a09a — aurora-prompt-linter/references/README.md:46-46 (list_item)

- **P** — Personaje / Sujeto

Extracted rules inside block: NONE

## 83631e0220b6bbf6 — aurora-prompt-linter/references/README.md:47-47 (list_item)

- **O** — Outfit

Extracted rules inside block: NONE

## c9c82d0160773c37 — aurora-prompt-linter/references/README.md:48-48 (list_item)

- **L** — Locación

Extracted rules inside block: NONE

## 22cd878d6b0d1cb4 — aurora-prompt-linter/references/README.md:49-49 (list_item)

- **PR** — Prop

Extracted rules inside block: NONE

## f55a617e14e4cfcb — aurora-prompt-linter/references/README.md:50-50 (list_item)

- **S** — Estilo

Extracted rules inside block: NONE

## b88a9a53de7e198a — aurora-prompt-linter/references/README.md:52-52 (paragraph)

Si una categoría tiene AL MENOS UN ref, sus descriptores estáticos quedan baneados en el MAIN prompt. Las categorías sin ref siguen siendo describibles.

Extracted rules inside block: NONE

## 32d822779c717a7b — aurora-prompt-linter/references/README.md:54-54 (heading)

## Casos soportados

Extracted rules inside block: NONE

## 60858bfd8b8e3004 — aurora-prompt-linter/references/README.md:56-56 (table_row)

| Case | Descripción | Word budget |

Extracted rules inside block: NONE
