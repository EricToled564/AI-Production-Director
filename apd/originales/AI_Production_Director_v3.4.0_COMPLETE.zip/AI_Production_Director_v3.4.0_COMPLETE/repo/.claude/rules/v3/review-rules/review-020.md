# Rule classification review 20/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## 34173409a1d1 — video/references/camera-lighting-vocabulary.md:11

Light direction

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "34173409a1d1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 007e8995e64b — video/references/camera-lighting-vocabulary.md:12

Light quality

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "007e8995e64b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 7cdd52709bc2 — video/references/camera-lighting-vocabulary.md:13

Color discipline

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "7cdd52709bc2",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## f06f964ce392 — video/references/camera-lighting-vocabulary.md:14

Sound categories

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "f06f964ce392",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 54bc1eb81fdf — video/references/camera-lighting-vocabulary.md:15

Blocking language

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "54bc1eb81fdf",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## cccb8ca7a598 — video/references/camera-lighting-vocabulary.md:16

Translating uncommon terms

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "cccb8ca7a598",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## aaf8974dd19b — video/references/camera-lighting-vocabulary.md:17

Transition vocabulary

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "aaf8974dd19b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 9d79a9d36df8 — video/references/camera-lighting-vocabulary.md:31

over-the-shoulder

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "9d79a9d36df8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## ea320b5350ef — video/references/camera-lighting-vocabulary.md:78

shallow depth of field.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "ea320b5350ef",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## fb35029af5f3 — video/references/camera-lighting-vocabulary.md:138

Define palette with concrete colors. Never write "cinematic colors."

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": "vocabulary.visual_style_quality",
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "fb35029af5f3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "lexical"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 02aa19d9c833 — video/references/camera-lighting-vocabulary.md:246

Rules of use. Name the transition and the exact moment it fires. One transition type per cut. When the choice is open, delegate: "choose the most suitable from [natural cut / occlusion mask / match cut] for the style of this film."

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "02aa19d9c833",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 86b32d5d66d3 — video/references/dramaturgy.md:3

This is the mandatory layer. A beautiful frame without dramaturgy is wallpaper. Every prompt built by this skill must pass the dramaturgy check before it is sent to the user.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "86b32d5d66d3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 479e77aad455 — video/references/dramaturgy.md:7

Core law. Scene formula

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "479e77aad455",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## a1a18fee60a3 — video/references/dramaturgy.md:8

Second law. Details intensify emotion

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "a1a18fee60a3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 0d7199d6f27f — video/references/dramaturgy.md:9

The three-jobs rule (what every shot must do)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "0d7199d6f27f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## a5dbcb81080e — video/references/dramaturgy.md:10

Walter Murch Rule of Six

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "a5dbcb81080e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## adf441ccfbcc — video/references/dramaturgy.md:11

Blocking as choreography of desire

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "adf441ccfbcc",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 027c6e566ecf — video/references/dramaturgy.md:12

Staging controls subtext

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "027c6e566ecf",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 75dd25364868 — video/references/dramaturgy.md:13

Camera must have a reason

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "75dd25364868",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 7973365cff72 — video/references/dramaturgy.md:14

Spatial clarity beats montage hysteria

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "7973365cff72",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 56080e651eb3 — video/references/dramaturgy.md:15

Environment plays

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "56080e651eb3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## ecf444cb8b44 — video/references/dramaturgy.md:16

Three-layer storyboard method

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "ecf444cb8b44",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## cedac221d541 — video/references/dramaturgy.md:17

Shot card template (14 fields)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "cedac221d541",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 0f9b3b9bbc39 — video/references/dramaturgy.md:18

Rhythm ladder

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "0f9b3b9bbc39",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 0fa3c7060a92 — video/references/dramaturgy.md:19

One-anchor principle

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "0fa3c7060a92",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 5046f1e31401 — video/references/dramaturgy.md:20

Worked example

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "5046f1e31401",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## fb39bdd69c68 — video/references/dramaturgy.md:21

Dramaturgy check before sending any prompt

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "fb39bdd69c68",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## cbf2a756fd6e — video/references/dramaturgy.md:45

The scene formula tells you **what a scene is**. The Details Law tells you **how every shot must be written**. Skip it and even a perfect dramaturgical structure produces mush on screen.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "cbf2a756fd6e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 7d3f54d67069 — video/references/dramaturgy.md:53

**Environmental pressure.** A physical fact about the space that carries the emotion. Cold refrigerator light. Wet asphalt. Flickering ceiling tube. Steam from the kettle. Rain on one specific windowpane. A buzzing AC unit. Tight corridor walls. Mirror reflection. (See §9 — Environment plays.)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "7d3f54d67069",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 0e88ae42f887 — video/references/dramaturgy.md:54

**Physical micro-action on the body.** The emotion translated into the actor's body. Jaw locks. Knuckles whiten. Lips press flat. Eyes drop a quarter-inch. He swallows hard. Fingers curl against the doorframe. The actor's body is the only place where feelings render — names of feelings do not.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "0e88ae42f887",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## e96d487a1ca3 — video/references/dramaturgy.md:55

**Sound anchor or visual motif.** A recurring perceptual hook tied to the spine of the piece. Stomach growl repeated three times. Reflection in dark glass on every transition. The same musical sting at every Crack beat. The clock's second hand. Footsteps in an empty corridor.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "e96d487a1ca3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "video"
      },
      {
        "op": "eq",
        "path": "subject.hands_visible",
        "value": true
      }
    ]
  }
}
```

## 3ba97ba6f534 — video/references/dramaturgy.md:81

Every shot must do at least one of three things. If it does none, delete it.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "3ba97ba6f534",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## 674f79d5da56 — video/references/dramaturgy.md:93

**Emotion (51%).** Does the cut honor the emotional truth of the moment. What does the viewer feel now vs. what they should feel next.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "674f79d5da56",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## d8a7429de47c — video/references/dramaturgy.md:94

**Story (23%).** Does the cut advance story or reveal character.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "d8a7429de47c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```

## d8dab8a1cdca — video/references/dramaturgy.md:95

**Rhythm (10%).** Does the cut fall on a musical beat of the scene.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "d8dab8a1cdca",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "video"
  }
}
```
