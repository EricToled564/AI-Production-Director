# Source coverage review 222/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 7c1e9e7f71ed0793 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:53-53 (list_item)

- **Midjourney** is a comma-separated stack with `--ar`, `--style raw`, `--s 50` flags

Extracted rules inside block: NONE

## c68086c01f649ff7 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:54-54 (list_item)

- **Flux** is natural-language paragraphs with no flags, parameters live in the API call

Extracted rules inside block: NONE

## 177f5f307ebcd728 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:55-55 (list_item)

- **GPT Image** uses paragraph breaks and explicit spatial language

Extracted rules inside block: NONE

## ee0a0491f548cc56 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:56-56 (list_item)

- **Seedream** is the shortest, comma stack like Midjourney but no flags

Extracted rules inside block: NONE

## 2e5d4caf51602429 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:57-57 (list_item)

- **Kling** (and every motion adapter) leads with camera motion (the stills adapters let it be implicit)

Extracted rules inside block: NONE

## 4fac3df4db9b244f — visual-prompt-forge/examples/one-shot-all-adapters/README.md:59-59 (paragraph)

Same intent. Different syntax. Same brand-lock and series-lock anchors flowing through all of them.

Extracted rules inside block: NONE

## 8227a309ba7cd7f7 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:61-61 (heading)

## What's not in any prompt

Extracted rules inside block: NONE

## 93b49b9fa1959421 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:63-63 (paragraph)

The on-screen text content. Even though shot_04 has an on-screen text overlay (`text_03`, "You don't have a content problem. You have an infrastructure problem."), none of the prompts contain that text. It's composited separately per the five-layer model.

Extracted rules inside block: 2b19da8c2aea

## 2b1c7e832daf2e22 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:65-65 (paragraph)

This is the discipline: the image generator handles the image, the compositor handles the text, neither tries to do the other's job.

Extracted rules inside block: NONE

## 44b5321698465b43 — visual-prompt-forge/references/consistency-locks.md:1-1 (heading)

# Consistency Locks

Extracted rules inside block: NONE

## bd9401f7bdd9386c — visual-prompt-forge/references/consistency-locks.md:3-3 (paragraph)

Visual consistency across a storyboard is the hardest problem in AI image generation. Generators are stateless, every prompt is interpreted fresh. Without consistency locks, shot 1 and shot 7 will look like different productions.

Extracted rules inside block: NONE

## a42271313948afcf — visual-prompt-forge/references/consistency-locks.md:5-5 (paragraph)

This document covers the techniques that actually work in 2026.

Extracted rules inside block: NONE

## 025347d3dfc58a25 — visual-prompt-forge/references/consistency-locks.md:7-7 (heading)

## Lock 1. Verbatim character anchors

Extracted rules inside block: NONE

## f32c541c86891c8a — visual-prompt-forge/references/consistency-locks.md:9-9 (paragraph)

The most effective single technique. The character is described in `series_lock.character` once, and that exact string appears in every shot's prompt verbatim. No paraphrasing, no synonyms, no "improvement."

Extracted rules inside block: NONE

## 0b4bc6541d805368 — visual-prompt-forge/references/consistency-locks.md:11-11 (paragraph)

**Good (consistent):**

Extracted rules inside block: NONE

## a88e7c3fd80e4a53 — visual-prompt-forge/references/consistency-locks.md:12-16 (code)

```
shot_01: "founder, mid-thirties, salt-and-pepper hair, navy crewneck, stubble"
shot_02: "founder, mid-thirties, salt-and-pepper hair, navy crewneck, stubble"
shot_07: "founder, mid-thirties, salt-and-pepper hair, navy crewneck, stubble"
```

Extracted rules inside block: NONE

## f7c51847eeb0f0e0 — visual-prompt-forge/references/consistency-locks.md:18-18 (paragraph)

**Bad (inconsistent):**

Extracted rules inside block: NONE

## e15cddfdac4025f1 — visual-prompt-forge/references/consistency-locks.md:19-23 (code)

```
shot_01: "a thoughtful entrepreneur in his thirties, dark hair, casual sweater"
shot_02: "founder, 35 years old, salt-pepper hair, blue knit top"
shot_07: "the man in the home office, navy shirt"
```

Extracted rules inside block: NONE

## 3ba8026c92bfa2af — visual-prompt-forge/references/consistency-locks.md:25-25 (paragraph)

Even small variations compound. Lock the string. Repeat verbatim.

Extracted rules inside block: NONE

## 79021a97ec830b14 — visual-prompt-forge/references/consistency-locks.md:27-27 (heading)

## Lock 2. Verbatim environment anchors

Extracted rules inside block: NONE

## e8ef72de7e8312e9 — visual-prompt-forge/references/consistency-locks.md:29-29 (paragraph)

Same principle for `series_lock.environment`. The environment string is identical in every shot prompt. The shot's individual subject describes what changes within the environment, not the environment itself.

Extracted rules inside block: NONE

## f613fb7fc05de11f — visual-prompt-forge/references/consistency-locks.md:31-31 (heading)

## Lock 3. Verbatim lighting anchors

Extracted rules inside block: NONE

## 36bfd63a36d49a40 — visual-prompt-forge/references/consistency-locks.md:33-33 (paragraph)

Same principle for `series_lock.lighting`. Lighting direction in particular is critical, flipping window-left to window-right between shots produces obvious cuts where there shouldn't be any.

Extracted rules inside block: 9ef19434032d

## 272f2a650cc6aa53 — visual-prompt-forge/references/consistency-locks.md:35-35 (heading)

## Lock 4. Seed locking

Extracted rules inside block: NONE

## e7be4862078a494b — visual-prompt-forge/references/consistency-locks.md:37-37 (paragraph)

For generators that support seeds (Flux, Seedream, Ideogram, Stable Diffusion), set the seed at the storyboard level. Same seed across every shot. This anchors the generator's randomness so character features carry.

Extracted rules inside block: NONE

## 6e113b20cde20b7f — visual-prompt-forge/references/consistency-locks.md:39-39 (paragraph)

In `shots.json`, you can document the seed at the project level:

Extracted rules inside block: NONE

## 316ec639d1d970e2 — visual-prompt-forge/references/consistency-locks.md:41-48 (code)

```json
{
  "project": {
    "title": "...",
    "seed": 2840193
  }
}
```

Extracted rules inside block: NONE

## efc108360ec83e98 — visual-prompt-forge/references/consistency-locks.md:50-50 (paragraph)

The adapter reads this and applies to every prompt.

Extracted rules inside block: NONE

## 0b0cf3f816c715fc — visual-prompt-forge/references/consistency-locks.md:52-52 (paragraph)

**Caveat:** Midjourney and some motion models (Veo, Seedance) handle seeds differently, or not at all. Document seed-locking as best-effort, not guaranteed.

Extracted rules inside block: NONE

## 5a5bcb1bb95e183a — visual-prompt-forge/references/consistency-locks.md:54-54 (heading)

## Lock 5. Reference images (`--cref`, omni-reference, image-to-image)

Extracted rules inside block: NONE
