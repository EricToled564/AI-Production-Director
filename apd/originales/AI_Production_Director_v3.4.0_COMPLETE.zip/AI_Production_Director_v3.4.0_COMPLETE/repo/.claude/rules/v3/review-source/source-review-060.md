# Source coverage review 60/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4d5a6d012773c3be — image/references/patterns/portrait-cinema.md:31-31 (paragraph)

<!-- Source concept: convenience store / bodega neon portrait — fluorescent + neon mixed light on face -->

Extracted rules inside block: NONE

## db858b1179524f02 — image/references/patterns/portrait-cinema.md:33-39 (code)

```
Scene: exterior of a {store_type} at night, shot through or near the front window/entrance, overhead fluorescent tubes casting flat {fluorescent_color} light from inside, {neon_sign_description} mounted on the wall/window casting {neon_color} glow on one side of the subject's face
Subject: {person_description}, {pose_description}, positioned at the threshold between interior fluorescent zone and exterior neon zone — split lighting across the face
Important Details: face receives {fluorescent_color} fill from the store interior on one side and {neon_color} accent from signage on the other — the two colors mix on the nose bridge and chin, visible product shelves or cooler glow softly in background bokeh, {clothing_description} absorbs and reflects the two light sources differently, condensation or grime on window glass if shot through it (subtle, not obscuring), wet pavement outside reflects both light sources in streaks, shallow depth of field with subject sharp, background a mosaic of colored bokeh, {camera_feel}
Use Case: urban editorial, music press portrait, fashion story, short film still
Constraints: face clearly visible — neither light source blows out features, neon sign text (if present) is secondary to the portrait not the focal point, no additional light sources beyond what exists in the scene, no heavy color grading beyond what the practical lights create naturally, no motion blur
```

Extracted rules inside block: NONE

## a27c6b01d6bf049b — image/references/patterns/portrait-cinema.md:41-41 (paragraph)

**Key levers:** `{store_type}` (Korean convenience store, bodega, late-night pharmacy, 24-hour laundromat), `{fluorescent_color}` (cool blue-white, greenish-white, warm tungsten), `{neon_sign_description}` (red "OPEN" sign, blue beer brand logo, pink cursive word), `{neon_color}` (red #FF2D2D, blue #3366FF, pink #FF69B4, green #39FF14), `{person_description}`, `{pose_description}` (leaning against door frame, sitting on overturned crate, standing with hands in pockets), `{clothing_description}` (dark hoodie that absorbs light, white t-shirt that bounces both colors, leather that reflects), `{camera_feel}` (Cinestill 800T with halation around neon, clean digital night, Fujifilm color science)

Extracted rules inside block: NONE

## 722418c60d35fc33 — image/references/patterns/portrait-cinema.md:43-43 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — precise dual-light color rendering on skin

Extracted rules inside block: 77c9a0f9be13

## a193371f41354369 — image/references/patterns/portrait-cinema.md:47-47 (heading)

## Monochrome Glitch Profile Portrait

Extracted rules inside block: NONE

## 2248957aeb451826 — image/references/patterns/portrait-cinema.md:49-49 (paragraph)

Use for edgy, tech-forward portraits — artist profiles, electronic music press, tech brand campaigns. High contrast black-and-white with selective red digital artifacts.

Extracted rules inside block: 02ba10d9c3cf

## a5b3abf1aac51265 — image/references/patterns/portrait-cinema.md:51-51 (paragraph)

<!-- Source concept: monochrome profile portrait with digital glitch artifacts and red accent color -->

Extracted rules inside block: NONE

## a817d8189858c60e — image/references/patterns/portrait-cinema.md:53-59 (code)

```
Scene: pure black background (#000000), no environment — subject emerges from darkness
Subject: {person_description} in sharp profile (facing {direction}), head and upper shoulders only, high-contrast black-and-white rendering
Important Details: extreme contrast — skin highlights blow to near-white, shadows fall to pure black with minimal midtone graduation, {hair_detail} silhouetted against black, one eye visible in profile with a single catchlight, horizontal glitch displacement lines cutting across the image at {glitch_positions} — each line offsets a thin horizontal slice (4-8px) to the right by 10-20px, the displaced slices rendered in {accent_color} (#FF0000 default) while the rest remains monochrome, fine horizontal scan lines across entire image (subtle, CRT monitor texture), grain: heavy high-ISO film grain throughout, jaw line and nose bridge are the sharpest elements in frame
Use Case: artist press photo, electronic music EP cover, tech brand portrait, social media profile
Constraints: glitch lines must look digital (clean horizontal displacement, not organic), accent color appears ONLY in the displaced glitch slices — no other colored elements, maximum {max_glitch_lines} glitch lines to avoid visual noise, face must remain recognizable despite artifacts, no text, background is solid black — no gradient or texture
```

Extracted rules inside block: NONE

## 46e19d8098a2a80d — image/references/patterns/portrait-cinema.md:61-61 (paragraph)

**Key levers:** `{person_description}`, `{direction}` (left, right), `{hair_detail}` (tight buzz cut showing skull contour, shoulder-length hair with flyaway strands catching backlight, pulled-back bun), `{glitch_positions}` (across the eye, across the mouth, across the forehead — specify 2-3 positions), `{accent_color}` (#FF0000 red, #00FF41 terminal green, #FF00FF magenta), `{max_glitch_lines}` (3-5)

Extracted rules inside block: 8851533189b2

## fa7b7168b86de609 — image/references/patterns/portrait-cinema.md:63-63 (paragraph)

**Recommended model:** GPT Image 2 — high-contrast mono rendering and controlled glitch placement

Extracted rules inside block: 4909ea7569be

## 960c04d30f1ba340 — image/references/patterns/portrait-cinema.md:67-67 (heading)

## Japanese Negative Film Rooftop Portrait

Extracted rules inside block: NONE

## 92c22113f858fe67 — image/references/patterns/portrait-cinema.md:69-69 (paragraph)

Use for moody, atmospheric portraits with overexposed analog film qualities — muted colors, lifted shadows, and a feeling of faded memory. Ideal for editorial, zine, or personal project work.

Extracted rules inside block: 0530ce6beedc

## e3b639a0bae9041d — image/references/patterns/portrait-cinema.md:71-71 (paragraph)

<!-- Source concept: Japanese negative film aesthetic — overexposed, muted tones, rooftop setting -->

Extracted rules inside block: NONE

## 8688562b93e9500b — image/references/patterns/portrait-cinema.md:73-73 (paragraph)

A waist-up portrait of {person_description} on a {rooftop_description}. They stand near the edge railing, {pose_description}, with the {city_skyline} visible behind them but washed out and desaturated by {sky_condition}. Shot on expired Japanese negative film — colors shifted toward {color_shift}, highlights blown soft and chalky, shadows lifted with visible grain in the flat midtones. Skin tones slightly green-yellow as if the film has aged. {clothing_description} reads as muted tones, almost monochromatic against the overexposed sky. Wind moves {wind_detail}. The mood is nostalgic and transient — a memory captured on deteriorating film stock. Eye-level framing, subject slightly off-center toward {frame_position}. Format: {aspect_ratio}.

Extracted rules inside block: NONE

## b85b1ce35f371b29 — image/references/patterns/portrait-cinema.md:75-75 (paragraph)

**Key levers:** `{person_description}`, `{rooftop_description}` (concrete apartment building rooftop, industrial warehouse roof with exhaust vents, school building roof with chain-link fence), `{pose_description}` (leaning on railing looking at camera, turned away looking at skyline, sitting on a ledge with knees drawn up), `{city_skyline}` (Tokyo mid-rise apartments, generic Asian city with power lines), `{sky_condition}` (overcast white sky, hazy afternoon sun), `{color_shift}` (green-cyan cast, yellow-amber cast), `{clothing_description}` (oversized vintage windbreaker, plain white t-shirt, navy work jacket), `{wind_detail}` (hair across face, jacket hem, collar), `{frame_position}` (left third, right third), `{aspect_ratio}` (3:2, 4:5)

Extracted rules inside block: NONE

## 77d8cf5e75287a77 — image/references/patterns/portrait-cinema.md:77-77 (paragraph)

**Recommended model:** NB2 — analog film grain emulation and atmospheric mood

Extracted rules inside block: 66920a404c20

## 775ae205918fe3ba — image/references/patterns/portrait-cinema.md:81-81 (heading)

## Dreamy Underwater Surreal Portrait

Extracted rules inside block: NONE

## 895bb4d93fd94772 — image/references/patterns/portrait-cinema.md:83-83 (paragraph)

Use for beauty campaigns, conceptual art, or album visuals — a portrait where the subject floats in clear water surrounded by translucent aquatic elements.

Extracted rules inside block: dc9fc2bd0a8f

## c219396c905d1102 — image/references/patterns/portrait-cinema.md:85-85 (paragraph)

<!-- Source concept: surreal underwater portrait with translucent fish and dreamy caustic light -->

Extracted rules inside block: NONE

## cfbe893d1c16176d — image/references/patterns/portrait-cinema.md:87-93 (code)

```
Scene: clear {water_color} water filling the entire frame, caustic light patterns rippling across the subject from above (sunlight through water surface), no visible pool walls or floor — infinite aquatic void
Subject: {person_description}, floating in a relaxed {pose_description}, eyes {eye_state}, hair fanning out in all directions as if weightless, {clothing_description} billowing and suspended in the water
Important Details: {fish_count} translucent {fish_type} swimming in a loose school around the subject — each fish semi-transparent with visible skeletal structure and iridescent scales catching the caustic light, light rays penetrating from above in {light_pattern}, fine air bubbles rising from near the subject's {bubble_source}, fabric of clothing moves independently from the body — folds and hems suspended in mid-drift, skin has a subtle cool {water_tint} cast from the water, overall palette is {palette}, composition framed as a {shot_type}
Use Case: beauty campaign, album cover, conceptual art print, fashion editorial
Constraints: subject's face must be clearly visible and serene (not distressed or holding breath with effort), fish are translucent — not solid opaque tropical fish, no visible water surface edge or pool tiles, no scuba gear or goggles, bubbles are small and delicate not large air pockets, underwater physics must be consistent (everything floats)
```

Extracted rules inside block: NONE

## 6ef6e99c1285b07b — image/references/patterns/portrait-cinema.md:95-95 (paragraph)

**Key levers:** `{water_color}` (deep cerulean #0077B6, pale turquoise #AFEEEE, dark teal #004D4D), `{person_description}`, `{pose_description}` (arms slightly outstretched like a slow free-fall, curled fetal position, one arm reaching upward toward the light), `{eye_state}` (softly closed, open and gazing upward at the light, looking directly at camera), `{clothing_description}` (flowing white silk dress, loose linen shirt and trousers, sheer organza wrap), `{fish_count}` (5-8), `{fish_type}` (jellyfish, small reef fish, elongated glass catfish), `{light_pattern}` (parallel god rays from upper right, scattered dappled caustics, single concentrated beam), `{bubble_source}` (lips, fingertips, fabric edges), `{water_tint}` (blue-green, aquamarine), `{palette}` (teal and ivory, deep blue and gold, seafoam and blush), `{shot_type}` (full body vertical, waist-up centered, three-quarter with negative space below)

Extracted rules inside block: NONE

## 2233d71047a78fe6 — image/references/patterns/portrait-cinema.md:97-97 (paragraph)

**Recommended model:** NBP — complex physics (floating hair, fabric, fish transparency, caustic light)

Extracted rules inside block: 0be6bc5b5672

## fae208acf7f6c2d8 — image/references/patterns/portrait-cinema.md:99-99 (heading)

### Nano Banana version:

Extracted rules inside block: NONE

## fca527f97e09879e — image/references/patterns/portrait-cinema.md:101-103 (code)

```
A surreal underwater portrait of {person_description} floating in a relaxed {pose_description} in clear {water_color} water. Eyes {eye_state}, hair fans out weightlessly in all directions. {clothing_description} billows and suspends in the current, folds drifting independently. {fish_count} translucent {fish_type} swim in a loose school around the subject — each semi-transparent with visible skeletal structure and iridescent scales catching caustic light from above. Sunlight penetrates from the surface in {light_pattern}, casting rippling patterns across skin and fabric. Fine air bubbles rise from the subject's {bubble_source}. Skin has a subtle cool {water_tint} cast. No pool walls, no surface edge visible — infinite aquatic void. Serene and dreamlike. Palette: {palette}. Format: 4:5.
```

Extracted rules inside block: NONE

## 3406790740823011 — image/references/patterns/portrait-cinema.md:107-107 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## f89d5479a377b511 — image/references/patterns/poster-illustration.md:1-1 (heading)

# Poster & Illustration Patterns

Extracted rules inside block: NONE

## 85b211e866d335fb — image/references/patterns/poster-illustration.md:3-3 (paragraph)

Reusable prompt templates for posters, art prints, campaign collages, and graphic illustrations. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

Extracted rules inside block: NONE

## e513b059cecfc5e5 — image/references/patterns/poster-illustration.md:7-7 (heading)

## City Across Two Centuries (Time-Split Composition)

Extracted rules inside block: NONE

## b78b5dbd041295f4 — image/references/patterns/poster-illustration.md:9-9 (paragraph)

Use for urban development campaigns, anniversary materials, cultural exhibitions, or editorial features — a single city view divided down the middle, one half historical and one half modern.

Extracted rules inside block: dc7605a12f79

## 89951414928040bc — image/references/patterns/poster-illustration.md:11-11 (paragraph)

<!-- Source concept: time-split composition — same city view, two eras side by side -->

Extracted rules inside block: NONE
