# Source coverage review 213/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 8db79b460c66530b — visual-prompt-forge/adapters/midjourney.md:13-13 (paragraph)

Comma-separated phrases. No full sentences. No connective words ("the", "with", "and") unless they're load-bearing.

Extracted rules inside block: NONE

## ed4663ea797dab6b — visual-prompt-forge/adapters/midjourney.md:15-15 (heading)

## Parameter reference (current as of Q2 2026)

Extracted rules inside block: NONE

## 57d86fdb49256bb2 — visual-prompt-forge/adapters/midjourney.md:17-17 (table_row)

| Param | Values | Default to use | Notes |

Extracted rules inside block: e44be687a773

## 12849b0c4b9067f6 — visual-prompt-forge/adapters/midjourney.md:19-19 (table_row)

| `--ar` | aspect ratio | from `project.aspect` | `--ar 9:16`, `--ar 16:9`, `--ar 1:1` |

Extracted rules inside block: NONE

## 926fa77b8aba38c6 — visual-prompt-forge/adapters/midjourney.md:20-20 (table_row)

| `--style` | `raw` / `4a` / `4b` / `4c` | `raw` | `raw` for photorealistic, omit for default Midjourney aesthetic |

Extracted rules inside block: NONE

## a72f3bedf9dac2e9 — visual-prompt-forge/adapters/midjourney.md:21-21 (table_row)

| `--s` | 0–1000 | `50` for branded, `250` for artistic | Stylization weight. Lower = closer to prompt, higher = more MJ aesthetic |

Extracted rules inside block: NONE

## c455ae12d72c322e — visual-prompt-forge/adapters/midjourney.md:22-22 (table_row)

| `--c` | 0–100 | omit | Chaos. Use only when exploring variations |

Extracted rules inside block: 24176401572f

## dd29c0614a6992a9 — visual-prompt-forge/adapters/midjourney.md:23-23 (table_row)

| `--seed` | integer | omit unless reproducing | For series consistency, set per-storyboard |

Extracted rules inside block: NONE

## 5691eb50b4045b7f — visual-prompt-forge/adapters/midjourney.md:24-24 (table_row)

| `--cref` | image URL | use when character anchor exists | Character reference. Pair with `--cw` |

Extracted rules inside block: b0e02b79237d

## 15bc16383d1074aa — visual-prompt-forge/adapters/midjourney.md:25-25 (table_row)

| `--cw` | 0–100 | `50` | Character weight. 100 = strict character match, 0 = clothing only |

Extracted rules inside block: NONE

## 29cac30b225f6344 — visual-prompt-forge/adapters/midjourney.md:26-26 (table_row)

| `--sref` | image URL | use when style anchor exists | Style reference |

Extracted rules inside block: e0387c3e5469

## e97ff6652a41763d — visual-prompt-forge/adapters/midjourney.md:28-28 (heading)

## Length

Extracted rules inside block: NONE

## d57eb532a92e4c42 — visual-prompt-forge/adapters/midjourney.md:30-30 (paragraph)

Aim for **40–80 words per prompt** including parameters. Anything over 100 words underperforms.

Extracted rules inside block: NONE

## a0863520ec057492 — visual-prompt-forge/adapters/midjourney.md:32-32 (heading)

## Composition mapping

Extracted rules inside block: NONE

## 6ee645d8ab376904 — visual-prompt-forge/adapters/midjourney.md:34-34 (paragraph)

Translate shot grammar into Midjourney-friendly phrases:

Extracted rules inside block: NONE

## c97d330d439a4839 — visual-prompt-forge/adapters/midjourney.md:36-36 (table_row)

| shot_grammar | Midjourney phrase |

Extracted rules inside block: NONE

## 6fb2cd853b25b2f0 — visual-prompt-forge/adapters/midjourney.md:38-38 (table_row)

| `MCU eye-level` | `medium close-up, eye level` |

Extracted rules inside block: NONE

## c635638d3e7c531f — visual-prompt-forge/adapters/midjourney.md:39-39 (table_row)

| `WS overhead` | `wide shot, overhead view, top-down` |

Extracted rules inside block: NONE

## ff1232dcd8737c0c — visual-prompt-forge/adapters/midjourney.md:40-40 (table_row)

| `static` | (omit, static is default) |

Extracted rules inside block: NONE

## 53d8d4f775982f9b — visual-prompt-forge/adapters/midjourney.md:41-41 (table_row)

| `push` | `dolly in, pushing forward` |

Extracted rules inside block: NONE

## dccc43dc6726c56e — visual-prompt-forge/adapters/midjourney.md:42-42 (table_row)

| `handheld` | `handheld documentary feel, slight motion blur` |

Extracted rules inside block: NONE

## b922cf7a85dc245c — visual-prompt-forge/adapters/midjourney.md:43-43 (table_row)

| `shallow DOF` | `shallow depth of field, f/1.8, bokeh background` |

Extracted rules inside block: fbaaf26aa19d

## cbbdb4a278477182 — visual-prompt-forge/adapters/midjourney.md:44-44 (table_row)

| `deep DOF` | `deep focus, everything sharp, f/8` |

Extracted rules inside block: NONE

## 4abc9e9343263289 — visual-prompt-forge/adapters/midjourney.md:46-46 (heading)

## Lighting language

Extracted rules inside block: NONE

## 442b2d1543ed8c55 — visual-prompt-forge/adapters/midjourney.md:48-48 (paragraph)

Midjourney rewards specific lighting vocabulary:

Extracted rules inside block: NONE

## 70ac899f5f9c61fd — visual-prompt-forge/adapters/midjourney.md:50-50 (list_item)

- `soft natural light, large window left, warm afternoon golden hour`

Extracted rules inside block: NONE

## 82fad1a0ab6125a9 — visual-prompt-forge/adapters/midjourney.md:51-51 (list_item)

- `hard top-light, single key, deep shadows, studio black backdrop`

Extracted rules inside block: NONE

## 9254e35f9fa5c1a1 — visual-prompt-forge/adapters/midjourney.md:52-52 (list_item)

- `practical mixed sources, neon accents, urban night, atmospheric haze`

Extracted rules inside block: NONE

## dc0c3efebc079492 — visual-prompt-forge/adapters/midjourney.md:53-53 (list_item)

- `volumetric backlight, rim light separating subject, cinematic haze`

Extracted rules inside block: NONE

## 00a8b42a30b02fa7 — visual-prompt-forge/adapters/midjourney.md:54-54 (list_item)

- `chiaroscuro, dramatic side-light, painterly`

Extracted rules inside block: NONE
