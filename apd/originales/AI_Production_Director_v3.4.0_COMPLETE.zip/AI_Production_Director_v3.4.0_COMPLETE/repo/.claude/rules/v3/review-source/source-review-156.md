# Source coverage review 156/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 008da9cf9b054894 — video/references/kling.md:261-261 (heading)

## 11. Failure modes and fixes

Extracted rules inside block: NONE

## 920b5e07ec0f39e3 — video/references/kling.md:263-263 (heading)

### Random camera drift in static scenes

Extracted rules inside block: NONE

## 285548c1bd28c822 — video/references/kling.md:265-265 (paragraph)

Fix. Say "locked static frame" or "camera fixed, no movement."

Extracted rules inside block: NONE

## 93d4286bd1025f1f — video/references/kling.md:267-267 (heading)

### Prompt exceeds model capacity, output melts

Extracted rules inside block: NONE

## 43cace22835d5499 — video/references/kling.md:269-269 (paragraph)

Fix. Cut to model-appropriate element count. 3-4 for Turbo, 5-7 for 2.6 Pro.

Extracted rules inside block: NONE

## f1ded4cf056eb6bb — video/references/kling.md:271-271 (heading)

### Character face changes between generations

Extracted rules inside block: NONE

## 43f2a76c1f829aca — video/references/kling.md:273-273 (paragraph)

Fix. Upload 3-4 reference images to Element Library. Use Bind Elements in the settings.

Extracted rules inside block: feb4558901d3

## 4cbe8fbfffbad114 — video/references/kling.md:275-275 (heading)

### Negative prompts ignored

Extracted rules inside block: NONE

## 233e1413d1a313a1 — video/references/kling.md:277-277 (paragraph)

Fix. Rewrite "no X" as "X" in the negative field.

Extracted rules inside block: NONE

## a69ef04ffad908d8 — video/references/kling.md:279-279 (heading)

### Motion Brush artifact

Extracted rules inside block: NONE

## acd740de207221c4 — video/references/kling.md:281-281 (paragraph)

Fix. Check that the text prompt verbs match the brush direction. Rewrite the text if it contradicts the motion.

Extracted rules inside block: NONE

## 6ef9dedf29756c42 — video/references/kling.md:283-283 (heading)

### Element overload melts hands

Extracted rules inside block: NONE

## 0e7e4d34e586dd81 — video/references/kling.md:285-285 (paragraph)

Fix. Simplify. Combine elements where possible. Cut secondary descriptions.

Extracted rules inside block: NONE

## 8e3a03abe75022f2 — video/references/kling.md:287-287 (heading)

### Kling 3.0 collapses multi-shot into one continuous take

Extracted rules inside block: NONE

## c70a5f6d5d4e6660 — video/references/kling.md:289-289 (paragraph)

Fix. Make shot boundaries explicit: `Shot 1 (0-3s). ... Shot 2 (3-6s). ...`. Each shot description must include a different framing or camera angle. If two adjacent shots share both framing and angle, the model merges them.

Extracted rules inside block: e62d80df363f

## 5439dac9965a255a — video/references/kling.md:291-291 (heading)

### Kling 3.0 dialogue lip-sync drifts

Extracted rules inside block: NONE

## baf0c1ae9938e00e — video/references/kling.md:293-293 (paragraph)

Fix. Apply P2 — bind dialogue to a unique visual action ("Character A pulls a folded note from his pocket and reads aloud:") before the line itself. Then add P4 linking words ("Immediately,") between consecutive lines.

Extracted rules inside block: NONE

## c1d88caa8d7eb5e9 — video/references/kling.md:295-295 (heading)

### Kling 3.0 picks the wrong voice

Extracted rules inside block: NONE

## ff35bfe83a1873a1 — video/references/kling.md:297-297 (paragraph)

Fix. Apply P3 — put voice tone inside the speaker tag: `[Character A, raspy deep voice]:`. Generic `[Man]:` / `[Woman]:` tags get a generic voice.

Extracted rules inside block: NONE

## d671f63b729901a1 — video/references/kling.md:299-299 (heading)

### Image quality drops when Elements / references are enabled

Extracted rules inside block: NONE

## b8659d68114bee48 — video/references/kling.md:301-301 (paragraph)

Fix. Strip references to the essential ones only; for one-off clips prefer in-prompt `[Character A: ...]` labels over elements. Accept the trade: elements buy consistency, not fidelity.

Extracted rules inside block: 5246d3fbbd11

## c6c59b425f39ac8d — video/references/kling.md:303-303 (heading)

### Two similar characters blend features in one frame

Extracted rules inside block: NONE

## 8eb31af9443e1fc2 — video/references/kling.md:305-305 (paragraph)

Fix. Give each character its own element (or its own labeled identity block). Never let two speaking characters share one visual description.

Extracted rules inside block: 3107230d8125

## 1878e8f8394f1c17 — video/references/kling.md:307-307 (heading)

### Morphing artifacts on fast motion

Extracted rules inside block: NONE

## 78214ffb0b68316f — video/references/kling.md:309-309 (paragraph)

Fix. Generate the action in slow motion and speed it up in post — the model holds geometry at slower internal motion.

Extracted rules inside block: NONE

## f75229c0c0a82025 — video/references/kling.md:311-311 (heading)

### Music appears even though the prompt says "no music"

Extracted rules inside block: NONE

## 1a79f431c2b3401d — video/references/kling.md:313-313 (paragraph)

Fix. Negative-prompting music is unreliable. Generate with `generate_audio` off and add sound in post, or strip the music track.

Extracted rules inside block: NONE

## 122eb73e30b83c29 — video/references/kling.md:315-315 (heading)

## 12. Skeleton

Extracted rules inside block: NONE

## b0486d92afcdcbdc — video/references/kling.md:317-317 (heading)

### Text-to-video (1.x – 2.x)

Extracted rules inside block: NONE

## a833939f19e21c97 — video/references/kling.md:319-323 (code)

```text
[Subject with identity anchor]. [Subject movement in one clean verb phrase]. Scene. [3-5 environment elements]. Camera. [one movement + lens]. Lighting. [source + quality]. Atmosphere. [mood].

Negative field. blurry, distorted hands, extra fingers, melted face, watermark, subtitles, jitter.
```

Extracted rules inside block: NONE
