# Source coverage review 118/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 60777b300843f6b1 — storyboard-architect/tools/README.md:22-22 (paragraph)

This is exactly what CI runs, so a green local run means a green PR.

Extracted rules inside block: NONE

## 1b916364e9c684a5 — storyboard-architect/tools/README.md:24-26 (paragraph)

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

Extracted rules inside block: NONE

## 0d7f9ab7091a0f4e — storyboard-architect/tools/README.md:28-28 (heading)

## Repo checks

Extracted rules inside block: NONE

## e2f85074a85c61d7 — storyboard-architect/tools/README.md:30-30 (heading)

### `validate_skills.py`

Extracted rules inside block: NONE

## 754e37c02ab009f3 — storyboard-architect/tools/README.md:32-33 (paragraph)

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

Extracted rules inside block: 256d07b42523

## 643dfb95f28bea50 — storyboard-architect/tools/README.md:35-37 (code)

```bash
python tools/validate_skills.py
```

Extracted rules inside block: NONE

## 73f8445e948dd079 — storyboard-architect/tools/README.md:39-39 (heading)

### `validate_schemas.py`

Extracted rules inside block: NONE

## 5f3545b61d16b745 — storyboard-architect/tools/README.md:41-42 (paragraph)

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

Extracted rules inside block: NONE

## 532e0fb1b63c7e69 — storyboard-architect/tools/README.md:44-46 (code)

```bash
python tools/validate_schemas.py
```

Extracted rules inside block: NONE

## 382c7a193d457611 — storyboard-architect/tools/README.md:48-48 (paragraph)

It validates schemas, not instances. For instances, see `validate_shots.py`.

Extracted rules inside block: NONE

## 9b4ffc3c6d92137c — storyboard-architect/tools/README.md:50-50 (heading)

### `validate_capabilities.py`

Extracted rules inside block: NONE

## de3c955660c1e7f1 — storyboard-architect/tools/README.md:52-54 (paragraph)

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

Extracted rules inside block: NONE

## a965f5eab693a0d6 — storyboard-architect/tools/README.md:56-56 (list_item)

- every generator id has an adapter `.md` and every adapter `.md` has an entry

Extracted rules inside block: NONE

## 7dbfad8f9f550ff2 — storyboard-architect/tools/README.md:57-57 (list_item)

- no adapter advertises more words than its own `max_prompt_words` ceiling

Extracted rules inside block: NONE

## 0473c37c679bdd1f — storyboard-architect/tools/README.md:58-58 (list_item)

- every adapter documents the `aspect_param` the matrix says to send

Extracted rules inside block: NONE

## 500b3080505f2a3b — storyboard-architect/tools/README.md:59-59 (list_item)

- no `notes` field cites a word count above its own ceiling

Extracted rules inside block: NONE

## 1fb3c4d41404a0c0 — storyboard-architect/tools/README.md:60-60 (list_item)

- warns when the matrix or an entry is past its 120-day freshness window

Extracted rules inside block: NONE

## ac40ca23f94b61ef — storyboard-architect/tools/README.md:62-65 (code)

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

Extracted rules inside block: NONE

## 4497c7f6f0ca41ed — storyboard-architect/tools/README.md:67-68 (paragraph)

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

Extracted rules inside block: NONE

## af03b660448dc01b — storyboard-architect/tools/README.md:70-70 (heading)

### `validate_brand_lock.py`

Extracted rules inside block: NONE

## 25079a55eeecd9a0 — storyboard-architect/tools/README.md:72-74 (paragraph)

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

Extracted rules inside block: 40f5953dc4b3

## c9f8b8b7c2f1ea88 — storyboard-architect/tools/README.md:76-82 (code)

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

Extracted rules inside block: NONE

## 552130d9463c52ff — storyboard-architect/tools/README.md:84-86 (paragraph)

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

Extracted rules inside block: 58b8442891b7

## 9668dde23a7f0652 — storyboard-architect/tools/README.md:88-88 (heading)

## Project checks

Extracted rules inside block: NONE

## 2cb18228dce3e286 — storyboard-architect/tools/README.md:90-90 (paragraph)

These run against a project's output directory, not the repo.

Extracted rules inside block: NONE

## fce7f7c1e7f40cfb — storyboard-architect/tools/README.md:92-92 (heading)

### `validate_shots.py`

Extracted rules inside block: NONE

## 1928ebf5bd6e516a — storyboard-architect/tools/README.md:94-98 (paragraph)

Validates `shots.json` and `text-overlays.json` as instances, plus every cross-field and
cross-file rule JSON Schema cannot express: `end` after `start`, no gaps or overlaps, span
matching `project.duration_s`, overlay references resolving in both directions, every overlay
reachable from some shot, overlay timing inside its shot window, and every overlay color
present in the brand-lock palette.

Extracted rules inside block: NONE

## 9e66f11fde0b0b74 — storyboard-architect/tools/README.md:100-105 (code)

```bash
python tools/validate_shots.py output/
python tools/validate_shots.py path/to/shots.json
python tools/validate_shots.py --examples     # every bundled example
python tools/validate_shots.py --selftest
```

Extracted rules inside block: NONE

## b3034756134b45ba — storyboard-architect/tools/README.md:107-108 (paragraph)

Warnings cover the judgement calls: overlay copy repeated in a shot subject, a raw hex in a
subject, shot ids out of chronological order, a font the brand-lock does not declare.

Extracted rules inside block: NONE

## a10d9a0e5b3d6590 — storyboard-architect/tools/README.md:110-110 (heading)

### `validate_prompts.py`

Extracted rules inside block: NONE
