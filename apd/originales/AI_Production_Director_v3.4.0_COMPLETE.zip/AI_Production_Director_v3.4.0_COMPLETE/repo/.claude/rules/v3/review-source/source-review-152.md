# Source coverage review 152/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## d138e2eb44489986 — video/references/kling.md:30-30 (list_item)

- **Kling 1.6.** Simplified prompts. Keep it very simple.

Extracted rules inside block: NONE

## 72798f8bb1db1f92 — video/references/kling.md:31-31 (list_item)

- **Kling 2.1 Pro.** 1080p at 30fps. Motion Brush. End frame control.

Extracted rules inside block: NONE

## 4300aa7fe822b036 — video/references/kling.md:32-32 (list_item)

- **Kling 2.5 Turbo Pro.** Maximum 3-4 distinct elements.

Extracted rules inside block: NONE

## 29cfc96bca769798 — video/references/kling.md:33-33 (list_item)

- **Kling 2.6 Pro.** 5-7 elements. Motion Control. Element Binding for character consistency.

Extracted rules inside block: NONE

## 80807ba668387976 — video/references/kling.md:34-34 (list_item)

- **Kling 3.0.** Multi-shot in one generation (up to 6 shots). Native audio with dialogue and lip-sync. 15s continuous output. Native 4K, up to 60 fps. Strongest character and scene consistency. Two tiers: v3/pro and v3/standard.

Extracted rules inside block: NONE

## 22dc1091e23d7335 — video/references/kling.md:35-35 (list_item)

- **Kling 3.0 Turbo** (June 2026). Speed/price tier: audio included in base cost, noticeably better lip-sync on talking heads, 3-15s, but capped at 1080p — no 4K.

Extracted rules inside block: NONE

## 175b2042b1430b12 — video/references/kling.md:36-36 (list_item)

- **Kling 3.0 Omni** (June 2026). The reference-and-editing flagship (API alias `o3`): strongest input understanding, editing pipeline at 3-15s with 4K in/out, Elements 3.0 with voice binding (see section 7).

Extracted rules inside block: NONE

## 92294dd714a1da4e — video/references/kling.md:38-38 (paragraph)

If in doubt about the user's version, ask. The prompting protocol differs between 1.x – 2.x (sections 4-9) and 3.0 (section 3).

Extracted rules inside block: NONE

## 8fe9cd680c09a527 — video/references/kling.md:40-40 (heading)

## 3. Kling 3.0 — multi-shot, native audio, 15s

Extracted rules inside block: NONE

## 5e50cdea093e055e — video/references/kling.md:42-42 (paragraph)

Kling 3.0 is a different beast. It understands cinematic intent, not just visual descriptions. Prompts read like scene directions, not object lists.

Extracted rules inside block: NONE

## ce92eb92d0798f67 — video/references/kling.md:44-44 (heading)

### What changed vs 2.x

Extracted rules inside block: NONE

## 05e0b18464a289f6 — video/references/kling.md:46-46 (table_row)

| Capability | 1.x – 2.6 | **3.0** |

Extracted rules inside block: NONE

## 81e4814df30a25c1 — video/references/kling.md:48-48 (table_row)

| Multi-shot in one generation | No (one continuous take) | **Yes — up to 6 shots** |

Extracted rules inside block: NONE

## 80eabf64e2c4180c — video/references/kling.md:49-49 (table_row)

| Native audio | Limited / off | **Yes — dialogue, ambient, voice tone** |

Extracted rules inside block: NONE

## 6aafad48e224a250 — video/references/kling.md:50-50 (table_row)

| Lip-sync | No | **Yes — coherent across multi-character scenes** |

Extracted rules inside block: NONE

## 3a87a47f49eb9e21 — video/references/kling.md:51-51 (table_row)

| Max duration | 5-10s | **Up to 15s** |

Extracted rules inside block: NONE

## ebd82ff7dce03d93 — video/references/kling.md:52-52 (table_row)

| Character labeling | Via Element Library + reference images | **Via in-prompt `[Character A: ...]` tags** (still supports references) |

Extracted rules inside block: NONE

## 5d047cf4581687b2 — video/references/kling.md:53-53 (table_row)

| Cinematic language understanding | Partial | **Full — reads "shot-reverse-shot", "POV", "tracking shot", "macro close-up"** |

Extracted rules inside block: NONE

## b49305cca5cbff6b — video/references/kling.md:55-55 (heading)

### Five-layer prompt structure

Extracted rules inside block: NONE

## 6f52491e8e0c81ad — video/references/kling.md:57-59 (code)

```text
Scene  →  Characters  →  Action  →  Camera  →  Audio
```

Extracted rules inside block: NONE

## 4dbfcb27e13c4a6b — video/references/kling.md:61-61 (paragraph)

Write each layer as flowing prose with explicit labels.

Extracted rules inside block: NONE

## 25d8d3544b9f2a88 — video/references/kling.md:63-63 (heading)

### Anchor subjects early

Extracted rules inside block: NONE

## c6cae6886050a436 — video/references/kling.md:65-65 (paragraph)

Introduce every character and key object at the **start** of the prompt, before any shot description. Use unique consistent identifiers — the same label survives across all shots:

Extracted rules inside block: 1c3c2fb77a4f

## 8b2f8b6ff0f68e63 — video/references/kling.md:67-70 (code)

```text
[Character A: Exhausted Partner — late 40s, gray-streaked beard, navy peacoat, hollow eyes]
[Character B: Female Investor — early 30s, sharp blazer, calm posture]
```

Extracted rules inside block: NONE

## 22cf94f634fd6376 — video/references/kling.md:72-72 (paragraph)

Then refer to them as "Character A" / "Character B" inside shot descriptions. This locks identity better than re-describing the character each shot.

Extracted rules inside block: NONE

## ae813a644181bcb9 — video/references/kling.md:74-74 (heading)

### Multi-shot syntax (think in shots, not clips)

Extracted rules inside block: NONE

## 86ce0798d11491ba — video/references/kling.md:76-91 (code)

```text
[Character A: ...]
[Character B: ...]

Master intent: tense negotiation in a glass-walled office at dusk.

Shot 1 (0-3s). Wide tracking shot. Character A enters frame from left, crosses to the table.
Shot 2 (3-6s). Profile close-up on Character A. He sets down a brown leather folder.
Shot 3 (6-9s). Shot-reverse-shot. Cut to Character B's face. She does not blink.
Shot 4 (9-12s). Macro insert on her hand tightening around a fountain pen.
Shot 5 (12-15s). Two-shot, low angle, both reflected in the glass wall behind them.

Camera. Slow, deliberate. Sony FX6 feel, 35mm and 85mm.
Lighting. Cold blue dusk through floor-to-ceiling windows. Single amber desk lamp.
Audio. Distant city ambience. No music. Footsteps on hardwood. Pen clicks on paper.
```

Extracted rules inside block: NONE

## 63e7775ba15eb9b6 — video/references/kling.md:93-93 (paragraph)

Each shot must answer: **framing + subject + motion**. Empty shot descriptions ("static frame, ambient mood") collapse into one continuous take.

Extracted rules inside block: 0e275d7305d2

## 6f210dec4cfebdcd — video/references/kling.md:95-95 (heading)

### Dialogue protocol (P1-P4)

Extracted rules inside block: NONE

## 849f3683573320e5 — video/references/kling.md:97-97 (paragraph)

For any speaking scene, follow these four rules. The fal.ai guide calls them P1, P2, P3, P4.

Extracted rules inside block: NONE
