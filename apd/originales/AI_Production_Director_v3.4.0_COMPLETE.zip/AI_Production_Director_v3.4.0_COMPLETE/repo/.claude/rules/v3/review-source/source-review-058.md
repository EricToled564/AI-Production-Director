# Source coverage review 58/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 4a3a3716bc36be4b — image/references/patterns/food-beverage.md:11-11 (paragraph)

<!-- Source concept: luxury chocolate brand campaign with variant moods and tactile surfaces -->

Extracted rules inside block: NONE

## 336a3ad9bb698173 — image/references/patterns/food-beverage.md:13-22 (code)

```
Scene: {surface_material} surface, {lighting_mood} lighting setup — {light_description}, thin atmospheric haze at background edge, color palette restricted to {palette}
Subject: {product_arrangement} — {product_count} pieces of {chocolate_type} arranged in {arrangement_style}
Important Details: visible snap edge on broken piece revealing {interior_texture}, fine cocoa powder dusted across surface (concentrated near product, fading to clean edges), {garnish_elements} placed deliberately as art direction not garnish, one piece mid-break with clean fracture line, surface texture of chocolate shows {surface_quality}, camera angle {camera_angle}, shallow depth of field with sharpest focus on the broken piece
Use Case: luxury chocolate brand campaign, print ad, packaging insert
Constraints: no human hands, no utensils, no wrappers or packaging visible, no text, cocoa dust must look natural not dumped, maximum {product_count} chocolate pieces, no melting

Mood variant — {mood_name}:
{mood_modifier}
```

Extracted rules inside block: NONE

## 18eb7b0e9b0a2a4f — image/references/patterns/food-beverage.md:24-24 (paragraph)

**Key levers:**

Extracted rules inside block: NONE

## 5ae2aa5869212537 — image/references/patterns/food-beverage.md:25-25 (list_item)

- `{surface_material}` — dark slate, raw walnut wood, black marble, crumpled kraft paper

Extracted rules inside block: NONE

## 58e56b4b35224720 — image/references/patterns/food-beverage.md:26-26 (list_item)

- `{lighting_mood}` — dramatic chiaroscuro / soft diffused warmth / cold window light

Extracted rules inside block: NONE

## 46045c7938f9ebd0 — image/references/patterns/food-beverage.md:27-27 (list_item)

- `{light_description}` — single hard key from upper left / wrap-around softbox / backlit through parchment

Extracted rules inside block: NONE

## 8dd831be2bcf9667 — image/references/patterns/food-beverage.md:28-28 (list_item)

- `{palette}` — deep browns #3E2723 + gold #C9A84C + black / warm terracotta #A0522D + cream #FFF8E7 / emerald #2D6A4F + copper #B87333

Extracted rules inside block: NONE

## 7332633f14d980f3 — image/references/patterns/food-beverage.md:29-29 (list_item)

- `{chocolate_type}` — single-origin dark 72%, white chocolate with matcha veins, ruby chocolate

Extracted rules inside block: NONE

## 9c9dc4324e0748bb — image/references/patterns/food-beverage.md:30-30 (list_item)

- `{interior_texture}` — smooth ganache center, crunchy praline layers, salted caramel pocket

Extracted rules inside block: NONE

## 02c98e54bb0e9e29 — image/references/patterns/food-beverage.md:31-31 (list_item)

- `{garnish_elements}` — single vanilla pod, fleur de sel crystals, edible gold leaf fragments, dried raspberry

Extracted rules inside block: NONE

## 7a3403ca59af6272 — image/references/patterns/food-beverage.md:32-32 (list_item)

- `{arrangement_style}` — diagonal cascade, tight cluster with negative space right, single row

Extracted rules inside block: NONE

## c73be1f15de1dce3 — image/references/patterns/food-beverage.md:33-33 (list_item)

- `{mood_name} / {mood_modifier}` — "Dark Indulgence": push contrast, deepen shadows, add smoke wisp / "Bright Artisan": overcast daylight, lifted blacks, pastel accent / "Origin Story": raw earth tones, burlap texture, raw cacao beans nearby

Extracted rules inside block: NONE

## f590cc084a0ff64c — image/references/patterns/food-beverage.md:35-35 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — fracture detail and cocoa powder precision

Extracted rules inside block: e8120db21d43

## 648b32c44e301759 — image/references/patterns/food-beverage.md:39-39 (heading)

## High-Fashion Beverage Campaign Board

Extracted rules inside block: NONE

## 9de8547d6c93d226 — image/references/patterns/food-beverage.md:41-41 (paragraph)

Use for premium beverage brand campaigns that combine lifestyle and product in a structured board layout — model shot + hero product + product lineup.

Extracted rules inside block: 71b72a41365f

## cdc6478771014f31 — image/references/patterns/food-beverage.md:43-43 (paragraph)

<!-- Source concept: fashion-meets-beverage campaign board with model, hero product, and lineup -->

Extracted rules inside block: NONE

## 16ee7399e3859d45 — image/references/patterns/food-beverage.md:45-55 (code)

```
Scene: horizontal triptych layout on single canvas — left panel (45% width), center panel (30%), right panel (25%), thin {divider_color} dividers (2px), unified {color_temperature} color temperature
Subject: {beverage_brand} campaign board featuring {model_description} and {product_name}
Important Details:
  Left panel (lifestyle): {model_description} at {location}, holding {product_name} at {hold_position}, {model_action}, shot on {film_aesthetic} — environment tells the brand story
  Center panel (hero): {product_name} bottle/can beauty shot, {product_angle} angle, {product_surface} surface, single key light with {highlight_style}, condensation droplets on glass/can surface, label sharp and legible
  Right panel (lineup): {lineup_count} product variants arranged in a {lineup_arrangement}, same lighting as center panel but pulled back wider, each label variant distinguishable by color ({variant_colors})
  Typography: none in image
Use Case: brand campaign presentation, pitch deck, retail POS
Constraints: model does not look directly at product (natural interaction), product label consistent and legible in all panels, lighting temperature cohesive, no floating elements, condensation looks physical not painted on
```

Extracted rules inside block: NONE

## 66fce9155127197b — image/references/patterns/food-beverage.md:57-57 (paragraph)

**Key levers:** `{product_name}`, `{beverage_brand}`, `{model_description}`, `{location}` (sunlit rooftop bar, marble kitchen counter, poolside), `{hold_position}` (mid-sip, resting at hip, gesturing with it), `{model_action}` (laughing mid-conversation, looking off-frame, walking), `{film_aesthetic}` (warm Kodak Portra feel, clean digital, cold editorial), `{product_angle}` (three-quarter front, straight-on, slight low angle), `{product_surface}` (wet dark stone, frosted glass shelf, white marble), `{lineup_count}` (3-5), `{variant_colors}` (amber/ruby/gold, mint/lemon/berry), `{divider_color}` (#FFFFFF, #1A1A1A)

Extracted rules inside block: NONE

## 69554790a36bb0e9 — image/references/patterns/food-beverage.md:59-59 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — label legibility and panel consistency

Extracted rules inside block: bc7f26c122f1

## 6c71b9bf438ab833 — image/references/patterns/food-beverage.md:63-63 (heading)

## Hyper-Realistic Food Poster Template

Extracted rules inside block: NONE

## 750110c98b2006c1 — image/references/patterns/food-beverage.md:65-65 (paragraph)

Use for hero food posters — restaurants, delivery apps, menu boards — where the food is the entire composition with fillable content slots.

Extracted rules inside block: 4b631215c9f7

## 5be591f5e5b37960 — image/references/patterns/food-beverage.md:67-67 (paragraph)

<!-- Source concept: hyper-realistic food poster with controlled composition slots -->

Extracted rules inside block: NONE

## 50355c72a0305161 — image/references/patterns/food-beverage.md:69-82 (code)

```
Scene: {background_treatment}, {atmosphere_effect}, overall tone {color_tone}
Subject: {dish_name} — {dish_description}, plated on {plate_description}, centered in frame
Important Details:
  Plating: {plating_details}
  Steam/moisture: {steam_detail}
  Garnish: {garnish_detail} placed at {garnish_position}
  Surface: {table_surface}, visible texture extending to frame edges
  Props: {prop_list} — arranged {prop_arrangement}
  Camera: overhead ({overhead_angle}) OR {camera_angle}, {lens_feel}
  Lighting: {food_lighting} — highlights on {highlight_targets}
Use Case: restaurant poster, delivery app hero, menu board, food magazine cover
Constraints: food must look freshly prepared (not cold or sat-out), no human hands or utensils in active use (props only), colors must be appetizing — no blue cast, no desaturated tones on the food itself, {plate_description} must not compete with the dish
```

Extracted rules inside block: NONE

## 151198c29a3dc287 — image/references/patterns/food-beverage.md:84-84 (paragraph)

**Key levers:**

Extracted rules inside block: NONE

## 9f27ce8ed9f52047 — image/references/patterns/food-beverage.md:85-85 (list_item)

- `{dish_name}` / `{dish_description}` — the hero food item described in appetizing physical detail

Extracted rules inside block: NONE

## e52f0911972a7d86 — image/references/patterns/food-beverage.md:86-86 (list_item)

- `{plate_description}` — matte white ceramic, dark stoneware, rustic wooden board, banana leaf

Extracted rules inside block: NONE

## cc107cb04d782486 — image/references/patterns/food-beverage.md:87-87 (list_item)

- `{plating_details}` — sauce swoosh from 2 o'clock, microgreens at 10 o'clock, sesame seed scatter

Extracted rules inside block: NONE

## c01a6fc0dbb62778 — image/references/patterns/food-beverage.md:88-88 (list_item)

- `{steam_detail}` — visible steam wisps rising from center, condensation on glass nearby, no steam

Extracted rules inside block: NONE

## c6a93da0d465d46d — image/references/patterns/food-beverage.md:89-89 (list_item)

- `{garnish_detail}` — single basil sprig, chili flake scatter, citrus zest curls

Extracted rules inside block: NONE

## 27ed49635a043bf5 — image/references/patterns/food-beverage.md:90-90 (list_item)

- `{table_surface}` — aged oak, dark concrete, white marble with gray veins

Extracted rules inside block: NONE
