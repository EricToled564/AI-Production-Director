# Source coverage review 120/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 849ded288bdb7dd5 — storyboard-architect/tools/README.md:212-217 (code)

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Extracted rules inside block: NONE

## bc11e4a06a66a579 — storyboard-architect/tools/README.md:219-222 (paragraph)

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Extracted rules inside block: 4104bcbb2f4c

## 14c8348d6ecf73aa — storyboard-architect/tools/README.md:224-224 (paragraph)

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

Extracted rules inside block: NONE

## 30b4810d5b45ccb7 — storyboard-architect/tools/README.md:226-226 (heading)

## Internal modules

Extracted rules inside block: NONE

## d5d61cd4b651e440 — storyboard-architect/tools/README.md:228-228 (paragraph)

Not entry points. Imported by the tools above.

Extracted rules inside block: NONE

## 9f3f637fd678f8de — storyboard-architect/tools/README.md:230-231 (list_item)

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.

Extracted rules inside block: NONE

## ec0822a62497614e — storyboard-architect/tools/README.md:232-233 (list_item)

- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

Extracted rules inside block: NONE

## 961831aafbf5cb5e — storyboard-architect/tools/README.md:235-235 (heading)

## Adding new tools

Extracted rules inside block: NONE

## 40d07e546e502dad — storyboard-architect/tools/README.md:237-237 (list_item)

- Make it executable (`chmod +x`)

Extracted rules inside block: NONE

## 1905d04a404ef86e — storyboard-architect/tools/README.md:238-238 (list_item)

- Add a usage docstring at the top of the file

Extracted rules inside block: NONE

## 5c1da6dbb1bd006c — storyboard-architect/tools/README.md:239-239 (list_item)

- Give it a `--selftest` that proves the check fires

Extracted rules inside block: NONE

## 4d3c0013202bcaea — storyboard-architect/tools/README.md:240-240 (list_item)

- Document it in this README

Extracted rules inside block: NONE

## ba9527ce3665dc69 — storyboard-architect/tools/README.md:241-241 (list_item)

- Wire it into `tools/check.sh`, which is what CI calls

Extracted rules inside block: NONE

## 73c9481a83b9cbb2 — storyboard-architect/tools/README.md:243-243 (paragraph)

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

Extracted rules inside block: NONE

## 41d63da4f36d9ace — storyboard-html-preview/SKILL.md:2-3 (paragraph)

name: storyboard-html-preview
description: Render a structured storyboard (storyboard.md, shots.json, text-overlays.json, brand-lock.snapshot.md) into a single-file HTML preview that is shareable, printable, and offline. Use when the user wants to share a storyboard, export for review, hand off to an editor, or print a hard copy. Triggers on "preview the storyboard", "share this", "export to HTML", "print version", or after a storyboard-architect run. Produces one self-contained .html file with no build or server.

Extracted rules inside block: NONE

## c4f66531d13e0de0 — storyboard-html-preview/SKILL.md:6-6 (heading)

# Storyboard HTML Preview

Extracted rules inside block: NONE

## fe74bb51f0f12ac7 — storyboard-html-preview/SKILL.md:8-8 (paragraph)

You are turning structured storyboard files into a single shareable HTML document. The output is what an editor, stakeholder, or client opens in a browser without thinking about it.

Extracted rules inside block: NONE

## 7d4e276ddafeadaa — storyboard-html-preview/SKILL.md:10-10 (paragraph)

The constraint is non-negotiable: **single file, no build step, no server, works offline.** Any time the output requires "run this build command" or "host this somewhere," the skill has failed.

Extracted rules inside block: 55f54d1a98b7

## 78cfd76ea9d897ab — storyboard-html-preview/SKILL.md:12-12 (heading)

## When to use

Extracted rules inside block: NONE

## eedfb8e5acc1b3e6 — storyboard-html-preview/SKILL.md:14-14 (paragraph)

Trigger when the user:

Extracted rules inside block: NONE

## f27df18cf2f0faf0 — storyboard-html-preview/SKILL.md:16-16 (list_item)

- Asks to preview, share, or export a storyboard

Extracted rules inside block: NONE

## 1929fdf6d9a422f6 — storyboard-html-preview/SKILL.md:17-17 (list_item)

- Wants a printable version

Extracted rules inside block: NONE

## ecd52c2ebe931ffc — storyboard-html-preview/SKILL.md:18-18 (list_item)

- Says "what's the next step" after a storyboard-architect run

Extracted rules inside block: NONE

## 3f5805eec1359df2 — storyboard-html-preview/SKILL.md:19-19 (list_item)

- Hands off `storyboard.md` + `shots.json` + asks for a deliverable for review

Extracted rules inside block: NONE

## ad89ab93953d4a72 — storyboard-html-preview/SKILL.md:21-21 (heading)

## What you produce

Extracted rules inside block: NONE

## 627b1d3f6b2d40dc — storyboard-html-preview/SKILL.md:23-23 (paragraph)

One file: `preview.html`. Self-contained. Inline CSS. No JavaScript dependencies (vanilla JS only, embedded). No external font files (uses system stack with brand-font fallbacks). No external images (placeholder slots; if generated images exist, embed as base64 OR reference relative paths).

Extracted rules inside block: NONE

## a8f780072bf02571 — storyboard-html-preview/SKILL.md:25-35 (code)

```
output/
├── run.json                   # input, for the run id and date
├── storyboard.md              # input
├── shots.json                 # input
├── text-overlays.json         # input
├── brand-lock.snapshot.md     # input
├── frames/round-N/            # input, if generation has happened
├── critiques/round-N/         # input, for the verdict badges
└── preview.html               # ← what this skill produces
```

Extracted rules inside block: NONE

## 67d702c3b98ba029 — storyboard-html-preview/SKILL.md:37-38 (paragraph)

If the user has generated frames, the HTML references them via relative paths so the file
works when the whole `output/` folder is shared. Resolve a shot's frame in this order:

Extracted rules inside block: NONE

## 399dfb93fa20c943 — storyboard-html-preview/SKILL.md:40-40 (list_item)

1. An entry in `shot.assets.generated` marked `accepted: true`

Extracted rules inside block: 327875d54744

## 3087c614071dd1f0 — storyboard-html-preview/SKILL.md:41-41 (list_item)

2. The newest entry in `shot.assets.generated`

Extracted rules inside block: 5e57934ce372
