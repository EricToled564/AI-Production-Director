# Source coverage review 176/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 9fdf492aec61d64d — video/references/seedance.md:79-79 (heading)

## 5. Six-step prompt formula (quick scenes)

Extracted rules inside block: NONE

## 8a90be999795fe75 — video/references/seedance.md:81-81 (paragraph)

For single-shot 5s clips with one clear action.

Extracted rules inside block: NONE

## b306d96ce47d6017 — video/references/seedance.md:83-90 (code)

```text
Subject. [Who or what]
Motion. [Present-tense verb, one clear action]
Camera. [Movement + framing + lens]
Environment. [Where, props, atmosphere]
Lighting. [Direction + quality + color]
Style. [Realism level, genre reference]
```

Extracted rules inside block: NONE

## 3d2ec68856427fee — video/references/seedance.md:92-92 (paragraph)

Write in full sentences, not tags. Seedance prefers clear grammatical prose. For dramatic / multi-shot / character-locked work, **use the production-grade skeleton in section 6 instead.**

Extracted rules inside block: cd221d4a7a2d

## 900277ad2c67ec71 — video/references/seedance.md:94-94 (heading)

## 6. Production-grade skeleton (11 blocks)

Extracted rules inside block: NONE

## 5226b9f9b432b403 — video/references/seedance.md:96-96 (paragraph)

Use this for any dramatic piece, multi-shot ad, music-video segment, or character-locked clip. Each block answers a specific failure mode. Skipping a block reintroduces that failure.

Extracted rules inside block: fc9b30345bea

## 9bec6c32deb427c3 — video/references/seedance.md:98-150 (code)

```text
[1] Character lock.
    Use @img1 as the main character reference and preserve the exact same person
    across the whole clip: <face shape, eye color, hair, facial hair, build, distinctive
    features>. Dress him in <exact wardrobe>. No nudity. No glasses (unless reference).
    No extra characters.

[2] Length + genre + editing intent.
    Generate a <duration>-second multi-shot <genre> sequence with <fast / slow / staircase>
    dynamic editing.

[3] Story (one paragraph).
    <Concrete physical events of this clip in present tense. What changes from start to
    end. Name the break point.>

[4] Visual style.
    <Palette, contrast, grain, color temperature, what to avoid (e.g. "no warm yellow
    tones"). Texture cues — realistic skin, food detail, fabric, surfaces.>

[5] Camera style.
    <Camera body / look (e.g. Sony FX3 handheld). Lenses with purpose:
    35mm / 50mm for medium, 85mm for emotional close-ups, 100mm macro for inserts,
    24mm for wide silhouettes. Handheld micro-shake or static. Strict cuts between
    shots. No continuous take.>

[6] Editing style.
    <Hard cuts vs match cuts. Rhythmic escalation. Where the pause lands. Where the
    impact hits. The rhythmic staircase: long → shorter → shorter → pause → impact.>

[7] Audio.
    <Diegetic sounds in order: ambient, micro-actions, impact, silence moment, final
    cue. Examples: stomach growl, refrigerator hum, fork clink, wet thud, abrupt
    silence, distant city ambience. No dialogue / No subtitles / No on-screen text.>

[8] Shot-by-shot timeline.
    Shot 1, 0.0–X.X sec: <framing, lens, camera move, action, environment detail,
                           emotion translated into body>.
    Shot 2, X.X–Y.Y sec: <...>.
    ...
    (See section 7 for the 5-second rhythm template.)

[9] Lighting (recap and specifics).
    <Main source, fill, rim. Direction. Color temperature. What it carries
    psychologically — judgment, isolation, hope, grief.>

[10] Composition.
    <Where the subject sits in frame across shots. Negative space. Reflections.
    Silhouettes. Foreground obstruction. The final image must be named.>

[11] Output specs.
    <Exact duration. Aspect ratio. Realism level. CLI: --resolution 1080p
    --duration 5 --camerafixed false>
```

Extracted rules inside block: NONE

## cd3b86e364647fa7 — video/references/seedance.md:152-152 (paragraph)

Why 11 blocks and not 6? Each block prevents one specific Seedance failure: identity drift, one-take collapse, mood smear, lens chaos, audio mismatch, drift on rhythm. Cheap insurance.

Extracted rules inside block: NONE

## a4a0b13f127bf615 — video/references/seedance.md:154-154 (heading)

## 7. The 5-second shot timeline (rhythm template)

Extracted rules inside block: NONE

## 7c38cb1a76cf5276 — video/references/seedance.md:156-156 (paragraph)

For a 5-second multi-shot clip, the model performs best with **5 shot beats** following a dramatic micro-arc. Use this timing as the default scaffold:

Extracted rules inside block: e456e980ac46

## 917f562acf35724d — video/references/seedance.md:158-164 (code)

```text
0.0–0.8 sec  | Establish     | extreme close-up or insert that anchors emotion / situation
0.8–1.6 sec  | Action        | medium shot, hero moves or reacts
1.6–2.5 sec  | Turn          | new framing reveals the shift (POV, OTS, rack focus)
2.5–3.6 sec  | Reaction      | tight close-up, slow push-in, emotion lands on the body
3.6–5.0 sec  | Climax / hero | hero shot, low angle, slow-mo if earned, final image
```

Extracted rules inside block: NONE

## b3b28d555c963de5 — video/references/seedance.md:166-166 (paragraph)

For 10s clips, double the structure or insert one pause before the climax (the pause beats speed). For 15s+ stories, split into 3 × 5s clips and stitch in the editor — Seedance is more reliable in shorter generations than one long take.

Extracted rules inside block: NONE

## 02d0afb60e787e5e — video/references/seedance.md:168-168 (heading)

## 8. Multi-shot syntax (unique)

Extracted rules inside block: NONE

## 9135be3b11317f98 — video/references/seedance.md:170-170 (paragraph)

Seedance reads explicit cut markers inside a single prompt and generates distinct shots connected by visible cuts. This is its strongest card. Use it when you need montage in a single generation.

Extracted rules inside block: 3fb00ad03dc3

## a880110f0f782a4e — video/references/seedance.md:172-172 (paragraph)

Supported cut markers.

Extracted rules inside block: NONE

## d5ae1bfced2fbc76 — video/references/seedance.md:174-180 (code)

```text
Shot 1. [description]
Cut to. [description]
Camera cut to. [description]
Camera switching. [description]
Lens switch to. [description]
```

Extracted rules inside block: NONE

## 64fe8c762ffae424 — video/references/seedance.md:182-182 (paragraph)

Inline timeline syntax.

Extracted rules inside block: NONE

## de7006e82ed1e301 — video/references/seedance.md:184-186 (code)

```text
[Shot A description] -> Cut to -> [Shot B description] -> Camera cut to -> [Shot C description]
```

Extracted rules inside block: NONE

## 6e7fdb56ce45c517 — video/references/seedance.md:188-188 (paragraph)

Example.

Extracted rules inside block: NONE

## b4c5ec855d500b81 — video/references/seedance.md:190-194 (code)

```text
Shot 1. Medium close-up on a tired man in a kitchen. He opens the refrigerator.
Cut to. Macro insert. His hand reaches toward a single sausage on an empty shelf.
Cut to. Over-the-shoulder shot. The fridge light paints his face cold blue.
```

Extracted rules inside block: NONE

## 274d5a3e5fc89376 — video/references/seedance.md:196-196 (paragraph)

Use 2-3 shots per 5-second clip for tight cinematic montage, 4-5 shot beats only when each beat is short and physically distinct (see section 7). Hard cap: 5 shots per generation — beyond that the model drops or compresses shots. Size the duration to the shot count (4 shots need 10-15s, not 5s). Every shot must share an anchor with its neighbors — same character, same location, or same lighting recipe — or the model produces disconnected clips instead of a sequence.

Extracted rules inside block: 9c897751e836

## 48263102d2bada26 — video/references/seedance.md:198-198 (heading)

## 9. Anti-mush guard block

Extracted rules inside block: NONE

## e32558c19f759aec — video/references/seedance.md:200-200 (paragraph)

Seedance sometimes ignores cuts and produces one continuous take, smears multiple shots into a single moving frame, or drifts character identity across the timeline. Drop this block at the **very top of the prompt** (before block [1]) when it happens or to prevent it pre-emptively on heavy multi-shot work:

Extracted rules inside block: NONE

## de9929d2259f685f — video/references/seedance.md:202-210 (code)

```text
Important direction:
This must be a clearly edited multi-shot sequence with visible cuts between shots.
Do not generate a single continuous take. Each shot must have a different camera angle
and different framing. Use rapid montage pacing with rhythmic escalation. Keep the same
character appearance throughout. Preserve the same clothing, face, body type, facial
hair, and hairstyle in every shot. The tone is <serious cinematic drama / tragicomedy /
documentary realism / etc.>.
```

Extracted rules inside block: NONE

## 27015b27924756da — video/references/seedance.md:212-212 (paragraph)

This is the highest-leverage paragraph in any Seedance prompt. Add it any time the model produced mush on a previous attempt.

Extracted rules inside block: NONE

## 9254b6a789f832e3 — video/references/seedance.md:214-214 (heading)

## 10. `@img1` character reference syntax

Extracted rules inside block: NONE

## 8ed5f4ce53292a80 — video/references/seedance.md:216-216 (paragraph)

Seedance 2.0 accepts image references inline using `@img1`, `@img2`, etc. Use this to lock the protagonist's likeness across all shots in a multi-shot clip and across multiple stitched clips.

Extracted rules inside block: cc8ac0bb38a3

## ccf73b490256b118 — video/references/seedance.md:218-222 (code)

```text
Use @img1 as the main character reference and preserve the exact same man across the
whole clip: <full identity block: face, eyes, hair, facial hair, build, distinctive
features, wardrobe>. No nudity. No glasses (unless in reference). No extra characters.
```

Extracted rules inside block: NONE

## bfb0c392cab67a39 — video/references/seedance.md:224-224 (paragraph)

Rules.

Extracted rules inside block: NONE

## ab46a16d8237f31a — video/references/seedance.md:226-226 (list_item)

- The full identity block must follow the `@img1` mention. The model needs the textual description as a backup signal — the image alone drifts.

Extracted rules inside block: 1934658fc90f
