# Source coverage review 37/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 28f1b9571b05584e — image/references/creative-direction.md:65-65 (list_item)

- "Fuji Velvia" — hyper-saturated, vivid

Extracted rules inside block: NONE

## 69509e4dae0f88cc — image/references/creative-direction.md:66-66 (list_item)

- "Ilford HP5" — classic B&W grain

Extracted rules inside block: NONE

## fe4cd472682df275 — image/references/creative-direction.md:67-67 (list_item)

- "Cinestill 800T" — tungsten, halation around lights

Extracted rules inside block: NONE

## 3cfe2cde2e565c8f — image/references/creative-direction.md:69-69 (paragraph)

**Digital grades:**

Extracted rules inside block: NONE

## e477c1261fb75cfc — image/references/creative-direction.md:70-70 (list_item)

- "Cinematic color grading with muted teal tones"

Extracted rules inside block: NONE

## 4e9b799cdf9df388 — image/references/creative-direction.md:71-71 (list_item)

- "High contrast, desaturated" — gritty, editorial

Extracted rules inside block: NONE

## 46ddfca6fd08db4d — image/references/creative-direction.md:72-72 (list_item)

- "Warm analog tones, lifted blacks" — vintage

Extracted rules inside block: NONE

## 0cbcfbaa8bf301d8 — image/references/creative-direction.md:73-73 (list_item)

- "Cool blue shadows, warm highlights" — modern cinema

Extracted rules inside block: NONE

## 960356d976c7d8f9 — image/references/creative-direction.md:74-74 (list_item)

- "Cross-processed, shifted greens" — experimental

Extracted rules inside block: NONE

## 4320f1687c07be65 — image/references/creative-direction.md:76-76 (heading)

## Materiality & Texture

Extracted rules inside block: NONE

## 8c6241d140e012a1 — image/references/creative-direction.md:78-78 (paragraph)

Define physical makeup of subjects. Don't just say the thing — describe what it's MADE of.

Extracted rules inside block: 582089b2ce25

## 90662dde8be55029 — image/references/creative-direction.md:80-80 (table_row)

| Vague | Specific |

Extracted rules inside block: NONE

## efb98da3b97c084c — image/references/creative-direction.md:82-82 (table_row)

| "a suit" | "navy blue tweed suit, visible weave" |

Extracted rules inside block: NONE

## 39bdca86b3af72fe — image/references/creative-direction.md:83-83 (table_row)

| "armor" | "ornate elven plate armor, etched with silver leaf patterns" |

Extracted rules inside block: NONE

## 50cf51009864c4f5 — image/references/creative-direction.md:84-84 (table_row)

| "a mug" | "minimalist ceramic coffee mug, matte glaze, slight imperfections" |

Extracted rules inside block: NONE

## 79f6a5d3e36a715d — image/references/creative-direction.md:85-85 (table_row)

| "skin" | "weathered, sun-damaged skin, deep expression lines" |

Extracted rules inside block: NONE

## 962cec1b3b372fee — image/references/creative-direction.md:86-86 (table_row)

| "metal" | "brushed steel with matte finish, fingerprint smudges" |

Extracted rules inside block: NONE

## 284d72117de75449 — image/references/creative-direction.md:88-88 (paragraph)

**Surface properties:**

Extracted rules inside block: NONE

## 6c959efb3315e392 — image/references/creative-direction.md:89-89 (list_item)

- Matte / glossy / satin

Extracted rules inside block: NONE

## 599702bbfa9ae3a6 — image/references/creative-direction.md:90-90 (list_item)

- Rough / smooth / textured

Extracted rules inside block: NONE

## 38e4ac1e674ab714 — image/references/creative-direction.md:91-91 (list_item)

- Translucent / opaque / refractive

Extracted rules inside block: NONE

## 277d79e385886a9f — image/references/creative-direction.md:92-92 (list_item)

- Worn / pristine / aged / patinated

Extracted rules inside block: NONE

## 3a2897e0ab22dc34 — image/references/creative-direction.md:94-94 (heading)

## Creative Prompt Examples

Extracted rules inside block: NONE

## 8ea765465386470b — image/references/creative-direction.md:96-96 (paragraph)

**Cartoon Portrait (3D + Real):**

Extracted rules inside block: NONE

## 84ba99529fdb8f65 — image/references/creative-direction.md:97-102 (code)

```
Based on the uploaded reference image, create a photorealistic scene
featuring the real human standing next to a giant 3D animation-style
version of themselves. Both must have identical facial structures,
clothing, and poses. Clean gray-blue studio background, cinematic lighting.
```

Extracted rules inside block: NONE

## 87ce7bd62aaaf9d5 — image/references/creative-direction.md:104-104 (paragraph)

**Animation → Photorealistic:**

Extracted rules inside block: NONE

## b3514f0b338e4cbf — image/references/creative-direction.md:105-109 (code)

```
Convert this uploaded animated still into an ultra-realistic, cinematic
scene. Transform the animated characters into real humans while preserving
their original identities, facial structures, outfits, and expressions.
```

Extracted rules inside block: NONE

## d7174315f1f77765 — image/references/creative-direction.md:111-111 (paragraph)

**Historical Maps (Google Street View style):**

Extracted rules inside block: NONE

## cecedcefd5cb3010 — image/references/creative-direction.md:112-117 (code)

```
Generate a hyper-realistic image of [HISTORICAL EVENT], perfectly
replicating a Google Maps Street View capture. Include wide-angle barrel
distortion, semi-transparent Maps UI overlay (compass, chevron arrows),
and '© Google [YEAR]' watermark. Automatically blur faces for privacy.
```

Extracted rules inside block: NONE

## 0b9fc9eef112d431 — image/references/creative-direction.md:119-119 (paragraph)

**Kindergarten Filter:**

Extracted rules inside block: NONE
