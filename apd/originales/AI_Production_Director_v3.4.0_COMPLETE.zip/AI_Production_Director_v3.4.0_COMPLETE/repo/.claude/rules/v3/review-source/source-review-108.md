# Source coverage review 108/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## cfd348218a949b7a — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:20-20 (table_row)

| Accent (warm) | `#D94F3A` | Coral, emphasis, periods on signature beats |

Extracted rules inside block: NONE

## 44ee5aa48609c112 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:21-21 (table_row)

| Accent (cool) | `#C9BBE0` | Pale lavender, secondary highlights |

Extracted rules inside block: NONE

## a3eaa87b152ac11e — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:22-22 (table_row)

| Muted | `#7A7580` | Secondary text, captions |

Extracted rules inside block: NONE

## 5b364fb8554c2ab0 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:23-23 (table_row)

| Rule | `#E8E1D4` | Subtle borders, dividers, card backgrounds |

Extracted rules inside block: NONE

## 73108933d367dad9 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:25-25 (heading)

## Typography

Extracted rules inside block: NONE

## 1dc84759d0b3f5da — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:27-29 (paragraph)

**Display font:** `Inter Black 900`, headline weight, hooks, on-screen text
**Body font:** `Inter Medium 500`, body copy, captions, UI
**Mono font:** `JetBrains Mono Regular`, code, data, technical references

Extracted rules inside block: NONE

## 50ec52668b8baca2 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:31-31 (paragraph)

Two-font stack for production. Mono only for technical content.

Extracted rules inside block: NONE

## a0f67afe2eadf7fb — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:33-33 (heading)

## Mood adjectives

Extracted rules inside block: NONE

## 87c9749857c555c6 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:35-35 (list_item)

- operator (not creator)

Extracted rules inside block: NONE

## 9f0739c739cdaae5 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:36-36 (list_item)

- considered (not reactive)

Extracted rules inside block: NONE

## c22bb6ce71c2f00d — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:37-37 (list_item)

- deterministic (not vibes-based)

Extracted rules inside block: NONE

## d2af95a2f8dd8176 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:38-38 (list_item)

- confident (without volume)

Extracted rules inside block: NONE

## 61fbb1437f249bc4 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:39-39 (list_item)

- defense-grade (not fragile)

Extracted rules inside block: NONE

## 1a884199ff157649 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:41-41 (heading)

## Never list

Extracted rules inside block: NONE

## 0e1165da10bb826e — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:43-43 (list_item)

- never use stock photo aesthetic

Extracted rules inside block: 7c6a0590780e

## 5576ee391496dd03 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:44-44 (list_item)

- never use AI uncanny faces

Extracted rules inside block: a33095e83db8

## 9a50b307f1fa6d94 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:45-45 (list_item)

- never over-saturate the cream background

Extracted rules inside block: 6532d54d8d55

## 66453e57cc5a53ab — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:46-46 (list_item)

- never use coral as a flood color (only as accent or signature periods)

Extracted rules inside block: 60b48c2a87a8

## 525a95cd047889d3 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:47-47 (list_item)

- never use em dashes in copy (only periods, commas, semicolons)

Extracted rules inside block: 5dd089fbd405

## 0c2e4ade817dd0db — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:48-48 (list_item)

- never use emojis in body copy

Extracted rules inside block: ad5d969ec6c6

## 665581e54510966a — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:49-49 (list_item)

- never use bullet points in narrative copy

Extracted rules inside block: 96ba276c90e0

## 4f073626463bf552 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:50-50 (list_item)

- never use clip-art or generic icon sets

Extracted rules inside block: e611bf62b644

## c47b36f981bb101c — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:51-51 (list_item)

- never use hype words ("game-changing", "revolutionary", "next-level", "comprehensive")

Extracted rules inside block: 26da66b6aae8

## e7b54114ad64e5a5 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:52-52 (list_item)

- never use exclamation points in headlines

Extracted rules inside block: 3e41ac1a76e4

## 961d7b7da2fe7418 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:53-53 (list_item)

- never default to dark mode, light mode hybrid is the brand

Extracted rules inside block: dabc9c235d86

## f7abdd03eeea4f94 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:54-54 (list_item)

- never animate text with bouncing or wobbling, type-on, fade, or hard cut only

Extracted rules inside block: 1243aa3d2453

## 9d404b4a2e681a0c — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:55-55 (list_item)

- never break the eye line between subject and the implied "operator perspective"

Extracted rules inside block: 8369a4d99e3a

## adabea656fe6ca09 — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:57-57 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## 99c12dbbe68f515c — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:59-59 (list_item)

- 9:16, primary for short-form social

Extracted rules inside block: NONE

## 84acc84fad4988be — storyboard-architect/examples/shotkit-explainer/brand-lock.snapshot.md:60-60 (list_item)

- 16:9, long-form, hero films, web embeds

Extracted rules inside block: NONE
