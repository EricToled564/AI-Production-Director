# Source coverage review 56/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 6aba7cbf98fd37d3 — image/references/patterns/ecommerce.md:49-49 (list_item)

> For a dark-themed variant with timestamps, see [multi-panel.md](../multi-panel.md#1-9-cell-grid-storyboard).

Extracted rules inside block: NONE

## 44af8646ff3faf6e — image/references/patterns/ecommerce.md:51-51 (paragraph)

Use to present a product commercial shot breakdown in a single image — pitch decks, creative presentations, client approvals.

Extracted rules inside block: 34aa7ddfcd1b

## c3822cd6e90fe829 — image/references/patterns/ecommerce.md:53-53 (paragraph)

<!-- Source concept: 9-panel television commercial storyboard grid with numbered frames -->

Extracted rules inside block: NONE

## 7f2e8d6b25f8a6b6 — image/references/patterns/ecommerce.md:55-70 (code)

```
Scene: white canvas background, clean 3x3 grid with thin #CCCCCC divider lines (2px), each cell represents one shot in a {duration}-second commercial
Subject: {product_name} commercial storyboard — each panel is a distinct camera setup
Important Details:
  Panel 1 (wide): establishing shot of {setting}, warm natural light, product not yet visible
  Panel 2 (medium): {protagonist} notices/discovers the product on {surface}
  Panel 3 (close-up): hand reaching for {product_name}, shallow depth of field
  Panel 4 (ECU): product detail — texture of {product_material}, label readable
  Panel 5 (medium): {protagonist} using/opening the product, genuine expression
  Panel 6 (reaction): close-up face, {emotion} expression, soft key light
  Panel 7 (wide): product in context of {lifestyle_scene}
  Panel 8 (beauty shot): product hero on {beauty_surface}, studio lighting
  Panel 9 (pack shot): product centered on white with "{tagline}" below in thin sans-serif, #333333
Use Case: creative pitch deck, storyboard for TVC production
Constraints: consistent character identity across all panels, no panel numbering text, uniform lighting temperature within the narrative (panels 1-7), distinct studio lighting for panels 8-9
```

Extracted rules inside block: NONE

## 4ce2af333db7491f — image/references/patterns/ecommerce.md:72-72 (paragraph)

**Key levers:** `{product_name}`, `{protagonist}` (woman in her 30s, young couple, family), `{setting}` (bright kitchen, outdoor terrace, urban cafe), `{emotion}` (satisfied, surprised, relaxed), `{beauty_surface}` (white marble, gradient gray), `{tagline}`, `{duration}` (15, 30)

Extracted rules inside block: NONE

## 436fa4f4519700e4 — image/references/patterns/ecommerce.md:74-74 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — grid precision and text in panel 9

Extracted rules inside block: c4e793a8fa86

## 4af659052390e503 — image/references/patterns/ecommerce.md:78-78 (heading)

## Floating Ingredient Freeze-Frame

Extracted rules inside block: NONE

## e30b836f3c924ad2 — image/references/patterns/ecommerce.md:80-80 (paragraph)

Use for food, beverage, or supplement products where suspended ingredients communicate freshness, flavor, or composition.

Extracted rules inside block: fc9ce4b19927

## c7854e13e77ee568 — image/references/patterns/ecommerce.md:82-82 (paragraph)

<!-- Source concept: frozen-motion ingredient explosion around product, high-speed photography aesthetic -->

Extracted rules inside block: NONE

## 2c94a6394e6976dd — image/references/patterns/ecommerce.md:84-90 (code)

```
Scene: {background_gradient} gradient backdrop, high-speed flash freeze-frame moment, clean studio environment
Subject: {product_name} container in center, tilted {tilt_angle} degrees, with {liquid_type} mid-pour arcing from the opening
Important Details: individual {ingredient_list} frozen in mid-air around the product — each element sharply focused with visible texture ({texture_details}), micro water droplets suspended alongside ingredients, single hard flash from behind (rim light on ingredients), secondary soft fill from front, liquid splash forms a clean arc with visible viscosity, product label faces camera and remains fully legible, ingredients distributed in a loose orbital pattern
Use Case: beverage packaging, food product poster, social media ad
Constraints: no ingredients overlapping the product label, no motion blur (everything frozen sharp), background must remain clean — no stray splashes hitting edges, no more than {max_ingredients} floating elements, no artificial glow effects
```

Extracted rules inside block: NONE

## 41e3edbfc2308087 — image/references/patterns/ecommerce.md:92-92 (paragraph)

**Key levers:** `{product_name}`, `{background_gradient}` (#F5F0EB to #FFFFFF for light, #1A0A2E to #0D0D0D for dark), `{liquid_type}` (amber juice, white milk, green smoothie), `{ingredient_list}` (sliced strawberries + mint leaves + ice cubes, cocoa nibs + hazelnuts + vanilla pod), `{texture_details}` (visible seeds on strawberry cross-section, frost crystals on ice), `{tilt_angle}` (15, 25), `{max_ingredients}` (6-8)

Extracted rules inside block: NONE

## 69b37c5ec6e9eac6 — image/references/patterns/ecommerce.md:94-94 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — frozen detail precision and label legibility

Extracted rules inside block: d1c06a23a185

## df8dfd6913f43777 — image/references/patterns/ecommerce.md:98-98 (heading)

## Inflatable Surrealism Product Poster

Extracted rules inside block: NONE

## eeccb6d6e2035bb6 — image/references/patterns/ecommerce.md:100-100 (paragraph)

Use for disruptive, scroll-stopping social ads where the product packaging appears squeezed, inflated, or physically distorted as if made of soft rubber or vinyl.

Extracted rules inside block: 3ce616284507

## a544628c10b1a8ac — image/references/patterns/ecommerce.md:102-102 (paragraph)

<!-- Source concept: inflatable surrealism — product packaging rendered as squeezed/puffy/distorted soft objects -->

Extracted rules inside block: NONE

## e4ce1188b111dc59 — image/references/patterns/ecommerce.md:104-110 (code)

```
Scene: solid {background_color} background, soft even studio lighting with no hard shadows, slightly elevated camera angle (15 degrees above eye level)
Subject: {product_name} packaging reimagined as a puffy inflatable vinyl object — the shape is recognizable but squeezed at the middle as if gripped by an invisible hand, seams visible where vinyl panels meet, surface slightly reflective like a pool float
Important Details: {product_color_scheme} preserved on the inflated surface but stretched and slightly warped around curves, visible air valve at the bottom edge (small brass circle), subtle wrinkles where the vinyl compresses, the brand name/logo distorted by the inflation but still readable, two or three {companion_objects} nearby also inflated (matching aesthetic), environment reflection on glossy vinyl surface, cast shadow soft and diffused below
Use Case: disruptive social media ad, brand campaign poster, billboard
Constraints: product must remain identifiable despite distortion, no liquid, no particles, no humans, no text outside what exists on the packaging, vinyl texture must read as physical (not digital 3D render), background is flat color only
```

Extracted rules inside block: NONE

## e28af0fdf9dbdbff — image/references/patterns/ecommerce.md:112-112 (paragraph)

**Key levers:** `{product_name}`, `{background_color}` (bubblegum pink #FFB6C1, electric blue #007BFF, acid yellow #E8FF00), `{product_color_scheme}`, `{companion_objects}` (matching accessories, ingredient items, brand mascot elements)

Extracted rules inside block: NONE

## 3fb9bcb8726e1ccc — image/references/patterns/ecommerce.md:114-114 (paragraph)

**Recommended model:** NBP — complex spatial reasoning for believable physical distortion

Extracted rules inside block: 238d0b311f33

## a884eef10272af67 — image/references/patterns/ecommerce.md:116-116 (heading)

### Nano Banana version:

Extracted rules inside block: NONE

## da0af85cfe54c48d — image/references/patterns/ecommerce.md:118-120 (code)

```
A product poster showing {product_name} packaging transformed into a puffy inflatable vinyl object, squeezed at the middle as if gripped by an invisible hand. The surface is slightly glossy like a pool float, with visible seams where vinyl panels meet and a small brass air valve at the base. The original {product_color_scheme} is preserved but stretched and warped around the inflated curves. Brand text is distorted by the shape but still legible. Two small {companion_objects} sit nearby, also inflated in the same vinyl style. Solid {background_color} background, soft even studio light, slightly elevated camera angle. Soft diffused shadow below. Format: 4:5.
```

Extracted rules inside block: NONE

## 0c5d55ffe9bff583 — image/references/patterns/ecommerce.md:124-124 (paragraph)

*Author: Serge Shima ([t.me/aimastersme](https://t.me/aimastersme) · [sergeshima.com](https://sergeshima.com) · [aimasters.me](https://aimasters.me)) · License: CC BY 4.0 — attribution required · Source: [smixs/visual-skills](https://github.com/smixs/visual-skills)*

Extracted rules inside block: NONE

## 686e8578c39307cd — image/references/patterns/fashion-editorial.md:1-1 (heading)

# Fashion Editorial Patterns

Extracted rules inside block: NONE

## 91c28ed5c1a568a1 — image/references/patterns/fashion-editorial.md:3-3 (paragraph)

Reusable prompt templates for fashion campaigns, lookbooks, and editorial shoots. Each pattern uses `{variables}` for customization. Default model: GPT Image 2 (5-slot format) unless noted.

Extracted rules inside block: NONE

## 95ccadc2be811ba5 — image/references/patterns/fashion-editorial.md:7-7 (heading)

## 3-Panel Campaign Collage

Extracted rules inside block: NONE

## 8f15c731393e75bc — image/references/patterns/fashion-editorial.md:9-9 (paragraph)

Use for fashion brand campaign hero images — one wide shot combining hero pose, close-up detail, and action/movement in a triptych layout.

Extracted rules inside block: 5d7f191ed435

## 7caa07bfa18b390a — image/references/patterns/fashion-editorial.md:11-11 (paragraph)

<!-- Source concept: fashion campaign triptych collage — hero + detail + movement panels -->

Extracted rules inside block: NONE

## 60e5ed1c135908e5 — image/references/patterns/fashion-editorial.md:13-23 (code)

```
Scene: three vertical panels side by side on a single canvas (left 40% width, right split into two stacked panels 60% height each), thin white divider lines (3px), cohesive {lighting_setup} across all panels
Subject: {model_description} wearing {outfit_description} — same person, same outfit, three perspectives
Important Details:
  Left panel (hero): full-body three-quarter pose, {model_description} standing against {background_1}, weight shifted to one hip, direct gaze at camera, medium-format film grain, {color_grade}
  Top-right panel (detail): extreme close-up of {detail_focus} — visible weave/stitching/texture of {fabric_type}, shallow depth of field, warm directional light raking across surface
  Bottom-right panel (action): mid-stride walking shot from low angle, {background_2}, coat/fabric in motion with natural drape physics, slight motion energy in hair
  Overall: cohesive warm/cool temperature of {color_temperature}, consistent skin tone rendering across panels, editorial magazine quality
Use Case: fashion brand campaign, lookbook cover, social media carousel hero
Constraints: same person with identical features in all three panels, no text, no logos, no visible studio equipment, panels must feel like one shoot not three separate photos, no heavy retouching glow
```

Extracted rules inside block: NONE

## 62f3308978a75ada — image/references/patterns/fashion-editorial.md:25-25 (paragraph)

**Key levers:** `{model_description}` (East Asian woman mid-20s, athletic man early 30s), `{outfit_description}`, `{detail_focus}` (collar construction, cuff button, belt buckle, shoe sole), `{fabric_type}` (raw selvedge denim, double-faced cashmere, washed silk), `{background_1}` (concrete wall, sand dune, industrial corridor), `{background_2}` (open street, field, rooftop), `{color_grade}` (lifted blacks with amber cast, desaturated teal), `{color_temperature}` (warm 4000K feel, cool overcast daylight)

Extracted rules inside block: NONE

## 8a25088d9796795a — image/references/patterns/fashion-editorial.md:27-27 (paragraph)

**Recommended model:** GPT Image 2 (`quality: high`) — identity consistency across panels and fabric texture detail

Extracted rules inside block: 5a3e057f3488

## 4d35773e335c139d — image/references/patterns/fashion-editorial.md:31-31 (heading)

## 2x2 Editorial Portrait Grid

Extracted rules inside block: NONE
