# Source coverage review 79/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## dda5a2d23d7cdb22 — produccion-visual-sw30/SKILL.md:35-38 (list_item)

1. **CATALOGAR** — identificar el TIPO de prompt y leer qué reglas aplican a ese tipo en la matriz
   (production-package/RULES_MATRIX.md: 26 reglas × 5 tipos, con fuente y bloque de cada una).
   Tipos: T1 maestro rostro · T2 maestro cuerpo · T3 cuadro 1 persona · T4 cuadro 2 personas ·
   T5 edición quirúrgica.

Extracted rules inside block: 1289222306ea

## fe3ae2fb8c1baef9 — produccion-visual-sw30/SKILL.md:39-41 (list_item)

2. **DEFINIR SECCIONES** — antes de redactar, listar las secciones que ese tipo exige. Cada regla vive
   en UN bloque nombrado y compartido (optics_*, skin_*, anatomy, idlock, text_lock, contact_*, unique,
   colour, hair, fabric, clean_*, autocontain_*), nunca en texto suelto dentro del brief.

Extracted rules inside block: f3844410892e

## cc51270d76b7a0d2 — produccion-visual-sw30/SKILL.md:42-44 (list_item)

3. **ENSAMBLAR POR SECCIÓN** — el prompt se construye llamando P(scene, subject, [details], mood,
   usecase, [constraints]) para creación o E(change, preserve, [constraints]) para edición, pasando
   bloques. Salida en el formato de SKILL.md del skill image: cabecera Model/Quality/Size + References

Extracted rules inside block: c91bb7d2e454

## 52266f60561e4af1 — produccion-visual-sw30/SKILL.md:45-45 (list_item)

   + "Prompt:" + "Notes:" fuera del cuerpo.

Extracted rules inside block: NONE

## 4acb71307b6b0f47 — produccion-visual-sw30/SKILL.md:47-47 (heading)

### Sistema de cobertura de reglas — la fuente manda, no la memoria

Extracted rules inside block: NONE

## e0cd6f6c4e4a072a — produccion-visual-sw30/SKILL.md:48-50 (paragraph)

Causa raíz medida: el catálogo de reglas salía de la memoria y cubría 26 de 209 enunciados de la
fuente (12%). Todos los controles derivaban de ese catálogo, así que compartían un único punto de
falla. Cadena corregida, con tres herramientas en production-package:

Extracted rules inside block: NONE

## bddb408b99c69f5e — produccion-visual-sw30/SKILL.md:52-53 (list_item)

1. `rule_registry.py` — relee los 23 archivos del skill image y EXTRAE mecánicamente cada enunciado
   normativo (209). Si el skill cambia, el registro cambia solo. Mi interpretación deja de ser etapa.

Extracted rules inside block: 29837864275c

## 7434f4785e8d4c87 — produccion-visual-sw30/SKILL.md:54-55 (list_item)

2. `rule_ledger.py` — obliga a que CADA regla aplicable tenga disposición explícita: CHECK (existe
   verificación) o NA (con razón escrita y auditable). Sale con código 1 si queda una sola PENDING.

Extracted rules inside block: 70959300d63e

## 2ceaf2084baa8525 — produccion-visual-sw30/SKILL.md:56-56 (list_item)

3. `audit_gi2.py` — verifica los prompts columna por columna.

Extracted rules inside block: c3632422a5a9

## ee461557c7a5b881 — produccion-visual-sw30/SKILL.md:58-60 (paragraph)

**GATE DE COBERTURA**: el builder corre `rule_ledger.py` antes de emitir; si no cierra en 100%
dispuesto, no hay archivo de prompts. Estado actual: 124 reglas aplicables · 100 con verificación
(80%) · 24 excluidas con razón (19%) · 0 pendientes · 100% dispuesto.

Extracted rules inside block: NONE

## 80cf6cdf7388723f — produccion-visual-sw30/SKILL.md:62-63 (paragraph)

Cuando el usuario detecte un defecto: se añade su regla al ledger con su check en el mismo turno.
Así el sistema aprende de su detector más confiable en vez de perder el hallazgo.

Extracted rules inside block: NONE

## 02b910e6c36f2b95 — produccion-visual-sw30/SKILL.md:65-65 (heading)

### Template canónico de MAESTRO DE ROSTRO (T1) — obligatorio, aplicado por código

Extracted rules inside block: NONE

## 6f79b42632773c0e — produccion-visual-sw30/SKILL.md:66-67 (paragraph)

Dirección canonizó el template que resolvió el look plástico (2026-08-25). Todo maestro de rostro
se instancia con estos cuatro bloques y el motor lanza TemplateViolation si se sustituye alguno:

Extracted rules inside block: NONE

## 074806315d8612e3 — produccion-visual-sw30/SKILL.md:69-69 (table_row)

| Sección | Bloque obligatorio | Por qué |

Extracted rules inside block: 4db66ab71600

## ca31fb7e00a2311d — produccion-visual-sw30/SKILL.md:71-71 (table_row)

| light | `light_hard` | luz dura sin relleno, rasante: los poros proyectan sombra. La luz suave de softbox aplana la piel y produce el look plástico — PROHIBIDA en rostros |

Extracted rules inside block: NONE

## b5466dd5c08581cb — produccion-visual-sw30/SKILL.md:72-72 (table_row)

| skin | `skin_doc` | defectos concretos (rojeces, descamación, sudor, pigmento desigual, pelos de barba individuales, labios agrietados), no "imperfecciones sutiles" |

Extracted rules inside block: NONE

## 0caa971817f1d1a6 — produccion-visual-sw30/SKILL.md:73-73 (table_row)

| usecase | `usecase_doc` | fotografía documental Kodak Tri-X de reportaje. Kodak Portra suaviza la piel por diseño y contradice los poros — PROHIBIDO en rostros |

Extracted rules inside block: b1f2d2ee867d

## ac60dd429bddf3b5 — produccion-visual-sw30/SKILL.md:74-74 (table_row)

| clean | `clean_doc` | anti-belleza explícito: no beauty retouching, no skin smoothing, no even complexion, no soft fill light |

Extracted rules inside block: NONE

## e4e779bf939674aa — produccion-visual-sw30/SKILL.md:76-77 (paragraph)

Además, en el slot de rasgos: describir una cara IRREGULAR (nariz con caballete, cicatriz, ojos
hundidos, asimetrías). La cara regular y simétrica es la que lee como maniquí.

Extracted rules inside block: NONE

## c6e6e03c82d673d5 — produccion-visual-sw30/SKILL.md:79-80 (paragraph)

Longitud: el prompt completo se mantiene alrededor de 250 palabras. Un slot de 300+ palabras compite
consigo mismo — causa documentada de artefactos en gpt-image-2.

Extracted rules inside block: NONE

## c21b632151d302a7 — produccion-visual-sw30/SKILL.md:82-82 (heading)

### Motor de plantillas — el molde se cumple por código, no por disciplina

Extracted rules inside block: NONE

## b4a2f95ff28b13b0 — produccion-visual-sw30/SKILL.md:83-85 (paragraph)

`production-package/template_engine.py` es OBLIGATORIO para construir cualquier prompt visual.
Un prompt no se escribe: se INSTANCIA con `build(tipo, ..., notes=...)`. El motor lanza
`TemplateViolation` y no devuelve nada si:

Extracted rules inside block: 5932b40618b8, be1fdee5e6f0

## e6b6d895a9583f24 — produccion-visual-sw30/SKILL.md:86-86 (list_item)

- falta cualquier sección obligatoria del tipo (T1..T5 declaran su lista, en orden);

Extracted rules inside block: NONE

## c1f321964b26e352 — produccion-visual-sw30/SKILL.md:87-87 (list_item)

- se pasa una sección que la plantilla no declara;

Extracted rules inside block: NONE

## 3356056f244bb420 — produccion-visual-sw30/SKILL.md:88-88 (list_item)

- una sección que debe venir de `BLOCKS` llega como texto suelto — el mensaje dice qué bloque editar;

Extracted rules inside block: NONE

## 2dabcf415984c481 — produccion-visual-sw30/SKILL.md:89-89 (list_item)

- falta el bloque `Notes`;

Extracted rules inside block: NONE

## 0fa6fcb4e918c168 — produccion-visual-sw30/SKILL.md:90-90 (list_item)

- se cuela un metadato (Model/Quality/Size/Aspect ratio) dentro del cuerpo del prompt.

Extracted rules inside block: NONE

## 4b9a4a1ca4c7dc76 — produccion-visual-sw30/SKILL.md:91-92 (paragraph)

`python3 template_engine.py` corre su autotest: comprueba que rechaza secciones faltantes, texto
suelto y tipos desconocidos, y que una instancia válida sí se construye.

Extracted rules inside block: NONE

## d57781200323b708 — produccion-visual-sw30/SKILL.md:94-94 (heading)

### Ante un cambio

Extracted rules inside block: NONE

## e111821696bbcca6 — produccion-visual-sw30/SKILL.md:95-95 (list_item)

- Identificar a qué BLOQUE pertenece → editar ese bloque UNA vez → recompilar → auditar.

Extracted rules inside block: NONE
