# Source coverage review 220/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 43776773d1ac3fd3 — visual-prompt-forge/adapters/veo.md:15-15 (heading)

## Parameters

Extracted rules inside block: NONE

## 5aea276eccf1779d — visual-prompt-forge/adapters/veo.md:17-17 (table_row)

| Parameter | Default | Notes |

Extracted rules inside block: NONE

## ebd6e6b74ae6deec — visual-prompt-forge/adapters/veo.md:19-19 (table_row)

| `duration` | `8s` | Veo's native clip length |

Extracted rules inside block: NONE

## e5608ae3a33dd517 — visual-prompt-forge/adapters/veo.md:20-20 (table_row)

| `aspect_ratio` | from `project.aspect` | |

Extracted rules inside block: NONE

## 6537f3b4bd997d91 — visual-prompt-forge/adapters/veo.md:21-21 (table_row)

| `generate_audio` | `true` | The reason to choose Veo. Set `false` only for silent shots |

Extracted rules inside block: NONE

## dd439dfc87334322 — visual-prompt-forge/adapters/veo.md:22-22 (table_row)

| `start_image` | optional | Image-to-video from an accepted still |

Extracted rules inside block: NONE

## a1f177e97ef5e1c3 — visual-prompt-forge/adapters/veo.md:24-27 (code)

```
# shot_04. Veo 3: duration=8s, ar=9:16, generate_audio=true
{prompt}
```

Extracted rules inside block: NONE

## 0e94951773ad609a — visual-prompt-forge/adapters/veo.md:29-29 (heading)

## Length

Extracted rules inside block: NONE

## 03dfcc698f9d2481 — visual-prompt-forge/adapters/veo.md:31-31 (paragraph)

Veo handles **80–150 words**. Spend the headroom on action timing and audio direction, not adjective stacks.

Extracted rules inside block: NONE

## 53067112c06c28b1 — visual-prompt-forge/adapters/veo.md:33-33 (heading)

## Dialogue and lipsync

Extracted rules inside block: NONE

## 9f30109bf19d04ea — visual-prompt-forge/adapters/veo.md:35-35 (paragraph)

When the shot calls for the subject to speak, put the exact line in quotes:

Extracted rules inside block: NONE

## d6a254ba013df660 — visual-prompt-forge/adapters/veo.md:37-37 (list_item)

> The founder looks directly into the lens and says, "I built the system once, and it runs without me."

Extracted rules inside block: NONE

## a84c31353d07a0ff — visual-prompt-forge/adapters/veo.md:39-39 (paragraph)

Keep spoken lines to what fits the duration, roughly 12–18 words for an 8s clip. Direct the delivery ("calm, unhurried"). Veo lipsyncs the quoted line.

Extracted rules inside block: NONE

## c020f3987445d2cf — visual-prompt-forge/adapters/veo.md:41-41 (heading)

## Motion vocabulary

Extracted rules inside block: NONE

## eba2c5e368e34711 — visual-prompt-forge/adapters/veo.md:43-43 (paragraph)

The shot grammar `motion` field maps directly. One move per shot.

Extracted rules inside block: NONE

## 33800c67333d4053 — visual-prompt-forge/adapters/veo.md:45-45 (table_row)

| `motion` | Video prompt phrase |

Extracted rules inside block: NONE

## a374e2461085b2e3 — visual-prompt-forge/adapters/veo.md:47-47 (table_row)

| `static` | "Static camera, locked off." |

Extracted rules inside block: NONE

## fcc7804455b06af2 — visual-prompt-forge/adapters/veo.md:48-48 (table_row)

| `push` / `pull` | "Camera dollies forward / backward slowly." |

Extracted rules inside block: NONE

## 36b116d312803dac — visual-prompt-forge/adapters/veo.md:49-49 (table_row)

| `pan-left` / `pan-right` | "Camera pans smoothly left / right." |

Extracted rules inside block: NONE

## eed050c072c3bd75 — visual-prompt-forge/adapters/veo.md:50-50 (table_row)

| `tilt-up` / `tilt-down` | "Camera tilts up / down." |

Extracted rules inside block: NONE

## 81b78af681cfa428 — visual-prompt-forge/adapters/veo.md:51-51 (table_row)

| `handheld` | "Handheld camera, subtle organic movement." |

Extracted rules inside block: NONE

## 214d0335613088c6 — visual-prompt-forge/adapters/veo.md:52-52 (table_row)

| `orbit` | "Camera orbits the subject slowly." |

Extracted rules inside block: NONE

## e33bc9b6de22fc73 — visual-prompt-forge/adapters/veo.md:53-53 (table_row)

| `whip` | "Fast whip pan with motion blur." |

Extracted rules inside block: NONE

## 57e99a3f57cfeb23 — visual-prompt-forge/adapters/veo.md:54-54 (table_row)

| `rack` | "Rack focus from foreground to background." |

Extracted rules inside block: NONE

## 479372337bd85fa9 — visual-prompt-forge/adapters/veo.md:56-56 (heading)

## Audio direction

Extracted rules inside block: NONE

## 72613d367ebf61bb — visual-prompt-forge/adapters/veo.md:58-58 (paragraph)

Even on silent shots Veo can place ambience. Be explicit and brief:

Extracted rules inside block: NONE

## 929a45d798e1fbab — visual-prompt-forge/adapters/veo.md:60-60 (list_item)

- "Audio: quiet room tone, faint keyboard, no music."

Extracted rules inside block: NONE

## 242044dc759648c7 — visual-prompt-forge/adapters/veo.md:61-61 (list_item)

- "Audio: soft afternoon ambience, distant street."

Extracted rules inside block: NONE

## c89fd969a6ff7ce2 — visual-prompt-forge/adapters/veo.md:63-63 (paragraph)

If the brand-lock or storyboard owns the audio bed (VO recorded separately, music added in post), set `generate_audio=false` and skip this section so Veo does not invent a competing track.

Extracted rules inside block: NONE

## ef6dca68cb1e8303 — visual-prompt-forge/adapters/veo.md:65-65 (heading)

## Example

Extracted rules inside block: NONE
