# Source coverage review 53/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 699380cad06d422d — image/references/nano-banana.md:90-94 (code)

```
Remove [OBJECT] from this image.
Fill with [LOGICAL REPLACEMENT] matching surroundings.
Keep [PRESERVED ELEMENTS] exactly the same.
```

Extracted rules inside block: NONE

## cda2bb671fd96dcc — image/references/nano-banana.md:96-96 (paragraph)

После генерации добавляй итеративно:

Extracted rules inside block: NONE

## 5d3772fc441bfc6c — image/references/nano-banana.md:97-97 (list_item)

- «Make it warmer»

Extracted rules inside block: NONE

## 258da8af534197df — image/references/nano-banana.md:98-98 (list_item)

- «Increase contrast»

Extracted rules inside block: NONE

## eb86b566020f75cc — image/references/nano-banana.md:99-99 (list_item)

- «Soften background, add blur»

Extracted rules inside block: NONE

## cc56b0733d61a897 — image/references/nano-banana.md:100-100 (list_item)

- «Change headline color to #3b82f6»

Extracted rules inside block: NONE

## ab0bd4db775e56ae — image/references/nano-banana.md:102-102 (paragraph)

Interactions API держит контекст сессии — до 3 последовательных правок стэкаются без потери исходника. Правило «Edit, don't re-roll»: картинка верна на 80% — проси точечное изменение, а не новую генерацию.

Extracted rules inside block: 809e69697b9b

## 814b7a3fcf723a29 — image/references/nano-banana.md:104-104 (heading)

## Text Rendering

Extracted rules inside block: NONE

## 6209becae7449529 — image/references/nano-banana.md:106-106 (list_item)

- SOTA по 100+ языкам.

Extracted rules inside block: NONE

## df9fbbfd7f82338d — image/references/nano-banana.md:107-107 (list_item)

- Font можно называть: «Century Gothic 12px», «Brush Script», «Impact», «Heavy blocky sans-serif».

Extracted rules inside block: NONE

## f2afc8825eb00a91 — image/references/nano-banana.md:108-108 (list_item)

- Multi-language в одном кадре работает.

Extracted rules inside block: NONE

## c0ca42006bb7d123 — image/references/nano-banana.md:109-109 (list_item)

- Hack: для сложного текста — сначала попроси модель **написать текст**, потом отдельным промптом «вставь этот текст в картинку».

Extracted rules inside block: NONE

## 1cd61e8514710276 — image/references/nano-banana.md:111-111 (heading)

## Resolution / Cost

Extracted rules inside block: NONE

## 948b97951fa2f9a2 — image/references/nano-banana.md:113-113 (table_row)

| Resolution | Использование |

Extracted rules inside block: NONE

## fa8cff8820c940cb — image/references/nano-banana.md:115-115 (table_row)

| 0.5K | Самая дешёвая, batch и А/B варианты |

Extracted rules inside block: NONE

## 90f0f486f67dabc6 — image/references/nano-banana.md:116-116 (table_row)

| 1K | Default |

Extracted rules inside block: NONE

## f52bba8e4cd8845a — image/references/nano-banana.md:117-117 (table_row)

| 2K | Финальный отбор |

Extracted rules inside block: NONE

## 1e0cdfd7b21f7e1b — image/references/nano-banana.md:118-118 (table_row)

| 4K | Печать, hero-ассеты |

Extracted rules inside block: NONE

## 2cdd202cc14e5bee — image/references/nano-banana.md:120-120 (paragraph)

**Workflow:** прогон вариантов на `0.5K` flash (или NB2 Lite на 1K) → отбор → переген победителя на `2K`/`4K`.

Extracted rules inside block: NONE

## 4f99a61d8ce76f4a — image/references/nano-banana.md:122-122 (paragraph)

В API `image_size` пишется строго с заглавной K (`1K`, `2K`, `4K`) — `1k` отклоняется. `512px` есть только у NB2; Lite — только 1K. Без указания размера модель матчит вход, иначе 1:1.

Extracted rules inside block: NONE

## 0b5050b40affe188 — image/references/nano-banana.md:124-124 (heading)

## Кейфреймы для видео

Extracted rules inside block: NONE

## c17f51e7f2720ea8 — image/references/nano-banana.md:126-126 (paragraph)

Nano Banana — image-слой перед motion-слоем. Всё критичное фиксируется на картинке ДО анимации: identity, композиция, aspect ratio, видимый текст, состояние продукта. Видеомодель усиливает любую неоднозначность стилла.

Extracted rules inside block: NONE

## 39855c16be8da63e — image/references/nano-banana.md:128-128 (list_item)

- **Character sheet / hero frame.** Утверди один кадр-эталон персонажа, на него ссылаются все последующие video-промпты.

Extracted rules inside block: NONE

## 602f9e5149a21885 — image/references/nano-banana.md:129-129 (list_item)

- **Aspect ratio сразу целевой.** Кампании нужен вертикальный ролик — генери 9:16, а не кропай после анимации (тихая точка отказа).

Extracted rules inside block: NONE

## ba97c55f778fcf9b — image/references/nano-banana.md:130-130 (list_item)

- **Хэндофф в видеомодель — motion brief, не пересказ.** Движение камеры, движение субъекта, движение фона, длительность, framing lock, запрещённые изменения. Видео-промпт не переописывает то, что уже есть в кадре.

Extracted rules inside block: eea69f6a6d4c

## 0cafc0a556305cc5 — image/references/nano-banana.md:131-131 (list_item)

- Downstream любой: Veo 3.1, Kling 3.0, Seedance 2.0/2.5, Gemini Omni Flash (штатная пара Google, 10-сек клипы). Батч картинок → ревью-гейт → в видео уходят только одобренные стиллы.

Extracted rules inside block: NONE

## 265eb921fb952c77 — image/references/nano-banana.md:133-133 (heading)

## Известные фейлы

Extracted rules inside block: NONE

## d5a2b8f48b86fd8d — image/references/nano-banana.md:135-135 (list_item)

- Руки и лица всё ещё плывут (пальцы, суставы, дрейф likeness) — явные anatomy-инструкции + рефы + перегенерации. Есть отчёты, что NBP держит лица хуже NB2.

Extracted rules inside block: NONE

## cafc2c01f65b6a93 — image/references/nano-banana.md:136-136 (list_item)

- Мелкий текст мылится на 1K — для плотного текста 2K+ или GPT Image 2.

Extracted rules inside block: NONE

## 11441ddeebc4f73c — image/references/nano-banana.md:137-137 (list_item)

- Инфографика может содержать фактически неверные данные — цифры проверять всегда, grounding помогает, но не гарантирует.

Extracted rules inside block: 26385a1bd97c
