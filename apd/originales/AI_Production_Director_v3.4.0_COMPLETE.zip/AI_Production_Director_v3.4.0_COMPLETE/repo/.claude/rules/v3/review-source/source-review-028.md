# Source coverage review 28/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## d4abd95324268d37 — brand-lock-extractor/examples/brand-lock.md:79-81 (paragraph)

**Last updated:** 2026-06-18
**Owner:** extracted
**Version:** 1.0

Extracted rules inside block: NONE

## 0a8090a6c5483f8a — brand-lock-extractor/examples/input-brief.md:1-1 (heading)

# Example input: what the user handed over

Extracted rules inside block: NONE

## 571c68d110de53c4 — brand-lock-extractor/examples/input-brief.md:3-3 (paragraph)

This is the raw source material for the worked extraction. The user provided a URL and a one-page brand sheet. The `brand-lock.md` in this folder is what the skill produced from it.

Extracted rules inside block: NONE

## 0d50ee10ec7af3b9 — brand-lock-extractor/examples/input-brief.md:5-5 (heading)

## Source 1: website (fetched)

Extracted rules inside block: NONE

## 8c0f86d012368521 — brand-lock-extractor/examples/input-brief.md:7-10 (paragraph)

**Homepage hero:**
> Northwind Coffee Roasters
> Small-batch coffee, roasted the morning it ships.
> No subscriptions to forget about. No bitter shortcuts. Just coffee that tastes like someone cared.

Extracted rules inside block: NONE

## 135e69b587ac09d3 — brand-lock-extractor/examples/input-brief.md:12-13 (paragraph)

**About page excerpt:**
> We started Northwind in a one-car garage in Duluth because the coffee we could buy locally was either burnt to hide cheap beans or priced like a luxury good. We roast in small batches, ship the same day, and tell you exactly where the beans came from and who grew them. We are roasters, not a lifestyle brand. The coffee does the talking.

Extracted rules inside block: NONE

## 3c3fbd030a7e608c — brand-lock-extractor/examples/input-brief.md:15-15 (paragraph)

**CSS (from the page source):**

Extracted rules inside block: NONE

## 67ed7d046046708d — brand-lock-extractor/examples/input-brief.md:16-23 (code)

```
--paper: #F4EFE6;
--espresso: #2B2018;
--ember: #C5562B;
--stone: #8A8076;
font-family: "Tiempos Headline", Georgia, serif;   /* headings */
font-family: "Söhne", -apple-system, sans-serif;    /* body */
```

Extracted rules inside block: NONE

## ae73f37e913e84cb — brand-lock-extractor/examples/input-brief.md:25-25 (heading)

## Source 2: one-page brand sheet (read)

Extracted rules inside block: NONE

## e7e6313650ba54ac — brand-lock-extractor/examples/input-brief.md:27-27 (list_item)

- Logo: wordmark only, espresso brown on paper cream. No icon.

Extracted rules inside block: NONE

## 1da24d0c21b4e6de — brand-lock-extractor/examples/input-brief.md:28-28 (list_item)

- Photography: matte, low-contrast, natural window light. Beans, hands, kraft bags. Never glossy product-on-white.

Extracted rules inside block: a1e68a72e11b

## 9c56e6a49c872fca — brand-lock-extractor/examples/input-brief.md:29-29 (list_item)

- "We don't do: stock smiles, latte art as decoration, exclamation points, or the word 'artisanal'."

Extracted rules inside block: 63e3397af43d

## e1d9765e169ce8ba — brand-lock-extractor/examples/input-brief.md:30-30 (list_item)

- Formats noted: Instagram (4:5 and 9:16), website hero (16:9).

Extracted rules inside block: NONE

## e67cafa9e0f5356c — brand-lock-extractor/references/extraction-rubric.md:1-1 (heading)

# Extraction rubric

Extracted rules inside block: NONE

## c6fb3dfc9c87a273 — brand-lock-extractor/references/extraction-rubric.md:3-3 (paragraph)

How to read each brand-lock section out of real assets. For every section: where the signal lives, how to read it, and how to assign confidence.

Extracted rules inside block: NONE

## 04b7a4e581b65910 — brand-lock-extractor/references/extraction-rubric.md:5-5 (heading)

## Confidence levels

Extracted rules inside block: NONE

## ab46344b0946aa1f — brand-lock-extractor/references/extraction-rubric.md:7-7 (paragraph)

Apply one to every value.

Extracted rules inside block: NONE

## 3c30df0d619e05f4 — brand-lock-extractor/references/extraction-rubric.md:9-9 (list_item)

- **extracted**, read directly from an asset. A hex in the brand book PDF. A `font-family` in the site CSS. A verbatim quote from the homepage. Ship it plainly.

Extracted rules inside block: NONE

## 5c94952d0faaeb00 — brand-lock-extractor/references/extraction-rubric.md:10-10 (list_item)

- **inferred**, reasoned from evidence, not stated. Archetype from how the brand frames problems. Never-list from what the assets consistently avoid. Ship it, note the reasoning.

Extracted rules inside block: 39cc69f567f7

## c2accdaac6dfa29b — brand-lock-extractor/references/extraction-rubric.md:11-11 (list_item)

- **needs confirmation**, a best estimate where assets were silent, compressed, or contradictory. A color sampled from a low-quality JPEG. A font you could not positively identify. Fill it so the file is complete, then flag it in Extraction notes.

Extracted rules inside block: NONE

## 3bb167feea04eaf6 — brand-lock-extractor/references/extraction-rubric.md:13-13 (heading)

## Identity

Extracted rules inside block: NONE

## 072f5e5b9e46f524 — brand-lock-extractor/references/extraction-rubric.md:15-15 (paragraph)

**Brand:** the name. Extracted from the logo, the title tag, or the description.

Extracted rules inside block: NONE

## d1b530f4f02b3e0b — brand-lock-extractor/references/extraction-rubric.md:17-17 (paragraph)

**One-line description:** what the brand does and who for. This is the load-bearing sentence; a generator implicitly references it on every prompt. Pull it from the hero headline plus the about page. Prefer concrete over abstract: "Managed bookkeeping for solo law firms" beats "Financial services for professionals." If the site only offers a vague tagline, sharpen it from the services/about copy and flag it `needs confirmation`.

Extracted rules inside block: d7cf5322601a

## f484648fb26500c6 — brand-lock-extractor/references/extraction-rubric.md:19-19 (paragraph)

**Archetype:** one word, Operator, Sage, Caregiver, Rebel, Creator, Jester, Ruler, Everyman, etc. Almost always `inferred`. Read it from how the brand frames the customer's problem:

Extracted rules inside block: 4ede25e468da

## 4da26e192ce87c4a — brand-lock-extractor/references/extraction-rubric.md:20-20 (list_item)

- frames problems as systems to engineer -> Operator

Extracted rules inside block: NONE

## 1c4a97a0af0b95ca — brand-lock-extractor/references/extraction-rubric.md:21-21 (list_item)

- frames problems as questions to investigate -> Sage

Extracted rules inside block: NONE

## c499e41b23241d31 — brand-lock-extractor/references/extraction-rubric.md:22-22 (list_item)

- frames problems as people to support -> Caregiver

Extracted rules inside block: NONE

## c19bf22e3b3aca93 — brand-lock-extractor/references/extraction-rubric.md:23-23 (list_item)

- frames problems as a status quo to break -> Rebel

Extracted rules inside block: NONE

## dc971db76f839f83 — brand-lock-extractor/references/extraction-rubric.md:25-25 (paragraph)

**Voice posture:** Confident / Warm / Sharp / Quiet / Playful / Authoritative. Read from sentence length, punctuation, and word choice in the body copy. Short declaratives -> Sharp/Confident. Long, soft, second-person -> Warm. Cite a representative sentence.

Extracted rules inside block: NONE

## 3cb657fedb96653f — brand-lock-extractor/references/extraction-rubric.md:27-27 (heading)

## Palette

Extracted rules inside block: NONE
