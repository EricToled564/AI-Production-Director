# Source coverage review 81/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## d565e9c221ed292f — screenwriter/SKILL.md:8-8 (paragraph)

  WORKFLOW: Raw idea → Scene breakdown → Visual enhancement → Professional formatting → XML-tagged markdown output

Extracted rules inside block: NONE

## 6a0f5b7dbcb50253 — screenwriter/SKILL.md:10-10 (paragraph)

  OUTPUT: Markdown document with XML-wrapped scenes, rich visual descriptions, proper screenplay elements (sluglines, action, dialogue), and metadata for pipeline processing.

Extracted rules inside block: NONE

## 02b2579a0301b53c — screenwriter/SKILL.md:13-13 (heading)

# Screenwriter Skill

Extracted rules inside block: NONE

## 353d55721a2b5380 — screenwriter/SKILL.md:15-15 (heading)

## Overview

Extracted rules inside block: NONE

## 7ceee5547ab431e4 — screenwriter/SKILL.md:17-17 (paragraph)

This skill transforms creative concepts into professional screenplay documents optimized for AI-powered video production pipelines. It bridges the gap between raw story ideas and production-ready scripts by generating structured, visual-rich narratives in industry-standard screenplay format.

Extracted rules inside block: NONE

## b8ea8b0b1b053ccd — screenwriter/SKILL.md:19-19 (paragraph)

**Pipeline Position:** `diverse-content-gen` → **screenwriter** → `imagine` → `arch-v`

Extracted rules inside block: NONE

## 2190990ae9b53a80 — screenwriter/SKILL.md:21-21 (paragraph)

**Key Capabilities:**

Extracted rules inside block: NONE

## b5171c39643611e7 — screenwriter/SKILL.md:22-22 (list_item)

- Convert raw ideas into structured scene-by-scene narratives

Extracted rules inside block: NONE

## 8826f0ff3cc6e71a — screenwriter/SKILL.md:23-23 (list_item)

- Generate rich visual descriptions optimized for image generation

Extracted rules inside block: NONE

## a5ce425ca47df9fe — screenwriter/SKILL.md:24-24 (list_item)

- Apply professional screenplay formatting (sluglines, action lines, dialogue)

Extracted rules inside block: NONE

## 151299f2007bb9ed — screenwriter/SKILL.md:25-25 (list_item)

- Output XML-tagged markdown for easy parsing

Extracted rules inside block: NONE

## 50cf9dc8c0d81205 — screenwriter/SKILL.md:26-26 (list_item)

- Optimize pacing for 5-10 minute short films (8-15 scenes typical)

Extracted rules inside block: NONE

## 8409df415f6d0980 — screenwriter/SKILL.md:30-30 (heading)

## Core Workflow

Extracted rules inside block: NONE

## 1fdaff8ff97914c1 — screenwriter/SKILL.md:32-32 (heading)

### 1. Analyze Input Concept

Extracted rules inside block: NONE

## 959da5ad6b523e75 — screenwriter/SKILL.md:33-33 (list_item)

- Extract key story beats from raw ideas

Extracted rules inside block: NONE

## 599c695d2747914a — screenwriter/SKILL.md:34-34 (list_item)

- Identify characters, locations, emotional arc

Extracted rules inside block: NONE

## 37913bb87a5ce49c — screenwriter/SKILL.md:35-35 (list_item)

- Determine story structure (beginning, middle, end)

Extracted rules inside block: NONE

## 69ec3cf5fcb38b45 — screenwriter/SKILL.md:37-37 (heading)

### 2. Generate Scene Breakdown

Extracted rules inside block: NONE

## 852ef62be4619c19 — screenwriter/SKILL.md:38-38 (list_item)

- Convert story beats into discrete scenes

Extracted rules inside block: NONE

## 48463a8f250ca5bf — screenwriter/SKILL.md:39-39 (list_item)

- Establish scene count (aim for 8-15 scenes for 5-10 min films)

Extracted rules inside block: NONE

## 4833486bf7cdd95c — screenwriter/SKILL.md:40-40 (list_item)

- Define scene purpose and emotional progression

Extracted rules inside block: NONE

## c316dd0904fb0978 — screenwriter/SKILL.md:42-42 (heading)

### 3. Write Professional Screenplay

Extracted rules inside block: NONE

## d096e4e91deeb2e9 — screenwriter/SKILL.md:43-43 (list_item)

- Apply industry-standard formatting

Extracted rules inside block: NONE

## dc8656992cdcd737 — screenwriter/SKILL.md:44-44 (list_item)

- Write visual-rich action lines

Extracted rules inside block: NONE

## c175d2ed907d7ef7 — screenwriter/SKILL.md:45-45 (list_item)

- Include dialogue when narratively essential

Extracted rules inside block: NONE

## f0013f86ea44cc87 — screenwriter/SKILL.md:46-46 (list_item)

- Maintain consistent character descriptions

Extracted rules inside block: NONE

## fef00d46d021c4c1 — screenwriter/SKILL.md:48-48 (heading)

### 4. Output XML-Tagged Markdown

Extracted rules inside block: NONE

## 0d62cb7ec2db7e94 — screenwriter/SKILL.md:49-49 (list_item)

- Wrap each scene in XML tags with metadata

Extracted rules inside block: NONE

## b21298ae6ce04059 — screenwriter/SKILL.md:50-50 (list_item)

- Include scene numbers, locations, key visuals

Extracted rules inside block: NONE

## eb7d8e0535a957ad — screenwriter/SKILL.md:51-51 (list_item)

- Format for easy pipeline parsing

Extracted rules inside block: NONE
