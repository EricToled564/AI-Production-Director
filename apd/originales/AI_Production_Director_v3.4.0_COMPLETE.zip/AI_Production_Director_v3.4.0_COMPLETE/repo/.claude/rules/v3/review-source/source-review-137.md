# Source coverage review 137/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 33b23c87e617e507 — video/references/camera-lighting-vocabulary.md:150-150 (list_item)

- Glazer neon. Black, one dominant neon hue (magenta or teal), hard edges.

Extracted rules inside block: NONE

## 6649816a0a74f405 — video/references/camera-lighting-vocabulary.md:151-151 (list_item)

- Commercial creamy. Warm creams, soft pastels, clean whites, no harsh blacks.

Extracted rules inside block: NONE

## e3a730a1077f3968 — video/references/camera-lighting-vocabulary.md:152-152 (list_item)

- Safdie chaotic. Mixed sources, overlapping color temperatures, urban neon spill.

Extracted rules inside block: NONE

## 27f0a1f1d7a80f31 — video/references/camera-lighting-vocabulary.md:154-154 (heading)

## 8. Sound categories

Extracted rules inside block: NONE

## 85db0117da08e5a1 — video/references/camera-lighting-vocabulary.md:156-156 (paragraph)

Even if the model does not generate audio, sound description helps structure rhythm.

Extracted rules inside block: NONE

## bba0cbc5adfe2c2f — video/references/camera-lighting-vocabulary.md:158-158 (paragraph)

Ambient.

Extracted rules inside block: NONE

## b5522433c563bd7c — video/references/camera-lighting-vocabulary.md:160-160 (list_item)

- room tone

Extracted rules inside block: NONE

## 20ed23d6ff280d5c — video/references/camera-lighting-vocabulary.md:161-161 (list_item)

- distant city ambience

Extracted rules inside block: NONE

## f704923ebc3b74f8 — video/references/camera-lighting-vocabulary.md:162-162 (list_item)

- rain on tin roof

Extracted rules inside block: NONE

## 70637aad82ae4d40 — video/references/camera-lighting-vocabulary.md:163-163 (list_item)

- wind through leaves

Extracted rules inside block: NONE

## f91518011a832d14 — video/references/camera-lighting-vocabulary.md:164-164 (list_item)

- fridge hum

Extracted rules inside block: NONE

## 44759e62b618aabb — video/references/camera-lighting-vocabulary.md:165-165 (list_item)

- fluorescent buzz

Extracted rules inside block: NONE

## 3d7c7c7b5e578373 — video/references/camera-lighting-vocabulary.md:166-166 (list_item)

- traffic wash

Extracted rules inside block: NONE

## 41ff14ae95511afc — video/references/camera-lighting-vocabulary.md:168-168 (paragraph)

Body and action.

Extracted rules inside block: NONE

## 4a5749f43edefc0c — video/references/camera-lighting-vocabulary.md:170-170 (list_item)

- breath

Extracted rules inside block: NONE

## 904ad35d77594fc1 — video/references/camera-lighting-vocabulary.md:171-171 (list_item)

- footsteps

Extracted rules inside block: NONE

## b21b483f87f31140 — video/references/camera-lighting-vocabulary.md:172-172 (list_item)

- fabric rustle

Extracted rules inside block: NONE

## 3e63f593916ce8b7 — video/references/camera-lighting-vocabulary.md:173-173 (list_item)

- fork clink

Extracted rules inside block: NONE

## 35d936371840cfc6 — video/references/camera-lighting-vocabulary.md:174-174 (list_item)

- door hinge

Extracted rules inside block: NONE

## f2377ce7be029f4d — video/references/camera-lighting-vocabulary.md:175-175 (list_item)

- key in lock

Extracted rules inside block: NONE

## d1a05ca0ed3f715b — video/references/camera-lighting-vocabulary.md:176-176 (list_item)

- zipper

Extracted rules inside block: NONE

## e0aaacc6bbbb87a4 — video/references/camera-lighting-vocabulary.md:177-177 (list_item)

- stomach growl

Extracted rules inside block: NONE

## 65137385c4d104a6 — video/references/camera-lighting-vocabulary.md:179-179 (paragraph)

Dramatic events.

Extracted rules inside block: NONE

## 824687490f46def0 — video/references/camera-lighting-vocabulary.md:181-181 (list_item)

- sudden silence

Extracted rules inside block: NONE

## 68e79e4f00e46f57 — video/references/camera-lighting-vocabulary.md:182-182 (list_item)

- low bass hit

Extracted rules inside block: NONE

## ad6055a24fadf487 — video/references/camera-lighting-vocabulary.md:183-183 (list_item)

- wet thud

Extracted rules inside block: NONE

## 4027735fb7e8a3b3 — video/references/camera-lighting-vocabulary.md:184-184 (list_item)

- glass break

Extracted rules inside block: NONE

## 07a3a0392c231f3d — video/references/camera-lighting-vocabulary.md:185-185 (list_item)

- distant thunder

Extracted rules inside block: NONE

## 216c95dc4af6f622 — video/references/camera-lighting-vocabulary.md:186-186 (list_item)

- car door slam

Extracted rules inside block: NONE

## 6628cb83a2d95a28 — video/references/camera-lighting-vocabulary.md:187-187 (list_item)

- final sound cue before cut to black

Extracted rules inside block: NONE
