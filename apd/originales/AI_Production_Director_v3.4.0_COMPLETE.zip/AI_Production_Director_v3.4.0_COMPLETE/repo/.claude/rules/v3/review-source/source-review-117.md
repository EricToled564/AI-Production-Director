# Source coverage review 117/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 3f67f07f0b96e0ee — storyboard-architect/references/timing-rules.md:41-41 (list_item)

- Sentence (≤14 words): 2.4s

Extracted rules inside block: NONE

## 2f2d33c326b85904 — storyboard-architect/references/timing-rules.md:42-42 (list_item)

- Long sentence (15–25 words): 4.0s

Extracted rules inside block: NONE

## a8516e3b07da1bee — storyboard-architect/references/timing-rules.md:44-44 (paragraph)

Multiply by 2 for the "read twice" rule. So a 6-word phrase needs **2.4s on screen minimum**.

Extracted rules inside block: NONE

## 368c9e6a9c62cd23 — storyboard-architect/references/timing-rules.md:46-46 (paragraph)

If a shot is 2 seconds and you need a 14-word sentence, you have a problem. Either:

Extracted rules inside block: NONE

## 285bbbe6b1e5dc9d — storyboard-architect/references/timing-rules.md:47-47 (list_item)

1. Shorten the copy

Extracted rules inside block: ec4c0874b2ca

## b7106190e185e776 — storyboard-architect/references/timing-rules.md:48-48 (list_item)

2. Carry the text across two consecutive shots (text persists during cut)

Extracted rules inside block: bf3249353bc5

## 6a6a46b6ffa362ab — storyboard-architect/references/timing-rules.md:49-49 (list_item)

3. Lengthen the shot

Extracted rules inside block: a25bda670e16

## 6d62a91d78b8fb6a — storyboard-architect/references/timing-rules.md:51-51 (paragraph)

Do not under-time text. It's the most common storyboard failure.

Extracted rules inside block: ff02f075bdd1

## 74098a2585ca1d0d — storyboard-architect/references/timing-rules.md:53-53 (heading)

## Pacing curve

Extracted rules inside block: NONE

## 4ee99fa576644e83 — storyboard-architect/references/timing-rules.md:55-55 (paragraph)

For 30-second content, the natural energy curve:

Extracted rules inside block: NONE

## e5f745487f179c68 — storyboard-architect/references/timing-rules.md:57-69 (code)

```
0s ─────────────────────────────────── 30s

Energy
  ▲     ╱╲
  │    ╱  ╲___
  │   ╱       ╲___
  │  ╱            ╲___
  │ ╱                 ╲___
  └─────────────────────────►
   hook  build  apex  release  CTA
   0-2   2-12   12-20  20-26   26-30
```

Extracted rules inside block: NONE

## a3f70c31eaeb186a — storyboard-architect/references/timing-rules.md:71-71 (paragraph)

The apex is two-thirds in, not at the end. The CTA is a release, not a peak.

Extracted rules inside block: NONE

## 414f8a35ca5960a6 — storyboard-architect/references/timing-rules.md:73-73 (paragraph)

For 60-second content, scale the same curve. Apex around 0:40, CTA from 0:50.

Extracted rules inside block: NONE

## d499d1d31aae6174 — storyboard-architect/references/timing-rules.md:75-75 (heading)

## Validating timing

Extracted rules inside block: NONE

## db318b720cc21afa — storyboard-architect/references/timing-rules.md:77-77 (paragraph)

Before declaring done, check:

Extracted rules inside block: NONE

## 2926a01f9dfc089d — storyboard-architect/references/timing-rules.md:79-79 (list_item)

1. Sum of `(end - start)` across all shots equals project duration ±0.1s

Extracted rules inside block: f9af9860178d

## 13669b3eef4f8db7 — storyboard-architect/references/timing-rules.md:80-80 (list_item)

2. No shot has `start >= end`

Extracted rules inside block: cd565c13f988

## 16a859d7f248c421 — storyboard-architect/references/timing-rules.md:81-81 (list_item)

3. No two shots overlap

Extracted rules inside block: 764b335de819

## 74073c2e5f42cc26 — storyboard-architect/references/timing-rules.md:82-82 (list_item)

4. First shot starts at 0.0

Extracted rules inside block: 1ccd238bc538

## 26c748e3dc4838a5 — storyboard-architect/references/timing-rules.md:83-83 (list_item)

5. Last shot ends at project duration

Extracted rules inside block: df2b4c151a73

## 0c22710fa1528456 — storyboard-architect/references/timing-rules.md:84-84 (list_item)

6. Every text overlay's `enter.at` is ≥ its shot's `start`

Extracted rules inside block: e80ce7b451fc

## 28656fd6b154e97a — storyboard-architect/references/timing-rules.md:85-85 (list_item)

7. Every text overlay's `exit.at` is ≤ its shot's `end` (or carries to a flagged successor shot)

Extracted rules inside block: c6863cce2359

## 158a3f57cecac987 — storyboard-architect/references/timing-rules.md:86-86 (list_item)

8. Every text overlay's on-screen duration ≥ read-twice threshold

Extracted rules inside block: 308b09ac4f3f

## 6c4a2180ddca68f2 — storyboard-architect/tools/README.md:1-1 (heading)

# Tools

Extracted rules inside block: NONE

## 033dbdda14776d0d — storyboard-architect/tools/README.md:3-4 (paragraph)

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

Extracted rules inside block: NONE

## 989766e53be63dd0 — storyboard-architect/tools/README.md:6-6 (heading)

## Requirements

Extracted rules inside block: NONE

## c43fbb140491951f — storyboard-architect/tools/README.md:8-10 (code)

```bash
pip install pyyaml jsonschema
```

Extracted rules inside block: NONE

## 98c065c50029aedd — storyboard-architect/tools/README.md:12-12 (paragraph)

Standard library otherwise. No pandas, no numpy.

Extracted rules inside block: NONE

## ac50b61f40c6bd44 — storyboard-architect/tools/README.md:14-14 (heading)

## Run everything

Extracted rules inside block: NONE

## c9a042679a2deb8b — storyboard-architect/tools/README.md:16-20 (code)

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

Extracted rules inside block: NONE
