# Source coverage review 129/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 2f5ce7eb0882a690 — video/references/animatic-keyframes.md:9-9 (heading)

## Contents

Extracted rules inside block: NONE

## 4c7dac5428147f35 — video/references/animatic-keyframes.md:11-11 (list_item)

1. What an animatic keyframe must do

Extracted rules inside block: 730b961b5aeb

## eb12389c69781e1c — video/references/animatic-keyframes.md:12-12 (list_item)

2. The keyframe card (a still extension of the shot card)

Extracted rules inside block: 9b8b04fe6321

## 37bb6a15c54e5444 — video/references/animatic-keyframes.md:13-13 (list_item)

3. How many keyframes per beat (density ladder)

Extracted rules inside block: 57d7260aba87

## 39518c56caa15878 — video/references/animatic-keyframes.md:14-14 (list_item)

4. Composing a still that reads as MOTION

Extracted rules inside block: a409d8e5eca0

## 43abdbaab3988056 — video/references/animatic-keyframes.md:15-15 (list_item)

5. Emotion without faces in a still

Extracted rules inside block: 09e32d358d9a

## 7b6e7e0f837d73c3 — video/references/animatic-keyframes.md:16-16 (list_item)

6. The loaded frame for one panel

Extracted rules inside block: 5199869d2d80

## 5325fd5da27f4e25 — video/references/animatic-keyframes.md:17-17 (list_item)

7. From keyframe to image-gen prompt

Extracted rules inside block: 8129d4aecb9c

## e9b7c3bf73d660bd — video/references/animatic-keyframes.md:18-18 (list_item)

8. Worked keyframe board for a 30s race spot

Extracted rules inside block: e0c9d226d330

## 786a6cf70e898121 — video/references/animatic-keyframes.md:19-19 (list_item)

9. Checklist: does this keyframe earn its place

Extracted rules inside block: 79c8d29dfdd2

## 9f053a754c28aa3d — video/references/animatic-keyframes.md:23-23 (heading)

## 1. What an animatic keyframe must do

Extracted rules inside block: NONE

## 465e3ed3276bc3cc — video/references/animatic-keyframes.md:25-25 (paragraph)

In an animatic the **panel is the unit, not the shot.** A shot has duration, motion, and sound to carry its function across time. A keyframe has one frozen image and must carry the same function in a single glance. So every panel does four things at once, in one still:

Extracted rules inside block: 0ecae47aab7b

## 68dafb8161e435f1 — video/references/animatic-keyframes.md:27-27 (list_item)

- **One readable story-beat** — name it in one sentence before generating. If you cannot, the panel is not ready (`dramaturgy.md` §1).

Extracted rules inside block: NONE

## 2159be8bf7c5f643 — video/references/animatic-keyframes.md:28-28 (list_item)

- **One function tag** — Establish / Reveal / Power / Pressure / Detail / Reaction / Shift / Impact / Aftermath / Exit (`role-modes.md` §4). The tag is the question the panel answers. In a faceless spot **Reaction** is reassigned from a human face to the *machine's* face — the needle jumping, the slick wrinkling, the nose squatting. Treat gauges and rubber as the actor.

Extracted rules inside block: NONE

## 0a399a0cd4de1e0c — video/references/animatic-keyframes.md:29-29 (list_item)

- **One emotion** — routed through metal, rubber, light, or anatomy, never named (`dramaturgy.md` §2). Mixed signals = no signal.

Extracted rules inside block: 03d9c087792b

## 45e54c82e099dde2 — video/references/animatic-keyframes.md:30-30 (list_item)

- **One implied motion** — the movement the still cannot perform, frozen as its physical residue (§4).

Extracted rules inside block: NONE

## c88284a3b1226822 — video/references/animatic-keyframes.md:32-32 (paragraph)

A panel that carries a beat, a function, an emotion, and an implied motion earns its place. A panel missing any of the four is a *fantik* — wrapper without candy (`dramaturgy.md` §3). The discipline of this whole file is: **you cannot prompt "motion" or "emotion" into a still — you prompt the physical consequence each leaves behind.**

Extracted rules inside block: NONE

## 204003952f7ecdfd — video/references/animatic-keyframes.md:36-36 (heading)

## 2. The keyframe card

Extracted rules inside block: NONE

## 7e3c9ee8608abc90 — video/references/animatic-keyframes.md:38-38 (paragraph)

The shot card in `dramaturgy.md` §11 describes a moving shot. A keyframe needs a *still*-specific card: every field describes a frozen image, and three fields are new (implied camera, emotion-via-object, motion-rendered-as-still). Fill every field before generating. Empty fields reveal missing direction.

Extracted rules inside block: NONE

## f4b33d9e322dd612 — video/references/animatic-keyframes.md:40-65 (code)

```text
KEYFRAME CARD
- Panel ID.            01, 02, 03
- Timecode.            on-screen life in the animatic (e.g. 0:10.5, HOLD 2s)
- Function tag.        Establish / Reveal / Power / Pressure / Detail /
                       Reaction / Shift / Impact / Aftermath / Exit
- Beat.                what changes in the story in this one still
- Framing + lens.      ECU / CU / MCU / wide / macro insert / POV + lens token
                       (24mm immersive ... 100mm macro — camera-lighting-vocabulary.md §3)
- Subject / anchor.    the ONE object or anatomy the eye lands on in 0.3s
- Depth layers.        FG job (frame / obstruct / put us inside)
                       MG job (the subject / the act)
                       BG job (stakes / context / rival)
- Implied camera.      the move this still is the first frame OF
                       (push-in, whip, bumper-POV, joust) — what it would do if it ran
- Light + palette.     one motivated source + direction + the surface it rims;
                       concrete colors, amber-ban repeated
- Emotion-via-object.  the feeling a face would show, mapped to an object's state (§5)
- Motion-as-still.     which frozen cue carries the missing movement (§4):
                       smear / partial blur / streak / vector / sharp-blur / held stillness
- Caption / label.     one word: setup / commitment / mistake / recovery /
                       proof-of-speed / result
- Sound.               what audio sits under the held frame, where the cut bites
                       (fill even though it is a still — dramaturgy.md §11)
- Production note.      prop, rig, continuity anchor
```

Extracted rules inside block: NONE

## 5349c1d33d25dbd4 — video/references/animatic-keyframes.md:67-67 (paragraph)

The card maps straight onto format C: `Function`, `Framing`, `Implied camera`, `Light`, `Sound`, `Emotion-via-object` become the table columns. The three still-specific fields — **implied camera, emotion-via-object, motion-as-still** — are the ones a normal shot card does not force you to name, and they are exactly the ones that keep a panel from going flat.

Extracted rules inside block: NONE

## e2df2baec96806d3 — video/references/animatic-keyframes.md:71-71 (heading)

## 3. How many keyframes per beat — the density ladder

Extracted rules inside block: NONE

## e85c2cc1061bfc34 — video/references/animatic-keyframes.md:73-73 (paragraph)

**Loudness in the audio = panel count in the board.** Silence gets one held panel; a bang gets a burst. This is the still-panel reading of `dramaturgy.md` §12 (rhythm ladder) and `role-modes.md` §3 (editor density: 3-4 beats/5s drama, 4-7 narrative, 6-9 fast montage). The full 30s beat map is the worked board in §8; split it per `patterns-and-genres.md` §3 (30s = 6×5s).

Extracted rules inside block: NONE

## 861a09f68d1941a7 — video/references/animatic-keyframes.md:75-75 (table_row)

| Beat | Density | Panels | Why |

Extracted rules inside block: NONE

## 5a571fcdad561ac0 — video/references/animatic-keyframes.md:77-77 (table_row)

| **Ritual / staging** (quiet) | 1 hero panel, held | 1 panel living 1.5-2.5s | A silent beat is monolithic. Do not subdivide it — its power is that nothing moves while the world holds its breath. One symmetric "breath" frame, most negative space, least motion. |

Extracted rules inside block: 49f066816332

## 78433c3998a80bde — video/references/animatic-keyframes.md:78-78 (table_row)

| **Pressure climbing** (amber stagger) | escalating singles | 3 panels, collapsing length | The Sportsman tree fires three ambers 0.5s apart — three drawable panels, each tighter than the last, cut length collapsing toward the green. |

Extracted rules inside block: NONE

## da35204a5f72c0f3 — video/references/animatic-keyframes.md:79-79 (table_row)

| **Launch / impact** (bang) | 3-panel micro-burst → up to 6-9 | 6-9 panels at 8fr → 4fr | The audio bang is rendered as panel *density*, not one big image. Hip-hop montage: bumper-POV smear, side wheelspin, tach flare, clutch hand, lane-stripe strobe. |

Extracted rules inside block: NONE

## 9ed2e9eeea9e9e24 — video/references/animatic-keyframes.md:80-80 (table_row)

| **Contest** (sustained roar) | alternating | fragment-cluster ↔ one held detail | Never two bang-clusters back to back. Between every burst, one held quiet panel — loud only works next to quiet. |

Extracted rules inside block: 84ae4cd8cd89

## 9edbd072c3944927 — video/references/animatic-keyframes.md:81-81 (table_row)

| **Aftermath / exit** (cut to silence) | 1 hero panel, held | 1-2 panels, ~2s hold | End on consequence, not explanation. One held still: drifting smoke, hand unclenching, car nosing into dark. |

Extracted rules inside block: NONE

## 371176f425a929f1 — video/references/animatic-keyframes.md:83-83 (paragraph)

**Allocation rule.** A 30s spot lands at ~18-26 panels. Plot the board as a descending duration staircase (≈2.5s → 0.5s → 4fr), broken only by the one pre-launch pause and the one post-finish hold. The board should *read* as an accelerating tachometer even on mute. Give a beat a micro-burst only when the audio detonates; everywhere else, one panel that holds is stronger than three that scatter.

Extracted rules inside block: 3b3192ce4fec
