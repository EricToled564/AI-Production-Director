# Source coverage review 208/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0cf80b92c0a91a2a — visual-prompt-forge/adapters/gpt-image.md:87-87 (list_item)

- **Don't omit spatial language when the shot has specific composition**, you're paying for the model's strength; use it

Extracted rules inside block: e4e1baf250ad

## 5020ee987215136c — visual-prompt-forge/adapters/gpt-image.md:88-88 (list_item)

- **Don't pile too many objects**, five or fewer distinct elements per scene; more degrades fidelity

Extracted rules inside block: f1515dd84053

## 491590c4f4340f30 — visual-prompt-forge/adapters/gpt-image.md:89-89 (list_item)

- **Don't include `--ar` flags or weight syntax**. GPT Image ignores them

Extracted rules inside block: be630ba24dc2

## c088c33cfa782ad8 — visual-prompt-forge/adapters/gpt-image.md:90-90 (list_item)

- **Don't forget that GPT Image's "AI look" is real**, the closing "natural skin texture, no AI rendering artifacts" line meaningfully helps but isn't a complete fix. For pure photoreal, Flux is still stronger

Extracted rules inside block: 861a8ef44da3

## 35912a92a4d52c7c — visual-prompt-forge/adapters/gpt-image.md:92-92 (heading)

## API access

Extracted rules inside block: NONE

## f23aa96e1de8419d — visual-prompt-forge/adapters/gpt-image.md:94-94 (paragraph)

GPT Image is OpenAI-only as of Q2 2026. Standard `images.generate` endpoint. Pricing roughly $0.04–0.08 per image depending on size and quality. ChatGPT Plus and above gives UI access.

Extracted rules inside block: NONE

## c8885a01a0be3331 — visual-prompt-forge/adapters/hailuo.md:1-1 (heading)

# Adapter: Hailuo 02 Pro (motion-aware video, budget iteration)

Extracted rules inside block: NONE

## 5d2cab4aacf0b3c5 — visual-prompt-forge/adapters/hailuo.md:3-3 (list_item)

> Capability data (length ceiling, text/motion support, aspect param) is canonical in `_capabilities.json`. This file is the how-to-prompt guidance. `max_prompt_words` there is a ceiling; the range below is the recommended target and has to sit inside it. Where a fact here and a fact in the JSON disagree, the JSON wins, and `tools/validate_capabilities.py` fails the build instead of letting the two drift.

Extracted rules inside block: 5ce00000875d

## bc4c0e5da2682465 — visual-prompt-forge/adapters/hailuo.md:5-5 (paragraph)

Hailuo 02 Pro is the cheap, fast iteration model. Strong motion response and prompt-following for the price, on fal.ai. Use it to **find the shot**, block out camera move, framing, and timing across many quick drafts, then re-generate the keeper on Kling (motion finals), Veo (dialogue), or Seedance (sequences). Treat Hailuo output as a working draft, not a final asset.

Extracted rules inside block: dbb744321bd2

## 8b58efd2716edeab — visual-prompt-forge/adapters/hailuo.md:7-7 (paragraph)

With video the **camera motion is load-bearing**. The prompt anatomy matches Kling; the difference is cost and intent: iterate freely here.

Extracted rules inside block: NONE

## 5151e9291094a7e3 — visual-prompt-forge/adapters/hailuo.md:9-9 (heading)

## Syntax pattern

Extracted rules inside block: NONE

## e859b4dbf8463feb — visual-prompt-forge/adapters/hailuo.md:11-13 (code)

```
{Camera motion sentence, leading.} {Subject and action over the duration.} {Environment and lighting from series_lock.} {Color grade and mood from brand_lock.}
```

Extracted rules inside block: NONE

## c24bdd55040a18e9 — visual-prompt-forge/adapters/hailuo.md:15-15 (heading)

## Parameters

Extracted rules inside block: NONE

## f28b07a4c756ce89 — visual-prompt-forge/adapters/hailuo.md:17-17 (table_row)

| Parameter | Default | Notes |

Extracted rules inside block: NONE

## fc179ea521a4d81f — visual-prompt-forge/adapters/hailuo.md:19-19 (table_row)

| `duration` | `6s` | Check the current fal.ai ceiling for the Pro tier |

Extracted rules inside block: NONE

## 8812a1397abe1f6b — visual-prompt-forge/adapters/hailuo.md:20-20 (table_row)

| `aspect_ratio` | from `project.aspect` | |

Extracted rules inside block: NONE

## a491bb3931b334cd — visual-prompt-forge/adapters/hailuo.md:21-21 (table_row)

| `start_image` | optional | Image-to-video from an accepted still |

Extracted rules inside block: NONE

## c1dc425636560a60 — visual-prompt-forge/adapters/hailuo.md:22-22 (table_row)

| `prompt_optimizer` | `false` for series | Auto-rewrite helps one-offs but breaks shot-to-shot consistency |

Extracted rules inside block: NONE

## a8badcb369c3e2a8 — visual-prompt-forge/adapters/hailuo.md:24-27 (code)

```
# shot_01 (draft). Hailuo 02 Pro: duration=6s, ar=9:16, optimizer=false
{prompt}
```

Extracted rules inside block: NONE

## 5f0862be6fffd03c — visual-prompt-forge/adapters/hailuo.md:29-29 (heading)

## Length

Extracted rules inside block: NONE

## 33c6c6d69dd2e118 — visual-prompt-forge/adapters/hailuo.md:31-31 (paragraph)

Hailuo handles **60–120 words** efficiently. Shorter than Kling/Veo. Keep drafts lean, you are testing motion and framing, not final polish.

Extracted rules inside block: NONE

## cc8a299c2b86df3e — visual-prompt-forge/adapters/hailuo.md:33-33 (heading)

## Motion vocabulary

Extracted rules inside block: NONE

## debb0c8abe029e2e — visual-prompt-forge/adapters/hailuo.md:35-35 (paragraph)

The shot grammar `motion` field maps directly. One move per shot.

Extracted rules inside block: NONE

## 3067ab5b20710541 — visual-prompt-forge/adapters/hailuo.md:37-37 (table_row)

| `motion` | Video prompt phrase |

Extracted rules inside block: NONE

## f6b4f2b3f48aed3a — visual-prompt-forge/adapters/hailuo.md:39-39 (table_row)

| `static` | "Static camera, locked off." |

Extracted rules inside block: NONE

## 24ae4f0c235788ab — visual-prompt-forge/adapters/hailuo.md:40-40 (table_row)

| `push` / `pull` | "Camera dollies forward / backward slowly." |

Extracted rules inside block: NONE

## 956e639fbaa7e972 — visual-prompt-forge/adapters/hailuo.md:41-41 (table_row)

| `pan-left` / `pan-right` | "Camera pans smoothly left / right." |

Extracted rules inside block: NONE

## 4eaebdc3cbd2bdbe — visual-prompt-forge/adapters/hailuo.md:42-42 (table_row)

| `tilt-up` / `tilt-down` | "Camera tilts up / down." |

Extracted rules inside block: NONE

## bc7d5b75839af80e — visual-prompt-forge/adapters/hailuo.md:43-43 (table_row)

| `handheld` | "Handheld camera, subtle organic movement." |

Extracted rules inside block: NONE

## 9b29be4e1bcbdd45 — visual-prompt-forge/adapters/hailuo.md:44-44 (table_row)

| `orbit` | "Camera orbits the subject slowly." |

Extracted rules inside block: NONE
