# Source coverage review 202/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0c198c003b0b6c3e — visual-prompt-forge/SKILL.md:194-195 (list_item)

1. Read every critique under `output/critiques/round-{N}/`, where N is the highest round
   present. Each file is one shot's verdict (`shot_id`, `verdict`, `issues[]`).

Extracted rules inside block: 06d582a10917

## d73e4b674e203c87 — visual-prompt-forge/SKILL.md:196-196 (list_item)

2. Skip any with `verdict: ACCEPT`. Those are done.

Extracted rules inside block: 4db2040b3898

## 7b9211e70737ab24 — visual-prompt-forge/SKILL.md:197-202 (list_item)

3. **Stop on `REJECT`.** A REJECT means the critic found a blocking issue, or three or more
   major ones: a failure with no clear fix path. Re-emitting a prompt for it pretends
   otherwise. List the rejected shots, say what the critic said about them, and ask the
   user how to proceed. Common answers are a change to the shot spec, a change to the
   brand-lock, or a different generator, and all three are decisions above this skill's
   pay grade.

Extracted rules inside block: 84006ac13e03

## 9f3a6dacc13ed1f4 — visual-prompt-forge/SKILL.md:203-203 (list_item)

4. For every `REVISE` shot, walk its `issues[]` and branch on `fix_type`:

Extracted rules inside block: ea14c0670fd8

## 7ca296acd10b07aa — visual-prompt-forge/SKILL.md:204-205 (list_item)

   - **`prompt-level`**, recompose that shot's prompt with the change in `fix` applied
     (e.g. add the missing series_lock anchor). Re-emit it.

Extracted rules inside block: NONE

## b1d8aff468caa0d4 — visual-prompt-forge/SKILL.md:206-208 (list_item)

   - **`re-roll`**, keep the prompt identical; the generation was just a bad sample.
     Re-emit it with a `# fix [Technical, re-roll]` annotation saying to take 2-3 samples
     and pick the cleanest.

Extracted rules inside block: NONE

## 3fb8734800b05362 — visual-prompt-forge/SKILL.md:209-210 (list_item)

   - **`post-level`**, do **not** re-emit. The fix happens in compositing, not a new
     generation.

Extracted rules inside block: NONE

## 63fbc802123a52c4 — visual-prompt-forge/SKILL.md:211-214 (list_item)

5. A shot whose issues are all `post-level` needs no new prompt. Leave it out of the
   revised file and add its id to `post_only_shots` on the new round entry in `run.json`.
   Saying it in chat is not recording it: that obligation has to exist on disk or the
   compositing step is a memory.

Extracted rules inside block: cac06ecf1dbb

## c414256d739b74ea — visual-prompt-forge/SKILL.md:215-215 (list_item)

6. Re-apply the five-layer anatomy and the same adapter as the original run.

Extracted rules inside block: a14965fcf95c

## 9f442c543559a47d — visual-prompt-forge/SKILL.md:217-217 (heading)

### Output

Extracted rules inside block: NONE

## 9cb9b9f4d17af188 — visual-prompt-forge/SKILL.md:219-221 (paragraph)

Write `output/prompts/round-{N+1}/revised-{generator}.txt` containing only the revised
shots, then append the round to `run.json`. Annotate each shot with what changed and why,
citing the issue:

Extracted rules inside block: NONE

## c834e98f6d37a55b — visual-prompt-forge/SKILL.md:223-228 (code)

```
# shot_03, reframe, 11.0-16.0s, MCU eye-level push, revision (was REVISE)
# fix [Series Lock, major]: added 'salt-and-pepper hair' to the character anchor (was missing)
# fix [Shot Spec, minor]: medium shot -> medium close-up
{the revised prompt}
```

Extracted rules inside block: NONE

## a2b9d5dcb8d25f6a — visual-prompt-forge/SKILL.md:230-233 (paragraph)

The block header leads with the shot id, same as a full pass. `tools/copy-prompt.py`
identifies a block by the shot id near the start of the line, so a header that led with
"Revision of" produced a file the paste helper could not read at all, which is
inconvenient in the one file the operator is about to paste from repeatedly.

Extracted rules inside block: NONE

## 447616dcb62ab38a — visual-prompt-forge/SKILL.md:235-237 (paragraph)

Tell the user which shots were revised, which need only post work, which were rejected,
and which were already ACCEPT. Then they generate the revised shots and run
`visual-asset-critic` again.

Extracted rules inside block: NONE

## 6c823329de4b4d3a — visual-prompt-forge/SKILL.md:239-239 (heading)

### Determinism, and its limits

Extracted rules inside block: NONE

## a45226b1924c830a — visual-prompt-forge/SKILL.md:241-243 (paragraph)

Given the same `shots.json`, the same brand-lock, and the same critique, this should
produce the same revised prompt. Nothing in the file format fights that any more: no
wall-clock stamps, no random ordering.

Extracted rules inside block: 712bf1463bbc

## 31b7e567d2ca5a38 — visual-prompt-forge/SKILL.md:245-249 (paragraph)

What the format cannot guarantee is the judgement in between. Applying a `fix` field means
reading a sentence of English and editing prose, so hold yourself to the narrowest edit
that satisfies the fix and leave every other layer byte-identical. If you find yourself
rewriting a prompt the critique did not ask you to touch, stop: that is drift, and it will
read as a mystery six shots later.

Extracted rules inside block: NONE

## 81e41d1df83737bb — visual-prompt-forge/SKILL.md:251-251 (heading)

## Hard rules

Extracted rules inside block: NONE

## 016a91857264e0d3 — visual-prompt-forge/SKILL.md:253-253 (paragraph)

These are non-negotiable. Violating them produces broken output even if the prompt looks fine.

Extracted rules inside block: NONE

## 2bf9be2236b5f20f — visual-prompt-forge/SKILL.md:255-255 (heading)

### Rule 1. Text is never in the prompt

Extracted rules inside block: NONE

## 465cfb9eb9e6b6a4 — visual-prompt-forge/SKILL.md:257-257 (paragraph)

If the shot has `on_screen_text: "text_03"`, the prompt does NOT contain the text content. Text is composited separately. The only exception: Ideogram, where text-in-image is the reason you'd choose it, but even then, treat it as an explicit override flagged in rationale.

Extracted rules inside block: NONE

## 03f4207cc27e58b4 — visual-prompt-forge/SKILL.md:259-259 (heading)

### Rule 2. Brand colors never in shot subject prose

Extracted rules inside block: NONE

## c5d22aa5867817f9 — visual-prompt-forge/SKILL.md:261-261 (paragraph)

Colors come from the series_lock color_grade and the brand_lock palette. They get rendered into the prompt by the adapter. Don't write "deep navy blazer" in the shot subject if "deep navy" is already in the palette, that's a duplicated description and produces oversaturation.

Extracted rules inside block: 8cecada8588a

## b69218aa8e8dd81a — visual-prompt-forge/SKILL.md:263-263 (heading)

### Rule 3. Series_lock anchors are verbatim

Extracted rules inside block: NONE

## e13b79c1e3e32eab — visual-prompt-forge/SKILL.md:265-267 (paragraph)

The series_lock `environment`, `lighting`, and `color_grade` strings flow into every
prompt **verbatim**. This is what produces visual consistency across shots. If you
paraphrase or vary, shots stop matching each other.

Extracted rules inside block: NONE

## 3ead738898acfc46 — visual-prompt-forge/SKILL.md:269-274 (paragraph)

Verbatim means the whole string, unedited. Not "the same idea in better prose". The
failure mode is specific and easy to walk into: you are writing fluent descriptive
English, `environment` is "minimalist home office, white walls, oak desk, single
houseplant", and it reads more naturally as "a minimal home office with white walls and
an oak desk". That is drift. The frames stop matching, and it stays invisible until you
line up six shots and see six different rooms.

Extracted rules inside block: NONE

## 01296674f9b5410f — visual-prompt-forge/SKILL.md:276-279 (paragraph)

Capitalising the first letter to start a sentence is fine, because the check is
case-insensitive. "Minimalist home office, white walls, oak desk, single houseplant."
satisfies the rule and reads like a sentence. Nothing else may change: no reordering, no
dropped clause, no synonym, no inserted adjective.

Extracted rules inside block: NONE

## e34503aedc5d6106 — visual-prompt-forge/SKILL.md:281-282 (paragraph)

`character` is a warning rather than an error, because a shot with no person in it can
legitimately leave it out. When the shot has a person, it is verbatim too.

Extracted rules inside block: NONE

## 897477a233b7de1d — visual-prompt-forge/SKILL.md:284-284 (paragraph)

This rule is enforced now, not trusted:

Extracted rules inside block: NONE

## a6c1676686932f62 — visual-prompt-forge/SKILL.md:286-288 (code)

```bash
python tools/validate_prompts.py output/
```

Extracted rules inside block: NONE
