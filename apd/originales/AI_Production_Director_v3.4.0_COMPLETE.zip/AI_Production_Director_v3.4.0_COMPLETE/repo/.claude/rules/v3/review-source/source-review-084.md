# Source coverage review 84/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 229d629effc39c03 — screenwriter/SKILL.md:158-158 (list_item)

- `SMASH CUT TO:` - Abrupt, jarring transition

Extracted rules inside block: NONE

## 535b7a2e6bef9e46 — screenwriter/SKILL.md:159-159 (list_item)

- `DISSOLVE TO:` - Passage of time

Extracted rules inside block: NONE

## 387dbc00bece1ac0 — screenwriter/SKILL.md:160-160 (list_item)

- `FADE OUT.` - End of screenplay

Extracted rules inside block: NONE

## 4406fea956e7440d — screenwriter/SKILL.md:162-162 (paragraph)

**Modern Best Practice:** Most transitions are IMPLIED. Use sparingly, only for specific narrative effect.

Extracted rules inside block: 79e3e9bf47d7

## 56338b64454d95d7 — screenwriter/SKILL.md:166-166 (heading)

## XML Output Format

Extracted rules inside block: NONE

## 3109b6aee76b8831 — screenwriter/SKILL.md:168-168 (heading)

### Scene Tag Structure

Extracted rules inside block: NONE

## 76a0476cd2369f1c — screenwriter/SKILL.md:170-170 (paragraph)

Each scene wrapped in XML with metadata for pipeline processing:

Extracted rules inside block: NONE

## 3a7ef66b063db1d9 — screenwriter/SKILL.md:172-192 (code)

```xml
<scene number="1" duration="30-45s">
  <slugline>EXT. WASTELAND - DAWN</slugline>
  <location>Wasteland</location>
  <time>Dawn</time>
  <characters>Unit-7</characters>
  <mood>desolate, lonely</mood>
  <key_visuals>
    <visual>post-apocalyptic wasteland with ruined skyscrapers</visual>
    <visual>boxy robot with single blue optical sensor</visual>
    <visual>dust and smog atmosphere, weak pale sun</visual>
  </key_visuals>
  <action>
Gray dust covers everything. Skeletal remains of skyscrapers pierce the horizon. The sun, pale and weak, struggles through thick smog.

A ROBOT (Unit-7, boxy frame with single blue optical sensor) rolls across cracked asphalt. Its treads leave marks in the dust—the only sign of life.

The robot stops at a pile of rubble, extending a mechanical arm to sort through debris. Methodical. Purposeful. Lonely.
  </action>
</scene>
```

Extracted rules inside block: NONE

## 461e120025bcfd58 — screenwriter/SKILL.md:194-194 (heading)

### Metadata Fields

Extracted rules inside block: NONE

## 1461b0a505105abd — screenwriter/SKILL.md:196-196 (list_item)

- `number`: Scene sequence number (1, 2, 3...)

Extracted rules inside block: NONE

## 2ebd343ae010b46c — screenwriter/SKILL.md:197-197 (list_item)

- `duration`: Estimated screen time (for 5-10 min total)

Extracted rules inside block: NONE

## 017607fe32a4e69f — screenwriter/SKILL.md:198-198 (list_item)

- `slugline`: Master scene heading

Extracted rules inside block: NONE

## 701e73c7e0eb92a7 — screenwriter/SKILL.md:199-199 (list_item)

- `location`: Extracted location name

Extracted rules inside block: NONE

## fe58f8c36841f46d — screenwriter/SKILL.md:200-200 (list_item)

- `time`: Time of day

Extracted rules inside block: NONE

## 32c43968ab74c586 — screenwriter/SKILL.md:201-201 (list_item)

- `characters`: Comma-separated character list

Extracted rules inside block: NONE

## 4fdaae7f33ae8d68 — screenwriter/SKILL.md:202-202 (list_item)

- `mood`: Emotional tone/atmosphere

Extracted rules inside block: NONE

## c7bca9926ba9009d — screenwriter/SKILL.md:203-203 (list_item)

- `key_visuals`: Array of specific visual elements for image generation

Extracted rules inside block: NONE

## 1c6c3fa65e387fd9 — screenwriter/SKILL.md:204-204 (list_item)

- `action`: The full action/description text

Extracted rules inside block: NONE

## 30a2aae1296d6834 — screenwriter/SKILL.md:205-205 (list_item)

- `dialogue` (optional): Character dialogue if present

Extracted rules inside block: NONE

## ce161d6f583b7e53 — screenwriter/SKILL.md:209-209 (heading)

## Short Film Structure (5-10 Minutes)

Extracted rules inside block: NONE

## 0fb6010cb6f13ec9 — screenwriter/SKILL.md:211-211 (heading)

### Scene Count Guidelines

Extracted rules inside block: NONE

## 6b91a3669cfd9c61 — screenwriter/SKILL.md:212-212 (list_item)

- **5 minutes:** 6-10 scenes

Extracted rules inside block: NONE

## 708ee8ce45d0f2f8 — screenwriter/SKILL.md:213-213 (list_item)

- **7 minutes:** 10-12 scenes

Extracted rules inside block: NONE

## 14e3ff6cd3619357 — screenwriter/SKILL.md:214-214 (list_item)

- **10 minutes:** 12-15 scenes

Extracted rules inside block: NONE

## 018f55a316e376c1 — screenwriter/SKILL.md:216-216 (paragraph)

**Average:** ~30-60 seconds per scene

Extracted rules inside block: NONE

## 91f2b9761bdead49 — screenwriter/SKILL.md:218-218 (heading)

### Three-Act Structure (Compressed)

Extracted rules inside block: NONE

## 77870491e49de25b — screenwriter/SKILL.md:220-220 (paragraph)

**Act 1 - Setup (20-25%):** 2-3 scenes

Extracted rules inside block: NONE

## 2040e88cc4d2504a — screenwriter/SKILL.md:221-221 (list_item)

- Establish world, character, situation

Extracted rules inside block: NONE

## 0859d1de1d9cea24 — screenwriter/SKILL.md:222-222 (list_item)

- Inciting incident

Extracted rules inside block: NONE

## 80a4d7ab5e4702d9 — screenwriter/SKILL.md:224-224 (paragraph)

**Act 2 - Confrontation (50-60%):** 4-8 scenes

Extracted rules inside block: NONE
