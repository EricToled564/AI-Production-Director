# Source coverage review 18/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 0e1790b941569a12 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:3-5 (paragraph)

**Fecha:** 2026-05-27
**Origen:** Retrospectiva F7 sesión 2026-05-27.
**Tipo de versión:** v6.0 → v6.1 (cambio MAYOR — añade regla inviolable + mecanismo de override).

Extracted rules inside block: NONE

## 2ffe7c7b2008f5d2 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:7-7 (heading)

## Cambio 1 — Nueva Regla 28

Extracted rules inside block: NONE

## 2eb01d4cebf8efb6 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:9-9 (heading)

### Ubicación

Extracted rules inside block: NONE

## 26de71db24999125 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:10-10 (paragraph)

Sección 14 "REGLAS INVIOLABLES" — añadir como #28, después de Regla 27 actual.

Extracted rules inside block: NONE

## 0d5c6887a7273dd6 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:12-12 (heading)

### Texto a añadir

Extracted rules inside block: NONE

## 33e0776a2d9a0ebb — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:14-16 (code)

```
28	LINTER DETERMINISTA OBLIGATORIO ANTES DE ENTREGAR PROMPT — Para todos los casos (1/2/3a/3b/3c/4), ejecutar `aurora-linter/prompt_linter.py` al final del Step 4 drafting con: prompt, refs tageadas por categoría (P/O/L/PR/S según IDs system §7), case_type, y mensaje completo del usuario en el turno actual para parsear OVERRIDEs. Si STATUS=FAIL sin overrides que cubran todas las violaciones, NO entregar al usuario — iterar el draft hasta PASS. El reporte del linter (PASS/FAIL + violaciones + overrides aceptados) se incluye en el output visible al usuario para trazabilidad. Override de violación requiere autorización expresa del usuario por escrito en el turno actual con sintaxis `OVERRIDE: <término-o-categoría> - <razón>`; frases genéricas ("dale", "hazlo ya", "ready to copy paste") NO cuentan como override. Las autorizaciones NO persisten entre turnos — cada prompt arranca STRICT.
```

Extracted rules inside block: NONE

## 1eb32efb866494bb — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:18-18 (heading)

## Cambio 2 — Actualizar Sección 1.3 (Principios fundamentales)

Extracted rules inside block: NONE

## da43259d639e58c2 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:20-20 (heading)

### Texto a añadir al final de Sección 1.3

Extracted rules inside block: NONE

## 48f3e008b3b19765 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:22-24 (code)

```
Enforcement determinista: cuando una regla puede codificarse, debe codificarse. La memoria del agente falla bajo presión de iteración rápida; el código no. Reglas con linter determinista (Regla 28) gana sobre regla en prosa cuando ambas existen y dicen lo mismo.
```

Extracted rules inside block: NONE

## f69daa0b38a3d839 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:26-26 (heading)

## Cambio 3 — Actualizar Sección 4.6 (F4 — Prompts Génesis)

Extracted rules inside block: NONE

## cf390cce07456730 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:28-28 (heading)

### Texto a añadir al final del paso 3 ("Entregar con trazabilidad completa")

Extracted rules inside block: NONE

## 0f963acd045d0ad2 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:30-32 (code)

```
- Antes de entregar, ejecutar Regla 28 (linter). Sin PASS o sin overrides cubriendo violaciones, NO entregar.
```

Extracted rules inside block: NONE

## 2fb3a62c88a6b4ad — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:34-34 (heading)

## Cambio 4 — Actualizar Sección 4.7 (F5 — Prompts Ancla FF+LF)

Extracted rules inside block: NONE

## c9e990eac10edc17 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:36-36 (heading)

### Texto a añadir después del paso 4 (caso 2.5 deportivo)

Extracted rules inside block: NONE

## 9432e9f38014bc49 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:38-40 (code)

```
6. Antes de entregar la Ancla, ejecutar Regla 28 (linter). Sin PASS o sin overrides cubriendo violaciones, NO entregar.
```

Extracted rules inside block: NONE

## f0f9b01a9086c394 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:42-42 (heading)

## Cambio 5 — Actualizar Sección 4.8 (F6 — Research video + Prompts)

Extracted rules inside block: NONE

## 1f1f75d63d53f173 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:44-44 (heading)

### Texto a añadir después del paso 2 (INVOCAR skill)

Extracted rules inside block: NONE

## 5ae3f8ed637452e7 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:46-48 (code)

```
3. Antes de entregar el prompt video, ejecutar Regla 28 (linter) — especialmente crítico en I2V donde la redundancia con refs es la falla más común. Sin PASS o sin overrides cubriendo violaciones, NO entregar.
```

Extracted rules inside block: NONE

## 55a02839056fb4f2 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:50-50 (heading)

## Cambio 6 — Sección 5 (Aprendizajes validados) — Nueva sub-sección 5.5

Extracted rules inside block: NONE

## e383a076a3ee20fb — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:52-65 (code)

```
5.5 Linter determinista — disciplina sobre memoria

Sesión 2026-05-27 documentó que la regla "no redescribir lo que está en los refs" (v6.0 §5.4) se viola repetidamente bajo presión de iteración rápida. La memoria del agente falla; el código no. El linter aurora-linter/prompt_linter.py mueve enforcement de memoria a código determinista. Aplica las siguientes reglas como gates duros:

- Redundancia por categoría P/O/L/PR/S vía IDs system §7.
- Word count duro (Regla 10 v6.0): 130 max T2I, 90 max I2V.
- Vocabulario baneado en MAIN: cartoon, anime, slow motion, etc. (deben ir en NEGATIVE).
- Negative prompt obligatorio.
- Keywords sports broadcast cuando aplica Regla 26.
- Exenciones: motion/camera context, anchors direccionales (away from her face).

Override del linter solo se acepta con autorización expresa escrita en el turno actual, con scope específico (término o categoría). Esto preserva flexibilidad sin permitir abuso de la disciplina.
```

Extracted rules inside block: NONE

## dab05eb5cebd08c9 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:67-67 (heading)

## Cambio 7 — Sección 14 actualizada: "27 total" → "28 total"

Extracted rules inside block: NONE

## 792cd3f24c9c7c49 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:69-69 (heading)

### ANTES

Extracted rules inside block: NONE

## 650d87367c834b28 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:70-72 (code)

```
14. REGLAS INVIOLABLES — v6.0 (27 total)
```

Extracted rules inside block: NONE

## eb1d7ea936365b56 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:74-74 (heading)

### DESPUÉS

Extracted rules inside block: NONE

## c72ed7aa7932c9d4 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:75-77 (code)

```
14. REGLAS INVIOLABLES — v6.1 (28 total)
```

Extracted rules inside block: NONE

## 9e39c5f5c58f2f72 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:79-79 (heading)

## Cambio 8 — Header del prompt

Extracted rules inside block: NONE

## 50f7f6348f15ac86 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:81-81 (heading)

### ANTES

Extracted rules inside block: NONE

## 46b2fa1c337bdee3 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:82-85 (code)

```
SYSTEM PROMPT v6.0
Fecha de emisión: 2026-05-23
```

Extracted rules inside block: NONE

## 6f654cbda77e162a — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:87-87 (heading)

### DESPUÉS

Extracted rules inside block: NONE

## 6637e6da5d47ee03 — aurora-prompt-linter/references/system_prompt_v6_1_rule28.md:88-91 (code)

```
SYSTEM PROMPT v6.1
Fecha de emisión: 2026-05-27
```

Extracted rules inside block: NONE
