# Source coverage review 106/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 48458cfdb79de380 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:68-68 (heading)

## Voice rules

Extracted rules inside block: NONE

## 8c65b879f0825213 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:70-70 (list_item)

- no em dashes

Extracted rules inside block: NONE

## bf6acc2cfcfd589a — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:71-71 (list_item)

- no emojis in body copy

Extracted rules inside block: NONE

## 88b427409f323aad — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:72-72 (list_item)

- no exclamation points in headlines

Extracted rules inside block: NONE

## adb2044b8f0b52dd — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:73-73 (list_item)

- no hype words

Extracted rules inside block: NONE

## dea0c2ebcdf93b44 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:74-74 (list_item)

- prefer specific numbers over vague claims

Extracted rules inside block: 1e60c3c96fdf

## 8870d5a4989cb2fa — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:75-75 (list_item)

- prefer present-tense over future-tense

Extracted rules inside block: 316b66acea7f

## cde6354df8ed4915 — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:76-76 (list_item)

- prefer "operator" over "creator", "infrastructure" over "agency"

Extracted rules inside block: db8af09c10ce

## 2b2928e99b94c8fd — storyboard-architect/examples/60s-founder-explainer/brand-lock.snapshot.md:80-82 (paragraph)

**Last updated:** 2026-05-07
**Owner:** Yuri Strohm
**Version:** 1.0

Extracted rules inside block: NONE

## f5321f525c93230e — storyboard-architect/examples/60s-founder-explainer/storyboard.md:1-1 (heading)

# WhyStrohm. How The System Actually Works

Extracted rules inside block: NONE

## 56afecdb8cf42d82 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:5-5 (table_row)

| **Duration** | 60s |

Extracted rules inside block: NONE

## de0410287a8573e9 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:6-6 (table_row)

| **Aspect** | 9:16 |

Extracted rules inside block: NONE

## f0ecd6293604b33d — storyboard-architect/examples/60s-founder-explainer/storyboard.md:7-7 (table_row)

| **Beat framework** | Founder Explainer |

Extracted rules inside block: NONE

## dc426c248345a213 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:8-8 (table_row)

| **Brand lock** | [`brand-lock.snapshot.md`](./brand-lock.snapshot.md) |

Extracted rules inside block: NONE

## c9212bddfed89ea5 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:9-9 (table_row)

| **Generated** | 2026-05-07 14:31 UTC |

Extracted rules inside block: NONE

## fc9156e42e966175 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:13-13 (heading)

## Brief

Extracted rules inside block: NONE

## 1e33af77b999e92e — storyboard-architect/examples/60s-founder-explainer/storyboard.md:15-15 (paragraph)

A 60-second founder explainer for WhyStrohm. The audience is operators and founders who already know they need a content system but haven't seen the WhyStrohm thesis articulated. The narrative arc moves through five micro-beats: hook, stakes, insight, proof, and CTA. Voice carries the explanation; on-screen text reinforces the key turns.

Extracted rules inside block: NONE

## 0214c4b6797f7e78 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:17-17 (heading)

## Beat framework: Founder Explainer

Extracted rules inside block: NONE

## 858c74b5c75a9b95 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:19-19 (paragraph)

Five micro-beats:

Extracted rules inside block: NONE

## 7720e0d54c7bd2ea — storyboard-architect/examples/60s-founder-explainer/storyboard.md:21-21 (list_item)

- 0–2s. Hook (provocation)

Extracted rules inside block: NONE

## a905505874701164 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:22-22 (list_item)

- 2–14s. Stakes (why it matters)

Extracted rules inside block: NONE

## 19f310db4d64994d — storyboard-architect/examples/60s-founder-explainer/storyboard.md:23-23 (list_item)

- 14–32s. Insight (the actual point, extended for 60s to give the thesis room)

Extracted rules inside block: NONE

## 66e00c0a9cc01b61 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:24-24 (list_item)

- 32–42s. Proof (the numbers)

Extracted rules inside block: NONE

## 70e7db277df71574 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:25-25 (list_item)

- 42–60s. Insight wrap + CTA

Extracted rules inside block: NONE

## 705000dd804e1717 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:27-27 (heading)

## Series lock

Extracted rules inside block: NONE

## 65088504404bd33e — storyboard-architect/examples/60s-founder-explainer/storyboard.md:31-31 (table_row)

| **Character anchor** | founder, mid-thirties, salt-and-pepper hair, navy crewneck, speaking directly to camera, calm authoritative posture |

Extracted rules inside block: NONE

## d35dbb9f464b96ba — storyboard-architect/examples/60s-founder-explainer/storyboard.md:32-32 (table_row)

| **Environment** | minimalist home office, white walls, oak desk, single houseplant, late afternoon |

Extracted rules inside block: NONE

## 9974ba3162bd42b4 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:33-33 (table_row)

| **Lighting** | soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff |

Extracted rules inside block: NONE

## e657c04977c3fc51 — storyboard-architect/examples/60s-founder-explainer/storyboard.md:34-34 (table_row)

| **Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed |

Extracted rules inside block: 1cfd332fc36c

## bb10c219b42961bb — storyboard-architect/examples/60s-founder-explainer/storyboard.md:38-38 (heading)

## Shots

Extracted rules inside block: NONE
