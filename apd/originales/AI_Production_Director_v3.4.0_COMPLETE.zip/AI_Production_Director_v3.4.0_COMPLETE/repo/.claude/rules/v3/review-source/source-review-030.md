# Source coverage review 30/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 9c70755842cdaf13 — brand-lock-extractor/tools/README.md:1-1 (heading)

# Tools

Extracted rules inside block: NONE

## 8031d95d38216bcc — brand-lock-extractor/tools/README.md:3-4 (paragraph)

Python helpers that keep the repo honest, gate a real project's output, and render previews
without invoking Claude.

Extracted rules inside block: NONE

## cc3f67e6bc23ec33 — brand-lock-extractor/tools/README.md:6-6 (heading)

## Requirements

Extracted rules inside block: NONE

## 31f404270a218f6c — brand-lock-extractor/tools/README.md:8-10 (code)

```bash
pip install pyyaml jsonschema
```

Extracted rules inside block: NONE

## 6ea2b1ddb6b939f1 — brand-lock-extractor/tools/README.md:12-12 (paragraph)

Standard library otherwise. No pandas, no numpy.

Extracted rules inside block: NONE

## 0fdeed3ef116e01c — brand-lock-extractor/tools/README.md:14-14 (heading)

## Run everything

Extracted rules inside block: NONE

## a88bb0331c5806a3 — brand-lock-extractor/tools/README.md:16-20 (code)

```bash
./tools/check.sh            # every check, with output
./tools/check.sh --quiet    # pass/fail lines only
PYTHON=python3.12 ./tools/check.sh
```

Extracted rules inside block: NONE

## 35256c42d12e3bf5 — brand-lock-extractor/tools/README.md:22-22 (paragraph)

This is exactly what CI runs, so a green local run means a green PR.

Extracted rules inside block: NONE

## d3dbc3862589e9dc — brand-lock-extractor/tools/README.md:24-26 (paragraph)

Every validator below also ships a `--selftest` that constructs failing fixtures and fails if
the check does not catch them. A validator that silently stops catching things is worse than
no validator, and the selftests are how that gets noticed.

Extracted rules inside block: NONE

## fddc203772da6884 — brand-lock-extractor/tools/README.md:28-28 (heading)

## Repo checks

Extracted rules inside block: NONE

## 6f35fea493f3626b — brand-lock-extractor/tools/README.md:30-30 (heading)

### `validate_skills.py`

Extracted rules inside block: NONE

## 313729e392b8a457 — brand-lock-extractor/tools/README.md:32-33 (paragraph)

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches
its directory and a substantive `description`.

Extracted rules inside block: 85bcf8700581

## ddbf70a3e69f3f33 — brand-lock-extractor/tools/README.md:35-37 (code)

```bash
python tools/validate_skills.py
```

Extracted rules inside block: NONE

## aa115ef642782ece — brand-lock-extractor/tools/README.md:39-39 (heading)

### `validate_schemas.py`

Extracted rules inside block: NONE

## 7d0cf2cede4ca465 — brand-lock-extractor/tools/README.md:41-42 (paragraph)

Checks every `*.schema.json` file is itself valid JSON Schema (Draft 2020-12) and carries
`$id`, `title`, and `description`.

Extracted rules inside block: NONE

## 6d241f54c78b4232 — brand-lock-extractor/tools/README.md:44-46 (code)

```bash
python tools/validate_schemas.py
```

Extracted rules inside block: NONE

## 5abc673960605c5e — brand-lock-extractor/tools/README.md:48-48 (paragraph)

It validates schemas, not instances. For instances, see `validate_shots.py`.

Extracted rules inside block: NONE

## a13c7c513a43bf41 — brand-lock-extractor/tools/README.md:50-50 (heading)

### `validate_capabilities.py`

Extracted rules inside block: NONE

## 1b01b6340e053b9f — brand-lock-extractor/tools/README.md:52-54 (paragraph)

Checks the generator capability matrix
(`skills/visual-prompt-forge/adapters/_capabilities.json`) against
`capabilities.schema.json`, then checks it against the adapter prose that defers to it:

Extracted rules inside block: NONE

## 2b0efec3d25d40a9 — brand-lock-extractor/tools/README.md:56-56 (list_item)

- every generator id has an adapter `.md` and every adapter `.md` has an entry

Extracted rules inside block: NONE

## fa3d56766cd9a6e9 — brand-lock-extractor/tools/README.md:57-57 (list_item)

- no adapter advertises more words than its own `max_prompt_words` ceiling

Extracted rules inside block: NONE

## cae2e937485dd6b2 — brand-lock-extractor/tools/README.md:58-58 (list_item)

- every adapter documents the `aspect_param` the matrix says to send

Extracted rules inside block: NONE

## e6565fcdfe66409c — brand-lock-extractor/tools/README.md:59-59 (list_item)

- no `notes` field cites a word count above its own ceiling

Extracted rules inside block: NONE

## 2ae31484109735cf — brand-lock-extractor/tools/README.md:60-60 (list_item)

- warns when the matrix or an entry is past its 120-day freshness window

Extracted rules inside block: NONE

## 79964a76f594e20b — brand-lock-extractor/tools/README.md:62-65 (code)

```bash
python tools/validate_capabilities.py
python tools/validate_capabilities.py --selftest
```

Extracted rules inside block: NONE

## d540d0482c935e72 — brand-lock-extractor/tools/README.md:67-68 (paragraph)

The prose checks exist because the matrix and the adapters had drifted in three places while
every file repeated the rule that the JSON wins.

Extracted rules inside block: NONE

## 26b488f450861919 — brand-lock-extractor/tools/README.md:70-70 (heading)

### `validate_brand_lock.py`

Extracted rules inside block: NONE

## 0afd492dd79b054e — brand-lock-extractor/tools/README.md:72-74 (paragraph)

Checks a brand-lock has all required sections and Identity fields, that its palette declares
the five roles the HTML preview maps onto CSS variables, and that its fonts are in the
backticked form the tools read.

Extracted rules inside block: 6940141b8971

## 05525297269e0922 — brand-lock-extractor/tools/README.md:76-82 (code)

```bash
python tools/validate_brand_lock.py brand-packs/whystrohm.md
python tools/validate_brand_lock.py --require-configured brand-packs/whystrohm.md
python tools/validate_brand_lock.py --snapshot output/brand-lock.snapshot.md
python tools/validate_brand_lock.py --snapshots     # every snapshot in the repo
python tools/validate_brand_lock.py --selftest
```

Extracted rules inside block: NONE

## 1daad96c1080567c — brand-lock-extractor/tools/README.md:84-86 (paragraph)

A brand-pack may be an unfilled template; that is what a template is. A snapshot may not, and
`--snapshot` additionally requires the `<!-- snapshot taken: ... -->` and
`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

Extracted rules inside block: 624418a79681
