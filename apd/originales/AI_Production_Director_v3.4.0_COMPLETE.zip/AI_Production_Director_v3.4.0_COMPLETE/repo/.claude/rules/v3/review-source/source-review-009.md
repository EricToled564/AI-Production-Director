# Source coverage review 9/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## eac26decd690f854 — ai-video-storyboard/SKILL.md:147-147 (list_item)

2. **Visual Theme** — Shared palette, lighting, lens, film look, motion

Extracted rules inside block: 3181d1dc4426

## 29b68837fb4fcffb — ai-video-storyboard/SKILL.md:148-148 (list_item)

3. **Shot List** — N shots, each following the structure in Step 4

Extracted rules inside block: 1acd93a37a94

## 82c84ed50260b932 — ai-video-storyboard/SKILL.md:149-149 (list_item)

4. **Post-Production Checklist**

Extracted rules inside block: 1b6206937cbd

## dbeaa71c5b93305f — ai-video-storyboard/SKILL.md:150-150 (list_item)

5. **Why This Works** — creative rationale

Extracted rules inside block: 85d473b66639

## 02991452b6844c03 — ai-video-storyboard/SKILL.md:152-152 (paragraph)

See `examples/tiktok-reel-30s-coffee.md` for a complete worked sample output (coffee shop opening TikTok, 30s / 6 shots).

Extracted rules inside block: NONE

## aa1621000aa3f89c — ai-video-storyboard/SKILL.md:154-154 (heading)

## License

Extracted rules inside block: NONE

## 41e39cac88d7e9e9 — ai-video-storyboard/SKILL.md:156-156 (paragraph)

MIT — use freely, commercial or personal.

Extracted rules inside block: ee71949e2532

## 57757fb2ff4166fb — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:1-1 (heading)

# 30s TikTok Reel — Coffee Shop Opening

Extracted rules inside block: NONE

## 89e19d7d11807cf6 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:3-3 (paragraph)

**Brief:** Small specialty coffee shop launching next week. Want a TikTok Reel to build anticipation and drive foot traffic on opening day.

Extracted rules inside block: NONE

## 8a36eaf088a9f264 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:5-5 (list_item)

- **Platform:** TikTok

Extracted rules inside block: NONE

## 413deb75a7fee693 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:6-6 (list_item)

- **Duration:** 30 seconds

Extracted rules inside block: NONE

## 26793d16c3d10682 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:7-7 (list_item)

- **Shots:** 6 × 5s

Extracted rules inside block: NONE

## 5fc4a596270b7b54 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:8-8 (list_item)

- **Aspect:** 9:16

Extracted rules inside block: NONE

## 729b6a09a400b0bd — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:9-9 (list_item)

- **CTA:** "Visit us. Opening next Saturday."

Extracted rules inside block: NONE

## b736965d7a55110d — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:10-10 (list_item)

- **Brand vibe:** Warm, analog, hand-crafted, for slow-morning coffee lovers

Extracted rules inside block: NONE

## 2de6d431cd236ba5 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:14-14 (heading)

## Visual Theme (applied to every shot)

Extracted rules inside block: NONE

## ba8824ac92a99501 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:16-16 (list_item)

- **Color palette:** Deep espresso brown `#3B2416`, cream `#F5E6D3`, muted amber `#D4A574`, soft sage green `#8FA88C`, black coffee `#1A1210`

Extracted rules inside block: NONE

## 9c6c9747c40b031b — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:17-17 (list_item)

- **Lighting style:** Warm golden backlight with motivated window light, soft shadows, no harsh fluorescents

Extracted rules inside block: NONE

## d916b58ae771d870 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:18-18 (list_item)

- **Lens character:** Shallow depth of field, gentle bokeh, 35mm full-frame look

Extracted rules inside block: df007d41d442

## f742106f3543b3ed — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:19-19 (list_item)

- **Film look:** Subtle 16mm film grain, slightly muted saturation, warm color temperature (around 3200K)

Extracted rules inside block: NONE

## 965188589163ed6d — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:20-20 (list_item)

- **Motion language:** Locked-off or very slow push-ins, no handheld shake

Extracted rules inside block: NONE

## 63236a34b7bf2d6c — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:24-24 (heading)

## Shot 1 (0-5s) — Hook: The Pour

Extracted rules inside block: NONE

## d230dbb8c5d2f53c — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:26-26 (paragraph)

**Purpose:** Instant visual hook to stop the scroll. Universal sensory trigger.

Extracted rules inside block: NONE

## 43e489b36fb773f0 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:28-32 (paragraph)

**Composition:** Extreme close-up (ECU), slight overhead angle (~20° down)
**Camera move:** Locked off with micro push-in
**Lighting:** Strong warm backlight behind the cup, light rim-lighting the steam
**Subject:** Gooseneck kettle pouring hot water into a white ceramic V60 dripper
**Action:** Slow bloom of coffee grounds rising as water hits them

Extracted rules inside block: NONE

## 0f256bb64836bb87 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:34-34 (paragraph)

**Prompt to copy:**

Extracted rules inside block: NONE

## c6e17bd49803da76 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:36-36 (list_item)

> Extreme close-up overhead shot of hot water pouring from a brass gooseneck kettle into a white ceramic V60 dripper filled with dark coffee grounds, the grounds blooming and rising in slow motion, warm golden backlight with visible steam curling upward, shallow depth of field, 35mm full-frame look, subtle 16mm film grain, deep espresso brown and cream color palette, muted saturation, cinematic 1080p, synchronized audio, 5 seconds, 9:16 vertical

Extracted rules inside block: 2da34fa21e3f

## b009f6bba77810bb — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:38-38 (paragraph)

**Audio direction:** Intimate sound of pouring water, bloom of hot coffee crema, distant café ambience fading in. First acoustic guitar note plays at 4.8s to bridge into Shot 2.

Extracted rules inside block: NONE

## 5be3555c3efdadfb — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:42-42 (heading)

## Shot 2 (5-10s) — Setting: The Space

Extracted rules inside block: NONE

## fe859ad26948d4bc — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:44-44 (paragraph)

**Purpose:** Establish the space. Show it's real, it's cozy, it exists.

Extracted rules inside block: NONE

## cc584422f48a5dc9 — ai-video-storyboard/examples/tiktok-reel-30s-coffee.md:46-50 (paragraph)

**Composition:** Medium wide shot (MWS), waist-high eye level
**Camera move:** Very slow dolly forward (~0.5x speed feeling)
**Lighting:** Large window on camera-left, warm amber streetlamp glow from deep background
**Subject:** Empty wooden café interior, reclaimed wood counter in focus, shelves of mugs blurred in background
**Action:** Morning sun rays cut through the space, dust motes floating

Extracted rules inside block: NONE
