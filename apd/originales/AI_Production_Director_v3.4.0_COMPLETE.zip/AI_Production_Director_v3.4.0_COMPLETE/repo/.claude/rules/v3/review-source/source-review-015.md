# Source coverage review 15/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## cf32f84fd6af64ad — aurora-prompt-linter/references/README.md:58-58 (table_row)

| 1 | Génesis text-to-image | 75-130 |

Extracted rules inside block: NONE

## 10d33f0d03b75532 — aurora-prompt-linter/references/README.md:59-59 (table_row)

| 2 | Ancla image-with-refs | 75-130 |

Extracted rules inside block: NONE

## 1ab855e90c95f980 — aurora-prompt-linter/references/README.md:60-60 (table_row)

| 3a | I2V FF only | 50-90 |

Extracted rules inside block: NONE

## f6da23c05329b735 — aurora-prompt-linter/references/README.md:61-61 (table_row)

| 3b | I2V FF + LF | 50-90 |

Extracted rules inside block: NONE

## 75bb3895d6618e2a — aurora-prompt-linter/references/README.md:62-62 (table_row)

| 3c | I2V motion control | 50-90 |

Extracted rules inside block: NONE

## 0bc3feabf6c780d7 — aurora-prompt-linter/references/README.md:63-63 (table_row)

| 4 | Video con diálogo | 75-130 |

Extracted rules inside block: NONE

## 48d6cfec648078d4 — aurora-prompt-linter/references/README.md:65-65 (paragraph)

Word count: el MAX es HARD FAIL (Regla 10 v6.0). El MIN es WARN no-bloqueante (compresión válida si intencional).

Extracted rules inside block: NONE

## 6f81180dc3392525 — aurora-prompt-linter/references/README.md:67-67 (heading)

## Override mechanism

Extracted rules inside block: NONE

## 4d44806c529d94f9 — aurora-prompt-linter/references/README.md:69-69 (paragraph)

Si una violación detectada es legítima en este caso, el usuario puede autorizarla por escrito en el turno actual. **Solo se acepta autorización expresa específica.**

Extracted rules inside block: NONE

## a8f3d17fbb2f65b1 — aurora-prompt-linter/references/README.md:71-71 (paragraph)

Sintaxis:

Extracted rules inside block: NONE

## cd49dba9ee9c9d95 — aurora-prompt-linter/references/README.md:72-74 (code)

```
OVERRIDE: <term-or-category> - <reason>
```

Extracted rules inside block: NONE

## 84788fba3c6bd4d2 — aurora-prompt-linter/references/README.md:76-76 (paragraph)

Ejemplos válidos:

Extracted rules inside block: NONE

## 135b33acda7aff63 — aurora-prompt-linter/references/README.md:77-81 (code)

```
OVERRIDE: red performance tank - necesito reforzar el color porque seeds previas lo pierden
OVERRIDE: L - autorizo describir locación porque la ref está muy oscura
OVERRIDE: slow motion - explícitamente quiero slow motion en este clip
```

Extracted rules inside block: NONE

## e819074ff45c91c0 — aurora-prompt-linter/references/README.md:83-83 (paragraph)

Ejemplos NO válidos (genéricos, sin scope específico):

Extracted rules inside block: NONE

## db9948e80458a11d — aurora-prompt-linter/references/README.md:84-84 (list_item)

- "hazlo de todas formas"

Extracted rules inside block: NONE

## 9b91f2fe73237fb3 — aurora-prompt-linter/references/README.md:85-85 (list_item)

- "ya sé que está en la ref, déjalo"

Extracted rules inside block: NONE

## 14cf0cd937e2ce0d — aurora-prompt-linter/references/README.md:86-86 (list_item)

- "ready to copy paste"

Extracted rules inside block: NONE

## 83d8e55016adaff2 — aurora-prompt-linter/references/README.md:88-88 (paragraph)

El override solo es válido en el turno actual del usuario. Autorizaciones de turnos pasados NO persisten — cada prompt nuevo arranca STRICT.

Extracted rules inside block: NONE

## 8cbc555e158c4a24 — aurora-prompt-linter/references/README.md:90-90 (heading)

## Reglas que aplica

Extracted rules inside block: NONE

## ca87434e8558db3a — aurora-prompt-linter/references/README.md:92-92 (list_item)

1. **Redundancia por categoría**: si ref carga categoría X, no describir X en MAIN.

Extracted rules inside block: 1e0ccc4385c5

## b7161fbfc4de12e7 — aurora-prompt-linter/references/README.md:93-93 (list_item)

2. **Vocabulario baneado cross-platform**: `slow motion`, `cartoon`, `anime`, `3D render`, etc. solo en NEGATIVE block.

Extracted rules inside block: 65774d17b5ad

## 1d221196fe9d1ae9 — aurora-prompt-linter/references/README.md:94-94 (list_item)

3. **Word count**: cap MAX duro = 90 (I2V) o 130 (T2I); MIN soft = 50/75.

Extracted rules inside block: 530dfe9aa47b

## 147b8cd0066f20f9 — aurora-prompt-linter/references/README.md:95-95 (list_item)

4. **Negative prompt**: bloque obligatorio.

Extracted rules inside block: c737439439ae

## c57302322fb50136 — aurora-prompt-linter/references/README.md:96-96 (list_item)

5. **Sports broadcast**: si flag activo, requiere `60fps` y `broadcast realism` en MAIN (Regla 26 v6.0).

Extracted rules inside block: 3de3d8001972

## 33a8587580e0e2b1 — aurora-prompt-linter/references/README.md:97-97 (list_item)

6. **Exenciones**: términos en contexto de motion/cámara o como anchor direccional (`away from her face`, `across the climbing wall`) NO se flaggean.

Extracted rules inside block: a7cb646e6f7f

## 13552aa3f053b896 — aurora-prompt-linter/references/README.md:99-99 (heading)

## Limitaciones conocidas v1.0 (roadmap v1.1+)

Extracted rules inside block: NONE

## dca906847057550c — aurora-prompt-linter/references/README.md:101-101 (list_item)

- **Sinónimos**: "tank top" en ref + "athletic shirt" en prompt = no detectado. Solución v1.1: tabla de sinónimos en vocabularies.yaml.

Extracted rules inside block: NONE

## e1cd84b8ba973bb7 — aurora-prompt-linter/references/README.md:102-102 (list_item)

- **Sub-tags por categoría**: O.upper / O.lower / P.face / P.body — para refs con coverage parcial. v1.2.

Extracted rules inside block: NONE

## 8d3d032eae15625a — aurora-prompt-linter/references/README.md:103-103 (list_item)

- **Embeddings semánticos**: para paráfrasis más sutiles. v2.0 si justifica el costo.

Extracted rules inside block: NONE

## b16f5cbc5c3ec5fb — aurora-prompt-linter/references/README.md:104-104 (list_item)

- **Auto-suggest rewrite**: hoy lista qué quitar; v1.1 podría generar versión limpia automática.

Extracted rules inside block: NONE
