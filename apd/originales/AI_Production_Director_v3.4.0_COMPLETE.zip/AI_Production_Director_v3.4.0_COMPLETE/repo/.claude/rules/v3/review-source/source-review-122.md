# Source coverage review 122/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 7a0c55eeb1c3a636 — storyboard-html-preview/SKILL.md:156-156 (paragraph)

This works when the whole output folder is zipped and shared.

Extracted rules inside block: NONE

## 2227f980f55fa147 — storyboard-html-preview/SKILL.md:158-159 (paragraph)

For hard-copy print (a single file with no folder structure), the skill can offer to inline
frames as base64. Ask the user which they prefer if frames are present.

Extracted rules inside block: 2736f52cd8fe

## df57dac865aedd46 — storyboard-html-preview/SKILL.md:161-164 (paragraph)

If a shot's `assets.generated` entry carries a `sha256` and the file no longer matches it,
render the frame but say so on the page. That mismatch means the frame changed after it was
recorded, which is exactly the case where a preview quietly showing the new file is worse
than one that flags it.

Extracted rules inside block: NONE

## f97fc9c6cd431e9b — storyboard-html-preview/SKILL.md:166-167 (paragraph)

If no frames exist, render styled placeholder cards showing the framing, subject, and shot
spec. These are still useful for stakeholder review at the storyboard stage.

Extracted rules inside block: NONE

## 111a0ba66ccb3ed1 — storyboard-html-preview/SKILL.md:169-169 (paragraph)

**Template flag convention.** When composing the per-shot context for `preview.html.tpl`, set exactly one of:

Extracted rules inside block: NONE

## d295199b1944c1ac — storyboard-html-preview/SKILL.md:171-171 (list_item)

- `has_image: true` and `image_path: "frames/round-2/shot_NN.png"`, when a frame exists

Extracted rules inside block: NONE

## 84a04d829be3cb16 — storyboard-html-preview/SKILL.md:172-172 (list_item)

- `has_no_image: true`, when none does (renders the placeholder card)

Extracted rules inside block: NONE

## 275db31b99e550da — storyboard-html-preview/SKILL.md:174-174 (paragraph)

The template uses two parallel `{{#if}}` blocks rather than `{{#if}}/{{else}}` to keep the rendering portable across template engines.

Extracted rules inside block: NONE

## a145bdc499d7064d — storyboard-html-preview/SKILL.md:176-179 (paragraph)

For text overlays, set `has_overlays: true` and an `overlays` array on the shot. Each entry
carries `id`, `content`, `font`, `weight`, `color`, `size`, `position_class`,
`position_label`, `enter_at`, `enter_animation`, `exit_at`, `exit_animation`. The template
iterates that array with `{{#each overlays}}`.

Extracted rules inside block: NONE

## 0c5a73b3731433a7 — storyboard-html-preview/SKILL.md:181-183 (paragraph)

It is an array because `shots.json` lets a shot carry several overlays and
`text-overlays.json` always did. A single set of `overlay_*` fields could hold one, so the
second overlay on a shot rendered nowhere and nothing reported it.

Extracted rules inside block: 836106ef93b0

## cb0ae6ded44a9cf0 — storyboard-html-preview/SKILL.md:185-187 (paragraph)

For verdict badges, set `has_verdict`, `verdict`, `verdict_round`, and `verdict_class`
(the lowercased verdict) from the newest critique for that shot under `critiques/`. Omit
them when the shot has no critique.

Extracted rules inside block: NONE

## dc48551ad3f7870c — storyboard-html-preview/SKILL.md:189-193 (paragraph)

**Escape everything.** Subjects, rationales, VO lines, and overlay copy are model-generated
prose that lands in both text and attribute contexts. One angle bracket in a rationale, or
one quote in an overlay font name, breaks the page a client is reading.
`tools/shots-to-html.py` escapes every substitution by default and reserves raw output for
the inlined CSS alone.

Extracted rules inside block: NONE

## 55e8808591211f5d — storyboard-html-preview/SKILL.md:195-195 (heading)

### Step 5. Render text overlays visually

Extracted rules inside block: NONE

## 54d82738c031a43a — storyboard-html-preview/SKILL.md:197-197 (paragraph)

For every shot with an `on_screen_text` reference, the HTML shows:

Extracted rules inside block: NONE

## 0e0d13da2102841b — storyboard-html-preview/SKILL.md:199-199 (list_item)

- The text content rendered in approximately the brand font (or visible fallback)

Extracted rules inside block: NONE

## fe025b3cf3ded98a — storyboard-html-preview/SKILL.md:200-200 (list_item)

- The position indicated visually (lower-third, center, etc.)

Extracted rules inside block: NONE

## 2f82d9cb1b5e266f — storyboard-html-preview/SKILL.md:201-201 (list_item)

- Timing info (enter/exit beats)

Extracted rules inside block: NONE

## 49a4986da7b76416 — storyboard-html-preview/SKILL.md:203-203 (paragraph)

This gives the reviewer a sense of what the final composited frame will look like, even before final compositing happens.

Extracted rules inside block: NONE

## 6553955e5b96cefd — storyboard-html-preview/SKILL.md:205-205 (heading)

### Step 6. Print stylesheet

Extracted rules inside block: NONE

## 4f59d89b485f455b — storyboard-html-preview/SKILL.md:207-207 (paragraph)

Include `@media print` rules that:

Extracted rules inside block: NONE

## 40887b010fdcaca1 — storyboard-html-preview/SKILL.md:209-209 (list_item)

- Hide nav, footer scripts, expand/collapse UI

Extracted rules inside block: NONE

## 9b9a488d0f1555c8 — storyboard-html-preview/SKILL.md:210-210 (list_item)

- Force one shot per page (or two if compact)

Extracted rules inside block: NONE

## 863413a0d0a75a52 — storyboard-html-preview/SKILL.md:211-211 (list_item)

- Ensure text overlays render legibly

Extracted rules inside block: 0d7646d5b6eb

## 35334fc6eb7ff9fa — storyboard-html-preview/SKILL.md:212-212 (list_item)

- Use black-on-white where brand colors won't print well

Extracted rules inside block: c059f6e81472

## 5c52873b89fee19a — storyboard-html-preview/SKILL.md:214-214 (paragraph)

The user should be able to hit Cmd-P / Ctrl-P and get a clean PDF.

Extracted rules inside block: ab2f944d2073

## 66c807fd8032de05 — storyboard-html-preview/SKILL.md:216-216 (heading)

## Hard rules

Extracted rules inside block: NONE

## b81c90776fea4014 — storyboard-html-preview/SKILL.md:218-218 (heading)

### Rule 1. Single file, no exceptions

Extracted rules inside block: NONE

## 045ea452aa10d417 — storyboard-html-preview/SKILL.md:220-220 (paragraph)

The output is one `.html` file. If you find yourself wanting a separate stylesheet or JS file, inline it. If you find yourself wanting a build step, you're solving the wrong problem.

Extracted rules inside block: NONE

## a58eb4554d1adbab — storyboard-html-preview/SKILL.md:222-222 (heading)

### Rule 2. No external dependencies at runtime

Extracted rules inside block: NONE

## 1a0c9c09f53c6d93 — storyboard-html-preview/SKILL.md:224-224 (paragraph)

No CDN scripts. No Google Fonts. No external CSS frameworks. The file must work with no internet connection.

Extracted rules inside block: 5ed142b9b59e
