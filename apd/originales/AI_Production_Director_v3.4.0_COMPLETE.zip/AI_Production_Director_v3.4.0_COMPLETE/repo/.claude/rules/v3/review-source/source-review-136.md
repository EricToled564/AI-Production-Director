# Source coverage review 136/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 95b6ebcd62792287 — video/references/camera-lighting-vocabulary.md:111-111 (list_item)

- frontal soft light

Extracted rules inside block: NONE

## 38df222c9042f2d9 — video/references/camera-lighting-vocabulary.md:112-112 (list_item)

- rim light

Extracted rules inside block: NONE

## 123d57e81d696991 — video/references/camera-lighting-vocabulary.md:113-113 (list_item)

- bounce fill

Extracted rules inside block: NONE

## 274558948bd96d9d — video/references/camera-lighting-vocabulary.md:114-114 (list_item)

- window key light

Extracted rules inside block: NONE

## c02c9a2957669378 — video/references/camera-lighting-vocabulary.md:115-115 (list_item)

- motivated practical (the light source is visible in frame)

Extracted rules inside block: NONE

## fd3fec681fec480b — video/references/camera-lighting-vocabulary.md:117-117 (heading)

## 6. Light quality

Extracted rules inside block: NONE

## 8ddc3f2a962ef23a — video/references/camera-lighting-vocabulary.md:119-119 (list_item)

- hard shadow

Extracted rules inside block: NONE

## 8eb2917baa447314 — video/references/camera-lighting-vocabulary.md:120-120 (list_item)

- soft diffused

Extracted rules inside block: NONE

## b8e8622cb18254ef — video/references/camera-lighting-vocabulary.md:121-121 (list_item)

- low-key lighting

Extracted rules inside block: NONE

## 3222005128bff1d0 — video/references/camera-lighting-vocabulary.md:122-122 (list_item)

- high contrast

Extracted rules inside block: NONE

## 243db623adea2df7 — video/references/camera-lighting-vocabulary.md:123-123 (list_item)

- silhouette

Extracted rules inside block: NONE

## 3b2a034bb4b4ef38 — video/references/camera-lighting-vocabulary.md:124-124 (list_item)

- specular highlights

Extracted rules inside block: NONE

## a0adc5e8577c3a47 — video/references/camera-lighting-vocabulary.md:125-125 (list_item)

- volumetric haze

Extracted rules inside block: NONE

## b19cf459f49fbf8e — video/references/camera-lighting-vocabulary.md:126-126 (list_item)

- steam catching backlight

Extracted rules inside block: NONE

## c837c75a5088cd65 — video/references/camera-lighting-vocabulary.md:127-127 (list_item)

- wet reflections

Extracted rules inside block: NONE

## 0b2dc311326b6fa0 — video/references/camera-lighting-vocabulary.md:128-128 (list_item)

- desaturated palette

Extracted rules inside block: NONE

## b9c0858d6297e6d9 — video/references/camera-lighting-vocabulary.md:129-129 (list_item)

- cold blue-gray grade

Extracted rules inside block: NONE

## d91de1b125d148a2 — video/references/camera-lighting-vocabulary.md:130-130 (list_item)

- teal shadows

Extracted rules inside block: NONE

## b1393331cb114e4e — video/references/camera-lighting-vocabulary.md:131-131 (list_item)

- clean commercial lighting

Extracted rules inside block: NONE

## 4c75fc2ad509f5c9 — video/references/camera-lighting-vocabulary.md:132-132 (list_item)

- gritty naturalistic

Extracted rules inside block: NONE

## 40cb12c5a6fb2de6 — video/references/camera-lighting-vocabulary.md:133-133 (list_item)

- blown-out overexposure

Extracted rules inside block: NONE

## 04b5eda24352f10e — video/references/camera-lighting-vocabulary.md:134-134 (list_item)

- crushed blacks

Extracted rules inside block: NONE

## 41a9f810524ce316 — video/references/camera-lighting-vocabulary.md:136-136 (heading)

## 7. Color discipline

Extracted rules inside block: NONE

## 2ff56efb1991fb0f — video/references/camera-lighting-vocabulary.md:138-138 (paragraph)

Define palette with concrete colors. Never write "cinematic colors."

Extracted rules inside block: fb35029af5f3

## b4f60f63047fc703 — video/references/camera-lighting-vocabulary.md:140-141 (paragraph)

Bad. "cinematic colors."
Good. "Cold blue-gray shadows, desaturated skin tones, greenish fridge spill, black negative space, no warm yellow tones."

Extracted rules inside block: NONE

## 7fbf6b5835dd1933 — video/references/camera-lighting-vocabulary.md:143-143 (paragraph)

If the user bans a color, obey it strictly. Repeat the ban in every clip of a multi-clip sequence.

Extracted rules inside block: NONE

## bcfe81e013e25bd4 — video/references/camera-lighting-vocabulary.md:145-145 (paragraph)

Common palettes.

Extracted rules inside block: NONE

## 7481868538463bf5 — video/references/camera-lighting-vocabulary.md:147-147 (list_item)

- Fincher cold. Cold blue-gray shadows, desaturated skin, black negative space.

Extracted rules inside block: NONE

## a7eb979d197deeda — video/references/camera-lighting-vocabulary.md:148-148 (list_item)

- Deakins natural. Warm amber interiors, cool blue exteriors, clean contrast.

Extracted rules inside block: NONE

## 702ae7bf32e8ff90 — video/references/camera-lighting-vocabulary.md:149-149 (list_item)

- Wong Kar-wai. Saturated warm reds, deep greens, hazy practicals.

Extracted rules inside block: NONE
