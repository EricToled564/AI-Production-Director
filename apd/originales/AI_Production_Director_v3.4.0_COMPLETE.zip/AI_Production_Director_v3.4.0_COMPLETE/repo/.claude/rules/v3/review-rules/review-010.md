# Rule classification review 10/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## 1bf9438ec870 — image/references/prompt-framework.md:216

**Fabric & material drape** — "natural fabric folds at elbow crease, gravity pull on loose linen garment, weight distribution visible in heavy wool coat"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "1bf9438ec870",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "image"
  }
}
```

## 143c6dad0eb7 — image/references/prompt-framework.md:217

**Contact shadows** — "soft contact shadow where cup meets saucer, ambient occlusion in crevices of stone wall, dark line where book spine meets table"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "143c6dad0eb7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "subject.human_contact",
        "value": true
      }
    ]
  }
}
```

## c7fc30fb6c1d — image/references/prompt-framework.md:218

**Environmental reflections** — "building reflections in wet pavement, sky gradient in chrome bumper surface, warm neon glow on skin from nearby sign"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "c7fc30fb6c1d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "image"
  }
}
```

## a5fe99c46079 — image/references/prompt-framework.md:219

**Motion cues** — "slight motion blur on trailing hair strand, frozen splash droplet from espresso pour, wind-displaced fabric edge of scarf"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "a5fe99c46079",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "image"
  }
}
```

## 5046d3da321a — image/references/slides.md:29

Избегай pure white #fff на чёрном - используй #f5f5f5

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "5046d3da321a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "GRAF"
      }
    ]
  }
}
```

## c9092b5ff8fe — image/references/slides.md:32

Контент должен дышать

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "c9092b5ff8fe",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "base_type",
        "value": "GRAF"
      }
    ]
  }
}
```

## d71c38a7ced6 — image/references/storyboards.md:78

"Identity must stay consistent throughout"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "d71c38a7ced6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "in",
            "path": "stage",
            "value": [
              "storyboard",
              "shot",
              "asset",
              "prompt"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 104dab30e16d — image/references/storyboards.md:81

"Expressions and poses should vary"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "104dab30e16d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "storyboard",
          "shot",
          "asset",
          "prompt"
        ]
      }
    ]
  }
}
```

## b12f56e38728 — image/references/structural.md:56

**What** proportions to use

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "b12f56e38728",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "in",
        "path": "operation",
        "value": [
          "image_to_image",
          "image_edit",
          "reference_analysis"
        ]
      }
    ]
  }
}
```

## 13778242909e — image/references/structural.md:84

Use reference for:

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "13778242909e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "in",
            "path": "operation",
            "value": [
              "image_to_image",
              "image_edit",
              "reference_analysis"
            ]
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## cd0e5e833aa9 — image/references/text-rendering.md:126

Ask the model to write/refine the text content

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "cd0e5e833aa9",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "in",
            "path": "text.mode",
            "value": [
              "composite",
              "in_image"
            ]
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## d7f70ffc8321 — image/references/text-rendering.md:127

Then ask for an image with that exact text

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "d7f70ffc8321",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "in",
            "path": "text.mode",
            "value": [
              "composite",
              "in_image"
            ]
          }
        ]
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 3c37ff5f736f — image/references/text-rendering.md:167

Upload with prompt: "Use layout from attached image"

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "3c37ff5f736f",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "in",
        "path": "text.mode",
        "value": [
          "composite",
          "in_image"
        ]
      }
    ]
  }
}
```

## 6e2610917111 — image/references/vision-decomposer.md:3

Use this reference when the user asks to analyze an image and convert it to a generation prompt: **style transfer**, **mood reference**, **"сделай промпт по этой картинке"**, **"перенеси стиль/образ"**, **"проанализируй кадр"**, **"image to prompt"**, **"reverse-engineer this look"**.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "6e2610917111",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "operation",
            "value": "reference_analysis"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 21ff9a74e1fa — image/references/vision-decomposer.md:7

The process has two strict steps. Do not skip Step 1. Do not freestyle Step 2.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "21ff9a74e1fa",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "reference_analysis"
      }
    ]
  }
}
```

## 7a2eab3d9d5b — image/references/vision-decomposer.md:36

**Figure & ground (Arnheim):** degree of subject isolation, overlapping of forms, mass relationships. Use of reflections (mirrors, windows) to expand context.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "7a2eab3d9d5b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "reference_analysis"
      }
    ]
  }
}
```

## 766f3ac1c6a6 — image/references/vision-decomposer.md:44

**Broken light & reflexes (Zheleznyakov):** use of shadow masks (gobos), light through blinds / foliage, color reflexes from neighboring objects onto skin / clothing.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "766f3ac1c6a6",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "reference_analysis"
      }
    ]
  }
}
```

## 217af555708d — image/references/vision-decomposer.md:49

**Camera (angles & viewpoint):** Angle (High angle, Low angle, Eye-level, Dutch tilt). Objective camera, Subjective, POV, Over-the-shoulder (OTS). Movement imitation (Push-in, Tracking shot).

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "217af555708d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "reference_analysis"
      }
    ]
  }
}
```

## b6de40f5a911 — image/references/vision-decomposer.md:62

Describe **strictly what you see**. Do not invent new objects.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "b6de40f5a911",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "reference_analysis"
      }
    ]
  }
}
```

## f74beaeba044 — image/references/vision-decomposer.md:63

**No filler.** Never write "The image shows...", "A picture of...", "I can see...".

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "f74beaeba044",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "reference_analysis"
      }
    ]
  }
}
```

## 0bbe3f73a630 — image/references/vision-decomposer.md:109

Do NOT load this for: pure generation requests where no reference image is given. For those, use the standard model files.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "0bbe3f73a630",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "eq",
            "path": "media",
            "value": "image"
          },
          {
            "op": "eq",
            "path": "operation",
            "value": "reference_analysis"
          }
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 753cf237f52c — produccion-visual-sw30/SKILL.md:13

respuesta honesta a esta pregunta no sea SÍ SIN MATICES:

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "753cf237f52c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## a95b3e8f01f8 — produccion-visual-sw30/SKILL.md:20

Si la respuesta es NO: no se entrega. Se leen los archivos faltantes, se aplica lo que falte y se vuelve a preguntar. Se repite cuantas veces sea necesario.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "a95b3e8f01f8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 14653b391db0 — produccion-visual-sw30/SKILL.md:22

Prohibido responder SÍ para complacer. Un SÍ falso es una mentira y cuesta más que el NO.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "14653b391db0",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 8cabcfd84c43 — produccion-visual-sw30/SKILL.md:23

Prohibido responder SÍ con matices, condiciones o notas al pie disfrazadas de honestidad.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "8cabcfd84c43",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "all": [
          {
            "op": "in",
            "path": "media",
            "value": [
              "image",
              "video"
            ]
          },
          {
            "op": "in",
            "path": "stage",
            "value": [
              "asset",
              "prompt",
              "generation",
              "qa"
            ]
          }
        ]
      },
      {
        "op": "eq",
        "path": "subject.feet_visible",
        "value": true
      }
    ]
  }
}
```

## d0ed4afe71b9 — produccion-visual-sw30/SKILL.md:24

"Exhaustiva" significa: leídos COMPLETOS todos los archivos del skill aplicables al caso (SKILL.md indica el orden obligatorio), no fragmentos ni grep.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "d0ed4afe71b9",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## d6939a03c608 — produccion-visual-sw30/SKILL.md:33

Orden de dirección: nunca se escribe un prompt de corrido ni se parchea texto. Tres pasos, en este orden:

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "d6939a03c608",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 1289222306ea — produccion-visual-sw30/SKILL.md:35

**CATALOGAR** — identificar el TIPO de prompt y leer qué reglas aplican a ese tipo en la matriz (production-package/RULES_MATRIX.md: 26 reglas × 5 tipos, con fuente y bloque de cada una). Tipos: T1 maestro rostro · T2 maestro cuerpo · T3 cuadro 1 persona · T4 cuadro 2 personas · T5 edición quirúrgica.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "1289222306ea",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## f3844410892e — produccion-visual-sw30/SKILL.md:39

**DEFINIR SECCIONES** — antes de redactar, listar las secciones que ese tipo exige. Cada regla vive en UN bloque nombrado y compartido (optics_*, skin_*, anatomy, idlock, text_lock, contact_*, unique, colour, hair, fabric, clean_*, autocontain_*), nunca en texto suelto dentro del brief.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "f3844410892e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## c91bb7d2e454 — produccion-visual-sw30/SKILL.md:42

**ENSAMBLAR POR SECCIÓN** — el prompt se construye llamando P(scene, subject, [details], mood, usecase, [constraints]) para creación o E(change, preserve, [constraints]) para edición, pasando bloques. Salida en el formato de SKILL.md del skill image: cabecera Model/Quality/Size + References

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "c91bb7d2e454",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 29837864275c — produccion-visual-sw30/SKILL.md:52

`rule_registry.py` — relee los 23 archivos del skill image y EXTRAE mecánicamente cada enunciado normativo (209). Si el skill cambia, el registro cambia solo. Mi interpretación deja de ser etapa.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "29837864275c",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 70959300d63e — produccion-visual-sw30/SKILL.md:54

`rule_ledger.py` — obliga a que CADA regla aplicable tenga disposición explícita: CHECK (existe verificación) o NA (con razón escrita y auditable). Sale con código 1 si queda una sola PENDING.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "70959300d63e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## c3632422a5a9 — produccion-visual-sw30/SKILL.md:56

`audit_gi2.py` — verifica los prompts columna por columna.

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "c3632422a5a9",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## 4db66ab71600 — produccion-visual-sw30/SKILL.md:69

Sección | Bloque obligatorio | Por qué

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 600,
  "rule_id": "4db66ab71600",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```

## b1f2d2ee867d — produccion-visual-sw30/SKILL.md:73

usecase | `usecase_doc` | fotografía documental Kodak Tri-X de reportaje. Kodak Portra suaviza la piel por diseño y contradice los poros — PROHIBIDO en rostros

Seed:
```json
{
  "authority": "PIPELINE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 600,
  "rule_id": "b1f2d2ee867d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "in",
        "path": "media",
        "value": [
          "image",
          "video"
        ]
      },
      {
        "op": "in",
        "path": "stage",
        "value": [
          "asset",
          "prompt",
          "generation",
          "qa"
        ]
      }
    ]
  }
}
```
