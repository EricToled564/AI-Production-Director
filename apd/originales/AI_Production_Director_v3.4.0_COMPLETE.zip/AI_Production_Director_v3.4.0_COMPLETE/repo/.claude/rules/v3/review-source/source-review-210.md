# Source coverage review 210/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## e2d0308a91a2d1dc — visual-prompt-forge/adapters/ideogram.md:26-28 (code)

```
{Subject and composition}. {Environment and lighting}. The text "{exact text}" appears {position description}, in {font style description}. {Brand mood and color closing.}
```

Extracted rules inside block: NONE

## ddecf8c19eab2c51 — visual-prompt-forge/adapters/ideogram.md:30-30 (paragraph)

The exact text must be in straight double-quotes. Ideogram parses these as the text-render target.

Extracted rules inside block: 5220fb767014

## b3c76e986ad34ddc — visual-prompt-forge/adapters/ideogram.md:32-32 (heading)

## Parameters

Extracted rules inside block: NONE

## 2abc0fd7aac11a5d — visual-prompt-forge/adapters/ideogram.md:34-34 (table_row)

| Parameter | Where | Default |

Extracted rules inside block: NONE

## 0dce70156b62e57e — visual-prompt-forge/adapters/ideogram.md:36-36 (table_row)

| `aspect_ratio` | API field | from `project.aspect` |

Extracted rules inside block: NONE

## dea6edc516207089 — visual-prompt-forge/adapters/ideogram.md:37-37 (table_row)

| `model` | API field | `V_3` |

Extracted rules inside block: NONE

## 0eeaa61d152827b3 — visual-prompt-forge/adapters/ideogram.md:38-38 (table_row)

| `magic_prompt` | API field | `OFF` for series work, kills consistency |

Extracted rules inside block: NONE

## a5d18870231a37d0 — visual-prompt-forge/adapters/ideogram.md:39-39 (table_row)

| `style_type` | API field | `DESIGN` for posters, `REALISTIC` for scenes |

Extracted rules inside block: NONE

## ac09e04eaa87a96b — visual-prompt-forge/adapters/ideogram.md:40-40 (table_row)

| `seed` | API field | set per-storyboard |

Extracted rules inside block: NONE

## 1130f35b8f00657d — visual-prompt-forge/adapters/ideogram.md:42-42 (paragraph)

Document in comment block:

Extracted rules inside block: NONE

## f66857488d512cf6 — visual-prompt-forge/adapters/ideogram.md:43-46 (code)

```
# shot_01, params: ar=9:16, model=V_3, magic_prompt=OFF, style=DESIGN, seed=2840193
{prompt}
```

Extracted rules inside block: NONE

## f23f719d0492c790 — visual-prompt-forge/adapters/ideogram.md:48-48 (heading)

## Length

Extracted rules inside block: NONE

## 3c2fd9b61655568a — visual-prompt-forge/adapters/ideogram.md:50-52 (paragraph)

Ideogram handles **60–120 words** comfortably. Text-bearing prompts run shorter still:
the more scene description you stack around a text instruction, the more likely the
render drops or garbles the copy.

Extracted rules inside block: NONE

## 408baf617e9dff57 — visual-prompt-forge/adapters/ideogram.md:54-54 (heading)

## Composition pattern (Mode 1, composited)

Extracted rules inside block: NONE

## 617647247d8ec873 — visual-prompt-forge/adapters/ideogram.md:56-56 (paragraph)

Same as Flux pattern, no text in prompt:

Extracted rules inside block: NONE

## d0c61de18ba288ac — visual-prompt-forge/adapters/ideogram.md:58-60 (code)

```
{Framing description with character and action}. {Environment from series_lock}. {Lighting from series_lock}. {Photographic spec}. {Brand mood and color}. Clean composition with negative space for text overlay placement.
```

Extracted rules inside block: NONE

## fb9992c54c2d7162 — visual-prompt-forge/adapters/ideogram.md:62-62 (heading)

## Composition pattern (Mode 2, text-in-image)

Extracted rules inside block: NONE

## 3787c54040faaf2e — visual-prompt-forge/adapters/ideogram.md:64-66 (code)

```
{Subject/composition sentence}. {Environment/lighting sentence}. The text "{exact content}" appears {center / top-third / bottom-third / etc.}, in {font style, bold sans-serif / elegant serif / handwritten script / etc.}, color {hex or named color from brand-lock}. {Brand mood closing}.
```

Extracted rules inside block: NONE

## d799f37fb8ebaa5f — visual-prompt-forge/adapters/ideogram.md:68-68 (heading)

## Example (Mode 2)

Extracted rules inside block: NONE

## afbf8b18ab99e2af — visual-prompt-forge/adapters/ideogram.md:70-72 (paragraph)

**Shot:** poster-style hero frame, brand launch
**Brand-lock:** display font is `Inter Black`, headline color `#0F1F3A` on `#F5F0E8` cream background
**Text content:** `built different`

Extracted rules inside block: NONE

## 3aaa16e2ef8fa8c5 — visual-prompt-forge/adapters/ideogram.md:74-74 (paragraph)

**Output prompt:**

Extracted rules inside block: NONE

## 8bc609378725f298 — visual-prompt-forge/adapters/ideogram.md:75-77 (code)

```
Editorial poster composition, dense cream background, single bold composition. Minimalist studio environment, even diffused lighting. The text "built different" appears center of the frame, in heavy sans-serif typography (Inter Black style), color deep navy #0F1F3A on cream #F5F0E8 background. Calm, considered, operator brand mood, confident without shouting.
```

Extracted rules inside block: NONE

## 12a08be9bdae9c81 — visual-prompt-forge/adapters/ideogram.md:79-79 (heading)

## When NOT to use Ideogram

Extracted rules inside block: NONE

## 6118532f3651a3c1 — visual-prompt-forge/adapters/ideogram.md:81-81 (list_item)

- **Photorealistic scenes with people**. Flux is better

Extracted rules inside block: NONE

## a3f22d73dd678c6f — visual-prompt-forge/adapters/ideogram.md:82-82 (list_item)

- **Cinematic mood/aesthetic**. Midjourney is better

Extracted rules inside block: NONE

## 85a530937dfb7fa4 — visual-prompt-forge/adapters/ideogram.md:83-83 (list_item)

- **Product photography**. Flux 2 Pro is better

Extracted rules inside block: NONE

## 8e8805c180a84b22 — visual-prompt-forge/adapters/ideogram.md:84-84 (list_item)

- **Series work where consistency matters**. Midjourney with `--cref` or Flux with seed-locking handles consistency better

Extracted rules inside block: NONE

## 70869e6977ac9362 — visual-prompt-forge/adapters/ideogram.md:86-86 (paragraph)

Ideogram's specialty is text. If the brief doesn't need text-in-image, picking Ideogram is choosing the wrong tool.

Extracted rules inside block: NONE

## 571468fb77fdef7f — visual-prompt-forge/adapters/ideogram.md:88-88 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 40ab4a70a93e7d01 — visual-prompt-forge/adapters/ideogram.md:90-90 (list_item)

- **Don't use Mode 2 without the rationale override**, defaults to text-in-image cause double-text (composited + generated) which destroys the comp

Extracted rules inside block: cceb6397276e
