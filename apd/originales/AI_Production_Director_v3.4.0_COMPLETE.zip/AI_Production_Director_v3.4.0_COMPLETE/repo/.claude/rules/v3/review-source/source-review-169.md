# Source coverage review 169/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 5fa42ec15f2dcd38 — video/references/seedance-25.md:34-34 (list_item)

- **Negative commands became reliable.** "Pure video, no subtitles, no background music" now actually suppresses random subtitles and unwanted score — the classic 1.x/2.0 failure is fixed.

Extracted rules inside block: NONE

## e6a08be9ded8a172 — video/references/seedance-25.md:35-35 (list_item)

- **Second-level timestamp control.** `[0-4s] ...` beat windows are honored as timing, not just ordering.

Extracted rules inside block: NONE

## 15ede5c29777b0ae — video/references/seedance-25.md:36-36 (list_item)

- **Editing an existing video** (partial re-render, background swap, language re-dub) and **extending** it are first-class modes, not workarounds.

Extracted rules inside block: NONE

## 3a1488fa8e69b41f — video/references/seedance-25.md:37-37 (list_item)

- **Blockout control**: white-model 3D previz video (or green-screen plates) locks camera path, staging and blocking; Blender/Maya plugins upload straight to Jimeng.

Extracted rules inside block: NONE

## dba80db0f2c5c6e5 — video/references/seedance-25.md:39-39 (paragraph)

Entry points: Jimeng (jimeng.jianying.com — Omni Reference / Smart Edit / Long Video / First & Last Frames), Doubao (Pro subscription), Xiaoyunque (xyq.jianying.com — character library, 3D director stage, segment reshoot).

Extracted rules inside block: NONE

## 43a2f142e57987ab — video/references/seedance-25.md:41-41 (heading)

## 2. Specs and hard limits

Extracted rules inside block: NONE

## a6e8492f2c364e36 — video/references/seedance-25.md:43-43 (table_row)

| Parameter | 2.0 | 2.5 |

Extracted rules inside block: NONE

## 4afabce4dbb9d823 — video/references/seedance-25.md:45-45 (table_row)

| Single-pass duration | up to 15s | up to **30s** (duration `-1` or 4-30) |

Extracted rules inside block: NONE

## a333df2a23e54a70 — video/references/seedance-25.md:46-46 (table_row)

| Images per request | 9 | **30** (each ≤4K, ≤30 MB) |

Extracted rules inside block: NONE

## 13d9b9e6165b7a81 — video/references/seedance-25.md:47-47 (table_row)

| Video references | 3 clips, ≤15s total | **10 clips**, single 2-30s, **≤30s total** |

Extracted rules inside block: NONE

## 9a98bb58b396af6d — video/references/seedance-25.md:48-48 (table_row)

| Audio references | 3 clips, ≤15s total | **10 clips, ≤30s total**; audio-only input now allowed |

Extracted rules inside block: NONE

## 567df50e09a4735f — video/references/seedance-25.md:49-49 (table_row)

| Output resolution | up to 4K | **480p / 720p** on Jimeng web |

Extracted rules inside block: NONE

## 92de9c48753695c3 — video/references/seedance-25.md:50-50 (table_row)

| Timestamps | ordering hints only | honored to the second |

Extracted rules inside block: NONE

## 5d3dae93152880c5 — video/references/seedance-25.md:52-52 (paragraph)

Generation parameters (duration, aspect ratio, resolution) are set on the generation page or via API — **they do not belong in the prompt**. The 1.x/2.0 CLI tail (`--resolution ... --duration ...`) is not 2.5 syntax. Exception: in Ultra Long mode, restate duration and ratio at the top of the prompt.

Extracted rules inside block: 81d74b992994

## cdcb53de5cf9cd30 — video/references/seedance-25.md:54-54 (paragraph)

Auto-locked parameters: video editing locks ratio and duration to the input (±0.3s); first/last frame locks ratio to the first image (a mismatched last frame gets stretched); extension locks ratio, duration settable.

Extracted rules inside block: NONE

## a27e32ef1067d725 — video/references/seedance-25.md:56-56 (heading)

## 3. Official prompt formula

Extracted rules inside block: NONE

## 5f2e3d7e250f55b9 — video/references/seedance-25.md:58-58 (paragraph)

Base formula for any 2.5 prompt:

Extracted rules inside block: NONE

## 3306bc69b2c0dca9 — video/references/seedance-25.md:60-65 (code)

```text
<Subject> performs <primary action or event> in <scene and environment>.
The visuals feature <visual style>.
Use <shot size, camera angle, camera movement, or cuts>.
Audio includes <dialogue, ambience, sound effects, or music>.
```

Extracted rules inside block: NONE

## 1019ec14792df744 — video/references/seedance-25.md:67-67 (paragraph)

Any component may be omitted. For long or reference-heavy work, the macro-formula:

Extracted rules inside block: NONE

## c329f90ebaec14c8 — video/references/seedance-25.md:69-71 (code)

```text
Complete prompt = [reference declaration] + [one-line summary] + [plot by timeline] + [global tail]
```

Extracted rules inside block: NONE

## 2d4bad6bcc9b86df — video/references/seedance-25.md:73-73 (list_item)

- **Reference declaration.** Each asset by upload order + its role (character / voice / motion / scene). See section 5.

Extracted rules inside block: NONE

## 212cc3124ccb53a0 — video/references/seedance-25.md:74-74 (list_item)

- **One-line summary.** Subject + place + event + genre/style + special camera treatment.

Extracted rules inside block: NONE

## d583901a576b98b1 — video/references/seedance-25.md:75-75 (list_item)

- **Plot by timeline.** Per beat: ➕ positive content (picture + camera + action + dialogue + SFX) and ➖ local bans ("no subtitles", "no BGM").

Extracted rules inside block: NONE

## 0f7edbe8bbc2dacf — video/references/seedance-25.md:76-76 (list_item)

- **Global tail.** Re-state the must-hold globals (camera position, environment, sound, lighting) and repeat the global bans.

Extracted rules inside block: 5a27d80e94dd

## c2ec1c0b97d00056 — video/references/seedance-25.md:78-78 (paragraph)

Re-@ the same asset multiple times through the prompt — the official guide says repeated mentions increase accuracy.

Extracted rules inside block: NONE

## 33a92e336453b22d — video/references/seedance-25.md:80-80 (heading)

## 4. Syntax markers for audio, dialogue and text

Extracted rules inside block: NONE

## fc22c4b7718c6106 — video/references/seedance-25.md:82-82 (paragraph)

2.5 has dedicated markers. Use them — do not describe audio in loose prose:

Extracted rules inside block: 0becd213ab65

## a9b20abf4a4aa993 — video/references/seedance-25.md:84-84 (table_row)

| Content | Marker | Example |

Extracted rules inside block: NONE

## 48da223df04693d9 — video/references/seedance-25.md:86-86 (table_row)

| Music | `( )` | `(Soft, rhythmic piano music plays in the background)` |

Extracted rules inside block: NONE

## 81f7281478dfbc91 — video/references/seedance-25.md:87-87 (table_row)

| Sound effect | `< >` | `<A bell rings in the distance>` |

Extracted rules inside block: NONE
