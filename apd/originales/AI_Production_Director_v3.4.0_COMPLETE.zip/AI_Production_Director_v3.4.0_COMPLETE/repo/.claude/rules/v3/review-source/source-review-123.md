# Source coverage review 123/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 21e937429857c2c3 — storyboard-html-preview/SKILL.md:226-226 (paragraph)

The exception: if the user explicitly opts in (e.g. "make it pretty, I'm online"), Tailwind via CDN is acceptable. Default is no.

Extracted rules inside block: NONE

## 1d4cf74ec676575e — storyboard-html-preview/SKILL.md:228-228 (heading)

### Rule 3. Print must work

Extracted rules inside block: NONE

## 083087fdc67eac12 — storyboard-html-preview/SKILL.md:230-230 (paragraph)

Hit Cmd-P. The result should be a clean PDF. If layout breaks across page boundaries, the print stylesheet is broken.

Extracted rules inside block: 1758e630dab9

## 566136b63eff179a — storyboard-html-preview/SKILL.md:232-232 (heading)

### Rule 4. Brand-aware but quiet

Extracted rules inside block: NONE

## 6afd1d3552484d04 — storyboard-html-preview/SKILL.md:234-234 (paragraph)

Use brand colors as accents, not as full backgrounds. The reviewer's job is to read the storyboard, not admire the design. Subtle.

Extracted rules inside block: 0e80dce7eae5

## 7e722bcdcfb9f03d — storyboard-html-preview/SKILL.md:236-236 (heading)

### Rule 5. Mobile-readable

Extracted rules inside block: NONE

## a892f543424428c6 — storyboard-html-preview/SKILL.md:238-238 (paragraph)

Stakeholders open links on phones. The HTML should be readable on mobile without horizontal scroll. Simple responsive CSS.

Extracted rules inside block: 8615a9a49c88

## 0bcf919ccbf4e579 — storyboard-html-preview/SKILL.md:240-240 (heading)

## Templates

Extracted rules inside block: NONE

## 44e51419cbf7c208 — storyboard-html-preview/SKILL.md:242-242 (list_item)

- `templates/preview.html.tpl`, the structural template

Extracted rules inside block: NONE

## 787924f439fc31f0 — storyboard-html-preview/SKILL.md:243-243 (list_item)

- `templates/styles.css.tpl`, the CSS to inline

Extracted rules inside block: NONE

## 86894e088c5d14ae — storyboard-html-preview/SKILL.md:244-244 (list_item)

- `templates/print.css.tpl`, the print rules

Extracted rules inside block: NONE

## 62203cf8cd14e404 — storyboard-html-preview/SKILL.md:246-246 (paragraph)

The skill reads all three and assembles them into a single `preview.html`.

Extracted rules inside block: NONE

## 1164a903e6b36702 — storyboard-html-preview/SKILL.md:248-248 (heading)

## Quality bar

Extracted rules inside block: NONE

## fffad37d48607dff — storyboard-html-preview/SKILL.md:250-250 (paragraph)

Before declaring done, verify:

Extracted rules inside block: NONE

## 31999a630fcafd79 — storyboard-html-preview/SKILL.md:252-252 (list_item)

- [ ] File opens in any browser (Chrome, Safari, Firefox) with no errors

Extracted rules inside block: NONE

## 3ef8b93118b8a08f — storyboard-html-preview/SKILL.md:253-253 (list_item)

- [ ] No external network requests fire on load

Extracted rules inside block: NONE

## 2057882a7a3686b6 — storyboard-html-preview/SKILL.md:254-254 (list_item)

- [ ] Print preview produces a clean PDF

Extracted rules inside block: NONE

## 59daba730096bde5 — storyboard-html-preview/SKILL.md:255-255 (list_item)

- [ ] Mobile viewport (375px) renders without horizontal scroll

Extracted rules inside block: NONE

## 43750aed4f2287cd — storyboard-html-preview/SKILL.md:256-256 (list_item)

- [ ] Brand colors and fonts come from the brand-lock, not from a fallback

Extracted rules inside block: NONE

## a5365489c9618cad — storyboard-html-preview/SKILL.md:257-257 (list_item)

- [ ] Every shot from `shots.json` is present

Extracted rules inside block: NONE

## 1a9646b10a56e8e4 — storyboard-html-preview/SKILL.md:258-258 (list_item)

- [ ] Every overlay referenced by a shot is rendered, including second and third overlays

Extracted rules inside block: NONE

## 40240f3c0beef6cc — storyboard-html-preview/SKILL.md:259-259 (list_item)

- [ ] `brand_lock_ref` from `shots.json` is what the footer links to, not a hardcoded name

Extracted rules inside block: NONE

## 3e2a1148e8e0b8d6 — storyboard-html-preview/SKILL.md:260-260 (list_item)

- [ ] The run date and the render date are both shown, and labelled differently

Extracted rules inside block: NONE

## 90f52a0085bb7821 — storyboard-html-preview/SKILL.md:261-261 (list_item)

- [ ] No `{{` remains anywhere in the output

Extracted rules inside block: NONE

## 0d5da1d778240270 — storyboard-html-preview/SKILL.md:263-263 (paragraph)

The CLI renderer checks the mechanical half of that list against itself:

Extracted rules inside block: NONE

## 3ad7ad0e0dd3f9a9 — storyboard-html-preview/SKILL.md:265-267 (code)

```bash
python tools/shots-to-html.py --selftest
```

Extracted rules inside block: NONE

## c5dbd4b7226d248d — storyboard-html-preview/SKILL.md:269-269 (heading)

## Two timestamps, not one

Extracted rules inside block: NONE

## bc998645dde12537 — storyboard-html-preview/SKILL.md:271-272 (paragraph)

"Run" is when the storyboard was produced, read from `run.json`. "Rendered" is when the page
was written. They are separate lines in the footer and they must stay separate.

Extracted rules inside block: fec99a316eac

## 5b93cf1fa0e35bf3 — storyboard-html-preview/SKILL.md:274-276 (paragraph)

Collapsing them into a single "Generated" date meant re-rendering a preview six months later
restamped the run as today, and the footer went on asserting the page was built against a
brand-lock on a date that had nothing to do with the frames above it.

Extracted rules inside block: NONE

## 19190f579f985e24 — storyboard-html-preview/SKILL.md:278-279 (paragraph)

If the brand-lock on disk no longer hashes to what `run.json` recorded, say so on the page.
The reader is looking at frames built against a brand state they can no longer see.

Extracted rules inside block: NONE
