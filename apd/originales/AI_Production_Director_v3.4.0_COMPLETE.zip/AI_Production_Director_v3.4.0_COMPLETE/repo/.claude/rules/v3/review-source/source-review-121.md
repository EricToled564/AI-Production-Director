# Source coverage review 121/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 158063858bf14e0a — storyboard-html-preview/SKILL.md:42-42 (list_item)

3. `frames/round-{highest}/{shot_id}.{png,jpg,jpeg,webp}`

Extracted rules inside block: 171b4dd71633

## 96c041db51b7c63e — storyboard-html-preview/SKILL.md:43-43 (list_item)

4. `generated/{shot_id}.{ext}`, the pre-3.0.0 flat layout

Extracted rules inside block: 1d9a24a86e36

## 73237c243740f423 — storyboard-html-preview/SKILL.md:45-46 (paragraph)

Data first, convention second. Reading the path convention first meant the page showed
whatever file happened to sit there, accepted or rejected, first draft or fifth re-roll.

Extracted rules inside block: NONE

## 3914c95e6983939f — storyboard-html-preview/SKILL.md:48-49 (paragraph)

If no frames exist yet, the HTML uses styled placeholder cards with the shot spec, still
useful for review and handoff.

Extracted rules inside block: NONE

## b9e4aba2abd8ee3f — storyboard-html-preview/SKILL.md:51-51 (heading)

## Workflow

Extracted rules inside block: NONE

## 3270c0db7fe4da32 — storyboard-html-preview/SKILL.md:53-53 (heading)

### Step 1. Read inputs

Extracted rules inside block: NONE

## 459e560bdbf36689 — storyboard-html-preview/SKILL.md:55-55 (paragraph)

Required:

Extracted rules inside block: NONE

## 839ebb4b435ab20f — storyboard-html-preview/SKILL.md:57-57 (list_item)

- `shots.json`

Extracted rules inside block: NONE

## 6e47ca3568f64b64 — storyboard-html-preview/SKILL.md:58-58 (list_item)

- `text-overlays.json`

Extracted rules inside block: NONE

## 7b827e8f60c2f646 — storyboard-html-preview/SKILL.md:59-59 (list_item)

- `brand-lock.snapshot.md`

Extracted rules inside block: NONE

## 7c03745d813d0fec — storyboard-html-preview/SKILL.md:61-61 (paragraph)

Optional:

Extracted rules inside block: NONE

## 36b619aa1f19bdb0 — storyboard-html-preview/SKILL.md:63-63 (list_item)

- `run.json` (for the run id and date; without it the page says "not recorded")

Extracted rules inside block: NONE

## 2dc8fd2d687cbb8d — storyboard-html-preview/SKILL.md:64-64 (list_item)

- `storyboard.md` (for narrative context, surface the brief at the top)

Extracted rules inside block: NONE

## 853011d4573706a9 — storyboard-html-preview/SKILL.md:65-65 (list_item)

- `frames/round-N/{shot_id}.{png,jpg,jpeg,webp}` (if generation has happened)

Extracted rules inside block: NONE

## a136785ef2c37d7f — storyboard-html-preview/SKILL.md:66-66 (list_item)

- `critiques/round-N/{shot_id}.critique.json` (for verdict badges)

Extracted rules inside block: NONE

## 26bb238d71c455cd — storyboard-html-preview/SKILL.md:68-68 (paragraph)

Validate before rendering, and stop if it fails:

Extracted rules inside block: NONE

## 9c00d2cdc942a921 — storyboard-html-preview/SKILL.md:70-72 (code)

```bash
python tools/validate_shots.py output/
```

Extracted rules inside block: NONE

## bf9ffe43b1062869 — storyboard-html-preview/SKILL.md:74-74 (heading)

### Step 2. Extract brand parameters

Extracted rules inside block: NONE

## 960af5d2e4a2866b — storyboard-html-preview/SKILL.md:76-76 (paragraph)

From `brand-lock.snapshot.md`, extract:

Extracted rules inside block: NONE

## 31828c511e824fa4 — storyboard-html-preview/SKILL.md:78-78 (list_item)

- Palette (hex values), used for HTML accent colors

Extracted rules inside block: NONE

## 5920f49b161ed100 — storyboard-html-preview/SKILL.md:79-79 (list_item)

- Display font and body font names, used as font-family values with system fallbacks

Extracted rules inside block: NONE

## 83aeed6e7875d17e — storyboard-html-preview/SKILL.md:80-80 (list_item)

- Brand voice / mood, used in subtle copy choices

Extracted rules inside block: NONE

## cc2d7728af92681a — storyboard-html-preview/SKILL.md:82-82 (paragraph)

The HTML preview should *feel* like the brand without going overboard. Quiet branding, not loud.

Extracted rules inside block: cc74e13c17ee

## 6445b1ae6338bae5 — storyboard-html-preview/SKILL.md:84-84 (heading)

### Step 3. Generate the HTML

Extracted rules inside block: NONE

## b3c8542305c1d49c — storyboard-html-preview/SKILL.md:86-86 (paragraph)

Use `templates/preview.html.tpl` as the structural template. Read it before generating.

Extracted rules inside block: a8a365f2753e

## 898552bdfe327137 — storyboard-html-preview/SKILL.md:88-88 (paragraph)

The HTML structure:

Extracted rules inside block: NONE

## cbd804c8de389bb1 — storyboard-html-preview/SKILL.md:90-145 (code)

```
<!DOCTYPE html>
<html>
<head>
  <meta>
  <title>{project title}</title>
  <style>
    /* All CSS inline. ~200 lines. Brand-aware. */
    /* Print stylesheet included. */
  </style>
</head>
<body>
  <header>
    <!-- Project title, duration, aspect, generated timestamp -->
  </header>

  <section class="brief">
    <!-- Brief summary if storyboard.md provides one -->
  </section>

  <section class="series-lock">
    <!-- Character / environment / lighting / color grade -->
  </section>

  <section class="shots">
    <!-- One card per shot -->
    <article class="shot" id="shot_01">
      <div class="shot-frame">
        <!-- generated image OR styled placeholder -->
      </div>
      <div class="shot-meta">
        <!-- timestamp, framing, angle, motion -->
      </div>
      <div class="shot-subject">
        <!-- subject description -->
      </div>
      <div class="shot-text-overlay">
        <!-- if on_screen_text exists, show overlay content with timing -->
      </div>
      <div class="shot-rationale">
        <!-- rationale text -->
      </div>
    </article>
    <!-- ... -->
  </section>

  <footer>
    <!-- audit trail: brand-lock snapshot reference, timestamp -->
  </footer>

  <script>
    /* Vanilla JS only. Optional: keyboard nav, jump-to-shot, expand/collapse. */
  </script>
</body>
</html>
```

Extracted rules inside block: NONE

## dbc8d32b64a218e3 — storyboard-html-preview/SKILL.md:147-147 (heading)

### Step 4. Embed frames if available

Extracted rules inside block: NONE

## 6b9452d472e5330d — storyboard-html-preview/SKILL.md:149-150 (paragraph)

Resolve each shot's frame by the order in "What you produce" above, then reference it by a
path relative to the output root:

Extracted rules inside block: NONE

## a78e3f61dcf3a160 — storyboard-html-preview/SKILL.md:152-154 (code)

```html
<img src="frames/round-2/shot_01.png" alt="shot_01: hook" loading="lazy" />
```

Extracted rules inside block: NONE
