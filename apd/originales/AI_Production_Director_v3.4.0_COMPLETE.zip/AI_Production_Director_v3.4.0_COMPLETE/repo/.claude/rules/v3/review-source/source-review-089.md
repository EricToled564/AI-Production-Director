# Source coverage review 89/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## a8f56ea092de30cd — screenwriter/references/pipeline-integration.md:3-3 (paragraph)

This reference provides detailed guidance for integrating screenwriter output with downstream AI tools (imagine, arch-v) in video generation pipelines.

Extracted rules inside block: NONE

## dd8d23114d8d2f92 — screenwriter/references/pipeline-integration.md:5-5 (heading)

## Table of Contents

Extracted rules inside block: NONE

## 831ed6ad961ba526 — screenwriter/references/pipeline-integration.md:6-6 (list_item)

1. [Scene Metadata Standards](#scene-metadata-standards)

Extracted rules inside block: a2f01fee1c92

## c5b5e037dcf637a6 — screenwriter/references/pipeline-integration.md:7-7 (list_item)

2. [Imagine-Ready Visual Descriptions](#imagine-ready-visual-descriptions)

Extracted rules inside block: 9c29d0b530b3

## db9e77daad19221f — screenwriter/references/pipeline-integration.md:8-8 (list_item)

3. [Character Consistency Tracking](#character-consistency-tracking)

Extracted rules inside block: 807408ae1259

## 171f9c1ccf06e7ac — screenwriter/references/pipeline-integration.md:9-9 (list_item)

4. [Scene Numbering Conventions](#scene-numbering-conventions)

Extracted rules inside block: e980a04a5b65

## 73082229fcdc66b5 — screenwriter/references/pipeline-integration.md:10-10 (list_item)

5. [Duration Estimation Guidelines](#duration-estimation-guidelines)

Extracted rules inside block: 58ec4c0f7a81

## dbb5d77354b97e53 — screenwriter/references/pipeline-integration.md:11-11 (list_item)

6. [Output Format Validation](#output-format-validation)

Extracted rules inside block: 7404739226fc

## e0c2b26977d677b2 — screenwriter/references/pipeline-integration.md:12-12 (list_item)

7. [Pipeline Handoff Checklist](#pipeline-handoff-checklist)

Extracted rules inside block: e51a91f098f1

## 6d2cb69570d98c8e — screenwriter/references/pipeline-integration.md:16-16 (heading)

## Scene Metadata Standards

Extracted rules inside block: NONE

## b46c63ff4827d6a3 — screenwriter/references/pipeline-integration.md:18-18 (heading)

### Metadata Completeness

Extracted rules inside block: NONE

## 3231b01561cc858a — screenwriter/references/pipeline-integration.md:20-20 (paragraph)

Every scene MUST include all required metadata fields for reliable pipeline processing:

Extracted rules inside block: ee76ca3a38c3

## 1055fbff20e1772b — screenwriter/references/pipeline-integration.md:22-22 (paragraph)

**Required Fields:**

Extracted rules inside block: 15d8323ce739

## 4f4999dceb2aa5d0 — screenwriter/references/pipeline-integration.md:23-23 (list_item)

- `number`: Integer, sequential scene numbering

Extracted rules inside block: NONE

## d744c6754711e74a — screenwriter/references/pipeline-integration.md:24-24 (list_item)

- `slugline`: Full scene heading (INT/EXT. LOCATION - TIME)

Extracted rules inside block: NONE

## c0a5f68675f16382 — screenwriter/references/pipeline-integration.md:25-25 (list_item)

- `location`: Extracted location name for tracking

Extracted rules inside block: NONE

## 64a9cabc5d5fc710 — screenwriter/references/pipeline-integration.md:26-26 (list_item)

- `time`: Time of day (affects lighting in image generation)

Extracted rules inside block: NONE

## a44a92e5a614f4d6 — screenwriter/references/pipeline-integration.md:27-27 (list_item)

- `characters`: All characters present in scene

Extracted rules inside block: NONE

## f3785522e8ca0efa — screenwriter/references/pipeline-integration.md:28-28 (list_item)

- `mood`: Emotional tone/atmosphere descriptor

Extracted rules inside block: NONE

## dae31aa2f9fd092f — screenwriter/references/pipeline-integration.md:29-29 (list_item)

- `key_visuals`: 3-5 specific visual elements

Extracted rules inside block: NONE

## d3503b2d70d65c7f — screenwriter/references/pipeline-integration.md:30-30 (list_item)

- `action`: Full action/description text

Extracted rules inside block: NONE

## 04cc25e0ea0c48e1 — screenwriter/references/pipeline-integration.md:32-32 (paragraph)

**Optional Fields:**

Extracted rules inside block: NONE

## 009b3005e7b72347 — screenwriter/references/pipeline-integration.md:33-33 (list_item)

- `dialogue`: Include only if dialogue exists

Extracted rules inside block: NONE

## 8a8317779c0306e5 — screenwriter/references/pipeline-integration.md:34-34 (list_item)

- `duration`: Scene duration estimate (helpful for pacing)

Extracted rules inside block: NONE

## 62e99d45270c9262 — screenwriter/references/pipeline-integration.md:36-36 (heading)

### Metadata Quality Guidelines

Extracted rules inside block: NONE

## 98b5258d4b2bc85c — screenwriter/references/pipeline-integration.md:38-38 (paragraph)

**Location Specificity:**

Extracted rules inside block: NONE

## 97af330d9a44964e — screenwriter/references/pipeline-integration.md:39-45 (code)

```xml
<!-- ❌ Too vague -->
<location>Building</location>

<!-- ✅ Specific and descriptive -->
<location>Abandoned Subway Station</location>
```

Extracted rules inside block: NONE

## aafcb661852b2f4c — screenwriter/references/pipeline-integration.md:47-48 (paragraph)

**Mood Descriptors:**
Use 1-3 adjectives that guide visual tone:

Extracted rules inside block: a7acdd69d49d

## 6085184779daf60a — screenwriter/references/pipeline-integration.md:49-49 (list_item)

- Good: "tense, claustrophobic"

Extracted rules inside block: NONE

## 801d54c135e7db2b — screenwriter/references/pipeline-integration.md:50-50 (list_item)

- Good: "serene, hopeful"

Extracted rules inside block: NONE
