# Source coverage review 27/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 07886a12f4474db4 — brand-lock-extractor/examples/brand-lock.md:32-32 (list_item)

- unhurried

Extracted rules inside block: NONE

## e77fea0855213c53 — brand-lock-extractor/examples/brand-lock.md:34-34 (heading)

## Never list

Extracted rules inside block: NONE

## 209e66ea9339460d — brand-lock-extractor/examples/brand-lock.md:36-36 (list_item)

- never use stock smiles or posed lifestyle photography

Extracted rules inside block: f36e0e650709

## 0dc9c8eab1102f0a — brand-lock-extractor/examples/brand-lock.md:37-37 (list_item)

- never use latte art as decoration

Extracted rules inside block: 69053c1a14a1

## 926eb7d1a0ccf9c7 — brand-lock-extractor/examples/brand-lock.md:38-38 (list_item)

- never use the word "artisanal"

Extracted rules inside block: 90a0525b5cb2

## bd2b2a3e545449de — brand-lock-extractor/examples/brand-lock.md:39-39 (list_item)

- never use exclamation points

Extracted rules inside block: cb341b2dcf41

## bc4d48945b5175b6 — brand-lock-extractor/examples/brand-lock.md:40-40 (list_item)

- never shoot glossy product-on-white; matte and natural-light only

Extracted rules inside block: 862d91a99313

## e3e7c77a411ccbf3 — brand-lock-extractor/examples/brand-lock.md:41-41 (list_item)

- never lean on burnt, dark-roast cliche imagery

Extracted rules inside block: 74eaf5a1c505

## 739269bdd8f62f68 — brand-lock-extractor/examples/brand-lock.md:43-43 (heading)

## Aspect ratios

Extracted rules inside block: NONE

## 84c611ce113af03c — brand-lock-extractor/examples/brand-lock.md:45-45 (paragraph)

Default: 4:5 and 9:16 for social, 16:9 for the web hero.

Extracted rules inside block: NONE

## f7174df2b5df3747 — brand-lock-extractor/examples/brand-lock.md:47-47 (heading)

## Color grade direction

Extracted rules inside block: NONE

## 501e65ee4159c409 — brand-lock-extractor/examples/brand-lock.md:49-49 (list_item)

> Matte, low contrast, natural window light, warm but restrained. Reminiscent of Kinfolk editorial photography. Never glossy commercial product lighting.

Extracted rules inside block: 440ca0211156

## fb515a55dee7306f — brand-lock-extractor/examples/brand-lock.md:51-51 (heading)

## Motion language

Extracted rules inside block: NONE

## 629bcb2b0f0fb75f — brand-lock-extractor/examples/brand-lock.md:53-53 (list_item)

> Minimal and unhurried. Static or slow push only. Cuts land on action, not on a timer. Type sets in place, it does not bounce or wobble. No fast cuts, no whip pans.

Extracted rules inside block: NONE

## c9fe36561ea6f3cf — brand-lock-extractor/examples/brand-lock.md:55-55 (heading)

## Voice rules

Extracted rules inside block: NONE

## 4ad7da40c22659de — brand-lock-extractor/examples/brand-lock.md:57-57 (list_item)

- no exclamation points, anywhere

Extracted rules inside block: NONE

## 4d57edf61fcafc98 — brand-lock-extractor/examples/brand-lock.md:58-58 (list_item)

- never the word "artisanal" (or "curated", "elevated")

Extracted rules inside block: 506e350fc6ae

## cdbb3ccb0e5a935f — brand-lock-extractor/examples/brand-lock.md:59-59 (list_item)

- short declarative sentences; cut adjectives before nouns that do not need them

Extracted rules inside block: 2a55a2b423c3

## e6597885c2d384e2 — brand-lock-extractor/examples/brand-lock.md:60-60 (list_item)

- prefer specific origin claims (farm, region, roast date) over vague quality words

Extracted rules inside block: f44a8aca7cce

## a2a483c515094018 — brand-lock-extractor/examples/brand-lock.md:61-61 (list_item)

- no hype words ("best", "premium", "game-changing")

Extracted rules inside block: NONE

## c4e08ea274f325b8 — brand-lock-extractor/examples/brand-lock.md:63-63 (heading)

## Extraction notes

Extracted rules inside block: NONE

## 2cdee72c16a238e9 — brand-lock-extractor/examples/brand-lock.md:65-65 (paragraph)

Audit trail for this extraction. Values not listed here were read directly from an asset (`extracted`): the four palette hex from the site CSS, both font names from the CSS, the never-list lines from the brand sheet, and the aspect ratios from the brand sheet.

Extracted rules inside block: c99f690f2880

## 2952c6a6e11a6ae8 — brand-lock-extractor/examples/brand-lock.md:67-67 (paragraph)

**Inferred** (reasoned from evidence, reasonable to ship):

Extracted rules inside block: NONE

## 1e0879076352b830 — brand-lock-extractor/examples/brand-lock.md:68-68 (list_item)

- Archetype "Maker / Rebel", from "we are roasters, not a lifestyle brand. The coffee does the talking" and the framing of competitors as burnt-cheap or overpriced.

Extracted rules inside block: NONE

## b9ba9b8e1f214acc — brand-lock-extractor/examples/brand-lock.md:69-69 (list_item)

- Mood adjectives, from the plainspoken homepage copy and the matte, natural-light photography described on the brand sheet.

Extracted rules inside block: NONE

## 386ac949a30cd05d — brand-lock-extractor/examples/brand-lock.md:70-70 (list_item)

- Color grade direction, inferred from the brand sheet's photography notes (matte, low-contrast, window light); no graded footage was provided.

Extracted rules inside block: NONE

## c54fbf32b80c85e6 — brand-lock-extractor/examples/brand-lock.md:72-72 (paragraph)

**Needs confirmation** (best estimate, please verify):

Extracted rules inside block: NONE

## dfd15dd347b949cc — brand-lock-extractor/examples/brand-lock.md:73-73 (list_item)

- Rule color `#DCD3C4`, no divider/border color was given; estimated as a darker tint of the paper background. Confirm or replace.

Extracted rules inside block: NONE

## d1cc5a23696f0f58 — brand-lock-extractor/examples/brand-lock.md:74-74 (list_item)

- Font weights (Tiempos Headline Semibold, Söhne Regular/Medium), fonts are confirmed from CSS, weights are estimated from visual weight. Confirm against the brand book.

Extracted rules inside block: NONE

## a673825ebe09e6b6 — brand-lock-extractor/examples/brand-lock.md:75-75 (list_item)

- Motion language, no motion assets were provided; this is a conservative default consistent with the Plainspoken/Confident posture. Confirm against any existing video.

Extracted rules inside block: NONE
