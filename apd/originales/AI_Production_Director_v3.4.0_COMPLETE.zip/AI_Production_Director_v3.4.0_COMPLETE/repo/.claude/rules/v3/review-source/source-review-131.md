# Source coverage review 131/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 94453544002719cf — video/references/animatic-keyframes.md:132-132 (table_row)

| **Anticipation (pre-launch)** | finger over ignition / line-lock; pre-stage bulb lit; held shifter | ECU / CU | finger a hair off the button, bulb just lit cold, everything frozen — the "silence" panel | setup → Pressure |

Extracted rules inside block: NONE

## 91875f81e602ae95 — video/references/animatic-keyframes.md:134-134 (paragraph)

State-change cheat-sheet (board the live state; the dead is implied): ignition dark → lamp blooming; tach idle → needle pinned red; slick round → wrinkle folded deep; water-box mirror-still → shredded by launch; front wheels planted → lifting; chassis level → squatted; chute packed → bloomed at the trap.

Extracted rules inside block: NONE

## 721fa9866eb38e9f — video/references/animatic-keyframes.md:138-138 (heading)

## 6. The loaded frame for one panel

Extracted rules inside block: NONE

## 4120734b7d426b91 — video/references/animatic-keyframes.md:140-140 (paragraph)

A keyframe is a diagram the viewer solves in 0.3s and re-reads with pleasure at 1s. With no face, the geometry and the depth stack do the acting.

Extracted rules inside block: NONE

## 7c474dd1b366aa89 — video/references/animatic-keyframes.md:142-142 (list_item)

> **Core law of the loaded panel.** One focal point, one emotion, three working depth layers, zero dead objects. Answer one question in the first glance; reward a second look.

Extracted rules inside block: NONE

## 4840d94c9914b382 — video/references/animatic-keyframes.md:144-144 (paragraph)

**Depth-layer jobs (FG / MG / BG).** Write the prompt in three explicit depth clauses, each with a stated job. This is the engine of "reads in one glance, rewards a second" (extends `dramaturgy.md` §10 into a single still). If all three planes carry the same blur or scale, you have one plane, not three — force a sharp MG subject against a soft FG frame and a soft BG stake (shallow DOF is the panel's hierarchy tool, `camera-lighting-vocabulary.md` §3).

Extracted rules inside block: 5617d7b6cb17

## 20dcd657da2664a6 — video/references/animatic-keyframes.md:146-146 (table_row)

| Plane | Default job | Drag-race objects | Function it serves |

Extracted rules inside block: NONE

## 6c17b1f36825bfaf — video/references/animatic-keyframes.md:148-148 (table_row)

| **Foreground** | frame / obstruct / put us inside | roll-cage bar, mirror edge, harness strap, smoke wisp, wet glass | Pressure, Power |

Extracted rules inside block: NONE

## 5a95df0290d0d1bf — video/references/animatic-keyframes.md:149-149 (table_row)

| **Midground** | the subject / the act | hand on shifter, knuckles on wheel, foot on pedal, tach face | Detail, Shift, Impact |

Extracted rules inside block: NONE

## 142f893901cb3040 — video/references/animatic-keyframes.md:150-150 (table_row)

| **Background** | stakes / context / rival | staging bulb, rival lane headlight, finish line, narrowing barrier | Establish, Reveal, Pressure |

Extracted rules inside block: NONE

## 4bed9395cc758e79 — video/references/animatic-keyframes.md:152-152 (paragraph)

**One-glance + reward** — what it does to emotion: an instantly readable frame creates trust; a frame that rewards re-reading creates density and worth. With no face to anchor on, a muddy panel collapses to nothing. — *in a keyframe*: name the single focal point before generating (tach needle / staging bulb / knuckle), put it on a strong line, demote everything else to support. The second-look reward is a reflection, a bridge object, or a state indicator — one, not a clutter.

Extracted rules inside block: NONE

## 09ab57f64f7f12fe — video/references/animatic-keyframes.md:154-154 (paragraph)

**Centerline spine, then break symmetry** — emotion: a single dominant axis (lane stripe, the Christmas Tree, a dividing wall) gives the eye a rail and makes even a chaotic frame readable; breaking it the instant one car noses ahead reads as momentum. — seen: Anderson centers for instant legibility; Bong breaks balanced staging to show a power shift. — *in a keyframe*: build one head-on symmetric "breath" panel — both cars mirrored across the centerline, Tree dead-middle, equal negative space (tag **Establish/Pressure**, hold longest). On the next panel, break the mirror — hero a nose ahead, rival shoved soft, centerline slid off the third (tag **Shift/Impact**). Use the pair exactly once, at the launch; overusing symmetry kills the speed.

Extracted rules inside block: b04c20e4e99f

## cffd1800256c8cc6 — video/references/animatic-keyframes.md:156-156 (paragraph)

**Functional vs decorative clutter — the evidence test.** Keep an object only if it does at least one of: (1) **indicator of state** (replaces the face — tach in the red, white knuckles), (2) **stage of action** (advances the beat — front wheel 7" off the line = pre-stage), (3) **bridge to the next panel** (sets up a match-cut or a reach). Dead detail — coffee cup, mirror dice, dashboard sticker — shows no state, advances nothing, bridges nowhere. Cut it. "Each object is a clue" (Park); functional clutter *loads* the frame, decorative clutter *weakens* it.

Extracted rules inside block: NONE

## 6e0587d75e15be9c — video/references/animatic-keyframes.md:158-158 (paragraph)

**Angle encodes the beat** (no face, so the angle *is* the emotion): low / ground-level = power, threat, launch force (**Power, Impact**); eye-level lateral = parity, rivalry stated (**Establish**); high / top-down = judgment, smallness, aftermath (**Aftermath, Exit**).

Extracted rules inside block: NONE

## 9b6aefb05e46e95d — video/references/animatic-keyframes.md:162-162 (heading)

## 7. From keyframe to image-gen prompt

Extracted rules inside block: NONE

## 04b679bc41c40d66 — video/references/animatic-keyframes.md:164-164 (paragraph)

A keyframe card becomes a still prompt by following the universal skeleton (`universal-rules.md` U1) with weight at the start (U2). **Lead with framing + lens + light + palette + anchor object** — these are the load-bearing tokens for a still; the model puts most attention on the first 30-40% of tokens.

Extracted rules inside block: NONE

## 875206abf12534a6 — video/references/animatic-keyframes.md:166-166 (paragraph)

Panel → prompt skeleton:

Extracted rules inside block: NONE

## 046fe64454cb760f — video/references/animatic-keyframes.md:168-177 (code)

```text
[Framing + lens]           e.g. "Low bumper-height macro, 24mm, shot past a blurred roll-cage bar"
[Anchor subject + state]   the ONE object at its threshold: "rear slick sidewall wrinkling at the contact patch"
[Depth clauses, 3 jobs]    FG frame / obstruct · MG subject / act · BG stake / rival
[Motion-as-still cue]      "sharp subject against horizontal motion-blurred background, foreground reference elongated into a light-streak, rear rim spokes smeared to a disc"
[Light + palette]          one motivated source + direction + surface it rims; concrete colors; amber-ban
[Texture]                  "fine film grain heaviest in shadow, halation on the practicals, one anamorphic flare, crushed blacks"
[Face rule]                "no face" — or "driver a featureless silhouette against blown rival headlights, only knuckle highlights legible"
[Aspect / no-speed-up note]  "no speed-ramp; build velocity into the static frame"
```

Extracted rules inside block: NONE

## 17924c5711125b2f — video/references/animatic-keyframes.md:179-179 (paragraph)

Rules that keep the still honest:

Extracted rules inside block: NONE

## 8533b751666c7eb0 — video/references/animatic-keyframes.md:181-181 (list_item)

- **Name the differential blur explicitly.** Models default to over-clean stabilization. Write "motion blur on background, fast-shutter look, sharp subject, rim spokes smeared to a disc." Equal/no blur is the most-faked and most-failed cue (anti-fake firewall, §4 speed-budget).

Extracted rules inside block: NONE

## 14a18cb7056acb06 — video/references/animatic-keyframes.md:182-182 (list_item)

- **Keep faces out or fragmented.** Convert any would-be face to silhouette / contre-jour with a rim and one glint. No features.

Extracted rules inside block: NONE

## e0714457b45cb221 — video/references/animatic-keyframes.md:183-183 (list_item)

- **Render audio as physical consequence, never as a named sound.** "Loud engine" is banned filler (`dramaturgy.md` §2) — prompt "heat-haze warp off the headers, exhaust flame, chassis squat, sidewall wrinkle" instead.

Extracted rules inside block: ae679fbb2922

## d6b77c640ecea1e8 — video/references/animatic-keyframes.md:184-184 (list_item)

- **Anti-sterile guard.** If the panel could be captioned "clean," "beautiful lighting," or "high quality," it has failed — name the grain, the bloom, the crushed black, the one specular hit (`universal-rules.md` U12). One motivated source dominates; ~70% of the frame stays unlit (`camera-lighting-vocabulary.md` §5-7).

Extracted rules inside block: NONE

## da2e91788c33209a — video/references/animatic-keyframes.md:186-186 (paragraph)

Cross-link the vocabulary file for every framing/lens/light token. Then **the keyframe is the locked first frame**; hand it to `seedance.md` / `kling.md` / `veo.md` with the single dominant move (one per 5s — `camera-lighting-vocabulary.md` §2) to animate it. Name in the model syntax: "low bumper-height camera, asphalt streaking, motion blur on background, sharp subject, no speed-up."

Extracted rules inside block: NONE

## 5d7b608a7e6b0730 — video/references/animatic-keyframes.md:190-190 (heading)

## 8. Worked keyframe board for a 30s race spot

Extracted rules inside block: NONE

## 9b10688ea6dfe77c — video/references/animatic-keyframes.md:192-192 (paragraph)

A Sportsman-tree drag run, cold palette, no faces — ~13 panels using the card. This is the deliverable template the user fills: each row is a compressed keyframe card, format-C compatible (`Time | Shot | Function | Action | Camera | Light | Sound | Emotion`). Cut length collapses toward the green, holds on the wrinkle, then accelerates to the finish.

Extracted rules inside block: NONE

## 1773c1746f593fa1 — video/references/animatic-keyframes.md:194-194 (table_row)

| Time | Shot (anchor) | Function | Action (state-change + motion-as-still) | Camera (implied move) | Light (cold) | Sound | Emotion-via-object |

Extracted rules inside block: NONE

## 9fbcc0f7452952b8 — video/references/animatic-keyframes.md:196-196 (table_row)

| 0.0–2.5 | Slick into water box | Establish | Front tyre breaks mirror-still water; bulb reflected in the sheet | locked macro, low (held) | steel-blue, wet specular | idle lope, water trickle | coiled stillness |

Extracted rules inside block: NONE

## c1f616e0a16d197b — video/references/animatic-keyframes.md:197-197 (table_row)

| 2.5–5.0 | Burnout wall | Power | Rear erupts a smoke wall, car straining on line-lock; smoke backlit luminous | ground-level wide (burnout-cam) | cyan backlight through smoke, red tail bleed | lope → tyre scream | leashed force |

Extracted rules inside block: NONE

## 01b18c7285414d18 — video/references/animatic-keyframes.md:198-198 (table_row)

| 5.0–6.5 | Pre-stage bulb + front tyre | Pressure | Tyre creeps, top blue bulb lights, beam line as graphic spine | CU, static | blue glow on wet metal | lope thickens | held breath |

Extracted rules inside block: NONE
