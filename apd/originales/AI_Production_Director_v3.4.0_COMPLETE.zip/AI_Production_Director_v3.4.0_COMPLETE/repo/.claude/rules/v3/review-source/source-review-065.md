# Source coverage review 65/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 6e9ed63e75b8ba25 — image/references/prompt-framework.md:107-107 (list_item)

> Image grounding (поиск реальных мест в интернете) и экстремальные ratio (1:8, 8:1, 4:1) — только Nano Banana. См. [nano-banana.md](nano-banana.md).

Extracted rules inside block: NONE

## e8dbbb5aa767d3cc — image/references/prompt-framework.md:109-109 (heading)

## Examples by Type

Extracted rules inside block: NONE

## 58bb35900c99784b — image/references/prompt-framework.md:111-111 (heading)

### Photorealistic

Extracted rules inside block: NONE

## 5630be3c1e9c2c7c — image/references/prompt-framework.md:112-118 (code)

```
Portrait of a weathered fisherman, 60s, deep wrinkles and sun-damaged skin.
Early morning golden hour on wooden dock.
Holding fresh catch, genuine smile of satisfaction.
Background: misty harbor, fishing boats soft focus.
Mood: authentic, documentary style
```

Extracted rules inside block: NONE

## e66930fddb9087d1 — image/references/prompt-framework.md:120-120 (heading)

### Product/Commercial

Extracted rules inside block: NONE

## 1b19deff02ccdea2 — image/references/prompt-framework.md:121-128 (code)

```
Product shot: luxury watch on raw concrete slab.
Single hard light from upper right, creating defined shadow.
Watch face at 10:10 position, metal bracelet draped naturally.
Background: gradient gray, vignette edges.
Style: high-end catalog, editorial
Format: 4:5
```

Extracted rules inside block: NONE

## c1ec834101683d63 — image/references/prompt-framework.md:130-130 (heading)

### Minimalist

Extracted rules inside block: NONE

## 62faa2640a7aa70f — image/references/prompt-framework.md:131-137 (code)

```
Single origami crane, red paper, centered.
Pure white infinite background.
Soft diffused light, barely visible shadow.
Extreme negative space - crane occupies <10% of frame.
Format: 1:1
```

Extracted rules inside block: NONE

## 9c13a4526b6d7a6b — image/references/prompt-framework.md:139-139 (heading)

### Text Rendering

Extracted rules inside block: NONE

## 538899b426a78916 — image/references/prompt-framework.md:140-151 (code)

```
Motivational poster for gym.

Background: dark textured concrete, subtle vignette.

Text:
"DISCIPLINE" in extra bold, white, centered upper third
"beats talent" in thin weight, #808080, centered below

Small icon: minimal dumbbell silhouette, bottom center
Format: 9:16 (stories)
```

Extracted rules inside block: NONE

## f658da204a33a1b5 — image/references/prompt-framework.md:153-153 (heading)

## Parameterized Templates

Extracted rules inside block: NONE

## a403b61c47fa86e2 — image/references/prompt-framework.md:155-155 (paragraph)

Паттерн `{variable}` для переиспользуемых промптов. Структура промпта остаётся стабильной — меняется только то, что нужно.

Extracted rules inside block: NONE

## 6ddb6925606f7da5 — image/references/prompt-framework.md:157-157 (heading)

### Синтаксис

Extracted rules inside block: NONE

## 4805ac65bb751af8 — image/references/prompt-framework.md:159-159 (paragraph)

Переменные записываются как `{name, default="value"}`. Если значение не указано — используется дефолт. Если дефолта нет — переменная обязательна.

Extracted rules inside block: 15e242e71a48

## 3016a63e99398797 — image/references/prompt-framework.md:161-161 (heading)

### Шаблон

Extracted rules inside block: NONE

## ad8e69e7c5af638a — image/references/prompt-framework.md:163-169 (code)

```
Scene: {location, default="small Lisbon florist storefront at blue hour"}
Subject: {person, default="woman in navy apron"} {action, default="locking the front door"}
Important Details: {lighting}, {lens_feel, default="50mm feel"}, {key_texture}
Use Case: {use_case, default="editorial photography"}
Constraints: {constraints, default="no extra signage, no people in background"}
```

Extracted rules inside block: NONE

## 3b63f20ed16bcd0a — image/references/prompt-framework.md:171-171 (heading)

### Как использовать

Extracted rules inside block: NONE

## 6733667d00499dfd — image/references/prompt-framework.md:173-173 (list_item)

1. **Заменяй только то, что меняется** — остальное берётся из дефолтов

Extracted rules inside block: a296299de44d

## 6821c6f5d4d02fdf — image/references/prompt-framework.md:174-174 (list_item)

2. **Структура стабильна** — порядок слотов одинаковый для всех вариаций, модель получает консистентный формат

Extracted rules inside block: 380897738a4f

## b0ed8b156297a277 — image/references/prompt-framework.md:175-175 (list_item)

3. **Batch-генерация** — идеально для серий: продуктовые ракурсы, позы персонажа, локации в одном стиле

Extracted rules inside block: d0820f3be29e

## e7e6323d0e5b2350 — image/references/prompt-framework.md:177-177 (heading)

### Примеры использования

Extracted rules inside block: NONE

## 4f61f3cb43fc55b1 — image/references/prompt-framework.md:179-179 (paragraph)

**Серия продуктовых шотов** (меняется только товар и текстура):

Extracted rules inside block: NONE

## 28416d6f6ce6e4eb — image/references/prompt-framework.md:180-186 (code)

```
Scene: {location, default="marble kitchen counter, morning light"}
Subject: {product} on {surface, default="raw linen cloth"}
Important Details: {lighting, default="soft window light from left"}, {lens_feel, default="85mm feel"}, {key_texture}
Use Case: {use_case, default="e-commerce hero shot"}
Constraints: {constraints, default="clean background, no props except surface"}
```

Extracted rules inside block: NONE

## 08e5d6c94b146a85 — image/references/prompt-framework.md:188-188 (paragraph)

**Серия персонажных поз** (меняется действие и настроение):

Extracted rules inside block: NONE

## cd716f7f8ea58173 — image/references/prompt-framework.md:189-195 (code)

```
Scene: {location, default="industrial loft studio"}
Subject: {person, default="man in black turtleneck"} {action}
Important Details: {lighting, default="single softbox, camera right"}, {lens_feel, default="50mm feel"}, {key_texture, default="fabric texture visible"}
Use Case: {use_case, default="fashion editorial"}
Constraints: {constraints, default="no visible logos, neutral expression"}
```

Extracted rules inside block: NONE

## 35467ed75ca101d6 — image/references/prompt-framework.md:197-197 (heading)

## Cinematic Verbose Mode

Extracted rules inside block: NONE

## d6333e84ec6a08bb — image/references/prompt-framework.md:199-199 (paragraph)

Стандартный verbose — 5-7 строк. **Cinematic verbose** — уровень выше, для случаев когда нужен максимум детализации: hero shots, ключевые визуалы, campaign centerpieces.

Extracted rules inside block: NONE

## 160f0f0a904c83a3 — image/references/prompt-framework.md:201-201 (heading)

### Когда использовать

Extracted rules inside block: NONE

## d5425b3cee03692e — image/references/prompt-framework.md:203-203 (list_item)

- Финальный визуал кампании, а не итерация

Extracted rules inside block: NONE

## 729c5b696e3e8c24 — image/references/prompt-framework.md:204-204 (list_item)

- Hero shot для лендинга или обложки

Extracted rules inside block: NONE
