# Source coverage review 231/231

Review all 28 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## c41854ccd74e6e04 — visual-prompt-forge/tools/README.md:172-172 (list_item)

- a frame on disk with no critique for its round, never reviewed at all

Extracted rules inside block: ccbc2a89cf61

## 6db9b452b849d83c — visual-prompt-forge/tools/README.md:173-173 (list_item)

- two critiques for the same shot in the same round, two operators colliding

Extracted rules inside block: NONE

## 6adda4cb64aae09c — visual-prompt-forge/tools/README.md:174-174 (list_item)

- rounds that skip a number, or a critique whose `run_id` belongs to another run

Extracted rules inside block: NONE

## db972b8a734f29fd — visual-prompt-forge/tools/README.md:176-177 (paragraph)

`--require-accept` makes it the pipeline stop condition: exit 0 only when the chain is intact
*and* every shot's latest verdict is ACCEPT.

Extracted rules inside block: NONE

## 3ef1181de96728bb — visual-prompt-forge/tools/README.md:179-179 (heading)

## Rendering

Extracted rules inside block: NONE

## e80261984632ac54 — visual-prompt-forge/tools/README.md:181-181 (heading)

### `shots-to-html.py`

Extracted rules inside block: NONE

## 432e7d74a842eb89 — visual-prompt-forge/tools/README.md:183-183 (paragraph)

Renders an output folder into a single `preview.html`.

Extracted rules inside block: NONE

## 82bbc90336476066 — visual-prompt-forge/tools/README.md:185-191 (code)

```bash
python tools/shots-to-html.py output/
python tools/shots-to-html.py output/ --inline-images
python tools/shots-to-html.py output/ --out review.html
python tools/shots-to-html.py output/ --rendered-at 2026-07-30T00:00:00Z
python tools/shots-to-html.py --selftest
```

Extracted rules inside block: NONE

## 269f431742179ad2 — visual-prompt-forge/tools/README.md:193-196 (paragraph)

It renders `skills/storyboard-html-preview/templates/preview.html.tpl`, the same structural
template the skill uses, through the small engine in `_template.py`. It did not always: the
CLI used to build its HTML inline while claiming to share the template, so the two could and
did diverge.

Extracted rules inside block: 40759795a164

## 250574eb20bf2b30 — visual-prompt-forge/tools/README.md:198-199 (paragraph)

Everything interpolated is HTML-escaped. Shot subjects and rationales are model-generated
prose, and one angle bracket used to be enough to break the page.

Extracted rules inside block: NONE

## fc44644eb9e0b647 — visual-prompt-forge/tools/README.md:201-202 (paragraph)

`--rendered-at` pins the render timestamp, which makes output reproducible. CI re-renders
every bundled preview with a pinned value and fails if a byte moves.

Extracted rules inside block: NONE

## 4d7b44b8c8d8645d — visual-prompt-forge/tools/README.md:204-205 (paragraph)

The page shows two dates, deliberately: the **run** date from `run.json`, and the **render**
date. A single "Generated" date meant re-rendering a preview restamped the run as today.

Extracted rules inside block: NONE

## 0a87d15f5a21a7b9 — visual-prompt-forge/tools/README.md:207-207 (heading)

### `copy-prompt.py`

Extracted rules inside block: NONE

## 3b16ba4c32f24141 — visual-prompt-forge/tools/README.md:209-210 (paragraph)

Pipes one shot's prompt to the clipboard so you can paste into a generator UI without hunting
through the file.

Extracted rules inside block: NONE

## 4c9e50715bff2065 — visual-prompt-forge/tools/README.md:212-217 (code)

```bash
python tools/copy-prompt.py output/prompts/round-1/flux.txt
python tools/copy-prompt.py output/prompts/round-2/revised-flux.txt --shot shot_02
python tools/copy-prompt.py output/prompts/round-1/flux.txt --list
python tools/copy-prompt.py --selftest
```

Extracted rules inside block: NONE

## 93c228310df4ce51 — visual-prompt-forge/tools/README.md:219-222 (paragraph)

Reads both file shapes the forge writes. Comment lines inside a shot block are annotations and
never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not
copied. Revision files used to be unreadable to this tool entirely, which was awkward given
they are the files an operator pastes from most.

Extracted rules inside block: cad388b91f11

## 38eec8e705e15806 — visual-prompt-forge/tools/README.md:224-224 (paragraph)

Pure standard library. `pbcopy` on macOS, `xclip` or `xsel` on Linux, `clip` on Windows.

Extracted rules inside block: NONE

## 23609d649136b335 — visual-prompt-forge/tools/README.md:226-226 (heading)

## Internal modules

Extracted rules inside block: NONE

## c8a5e3e2d0709f5c — visual-prompt-forge/tools/README.md:228-228 (paragraph)

Not entry points. Imported by the tools above.

Extracted rules inside block: NONE

## 4390675cf165d84d — visual-prompt-forge/tools/README.md:230-231 (list_item)

- `_shotkit.py`, hashing, run ids, brand-lock parsing, and the output-tree path conventions.
  One copy, so no two tools can disagree about what a palette or a frame path is.

Extracted rules inside block: NONE

## df600b9029eadec6 — visual-prompt-forge/tools/README.md:232-233 (list_item)

- `_template.py`, the template engine: `{{var}}`, `{{{raw}}}`, `{{#each}}`, `{{#if}}`. Only
  the subset `preview.html.tpl` uses, deliberately.

Extracted rules inside block: NONE

## 997564aa6c386500 — visual-prompt-forge/tools/README.md:235-235 (heading)

## Adding new tools

Extracted rules inside block: NONE

## 275b895b5e8b5205 — visual-prompt-forge/tools/README.md:237-237 (list_item)

- Make it executable (`chmod +x`)

Extracted rules inside block: NONE

## 9b6ce2e2d83fbc6b — visual-prompt-forge/tools/README.md:238-238 (list_item)

- Add a usage docstring at the top of the file

Extracted rules inside block: NONE

## 8270ae966e57fe6b — visual-prompt-forge/tools/README.md:239-239 (list_item)

- Give it a `--selftest` that proves the check fires

Extracted rules inside block: NONE

## 9cf4d84989f3a1fd — visual-prompt-forge/tools/README.md:240-240 (list_item)

- Document it in this README

Extracted rules inside block: NONE

## be6456e8b235fa15 — visual-prompt-forge/tools/README.md:241-241 (list_item)

- Wire it into `tools/check.sh`, which is what CI calls

Extracted rules inside block: NONE

## 4240014310299a17 — visual-prompt-forge/tools/README.md:243-243 (paragraph)

Keep tools dependency-light. PyYAML, jsonschema, and the standard library are the baseline.

Extracted rules inside block: NONE
