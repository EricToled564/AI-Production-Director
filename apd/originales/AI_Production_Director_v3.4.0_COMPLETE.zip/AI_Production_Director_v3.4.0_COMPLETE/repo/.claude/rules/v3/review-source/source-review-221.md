# Source coverage review 221/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## aa2f023861919a34 — visual-prompt-forge/adapters/veo.md:67-67 (paragraph)

**Shot with `motion = "static"` and a spoken line.**

Extracted rules inside block: NONE

## 4ca173394e8a0c40 — visual-prompt-forge/adapters/veo.md:69-71 (code)

```
Static camera, locked off, eye level. A founder in his mid-thirties with salt-and-pepper hair in a navy crewneck sits at his laptop in a minimalist home office and looks directly into the lens. He says, "I built the system once, and it runs without me," calm and unhurried. Soft natural side-light from a large window on the left, warm afternoon golden hour. Audio: quiet room tone, faint keyboard, no music. Warm filmic color grade with muted teal shadows. Calm, considered, operator mood.
```

Extracted rules inside block: NONE

## 840b2f033d769a4d — visual-prompt-forge/adapters/veo.md:73-73 (heading)

## Pitfalls to avoid

Extracted rules inside block: NONE

## 39c2315811aba00a — visual-prompt-forge/adapters/veo.md:75-75 (list_item)

- **Don't use Veo for silent B-roll.** You are paying for an audio engine you turned off; use Kling.

Extracted rules inside block: 2cb8d44c9c71

## cfece828409abe40 — visual-prompt-forge/adapters/veo.md:76-76 (list_item)

- **Don't overrun the duration with dialogue.** A line that needs 12s of speech will clip or rush at 8s.

Extracted rules inside block: 0f7c9aeb8f35

## b6562abef86b8674 — visual-prompt-forge/adapters/veo.md:77-77 (list_item)

- **Don't put on-screen text in the prompt.** Spoken lines are fine; rendered captions still come from `text-overlays.json` in post.

Extracted rules inside block: 2f0b1c1117c7

## 5ea7ce3774ecfd2f — visual-prompt-forge/adapters/veo.md:78-78 (list_item)

- **Don't stack two camera moves.** One move per shot.

Extracted rules inside block: 7421f96fc6af

## c2a3519500d8f382 — visual-prompt-forge/adapters/veo.md:79-79 (list_item)

- **Don't let Veo's auto-audio fight a post audio bed.** Pick one owner of sound per shot.

Extracted rules inside block: bb9fa2418c71

## 7370bcc7448d4e57 — visual-prompt-forge/adapters/veo.md:81-81 (heading)

## Output handoff

Extracted rules inside block: NONE

## 1e3d36dcac7ef95b — visual-prompt-forge/adapters/veo.md:83-83 (paragraph)

Veo clips arrive with audio attached. They still need: editorial assembly to timing, on-screen text compositing from `text-overlays.json`, a color-grade pass, and an audio decision, keep Veo's native track, or mute it and use the storyboard's recorded VO and music. State which in handoff.

Extracted rules inside block: 73d5b86aaf30

## 0fc493b8cf661d89 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:1-1 (heading)

# One Shot, All Adapters

Extracted rules inside block: NONE

## c4a675f5bd838625 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:3-3 (paragraph)

This example takes a single shot from the WhyStrohm 30-second pitch and renders it through the generator adapters in the pack. Use it as a calibration reference: same intent, same data, different prompt syntaxes. Six stills adapters are shown, plus the default motion adapter (Kling) standing in for the motion video lane.

Extracted rules inside block: c8b6ffda298d

## 4bede44b3bed199c — visual-prompt-forge/examples/one-shot-all-adapters/README.md:5-5 (heading)

## The source shot

Extracted rules inside block: NONE

## 38c671a2fd99c7a4 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:7-7 (paragraph)

From `examples/30s-pain-proof-promise/shots.json`:

Extracted rules inside block: NONE

## 7e5e2b2c8ea422e6 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:9-22 (code)

```json
{
  "id": "shot_04",
  "beat": "reframe",
  "start": 11.0,
  "end": 16.0,
  "framing": "MCU",
  "angle": "eye-level",
  "motion": "push",
  "depth_of_field": "shallow",
  "subject": "founder, same posture, looking at camera, expression shifts from tired to clear, small almost-smile",
  "rationale": "Slow push as the reframe lands. Same character, same environment, only the expression changes. The change is the point."
}
```

Extracted rules inside block: NONE

## c1b1020a0465d897 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:24-24 (heading)

## Series lock context (constant across all adapters)

Extracted rules inside block: NONE

## 11f24ba513ef57f1 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:26-31 (code)

```
character: founder, mid-thirties, salt-and-pepper hair, navy crewneck, calm posture
environment: minimalist home office, white walls, oak desk, single houseplant
lighting: soft natural side-light, large window camera-left, warm afternoon golden hour
color_grade: warm filmic, muted teal shadows, slight grain
```

Extracted rules inside block: NONE

## 2bb7efdf91c7d7d4 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:33-33 (heading)

## Brand mood

Extracted rules inside block: NONE

## 5a3335d51c46698e — visual-prompt-forge/examples/one-shot-all-adapters/README.md:35-35 (paragraph)

`calm, considered, operator (not creator), confident without volume`

Extracted rules inside block: NONE

## 218c395d2c654758 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:37-37 (heading)

## Outputs

Extracted rules inside block: NONE

## 42982cc7119791e6 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:39-39 (paragraph)

Each `.txt` file in this directory is the prompt for one adapter:

Extracted rules inside block: NONE

## fc46eec4efc6ff1c — visual-prompt-forge/examples/one-shot-all-adapters/README.md:41-41 (list_item)

- `midjourney.txt`. Midjourney v7

Extracted rules inside block: NONE

## 3009f368d886a9c1 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:42-42 (list_item)

- `flux.txt`. Flux 2 Pro

Extracted rules inside block: NONE

## 4c6713202a3139e2 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:43-43 (list_item)

- `ideogram.txt`. Ideogram v3 (composited mode)

Extracted rules inside block: NONE

## 010fdc6c01f9cdc3 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:44-44 (list_item)

- `gpt-image.txt`. GPT Image 1.5

Extracted rules inside block: NONE

## cc8f26ad2f4c7957 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:45-45 (list_item)

- `nano-banana.txt`. Gemini 2.5 Flash Image

Extracted rules inside block: NONE

## 04ecf11b11fa14ea — visual-prompt-forge/examples/one-shot-all-adapters/README.md:46-46 (list_item)

- `seedream.txt`. Seedream 4.5

Extracted rules inside block: NONE

## da440b6258e0d590 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:47-47 (list_item)

- `kling.txt`. Kling 3.0 (motion video, the default motion adapter)

Extracted rules inside block: NONE

## 35c44d288420f2b9 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:49-49 (paragraph)

The other three motion adapters (`veo` for dialogue/lipsync, `seedance` for multi-shot sequences, `hailuo` for budget iteration) follow the same five-layer anatomy as Kling and are chosen by need; see their files in `adapters/`. This single silent push shot doesn't exercise dialogue or a sequence, so Kling is the representative motion example here.

Extracted rules inside block: NONE

## d3925962f8aaffe2 — visual-prompt-forge/examples/one-shot-all-adapters/README.md:51-51 (paragraph)

Note the differences:

Extracted rules inside block: NONE
