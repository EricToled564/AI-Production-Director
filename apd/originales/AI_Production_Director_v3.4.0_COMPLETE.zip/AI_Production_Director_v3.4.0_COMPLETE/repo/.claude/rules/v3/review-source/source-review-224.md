# Source coverage review 224/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## cc4483846860e95d — visual-prompt-forge/references/consistency-locks.md:109-109 (paragraph)

Every one of these is a production problem editorial cannot fully fix. Lock at the prompt level. Save the editor's time.

Extracted rules inside block: NONE

## 709ecfe1fe54ceea — visual-prompt-forge/references/consistency-locks.md:111-111 (heading)

## What doesn't work

Extracted rules inside block: NONE

## 6b7ad193d0a525f0 — visual-prompt-forge/references/consistency-locks.md:113-113 (paragraph)

A few things people try that don't actually fix consistency:

Extracted rules inside block: d5bcf85dd207

## 8bbc26af44b9a3f6 — visual-prompt-forge/references/consistency-locks.md:115-115 (list_item)

- **Adding "consistent character" or "same person" to the prompt**, generators don't read meta-instructions

Extracted rules inside block: 7b3702dfb9b2

## 6e16426d6c987549 — visual-prompt-forge/references/consistency-locks.md:116-116 (list_item)

- **Numbering shots in the prompt** ("shot 3 of 7, same as before"), generators don't have memory across calls

Extracted rules inside block: d2a5a9d6f2cc

## b88331bff7ce8d6f — visual-prompt-forge/references/consistency-locks.md:117-117 (list_item)

- **Long descriptive paragraphs of the character**, past 4–5 features, the generator starts dropping details randomly

Extracted rules inside block: NONE

## b9cc9a22cb2c0fcd — visual-prompt-forge/references/consistency-locks.md:118-118 (list_item)

- **Asking for "exactly the same"**, there is no such thing in stateless image gen; you reduce drift, you don't eliminate it

Extracted rules inside block: 09c105d7a76f

## cd8c79d5655966ce — visual-prompt-forge/references/consistency-locks.md:120-120 (paragraph)

Accept that some shots will need re-rolls. Budget for it. The locks reduce the failure rate; they don't eliminate it.

Extracted rules inside block: a6573f638fb4

## f719d9698ccc79b8 — visual-prompt-forge/references/failure-modes.md:1-1 (heading)

# Failure Modes

Extracted rules inside block: NONE

## d0dc98d9809c08a0 — visual-prompt-forge/references/failure-modes.md:3-3 (paragraph)

What goes wrong when generated images don't match the storyboard, and what to fix at the prompt level vs. accept as editorial work.

Extracted rules inside block: 082ef4c63248

## 990af6ac03091010 — visual-prompt-forge/references/failure-modes.md:5-5 (heading)

## Failure 1. The "AI look"

Extracted rules inside block: NONE

## 0eea1d450aa32dce — visual-prompt-forge/references/failure-modes.md:7-7 (paragraph)

**Symptoms:** plastic skin, oversaturated colors, eyes too symmetrical, hands wrong, generic stock-photo composition, lighting that's too even, "rendered" feel.

Extracted rules inside block: NONE

## 445f1789042ed110 — visual-prompt-forge/references/failure-modes.md:9-9 (paragraph)

**Causes:**

Extracted rules inside block: NONE

## 32223257d6c18e34 — visual-prompt-forge/references/failure-modes.md:10-10 (list_item)

- Generic mood adjectives ("beautiful", "stunning", "amazing")

Extracted rules inside block: NONE

## 20c46dcd753329fa — visual-prompt-forge/references/failure-modes.md:11-11 (list_item)

- Stable Diffusion crutches ("4k", "highly detailed", "masterpiece") in non-SD generators

Extracted rules inside block: NONE

## 9700509f4b2fe039 — visual-prompt-forge/references/failure-modes.md:12-12 (list_item)

- Missing photographic specifics

Extracted rules inside block: NONE

## da8854687d357f0c — visual-prompt-forge/references/failure-modes.md:13-13 (list_item)

- No "never" list applied from brand-lock

Extracted rules inside block: 26f67e595bc5

## f2dbf83a6107a5c3 — visual-prompt-forge/references/failure-modes.md:15-15 (paragraph)

**Prompt-level fixes:**

Extracted rules inside block: NONE

## 076b69359160c58e — visual-prompt-forge/references/failure-modes.md:16-16 (list_item)

- Add specific lens and aperture ("50mm prime, f/2.0")

Extracted rules inside block: NONE

## 55afd302079aabe3 — visual-prompt-forge/references/failure-modes.md:17-17 (list_item)

- Add film stock or camera reference ("Sony FX6", "Kodak Portra 400 film stock")

Extracted rules inside block: NONE

## d18dc36c724ffaf6 — visual-prompt-forge/references/failure-modes.md:18-18 (list_item)

- Add "natural skin texture, no AI rendering artifacts" closing line (Flux, GPT Image)

Extracted rules inside block: NONE

## 48c9ac54418dc817 — visual-prompt-forge/references/failure-modes.md:19-19 (list_item)

- Verify brand-lock "never" list is being applied, if it includes "no AI uncanny", surface that into the prompt

Extracted rules inside block: c927233dce49

## e7ff2922e18edf7f — visual-prompt-forge/references/failure-modes.md:20-20 (list_item)

- Use Flux 2 Pro or Midjourney v7 instead of cheaper models for hero shots

Extracted rules inside block: c6f5af57536e

## 292a977fef7c234c — visual-prompt-forge/references/failure-modes.md:22-22 (paragraph)

**Accept editorially when:** the brief is for stylized content where realism isn't the goal.

Extracted rules inside block: NONE

## e57a737049a50d81 — visual-prompt-forge/references/failure-modes.md:24-24 (heading)

## Failure 2. Character drift across shots

Extracted rules inside block: NONE

## 6152f69edd64994f — visual-prompt-forge/references/failure-modes.md:26-26 (paragraph)

**Symptoms:** same person looks different in shot 1 vs shot 5; clothing changes; hair color shifts; age perceived differently.

Extracted rules inside block: NONE

## 563cc1295ab73f73 — visual-prompt-forge/references/failure-modes.md:28-28 (paragraph)

**Causes:**

Extracted rules inside block: NONE

## a58c527cf512d343 — visual-prompt-forge/references/failure-modes.md:29-29 (list_item)

- Series_lock character string paraphrased rather than verbatim

Extracted rules inside block: NONE

## a3bfd8ead3653aed — visual-prompt-forge/references/failure-modes.md:30-30 (list_item)

- No reference image passed (`--cref`, omni-reference)

Extracted rules inside block: NONE

## 0200489bfc639121 — visual-prompt-forge/references/failure-modes.md:31-31 (list_item)

- Seed not locked

Extracted rules inside block: NONE
