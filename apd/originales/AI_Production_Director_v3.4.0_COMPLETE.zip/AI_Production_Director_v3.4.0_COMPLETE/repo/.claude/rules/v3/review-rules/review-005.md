# Rule classification review 5/35

Review all 35 rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.

## 74eaf5a1c505 — brand-lock-extractor/examples/brand-lock.md:41

never lean on burnt, dark-roast cliche imagery

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "74eaf5a1c505",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 440ca0211156 — brand-lock-extractor/examples/brand-lock.md:49

> Matte, low contrast, natural window light, warm but restrained. Reminiscent of Kinfolk editorial photography. Never glossy commercial product lighting.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "440ca0211156",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 506e350fc6ae — brand-lock-extractor/examples/brand-lock.md:58

never the word "artisanal" (or "curated", "elevated")

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "506e350fc6ae",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 2a55a2b423c3 — brand-lock-extractor/examples/brand-lock.md:59

short declarative sentences; cut adjectives before nouns that do not need them

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "2a55a2b423c3",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## f44a8aca7cce — brand-lock-extractor/examples/brand-lock.md:60

prefer specific origin claims (farm, region, roast date) over vague quality words

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "f44a8aca7cce",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## c99f690f2880 — brand-lock-extractor/examples/brand-lock.md:65

Audit trail for this extraction. Values not listed here were read directly from an asset (`extracted`): the four palette hex from the site CSS, both font names from the CSS, the never-list lines from the brand sheet, and the aspect ratios from the brand sheet.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "c99f690f2880",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## a1e68a72e11b — brand-lock-extractor/examples/input-brief.md:28

Photography: matte, low-contrast, natural window light. Beans, hands, kraft bags. Never glossy product-on-white.

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "a1e68a72e11b",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 63e3397af43d — brand-lock-extractor/examples/input-brief.md:29

"We don't do: stock smiles, latte art as decoration, exclamation points, or the word 'artisanal'."

Seed:
```json
{
  "authority": "EXAMPLE",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "NONE",
  "priority": 400,
  "rule_id": "63e3397af43d",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "none"
  },
  "when": {}
}
```

## 39cc69f567f7 — brand-lock-extractor/references/extraction-rubric.md:10

**inferred**, reasoned from evidence, not stated. Archetype from how the brand frames problems. Never-list from what the assets consistently avoid. Ship it, note the reasoning.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "39cc69f567f7",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## d7cf5322601a — brand-lock-extractor/references/extraction-rubric.md:17

**One-line description:** what the brand does and who for. This is the load-bearing sentence; a generator implicitly references it on every prompt. Pull it from the hero headline plus the about page. Prefer concrete over abstract: "Managed bookkeeping for solo law firms" beats "Financial services for professionals." If the site only offers a vague tagline, sharpen it from the services/about copy a

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": "vocabulary.visual_style_quality",
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "d7cf5322601a",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 4ede25e468da — brand-lock-extractor/references/extraction-rubric.md:19

**Archetype:** one word, Operator, Sage, Caregiver, Rebel, Creator, Jester, Ruler, Everyman, etc. Almost always `inferred`. Read it from how the brand frames the customer's problem:

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "4ede25e468da",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## bfca9c3046b9 — brand-lock-extractor/references/extraction-rubric.md:36

**Never guess a hex.** If you cannot read or sample one, estimate, label it `needs confirmation`, and tell the user exactly which role to verify. (See SKILL.md Rule 1.)

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "bfca9c3046b9",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 859f8b6618ba — brand-lock-extractor/references/extraction-rubric.md:44

**Screenshots:** identify by eye only if confident; otherwise flag `needs confirmation`. Do not invent a plausible name (Rule 2).

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "859f8b6618ba",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 0ddcf2544ddb — brand-lock-extractor/references/extraction-rubric.md:50

3-5 adjectives, specific, contrast clauses preferred. Read tone from the body copy and the imagery together.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "0ddcf2544ddb",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## af979316267e — brand-lock-extractor/references/extraction-rubric.md:56

The hardest and most valuable section. Brands document what they do; you infer what they avoid from consistency across the assets.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "af979316267e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## a441f1d7a7d8 — brand-lock-extractor/references/extraction-rubric.md:59

Imagery: no stock-photo gloss? no people? no gradients? no clip-art icons? Each absence is a never.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "a441f1d7a7d8",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## be855705dd55 — brand-lock-extractor/references/extraction-rubric.md:60

Copy: no exclamation points? no hype words ("revolutionary", "game-changing")? no emojis? no questions in headlines? Each pattern is a never.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "be855705dd55",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 971c7f32e6be — brand-lock-extractor/references/extraction-rubric.md:61

Color/layout: never full-bleed photography? never more than one accent? never centered body text?

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "971c7f32e6be",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 3f31edc925bf — brand-lock-extractor/references/extraction-rubric.md:63

Turn each observed constraint into a `never` line. Be specific: "never use stock-photo aesthetic" beats "keep it authentic". Aim for 5+. Never ship an empty list (Rule 4).

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "3f31edc925bf",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 7bbf6d48abcc — brand-lock-extractor/references/extraction-rubric.md:71

One sentence on how footage and generated images should be graded, with a reference point where possible (Kodak Portra 400, Apple keynote photography, A24 film grade). Infer from the existing photography's warmth, contrast, and saturation. If there is no photography to read, base it on the palette and flag `needs confirmation`.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "7bbf6d48abcc",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## d98eaed160fe — brand-lock-extractor/references/extraction-rubric.md:75

One paragraph: camera moves, cut style, text animation, pacing. Read from any existing video or motion on the site; if there is none, infer a conservative default consistent with the voice posture (a Quiet/Authoritative brand -> minimal, slow, deliberate) and flag `needs confirmation`. Keep it to one coherent motion language, do not blend "minimal and deliberate" with "energetic whip pans".

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d98eaed160fe",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## d46a58d6e6bc — brand-lock-extractor/references/extraction-rubric.md:79

Copy-level constraints for VO and on-screen text. Many overlap the never-list but are phrased as authoring rules: "no em dashes", "sentences under 14 words", "prefer specific numbers over vague claims", "no exclamation points in headlines". Extract from observed copy patterns. These become prompt constraints downstream, so make them enforceable, not aspirational.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "d46a58d6e6bc",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 85bcf8700581 — brand-lock-extractor/tools/README.md:32

Checks every `SKILL.md` in `skills/` has the required YAML frontmatter, a `name` that matches

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "85bcf8700581",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 6940141b8971 — brand-lock-extractor/tools/README.md:72

Checks a brand-lock has all required sections and Identity fields, that its palette declares

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "6940141b8971",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "any": [
          {
            "op": "eq",
            "path": "stage",
            "value": "brief"
          },
          {
            "op": "eq",
            "path": "operation",
            "value": "brand_extract"
          },
          {
            "op": "not_in",
            "path": "brand.mode",
            "value": [
              "none"
            ]
          }
        ]
      },
      {
        "op": "in",
        "path": "subject.identity_fidelity",
        "value": [
          "consistent",
          "exact"
        ]
      }
    ]
  }
}
```

## 624418a79681 — brand-lock-extractor/tools/README.md:86

`<!-- source: ... -->` header, with a full UTC instant preferred over a bare date.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "624418a79681",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## cfee7ad5d452 — brand-lock-extractor/tools/README.md:144

to be identified, and a named generator has to exist in the capability matrix.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "cfee7ad5d452",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 3e81730d82c1 — brand-lock-extractor/tools/README.md:172

a frame on disk with no critique for its round, never reviewed at all

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "3e81730d82c1",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 1af7caeeaf8e — brand-lock-extractor/tools/README.md:194

template the skill uses, through the small engine in `_template.py`. It did not always: the

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "1af7caeeaf8e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 7153eacbba42 — brand-lock-extractor/tools/README.md:220

never land in the clipboard, so a revision file's `# fix [...]` notes are shown but not

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "7153eacbba42",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "any": [
      {
        "op": "eq",
        "path": "stage",
        "value": "brief"
      },
      {
        "op": "eq",
        "path": "operation",
        "value": "brand_extract"
      },
      {
        "op": "not_in",
        "path": "brand.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 4f7dd441110e — image/SKILL.md:18

The body of this SKILL.md is intentionally thin so you cannot fake a result by reading it alone. The actual rules — what the models reward, what they punish, how to phrase a 5-slot template, when to add `quality: high`, when to use image grounding — live only in the reference files.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "4f7dd441110e",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## 65b0b50050af — image/SKILL.md:22

**Motion, clips, montage** (Seedance, Kling, Veo, any image-to-video): use the sibling `video` skill. This skill's storyboard and keyframe outputs feed it.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "RECOMMEND",
  "priority": 400,
  "rule_id": "65b0b50050af",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "op": "eq",
    "path": "media",
    "value": "image"
  }
}
```

## 885e51e17bff — image/SKILL.md:40

**Nano Banana** → [nano-banana.md](references/nano-banana.md) Image grounding for real locations. Extreme aspect ratios (1:8, 8:1, 4:1). Thinking mode. JSON for 5+ elements. Up to 14 reference images. Why you must NOT write `50mm / f-stop / ISO` numbers.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "885e51e17bff",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      }
    ]
  }
}
```

## a8c24be2cf59 — image/SKILL.md:43

**GPT Image 2** → [gpt-image.md](references/gpt-image.md) 5-slot template (Scene / Subject / Important Details / Use Case / Constraints). Anti-slop banned-words list. `quality: low / medium / high` as a deliberate fidelity lever. Size constraints (multiples of 16, max 3:1, up to 2560×1440). Two-column edit logic (Change / Preserve / Constraints). Up to 16 reference images with explicit roles.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "a8c24be2cf59",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      },
      {
        "op": "in",
        "path": "operation",
        "value": [
          "image_edit",
          "image_to_image"
        ]
      }
    ]
  }
}
```

## e2f77b957f37 — image/SKILL.md:50

Universal rules that apply to both models: start with a verb, positive framing, hex colors, quote text, edit don't re-roll, one change per iteration, reference images.

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "FORBID",
  "priority": 400,
  "rule_id": "e2f77b957f37",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "not_in",
        "path": "text.mode",
        "value": [
          "none"
        ]
      },
      {
        "op": "not_in",
        "path": "references.mode",
        "value": [
          "none"
        ]
      },
      {
        "op": "in",
        "path": "operation",
        "value": [
          "image_edit",
          "image_to_image"
        ]
      }
    ]
  }
}
```

## 2602e0a1b258 — image/SKILL.md:100

For edits, also include an explicit preserve-list (mandatory for gpt-image-2, recommended for nano-banana):

Seed:
```json
{
  "authority": "SKILL",
  "classification_provenance": {
    "method": "migration_seed",
    "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication.",
    "reviewed_at": null,
    "reviewer": "unreviewed"
  },
  "classification_status": "NEEDS_REVIEW",
  "conflict_key": null,
  "effect": "REQUIRE",
  "priority": 400,
  "rule_id": "2602e0a1b258",
  "supersedes": [],
  "validator": {
    "id": null,
    "kind": "semantic"
  },
  "when": {
    "all": [
      {
        "op": "eq",
        "path": "media",
        "value": "image"
      },
      {
        "op": "in",
        "path": "operation",
        "value": [
          "image_edit",
          "image_to_image"
        ]
      }
    ]
  }
}
```
