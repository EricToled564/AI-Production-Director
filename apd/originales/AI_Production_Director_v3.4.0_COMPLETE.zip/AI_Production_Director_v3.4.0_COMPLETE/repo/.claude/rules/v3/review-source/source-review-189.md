# Source coverage review 189/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 628aa34a51abfd90 — visual-asset-critic/SKILL.md:232-232 (paragraph)

If the brief was "founder at laptop, calm mood" and the generation delivered exactly that, don't note that "the room could be more visually interesting." That's scope creep, not critique.

Extracted rules inside block: 04559072fd28

## 6ebf46b8b31a3032 — visual-asset-critic/SKILL.md:234-234 (heading)

### Rule 4. Be honest about generator limits

Extracted rules inside block: NONE

## 4b41a2816cb014c7 — visual-asset-critic/SKILL.md:236-236 (paragraph)

Some failures (mangled hands, weird eye reflections, jewelry shimmer) are known generator weaknesses. Surface them as such, don't pretend a different prompt will fix them. Recommend re-roll or post.

Extracted rules inside block: 8de585f99eb5

## a21c183ac0b5183e — visual-asset-critic/SKILL.md:238-238 (heading)

### Rule 5. When in doubt, ACCEPT and recommend post

Extracted rules inside block: NONE

## 93fc4cab46b074ad — visual-asset-critic/SKILL.md:240-240 (paragraph)

Generation is one stage in a pipeline. If the image is 80% right and the gap is fixable in post, that's an ACCEPT with post notes. Don't send the user back to re-generate when an editor would handle it in 90 seconds.

Extracted rules inside block: db9af3e304a2

## 23ff0fa520f0007f — visual-asset-critic/SKILL.md:242-242 (heading)

## Reference

Extracted rules inside block: NONE

## ecf7cec73b4fc9b4 — visual-asset-critic/SKILL.md:244-244 (list_item)

- `references/critique-rubric.md`, the full layer-by-layer rubric

Extracted rules inside block: NONE

## 9f871c842ee862a4 — visual-asset-critic/SKILL.md:246-246 (heading)

## Example output

Extracted rules inside block: NONE

## 29dc752cc44dccfb — visual-asset-critic/SKILL.md:248-248 (list_item)

> ## Verdict

Extracted rules inside block: NONE

## e4225f7042e34a0b — visual-asset-critic/SKILL.md:249-249 (list_item)

> REVISE

Extracted rules inside block: NONE

## 123b0e1b64592b65 — visual-asset-critic/SKILL.md:250-250 (list_item)

>

Extracted rules inside block: NONE

## b3dd9cfdba0c7fa1 — visual-asset-critic/SKILL.md:251-251 (list_item)

> ## What's working

Extracted rules inside block: NONE

## c834288dff5fa436 — visual-asset-critic/SKILL.md:252-252 (list_item)

> - Composition correctly reserves the right two-thirds for text overlay (matches shot_03 rationale)

Extracted rules inside block: NONE

## eee49e434f60ad92 — visual-asset-critic/SKILL.md:253-253 (list_item)

> - Lighting direction matches series_lock (window-left, warm afternoon)

Extracted rules inside block: NONE

## 1d73f8bcc8cd5428 — visual-asset-critic/SKILL.md:254-254 (list_item)

> - Mood reads as calm/considered, on-brand

Extracted rules inside block: NONE

## f389e170b7b6e018 — visual-asset-critic/SKILL.md:255-255 (list_item)

>

Extracted rules inside block: NONE

## 8f04986762d3015b — visual-asset-critic/SKILL.md:256-256 (list_item)

> ## What's not working

Extracted rules inside block: NONE

## 6157d18bab79df21 — visual-asset-critic/SKILL.md:257-257 (list_item)

> - **Series Lock, character mismatch.** The character has brown hair, but series_lock specifies "salt-and-pepper." This is a verbatim-anchor failure.

Extracted rules inside block: NONE

## 7795bbd0468a96d9 — visual-asset-critic/SKILL.md:258-258 (list_item)

> - **Technical, left hand.** Hand on the laptop has six fingers (Flux known failure mode).

Extracted rules inside block: NONE

## 00e43181a6e044d1 — visual-asset-critic/SKILL.md:259-259 (list_item)

> - **Shot Spec, framing.** Generated as MS but spec called for MCU. Subject is too small in frame.

Extracted rules inside block: NONE

## 2ca66a5f9530fc0f — visual-asset-critic/SKILL.md:260-260 (list_item)

>

Extracted rules inside block: NONE

## 52138146862ae8b7 — visual-asset-critic/SKILL.md:261-261 (list_item)

> ## Revision plan

Extracted rules inside block: NONE

## 6c3d9c59d2c3c34d — visual-asset-critic/SKILL.md:262-262 (list_item)

> - **Hair:** Prompt-level. Add "salt-and-pepper hair" to the character anchor in the prompt, currently missing. Re-roll.

Extracted rules inside block: NONE

## 50749722c07cac53 — visual-asset-critic/SKILL.md:263-263 (list_item)

> - **Hand:** Re-roll required. Generate 2–3 more times with same prompt and pick a clean one.

Extracted rules inside block: 4f83ae143d7e

## b377b8253c71f77b — visual-asset-critic/SKILL.md:264-264 (list_item)

> - **Framing:** Prompt-level. Change "medium shot" to "medium close-up" in the prompt. Re-roll.

Extracted rules inside block: NONE

## 2df7bfb838aa61a8 — visual-asset-critic/SKILL.md:265-265 (list_item)

>

Extracted rules inside block: NONE

## 0403c8becc8700f4 — visual-asset-critic/SKILL.md:266-266 (list_item)

> ## Confidence

Extracted rules inside block: NONE

## 0b4765776c98bb70 — visual-asset-critic/SKILL.md:267-267 (list_item)

> HIGH

Extracted rules inside block: NONE

## 5dd724568a607b19 — visual-asset-critic/SKILL.md:269-269 (heading)

## Handoff

Extracted rules inside block: NONE

## 494b47ca89bdef2f — visual-asset-critic/SKILL.md:271-271 (paragraph)

After delivering the critique, if the verdict is REVISE, offer:

Extracted rules inside block: NONE
