# Source coverage review 103/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 33f5ae39f8917d2d — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:25-25 (list_item)

- 26–30s. CTA

Extracted rules inside block: NONE

## aa518da6895e529b — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:27-27 (heading)

## Series lock

Extracted rules inside block: NONE

## 08229dd4bbff9a89 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:31-31 (table_row)

| **Character anchor** | founder, mid-thirties, salt-and-pepper hair, navy crewneck, calm posture, working at laptop |

Extracted rules inside block: NONE

## fb00195646e1e1e3 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:32-32 (table_row)

| **Environment** | minimalist home office, white walls, oak desk, single houseplant, no decor clutter |

Extracted rules inside block: NONE

## 67288d831586b3c6 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:33-33 (table_row)

| **Lighting** | soft natural side-light, large window camera-left, warm afternoon golden hour, gentle shadow rolloff |

Extracted rules inside block: NONE

## 47bb48fba563955a — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:34-34 (table_row)

| **Color grade** | warm filmic, muted teal shadows, slight grain, cream highlights, deep navy shadows never crushed |

Extracted rules inside block: 25af2b632520

## 9eab08c096cedc2a — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:38-38 (heading)

## Shots

Extracted rules inside block: NONE

## 2d566ea8bb4baff6 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:40-40 (heading)

### shot_01 · 0.0–2.0s · MCU · static

Extracted rules inside block: NONE

## 32e3d5a5cf000349 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:42-42 (paragraph)

**Beat:** hook

Extracted rules inside block: NONE

## fb806bc01782cbdc — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:44-44 (paragraph)

**Subject:** founder, mid-thirties, salt-and-pepper hair, navy crewneck, looking directly into camera, neutral expression, slightly tired

Extracted rules inside block: NONE

## cf8e7faf87012126 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:46-46 (paragraph)

**On-screen text:** "Your content feels random." (Inter Black 900, lower-third, hard cut at 0.4s)

Extracted rules inside block: NONE

## 8f60b210c9a8ba5a — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:48-48 (paragraph)

**Rationale:** Cold open, direct eye contact establishes parasocial trust. Static framing keeps the hook simple, text does the work.

Extracted rules inside block: NONE

## de91c21422ce3e3a — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:52-52 (heading)

### shot_02 · 2.0–7.0s · MS · static

Extracted rules inside block: NONE

## 4cd969c092d6f61f — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:54-54 (paragraph)

**Beat:** pain

Extracted rules inside block: NONE

## 86f4377fbf3a643c — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:56-56 (paragraph)

**Subject:** founder at laptop, scrolling social feed, content tiles glowing on screen, slight slump in shoulders, mug of coffee mid-distance

Extracted rules inside block: d5fc64ec46f8

## e9e67877da70ded1 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:58-58 (paragraph)

**On-screen text:** "Posting more isn't fixing it." (Inter Black 900, right-third, fade-in at 2.4s)

Extracted rules inside block: NONE

## 641a1768c0df25dd — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:60-60 (paragraph)

**Rationale:** High angle subtly diminishes the subject, pain beat. Deep DOF keeps the messy social feed legible. Subject left-weighted, text reserves right two-thirds.

Extracted rules inside block: NONE

## b586db98812446c0 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:64-64 (heading)

### shot_03 · 7.0–11.0s · ECU · static

Extracted rules inside block: NONE

## be745dd1a797f558 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:66-66 (paragraph)

**Beat:** pain

Extracted rules inside block: NONE

## 731092852bde1d0c — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:68-68 (paragraph)

**Subject:** close on founder's hand hovering over laptop trackpad, frozen, not moving

Extracted rules inside block: NONE

## ac1775def0433826 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:70-70 (paragraph)

**On-screen text:** none

Extracted rules inside block: NONE

## 5be9f74e6c7937b6 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:72-72 (paragraph)

**Rationale:** Hand frozen above trackpad is the visual symbol of decision paralysis. Wordless beat, let the image carry the pain before the reframe.

Extracted rules inside block: NONE

## ce360b76e16fa646 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:76-76 (heading)

### shot_04 · 11.0–16.0s · MCU · push

Extracted rules inside block: NONE

## e6565eb23c169deb — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:78-78 (paragraph)

**Beat:** reframe

Extracted rules inside block: NONE

## 076e504182952272 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:80-80 (paragraph)

**Subject:** founder, same posture, looking at camera, expression shifts from tired to clear, small almost-smile

Extracted rules inside block: NONE

## 165d80e028bd579a — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:82-82 (paragraph)

**On-screen text:** "You don't have a content problem. / You have an infrastructure problem." (Inter Black 900, coral, center, type-on at 11.5s)

Extracted rules inside block: 1294de980a93

## e80e386314fad8c6 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:84-84 (paragraph)

**Rationale:** Slow push as the reframe lands. Same character, same environment, only the expression changes. The change is the point.

Extracted rules inside block: NONE

## 5bf0f952aa945a52 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:88-88 (heading)

### shot_05 · 16.0–20.0s · MS · static

Extracted rules inside block: NONE

## a06babb75c9c0b64 — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:90-90 (paragraph)

**Beat:** proof

Extracted rules inside block: NONE

## 57279c942a257b9c — storyboard-architect/examples/30s-pain-proof-promise/storyboard.md:92-92 (paragraph)

**Subject:** founder gestures toward laptop screen, kanban-style content pipeline visible, organized columns, clean structure

Extracted rules inside block: NONE
