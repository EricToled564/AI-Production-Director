# Source coverage review 215/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 28671e7615ee29c1 — visual-prompt-forge/adapters/nano-banana.md:25-25 (paragraph)

Nano Banana goes through the Gemini API:

Extracted rules inside block: NONE

## 967913f24055929c — visual-prompt-forge/adapters/nano-banana.md:27-27 (table_row)

| Parameter | Default | Notes |

Extracted rules inside block: NONE

## 27d5cc34e07244bf — visual-prompt-forge/adapters/nano-banana.md:29-29 (table_row)

| `model` | `gemini-2.5-flash-image` | |

Extracted rules inside block: NONE

## b0391462dbf9fda5 — visual-prompt-forge/adapters/nano-banana.md:30-30 (table_row)

| `aspectRatio` | from `project.aspect` | Native support for `9:16`, `16:9`, `1:1`, `4:5`, `3:4`, `21:9` |

Extracted rules inside block: NONE

## ce94918f6816ae4a — visual-prompt-forge/adapters/nano-banana.md:31-31 (table_row)

| `numberOfImages` | `1` for series, `4` for variant exploration | |

Extracted rules inside block: NONE

## 5df363ea8cbda0e7 — visual-prompt-forge/adapters/nano-banana.md:32-32 (table_row)

| `referenceImages` | array of base64 images | Optional |

Extracted rules inside block: NONE

## 5114dbe4ea1a9098 — visual-prompt-forge/adapters/nano-banana.md:34-34 (paragraph)

Document:

Extracted rules inside block: NONE

## ce933957d487b99c — visual-prompt-forge/adapters/nano-banana.md:35-38 (code)

```
# shot_01, params: ar=9:16, n=1, ref=none (or list of refs)
{prompt}
```

Extracted rules inside block: NONE

## 864c968b2d497fa7 — visual-prompt-forge/adapters/nano-banana.md:40-40 (heading)

## Length

Extracted rules inside block: NONE

## 50e2bb0535005344 — visual-prompt-forge/adapters/nano-banana.md:42-42 (paragraph)

Nano Banana handles **60–120 words** efficiently. Shorter than GPT Image, longer than Midjourney.

Extracted rules inside block: NONE

## 1b401607836ef908 — visual-prompt-forge/adapters/nano-banana.md:44-44 (heading)

## Composition pattern (text-to-image)

Extracted rules inside block: NONE

## ab07df8b2d1ad09d — visual-prompt-forge/adapters/nano-banana.md:46-48 (code)

```
{Framing and subject sentence with character anchor}. {Environment and lighting from series_lock}. {Photographic spec, lens, depth of field, mood}. {Brand color grade closing}.
```

Extracted rules inside block: NONE

## 937b05be7cd3c262 — visual-prompt-forge/adapters/nano-banana.md:50-50 (heading)

## Composition pattern (image-to-image, the strength)

Extracted rules inside block: NONE

## ef7ee0bb9ce9ca4d — visual-prompt-forge/adapters/nano-banana.md:52-52 (paragraph)

When refining a hero shot generated elsewhere:

Extracted rules inside block: NONE

## b53a24749b41ff49 — visual-prompt-forge/adapters/nano-banana.md:54-56 (code)

```
Reference: {description of input image}. Modify the image to {specific change}. Preserve the character's {face/clothing/pose}, the {environment elements}, and the lighting direction. Change {specific element} to {target state}.
```

Extracted rules inside block: NONE

## 8d5fc8b68741ae55 — visual-prompt-forge/adapters/nano-banana.md:58-58 (heading)

## Example (text-to-image)

Extracted rules inside block: NONE

## 8520c9469e8bcd3f — visual-prompt-forge/adapters/nano-banana.md:60-60 (paragraph)

**Same shot data as previous examples.**

Extracted rules inside block: NONE

## 93af25cd48214e9c — visual-prompt-forge/adapters/nano-banana.md:62-62 (paragraph)

**Output prompt:**

Extracted rules inside block: NONE

## c88aa6cf3d9fab58 — visual-prompt-forge/adapters/nano-banana.md:63-65 (code)

```
Medium shot of a founder, mid-thirties, salt-and-pepper hair, navy crewneck sweater, leaning forward at his laptop with face turned partially toward window light. Composition leaves negative space on the right side. Minimalist home office, white walls, oak desk. Soft natural side-light from large window left, warm afternoon golden hour. Shot on 50mm prime, f/2.0, shallow depth of field, warm filmic color grade with muted teal shadows. Calm, considered, operator mood.
```

Extracted rules inside block: NONE

## 1664bafb8b8874f6 — visual-prompt-forge/adapters/nano-banana.md:67-67 (heading)

## Example (image-to-image variant)

Extracted rules inside block: NONE

## bff2ed2e102ece48 — visual-prompt-forge/adapters/nano-banana.md:69-69 (paragraph)

**Use case:** generated `shot_03` in Flux, want a variant where the founder is looking directly at camera

Extracted rules inside block: 908dfc533de5

## 071c01e73196bacd — visual-prompt-forge/adapters/nano-banana.md:71-71 (paragraph)

**Output prompt:**

Extracted rules inside block: NONE

## d05ea60b5b9819ff — visual-prompt-forge/adapters/nano-banana.md:72-74 (code)

```
Reference: medium shot of founder at laptop in home office, leaning forward, face partially turned to window. Modify the image so the founder looks directly into the camera lens with a calm, neutral expression. Preserve the character's face, salt-and-pepper hair, navy crewneck, body posture, the home office environment, the desk and laptop, and the warm afternoon side-lighting. Change only the head angle and gaze direction.
```

Extracted rules inside block: NONE

## 0ce672ec05e29b51 — visual-prompt-forge/adapters/nano-banana.md:76-76 (heading)

## Variant-generation workflow

Extracted rules inside block: NONE

## e1cfcfb1fd39a97f — visual-prompt-forge/adapters/nano-banana.md:78-78 (paragraph)

The pattern Nano Banana enables, and the reason it's worth including in storyboard work:

Extracted rules inside block: NONE

## 358a874498705a50 — visual-prompt-forge/adapters/nano-banana.md:80-80 (list_item)

1. Generate hero shot in Midjourney or Flux (one prompt → one image)

Extracted rules inside block: 29960d0fa551

## eda513f8c654f618 — visual-prompt-forge/adapters/nano-banana.md:81-81 (list_item)

2. Feed that image to Nano Banana with variation prompts

Extracted rules inside block: 60179dcf24ec

## d87fbfc171ebaeee — visual-prompt-forge/adapters/nano-banana.md:82-82 (list_item)

3. Get 4–8 variants of the same shot for editorial selection

Extracted rules inside block: 416f3b7ab854

## 4fc474517a8d0c57 — visual-prompt-forge/adapters/nano-banana.md:83-83 (list_item)

4. Composite text on the chosen variant

Extracted rules inside block: 557b754e72e7

## 1b6b9b20aa625061 — visual-prompt-forge/adapters/nano-banana.md:85-85 (paragraph)

When generating prompts for Nano Banana in `nano-banana.txt`, include both:

Extracted rules inside block: NONE
