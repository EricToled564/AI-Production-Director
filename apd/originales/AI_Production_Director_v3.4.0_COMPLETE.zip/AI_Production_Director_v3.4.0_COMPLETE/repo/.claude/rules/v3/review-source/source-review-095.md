# Source coverage review 95/231

Review all 30 blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.

## 392d289d3072cdef — storyboard-architect/SKILL.md:85-85 (paragraph)

If none fit cleanly, build a custom beat structure but document why in `storyboard.md` rationale section.

Extracted rules inside block: NONE

## d07113168437d0de — storyboard-architect/SKILL.md:87-87 (heading)

### Step 3. Block out timing

Extracted rules inside block: NONE

## fc99a814dd93948e — storyboard-architect/SKILL.md:89-89 (paragraph)

Read `references/timing-rules.md` for the math. Default cadence:

Extracted rules inside block: NONE

## 19c3f80752246d6b — storyboard-architect/SKILL.md:91-91 (list_item)

- Hook beat: 0–2 seconds

Extracted rules inside block: NONE

## 1060c4d3d3760b62 — storyboard-architect/SKILL.md:92-92 (list_item)

- Pain/setup: 2–6 seconds (for 30s) or 2–10 seconds (for 60s)

Extracted rules inside block: NONE

## 270f5b006ff5f9ea — storyboard-architect/SKILL.md:93-93 (list_item)

- Proof/reframe: middle third

Extracted rules inside block: NONE

## a38f1daba1692c63 — storyboard-architect/SKILL.md:94-94 (list_item)

- Promise/CTA: final 4–6 seconds

Extracted rules inside block: NONE

## b1915c43f3c32095 — storyboard-architect/SKILL.md:96-96 (paragraph)

Don't fight the framework. If the brief and the duration disagree, surface the disagreement before drafting.

Extracted rules inside block: 4565e5d24295

## 82d84d88d2eabc22 — storyboard-architect/SKILL.md:98-98 (heading)

### Step 4. Draft the shot list

Extracted rules inside block: NONE

## 6aeb52c45731edcd — storyboard-architect/SKILL.md:100-103 (paragraph)

Read `references/shot-grammar.md` for controlled vocabulary. The field names below are
the schema's field names. `templates/shots.schema.json` sets `additionalProperties:
false`, so a near-miss like `environment` instead of `environment_ref` is a validation
failure, not a synonym.

Extracted rules inside block: NONE

## 60f69d90d816f2cc — storyboard-architect/SKILL.md:105-105 (list_item)

- `id`, sequential, zero-padded (`shot_01`, `shot_02`...)

Extracted rules inside block: NONE

## 923e2bd4314b07f5 — storyboard-architect/SKILL.md:106-106 (list_item)

- `beat`, which beat this shot serves

Extracted rules inside block: NONE

## dc264cf3603de7c0 — storyboard-architect/SKILL.md:107-107 (list_item)

- `start` / `end`, timestamps in seconds, decimal allowed. `end` must be after `start`

Extracted rules inside block: b002fb030ee0

## a94394c69a366076 — storyboard-architect/SKILL.md:108-108 (list_item)

- `framing`, ECU / CU / MCU / MS / MLS / WS / EWS

Extracted rules inside block: NONE

## 2dce5bd491609ae3 — storyboard-architect/SKILL.md:109-109 (list_item)

- `angle`, eye-level / high / low / overhead / dutch

Extracted rules inside block: NONE

## 4f52ef9b5359fb20 — storyboard-architect/SKILL.md:110-112 (list_item)

- `motion`, static / push / pull / pan-left / pan-right / tilt-up / tilt-down /
  handheld / orbit / whip / rack. All eleven are legal; the schema enum is the
  authority and `references/shot-grammar.md` explains when each earns its keep

Extracted rules inside block: NONE

## 11a944249180d72e — storyboard-architect/SKILL.md:113-113 (list_item)

- `depth_of_field`, optional, shallow / deep / rack

Extracted rules inside block: 238356584572

## 9f2924c70280e227 — storyboard-architect/SKILL.md:114-114 (list_item)

- `subject`, what's in frame, structured

Extracted rules inside block: NONE

## 3fdbdeedc38dc095 — storyboard-architect/SKILL.md:115-115 (list_item)

- `environment_ref`, references series-lock language, default `series_lock.environment`

Extracted rules inside block: NONE

## 3f05cecde540b5f4 — storyboard-architect/SKILL.md:116-116 (list_item)

- `lighting_ref`, references series-lock language, default `series_lock.lighting`

Extracted rules inside block: NONE

## 5ed8f6968fae5426 — storyboard-architect/SKILL.md:117-118 (list_item)

- `on_screen_text`, null, one text-overlay id, OR an array of ids when a shot carries
  more than one overlay

Extracted rules inside block: NONE

## 927974b1fe24e5d4 — storyboard-architect/SKILL.md:119-119 (list_item)

- `vo`, voiceover line, or null

Extracted rules inside block: NONE

## 0fc731dc670203ea — storyboard-architect/SKILL.md:120-120 (list_item)

- `rationale`, one sentence explaining *why this shot at this moment*

Extracted rules inside block: NONE

## 83f708134124df9b — storyboard-architect/SKILL.md:122-124 (paragraph)

Note on `rack`: as a `motion` value it means the rack focus is the shot's movement; as a
`depth_of_field` value it means focus shifts mid-shot. Same word, two fields, two
meanings.

Extracted rules inside block: NONE

## 4e9e07529442051f — storyboard-architect/SKILL.md:126-126 (heading)

### Step 5. Separate the text layer

Extracted rules inside block: NONE

## 209890c2c03f8707 — storyboard-architect/SKILL.md:128-128 (paragraph)

Every piece of on-screen text becomes an entry in `text-overlays.json`. Never bake text into the visual description. Each overlay has:

Extracted rules inside block: 36d0a886279e

## 426e69217fdc380c — storyboard-architect/SKILL.md:130-130 (list_item)

- `id`, `text_01`, `text_02`...

Extracted rules inside block: NONE

## 492b8686d358cc3c — storyboard-architect/SKILL.md:131-131 (list_item)

- `shot_id`, which shot this overlays on

Extracted rules inside block: NONE

## e379f21584c743c2 — storyboard-architect/SKILL.md:132-132 (list_item)

- `content`, the actual text

Extracted rules inside block: NONE

## 32e1b119c981d625 — storyboard-architect/SKILL.md:133-133 (list_item)

- `font`, references brand-lock typography

Extracted rules inside block: NONE
