#!/usr/bin/env python3
"""Seed one review row for every source block. Nothing is certified by default."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from rule_engine_v3 import write_jsonl

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inventory',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    inv=json.loads(Path(a.inventory).read_text(encoding='utf-8')); rows=[]
    for b in inv['blocks']:
        rows.append({'block_id':b['block_id'],'status':'NEEDS_REVIEW','rule_ids':[],'reviewer':'unreviewed','reviewed_at':None,'reason':''})
    write_jsonl(Path(a.out),rows); print(f'source disposition rows: {len(rows)}; all NEEDS_REVIEW'); return 0
if __name__=='__main__': raise SystemExit(main())
