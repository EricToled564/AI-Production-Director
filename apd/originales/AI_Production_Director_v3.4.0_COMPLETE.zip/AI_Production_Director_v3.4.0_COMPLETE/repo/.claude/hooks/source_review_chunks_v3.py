#!/usr/bin/env python3
"""Create review chunks for exhaustive source-block disposition.

Every block must become NORMATIVE, NON_NORMATIVE, EXAMPLE, or STRUCTURE.
If NORMATIVE, reviewer maps it to one or more canonical rule ids. If the block
contains an implicit rule missing from raw_rules.json, the reviewer must flag it
for extractor correction rather than pretending coverage is complete.
"""
from __future__ import annotations
import argparse,json,math
from pathlib import Path
from rule_engine_v3 import load_jsonl

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inventory',required=True); ap.add_argument('--dispositions',required=True); ap.add_argument('--raw-rules',required=True); ap.add_argument('--out-dir',required=True); ap.add_argument('--size',type=int,default=30); a=ap.parse_args()
    inv=json.loads(Path(a.inventory).read_text(encoding='utf-8')); raw=json.loads(Path(a.raw_rules).read_text(encoding='utf-8'))
    disp={d['block_id']:d for d in load_jsonl(Path(a.dispositions))}; rules=raw['rules']
    pending=[b for b in inv['blocks'] if disp.get(b['block_id'],{}).get('status') not in {'NORMATIVE','NON_NORMATIVE','EXAMPLE','STRUCTURE'}]
    pending.sort(key=lambda b:(b['skill'],b['file'],b['start_line']))
    out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
    for p in out.glob('source-review-*.md'): p.unlink()
    n=math.ceil(len(pending)/a.size) if pending else 0
    by_source={}
    for r in rules: by_source.setdefault(r['source_path'],[]).append(r)
    for i in range(n):
        group=pending[i*a.size:(i+1)*a.size]
        lines=[f'# Source coverage review {i+1}/{n}','',f'Review all {len(group)} blocks. Every block needs one disposition: NORMATIVE / NON_NORMATIVE / EXAMPLE / STRUCTURE. For NORMATIVE, map it to canonical rule_id(s). If it contains a normative instruction that has no matching canonical rule, write `MISSING_RULE` in your review notes: the extractor must be fixed before publication.','']
        for b in group:
            nearby=[r for r in by_source.get(b['source_path'],[]) if not (r['line']<b['start_line'] or r['line']>b['end_line'])]
            lines += [f"## {b['block_id']} — {b['source_path']}:{b['start_line']}-{b['end_line']} ({b['kind']})",'',b['text'],'',f"Extracted rules inside block: {', '.join(r['id'] for r in nearby) or 'NONE'}",'']
        (out/f'source-review-{i+1:03d}.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'pending blocks: {len(pending)} -> {n} chunks in {out}')
    return 0
if __name__=='__main__': raise SystemExit(main())
