#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
H="$ROOT/.claude/hooks"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
P=0; F=0
check(){ if [[ "$2" == "$3" ]]; then echo "PASS  $1"; P=$((P+1)); else echo "FAIL  $1 (got $3 expected $2)"; F=$((F+1)); fi; }

python3 "$H/case_validate.py" "$ROOT/examples/cases/diver_split_level.json" >/dev/null 2>&1; check "valid diver fingerprint passes" 0 $?
python3 - "$ROOT/examples/cases/diver_split_level.json" "$TMP/bad.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1])); x['subject']['count']=2; json.dump(x,open(sys.argv[2],'w'))
PY
python3 "$H/case_validate.py" "$TMP/bad.json" >/dev/null 2>&1; check "T3 with two people fails" 1 $?

mkdir -p "$TMP/build"
python3 "$H/kb_compile.py" --skills-root "$ROOT/../skills" --out-dir "$TMP/build" >/dev/null 2>&1; check "KB compiler runs" 0 $?
N=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["manifest"]["raw_rule_count"])' "$TMP/build/raw_rules.json")
[[ "$N" -gt 1000 ]]; check "KB compiler sees >1000 canonical rules" 0 $?
python3 "$H/kb_block_inventory.py" --skills-root "$ROOT/../skills" --out "$TMP/build/blocks.json" >/dev/null 2>&1; check "source block inventory runs" 0 $?
B=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["block_count"])' "$TMP/build/blocks.json")
[[ "$B" -gt 5000 ]]; check "source inventory covers >5000 blocks" 0 $?
python3 "$H/seed_source_dispositions.py" --inventory "$TMP/build/blocks.json" --out "$TMP/source-seed.jsonl" >/dev/null 2>&1
python3 "$H/source_coverage_gate.py" --inventory "$TMP/build/blocks.json" --dispositions "$TMP/source-seed.jsonl" --raw-rules "$TMP/build/raw_rules.json" >/dev/null 2>&1; check "unreviewed source inventory cannot pass" 1 $?
python3 "$H/seed_rule_metadata.py" --raw-rules "$TMP/build/raw_rules.json" --out "$TMP/seed.jsonl" >/dev/null 2>&1
python3 "$H/ruleset_publish.py" --raw-rules "$TMP/build/raw_rules.json" --metadata "$TMP/seed.jsonl" --version test --out "$TMP/no.json" --unsafe-skip-source-coverage >/dev/null 2>&1; check "unreviewed KB cannot publish" 1 $?

# Small fully-classified fixture exercises runtime semantics.
cat > "$TMP/raw.json" <<'JSON'
{"manifest":{"raw_rules_sha256":"fixture"},"rules":[
 {"id":"111111111111","skill":"image","file":"a.md","source_path":"image/a.md","line":1,"markers":["obligation"],"text":"image rule"},
 {"id":"222222222222","skill":"video","file":"b.md","source_path":"video/b.md","line":1,"markers":["obligation"],"text":"video rule"},
 {"id":"333333333333","skill":"image","file":"c.md","source_path":"image/c.md","line":1,"markers":["obligation"],"text":"water rule"}
]}
JSON
cat > "$TMP/meta.jsonl" <<'JSONL'
{"rule_id":"111111111111","classification_status":"CLASSIFIED","authority":"SKILL","effect":"REQUIRE","priority":400,"when":{"path":"media","op":"eq","value":"image"},"validator":{"kind":"semantic","id":null},"conflict_key":null,"supersedes":[],"classification_provenance":{"method":"manual","reviewer":"test","reviewed_at":"2026-09-10T00:00:00Z","notes":"fixture"}}
{"rule_id":"222222222222","classification_status":"CLASSIFIED","authority":"SKILL","effect":"REQUIRE","priority":400,"when":{"path":"media","op":"eq","value":"video"},"validator":{"kind":"semantic","id":null},"conflict_key":null,"supersedes":[],"classification_provenance":{"method":"manual","reviewer":"test","reviewed_at":"2026-09-10T00:00:00Z","notes":"fixture"}}
{"rule_id":"333333333333","classification_status":"CLASSIFIED","authority":"SKILL","effect":"REQUIRE","priority":400,"when":{"path":"physics.water","op":"eq","value":true},"validator":{"kind":"semantic","id":null},"conflict_key":null,"supersedes":[],"classification_provenance":{"method":"manual","reviewer":"test","reviewed_at":"2026-09-10T00:00:00Z","notes":"fixture"}}
JSONL
python3 "$H/ruleset_publish.py" --raw-rules "$TMP/raw.json" --metadata "$TMP/meta.jsonl" --version fixture --out "$TMP/rs.json" --unsafe-skip-source-coverage >/dev/null 2>&1; check "fully classified fixture publishes" 0 $?
python3 "$H/rule_matcher_v3.py" --ruleset "$TMP/rs.json" --case "$ROOT/examples/cases/diver_split_level.json" --out "$TMP/matched.json" >/dev/null 2>&1; check "matcher evaluates every fixture rule" 0 $?
ACTIVE=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["counts"]["active"])' "$TMP/matched.json")
check "image + water rules active, video NA" 2 "$ACTIVE"
echo '{}' > "$TMP/evidence.json"
python3 "$H/runtime_ledger_v3.py" --matched "$TMP/matched.json" --evidence "$TMP/evidence.json" >/dev/null 2>&1; check "runtime ledger fails on pending applicable rules" 1 $?
python3 - "$TMP/matched.json" "$TMP/evidence.json" <<'PY'
import json,sys
m=json.load(open(sys.argv[1])); e={r['rule_id']:{'status':'PASS','by':'fixture-test'} for r in m['active_rules']}; json.dump(e,open(sys.argv[2],'w'))
PY
python3 "$H/runtime_ledger_v3.py" --matched "$TMP/matched.json" --evidence "$TMP/evidence.json" >/dev/null 2>&1; check "runtime ledger passes at 100%" 0 $?

# UNKNOWN must not silently become NA.
python3 - "$TMP/raw.json" "$TMP/meta.jsonl" <<'PY'
import json,sys
r=json.load(open(sys.argv[1])); r['rules'].append({"id":"444444444444","skill":"image","file":"d.md","source_path":"image/d.md","line":1,"markers":["obligation"],"text":"indoor rule"}); json.dump(r,open(sys.argv[1],'w'))
with open(sys.argv[2],'a') as f: f.write('\n'+json.dumps({"rule_id":"444444444444","classification_status":"CLASSIFIED","authority":"SKILL","effect":"REQUIRE","priority":400,"when":{"path":"environment.indoor_outdoor","op":"eq","value":"indoor"},"validator":{"kind":"semantic","id":None},"conflict_key":None,"supersedes":[],"classification_provenance":{"method":"manual","reviewer":"test","reviewed_at":"2026-09-10T00:00:00Z","notes":"fixture"}})+'\n')
PY
python3 "$H/ruleset_publish.py" --raw-rules "$TMP/raw.json" --metadata "$TMP/meta.jsonl" --version fixture2 --out "$TMP/rs2.json" --unsafe-skip-source-coverage >/dev/null 2>&1
python3 "$H/rule_matcher_v3.py" --ruleset "$TMP/rs2.json" --case "$ROOT/examples/cases/diver_split_level.json" --out "$TMP/m2.json" >/dev/null 2>&1; check "UNKNOWN field closes matcher instead of becoming NA" 1 $?

# Explicit case-dependent conflict policy.
python3 - "$ROOT/examples/cases/diver_split_level.json" "$TMP/outdoor.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1])); x['environment']['indoor_outdoor']='outdoor'; x['unknowns']=[]; json.dump(x,open(sys.argv[2],'w'))
PY
cat > "$TMP/rawc.json" <<'JSON'
{"manifest":{},"rules":[
 {"id":"aaaaaaaaaaaa","skill":"x","file":"a.md","source_path":"x/a.md","line":1,"markers":["obligation"],"text":"require term"},
 {"id":"bbbbbbbbbbbb","skill":"x","file":"b.md","source_path":"x/b.md","line":1,"markers":["prohibition"],"text":"forbid term"}
]}
JSON
cat > "$TMP/metac.jsonl" <<'JSONL'
{"rule_id":"aaaaaaaaaaaa","classification_status":"CLASSIFIED","authority":"MODEL_ADAPTER","effect":"REQUIRE","priority":400,"when":{"path":"media","op":"eq","value":"image"},"validator":{"kind":"lexical","id":null},"conflict_key":"vocab.demo","supersedes":[],"classification_provenance":{"method":"manual","reviewer":"test","reviewed_at":"2026-09-10T00:00:00Z","notes":"fixture"}}
{"rule_id":"bbbbbbbbbbbb","classification_status":"CLASSIFIED","authority":"SKILL","effect":"FORBID","priority":400,"when":{"path":"media","op":"eq","value":"image"},"validator":{"kind":"lexical","id":null},"conflict_key":"vocab.demo","supersedes":[],"classification_provenance":{"method":"manual","reviewer":"test","reviewed_at":"2026-09-10T00:00:00Z","notes":"fixture"}}
JSONL
python3 "$H/ruleset_publish.py" --raw-rules "$TMP/rawc.json" --metadata "$TMP/metac.jsonl" --version c --out "$TMP/rsc.json" --unsafe-skip-source-coverage >/dev/null 2>&1
python3 "$H/rule_matcher_v3.py" --ruleset "$TMP/rsc.json" --case "$TMP/outdoor.json" --out "$TMP/mc.json" >/dev/null 2>&1; check "unresolved applicable conflict closes matcher" 1 $?
cat > "$TMP/policy.json" <<'JSON'
{"policies":[{"id":"p1","conflict_key":"vocab.demo","when":{"path":"generator.family","op":"eq","value":"gpt_image"},"winner_rule_id":"bbbbbbbbbbbb"}]}
JSON
python3 "$H/ruleset_publish.py" --raw-rules "$TMP/rawc.json" --metadata "$TMP/metac.jsonl" --conflicts "$TMP/policy.json" --version c2 --out "$TMP/rsc2.json" --unsafe-skip-source-coverage >/dev/null 2>&1
python3 "$H/rule_matcher_v3.py" --ruleset "$TMP/rsc2.json" --case "$TMP/outdoor.json" --out "$TMP/mc2.json" >/dev/null 2>&1; check "case-dependent conflict policy resolves conflict" 0 $?


# Inheritance locks cannot be silently changed downstream.
python3 "$H/inheritance_resolver_v3.py" --base "$ROOT/examples/cases/diver_split_level.json" --layer "$ROOT/examples/cases/diver_project_layer.json" --layer "$ROOT/examples/cases/diver_shot_layer.json" --out "$TMP/inherited.json" >/dev/null 2>&1; check "valid inheritance chain passes" 0 $?
cat > "$TMP/illegal-layer.json" <<'JSON'
{"schema_version":"1.0","layer_id":"asset_bad","entity_type":"asset","parent_id":"shot_001","assignments":[{"path":"realism.mode","value":"stylized","state":"DERIVED","source_type":"asset","source_id":"asset_bad","confidence":1.0,"reason":"test illegal change","authorized_by":null}]}
JSON
python3 "$H/inheritance_resolver_v3.py" --base "$ROOT/examples/cases/diver_split_level.json" --layer "$ROOT/examples/cases/diver_project_layer.json" --layer "$TMP/illegal-layer.json" --out "$TMP/illegal.json" >/dev/null 2>&1; check "locked upstream field cannot drift silently" 1 $?

echo "$P passed · $F failed"
[[ $F -eq 0 ]]
