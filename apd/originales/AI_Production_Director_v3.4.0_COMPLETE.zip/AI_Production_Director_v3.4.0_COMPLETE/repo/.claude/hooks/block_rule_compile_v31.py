#!/usr/bin/env python3
from __future__ import annotations
import json,hashlib
from pathlib import Path
from collections import defaultdict,Counter

HOOKS=Path(__file__).resolve().parent
RULES=HOOKS.parent/'rules'/'v3'; BUILD=RULES/'build'
DISP=RULES/'source-dispositions.final-v3.1.jsonl'
BLOCKS=BUILD/'source_blocks.json'; RAW=BUILD/'raw_rules_with_context.json'; CAT=BUILD/'source_catalog.json'
OUT=BUILD/'rules.block-v3.1.json'

def load_jsonl(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def rid(block_id): return hashlib.sha256(f'block-rule-v3.1|{block_id}'.encode()).hexdigest()[:12]
def sha(obj): return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def main():
    disp=load_jsonl(DISP); blocks={b['block_id']:b for b in json.load(open(BLOCKS,encoding='utf-8'))['blocks']}
    raws=json.load(open(RAW,encoding='utf-8'))['rules']
    raw_by_src=defaultdict(list)
    for r in raws: raw_by_src[r['source_path']].append(r)
    cat=json.load(open(CAT,encoding='utf-8')); source_sha={s['path'].removeprefix('skills/'):s['sha256'] for s in cat['sources'] if s['path'].startswith('skills/')}
    rules=[]
    for d in disp:
        if d['status']!='NORMATIVE': continue
        b=blocks[d['block_id']]; path=d['source_path']; text=' '.join(b['text'].split())
        legacy=[r['id'] for r in raw_by_src.get(path,[]) if d['start_line']<=r['line']<=d['end_line']]
        rules.append({
            'id':rid(d['block_id']), 'block_id':d['block_id'], 'legacy_rule_ids':legacy,
            'skill':path.split('/',1)[0], 'file':path.split('/',1)[1], 'source_path':path,
            'line':d['start_line'], 'end_line':d['end_line'], 'kind':d['kind'],
            'headings':[x.strip() for x in d.get('context','').split(' > ') if x.strip()], 'context':d.get('context',''),
            'text':text, 'source_sha256':source_sha.get(path), 'classification_reason':d.get('reason','')
        })
    rules.sort(key=lambda r:(r['skill'],r['source_path'],r['line'],r['id']))
    ids=[r['id'] for r in rules]
    if len(ids)!=len(set(ids)): raise SystemExit('block rule ID collision')
    source_files=sorted(set(r['source_path'] for r in rules))
    manifest={
      'schema_version':'3.1-block',
      'source_block_count':len(blocks),
      'normative_block_rule_count':len(rules),
      'normative_source_file_count':len(source_files),
      'legacy_rule_links':sum(len(r['legacy_rule_ids']) for r in rules),
      'rules_sha256':sha(rules),
      'source_dispositions_sha256':sha(disp),
    }
    OUT.write_text(json.dumps({'manifest':manifest,'rules':rules},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))
    print('by skill',dict(sorted(Counter(r['skill'] for r in rules).items())))
    print('written',OUT)
if __name__=='__main__':main()
