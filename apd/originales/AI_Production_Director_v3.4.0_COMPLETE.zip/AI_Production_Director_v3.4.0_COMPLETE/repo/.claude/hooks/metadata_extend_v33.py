#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime,timezone

def load_jsonl(p): return [json.loads(x) for x in Path(p).read_text(encoding='utf-8').splitlines() if x.strip()]
def cond_stage(stages): return {'all':[{'path':'stage','op':'in','value':stages}]}
def image_stage(stages): return {'all':[{'path':'media','op':'eq','value':'image'},{'path':'stage','op':'in','value':stages}]}
def video_stage(stages): return {'all':[{'path':'media','op':'eq','value':'video'},{'path':'stage','op':'in','value':stages}]}
def meta_for(r):
    path=r['source_path']; ctx=r.get('context','')
    now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    authority='SKILL'; effect='PROCESS'; priority=540; when={}; kind='process'; vid='v33:decision-table'
    notes='v3.3 decision-table reaudit: previously discarded table/list decision promoted to executable canonical rule.'
    if path=='image/references/models.md':
        if 'TL;DR' in ctx or 'Где обе модели одинаково хороши' in ctx:
            when=image_stage(['asset']); vid='v33:model-routing-canonical'; priority=570
        elif 'Различия в синтаксисе промпта' in ctx:
            when=image_stage(['prompt','generation']); vid='v33:model-syntax-table'; priority=565
        else:
            when=image_stage(['asset','prompt','generation'])
    elif path=='ai-production-director/SKILL.md' and 'Selección de track' in ctx:
        authority='PIPELINE'; when=cond_stage(['brief']); priority=620; vid='v33:track-routing'
    elif path=='ai-video-storyboard/SKILL.md' and 'Infer Structure' in ctx:
        when=video_stage(['storyboard','shot']); effect='RECOMMEND'; priority=530; kind='semantic'; vid='v33:storyboard-structure-defaults'
    elif path=='visual-prompt-forge/adapters/seedance.md' and 'When to use multi-shot vs single' in ctx:
        authority='MODEL_ADAPTER'; when={'all':[{'path':'media','op':'eq','value':'video'},{'path':'generator.family','op':'eq','value':'seedance'},{'path':'stage','op':'in','value':['prompt','generation']}]}; priority=575; vid='v33:seedance-shot-mode-routing'
    return {
      'rule_id':r['id'],'classification_status':'CLASSIFIED','authority':authority,'effect':effect,'priority':priority,
      'when':when,'validator':{'kind':kind,'id':vid},'conflict_key':None,'supersedes':[],
      'classification_provenance':{'method':'external_audit','reviewer':'APD-v3.3-decision-table-reaudit','reviewed_at':now,'notes':notes}
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--base',required=True); ap.add_argument('--rules',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    base=load_jsonl(a.base); by={m['rule_id']:m for m in base}; rules=json.load(open(a.rules,encoding='utf-8'))['rules']
    added=[]
    for r in rules:
        if r['id'] not in by:
            m=meta_for(r); by[r['id']]=m; added.append((r['id'],r['source_path'],r.get('context'),r['text']))
    stale=set(by)-{r['id'] for r in rules}
    if stale: raise SystemExit(f'stale metadata ids: {len(stale)}')
    ordered=[by[r['id']] for r in rules]
    Path(a.out).write_text('\n'.join(json.dumps(x,ensure_ascii=False,sort_keys=True) for x in ordered)+'\n',encoding='utf-8')
    print('METADATA EXTEND V3.3: PASS'); print('base',len(base),'added',len(added),'total',len(ordered))
    for x in added: print(' +',x[0],x[1],x[2])
if __name__=='__main__': main()
