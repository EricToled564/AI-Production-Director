#!/usr/bin/env python3
"""Inventory every meaningful Markdown block in every skill source.

Why: a deontic-marker extractor can miss an implicit rule that never says
"must/never/should". Source exhaustivity therefore needs a second, broader
inventory where EVERY meaningful block receives a one-time disposition.
"""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path
from rule_engine_v3 import sha256_json

HR=re.compile(r'^\s*[-*_]{3,}\s*$')
FENCE=re.compile(r'^\s*```')
LIST=re.compile(r'^\s*(?:[-*+]\s+|\d{1,3}[.)]\s+)')
HEADING=re.compile(r'^\s*#{1,6}\s+')
TABLESEP=re.compile(r'^\s*\|?[\s:|-]+\|?\s*$')


def bid(skill, rel, kind, start, text):
    norm=' '.join(text.split()).strip().lower()
    return hashlib.sha1(f'{skill}\x00{rel}\x00{kind}\x00{start}\x00{norm}'.encode()).hexdigest()[:16]


def blocks(path:Path, skill:str, root:Path):
    rel=str(path.relative_to(root)); lines=path.read_text(encoding='utf-8').splitlines(); out=[]; i=0
    while i<len(lines):
        raw=lines[i]; ln=i+1
        if not raw.strip() or HR.match(raw): i+=1; continue
        if FENCE.match(raw):
            fence=raw.strip()[:3]; buf=[raw]; i+=1
            while i<len(lines):
                buf.append(lines[i])
                if FENCE.match(lines[i]): i+=1; break
                i+=1
            text='\n'.join(buf); out.append(('code',ln,i,text)); continue
        if HEADING.match(raw): out.append(('heading',ln,ln,raw)); i+=1; continue
        if raw.strip()=='---' and ln==1:
            buf=[raw]; i+=1
            while i<len(lines):
                buf.append(lines[i])
                if lines[i].strip()=='---': i+=1; break
                i+=1
            out.append(('frontmatter',ln,i,'\n'.join(buf))); continue
        if raw.lstrip().startswith('|'):
            if not TABLESEP.match(raw): out.append(('table_row',ln,ln,raw))
            i+=1; continue
        if LIST.match(raw) or raw.lstrip().startswith('>'):
            buf=[raw]; i+=1
            while i<len(lines) and lines[i].strip() and not HEADING.match(lines[i]) and not LIST.match(lines[i]) and not lines[i].lstrip().startswith('|') and not FENCE.match(lines[i]):
                if lines[i].startswith((' ','\t')): buf.append(lines[i]); i+=1
                else: break
            out.append(('list_item',ln,i,'\n'.join(buf))); continue
        buf=[raw]; i+=1
        while i<len(lines) and lines[i].strip() and not HEADING.match(lines[i]) and not LIST.match(lines[i]) and not lines[i].lstrip().startswith('|') and not FENCE.match(lines[i]) and not HR.match(lines[i]):
            buf.append(lines[i]); i+=1
        out.append(('paragraph',ln,i,'\n'.join(buf)))
    result=[]
    for kind,start,end,text in out:
        result.append({'block_id':bid(skill,rel,kind,start,text),'skill':skill,'file':rel,'source_path':f'{skill}/{rel}','kind':kind,'start_line':start,'end_line':end,'text':text})
    return result


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--skills-root',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    root=Path(a.skills_root).resolve(); allb=[]; files=0
    for sdir in sorted(p for p in root.iterdir() if p.is_dir() and (p/'SKILL.md').is_file()):
        for md in sorted(sdir.rglob('*.md')):
            files+=1; allb.extend(blocks(md,sdir.name,sdir))
    payload={'schema_version':'1.0','source_files':files,'block_count':len(allb),'blocks_sha256':sha256_json([{k:b[k] for k in ('block_id','source_path','kind','start_line','end_line','text')} for b in allb]),'blocks':allb}
    Path(a.out).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'source files: {files}'); print(f'meaningful blocks: {len(allb)}'); print(f'blocks hash: {payload["blocks_sha256"]}'); print(f'written: {a.out}')
    return 0
if __name__=='__main__': raise SystemExit(main())
