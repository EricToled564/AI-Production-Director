#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from collections import defaultdict, Counter

HOOKS=Path(__file__).resolve().parent
RULES=HOOKS.parent/'rules'/'v3'
BUILD=RULES/'build'
IN_DISP=RULES/'source-dispositions.reviewed.jsonl'
EFF=BUILD/'effective_rules.json'
OUT=RULES/'source-dispositions.effective.jsonl'

def load_jsonl(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def main():
    rows=load_jsonl(IN_DISP)
    rules=json.load(open(EFF,encoding='utf-8'))['rules']
    bysrc=defaultdict(list)
    for r in rules: bysrc[r['source_path']].append(r)
    for rs in bysrc.values(): rs.sort(key=lambda r:(r['line'],r.get('end_line',r['line']),r['id']))
    out=[]; contradictions=[]; recast=0
    for d in rows:
        x=dict(d)
        ids=[]
        for r in bysrc.get(d['source_path'],[]):
            end=r.get('end_line',r['line'])
            # A rule belongs to the block whose line range contains its start line.
            if d['start_line'] <= r['line'] <= d['end_line']:
                ids.append(r['id'])
        if ids:
            # Explicitly promoted template constraints are allowed to upgrade a TEMPLATE block.
            promoted_template = d['source_path']=='brand-lock-extractor/brand-packs/_template.md' and d['start_line'] in {15,25,33,37,41}
            if d['status']!='NORMATIVE' and not promoted_template:
                contradictions.append((d['block_id'],d['status'],ids))
            x['status']='NORMATIVE'; x['rule_ids']=ids
            x['reason']=x.get('reason','')+'; effective reconciliation: contains published normative rule(s)'
        else:
            x['rule_ids']=[]
            if d['status']=='NORMATIVE':
                x['status']='NON_NORMATIVE'; recast+=1
                x['reason']=x.get('reason','')+'; effective reconciliation: all extracted propositions in this block were explicitly reviewed non-normative'
        out.append(x)
    if contradictions:
        print('Contradictions: effective rules in blocks dispositioned non-normative:',len(contradictions))
        for c in contradictions[:20]: print(c)
        raise SystemExit(1)
    OUT.write_text('\n'.join(json.dumps(x,ensure_ascii=False,sort_keys=True) for x in out)+'\n',encoding='utf-8')
    c=Counter(x['status'] for x in out)
    print('effective source dispositions',dict(c))
    print('recast NORMATIVE->NON_NORMATIVE',recast)
    print('normative rule links',sum(len(x['rule_ids']) for x in out))
    print('written',OUT)

if __name__=='__main__':main()
