#!/usr/bin/env python3
"""Publish a canonical ruleset only when KB classification is exhaustive.

Publication requirements:
- raw registry exists and hashes the current KB sources
- exactly one metadata row per raw rule
- no stale metadata ids
- every row is CLASSIFIED or NON_NORMATIVE
- metadata validates against schema

This is the one-time/per-KB-version exhaustivity gate.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import jsonschema

from rule_engine_v3 import load_jsonl, sha256_json

DEFAULT_SCHEMA = Path(__file__).resolve().parent.parent / "rules" / "v3" / "rule-metadata.schema.json"


def utcnow():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def main() -> int:
    ap = argparse.ArgumentParser(description="Publish fail-closed APD ruleset")
    ap.add_argument("--raw-rules", required=True)
    ap.add_argument("--metadata", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--version", required=True)
    ap.add_argument("--schema", default=str(DEFAULT_SCHEMA))
    ap.add_argument("--conflicts", help="optional conflict-policies.json")
    ap.add_argument("--source-inventory", help="source_blocks.json from kb_block_inventory.py")
    ap.add_argument("--source-dispositions", help="reviewed JSONL for every source block")
    ap.add_argument("--unsafe-skip-source-coverage", action="store_true", help="tests/migration only; never use for production publish")
    args = ap.parse_args()

    raw = json.loads(Path(args.raw_rules).read_text(encoding="utf-8"))
    rules = {r["id"]: r for r in raw["rules"]}
    rows = load_jsonl(Path(args.metadata))
    schema = json.loads(Path(args.schema).read_text(encoding="utf-8"))
    v = jsonschema.Draft202012Validator(schema)

    errors = []
    meta = {}
    for i, row in enumerate(rows, 1):
        es = list(v.iter_errors(row))
        for e in es:
            errors.append(f"metadata row {i} {row.get('rule_id','?')}: {e.message}")
        rid = row.get("rule_id")
        if rid in meta:
            errors.append(f"duplicate metadata rule_id: {rid}")
        meta[rid] = row

    missing = sorted(set(rules) - set(meta))
    stale = sorted(set(meta) - set(rules))
    unreviewed = sorted(rid for rid, m in meta.items() if m.get("classification_status") not in {"CLASSIFIED", "NON_NORMATIVE"})
    if missing:
        errors.append(f"{len(missing)} raw rules have no metadata")
    if stale:
        errors.append(f"{len(stale)} metadata rows refer to stale/nonexistent rule ids")
    if unreviewed:
        errors.append(f"{len(unreviewed)} rules are not reviewed/classified")

    source_coverage = None
    if not args.unsafe_skip_source_coverage:
        if not args.source_inventory or not args.source_dispositions:
            errors.append("strict source coverage requires --source-inventory and --source-dispositions")
        else:
            inv = json.loads(Path(args.source_inventory).read_text(encoding="utf-8"))
            disp_rows = load_jsonl(Path(args.source_dispositions))
            blocks = {b["block_id"]: b for b in inv.get("blocks", [])}
            disp = {d.get("block_id"): d for d in disp_rows}
            missing_blocks = sorted(set(blocks) - set(disp))
            stale_blocks = sorted(set(disp) - set(blocks))
            pending_blocks = sorted(bid for bid, d in disp.items() if d.get("status") not in {"NORMATIVE", "NON_NORMATIVE", "EXAMPLE", "STRUCTURE"})
            malformed_blocks = []
            for bid, d in disp.items():
                if bid not in blocks:
                    continue
                if d.get("status") == "NORMATIVE":
                    ids = d.get("rule_ids") or []
                    if not ids:
                        malformed_blocks.append((bid, "NORMATIVE without rule_ids"))
                    bad = [rid for rid in ids if rid not in rules]
                    if bad:
                        malformed_blocks.append((bid, "unknown rule ids"))
            if missing_blocks: errors.append(f"{len(missing_blocks)} source blocks have no disposition")
            if stale_blocks: errors.append(f"{len(stale_blocks)} source dispositions are stale")
            if pending_blocks: errors.append(f"{len(pending_blocks)} source blocks are not reviewed")
            if malformed_blocks: errors.append(f"{len(malformed_blocks)} source block dispositions are malformed")
            source_coverage = {
                "block_count": len(blocks),
                "inventory_sha256": inv.get("blocks_sha256"),
                "dispositions_sha256": sha256_json(disp_rows),
                "missing": len(missing_blocks),
                "stale": len(stale_blocks),
                "pending": len(pending_blocks),
                "malformed": len(malformed_blocks),
            }

    policies = {"policies": []}
    if args.conflicts:
        policies = json.loads(Path(args.conflicts).read_text(encoding="utf-8"))

    if errors:
        print("RULESET PUBLISH: FAIL")
        for e in errors[:20]:
            print("  -", e)
        if len(errors) > 20:
            print(f"  ... and {len(errors)-20} more")
        print(f"raw rules: {len(rules)} · metadata: {len(meta)} · missing: {len(missing)} · unreviewed: {len(unreviewed)} · stale: {len(stale)}")
        return 1

    bundle_rules = []
    for rid, rule in rules.items():
        bundle_rules.append({"rule": rule, "metadata": meta[rid]})
    bundle_rules.sort(key=lambda x: (x["rule"]["skill"], x["rule"]["file"], x["rule"]["line"], x["rule"]["id"]))

    out = {
        "published": True,
        "ruleset_version": args.version,
        "published_at": utcnow(),
        "kb_manifest": raw.get("manifest", {}),
        "rule_count": len(bundle_rules),
        "ruleset_sha256": sha256_json(bundle_rules),
        "source_coverage": source_coverage,
        "conflict_policies": policies.get("policies", []),
        "rules": bundle_rules,
    }
    Path(args.out).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("RULESET PUBLISH: PASS")
    print(f"version: {args.version}")
    print(f"rules:   {len(bundle_rules)}")
    print(f"hash:    {out['ruleset_sha256']}")
    print(f"written: {args.out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
