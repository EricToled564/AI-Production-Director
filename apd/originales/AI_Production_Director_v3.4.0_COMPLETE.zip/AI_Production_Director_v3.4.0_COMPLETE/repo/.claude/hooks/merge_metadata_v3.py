#!/usr/bin/env python3
"""Merge reviewed rule-metadata JSONL into the canonical metadata file."""
from __future__ import annotations
import argparse
from pathlib import Path
from rule_engine_v3 import load_jsonl, write_jsonl


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--base',required=True); ap.add_argument('--reviewed',required=True,nargs='+'); ap.add_argument('--out',required=True); a=ap.parse_args()
    rows={r['rule_id']:r for r in load_jsonl(Path(a.base))}
    changed=0
    for p in a.reviewed:
        for r in load_jsonl(Path(p)):
            rows[r['rule_id']]=r; changed+=1
    write_jsonl(Path(a.out),[rows[k] for k in sorted(rows)])
    print(f"merged reviewed rows: {changed}; total rows: {len(rows)}; written: {a.out}")
    return 0
if __name__=='__main__': raise SystemExit(main())
