#!/usr/bin/env python3
"""Fail unless every source block has an explicit one-time disposition.

Final statuses: NORMATIVE, NON_NORMATIVE, EXAMPLE, STRUCTURE.
NORMATIVE blocks must map to at least one canonical rule id.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
from rule_engine_v3 import load_jsonl
FINAL={'NORMATIVE','NON_NORMATIVE','EXAMPLE','STRUCTURE'}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inventory',required=True); ap.add_argument('--dispositions',required=True); ap.add_argument('--raw-rules',required=True); ap.add_argument('--json',action='store_true'); a=ap.parse_args()
    inv=json.loads(Path(a.inventory).read_text(encoding='utf-8')); raw=json.loads(Path(a.raw_rules).read_text(encoding='utf-8'))
    blocks={b['block_id']:b for b in inv['blocks']}; rules={r['id'] for r in raw['rules']}; disp={d['block_id']:d for d in load_jsonl(Path(a.dispositions))}
    missing=set(blocks)-set(disp); stale=set(disp)-set(blocks); pending=[]; malformed=[]
    for bid,b in blocks.items():
        d=disp.get(bid)
        if not d: continue
        st=d.get('status')
        if st not in FINAL: pending.append(bid); continue
        if st=='NORMATIVE':
            ids=d.get('rule_ids') or []
            if not ids: malformed.append((bid,'NORMATIVE without rule_ids'))
            bad=[x for x in ids if x not in rules]
            if bad: malformed.append((bid,'unknown rule_ids '+','.join(bad)))
        if st!='STRUCTURE' and not (d.get('reason') or '').strip():
            malformed.append((bid,f'{st} requires reason'))
    status='PASS' if not missing and not stale and not pending and not malformed else 'FAIL'
    result={'status':status,'blocks':len(blocks),'missing':len(missing),'stale':len(stale),'pending':len(pending),'malformed':len(malformed)}
    if a.json: print(json.dumps(result,indent=2))
    else:
        print(f'SOURCE COVERAGE: {status}'); [print(f'  {k:10} {v}') for k,v in result.items() if k!='status']
        for bid in pending[:5]: print(f'  PENDING {bid} {blocks[bid]["source_path"]}:{blocks[bid]["start_line"]}')
        for bid,why in malformed[:5]: print(f'  MALFORMED {bid} {why}')
    return 0 if status=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
