#!/usr/bin/env python3
"""Resolve structured qualification inheritance across project→scene→shot→asset.

A downstream layer may refine unlocked fields. A LOCKED field cannot change
silently. The only legal change is an explicit OVERRIDE carrying authorized_by.
Every accepted assignment is appended to provenance.
"""
from __future__ import annotations
import argparse, copy, json
from pathlib import Path
import jsonschema
from rule_engine_v3 import get_path

DEFAULT_SCHEMA=Path(__file__).resolve().parent.parent/'rules'/'v3'/'qualification-layer.schema.json'


def set_path(data, path, value):
    parts=path.split('.'); cur=data
    for p in parts[:-1]:
        if not isinstance(cur,dict) or p not in cur: raise KeyError(path)
        cur=cur[p]
    if not isinstance(cur,dict) or parts[-1] not in cur: raise KeyError(path)
    cur[parts[-1]]=value


def locked_by(path, locks):
    candidates=[l for l in locks if path==l or path.startswith(l+'.')]
    return max(candidates,key=len) if candidates else None


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--base',required=True); ap.add_argument('--layer',action='append',default=[]); ap.add_argument('--schema',default=str(DEFAULT_SCHEMA)); ap.add_argument('--out',required=True); ap.add_argument('--state-out'); a=ap.parse_args()
    case=json.loads(Path(a.base).read_text(encoding='utf-8')); schema=json.loads(Path(a.schema).read_text(encoding='utf-8')); v=jsonschema.Draft202012Validator(schema)
    locks=set(); history=[]; errors=[]; overrides=[]
    for lp in a.layer:
        layer=json.loads(Path(lp).read_text(encoding='utf-8'))
        for e in v.iter_errors(layer): errors.append(f'{lp}: {e.message}')
        if errors: continue
        for x in layer['assignments']:
            path=x['path']; exists,old=get_path(case,path)
            if not exists:
                errors.append(f'{lp}: unknown fingerprint path {path}'); continue
            lock=locked_by(path,locks)
            changing=old!=x['value']
            if lock and changing:
                if x['state']!='OVERRIDE' or not x.get('authorized_by'):
                    errors.append(f'{lp}: {path} is locked by {lock}; change requires OVERRIDE + authorized_by'); continue
                overrides.append({'path':path,'old':old,'new':x['value'],'authorized_by':x['authorized_by'],'layer_id':layer['layer_id'],'reason':x.get('reason','')})
            if x['state']=='OVERRIDE' and not x.get('authorized_by'):
                errors.append(f'{lp}: OVERRIDE for {path} requires authorized_by'); continue
            try: set_path(case,path,x['value'])
            except KeyError: errors.append(f'{lp}: cannot assign {path}'); continue
            if x['state']=='LOCKED': locks.add(path)
            history.append({'layer_id':layer['layer_id'],'entity_type':layer['entity_type'],'path':path,'state':x['state'],'old':old,'new':x['value'],'source_type':x['source_type'],'source_id':x['source_id'],'confidence':x['confidence'],'reason':x.get('reason','')})
            # Keep fingerprint provenance machine-readable using existing schema.
            case.setdefault('provenance',[]).append({'path':path,'source_type':x['source_type'],'source_id':x['source_id'],'confidence':x['confidence']})
    if errors:
        print('INHERITANCE: FAIL')
        for e in errors[:20]: print('  -',e)
        return 1
    Path(a.out).write_text(json.dumps(case,ensure_ascii=False,indent=2),encoding='utf-8')
    state={'status':'PASS','base':str(a.base),'layers':a.layer,'locks':sorted(locks),'overrides':overrides,'history':history}
    if a.state_out: Path(a.state_out).write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
    print('INHERITANCE: PASS'); print(f'  assignments: {len(history)}'); print(f'  locks: {len(locks)}'); print(f'  overrides: {len(overrides)}'); print(f'  written: {a.out}')
    return 0
if __name__=='__main__': raise SystemExit(main())
