#!/usr/bin/env python3
"""Compile the Knowledge Base into a stable raw rule registry + source manifest.

This is the OFFLINE exhaustivity step. It scans every installed skill Markdown
source, hashes every source file, extracts rule candidates mechanically using the
existing rule_registry extractor, and assigns canonical ids that include skill
name so identical relative paths in different skills cannot collide.

It does NOT claim semantic classification. Publication is a separate gate.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path

from rule_engine_v3 import sha256_file, sha256_json

HERE = Path(__file__).resolve().parent


def utcnow() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_legacy_extractor():
    p = HERE / "rule_registry.py"
    spec = importlib.util.spec_from_file_location("legacy_rule_registry", p)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(mod)
    return mod


def canonical_id(skill: str, rel: str, text: str) -> str:
    norm = " ".join(text.split()).strip().lower()
    return hashlib.sha1(f"{skill}\x00{rel}\x00{norm}".encode()).hexdigest()[:12]


def skill_dirs(root: Path) -> list[Path]:
    return sorted(p for p in root.iterdir() if p.is_dir() and (p / "SKILL.md").is_file())


def main() -> int:
    ap = argparse.ArgumentParser(description="Compile APD KB into raw canonical rule registry")
    ap.add_argument("--skills-root", required=True)
    ap.add_argument("--out-dir", required=True)
    args = ap.parse_args()

    skills_root = Path(args.skills_root).resolve()
    out_dir = Path(args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    extractor = load_legacy_extractor()

    sources = []
    rules = []
    legacy_collisions: dict[str, list[str]] = {}

    for sdir in skill_dirs(skills_root):
        skill = sdir.name
        for md in sorted(sdir.rglob("*.md")):
            rel = str(md.relative_to(sdir))
            source_rel = f"{skill}/{rel}"
            source_rules = extractor.extract_file(md, sdir)
            sources.append({
                "skill": skill,
                "file": rel,
                "source_path": source_rel,
                "sha256": sha256_file(md),
                "bytes": md.stat().st_size,
                "extracted_rules": len(source_rules),
            })
            for r in source_rules:
                cid = canonical_id(skill, r["file"], r["text"])
                legacy_collisions.setdefault(r["id"], []).append(cid)
                rules.append({
                    "id": cid,
                    "legacy_id": r["id"],
                    "skill": skill,
                    "file": r["file"],
                    "source_path": source_rel,
                    "line": r["line"],
                    "markers": r["markers"],
                    "text": r["text"],
                    "source_sha256": sha256_file(md),
                })

    # canonical ids must be unique. If not, identical text in the same source is
    # a duplicate candidate; preserve one but report the duplicate count.
    by_id = {}
    duplicate_canonical = 0
    for r in rules:
        if r["id"] in by_id:
            duplicate_canonical += 1
        else:
            by_id[r["id"]] = r
    rules = sorted(by_id.values(), key=lambda r: (r["skill"], r["file"], r["line"], r["id"]))

    collisions = {
        lid: sorted(set(cids)) for lid, cids in legacy_collisions.items()
        if len(set(cids)) > 1
    }

    manifest = {
        "schema_version": "3.0",
        "compiled_at": utcnow(),
        "skills_root": str(skills_root),
        "skills": len(skill_dirs(skills_root)),
        "source_files": len(sources),
        "source_bytes": sum(x["bytes"] for x in sources),
        "raw_rule_count": len(rules),
        "duplicate_canonical_candidates": duplicate_canonical,
        "legacy_id_collision_count": len(collisions),
        "sources_sha256": sha256_json([{k: x[k] for k in ("source_path", "sha256")} for x in sources]),
        "raw_rules_sha256": sha256_json([{k: r[k] for k in ("id", "source_path", "line", "text")} for r in rules]),
    }

    (out_dir / "sources.json").write_text(json.dumps({"sources": sources}, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "raw_rules.json").write_text(json.dumps({"manifest": manifest, "rules": rules}, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "kb_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "legacy_id_collisions.json").write_text(json.dumps(collisions, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"skills:                  {manifest['skills']}")
    print(f"source files scanned:    {manifest['source_files']}")
    print(f"raw rules extracted:     {manifest['raw_rule_count']}")
    print(f"legacy id collisions:    {manifest['legacy_id_collision_count']}")
    print(f"canonical duplicates:    {manifest['duplicate_canonical_candidates']}")
    print(f"KB source hash:          {manifest['sources_sha256']}")
    print(f"raw rules hash:          {manifest['raw_rules_sha256']}")
    print(f"written:                 {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
