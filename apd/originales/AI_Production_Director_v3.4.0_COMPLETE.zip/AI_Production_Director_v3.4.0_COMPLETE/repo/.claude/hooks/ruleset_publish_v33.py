#!/usr/bin/env python3
"""Strict APD v3.1 ruleset publisher.

Exhaustivity is certified relative to the frozen original source universe:
1) every original source has a role;
2) every meaningful Markdown block has exactly one final disposition;
3) every NORMATIVE block maps 1:1 to one canonical block rule;
4) every canonical rule has exactly one schema-valid CLASSIFIED metadata row;
5) direct executable/config/schema normative authorities are independently inventoried;
6) every declared incompatible conflict group has exactly one explicit policy winner;
7) no unsafe inferred runtime fields are allowed in applicability scope.
"""
from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path
from collections import Counter, defaultdict
import jsonschema

ALLOWED_DISP={'NORMATIVE','NON_NORMATIVE','EXAMPLE','STRUCTURE'}
DIRECT_ROLES={'EXECUTABLE_VALIDATOR','NORMATIVE_CONFIG','NORMATIVE_SCHEMA','NORMATIVE_METHOD'}
# Scope fields whose presence would indicate the rejected body-keyword inference approach.
UNSAFE_INFERRED_PATHS={
 'subject.hands_visible','subject.feet_visible','subject.human_contact',
 'physics.water','physics.splash','physics.refraction','subject.product_present',
 'audio.dialogue_required','audio.lipsync'
}

def load_jsonl(p):
    return [json.loads(x) for x in Path(p).read_text(encoding='utf-8').splitlines() if x.strip()]

def sha_json(x):
    b=json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    return hashlib.sha256(b).hexdigest()

def paths(x):
    if isinstance(x,dict):
        if 'path' in x: yield x['path']
        for v in x.values(): yield from paths(v)
    elif isinstance(x,list):
        for v in x: yield from paths(v)

def incompatible(effects):
    e=set(effects)
    return ({'REQUIRE','FORBID'} <= e) or ('FORBID' in e and 'RECOMMEND' in e)

def utcnow(): return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-catalog',required=True)
    ap.add_argument('--source-blocks',required=True)
    ap.add_argument('--source-dispositions',required=True)
    ap.add_argument('--block-rules',required=True)
    ap.add_argument('--metadata',required=True)
    ap.add_argument('--metadata-schema',required=True)
    ap.add_argument('--direct-authorities',required=True)
    ap.add_argument('--conflicts',required=True)
    ap.add_argument('--version',required=True)
    ap.add_argument('--out',required=True)
    a=ap.parse_args()
    errors=[]; warnings=[]

    cat=json.load(open(a.source_catalog,encoding='utf-8'))
    blocks_doc=json.load(open(a.source_blocks,encoding='utf-8'))
    disp=load_jsonl(a.source_dispositions)
    raw=json.load(open(a.block_rules,encoding='utf-8'))
    metas=load_jsonl(a.metadata)
    schema=json.load(open(a.metadata_schema,encoding='utf-8'))
    direct=json.load(open(a.direct_authorities,encoding='utf-8'))
    conf=json.load(open(a.conflicts,encoding='utf-8'))

    # 1. Frozen original source universe.
    sources=cat.get('sources',[])
    if cat.get('inventory_count') != len(sources): errors.append('source catalog inventory_count mismatch')
    if cat.get('inventory_count') != 274: errors.append(f"expected frozen original source universe of 274, got {cat.get('inventory_count')}")
    if cat.get('unclassified'): errors.append(f"{len(cat['unclassified'])} original sources remain UNCLASSIFIED")
    if any(not s.get('role') for s in sources): errors.append('one or more source files has empty role')

    # 2. Source blocks and dispositions exact accounting.
    blocks=blocks_doc.get('blocks',[])
    bmap={b['block_id']:b for b in blocks}
    if len(bmap)!=len(blocks): errors.append('duplicate block_id in source block inventory')
    dmap={d['block_id']:d for d in disp}
    if len(dmap)!=len(disp): errors.append('duplicate block_id in source dispositions')
    mb=set(bmap)-set(dmap); sb=set(dmap)-set(bmap)
    if mb: errors.append(f'{len(mb)} source blocks missing final disposition')
    if sb: errors.append(f'{len(sb)} stale source dispositions')
    bad_disp=[d for d in disp if d.get('status') not in ALLOWED_DISP]
    if bad_disp: errors.append(f'{len(bad_disp)} source blocks have invalid/pending disposition')

    # 3. NORMATIVE block -> exactly one canonical rule; and no rule from nonnorm block.
    rules=raw.get('rules',[]); rmap={r['id']:r for r in rules}
    if len(rmap)!=len(rules): errors.append('duplicate canonical block rule id')
    by_block=defaultdict(list)
    for r in rules: by_block[r.get('block_id')].append(r)
    normative_blocks={bid for bid,d in dmap.items() if d.get('status')=='NORMATIVE'}
    missing_rule=[bid for bid in normative_blocks if len(by_block.get(bid,[]))!=1]
    extra_rule=[bid for bid,rs in by_block.items() if bid not in normative_blocks]
    if missing_rule: errors.append(f'{len(missing_rule)} NORMATIVE blocks do not map to exactly one canonical rule')
    if extra_rule: errors.append(f'{len(extra_rule)} canonical rules originate from non-NORMATIVE blocks')
    if len(normative_blocks)!=len(rules): errors.append(f'normative block/rule count mismatch {len(normative_blocks)} != {len(rules)}')

    # 4. Metadata exact + schema valid + no unsafe inferred scope.
    validator=jsonschema.Draft202012Validator(schema)
    mmap={}
    schema_errors=0
    unsafe=[]
    for i,m in enumerate(metas,1):
        if m.get('rule_id') in mmap: errors.append(f"duplicate metadata id {m.get('rule_id')}")
        mmap[m.get('rule_id')]=m
        es=list(validator.iter_errors(m))
        if es:
            schema_errors+=len(es)
            if schema_errors<=10: errors.append(f"metadata schema {m.get('rule_id')}: {es[0].message}")
        bad=set(paths(m.get('when',{}))) & UNSAFE_INFERRED_PATHS
        if bad: unsafe.append((m.get('rule_id'),sorted(bad)))
    if schema_errors>10: errors.append(f'{schema_errors} total metadata schema errors')
    if unsafe: errors.append(f'{len(unsafe)} rules contain unsafe body-derived applicability paths; first={unsafe[:3]}')
    missing_meta=set(rmap)-set(mmap); stale_meta=set(mmap)-set(rmap)
    if missing_meta: errors.append(f'{len(missing_meta)} canonical rules missing metadata')
    if stale_meta: errors.append(f'{len(stale_meta)} stale metadata rows')
    unclassified=[m for m in metas if m.get('classification_status')!='CLASSIFIED']
    if unclassified: errors.append(f'{len(unclassified)} canonical rules not CLASSIFIED')

    # 5. Direct normative authorities independently accounted.
    expected_direct=sorted(s['path'] for s in sources if s.get('role') in DIRECT_ROLES)
    actual_direct=sorted(s['path'] for s in direct.get('sources',[]))
    if expected_direct!=actual_direct: errors.append('direct authority manifest does not exactly match source catalog direct roles')
    if direct.get('count')!=len(actual_direct): errors.append('direct authority count mismatch')
    if direct.get('authorities_sha256')!=sha_json(direct.get('sources',[])): errors.append('direct authority manifest hash mismatch')

    # 6. Conflict policy integrity for every explicit incompatible group.
    groups=defaultdict(list)
    for rid,m in mmap.items():
        if m.get('conflict_key'): groups[m['conflict_key']].append(m)
    policies=conf.get('policies',[])
    pby=defaultdict(list)
    for p in policies: pby[p.get('conflict_key')].append(p)
    conflict_audit=[]
    for key,grp in sorted(groups.items()):
        inc=incompatible([m['effect'] for m in grp])
        row={'conflict_key':key,'rule_ids':[m['rule_id'] for m in grp],'effects':[m['effect'] for m in grp],'incompatible':inc,'policies':[p.get('id') for p in pby.get(key,[])]}
        if inc:
            if len(pby.get(key,[]))!=1: errors.append(f'conflict {key} requires exactly one policy')
            else:
                winner=pby[key][0].get('winner_rule_id')
                if winner not in row['rule_ids']: errors.append(f'conflict {key} policy winner is not a member of group')
                row['winner_rule_id']=winner
        conflict_audit.append(row)
    stale_policies=[p for p in policies if p.get('conflict_key') not in groups]
    if stale_policies: errors.append(f'{len(stale_policies)} conflict policies refer to nonexistent groups')

    # Master rule presence hard check, because prior audits found these false negatives.
    required_master={
      '2bdbd8488f44':'§6.1 vocabulary', '8b582880dec3':'§6.2 model syntax',
      'a94663a6fb29':'§6.3 structural source of truth','299e96108395':'§6.4 prompt ownership',
      '42c21b177cbb':'§6.5 attribution'
    }
    for rid,name in required_master.items():
        if rid not in rmap: errors.append(f'missing master conflict rule {name} ({rid})')
        elif rid not in mmap: errors.append(f'missing metadata for master conflict rule {name}')

    audit={
      'source_universe':{'files':len(sources),'unclassified':len(cat.get('unclassified',[])),'role_counts':cat.get('role_counts',{})},
      'source_blocks':{'total':len(blocks),'disposition_counts':dict(Counter(d.get('status') for d in disp)),'missing':len(mb),'stale':len(sb)},
      'canonical_rules':{'total':len(rules),'rules_sha256':raw.get('manifest',{}).get('rules_sha256'),'metadata_rows':len(metas),'metadata_sha256':sha_json(metas)},
      'direct_authorities':{'count':len(actual_direct),'hash':direct.get('authorities_sha256'),'by_role':direct.get('by_role',{})},
      'conflicts':conflict_audit,
      'unsafe_inferred_scope_paths':len(unsafe),
      'warnings':warnings,
    }
    if errors:
        print('RULESET V3.3 PUBLISH: FAIL')
        for e in errors: print('  -',e)
        return 1

    bundle_rules=[{'rule':rmap[rid],'metadata':mmap[rid]} for rid in sorted(rmap,key=lambda rid:(rmap[rid]['skill'],rmap[rid]['source_path'],rmap[rid]['line'],rid))]
    ruleset_hash=sha_json({'rules':bundle_rules,'policies':policies,'source_catalog_hash':sha_json(sources),'direct_authorities_hash':direct.get('authorities_sha256')})
    out={
      'published':True,
      'certification':'EXHAUSTIVE_RELATIVE_TO_KB_SOURCE_UNIVERSE_V3_3_DECISION_TABLE_REAUDIT',
      'ruleset_version':a.version,
      'published_at':utcnow(),
      'ruleset_sha256':ruleset_hash,
      'rule_count':len(bundle_rules),
      'source_catalog_sha256':sha_json(sources),
      'source_dispositions_sha256':sha_json(disp),
      'metadata_sha256':sha_json(metas),
      'direct_authorities_sha256':direct.get('authorities_sha256'),
      'direct_authorities':direct,
      'audit':audit,
      'conflict_policies':policies,
      'rules':bundle_rules,
    }
    Path(a.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('RULESET V3.3 PUBLISH: PASS')
    print('version',a.version)
    print('sources',len(sources),'blocks',len(blocks),'rules',len(bundle_rules),'direct_authorities',len(actual_direct))
    print('hash',ruleset_hash)
    print('written',a.out)
    return 0
if __name__=='__main__': raise SystemExit(main())
