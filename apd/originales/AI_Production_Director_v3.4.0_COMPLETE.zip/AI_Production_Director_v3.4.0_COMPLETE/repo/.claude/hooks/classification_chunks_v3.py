#!/usr/bin/env python3
"""Create review chunks for the one-time semantic classification of every rule.

Each chunk contains source text + migration seed. Reviewer returns one JSON object
per rule (same schema as rule-metadata.schema.json). Missing ids are detectable.
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
from rule_engine_v3 import load_jsonl


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--raw-rules',required=True); ap.add_argument('--metadata',required=True); ap.add_argument('--out-dir',required=True); ap.add_argument('--size',type=int,default=35); a=ap.parse_args()
    raw=json.loads(Path(a.raw_rules).read_text(encoding='utf-8')); rules={r['id']:r for r in raw['rules']}; meta={m['rule_id']:m for m in load_jsonl(Path(a.metadata))}
    pending=[rules[rid] for rid in rules if meta.get(rid,{}).get('classification_status') not in {'CLASSIFIED','NON_NORMATIVE'}]
    pending.sort(key=lambda r:(r['skill'],r['file'],r['line']))
    out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
    for p in out.glob('review-*.md'): p.unlink()
    n=math.ceil(len(pending)/a.size) if pending else 0
    for i in range(n):
        group=pending[i*a.size:(i+1)*a.size]
        lines=[f"# Rule classification review {i+1}/{n}","",f"Review all {len(group)} rules. For each rule, inspect the original text and its seed metadata. Return a complete JSON object per rule using rule-metadata.schema.json. Do not omit IDs. Mark CLASSIFIED only when scope/conditions/effect are correct; otherwise correct them. Mark NON_NORMATIVE only when the source line is not a production rule.",""]
        for r in group:
            m=meta[r['id']]
            lines += [f"## {r['id']} — {r['skill']}/{r['file']}:{r['line']}","",r['text'],"","Seed:","```json",json.dumps(m,ensure_ascii=False,indent=2),"```",""]
        (out/f"review-{i+1:03d}.md").write_text('\n'.join(lines),encoding='utf-8')
    print(f"pending rules: {len(pending)} -> {n} review chunks in {out}")
    return 0
if __name__=='__main__': raise SystemExit(main())
