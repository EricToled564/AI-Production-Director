#!/usr/bin/env python3
"""Create a reviewable metadata seed for every raw rule.

Important: this is a MIGRATION SEED, not a certified classification. Every row
is emitted, so coverage is exhaustive, but classification_status defaults to
NEEDS_REVIEW. ruleset_publish.py refuses to publish those rows.

The seed uses source-file semantics to reduce manual work. Human/external review
can promote each row to CLASSIFIED after checking the original rule.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from rule_engine_v3 import write_jsonl


def leaf(path, op, value=None):
    x = {"path": path, "op": op}
    if op not in ("truthy", "falsy", "exists") or value is not None:
        x["value"] = value
    return x


def all_(*conds):
    cs = [c for c in conds if c]
    return {} if not cs else (cs[0] if len(cs) == 1 else {"all": cs})


def any_(*conds):
    cs = [c for c in conds if c]
    return {} if not cs else (cs[0] if len(cs) == 1 else {"any": cs})


def base_for(rule):
    skill, f, text = rule["skill"], rule["file"].lower(), rule["text"].lower()
    cond = {}
    authority = "SKILL"
    effect = "RECOMMEND"
    validator = {"kind": "semantic", "id": None}
    priority = 400
    conflict_key = None

    markers = set(rule.get("markers", []))
    if "prohibition" in markers:
        effect = "FORBID"
    elif "obligation" in markers or "numbered_rule" in markers:
        effect = "REQUIRE"
    elif "recommendation" in markers:
        effect = "RECOMMEND"

    # Non-normative/example paths are still represented but require review.
    if "/examples/" in f"/{f}" or f.startswith("examples/"):
        authority = "EXAMPLE"
        effect = "NONE"
        cond = {}
        validator = {"kind": "none", "id": None}
        return cond, authority, effect, priority, validator, conflict_key

    # Skill-level stage/media routing.
    if skill == "image":
        cond = leaf("media", "eq", "image")
        if "gpt-image" in f:
            cond = all_(cond, leaf("generator.family", "eq", "gpt_image")); authority = "MODEL_ADAPTER"
        elif "nano-banana" in f:
            cond = all_(cond, leaf("generator.family", "eq", "nano_banana")); authority = "MODEL_ADAPTER"
        elif "editing" in f:
            cond = all_(cond, leaf("operation", "in", ["image_edit", "image_to_image"]))
        elif "vision-decomposer" in f:
            cond = all_(cond, leaf("operation", "eq", "reference_analysis"))
        elif "text-rendering" in f:
            cond = all_(cond, leaf("text.mode", "in", ["composite", "in_image"]))
        elif "characters" in f or "character-design" in f or "portrait-cinema" in f or "fashion-editorial" in f:
            cond = all_(cond, leaf("subject.human", "eq", True))
        elif "ecommerce" in f or "food-beverage" in f:
            cond = all_(cond, leaf("subject.product_present", "eq", True))
        elif "ui-social" in f or "poster-illustration" in f or "slides" in f:
            cond = all_(cond, leaf("base_type", "eq", "GRAF"))
        elif "storyboards" in f:
            cond = all_(cond, leaf("stage", "in", ["storyboard", "shot", "asset", "prompt"]))
        elif "multi-panel" in f:
            cond = all_(cond, leaf("base_type", "eq", "MULTI"))
        elif "structural" in f:
            cond = all_(cond, leaf("operation", "in", ["image_to_image", "image_edit", "reference_analysis"]))

    elif skill == "video":
        cond = leaf("media", "eq", "video")
        if f.endswith("/kling.md") or f == "references/kling.md":
            cond = all_(cond, leaf("generator.family", "eq", "kling")); authority = "MODEL_ADAPTER"
        elif "veo" in f:
            cond = all_(cond, leaf("generator.family", "eq", "veo")); authority = "MODEL_ADAPTER"
        elif "seedance" in f:
            cond = all_(cond, leaf("generator.family", "eq", "seedance")); authority = "MODEL_ADAPTER"
        elif "animatic-keyframes" in f:
            cond = all_(cond, leaf("stage", "in", ["storyboard", "shot", "asset"]))
        elif "race-and-speed" in f:
            cond = all_(cond, leaf("risk_flags", "intersects", ["SPEED", "RACE", "VEHICLE"]))

    elif skill == "visual-prompt-forge":
        cond = leaf("stage", "eq", "prompt")
        if f.startswith("adapters/"):
            fam = Path(f).stem.replace("gpt-image", "gpt_image").replace("nano-banana", "nano_banana")
            cond = all_(cond, leaf("generator.family", "eq", fam)); authority = "MODEL_ADAPTER"
        elif "consistency-locks" in f:
            cond = all_(cond, leaf("continuity.level", "not_in", ["none"]))
        elif "failure-modes" in f:
            cond = leaf("stage", "in", ["prompt", "qa"])

    elif skill == "storyboard-architect":
        cond = leaf("stage", "in", ["storyboard", "shot"])
    elif skill == "screenwriter":
        cond = leaf("stage", "in", ["script", "scene"])
    elif skill == "visual-asset-critic":
        cond = leaf("stage", "eq", "qa")
    elif skill == "brand-lock-extractor":
        cond = any_(leaf("stage", "eq", "brief"), leaf("operation", "eq", "brand_extract"), leaf("brand.mode", "not_in", ["none"]))
    elif skill == "storyboard-html-preview":
        cond = leaf("stage", "eq", "delivery")
    elif skill == "ai-video-storyboard":
        cond = all_(leaf("media", "eq", "video"), leaf("stage", "in", ["storyboard", "shot"]), leaf("track", "eq", "QUICK"))
    elif skill == "visual-media":
        cond = all_(leaf("media", "in", ["image", "video", "mixed"]), leaf("risk_flags", "contains", "ANIMATION"))
    elif skill == "produccion-visual-sw30":
        cond = all_(leaf("media", "in", ["image", "video"]), leaf("stage", "in", ["asset", "prompt", "generation", "qa"]))
        authority = "PIPELINE"; priority = 600
    elif skill == "ai-production-director":
        cond = {}
        authority = "PIPELINE"; priority = 650

    # Rule-level refinements for common conditional features.
    refinements = []
    if re.search(r"\b(hand|hands|mano|manos)\b", text):
        refinements.append(leaf("subject.hands_visible", "eq", True))
    if re.search(r"\b(feet|foot|toe|toes|pie|pies)\b", text):
        refinements.append(leaf("subject.feet_visible", "eq", True))
    if re.search(r"\b(identity|identidad|same person|same face|character consistency)\b", text):
        refinements.append(leaf("subject.identity_fidelity", "in", ["consistent", "exact"]))
    if re.search(r"\b(contact|high five|hug|touch|interaction between people)\b", text):
        refinements.append(leaf("subject.human_contact", "eq", True))
    if re.search(r"\b(text|typograph|lettering|logo|caption|subtitle|copy)\b", text) and skill in {"image", "visual-prompt-forge"}:
        refinements.append(leaf("text.mode", "not_in", ["none"]))
    if re.search(r"\b(reference|ref image|cref|sref)\b", text) and skill in {"image", "visual-prompt-forge"}:
        refinements.append(leaf("references.mode", "not_in", ["none"]))
    if re.search(r"\bedit|editing|replace|remove|swap|preserve\b", text) and skill == "image":
        refinements.append(leaf("operation", "in", ["image_edit", "image_to_image"]))

    if refinements:
        cond = all_(cond, *refinements)

    # Known lexical conflict family: vague quality/style words. The exact
    # disposition remains case-dependent and must be reviewed before publish.
    if re.search(r"photoreal|cinematic|masterpiece|stunning|epic|high quality|professional", text):
        conflict_key = "vocabulary.visual_style_quality"

    if effect == "FORBID":
        validator = {"kind": "lexical" if conflict_key else "semantic", "id": None}
    elif effect in {"REQUIRE", "GATE"}:
        validator = {"kind": "semantic", "id": None}

    return cond, authority, effect, priority, validator, conflict_key


def main() -> int:
    ap = argparse.ArgumentParser(description="Seed v3 metadata for every raw rule")
    ap.add_argument("--raw-rules", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    data = json.loads(Path(args.raw_rules).read_text(encoding="utf-8"))
    rows = []
    for r in data["rules"]:
        when, authority, effect, priority, validator, conflict_key = base_for(r)
        rows.append({
            "rule_id": r["id"],
            "classification_status": "NEEDS_REVIEW",
            "authority": authority,
            "effect": effect,
            "priority": priority,
            "when": when,
            "validator": validator,
            "conflict_key": conflict_key,
            "supersedes": [],
            "classification_provenance": {
                "method": "migration_seed",
                "reviewer": "unreviewed",
                "reviewed_at": None,
                "notes": "Deterministic seed from source path/text. Must be reviewed rule-by-rule before publication."
            }
        })
    write_jsonl(Path(args.out), rows)
    print(f"metadata rows: {len(rows)}")
    print("classification_status: NEEDS_REVIEW for every row")
    print(f"written: {args.out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
