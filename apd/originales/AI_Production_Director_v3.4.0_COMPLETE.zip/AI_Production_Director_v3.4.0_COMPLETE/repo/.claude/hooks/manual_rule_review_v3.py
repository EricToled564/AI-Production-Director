#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[3]
HOOKS=Path(__file__).resolve().parent
RULES=HOOKS.parent/'rules'/'v3'
AUTO=RULES/'rule-metadata.autoclassified.jsonl'
OUT=RULES/'rule-metadata.reviewed.jsonl'
BUILD=RULES/'build'

NON={
# table/contents/glossary/example fragments, not standalone normative propositions
'205410f1a889','e9db5f8c373c','15c99afb2343','08931603660c',
'5c3e03321fa0','957ceed645fa','89f544625d1a','34173409a1d1','007e8995e64b','7cdd52709bc2','f06f964ce392','54bc1eb81fdf','cccb8ca7a598','aaf8974dd19b','9d79a9d36df8','ea320b5350ef','d262a36afb53',
'4ea2d740c9fb','5e036b5dbfbe','23daca849a3b','cafc872ec70d','a092f6e92a5a','1db3d6f6a311','4ab25bb8abac',
'9b9850ad026d','082ef4c63248','07271a44b40d',
# duplicate template copy; canonical palette cap retained in brand-lock-extractor template
'08931603660c',
}

# helper conditions
L=lambda path,op,value=None: ({'path':path,'op':op} if op in {'truthy','falsy','exists'} and value is None else {'path':path,'op':op,'value':value})
def ALL(*xs): return {'all':[x for x in xs if x]}
def ANY(*xs): return {'any':[x for x in xs if x]}

OV={
# Aurora: only when the explicit sports-broadcast mode/tag is active.
'bdbfe3825e8c': dict(when=ALL(L('media','eq','video'),L('stage','eq','prompt'),L('task.tags','contains','SPORTS_BROADCAST')), effect='REQUIRE', authority='PIPELINE', priority=770, validator={'kind':'deterministic','id':'aurora.prompt_linter:sports_broadcast_required'}),
# Brand extraction hard rules: scope is extraction, not every branded downstream artifact.
'8d59454c87ee': dict(when=L('operation','eq','brand_extract'),effect='FORBID',validator={'kind':'semantic','id':'brand_lock:no_unverified_hex'}),
'd6d1b7da8559': dict(when=L('operation','eq','brand_extract'),effect='FORBID',validator={'kind':'semantic','id':'brand_lock:no_unverified_typeface'}),
'1cd7266731ef': dict(when=L('operation','eq','brand_extract'),effect='REQUIRE',validator={'kind':'semantic','id':'brand_lock:never_list_nonempty'}),
'e12b6c2a6277': dict(when=L('operation','eq','brand_extract'),effect='RECOMMEND',authority='GUIDELINE',priority=340,validator={'kind':'semantic','id':'brand_lock:palette_max_8_guideline'}),
'bfca9c3046b9': dict(when=L('operation','eq','brand_extract'),effect='FORBID',validator={'kind':'semantic','id':'brand_lock:no_unverified_hex'}),
'859f8b6618ba': dict(when=L('operation','eq','brand_extract'),effect='FORBID',validator={'kind':'semantic','id':'brand_lock:no_unverified_typeface'}),
'd98eaed160fe': dict(when=L('operation','eq','brand_extract'),effect='REQUIRE',validator={'kind':'semantic','id':'brand_lock:coherent_motion_language'}),
# Image multi-panel selection/constraints.
'8d6fa38ceae4': dict(when=ALL(L('media','eq','image'),L('stage','eq','prompt'),L('task.family','eq','multi_panel'),L('task.tags','intersects',['TVC_SHOT_BREAKDOWN','COMMERCIAL_SHOT_BREAKDOWN','NINE_CELL_GRID'])),effect='RECOMMEND'),
'c62949165832': dict(when=ALL(L('media','eq','image'),L('stage','eq','prompt'),L('task.family','eq','multi_panel'),L('task.tags','intersects',['CAMPAIGN_VISUAL','TRIPTYCH','HERO_CLOSEUP_ACTION'])),effect='RECOMMEND'),
'22e10fd1c5d9': dict(when=ALL(L('media','eq','image'),L('stage','eq','prompt'),L('task.family','eq','multi_panel'),L('task.tags','intersects',['TWELVE_PANEL','STORY_GRID','MOOD_GRID','4X3_GRID'])),effect='RECOMMEND'),
'8ecc3dab1066': dict(when=ALL(L('media','eq','image'),L('stage','eq','prompt'),L('task.family','eq','multi_panel')),effect='WARN',validator={'kind':'semantic','id':'image.multi_panel:grid_position_anchor'}),
# SW30 response process rule.
'16c17b8e1acd': dict(effect='PROCESS',validator={'kind':'process','id':'sw30:response_style'}),
# Storyboard routing/workflow.
'34e34a703266': dict(when=ALL(L('stage','in',['storyboard','shot']),L('operation','in',['text_to_image','image_edit','image_to_image'])),effect='PROCESS',validator={'kind':'process','id':'router:image_prompt_without_narrative'}),
'3c026411e88c': dict(effect='PROCESS',validator={'kind':'process','id':'storyboard:workflow_order'}),
'08a82c6e1ac9': dict(effect='PROCESS',validator={'kind':'process','id':'storyboard:brand_lock_fallback'}),
'4565e5d24295': dict(effect='GATE',validator={'kind':'semantic','id':'storyboard:brief_duration_framework_consistency'}),
'2bc88674d62e': dict(effect='PROCESS',validator={'kind':'semantic','id':'storyboard:framework_selection_documented'}),
'8a71279cfea7': dict(when=ALL(L('stage','in',['storyboard','shot']),L('task.tags','contains','FRAMEWORK_PRP')),effect='REQUIRE',validator={'kind':'semantic','id':'storyboard:prp_promise_specific'}),
'0ad6875e0c75': dict(when=ALL(L('stage','in',['storyboard','shot']),L('task.tags','intersects',['AD_CREATIVE','LANDING_PAGE_HERO','CONVERSION_SOCIAL'])),effect='RECOMMEND'),
'687be98287e5': dict(when=ALL(L('stage','in',['storyboard','shot']),L('task.tags','intersects',['TUTORIAL','DEMO_VIDEO','TRAINING_CONTENT'])),effect='RECOMMEND'),
'f9e5dcaaaa02': dict(effect='RECOMMEND',validator={'kind':'semantic','id':'storyboard:text_must_earn_keep'}),
'f55830225e9a': dict(when=ALL(L('stage','in',['storyboard','shot']),L('task.tags','contains','VOICEOVER')),effect='WARN',validator={'kind':'semantic','id':'storyboard:no_redundant_vo_text'}),
'a228b38d9594': dict(effect='RECOMMEND',validator={'kind':'semantic','id':'storyboard:no_filler_text'}),
'286174f4bd6c': dict(when=ALL(L('stage','in',['storyboard','shot']),L('text.mode','not_in',['none'])),effect='REQUIRE',validator={'kind':'semantic','id':'storyboard:reserve_negative_space_for_text'}),
'920a20ec8466': dict(when=ALL(L('stage','in',['storyboard','shot']),L('text.mode','not_in',['none']),L('task.tags','contains','CUSTOM_TEXT_POSITION')),effect='RECOMMEND'),
'f0cb3ea97558': dict(effect='RECOMMEND',validator={'kind':'semantic','id':'storyboard:hook_framing_contrast'}),
# Storyboard HTML.
'2736f52cd8fe': dict(effect='PROCESS',validator={'kind':'process','id':'storyboard_html:frame_embedding_choice'}),
'1758e630dab9': dict(effect='GATE',validator={'kind':'deterministic','id':'storyboard_html:print_layout'}),
# Video core.
'ab71adf39890': dict(effect='GATE',validator={'kind':'process','id':'video:dramaturgy_and_three_detail_before_delivery'}),
'3b3192ce4fec': dict(when=ALL(L('media','eq','video'),L('stage','in',['storyboard','shot','asset']),L('task.tags','contains','ANIMATIC')),effect='RECOMMEND',validator={'kind':'semantic','id':'video.animatic:keyframe_density_30s'}),
'6d159be1c0d1': dict(when=ALL(L('media','eq','video'),L('stage','in',['storyboard','shot','asset']),L('task.tags','contains','ANIMATIC')),effect='RECOMMEND',validator={'kind':'semantic','id':'video.animatic:emotion_without_face_substitution'}),
'5617d7b6cb17': dict(when=ALL(L('media','eq','video'),L('stage','in',['storyboard','shot','asset']),L('task.tags','contains','ANIMATIC')),effect='RECOMMEND',validator={'kind':'semantic','id':'video.animatic:depth_layer_jobs'}),
'3d060f8d9326': dict(effect='REQUIRE',validator={'kind':'lexical','id':'video:vague_cinematic_direction'}),
'fb35029af5f3': dict(effect='FORBID',validator={'kind':'lexical','id':'video:no_cinematic_colors'}),
'02aa19d9c833': dict(effect='REQUIRE',validator={'kind':'semantic','id':'video:transition_exact_moment_one_type'}),
'3ba97ba6f534': dict(effect='GATE',validator={'kind':'semantic','id':'video:three_jobs'}),
# Montage pattern selectors.
'8f04847c2a22': dict(when=ALL(L('media','eq','video'),L('task.tags','intersects',['TENSION_BUILD','REVEAL','DRAMATIC_EMPHASIS'])),effect='RECOMMEND'),
'50d97079d8b7': dict(when=ALL(L('media','eq','video'),L('task.tags','intersects',['PSYCHOLOGICAL_PRESSURE','INTERNAL_CONFLICT','IMPENDING_BAD_NEWS'])),effect='RECOMMEND'),
'1c762875bfb4': dict(when=ALL(L('media','eq','video'),L('task.tags','intersects',['DISCOVERY','HIDDEN_REVEAL','EXPLORATION','SEARCH'])),effect='RECOMMEND'),
'37c83abdc8f5': dict(when=ALL(L('media','eq','video'),L('task.tags','intersects',['CATASTROPHE','COMEDIC_DISASTER','DRAMATIC_DISASTER'])),effect='RECOMMEND'),
'5397f132e042': dict(when=ALL(L('media','eq','video'),L('subject.product_present','eq',True)),effect='RECOMMEND'),
'0c9c5c079633': dict(when=ALL(L('media','eq','video'),L('task.tags','intersects',['MUSIC_VIDEO','RHYTHMIC_LOOP','PERFORMANCE'])),effect='RECOMMEND'),
'5d1aa69765ea': dict(when=ALL(L('media','eq','video'),L('sequence.multi_shot','eq',True)),effect='REQUIRE',validator={'kind':'semantic','id':'video:repeat_continuity_block_per_clip'}),
'a6d0370c2869': dict(when=ALL(L('media','eq','video'),L('sequence.multi_shot','eq',True),L('generator.family','in',['seedance','veo'])),effect='REQUIRE',validator={'kind':'semantic','id':'video:timecoded_internal_beats'}),
'1d78f512ab7f': dict(when=ALL(L('media','eq','video'),L('sequence.multi_shot','eq',True)),effect='REQUIRE',validator={'kind':'semantic','id':'video:model_specific_timecode_structure'}),
'5f1096a6bc0d': dict(when=ALL(L('media','eq','video'),L('sequence.multi_shot','eq',True)),effect='REQUIRE',validator={'kind':'semantic','id':'video:clip_boundary_continuity'}),
'ea7ec3a10b98': dict(effect='GATE',validator={'kind':'semantic','id':'video.race:insert_load_bearing'}),
'd8555bab9213': dict(effect='REQUIRE',validator={'kind':'semantic','id':'video.race:warmth_point_source_limit'}),
'326cf8d03185': dict(when=ALL(L('media','eq','video'),L('stage','in',['scene','shot'])),effect='GATE',validator={'kind':'semantic','id':'video:shot_function_present'}),
'9b13cc686999': dict(when=ALL(L('media','eq','video'),L('stage','in',['scene','shot']),L('references.mode','not_in',['none'])),effect='REQUIRE',validator={'kind':'semantic','id':'video:single_dominant_director_reference'}),
'4d798e8705a5': dict(when=ALL(L('media','eq','video'),L('stage','in',['script','scene','shot'])),effect='REQUIRE',validator={'kind':'semantic','id':'video:physicalize_beats_and_subtext'}),
'5b90694c544e': dict(when=ALL(L('media','eq','video'),L('stage','in',['scene','shot'])),effect='REQUIRE',validator={'kind':'semantic','id':'video:function_tag_per_beat'}),
'69adec2b8bb4': dict(when=ALL(L('media','eq','video'),L('stage','in',['scene','shot']),L('task.tags','contains','MONTAGE')),effect='RECOMMEND'),
'6b561c99afcf': dict(when=ALL(L('media','eq','video'),L('stage','in',['scene','shot'])),effect='RECOMMEND',validator={'kind':'semantic','id':'video:function_tag_semantics'}),
'e1c3494d28e1': dict(effect='GATE',validator={'kind':'semantic','id':'video:three_detail_check'}),
# Visual asset critic.
'ebe24ae336c9': dict(effect='RECOMMEND',validator={'kind':'process','id':'critic:shot_intent_fallback'}),
'6480d1a0f109': dict(effect='RECOMMEND',validator={'kind':'process','id':'critic:brand_lock_optional_scope'}),
'a70b73cef603': dict(effect='GATE',validator={'kind':'semantic','id':'critic:intent_established'}),
'0feac8cdb201': dict(when=ALL(L('stage','eq','qa'),L('text.mode','not_in',['none'])),effect='REQUIRE',validator={'kind':'visual','id':'critic:text_negative_space'}),
'0201f6202dcf': dict(when=ALL(L('stage','eq','qa'),L('continuity.level','not_in',['none'])),effect='REQUIRE',validator={'kind':'visual','id':'critic:continuity_match'}),
'04559072fd28': dict(effect='FORBID',validator={'kind':'semantic','id':'critic:no_scope_creep'}),
'5a47e2a4eab4': dict(effect='PROCESS',validator={'kind':'process','id':'critic:layered_rubric'}),
'66404602f287': dict(effect='REQUIRE',validator={'kind':'visual','id':'critic:dof_matches_if_specified'}),
'129f383f5d5b': dict(effect='RECOMMEND',validator={'kind':'semantic','id':'critic:soft_fail_cluster_recheck'}),
'd1eff8b1d346': dict(effect='FORBID',validator={'kind':'semantic','id':'critic:no_scope_creep'}),
'faba6eeb358a': dict(effect='FORBID',validator={'kind':'semantic','id':'critic:no_pile_on_after_verdict'}),
# Visual prompt forge routing, capability authority, composition, locks.
'7de160615e64': dict(effect='PROCESS',validator={'kind':'process','id':'forge:storyboard_first_when_missing_shots'}),
'806d5d19d68a': dict(effect='REQUIRE',validator={'kind':'schema','id':'forge:target_generator_required'}),
'08916ae57b0c': dict(effect='PROCESS',validator={'kind':'process','id':'forge:schema_path_fallback'}),
'e90072bcc355': dict(effect='REQUIRE',authority='MODEL_ADAPTER',priority=600,validator={'kind':'deterministic','id':'forge:capabilities_source_of_truth'}),
'2988766eac65': dict(effect='REQUIRE',authority='MODEL_ADAPTER',priority=550,validator={'kind':'semantic','id':'forge:generator_parameters'}),
'8cecada8588a': dict(when=ALL(L('stage','eq','prompt'),L('brand.mode','not_in',['none'])),effect='FORBID',validator={'kind':'semantic','id':'forge:no_duplicate_brand_color_subject_prose'}),
'00c605e050f0': dict(when=ALL(L('stage','eq','prompt'),L('generator.family','eq','gpt_image'),L('composition.load_bearing','eq',True)),effect='REQUIRE',validator={'kind':'semantic','id':'gpt_image:explicit_spatial_language'}),
'e4e1baf250ad': dict(when=ALL(L('stage','eq','prompt'),L('generator.family','eq','gpt_image'),L('composition.load_bearing','eq',True)),effect='REQUIRE',validator={'kind':'semantic','id':'gpt_image:explicit_spatial_language'}),
'78ffb0d37f72': dict(effect='REQUIRE',validator={'kind':'semantic','id':'forge:lighting_direction_lock'}),
'76f3265ebf27': dict(effect='REQUIRE',validator={'kind':'semantic','id':'forge:lighting_flip_rationale'}),
'c927233dce49': dict(when=ALL(L('stage','in',['prompt','qa']),L('brand.mode','not_in',['none'])),effect='PROCESS',validator={'kind':'semantic','id':'forge:surface_brand_never_list'}),
}

def main():
    rows=[json.loads(x) for x in AUTO.read_text(encoding='utf-8').splitlines() if x.strip()]
    remaining=json.load(open(BUILD/'rule_review_remaining.json',encoding='utf-8'))['items']
    review_ids={x['rule']['id'] for x in remaining}
    covered=set(NON)|set(OV)
    missing=sorted(review_ids-covered)
    extra=sorted(covered-review_ids)
    if missing:
        raise SystemExit('Manual review map incomplete; missing: '+','.join(missing))
    # extras are okay only if accidental duplicate in NON/OV overlap; otherwise reject
    real_extra=[x for x in extra if x not in review_ids]
    if real_extra:
        raise SystemExit('Manual review map contains non-review ids: '+','.join(real_extra))
    now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    for r in rows:
        rid=r['rule_id']
        if rid not in review_ids: continue
        if rid in NON:
            r.update(classification_status='NON_NORMATIVE',authority='EXAMPLE',effect='NONE',priority=0,when={},validator={'kind':'none','id':None},conflict_key=None,supersedes=[])
            note='Manual exhaustive review: table/contents/glossary/example/duplicate fragment is not a standalone normative proposition.'
        else:
            r['classification_status']='CLASSIFIED'
            for k,v in OV.get(rid,{}).items(): r[k]=v
            note='Manual exhaustive review: scope separated from internal conditional compliance; rule retained as current normative/guidance.'
        r['classification_provenance']={'method':'manual','reviewer':'APD-v3-exhaustive-review','reviewed_at':now,'notes':note}
    OUT.write_text('\n'.join(json.dumps(x,ensure_ascii=False,sort_keys=True) for x in rows)+'\n',encoding='utf-8')
    from collections import Counter
    c=Counter(x['classification_status'] for x in rows)
    print('reviewed metadata:',OUT)
    print(dict(c))
    print('NEEDS_REVIEW',c.get('NEEDS_REVIEW',0))

if __name__=='__main__':main()
