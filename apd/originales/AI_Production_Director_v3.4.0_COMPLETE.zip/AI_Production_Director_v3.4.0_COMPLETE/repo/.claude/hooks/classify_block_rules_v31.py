#!/usr/bin/env python3
from __future__ import annotations
import json,re
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone

HOOKS=Path(__file__).resolve().parent
RULES=HOOKS.parent/'rules'/'v3'
BUILD=RULES/'build'
IN=BUILD/'rules.block-v3.1.json'
OUT=RULES/'rule-metadata.final-v3.1.jsonl'

# Scope is deliberately derived only from source identity and heading context.
# Rule text is used for EFFECT / validator type, never to narrow applicability.

def L(path,op,value=None):
    d={'path':path,'op':op}
    if value is not None: d['value']=value
    return d

def ALL(*xs):
    ys=[]
    for x in xs:
        if not x: continue
        if set(x)=={'all'}: ys.extend(x['all'])
        else: ys.append(x)
    if not ys:return {}
    return ys[0] if len(ys)==1 else {'all':ys}

def ANY(*xs):
    ys=[x for x in xs if x]
    if not ys:return {}
    return ys[0] if len(ys)==1 else {'any':ys}

def add(c,x): return ALL(c,x)

IMG_ADAPTERS={'flux','gpt-image','ideogram','midjourney','nano-banana','seedream'}
VID_ADAPTERS={'hailuo','kling','seedance','veo'}
FAM={'gpt-image':'gpt_image','nano-banana':'nano_banana','seedream':'seedream','midjourney':'midjourney','ideogram':'ideogram','flux':'flux','hailuo':'hailuo','kling':'kling','seedance':'seedance','veo':'veo'}

PATTERN_FAMILY={
 'references/patterns/character-design.md':'character_design',
 'references/patterns/ecommerce.md':'ecommerce',
 'references/patterns/fashion-editorial.md':'fashion_editorial',
 'references/patterns/food-beverage.md':'food_beverage',
 'references/patterns/portrait-cinema.md':'portrait',
 'references/patterns/poster-illustration.md':'poster_illustration',
 'references/patterns/ui-social.md':'ui_social',
}


def stage_scope_from_director(ctx):
    lc=ctx.lower()
    if 'etapa 0' in lc: return L('stage','eq','brief')
    if 'etapa 1' in lc: return L('stage','eq','strategy')
    if 'etapa 2' in lc: return L('stage','in',['script','scene'])
    if 'etapa 3' in lc: return L('stage','in',['scene','shot'])
    if 'etapa 4' in lc: return L('stage','in',['storyboard','shot'])
    if 'etapa 5' in lc: return L('stage','in',['asset','prompt','generation','qa'])
    if 'etapa 6' in lc: return ALL(L('media','eq','video'),L('stage','in',['prompt','generation']))
    if 'etapa 7' in lc: return L('stage','eq','delivery')
    return {}


def explicit_heading_scope(r):
    """Only scopes encoded by section/file names, never body word matches."""
    s=r['skill']; f=r['file'].lower(); ctx=r.get('context',''); lc=ctx.lower()
    authority='SKILL'; priority=500; c={}; reason=[]

    if s=='ai-production-director':
        authority='PIPELINE'; priority=800
        c=stage_scope_from_director(ctx)
        reason.append('director pipeline stage from heading' if c else 'director global pipeline rule')
        if f=='references/creative-strategy.md': c=L('stage','eq','strategy'); reason=['creative-strategy source']
        elif f=='references/production-package.md': c=L('stage','eq','delivery'); reason=['production-package source']
        if '6. reglas de resolución de conflictos' in lc:
            authority='GLOBAL_HARD'; priority=950; reason.append('explicit conflict-resolution section')

    elif s=='produccion-visual-sw30':
        authority='GLOBAL_HARD' if ('reglas críticas' in lc or 'micro-gate' in lc or 'arquitectura por secciones' in lc) else 'PIPELINE'
        priority=900 if authority=='GLOBAL_HARD' else 790
        c=ALL(L('media','in',['image','video']),L('stage','in',['asset','prompt','generation','qa']))
        reason=['SW30 visual production scope']
        if 'maestro de rostro (t1)' in lc:
            c=add(c,L('base_type','eq','T1')); reason.append('T1 heading')

    elif s=='ai-video-storyboard':
        authority='SKILL'; priority=420
        c=ALL(L('media','eq','video'),L('stage','in',['storyboard','shot','prompt']),L('pipeline_track','eq','EXPRESS'))
        reason=['EXPRESS storyboard source']

    elif s=='aurora-prompt-linter':
        authority='PIPELINE'; priority=780
        c=ALL(L('media','in',['image','video']),L('stage','eq','prompt'))
        reason=['Aurora linter prompt gate']

    elif s=='brand-lock-extractor':
        authority='SKILL'; priority=520
        c=ANY(L('operation','eq','brand_extract'),L('brand.mode','not_in',['none']))
        reason=['brand extraction / brand-bearing task']

    elif s=='image':
        authority='SKILL'; priority=520
        c=ALL(L('media','eq','image'),L('stage','in',['asset','prompt','generation']))
        reason=['image production source']
        if f in PATTERN_FAMILY:
            c=add(c,L('task.family','eq',PATTERN_FAMILY[f])); authority='GUIDELINE'; priority=350; reason.append('pattern family from file')
        elif f=='references/gpt-image.md': c=add(c,L('generator.family','eq','gpt_image')); authority='MODEL_ADAPTER'; priority=610; reason.append('GPT Image model file')
        elif f=='references/nano-banana.md': c=add(c,L('generator.family','eq','nano_banana')); authority='MODEL_ADAPTER'; priority=610; reason.append('Nano Banana model file')
        elif f=='references/characters.md': c=add(c,ANY(L('subject.identity_fidelity','in',['consistent','exact']),L('subject.recurring_character','eq',True))); reason.append('character consistency file')
        elif f=='references/dimensional.md': c=add(c,L('task.family','eq','dimensional')); reason.append('dimensional file')
        elif f=='references/editing.md': c=add(c,L('operation','in',['image_edit','image_to_image'])); reason.append('editing file')
        elif f=='references/multi-panel.md': c=add(c,L('task.family','eq','multi_panel')); reason.append('multi-panel file')
        elif f=='references/slides.md': c=add(c,L('task.family','eq','presentation_slide')); reason.append('slides file')
        elif f=='references/storyboards.md': c=add(c,L('task.family','eq','storyboard')); reason.append('storyboards file')
        elif f=='references/structural.md': c=add(c,L('task.tags','contains','STRUCTURAL_INPUT')); reason.append('structural-input file')
        elif f=='references/text-rendering.md': c=add(c,ANY(L('task.family','eq','text_rendering'),L('text.mode','not_in',['none']))); reason.append('text-rendering file')
        elif f=='references/vision-decomposer.md': c=ALL(L('media','eq','image'),L('operation','eq','reference_analysis')); reason=['reference-analysis file']

    elif s=='screenwriter':
        authority='SKILL'; priority=520
        c=ALL(L('media','in',['text','mixed','video']),L('stage','in',['script','scene']))
        reason=['screenwriting source']

    elif s=='storyboard-architect':
        authority='SKILL'; priority=540
        c=L('stage','in',['storyboard','shot'])
        reason=['storyboard/shot source']

    elif s=='storyboard-html-preview':
        authority='SKILL'; priority=500
        c=L('stage','eq','delivery')
        reason=['storyboard delivery preview source']

    elif s=='video':
        authority='SKILL'; priority=540
        c=ALL(L('media','eq','video'),L('stage','in',['scene','shot','prompt','qa']))
        reason=['video source']
        if f=='references/kling.md': c=add(c,L('generator.family','eq','kling')); authority='MODEL_ADAPTER'; priority=620; reason.append('Kling model file')
        elif f=='references/veo.md': c=add(c,L('generator.family','eq','veo')); authority='MODEL_ADAPTER'; priority=620; reason.append('Veo model file')
        elif f=='references/seedance.md': c=add(c,L('generator.family','eq','seedance')); authority='MODEL_ADAPTER'; priority=610; reason.append('Seedance model file')
        elif f=='references/seedance-25.md': c=ALL(c,L('generator.family','eq','seedance'),L('generator.model','regex',r'2[.]5')); authority='MODEL_ADAPTER'; priority=630; reason.append('Seedance 2.5 model file')
        elif f=='references/animatic-keyframes.md': c=ALL(L('media','eq','video'),L('stage','in',['storyboard','shot','asset'])); reason=['animatic keyframe source']
        elif f=='references/race-and-speed.md': c=add(c,L('task.family','eq','race_speed')); reason.append('race/speed source')
        elif f=='references/fixes-and-skeletons.md': c=ALL(L('media','eq','video'),L('stage','in',['prompt','qa'])); reason=['video fixes source']
        elif f=='references/patterns-and-genres.md': authority='GUIDELINE'; priority=360; reason.append('genre/pattern catalog')
        elif f=='references/camera-lighting-vocabulary.md': authority='GUIDELINE'; priority=340; reason.append('camera/light vocabulary')
        elif f=='references/role-modes.md':
            # Section names are explicit model/speaker modes; do not infer from body prose.
            if 'veo' in lc: c=add(c,L('generator.family','eq','veo')); authority='MODEL_ADAPTER'; priority=610; reason.append('Veo heading')

    elif s=='visual-asset-critic':
        authority='SKILL'; priority=560
        c=L('stage','eq','qa')
        reason=['visual QA source']

    elif s=='visual-prompt-forge':
        authority='SKILL'; priority=550
        c=L('stage','eq','prompt')
        reason=['prompt forge source']
        if f.startswith('adapters/') and f.endswith('.md'):
            name=Path(f).stem
            fam=FAM.get(name,name.replace('-','_'))
            media='image' if name in IMG_ADAPTERS else 'video' if name in VID_ADAPTERS else None
            c=ALL(c,L('generator.family','eq',fam),L('media','eq',media) if media else {})
            authority='MODEL_ADAPTER'; priority=600; reason.append('adapter file identity')
        elif f=='references/consistency-locks.md': c=add(c,L('continuity.level','not_in',['none'])); reason.append('consistency-lock source')
        elif f=='references/failure-modes.md': c=L('stage','in',['prompt','qa']); reason=['prompt failure/QA source']

    elif s=='visual-media':
        authority='GUIDELINE'; priority=300
        c=ALL(L('task.family','eq','animation'),L('media','in',['image','video','mixed']))
        reason=['visual-media explicitly limited to animation/didactic by director']
    else:
        reason=['unscoped normative source: conservative global applicability']

    # Explicit heading refinements are safe because they are structural labels.
    # These deliberately do NOT scan rule body text.
    if re.search(r'(?i)\bT1\b|maestro de rostro',ctx) and s=='produccion-visual-sw30': c=add(c,L('base_type','eq','T1')); reason.append('T1 explicit heading')
    if re.search(r'(?i)\bcase 1\b|caso 1\b',ctx) and s=='aurora-prompt-linter': c=add(c,L('prompt_case','eq','1')); reason.append('prompt case heading')
    if re.search(r'(?i)\bcase 2\b|caso 2\b',ctx) and s=='aurora-prompt-linter': c=add(c,L('prompt_case','eq','2')); reason.append('prompt case heading')
    if re.search(r'(?i)\b3a\b',ctx) and s=='aurora-prompt-linter': c=add(c,L('prompt_case','eq','3a')); reason.append('prompt case heading')
    if re.search(r'(?i)\b3b\b',ctx) and s=='aurora-prompt-linter': c=add(c,L('prompt_case','eq','3b')); reason.append('prompt case heading')
    if re.search(r'(?i)\b3c\b',ctx) and s=='aurora-prompt-linter': c=add(c,L('prompt_case','eq','3c')); reason.append('prompt case heading')
    if re.search(r'(?i)\bcase 4\b|caso 4\b',ctx) and s=='aurora-prompt-linter': c=add(c,L('prompt_case','eq','4')); reason.append('prompt case heading')

    return c,authority,priority,'; '.join(reason)

PROHIB=re.compile(r'(?i)\b(never|nunca|do not|don\'t|must not|cannot|can\'t|forbidden|prohibid|no se permite|no entregar|no se entrega|avoid\b)')
NEG_REQUIRE=re.compile(r"(?i)\b(?:don['’]t|do not|never)\s+(?:forget|omit|skip|leave out|fail to include|fail to)\b")
GATE=re.compile(r'(?i)\b(gate|pass/fail|status=fail|bloquea|blocked|quality bar|checklist maestro|no .* entrega)\b')
HARD=re.compile(r'(?i)\b(must|shall|required|mandatory|obligatorio|hay que|se debe|always|siempre|exactly|verbatim|source of truth|fuente de verdad|non-negotiable|cannot|can\'t|include in every|repeat .* every|one at a time|max(?:imum)?\b|min(?:imum)?\b)')
RECOMMEND=re.compile(r'(?i)\b(should|prefer|recommend|recommended|default to|best practice|use when|when to use|consider)\b')
PROCESS_CTX=re.compile(r'(?i)\b(workflow|step \d|process|protocol|routing|when to use|inputs?|outputs?|integration|reading order|cómo invocarlo|how to invoke|ante un cambio|load|read order)\b')
LEXICAL=re.compile(r'(?i)\b(vocabulary|vocabulario|word|term|phrase|literal|string|quoted|exact text|palabra|texto exacto|no ai artifacts|cinematic|masterpiece|high quality)\b')
SCHEMA=re.compile(r'(?i)\b(schema|json|xml|field|required field|hash|sha256|timing|duration sum|resolves to|foreign key|validate_shots|validator)\b')
VISUAL=re.compile(r'(?i)\b(anatom|skin|hands?|feet|face|eyes?|artifacts?|continuity|composition|lighting|dof|depth of field|reflection|refraction|water|splash|material|texture|visual)\b')


def effect_and_validator(r):
    t=r['text']; ctx=r.get('context','')
    full=ctx+' '+t
    # Process/routing rules remain PROCESS even if imperative unless they explicitly forbid/gate.
    if GATE.search(full):
        effect='GATE'
    elif NEG_REQUIRE.search(t):
        effect='REQUIRE'
    elif PROHIB.search(t):
        effect='FORBID'
    elif HARD.search(t):
        effect='REQUIRE'
    elif RECOMMEND.search(t):
        effect='RECOMMEND'
    elif PROCESS_CTX.search(ctx):
        effect='PROCESS'
    else:
        # Terse items promoted from hard/checklist contexts are requirements; others guidance.
        effect='REQUIRE' if re.search(r'(?i)\b(hard rules?|critical rules?|quality bar|checklist|mandatory|required|non-negotiables|golden rules?)\b',ctx) else 'RECOMMEND'

    if effect=='PROCESS': kind='process'
    elif SCHEMA.search(full): kind='deterministic'
    elif LEXICAL.search(full) and effect in {'FORBID','REQUIRE','GATE'}: kind='lexical'
    elif r['skill']=='visual-asset-critic' or (r['stage'] if 'stage' in r else False): kind='semantic'
    elif VISUAL.search(full) and ('qa' in ctx.lower() or r['skill']=='visual-asset-critic'): kind='visual'
    else: kind='semantic'
    return effect,kind


def conflict_metadata(r):
    key=None; supersedes=[]
    ctx=r.get("context","")
    path=r.get("source_path","")
    line=r.get("line",0)
    # Explicit APD conflict sections. IDs are block-based, so loser links are resolved later by conflict builder.
    if path=="ai-production-director/SKILL.md" and "6.1 Vocabulario" in ctx:
        key="video.final_prompt.vocabulary_closing"
    elif path=="ai-production-director/SKILL.md" and "6.2 Sintaxis de modelo" in ctx:
        key="final_prompt.syntax_authority"
    elif path=="ai-production-director/SKILL.md" and "6.3 Fuente de verdad estructural" in ctx:
        key="structural.source_of_truth"
    elif path=="ai-production-director/SKILL.md" and "6.4 División forge" in ctx:
        key="prompt.text_authority"
    if path=="ai-video-storyboard/SKILL.md" and line==91:
        key="video.final_prompt.vocabulary_closing"
    if path=="ai-video-storyboard/SKILL.md" and line==94:
        key="final_prompt.syntax_authority"
    return key,supersedes

# Manual semantic scope overrides for a small number of conflict/routing rules whose applicability
# cannot be represented faithfully from file/heading identity alone. These are explicit reviewed decisions,
# not keyword inference.
def manual_scope_override(r, when, authority, priority, notes):
    path=r.get("source_path",""); ctx=r.get("context",""); line=r.get("line",0)
    if path=="ai-production-director/SKILL.md" and "6.1 Vocabulario" in ctx:
        return ALL(L("media","eq","video"),L("stage","eq","prompt")),"GLOBAL_HARD",980,notes+"; manual semantic scope: final video prompt vocabulary"
    if path=="ai-production-director/SKILL.md" and "6.2 Sintaxis de modelo" in ctx:
        return ALL(L("media","in",["image","video"]),L("stage","eq","prompt")),"GLOBAL_HARD",975,notes+"; manual semantic scope: final visual prompt syntax"
    if path=="ai-production-director/SKILL.md" and "6.3 Fuente de verdad estructural" in ctx:
        return L("stage","in",["storyboard","shot","asset","prompt","generation","qa","delivery"]),"GLOBAL_HARD",970,notes+"; manual semantic scope: stage 4 onward"
    if path=="ai-production-director/SKILL.md" and "6.4 División forge" in ctx:
        return ALL(L("media","in",["image","video"]),L("stage","eq","prompt")),"GLOBAL_HARD",970,notes+"; manual semantic scope: final prompt authority"
    if path=="ai-production-director/SKILL.md" and "6.5 Atribución" in ctx:
        return L("stage","eq","delivery"),"GLOBAL_HARD",960,notes+"; manual semantic scope: package credits"
    return when,authority,priority,notes

def main():
    data=json.load(open(IN,encoding='utf-8'))
    now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    out=[]
    for r in data['rules']:
        when,authority,priority,notes=explicit_heading_scope(r)
        when,authority,priority,notes=manual_scope_override(r,when,authority,priority,notes)
        effect,kind=effect_and_validator(r)
        # Manual semantic effect overrides for the five explicit master conflict decisions.
        if r.get('source_path')=='ai-production-director/SKILL.md':
            _ctx=r.get('context','')
            if '6.1 Vocabulario' in _ctx:
                effect,kind='FORBID','lexical'
            elif '6.2 Sintaxis de modelo' in _ctx:
                effect,kind='REQUIRE','semantic'
            elif '6.3 Fuente de verdad estructural' in _ctx:
                effect,kind='FORBID','deterministic'
            elif '6.4 División forge' in _ctx:
                effect,kind='REQUIRE','deterministic'
            elif '6.5 Atribución' in _ctx:
                effect,kind='REQUIRE','semantic'
        conflict_key,supersedes=conflict_metadata(r)
        meta={
            'rule_id':r['id'],
            'classification_status':'CLASSIFIED',
            'authority':authority,
            'effect':effect,
            'priority':priority,
            'when':when,
            'validator':{'kind':kind,'id':f"v3:{r['skill']}:{r['id']}"},
            'conflict_key':conflict_key,
            'supersedes':supersedes,
            'classification_provenance':{
                'method':'source_file_policy',
                'reviewer':'APD-v3.1-safe-scope-classifier',
                'reviewed_at':now,
                'notes':notes+'; applicability narrowed only by file/heading structure; body text is reserved for compliance semantics, not scope.'
            }
        }
        out.append(meta)
    OUT.write_text('\n'.join(json.dumps(x,ensure_ascii=False,sort_keys=True) for x in out)+'\n',encoding='utf-8')
    print('classified',len(out))
    print('status',dict(Counter(x['classification_status'] for x in out)))
    print('authority',dict(Counter(x['authority'] for x in out)))
    print('effect',dict(Counter(x['effect'] for x in out)))
    print('validator',dict(Counter(x['validator']['kind'] for x in out)))
    print('nonempty when',sum(bool(x['when']) for x in out))
    # Scope audit: forbid risky body-derived field paths entirely.
    risky={'subject.hands_visible','subject.feet_visible','subject.human_contact','physics.water','physics.splash','physics.refraction','subject.product_present','audio.dialogue_required','audio.lipsync'}
    bad=[]
    def paths(x):
        if isinstance(x,dict):
            if 'path' in x: yield x['path']
            for v in x.values(): yield from paths(v)
        elif isinstance(x,list):
            for v in x: yield from paths(v)
    for m in out:
        ps=set(paths(m['when']))
        if ps & risky: bad.append((m['rule_id'],sorted(ps&risky)))
    if bad: raise SystemExit('Unsafe inferred runtime fields found: '+repr(bad[:10]))
    print('unsafe inferred field conditions: 0')
    print('written',OUT)

if __name__=='__main__':main()
