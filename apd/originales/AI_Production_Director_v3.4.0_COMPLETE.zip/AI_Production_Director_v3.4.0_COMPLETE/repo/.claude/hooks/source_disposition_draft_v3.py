#!/usr/bin/env python3
from __future__ import annotations
import json,re
from pathlib import Path
from collections import Counter,defaultdict
ROOT=Path(__file__).resolve().parents[3]
BUILD=Path(__file__).resolve().parents[1]/'rules'/'v3'/'build'

EXAMPLE_HEAD=re.compile(r'(?i)\b(example|examples|ejemplo|ejemplos|worked[- ]run|sample|samples|demo|demonstration|caso de ejemplo|creative prompt examples)\b')
NORM_HEAD=re.compile(r'(?i)\b(rule|rules|regla|reglas|required|requirements?|obligatorio|mandatory|gate|constraint|principle|principios|workflow|process|proceso|protocol|protocolo|checklist|invariant|output|input|syntax|format|schema|parameter|routing|selection|decision|consistency|identity|control|editing|composition|lighting|camera|shot|step|pipeline|failure|avoid|pitfall|best practice|quality|validation|check|limit|preserve|text rendering|character|material|microdetail|negative prompt|word count|override|when to use|cuándo usar|cómo usar|how to use|structure|estructura)\b')
IMPERATIVE=re.compile(r'(?i)^(?:[-*+]\s*)?(?:\d+[.)]\s*)?(?:create|keep|use|add|remove|replace|swap|move|choose|describe|specify|include|start|maintain|vary|generate|convert|flatten|turn|design|change|avoid|never|always|ensure|prefer|write|run|validate|check|capture|set|define|preserve|apply|load|read|classify|select|sequence|resolve|trace|do not|don\'t|no\s+|usa|usar|mant[eé]n|mantener|crea|crear|incluye|incluir|define|definir|ejecuta|ejecutar|valida|validar|evita|evitar|describe|describir|especifica|especificar|selecciona|seleccionar|clasifica|clasificar|conserva|conservar|aplica|aplicar)\b')
NORM_PHRASE=re.compile(r'(?i)\b(must|shall|required|mandatory|obligatorio|se debe|hay que|never|nunca|do not|don\'t|avoid|forbidden|prohib|always|siempre|should|prefer|recommend|default|only|solo|sólo|source of truth|fuente de verdad|gate|pass|fail|blocked|bloquea|no se entrega|exactly|verbatim|one at a time|max(?:imum)?|minimum|min\.|máximo|mínimo)\b')


def main():
    inv=json.load(open(BUILD/'source_blocks.json'))
    raw=json.load(open(BUILD/'raw_rules.json'))
    cat=json.load(open(BUILD/'source_catalog.json'))
    roles={r['path']:r['role'] for r in cat['sources']}
    bysrc=defaultdict(list)
    for r in raw['rules']: bysrc['skills/'+r['source_path']].append(r)
    blocks=defaultdict(list)
    for b in inv['blocks']: blocks['skills/'+b['source_path']].append(b)
    out=[]; counters=Counter(); candidates=[]
    for path,bs in blocks.items():
        role=roles.get(path,'UNCLASSIFIED')
        stack=[]
        for b in sorted(bs,key=lambda x:x['start_line']):
            kind=b['kind']; text=b['text'];
            if kind=='heading':
                m=re.match(r'^(#+)\s+(.*)',text.strip()); level=len(m.group(1)) if m else 1; title=m.group(2) if m else text
                stack=[x for x in stack if x[0]<level]; stack.append((level,title))
                status='STRUCTURE'; reason='heading'
            elif kind=='frontmatter': status='STRUCTURE'; reason='frontmatter'
            elif role in {'EXAMPLE','BINARY_EXAMPLE'}: status='EXAMPLE'; reason='source classified EXAMPLE'
            elif role=='PROPOSED_DOC': status='NON_NORMATIVE'; reason='proposal not approved/current authority'
            elif role not in {'NORMATIVE_DOC'}:
                status='NON_NORMATIVE'; reason=f'source role {role}'
            else:
                context=' > '.join(x[1] for x in stack)
                rules=[r for r in bysrc.get(path,[]) if b['start_line']<=r['line']<=b['end_line']]
                if rules:
                    status='NORMATIVE'; reason='contains extracted canonical rule(s)'
                elif EXAMPLE_HEAD.search(context):
                    status='EXAMPLE'; reason='inside example/sample section'
                elif kind=='code':
                    if NORM_HEAD.search(context) and not EXAMPLE_HEAD.search(context):
                        status='REVIEW_REQUIRED'; reason='code/template under normative section may encode requirements'
                    else:
                        status='EXAMPLE'; reason='code block without extracted rule'
                else:
                    t=' '.join(text.split())
                    if NORM_PHRASE.search(t) or IMPERATIVE.search(t) or (kind in {'list_item','table_row'} and NORM_HEAD.search(context)):
                        status='REVIEW_REQUIRED'; reason='possible implicit normative statement missing from extractor'
                    else:
                        status='NON_NORMATIVE'; reason='descriptive/explanatory block; no normative signal'
                rules=[]
            rec={'block_id':b['block_id'],'source_path':b['source_path'],'kind':kind,'start_line':b['start_line'],'end_line':b['end_line'],'context':' > '.join(x[1] for x in stack),'status':status,'reason':reason,'rule_ids':[r['id'] for r in locals().get('rules',[]) if isinstance(r,dict)] if status=='NORMATIVE' else []}
            out.append(rec); counters[status]+=1
            if status=='REVIEW_REQUIRED': candidates.append({**rec,'text':text})
    payload={'counts':dict(counters),'records':out,'review_required':candidates}
    (BUILD/'source_disposition_draft.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print('counts');
    for k,v in counters.most_common(): print(f'{k:20} {v}')
    print('review_required',len(candidates))
    by=Counter(c['source_path'] for c in candidates)
    print('top candidate files:')
    for k,v in by.most_common(30): print(f'{v:3d} {k}')
if __name__=='__main__': main()
