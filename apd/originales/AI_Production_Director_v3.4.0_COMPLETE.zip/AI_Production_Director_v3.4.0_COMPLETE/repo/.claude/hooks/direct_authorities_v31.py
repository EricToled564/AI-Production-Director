#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, hashlib
from pathlib import Path

DIRECT_ROLES={"EXECUTABLE_VALIDATOR","NORMATIVE_CONFIG","NORMATIVE_SCHEMA","NORMATIVE_METHOD"}

def sha256_json(x):
    b=json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()
    return hashlib.sha256(b).hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-catalog',required=True)
    ap.add_argument('--out',required=True)
    a=ap.parse_args()
    cat=json.load(open(a.source_catalog,encoding='utf-8'))
    rows=[]
    for s in cat['sources']:
        if s['role'] in DIRECT_ROLES:
            rows.append({k:s.get(k) for k in ['path','role','bytes','sha256','duplicate_group_size','duplicate_of']})
    rows.sort(key=lambda x:x['path'])
    out={
      'schema_version':'3.1',
      'description':'Non-Markdown and executable normative authorities accounted independently from block rules. They constrain validators/config/schema behavior and are not duplicated into prose block rules.',
      'direct_roles':sorted(DIRECT_ROLES),
      'count':len(rows),
      'by_role':{r:sum(1 for x in rows if x['role']==r) for r in sorted(DIRECT_ROLES)},
      'authorities_sha256':sha256_json(rows),
      'sources':rows
    }
    Path(a.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DIRECT AUTHORITIES: PASS')
    print('count',len(rows))
    print('by_role',out['by_role'])
    print('hash',out['authorities_sha256'])
    print('written',a.out)
if __name__=='__main__': main()
