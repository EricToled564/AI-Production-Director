#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,hashlib
from pathlib import Path
from collections import defaultdict,Counter

def load_jsonl(p): return [json.loads(x) for x in Path(p).read_text(encoding='utf-8').splitlines() if x.strip()]
def rid(block_id): return hashlib.sha256(f'block-rule-v3.1|{block_id}'.encode()).hexdigest()[:12]
def sha(obj): return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--dispositions',required=True); ap.add_argument('--blocks',required=True); ap.add_argument('--raw',required=True); ap.add_argument('--catalog',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    disp=load_jsonl(a.dispositions); blocks={b['block_id']:b for b in json.load(open(a.blocks,encoding='utf-8'))['blocks']}
    raws=json.load(open(a.raw,encoding='utf-8'))['rules']; raw_by_src=defaultdict(list)
    for r in raws: raw_by_src[r['source_path']].append(r)
    cat=json.load(open(a.catalog,encoding='utf-8')); source_sha={s['path'].removeprefix('skills/'):s['sha256'] for s in cat['sources'] if s['path'].startswith('skills/')}
    rules=[]
    for d in disp:
        if d['status']!='NORMATIVE': continue
        b=blocks[d['block_id']]; path=d['source_path']; text=' '.join(b['text'].split())
        legacy=[r['id'] for r in raw_by_src.get(path,[]) if d['start_line']<=r['line']<=d['end_line']]
        rules.append({'id':rid(d['block_id']),'block_id':d['block_id'],'legacy_rule_ids':legacy,'skill':path.split('/',1)[0],'file':path.split('/',1)[1],'source_path':path,'line':d['start_line'],'end_line':d['end_line'],'kind':d['kind'],'headings':[x.strip() for x in d.get('context','').split(' > ') if x.strip()],'context':d.get('context',''),'text':text,'source_sha256':source_sha.get(path),'classification_reason':d.get('reason','')})
    rules.sort(key=lambda r:(r['skill'],r['source_path'],r['line'],r['id']))
    if len({r['id'] for r in rules})!=len(rules): raise SystemExit('rule ID collision')
    manifest={'schema_version':'3.3-block','source_block_count':len(blocks),'normative_block_rule_count':len(rules),'normative_source_file_count':len(set(r['source_path'] for r in rules)),'legacy_rule_links':sum(len(r['legacy_rule_ids']) for r in rules),'rules_sha256':sha(rules),'source_dispositions_sha256':sha(disp)}
    Path(a.out).write_text(json.dumps({'manifest':manifest,'rules':rules},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2)); print('by skill',dict(sorted(Counter(r['skill'] for r in rules).items())))
if __name__=='__main__': main()
