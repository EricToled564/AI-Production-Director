#!/usr/bin/env python3
from __future__ import annotations
import json, hashlib
from pathlib import Path
from collections import Counter, defaultdict

HOOKS=Path(__file__).resolve().parent
RULES=HOOKS.parent/'rules'/'v3'
BUILD=RULES/'build'
RAW_CTX=BUILD/'raw_rules_with_context.json'
RAW_EXH=BUILD/'raw_rules.exhaustive.json'
SUP=BUILD/'supplemental_rules.json'
PRIOR=BUILD/'prior-review-input.jsonl'
DISP=RULES/'source-dispositions.reviewed.jsonl'
CAT=BUILD/'source_catalog.json'
BLOCKS=BUILD/'source_blocks.json'
OUT=BUILD/'effective_rules.json'

# Only current normative prose sources create prose rules. Other source roles remain
# accounted for in source_catalog and may be direct machine authorities (schemas,
# configs, validators) but are not duplicated into prose-rule entries.
PROSE_RULE_ROLES={'NORMATIVE_DOC'}
CANONICAL_TEMPLATE='brand-lock-extractor/brand-packs/_template.md'
TEMPLATE_CONSTRAINT_LINES={15,25,33,37,41}

def load_jsonl(p):
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def sha256_json(obj):
    b=json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    return hashlib.sha256(b).hexdigest()

def template_id(path,line,text):
    raw=f'template-rule-v3|{path}|{line}|{text}'.encode('utf-8')
    return hashlib.sha256(raw).hexdigest()[:12]

def main():
    rawctx={r['id']:r for r in json.load(open(RAW_CTX,encoding='utf-8'))['rules']}
    exh=json.load(open(RAW_EXH,encoding='utf-8'))['rules']
    supids={r['id'] for r in json.load(open(SUP,encoding='utf-8'))['rules']}
    prior={r['rule_id']:r for r in load_jsonl(PRIOR)}
    disp=load_jsonl(DISP)
    cat=json.load(open(CAT,encoding='utf-8'))
    roles={s['path'].removeprefix('skills/'):s['role'] for s in cat['sources'] if s['path'].startswith('skills/')}
    source_sha={s['path'].removeprefix('skills/'):s['sha256'] for s in cat['sources'] if s['path'].startswith('skills/')}
    blocks=json.load(open(BLOCKS,encoding='utf-8'))['blocks']

    dby=defaultdict(list)
    for d in disp: dby[d['source_path']].append(d)
    for rows in dby.values(): rows.sort(key=lambda x:(x['start_line'],x['end_line']))

    kept=[]; dropped=[]
    for r in exh:
        role=roles.get(r['source_path'],'UNCLASSIFIED')
        if role not in PROSE_RULE_ROLES:
            dropped.append({'id':r['id'],'reason':f'source role {role} is accounted separately, not a prose-rule authority'})
            continue
        rr=dict(r)
        if r['id'] in supids:
            matches=[d for d in dby.get(r['source_path'],[]) if d['start_line']==r['line'] and d['status']=='NORMATIVE']
            if not matches:
                dropped.append({'id':r['id'],'reason':'supplemental source block no longer NORMATIVE'})
                continue
            d=matches[0]
            rr['headings']=[x.strip() for x in d.get('context','').split(' > ') if x.strip()]
            rr['context']=d.get('context','')
            rr['source_sha256']=source_sha.get(r['source_path'])
            rr['origin']='SUPPLEMENTAL_SOURCE_BLOCK'
            kept.append(rr)
            continue

        p=prior.get(r['id'])
        if not p:
            dropped.append({'id':r['id'],'reason':'legacy-extracted rule lacks prior review disposition'})
            continue
        if p.get('classification_status')!='CLASSIFIED':
            dropped.append({'id':r['id'],'reason':f"prior rule disposition {p.get('classification_status')}"})
            continue
        ctx=rawctx.get(r['id'])
        if not ctx:
            dropped.append({'id':r['id'],'reason':'missing heading context'})
            continue
        rr.update({'headings':ctx.get('headings',[]),'context':ctx.get('context',''),'origin':'LEGACY_EXTRACTED_REVIEWED'})
        kept.append(rr)

    # The canonical brand-lock template is structural authority. Promote only its
    # explicit template constraints, not placeholder Never-list examples. The
    # storyboard-architect copy is byte-duplicate and is accounted as duplicate.
    for b in blocks:
        if b['source_path']!=CANONICAL_TEMPLATE or b['start_line'] not in TEMPLATE_CONSTRAINT_LINES:
            continue
        text=' '.join(b['text'].split())
        rid=template_id(CANONICAL_TEMPLATE,b['start_line'],text)
        ctx='Brand Lock template'
        kept.append({
            'id':rid,'legacy_id':None,'skill':'brand-lock-extractor',
            'file':'brand-packs/_template.md','source_path':CANONICAL_TEMPLATE,
            'line':b['start_line'],'end_line':b['end_line'],'markers':['template_constraint'],
            'text':text,'source_sha256':source_sha.get(CANONICAL_TEMPLATE),
            'headings':[],'context':ctx,'origin':'NORMATIVE_TEMPLATE_CONSTRAINT'
        })

    kept.sort(key=lambda r:(r['skill'],r['source_path'],r.get('line',0),r['id']))
    ids=[r['id'] for r in kept]
    if len(ids)!=len(set(ids)):
        raise SystemExit('duplicate effective rule ids')
    manifest={
        'schema_version':'3.1',
        'legacy_extracted_total':1221,
        'legacy_reviewed_normative':sum(1 for r in kept if r['origin']=='LEGACY_EXTRACTED_REVIEWED'),
        'supplemental_normative':sum(1 for r in kept if r['origin']=='SUPPLEMENTAL_SOURCE_BLOCK'),
        'template_constraints':sum(1 for r in kept if r['origin']=='NORMATIVE_TEMPLATE_CONSTRAINT'),
        'effective_rule_count':len(kept),
        'dropped_rule_count':len(dropped),
        'effective_rules_sha256':sha256_json(kept),
        'source_role_policy':{
            'prose_rule_roles':sorted(PROSE_RULE_ROLES),
            'direct_machine_authority_roles':['NORMATIVE_CONFIG','NORMATIVE_SCHEMA','EXECUTABLE_VALIDATOR','NORMATIVE_METHOD'],
            'non_rule_accounted_roles':['EXAMPLE','TEMPLATE','TOOL_DOCUMENTATION','TOOL_IMPLEMENTATION','ENGINE_IMPLEMENTATION','IMPLEMENTATION','LEGAL','TEST','DERIVED_CORPUS','BINARY_EXAMPLE','PROPOSED_DOC']
        }
    }
    OUT.write_text(json.dumps({'manifest':manifest,'rules':kept,'dropped':dropped},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))
    print('by skill',dict(sorted(Counter(r['skill'] for r in kept).items())))
    print('drop reasons top',dict(Counter(d['reason'] for d in dropped).most_common(12)))
    print('written',OUT)

if __name__=='__main__':main()
