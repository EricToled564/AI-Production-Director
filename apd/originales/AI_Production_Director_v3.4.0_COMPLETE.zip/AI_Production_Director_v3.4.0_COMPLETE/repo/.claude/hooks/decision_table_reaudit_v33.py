#!/usr/bin/env python3
from __future__ import annotations
import json, argparse
from pathlib import Path
from collections import Counter

PROMOTE = {
    # image/references/models.md — model selection TL;DR (12 decision rows)
    '0e362870b5d75e65','e8b13f2f6cc8387b','1fbbc8fe5deef52b','b4ee98784817c8fa',
    'b02ac5f1bb22eb91','4d576e3f68d39519','873706bd2095485c','3a7cdc153ba8c77d',
    '62180a687593b7d9','4d8e3458b579dbfa','976f411cc0253223','25df7f065b3e12c8',
    # model syntax table (exclude multi-ref capability row; it remains capability/reference data)
    'b7bc3862c1c5e03a','cb43afa8f0339571','a0138a15705e4395','796ecf22ce756f6c',
    '95e79e7d12c30503','e57dcd03bc389fdd','ff9d5f672ff8391a',
    # equal-good routing cases absent from TL;DR
    'b93217eb3ad730fc','a4946c5fc4aee393','fc9c06d3af04b42c','fcdfe3fbf2d0a1e2',
    # director track selection criteria (header/example remain non-normative)
    '5f6b38e2f6dc3436','2833002a4af8080b','2c64f675cad9c6ab','382b8189d6c1c530','bd0508ff2f24317c',
    # ai-video-storyboard default structure decision rows
    '519a15e312413379','d4e42d982138203f','b86643250bea09d0','85f8f140be9a1abf',
    'ffa980c5923d9654','9946d563d6822118','b1eacaf98c9edb3e',
    # Seedance multi-shot routing rows
    'e4dcc0e8963a0a40','9c00593c8da60370',
}

# Explicitly audited routing/decision table rows that remain non-normative because another
# executable authority or a freshness rule owns the decision.
REPRESENTED = {
    # Aurora CASE_CONFIGS in executable prompt_linter.py
    'cf32f84fd6af64ad':'aurora-prompt-linter/scripts/prompt_linter.py::CASE_CONFIGS',
    '10d33f0d03b75532':'aurora-prompt-linter/scripts/prompt_linter.py::CASE_CONFIGS',
    '1ab855e90c95f980':'aurora-prompt-linter/scripts/prompt_linter.py::CASE_CONFIGS',
    'f6da23c05329b735':'aurora-prompt-linter/scripts/prompt_linter.py::CASE_CONFIGS',
    '75bb3895d6618e2a':'aurora-prompt-linter/scripts/prompt_linter.py::CASE_CONFIGS',
    '0bc3feabf6c780d7':'aurora-prompt-linter/scripts/prompt_linter.py::CASE_CONFIGS',
}

# Table headers and non-authoritative/stale capability data explicitly reviewed.
KEEP_NON_NORMATIVE = {
    'cff7531a935743ae','e3e3aec6e02fb244','60858bfd8b8e3004','4d34dc5d3f82510f',
    '3280fe51e6d6908f','888441af85198d15','6d45012f02fa1e74','005af166900d1b31',
    # model pricing/capability rows: current-turn capability verification rule wins
    'bfe247e4a44377d7','401f9bbad13da3e7','f26e09265e46f43d','5b3c30a9196c5db9',
    '8e8ddf1ab0581b6d','463d0898001c912c','4475ceeba4a2b587',
    # Visual Prompt Forge adapter directory: inventory/navigation, adapters themselves are authority
    'bec3fb13ab78a64b','6e27c44d317fc4ea','39ddb37d997f18ba','2c29a57fa99720a4',
    'f2ee335e88734998','dee9e889f9addd90','7f373644e5eb0d6c','d2acf3208f01c582',
    '3efc36896f6970fa','61345690349997cb',
    # multi-ref limits row is a capability claim; do not make normative without current verification
    'add747662602efad',
    # director example row
    '1abc14dbbffab1eb',
}

def load_jsonl(p: Path):
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--base',required=True)
    ap.add_argument('--blocks',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--audit',required=True)
    a=ap.parse_args()
    rows=load_jsonl(Path(a.base)); blocks={b['block_id']:b for b in json.load(open(a.blocks,encoding='utf-8'))['blocks']}
    ids={r['block_id'] for r in rows}
    missing=(PROMOTE|set(REPRESENTED)|KEEP_NON_NORMATIVE)-ids
    if missing: raise SystemExit(f'unknown audited block ids: {sorted(missing)}')
    out=[]; changed=[]
    for r in rows:
        x=dict(r); bid=x['block_id']
        old=x['status']
        if bid in PROMOTE:
            x['status']='NORMATIVE'
            x['reason']='v3.3 decision-table reaudit: executable routing/process decision; must be compiled before runtime'
        elif bid in REPRESENTED:
            x['status']='NON_NORMATIVE'
            x['reason']=f'v3.3 decision-table reaudit: represented by executable authority {REPRESENTED[bid]}'
            x['represented_by']=REPRESENTED[bid]
        elif bid in KEEP_NON_NORMATIVE:
            x['status']='NON_NORMATIVE'
            x['reason']='v3.3 decision-table reaudit: header/navigation/example/stale capability data; not an independent normative rule'
        if old!=x['status'] or x.get('reason')!=r.get('reason'):
            changed.append({'block_id':bid,'source_path':x['source_path'],'context':x.get('context'),'old':old,'new':x['status'],'text':blocks[bid]['text'],'reason':x['reason']})
        out.append(x)
    Path(a.out).write_text('\n'.join(json.dumps(x,ensure_ascii=False,sort_keys=True) for x in out)+'\n',encoding='utf-8')
    audit={'version':'3.3.0','promoted':len(PROMOTE),'represented':len(REPRESENTED),'explicit_non_normative':len(KEEP_NON_NORMATIVE),'changed':changed,'disposition_counts':dict(Counter(x['status'] for x in out))}
    Path(a.audit).write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DECISION TABLE REAUDIT V3.3: PASS')
    print('promoted',len(PROMOTE),'represented',len(REPRESENTED),'explicit_non_normative',len(KEEP_NON_NORMATIVE))
    print('counts',audit['disposition_counts'])

if __name__=='__main__': main()
