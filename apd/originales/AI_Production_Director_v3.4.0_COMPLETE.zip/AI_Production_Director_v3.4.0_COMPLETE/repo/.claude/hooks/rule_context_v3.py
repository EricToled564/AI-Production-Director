#!/usr/bin/env python3
from __future__ import annotations
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BUILD=Path(__file__).resolve().parents[1]/'rules'/'v3'/'build'

def headings(path:Path):
    stack=[]; out={}
    for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        m=re.match(r'^(#{1,6})\s+(.*)',line)
        if m:
            lvl=len(m.group(1)); title=m.group(2).strip()
            stack=[x for x in stack if x[0]<lvl]; stack.append((lvl,title))
        out[i]=[x[1] for x in stack]
    return out

def main():
    raw=json.load(open(BUILD/'raw_rules.json'))
    cache={}; rows=[]
    for r in raw['rules']:
        p=ROOT/'skills'/r['skill']/r['file']
        key=str(p)
        if key not in cache: cache[key]=headings(p)
        hs=cache[key].get(r['line'],[])
        rows.append({**r,'headings':hs,'context':' > '.join(hs)})
    (BUILD/'raw_rules_with_context.json').write_text(json.dumps({'rules':rows},ensure_ascii=False,indent=2),encoding='utf-8')
    print('rules',len(rows)); print('written',BUILD/'raw_rules_with_context.json')
if __name__=='__main__': main()
