#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
PASS=0; FAIL=0
ok(){ echo "PASS  $1"; PASS=$((PASS+1)); }
bad(){ echo "FAIL  $1"; FAIL=$((FAIL+1)); }
check(){ local msg="$1"; shift; if "$@" >/tmp/apd-v31-check.out 2>&1; then ok "$msg"; else bad "$msg"; cat /tmp/apd-v31-check.out; fi; }

check "source catalog is exactly 274/274 with zero unclassified" python3 - <<'PY'
import json
x=json.load(open('.claude/rules/v3/build/source_catalog.json'))
assert x['inventory_count']==274==len(x['sources']);assert x['unclassified']==[]
PY
check "all 6928 Markdown blocks have final dispositions" python3 - <<'PY'
import json,collections
b=json.load(open('.claude/rules/v3/build/source_blocks.json'))['blocks']
d=[json.loads(l) for l in open('.claude/rules/v3/source-dispositions.final-v3.1.jsonl') if l.strip()]
assert len(b)==6928==len(d);assert len({x['block_id'] for x in d})==6928
assert set(x['status'] for x in d)<= {'NORMATIVE','NON_NORMATIVE','EXAMPLE','STRUCTURE'}
assert sum(x['status']=='NORMATIVE' for x in d)==1649
PY
check "final source disposition audit reports zero suspicious blocks" python3 - <<'PY'
import json
x=json.load(open('.claude/rules/v3/build/source-disposition-audit-v3.1.json'))
# tolerate different audit key names but require no unresolved/suspicious list/count
blob=str(x).lower()
for k,v in x.items():
 if 'suspicious' in k.lower() or 'pending' in k.lower() or 'unresolved' in k.lower():
  if isinstance(v,int): assert v==0,(k,v)
  elif isinstance(v,list): assert len(v)==0,(k,len(v))
PY
check "1649 NORMATIVE blocks map one-to-one to canonical rules" python3 - <<'PY'
import json,collections
r=json.load(open('.claude/rules/v3/build/rules.block-v3.1.json'))['rules']
d={json.loads(l)['block_id']:json.loads(l)['status'] for l in open('.claude/rules/v3/source-dispositions.final-v3.1.jsonl') if l.strip()}
assert len(r)==1649; c=collections.Counter(x['block_id'] for x in r);assert all(v==1 for v in c.values());assert set(c)=={k for k,v in d.items() if v=='NORMATIVE'}
PY
check "1649 rule metadata rows are schema-valid and all CLASSIFIED" python3 - <<'PY'
import json,jsonschema
s=json.load(open('.claude/rules/v3/rule-metadata.schema.json'))
rows=[json.loads(l) for l in open('.claude/rules/v3/rule-metadata.final-v3.1.jsonl') if l.strip()]
assert len(rows)==1649;assert len({x['rule_id'] for x in rows})==1649;assert all(x['classification_status']=='CLASSIFIED' for x in rows)
v=jsonschema.Draft202012Validator(s);assert not [e for x in rows for e in v.iter_errors(x)]
PY
check "no rejected body-keyword scope fields appear" python3 - <<'PY'
import json
bad={'subject.hands_visible','subject.feet_visible','subject.human_contact','physics.water','physics.splash','physics.refraction','subject.product_present','audio.dialogue_required','audio.lipsync'}
def paths(x):
 if isinstance(x,dict):
  if 'path' in x: yield x['path']
  for v in x.values(): yield from paths(v)
 elif isinstance(x,list):
  for v in x: yield from paths(v)
for l in open('.claude/rules/v3/rule-metadata.final-v3.1.jsonl'):
 m=json.loads(l);assert not(set(paths(m['when']))&bad),(m['rule_id'],set(paths(m['when']))&bad)
PY
check "55 executable/config/schema authorities are directly accounted" python3 - <<'PY'
import json
x=json.load(open('.claude/rules/v3/build/direct-authorities-v3.1.json'))
assert x['count']==55;assert x['by_role']=={'EXECUTABLE_VALIDATOR':47,'NORMATIVE_CONFIG':2,'NORMATIVE_METHOD':1,'NORMATIVE_SCHEMA':5}
PY
check "master conflict rules §6.1-§6.5 are all canonical and classified" python3 - <<'PY'
import json
req={'2bdbd8488f44','8b582880dec3','a94663a6fb29','299e96108395','42c21b177cbb'}
r={x['id'] for x in json.load(open('.claude/rules/v3/build/rules.block-v3.1.json'))['rules']}
m={json.loads(l)['rule_id'] for l in open('.claude/rules/v3/rule-metadata.final-v3.1.jsonl') if l.strip()}
assert req<=r and req<=m
PY
check "strict ruleset publication succeeds" python3 .claude/hooks/ruleset_publish_v31.py \
 --source-catalog .claude/rules/v3/build/source_catalog.json \
 --source-blocks .claude/rules/v3/build/source_blocks.json \
 --source-dispositions .claude/rules/v3/source-dispositions.final-v3.1.jsonl \
 --block-rules .claude/rules/v3/build/rules.block-v3.1.json \
 --metadata .claude/rules/v3/rule-metadata.final-v3.1.jsonl \
 --metadata-schema .claude/rules/v3/rule-metadata.schema.json \
 --direct-authorities .claude/rules/v3/build/direct-authorities-v3.1.json \
 --conflicts .claude/rules/v3/conflict-policies.v3.1.json \
 --version 3.1.0 --out .claude/rules/v3/build/ruleset-3.1.0.json
check "published ruleset contains 1649 rules and 55 direct authorities" python3 - <<'PY'
import json
x=json.load(open('.claude/rules/v3/build/ruleset-3.1.0.json'))
assert x['published'] is True;assert x['rule_count']==1649;assert x['direct_authorities']['count']==55
PY
check "invalid Case Fingerprint is blocked before matching" bash -c 'cp examples/cases/express_video_conflict_test.json /tmp/apd-v31-invalid.json; python3 - <<"PY"
import json
p="/tmp/apd-v31-invalid.json";d=json.load(open(p));d["deliverable"]["purpose"]="INVALID";json.dump(d,open(p,"w"),indent=2)
PY
! python3 .claude/hooks/rule_matcher_v3.py --ruleset .claude/rules/v3/build/ruleset-3.1.0.json --case /tmp/apd-v31-invalid.json --out /tmp/apd-v31-invalid-match.json'
check "diver runtime evaluates all 1649 rules with zero unresolved" bash -c 'python3 .claude/hooks/rule_matcher_v3.py --ruleset .claude/rules/v3/build/ruleset-3.1.0.json --case examples/cases/diver_split_level.json --out .claude/rules/v3/build/diver-match-v3.1.json >/dev/null && python3 - <<"PY"
import json
x=json.load(open(".claude/rules/v3/build/diver-match-v3.1.json"));assert x["status"]=="PASS";assert x["counts"]["rules_evaluated"]==1649;assert x["counts"]["unresolved"]==0;assert x["counts"]["unresolved_conflicts"]==0
PY'
check "EXPRESS final-prompt conflicts resolve to APD master rules" bash -c 'python3 .claude/hooks/rule_matcher_v3.py --ruleset .claude/rules/v3/build/ruleset-3.1.0.json --case examples/cases/express_video_conflict_test.json --out .claude/rules/v3/build/express-video-conflict-match-v3.1.json >/dev/null && python3 - <<"PY"
import json
x=json.load(open(".claude/rules/v3/build/express-video-conflict-match-v3.1.json")); c={z["conflict_key"]:z for z in x["conflicts"]};assert c["video.final_prompt.vocabulary_closing"]["winner_rule_id"]=="2bdbd8488f44";assert c["final_prompt.syntax_authority"]["winner_rule_id"]=="8b582880dec3";assert all(z["status"]=="RESOLVED" for z in c.values())
PY'
echo "NOTE  legacy v3 regression suite is intentionally separate: run .claude/hooks/verify_v3.sh"

echo "$PASS passed · $FAIL failed"
test "$FAIL" -eq 0
