#!/usr/bin/env python3
from __future__ import annotations
import json,re
from pathlib import Path
from collections import Counter

HOOKS=Path(__file__).resolve().parent
RULES=HOOKS.parent/'rules'/'v3'
BUILD=RULES/'build'
BASE=RULES/'source-dispositions.reviewed.jsonl'
BLOCKS=BUILD/'source_blocks.json'
CAT=BUILD/'source_catalog.json'
OUT=RULES/'source-dispositions.final-v3.1.jsonl'
REPORT=BUILD/'source-disposition-audit-v3.1.json'

DEON=re.compile(r'(?i)\b(must|shall|required|mandatory|obligatorio|se debe|hay que|never|nunca|do not|don\'t|avoid|forbidden|prohib|always|siempre|should|prefer|recommend|default|only|solo|sólo|source of truth|fuente de verdad|gate|pass|fail|blocked|bloquea|no se entrega|exactly|verbatim|one at a time|max(?:imum)?|minimum|min\.|máximo|mínimo|cannot|can\'t|has to|needs to|include(?:d)? in every|repeat(?:ed)? in every|gana siempre|wins always|veto final|no participa|únicamente)\b')
IMP=re.compile(r'(?i)^(?:[-*+]\s*)?(?:\d+[.)]\s*)?(?:create|keep|use|add|remove|replace|swap|move|choose|describe|specify|include|start|maintain|vary|generate|convert|flatten|turn|design|change|avoid|never|always|ensure|prefer|write|run|validate|check|capture|set|define|preserve|apply|load|read|classify|select|sequence|resolve|trace|do not|don\'t|ask|stop|repeat|document|tag|reserve|surface|pick|follow|translate|usa|usar|mant[eé]n|mantener|crea|crear|incluye|incluir|define|definir|ejecuta|ejecutar|valida|validar|evita|evitar|describe|describir|especifica|especificar|selecciona|seleccionar|clasifica|clasificar|conserva|conservar|aplica|aplicar)\b')
HARD_CTX=re.compile(r'(?i)(reglas de resolución de conflictos|hard rules?|critical rules?|reglas críticas|golden rules?|universal rules?|quality bar|checklist|mandatory reading order|do not write a prompt without this|non-negotiables|pitfalls? to avoid|audit before sending|before delivery|before sending)')
ROUTE_CTX=re.compile(r'(?i)(when to use|cuándo usar|mandatory reading order|workflow > step|routing|selection|decision tree)')
EXAMPLE_CTX=re.compile(r'(?i)(?:^| > )(?:example|examples|worked run|sample output|creative prompt examples|example prompt|ejemplo|ejemplos)(?: >|$)')
EXAMPLE_LINE=re.compile(r'(?i)^(?:[-*+> ]*)?(?:[✓✗✔✘]|good[.:]|bad[.:]|example[.:]|ejemplo[.:]|e\.g\.|["“«].*["”»]|`[^`]+`\s*(?:→|->)|(?:prompt|example|ejemplo)\s*:|>\s*["“«]?.+)')
CAPABILITY=re.compile(r'(?i)\b(supports?|available|up to|pricing|costs?|\$[0-9]|api|endpoint|fps|seconds?|native audio|model version|resolution|slots?|quality modes?|context window)\b')
MODEL_CTX=re.compile(r'(?i)(adapters/|references/(?:models|gpt-image|nano-banana|kling|veo|seedance|seedance-25)\.md)')
META=re.compile(r'(?i)^(?:name|description|license|author|version|source|tags?)\s*:')
ATTRIB=re.compile(r'(?i)(author:|license:|CC BY|attribution required|github\.com/smixs/visual-skills|sergeshima)')

CANON_TEMPLATE='brand-lock-extractor/brand-packs/_template.md'
TEMPLATE_LINES={15,25,33,37,41}


def load_jsonl(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def should_promote(d,b,role):
    text=' '.join(b.get('text','').split()); ctx=d.get('context',''); kind=d['kind']; path=d['source_path']
    if path==CANON_TEMPLATE and d['start_line'] in TEMPLATE_LINES:
        return True,'canonical brand-lock template constraint'
    if role!='NORMATIVE_DOC': return False,''
    if kind in {'heading','frontmatter','code'}: return False,''
    if EXAMPLE_CTX.search(ctx): return False,''
    # explicit prompt/example literals do not become independent rules
    if EXAMPLE_LINE.search(text) and not re.search(r'(?i)\b(gate|must|required|never|do not|only|source of truth)\b',text): return False,''
    # Entire conflict-resolution section is authoritative, including attribution.
    if path=='ai-production-director/SKILL.md' and '6. Reglas de resolución de conflictos' in ctx:
        return True,'director conflict-resolution section is explicitly normative'
    # Explicit Gate labels are requirements even if the block parser called them structure.
    if re.search(r'(?i)\*\*Gate(?::| obligatorio)',text) or re.match(r'(?i)^[-*+]\s*\*\*Gate',text):
        return True,'explicit Gate statement'
    # Hard-rule/checklist contexts: prose/list obligations are rules; table/code examples remain structure.
    if HARD_CTX.search(ctx) and kind in {'paragraph','list_item'}:
        if not EXAMPLE_LINE.search(text): return True,'hard-rule/checklist section'
    # Routing/workflow instructions are process rules when the block itself is imperative/deontic.
    if ROUTE_CTX.search(ctx) and kind in {'paragraph','list_item'} and (DEON.search(text) or IMP.search(text)):
        return True,'routing/workflow instruction'
    # Any explicit obligation/prohibition in a normative doc is a rule, except stale model capability facts.
    if kind in {'paragraph','list_item'} and (DEON.search(text) or IMP.search(text)):
        if MODEL_CTX.search(path) and CAPABILITY.search(text) and not re.search(r'(?i)\b(must|never|do not|don\'t|required|source of truth|fails? the build|set |use |include |omit |prefer |avoid )\b',text):
            return False,''
        if (META.search(text) or ATTRIB.search(text)) and not (path=='ai-production-director/SKILL.md' and '6.5 Atribución' in ctx):
            return False,''
        return True,'explicit obligation/prohibition/instruction'
    return False,''

def should_demote(d,b,role):
    text=' '.join(b.get('text','').split()); ctx=d.get('context',''); kind=d['kind']; path=d['source_path']
    # Non-authoritative source roles cannot create prose rules, except explicit canonical template constraints.
    if role!='NORMATIVE_DOC':
        if path==CANON_TEMPLATE and d['start_line'] in TEMPLATE_LINES: return False,''
        return True,f'source role {role} is not prose-rule authority'
    if EXAMPLE_CTX.search(ctx): return True,'example/sample section'
    if kind=='code' and not re.search(r'(?i)(schema|validator)',ctx): return True,'code/example block represented structurally'
    if (META.search(text) or ATTRIB.search(text)) and not (path=='ai-production-director/SKILL.md' and '6.5 Atribución' in ctx):
        return True,'metadata/attribution outside explicit director attribution rule'
    return False,''

def main():
    base=load_jsonl(BASE)
    blocks={b['block_id']:b for b in json.load(open(BLOCKS,encoding='utf-8'))['blocks']}
    cat=json.load(open(CAT,encoding='utf-8'))
    roles={s['path'].removeprefix('skills/'):s['role'] for s in cat['sources'] if s['path'].startswith('skills/')}
    out=[]; overrides=[]
    for d in base:
        x=dict(d); b=blocks[d['block_id']]; role=roles.get(d['source_path'],'UNCLASSIFIED')
        promote,preason=should_promote(d,b,role)
        demote,dreason=should_demote(d,b,role)
        old=x['status']
        if promote:
            x['status']='NORMATIVE'; x['reason']=f'v3.1 final audit: {preason}'
        elif demote and x['status']=='NORMATIVE':
            # Preserve the most informative non-rule class where possible.
            x['status']='EXAMPLE' if (role=='EXAMPLE' or EXAMPLE_CTX.search(x.get('context',''))) else 'NON_NORMATIVE'
            x['reason']=f'v3.1 final audit: {dreason}'
        # rule_ids are rebuilt in the next compiler; clear stale links now.
        x['rule_ids']=[]
        if x['status']!=old: overrides.append({'block_id':x['block_id'],'source_path':x['source_path'],'line':x['start_line'],'from':old,'to':x['status'],'reason':x['reason']})
        out.append(x)

    # Third-pass suspicious audit: normative docs with explicit obligation language cannot remain silently NON_NORMATIVE/STRUCTURE,
    # unless they are examples, code/table/reference capability or metadata.
    suspicious=[]
    for x in out:
        if x['status']=='NORMATIVE' or x['kind'] in {'heading','frontmatter','code','table_row'}: continue
        role=roles.get(x['source_path'],'UNCLASSIFIED')
        if role!='NORMATIVE_DOC': continue
        b=blocks[x['block_id']]; text=' '.join(b.get('text','').split()); ctx=x.get('context','')
        if EXAMPLE_CTX.search(ctx) or EXAMPLE_LINE.search(text): continue
        if MODEL_CTX.search(x['source_path']) and CAPABILITY.search(text) and not re.search(r'(?i)\b(must|never|do not|don\'t|required|source of truth|fails? the build|set |use |include |omit |prefer |avoid )\b',text): continue
        if (META.search(text) or ATTRIB.search(text)) and not ('6.5 Atribución' in ctx): continue
        if DEON.search(text) or IMP.search(text):
            suspicious.append({'block_id':x['block_id'],'source_path':x['source_path'],'line':x['start_line'],'status':x['status'],'context':ctx,'text':text})

    OUT.write_text('\n'.join(json.dumps(x,ensure_ascii=False,sort_keys=True) for x in out)+'\n',encoding='utf-8')
    report={'counts':dict(Counter(x['status'] for x in out)),'override_count':len(overrides),'overrides':overrides,'suspicious_remaining_count':len(suspicious),'suspicious_remaining':suspicious}
    REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('final block dispositions',report['counts'])
    print('overrides',len(overrides))
    print('suspicious remaining',len(suspicious))
    for s in suspicious[:40]: print('SUSPICIOUS',s['source_path'],s['line'],s['status'],s['text'][:180])
    print('written',OUT)
    print('audit',REPORT)

if __name__=='__main__': main()
