#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re
from pathlib import Path
from collections import Counter, defaultdict

ROOT = Path(__file__).resolve().parents[3]
INDEX = ROOT / 'INDEX.md'
OUT = Path(__file__).resolve().parents[1] / 'rules' / 'v3' / 'build' / 'source_catalog.json'

def sha256(p: Path):
    h=hashlib.sha256();
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20), b''): h.update(b)
    return h.hexdigest()

def inventory():
    text=INDEX.read_text(encoding='utf-8')
    sub=text[text.index('## Inventario completo de archivos'):]
    a=sub.index('```')+3; b=sub.index('```',a)
    return [x.strip() for x in sub[a:b].splitlines() if x.strip()]

def role(path:str):
    p=Path(path); s=path.lower(); name=p.name.lower(); ext=p.suffix.lower()
    # Global/package surfaces
    if path == 'INDEX.md' or path == 'skills-manifest.json': return 'MANIFEST'
    if ext == '.png': return 'BINARY_EXAMPLE'
    if name in {'license','notice'}: return 'LEGAL'
    if s.startswith('repo/notebooklm-corpus/') or s.startswith('repo/nblm-ids/'): return 'DERIVED_CORPUS'
    if s.startswith('repo/api/') or s.startswith('repo/app/') or s.startswith('repo/public/') or path in {'repo/package.json','repo/package-lock.json','repo/vercel.json','repo/VERCEL.md','repo/.mcp.json','repo/.gitignore'}: return 'IMPLEMENTATION'
    if path == 'repo/.claude/settings.json': return 'IMPLEMENTATION_CONFIG'
    if path == 'repo/.claude/rules/METODO.md': return 'NORMATIVE_METHOD'
    if path == 'repo/.claude/rules/scope.yaml': return 'LEGACY_FALLBACK_CONFIG'
    if s.startswith('repo/.claude/hooks/'):
        if name == 'readme.md': return 'TOOL_DOCUMENTATION'
        if name == 'verify.sh': return 'TEST'
        if name == 'schema_v2.sql': return 'IMPLEMENTATION_SCHEMA'
        if name.startswith('gate_') and ext == '.py': return 'EXECUTABLE_VALIDATOR'
        if name in {'rule_answer_check.py','rule_ledger.py'}: return 'EXECUTABLE_VALIDATOR'
        if name in {'inject_rules.py','prompt_detect.py','rule_scope.py','rule_registry.py','rule_export.py','rule_db.py','rules_sqlite.py','nblm_client.py','nblm_import_auth.py','nblm_load.py','export_xlsx.py'}: return 'ENGINE_IMPLEMENTATION'
        return 'ENGINE_IMPLEMENTATION'
    # Skills
    if s.startswith('skills/'):
        if '/examples/' in s: return 'EXAMPLE'
        if '/brand-packs/examples/' in s: return 'EXAMPLE'
        if '/templates/' in s:
            return 'NORMATIVE_SCHEMA' if name.endswith('.schema.json') else 'TEMPLATE'
        if '/tools/' in s:
            if name == 'readme.md': return 'TOOL_DOCUMENTATION'
            if name == 'check.sh': return 'TEST'
            if name.startswith('validate_') and ext == '.py': return 'EXECUTABLE_VALIDATOR'
            return 'TOOL_IMPLEMENTATION'
        if '/scripts/' in s:
            if name == 'prompt_linter.py': return 'EXECUTABLE_VALIDATOR'
            if ext in {'.yaml','.yml','.json'}: return 'NORMATIVE_CONFIG'
            return 'TOOL_IMPLEMENTATION'
        if '/adapters/' in s:
            if name == '_capabilities.json': return 'NORMATIVE_CONFIG'
            if name == 'capabilities.schema.json': return 'NORMATIVE_SCHEMA'
            if ext == '.md': return 'NORMATIVE_DOC'
        if '/brand-packs/' in s:
            if name == '_template.md': return 'TEMPLATE'
            if name == 'readme.md': return 'NORMATIVE_DOC'
        if '/references/' in s and ext == '.md':
            if name in {'skill_update_step5.md','system_prompt_v6_1_rule28.md'}: return 'PROPOSED_DOC'
            return 'NORMATIVE_DOC'
        if name == 'skill.md': return 'NORMATIVE_DOC'
    return 'UNCLASSIFIED'

def main():
    rows=[]
    for path in inventory():
        fp=ROOT/path
        rows.append({'path':path,'role':role(path),'bytes':fp.stat().st_size,'sha256':sha256(fp)})
    byhash=defaultdict(list)
    for r in rows: byhash[r['sha256']].append(r['path'])
    for r in rows:
        g=byhash[r['sha256']]
        r['duplicate_group_size']=len(g)
        r['duplicate_of']=g[0] if len(g)>1 and r['path']!=g[0] else None
    counts=Counter(r['role'] for r in rows)
    out={'inventory_count':len(rows),'role_counts':dict(sorted(counts.items())),'unclassified':[r['path'] for r in rows if r['role']=='UNCLASSIFIED'],'duplicate_content_groups':[v for v in byhash.values() if len(v)>1],'sources':rows}
    OUT.parent.mkdir(parents=True,exist_ok=True); OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('inventory:',len(rows));
    for k,v in sorted(counts.items()): print(f'{k:28} {v}')
    print('unclassified:',len(out['unclassified']))
    print('duplicate groups:',len(out['duplicate_content_groups']))
    print('written:',OUT)
if __name__=='__main__': main()
