#!/usr/bin/env python3
from __future__ import annotations
import json,re,hashlib
from pathlib import Path
from collections import Counter,defaultdict

HOOKS=Path(__file__).resolve().parent
RULES=HOOKS.parent/'rules'/'v3'
BUILD=RULES/'build'
DRAFT=BUILD/'source_disposition_draft.json'
RAW=BUILD/'raw_rules.json'
OUT_DISP=RULES/'source-dispositions.reviewed.jsonl'
OUT_SUP=BUILD/'supplemental_rules.json'
OUT_MERGED=BUILD/'raw_rules.exhaustive.json'

# Contexts that are reference vocabularies/data, not standalone requirements.
REFERENCE_CTX=re.compile(r'(?i)(?:^| > )(?:contents|camera movement|lens language|light sources|light direction|light quality|sound categories|blocking language|transition vocabulary|framing(?: \(|$)|visual styles|layout types|color and lighting vocabulary|camera & hardware|lighting design|model selection|tl;dr|стоимость|размеры|syntax differences|motion vocabulary|shot grammar > (?:framing|angle|motion|depth of field)|genre modules|shot function taxonomy)$')
REFERENCE_ANY=re.compile(r'(?i)\b(contents|vocabulary|glossary|presets?|archetypes?|film stocks?|hardware names|angles:|shot types:|surface properties|visual styles|layout types|cost|pricing|sizes|parameters table|supported|motion vocabulary)\b')
STRUCT_CTX=re.compile(r'(?i)\b(schema|format|template|xml output|json output|output format|metadata fields|field reference|shot card template|prompt template|file structure|directory structure|example output|syntax pattern|parameterized template|five-slot|5-slot)\b')
NORM_CTX=re.compile(r'(?i)\b(hard rules?|critical rules?|reglas críticas|quality bar|checklist|gate|mandatory|obligatorio|required|requirements?|workflow|step \d|process|protocol|validation|validator|invariant|reading order|before sending|before delivery|audit|consistency|lock|failure modes?|pitfalls? to avoid|avoid|best practices?|production rules?|core laws|non-negotiables|universal rules?|golden rules?|rules of use|inputs?|outputs?|routing|selection|decision tree)\b')
HARD_CTX=re.compile(r'(?i)\b(hard rules?|critical rules?|reglas críticas|quality bar|checklist|gate|mandatory|obligatorio|required|requirements?|validation|validator|invariant|before sending|before delivery|audit|core laws|non-negotiables|universal rules?|golden rules?|pitfalls? to avoid|production rules?|rules of use)\b')
PROCESS_CTX=re.compile(r'(?i)\b(workflow|step \d|process|protocol|reading order|inputs?|outputs?|routing|selection|decision tree|when to use|use when)\b')
IMPLICIT_NORM=re.compile(r'(?i)\b(must|shall|required|mandatory|obligatorio|se debe|hay que|never|nunca|do not|don\'t|avoid|forbidden|prohib|always|siempre|should|prefer|recommend|default|only|solo|sólo|source of truth|fuente de verdad|gate|pass|fail|blocked|bloquea|no se entrega|exactly|verbatim|one at a time|max(?:imum)?|minimum|min\.|máximo|mínimo|ask the user|stop and tell|fails? the build|keep .* same|matches if specified|needs to|has to|cannot|can\'t|include(?:d)? in every|repeat(?:ed)? in every|appears? in every|flows? into every|every [^.]{0,80}(?:traces|inherits|appears|flows|uses|gets|must|has to))\b')
IMPERATIVE=re.compile(r'(?i)^(?:[-*+]\s*)?(?:\d+[.)]\s*)?(?:create|keep|use|add|remove|replace|swap|move|choose|describe|specify|include|start|maintain|vary|generate|convert|flatten|turn|design|change|avoid|never|always|ensure|prefer|write|run|validate|check|capture|set|define|preserve|apply|load|read|classify|select|sequence|resolve|trace|do not|don\'t|ask|stop|repeat|document|tag|reserve|surface|pick|follow|translate|usa|usar|mant[eé]n|mantener|crea|crear|incluye|incluir|define|definir|ejecuta|ejecutar|valida|validar|evita|evitar|describe|describir|especifica|especificar|selecciona|seleccionar|clasifica|clasificar|conserva|conservar|aplica|aplicar)\b')
# Explicitly structural/table-label fragments that are not propositions.
LABELISH=re.compile(r'(?i)^(?:[\w /+&().-]{1,45}|(?:input|position|code|effect|use when|field|type|category|value|parameter)\s*\|.*)$')
META_LINE=re.compile(r'(?i)^(?:name|description|license|author|version|source|tags?)\s*:')
LICENSE_LINE=re.compile(r'(?i)(?:\*?author:|license:|CC BY|attribution required|github\.com/smixs/visual-skills|sergeshima)')
EXAMPLE_LINE=re.compile(r'(?i)^(?:(?:[-*+>]\s*)?)(?:[✓✗✔✘]|good[.:]|bad[.:]|example[.:]|ejemplo[.:]|e\.g\.|["“«].*["”»]|`[^`]+`\s*(?:→|->)|(?:prompt|example|ejemplo)\s*:|[>]?\s*["“«].+)')
CAPABILITY_LINE=re.compile(r'(?i)\b(?:supports?|available|up to|max(?:imum)?|minimum|costs?|pricing|\$[0-9]|fps|seconds?|refs?|reference images?|resolution|native(?: synchronized)? audio|audio|lip[- ]?sync|dialogue|music|model version|api|endpoint|context window|slots?|cfg_scale|duration|quality modes?)\b')
MODEL_PREFIX=re.compile(r'(?i)^(?:[-*+]\s*)?(?:Kling|Veo|Seedance|Nano Banana|GPT Image|Flux|Midjourney|Ideogram|Sora|Hailuo|Runway|Luma|Pika)\b')
BOLD_FIELD=re.compile(r'(?i)^(?:[-*+]\s*)?\*\*[^*]{1,60}:\*\*')
BOLD_DASH=re.compile(r'(?i)^(?:[-*+]\s*)?\*\*[^*]{1,80}\*\*\s*[—–-]')
FIELDISH=re.compile(r'(?i)^(?:[-*+]\s*)?(?:`[^`]+`|\*\*[^*]+\*\*|[A-Za-z][A-Za-z0-9_ /+-]{1,40}|Shot\s+\d+(?:-\d+)?)\s*[:|]')
CODE_BULLET=re.compile(r'^(?:[-*+]\s*)?`[^`]+`')
SHORT_VOCAB=re.compile(r'(?i)^(?:[-*+]\s*)?(?:\d{2,3}mm|ECU|CU|MCU|MS|WS|EWS|OTS|POV)\b')

# Source/path-specific sections known to be reference data even if their headings contain broad words.
REFERENCE_PATHS={
 'image/references/creative-direction.md','image/references/models.md','image/references/dimensional.md',
 'video/references/camera-lighting-vocabulary.md','storyboard-architect/references/shot-grammar.md',
}

def stable_id(b):
    raw=f"sourceblock-v3|{b['source_path']}|{b['start_line']}|{b['end_line']}|{b.get('text','')}".encode()
    return hashlib.sha256(raw).hexdigest()[:12]

def source_skill(path): return path.split('/',1)[0]

def disposition(c):
    text=' '.join(c.get('text','').split()); ctx=c.get('context',''); kind=c['kind']; path=c['source_path']
    # Metadata/legal/attribution inside source docs is accounted for as source metadata, never a production rule.
    if META_LINE.search(text) or LICENSE_LINE.search(text): return 'NON_NORMATIVE','source metadata/license/attribution'
    if re.search(r'(?i)\b(example|examples|worked run|sample output|creative prompt examples|example prompt)\b',ctx): return 'EXAMPLE','example/sample context'
    # Explicit example rows/quoted prompt snippets.
    if EXAMPLE_LINE.search(text) and not re.search(r'(?i)\b(checklist|hard rules?|quality bar|gate)\b',ctx): return 'EXAMPLE','example/prompt snippet'
    # Labeled parameter/anatomy fields are structural decomposition, unless explicitly inside a checklist/hard-rule section.
    if BOLD_FIELD.search(text) and not re.search(r'(?i)\b(checklist|quality bar|hard rules?|core laws|non-negotiables|gate)\b',ctx): return 'STRUCTURE','labeled parameter/field definition'
    if BOLD_DASH.search(text) and not re.search(r'(?i)\b(checklist|quality bar|hard rules?|core laws|non-negotiables|gate)\b',ctx): return 'STRUCTURE','labeled reference/parameter decomposition item'
    if FIELDISH.search(text) and not re.search(r'(?i)\b(checklist|quality bar|hard rules?|core laws|non-negotiables|gate|rules of use)\b',ctx): return 'STRUCTURE','field/timeline/shot label or structured mapping'
    if CODE_BULLET.search(text) and not re.search(r'(?i)\b(checklist|quality bar|hard rules?|gate)\b',ctx): return ('STRUCTURE','code/file/parameter item') if STRUCT_CTX.search(ctx) or re.search(r'(?i)\b(input|output|adapter|parameter|format)\b',ctx) else ('EXAMPLE','literal/example item')
    # Code in template/schema/format contexts is structural contract, not a prose proposition.
    if kind=='code':
        if STRUCT_CTX.search(ctx) or re.search(r'(?i)\b(template|format|schema|syntax|output|xml|json)\b',ctx): return 'STRUCTURE','code/template/schema structure'
        return 'EXAMPLE','code block/example structure'
    # Tables are data/structure. Their governing rule is the surrounding prose or executable schema/validator.
    if kind=='table_row':
        return 'STRUCTURE' if STRUCT_CTX.search(ctx) or re.search(r'(?i)\b(check|rubric|input|output|field|metadata|timing|framework|position|shot card)\b',ctx) else 'NON_NORMATIVE','table/reference data represented by surrounding rule/config'
    # Labels/glossary fragments.
    explicit=bool(IMPLICIT_NORM.search(text) or IMPERATIVE.search(text))
    if LABELISH.match(text) and not explicit:
        return 'STRUCTURE' if STRUCT_CTX.search(ctx) else 'NON_NORMATIVE','label/glossary fragment'
    # Model/capability facts are reference data unless they are explicit prompt/process instructions.
    model_ref=bool(re.search(r'(?i)(?:references/(?:models|gpt-image|nano-banana|kling|veo|seedance|seedance-25)\.md|adapters/)',path))
    if MODEL_PREFIX.search(re.sub(r'^[-*+]\s*','',text)) and CAPABILITY_LINE.search(text) and not IMPERATIVE.search(text) and not re.search(r'(?i)\b(must|never|do not|don\'t|required|source of truth|wins|fails? the build)\b',text): return 'NON_NORMATIVE','time-sensitive model capability fact; verify at execution time'
    imperative=bool(IMPERATIVE.search(text))
    if model_ref and CAPABILITY_LINE.search(text) and not imperative and not re.search(r'(?i)\b(must|never|do not|don\'t|required|source of truth|wins|fails? the build)\b',text):
        return 'NON_NORMATIVE','time-sensitive model capability/reference fact; not a permanent normative rule'
    if CAPABILITY_LINE.search(text) and re.search(r'(?i)\b(Kling|Veo|Seedance|Nano Banana|GPT Image|Flux|Midjourney|Ideogram|Sora|Hailuo|Runway|Luma|Pika)\b',text) and not imperative and not re.search(r'(?i)\b(must|never|do not|don\'t|required|source of truth|wins|fails? the build)\b',text): return 'NON_NORMATIVE','time-sensitive model capability/reference fact'
    if re.search(r'(?i)\bdefault splits?\b',ctx): return 'STRUCTURE','duration/clip split reference table/list'
    # Structural field lists.
    if STRUCT_CTX.search(ctx) and not explicit:
        return 'STRUCTURE','schema/template/field structure'
    if SHORT_VOCAB.search(text) and not imperative: return 'NON_NORMATIVE','camera/lens vocabulary fragment'
    if re.search(r'(?i)\bfailure modes?|failure \d',ctx) and not explicit: return 'NON_NORMATIVE','diagnostic symptom/cause list; actionable rule lives in explicit fix instruction'
    # Known reference vocab sources: only actual instructions are rules.
    if path in REFERENCE_PATHS or REFERENCE_ANY.search(ctx):
        if imperative or re.search(r'(?i)\b(must|never|do not|don\'t|required|only|default to|prefer|avoid)\b',text): return 'NORMATIVE','explicit instruction embedded in reference data'
        return 'NON_NORMATIVE','reference vocabulary/descriptive data'
    # Hard gates/checklists/quality bars are contracts even when phrased as terse checklist fragments.
    if HARD_CTX.search(ctx):
        return 'NORMATIVE','implicit requirement in hard gate/checklist/quality context'
    # Workflow/input/output sections contain both instructions and mere structural inventories.
    if PROCESS_CTX.search(ctx):
        if explicit or imperative or re.search(r'(?i)\bwhen to use|use when|cuando usar|cuándo usar\b',ctx) or (('→' in text or '->' in text) and '.md' in text):
            return 'NORMATIVE','process/routing instruction'
        return 'STRUCTURE','workflow/input/output structural or descriptive item'
    # Explicit normative language in current normative docs.
    if explicit: return 'NORMATIVE','explicit implicit normative statement missed by legacy extractor'
    if re.search(r'(?i)\bwhen to use|use when|cuando usar|cuándo usar\b',ctx+' '+text): return 'NORMATIVE','conditional selection guidance'
    return 'NON_NORMATIVE','descriptive/reference prose; no standalone obligation'

def main():
    draft=json.load(open(DRAFT,encoding='utf-8'))
    raw=json.load(open(RAW,encoding='utf-8'))
    block_inv=json.load(open(BUILD/'source_blocks.json',encoding='utf-8'))
    block_by_id={b['block_id']:b for b in block_inv['blocks']}
    catalog=json.load(open(BUILD/'source_catalog.json',encoding='utf-8'))
    roles={x['path']:x['role'] for x in catalog['sources']}
    records=[]; sup=[]; counts=Counter(); seen=set(r['id'] for r in raw['rules'])
    candidate={r['block_id']:r for r in draft['review_required']}
    for rec in draft['records']:
        rec=dict(rec)
        role=roles.get('skills/'+rec['source_path'],'UNCLASSIFIED')
        reconsider = rec['status']=='REVIEW_REQUIRED' or (rec['status']=='NON_NORMATIVE' and role=='NORMATIVE_DOC' and rec['kind'] in {'paragraph','list_item','table_row','code'})
        if reconsider:
            base=block_by_id[rec['block_id']]
            c={**rec,'text':base.get('text','')}
            st,reason=disposition(c)
            rec['status']=st;rec['reason']='exhaustive_review_v3: '+reason
            if st=='NORMATIVE':
                rid=stable_id(c)
                # Extremely unlikely collision; fail closed.
                if rid in seen: raise SystemExit(f'supplemental rule id collision {rid}')
                seen.add(rid);rec['rule_ids']=[rid]
                sup.append({
                    'id':rid,'legacy_id':None,'skill':source_skill(c['source_path']),'file':c['source_path'].split('/',1)[1],
                    'source_path':c['source_path'],'line':c['start_line'],'end_line':c['end_line'],
                    'markers':['source_block_normative'],'text':' '.join(c['text'].split()),
                    'source_sha256':None,
                })
            else: rec['rule_ids']=[]
        records.append(rec);counts[rec['status']]+=1
    pending=[r for r in records if r['status'] not in {'NORMATIVE','NON_NORMATIVE','EXAMPLE','STRUCTURE'}]
    if pending: raise SystemExit(f'pending source blocks: {len(pending)}')
    OUT_DISP.write_text('\n'.join(json.dumps(r,ensure_ascii=False,sort_keys=True) for r in records)+'\n',encoding='utf-8')
    OUT_SUP.write_text(json.dumps({'count':len(sup),'rules':sup},ensure_ascii=False,indent=2),encoding='utf-8')
    merged=dict(raw); merged['rules']=raw['rules']+sup; merged['rules'].sort(key=lambda r:(r['skill'],r['file'],r['line'],r['id']))
    merged.setdefault('manifest',{})['legacy_extracted_rule_count']=len(raw['rules'])
    merged['manifest']['supplemental_source_block_rules']=len(sup)
    merged['manifest']['exhaustive_rule_count']=len(merged['rules'])
    OUT_MERGED.write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding='utf-8')
    print('source dispositions',dict(counts))
    print('supplemental normative rules',len(sup))
    print('merged rule count',len(merged['rules']))
    print('pending',len(pending))
    by=Counter(r['skill'] for r in sup)
    print('supplemental by skill',dict(sorted(by.items())))

if __name__=='__main__':main()
