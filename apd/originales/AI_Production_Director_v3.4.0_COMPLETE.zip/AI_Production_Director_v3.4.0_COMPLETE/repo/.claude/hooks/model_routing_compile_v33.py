#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path

# This is the ONE-TIME machine-readable classification of the canonical model-selection table.
# Runtime never reads models.md. Each entry is pinned to a canonical source block/rule.
ROUTE_SPECS = [
  ('0e362870b5d75e65','requires_real_world_grounding','DECISIVE',750,[{'family':'nano_banana','model':'nano-banana-pro'},{'family':'nano_banana','model':'nano-banana-2'}]),
  ('e8b13f2f6cc8387b','complex_scene_physics_composition','DECISIVE',800,[{'family':'nano_banana','model':'nano-banana-pro'}]),
  ('1fbbc8fe5deef52b','extreme_aspect_ratio','DECISIVE',790,[{'family':'nano_banana','model':'nano-banana-pro'},{'family':'nano_banana','model':'nano-banana-2'}]),
  ('b4ee98784817c8fa','bulk_low_cost','CHOICE',700,[{'family':'nano_banana','model':'nano-banana-2-lite'},{'family':'gpt_image','model':'gpt-image-1-mini'}]),
  ('b02ac5f1bb22eb91','photographic_fine_typography_ui','DECISIVE',830,[{'family':'gpt_image','model':'gpt-image-2'}]),
  ('4d576e3f68d39519','exact_edit_preservation','DECISIVE',850,[{'family':'gpt_image','model':'gpt-image-2'}]),
  ('873706bd2095485c','dense_small_text','DECISIVE',845,[{'family':'gpt_image','model':'gpt-image-2','quality':'high'}]),
  ('3a7cdc153ba8c77d','brand_print_exact_text','DECISIVE',840,[{'family':'gpt_image','model':'gpt-image-2'}]),
  ('62180a687593b7d9','storyboard_sequence','DECISIVE',770,[{'family':'nano_banana','model':'nano-banana-pro'},{'family':'nano_banana','model':'nano-banana-2'}]),
  ('4d8e3458b579dbfa','storyboard_typography','DECISIVE',835,[{'family':'gpt_image','model':'gpt-image-2'}]),
  ('976f411cc0253223','style_transfer_without_refs','DECISIVE',760,[{'family':'gpt_image','model':'gpt-image-2'}]),
  ('25df7f065b3e12c8','many_references_14_plus','CHOICE',740,[{'family':'nano_banana','model':'nano-banana-pro'},{'family':'gpt_image','model':'gpt-image-2'}]),
]
NEUTRAL = [
  ('b93217eb3ad730fc','photographic_portrait'),('a4946c5fc4aee393','neutral_product_shot'),
  ('fc9c06d3af04b42c','minimalist_poster'),('fcdfe3fbf2d0a1e2','editorial_photography')
]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--rules',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    rules=json.load(open(a.rules,encoding='utf-8'))['rules']; by_block={r['block_id']:r for r in rules}
    missing=[bid for bid,*_ in ROUTE_SPECS+[(x,y,None,None,None) for x,y in NEUTRAL] if bid not in by_block]
    if missing: raise SystemExit(f'model-selection source blocks not canonical: {missing}')
    routes=[]
    for bid,feature,kind,priority,candidates in ROUTE_SPECS:
        r=by_block[bid]
        routes.append({'id':f'kb_model_{feature}','source_rule_id':r['id'],'source_block_id':bid,'source_path':r['source_path'],'source_text':r['text'],'feature':feature,'kind':kind,'priority':priority,'candidates':candidates})
    neutral=[]
    for bid,feature in NEUTRAL:
        r=by_block[bid]
        neutral.append({'id':f'kb_model_neutral_{feature}','source_rule_id':r['id'],'source_block_id':bid,'source_path':r['source_path'],'source_text':r['text'],'feature':feature,'kind':'NEUTRAL','priority':100,'candidates':[{'family':'nano_banana','model':'nano-banana-pro'},{'family':'gpt_image','model':'gpt-image-2'}]})
    out={'version':'3.3.0','authority':'KB_CANONICAL_COMPILED','runtime_source_reads_forbidden':True,'routes':routes,'neutral_routes':neutral}
    Path(a.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('MODEL ROUTING COMPILE V3.3: PASS'); print('decisive/choice',len(routes),'neutral',len(neutral)); print('written',a.out)
if __name__=='__main__': main()
