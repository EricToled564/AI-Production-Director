#!/usr/bin/env python3
"""Report one-time KB classification progress against the raw registry."""
from __future__ import annotations
import argparse, json
from collections import Counter
from pathlib import Path
from rule_engine_v3 import load_jsonl


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--raw-rules',required=True); ap.add_argument('--metadata',required=True); ap.add_argument('--json',action='store_true'); a=ap.parse_args()
    raw=json.loads(Path(a.raw_rules).read_text(encoding='utf-8'))
    rules={r['id']:r for r in raw['rules']}; rows=load_jsonl(Path(a.metadata)); meta={r['rule_id']:r for r in rows}
    c=Counter(meta.get(rid,{}).get('classification_status','MISSING') for rid in rules)
    stale=sorted(set(meta)-set(rules))
    by_skill={}
    for rid,r in rules.items():
        st=meta.get(rid,{}).get('classification_status','MISSING')
        x=by_skill.setdefault(r['skill'],Counter()); x[st]+=1; x['TOTAL']+=1
    result={'total':len(rules),'status_counts':dict(c),'stale':len(stale),'by_skill':{k:dict(v) for k,v in sorted(by_skill.items())}}
    if a.json: print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    print('KB CLASSIFICATION STATUS')
    print(f"  total rules      {len(rules)}")
    for k in ['CLASSIFIED','NON_NORMATIVE','NEEDS_REVIEW','LEGACY','MISSING']:
        if c[k]: print(f"  {k:16} {c[k]}")
    print(f"  stale metadata   {len(stale)}")
    print('\n  by skill:')
    for skill,x in sorted(by_skill.items()):
        done=x['CLASSIFIED']+x['NON_NORMATIVE']
        print(f"    {skill:28} {done:4}/{x['TOTAL']:<4} reviewed")
    return 0
if __name__=='__main__': raise SystemExit(main())
