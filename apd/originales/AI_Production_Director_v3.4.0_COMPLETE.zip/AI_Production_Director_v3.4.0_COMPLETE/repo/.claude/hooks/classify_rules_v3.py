#!/usr/bin/env python3
from __future__ import annotations
import json,re
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[3]
BUILD=Path(__file__).resolve().parents[1]/'rules'/'v3'/'build'
OUT=Path(__file__).resolve().parents[1]/'rules'/'v3'/'rule-metadata.autoclassified.jsonl'

def leaf(path,op,value=None):
    x={'path':path,'op':op}
    if op not in {'truthy','falsy','exists'} or value is not None: x['value']=value
    return x

def all_(*xs):
    ys=[]
    for x in xs:
        if not x: continue
        if 'all' in x and len(x)==1: ys.extend(x['all'])
        else: ys.append(x)
    if not ys:return {}
    return ys[0] if len(ys)==1 else {'all':ys}

def any_(*xs):
    ys=[x for x in xs if x]
    if not ys:return {}
    return ys[0] if len(ys)==1 else {'any':ys}

def add(c,x): return all_(c,x)

def stage_from_context(skill,ctx):
    lc=ctx.lower()
    if skill=='ai-production-director':
        if 'etapa 0' in lc: return leaf('stage','eq','brief')
        if 'etapa 1' in lc: return leaf('stage','eq','strategy')
        if 'etapa 2' in lc: return leaf('stage','in',['script','scene'])
        if 'etapa 3' in lc: return leaf('stage','in',['scene','shot'])
        if 'etapa 4' in lc: return leaf('stage','in',['storyboard','shot'])
        if 'etapa 5' in lc: return leaf('stage','in',['asset','prompt','generation','qa'])
        if 'etapa 6' in lc: return all_(leaf('stage','in',['prompt','generation']),leaf('media','eq','video'))
        if 'etapa 7' in lc: return leaf('stage','eq','delivery')
    return {}

def base_scope(r):
    s=r['skill']; f=r['file'].lower(); ctx=r.get('context','').lower(); t=r['text'].lower()
    authority='SKILL'; priority=500; c={}
    # pipeline/source-level routing
    if s=='ai-production-director':
        authority='PIPELINE'; priority=800; c=stage_from_context(s,ctx)
        if f.endswith('references/creative-strategy.md'): c=leaf('stage','eq','strategy')
        if f.endswith('references/production-package.md'): c=leaf('stage','eq','delivery')
    elif s=='produccion-visual-sw30':
        authority='PIPELINE'; priority=780; c=all_(leaf('media','in',['image','video']),leaf('stage','in',['asset','prompt','generation','qa']))
    elif s=='ai-video-storyboard':
        c=all_(leaf('media','eq','video'),leaf('stage','in',['storyboard','shot']),leaf('pipeline_track','eq','EXPRESS'))
    elif s=='aurora-prompt-linter':
        authority='PIPELINE'; priority=770; c=all_(leaf('media','in',['image','video']),leaf('stage','eq','prompt'))
    elif s=='brand-lock-extractor':
        c=any_(leaf('operation','eq','brand_extract'),leaf('stage','eq','brief'),leaf('brand.mode','not_in',['none']))
    elif s=='image':
        c=all_(leaf('media','eq','image'),leaf('stage','eq','prompt'))
        if f=='references/gpt-image.md': c=add(c,leaf('generator.family','eq','gpt_image')); authority='MODEL_ADAPTER'; priority=560
        elif f=='references/nano-banana.md': c=add(c,leaf('generator.family','eq','nano_banana')); authority='MODEL_ADAPTER'; priority=560
        elif f=='references/characters.md': c=add(c,any_(leaf('subject.identity_fidelity','in',['consistent','exact']),leaf('subject.recurring_character','eq',True),leaf('references.identity_reference','eq',True)))
        elif f=='references/dimensional.md': c=add(c,leaf('task.family','eq','dimensional'))
        elif f=='references/editing.md': c=add(c,leaf('operation','in',['image_edit','image_to_image']))
        elif f=='references/multi-panel.md': c=add(c,leaf('task.family','eq','multi_panel'))
        elif 'patterns/character-design.md' in f: c=add(c,leaf('task.family','eq','character_design')); authority='GUIDELINE'; priority=360
        elif 'patterns/ecommerce.md' in f: c=add(c,leaf('task.family','eq','ecommerce')); authority='GUIDELINE'; priority=360
        elif 'patterns/fashion-editorial.md' in f: c=add(c,leaf('task.family','eq','fashion_editorial')); authority='GUIDELINE'; priority=360
        elif 'patterns/food-beverage.md' in f: c=add(c,leaf('task.family','eq','food_beverage')); authority='GUIDELINE'; priority=360
        elif 'patterns/portrait-cinema.md' in f: c=add(c,leaf('task.family','eq','portrait')); authority='GUIDELINE'; priority=360
        elif 'patterns/poster-illustration.md' in f: c=add(c,leaf('task.family','eq','poster_illustration')); authority='GUIDELINE'; priority=360
        elif 'patterns/ui-social.md' in f: c=add(c,leaf('task.family','eq','ui_social')); authority='GUIDELINE'; priority=360
        elif f=='references/slides.md': c=add(c,leaf('task.family','eq','presentation_slide'))
        elif f=='references/storyboards.md': c=add(c,leaf('task.family','eq','storyboard'))
        elif f=='references/structural.md': c=add(c,leaf('task.tags','contains','STRUCTURAL_INPUT'))
        elif f=='references/text-rendering.md': c=add(c,any_(leaf('task.family','eq','text_rendering'),leaf('text.mode','not_in',['none'])))
        elif f=='references/vision-decomposer.md': c=all_(leaf('media','eq','image'),leaf('operation','eq','reference_analysis'))
    elif s=='screenwriter':
        c=all_(leaf('media','in',['text','mixed','video']),leaf('stage','in',['script','scene']))
    elif s=='storyboard-architect':
        c=leaf('stage','in',['storyboard','shot'])
    elif s=='storyboard-html-preview':
        c=leaf('stage','eq','delivery')
    elif s=='video':
        c=all_(leaf('media','eq','video'),leaf('stage','in',['scene','shot','prompt','qa']))
        if f=='references/kling.md': c=add(c,leaf('generator.family','eq','kling')); authority='MODEL_ADAPTER'; priority=560
        elif f=='references/veo.md': c=add(c,leaf('generator.family','eq','veo')); authority='MODEL_ADAPTER'; priority=560
        elif f=='references/seedance.md': c=add(c,leaf('generator.family','eq','seedance')); authority='MODEL_ADAPTER'; priority=550
        elif f=='references/seedance-25.md': c=all_(c,leaf('generator.family','eq','seedance'),leaf('generator.model','regex',r'2[.]5')); authority='MODEL_ADAPTER'; priority=570
        elif f=='references/animatic-keyframes.md': c=all_(leaf('media','eq','video'),leaf('stage','in',['storyboard','shot','asset']))
        elif f=='references/race-and-speed.md': c=add(c,leaf('task.family','eq','race_speed'))
        elif f=='references/fixes-and-skeletons.md': c=all_(leaf('media','eq','video'),leaf('stage','in',['prompt','qa']))
        elif f=='references/patterns-and-genres.md': authority='GUIDELINE'; priority=360
        elif f=='references/camera-lighting-vocabulary.md': authority='GUIDELINE'; priority=330
    elif s=='visual-asset-critic':
        c=leaf('stage','eq','qa')
    elif s=='visual-media':
        c=all_(leaf('task.family','eq','animation'),leaf('media','in',['image','video','mixed']))
    elif s=='visual-prompt-forge':
        c=leaf('stage','eq','prompt')
        if f.startswith('adapters/'):
            fam=Path(f).stem.replace('gpt-image','gpt_image').replace('nano-banana','nano_banana')
            c=all_(c,leaf('generator.family','eq',fam)); authority='MODEL_ADAPTER'; priority=550
        elif f=='references/consistency-locks.md': c=all_(leaf('stage','eq','prompt'),leaf('continuity.level','not_in',['none']))
        elif f=='references/failure-modes.md': c=leaf('stage','in',['prompt','qa'])
    return c,authority,priority

def refine(r,c):
    t=(r['text']+' '+r.get('context','')).lower(); reasons=[]
    def A(x,why):
        nonlocal c; c=add(c,x); reasons.append(why)
    # exact case/model/task refinements
    if re.search(r'\bt1\b|maestro de rostro|master face|face master',t): A(leaf('base_type','eq','T1'),'T1/face-master text')
    elif re.search(r'\bt2\b|maestro de cuerpo|body master',t): A(leaf('base_type','eq','T2'),'T2/body-master text')
    elif re.search(r'\bt3\b',t): A(leaf('base_type','eq','T3'),'T3 text')
    elif re.search(r'\bt4\b',t): A(leaf('base_type','eq','T4'),'T4 text')
    elif re.search(r'\bt5\b|edici[oó]n quir[úu]rgica|surgical edit',t): A(leaf('base_type','eq','T5'),'T5/surgical edit text')
    if re.search(r'\b(two|2|dos) (?:people|persons|characters|personas|personajes)\b|multi-person|multi person',t): A(leaf('subject.count','gte',2),'multi-person text')
    if re.search(r'\bhand|hands|mano|manos\b',t): A(leaf('subject.hands_visible','eq',True),'hands text')
    if re.search(r'\bfeet|foot|toe|toes|pie|pies\b',t): A(leaf('subject.feet_visible','eq',True),'feet text')
    if re.search(r'\bidentity|identidad|same person|same face|character consistency|face preservation\b',t): A(leaf('subject.identity_fidelity','in',['consistent','exact']),'identity text')
    if re.search(r'\bcontact|high five|hug|touch|interaction between people\b',t): A(leaf('subject.human_contact','eq',True),'human-contact text')
    if re.search(r'\bproduct|producto\b',t) and r['skill']=='image': A(leaf('subject.product_present','eq',True),'product text')
    if re.search(r'\btext|typograph|lettering|caption|subtitle|copy\b',t) and r['skill'] in {'image','visual-prompt-forge'}: A(leaf('text.mode','not_in',['none']),'text-rendering text')
    if re.search(r'\blogo|brand mark|marca\b',t): A(leaf('brand.mode','not_in',['none']),'brand/logo text')
    if re.search(r'\breference|ref image|cref|sref|@img|image reference\b',t) and r['skill'] in {'image','visual-prompt-forge','video','aurora-prompt-linter'}: A(leaf('references.mode','not_in',['none']),'reference text')
    if re.search(r'\bedit|editing|replace|remove|swap|preserve\b',t) and r['skill']=='image': A(leaf('operation','in',['image_edit','image_to_image']),'image-edit text')
    if re.search(r'\bdialogue|dialog|lip[- ]?sync|speaker|voice line\b',t): A(leaf('audio.dialogue_required','eq',True),'dialogue text')
    if re.search(r'\blip[- ]?sync\b',t): A(leaf('audio.lipsync','eq',True),'lipsync text')
    if re.search(r'\bmulti[- ]shot|multiple shots|3 × 5s clips|shot sequence\b',t): A(leaf('sequence.multi_shot','eq',True),'multi-shot text')
    if re.search(r'\bstart frame|first frame|ff\b',t): A(leaf('sequence.start_frame_ref','eq',True),'start-frame text')
    if re.search(r'\bend frame|last frame|lf\b',t): A(leaf('sequence.end_frame_ref','eq',True),'end-frame text')
    if re.search(r'\bmotion reference|motion control\b',t): A(leaf('sequence.motion_reference','eq',True),'motion-reference text')
    if re.search(r'\bstill|static image|imagen fija|instante congelado|frozen\b',t) and r['skill'] in {'image','produccion-visual-sw30'}: A(leaf('motion.static_frame','eq',True),'static/frozen text')
    if re.search(r'\bwater|splash|bubble|turbulence|refraction\b',t):
        if 'water' in t: A(leaf('physics.water','eq',True),'water text')
    # aurora protocol cases
    m=re.search(r'\bcase\s*(3a|3b|3c|1|2|4)\b|\bcaso\s*(3a|3b|3c|1|2|4)\b',t)
    if m:
        val=next(x for x in m.groups() if x); A(leaf('prompt_case','eq',val),f'prompt case {val}')
    # track refs
    if 'express' in t and r['skill'] in {'ai-production-director','ai-video-storyboard'}: A(leaf('pipeline_track','eq','EXPRESS'),'EXPRESS track text')
    if 'standard' in t and r['skill']=='ai-production-director': A(leaf('pipeline_track','eq','STANDARD'),'STANDARD track text')
    if re.search(r'\bfilm\b',t) and r['skill']=='ai-production-director': A(leaf('pipeline_track','eq','FILM'),'FILM track text')
    # model-version sections
    if r['skill']=='video' and r['file']=='references/kling.md':
        if 'kling 3.0' in r.get('context','').lower(): A(leaf('generator.model','regex',r'3[.]0'),'Kling 3.0 section')
        elif re.search(r'1\.x\s*[–-]\s*2\.x',r.get('context',''),re.I): A(leaf('generator.model','regex',r'^(1|2)[.]'),'Kling 1.x-2.x section')
    return c,reasons

def effect_for(r):
    m=set(r.get('markers',[])); t=r['text'].lower(); ctx=r.get('context','').lower()
    if 'good_example' in m or 'bad_example' in m: return 'NONE','example_marker'
    if 'prohibition' in m: return 'FORBID','prohibition marker'
    if 'obligation' in m: return 'REQUIRE','obligation marker'
    if 'recommendation' in m: return 'RECOMMEND','recommendation marker'
    if 'numbered_rule' in m:
        if r['skill'] in {'produccion-visual-sw30','ai-production-director'}: return 'REQUIRE','numbered pipeline rule'
        return 'PROCESS','numbered procedural/reference rule'
    return 'RECOMMEND','fallback'

def main():
    raw=json.load(open(BUILD/'raw_rules_with_context.json'))['rules']
    cat=json.load(open(BUILD/'source_catalog.json'))
    roles={r['path']:r['role'] for r in cat['sources']}
    now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    rows=[]; st=Counter(); byskill=defaultdict(Counter); review=[]
    for r in raw:
        src='skills/'+r['source_path']; role=roles.get(src,'UNCLASSIFIED')
        c,auth,prio=base_scope(r); c,why=refine(r,c); effect,effwhy=effect_for(r)
        status='CLASSIFIED'; notes=[]
        if role=='EXAMPLE': status='NON_NORMATIVE'; auth='EXAMPLE'; effect='NONE'; c={}; notes.append('Source is an example fixture.')
        elif role=='PROPOSED_DOC': status='NON_NORMATIVE'; auth='LEGACY'; effect='NONE'; c={}; notes.append('Proposal not approved as current authority.')
        elif effect=='NONE': status='NON_NORMATIVE'; notes.append('Good/bad example marker, not a standalone rule.')
        # Conservative review flags: conditional prose not captured by a known condition.
        conditional=bool(re.search(r'(?i)\b(if|when|whenever|unless|only when|only if|except|for .*? only|solo si|cuando|salvo|excepto)\b',r['text']))
        # source contexts with mixed model versions/genres need manual review unless version/task already encoded
        mixed=False
        if r['skill']=='video' and r['file'] in {'references/patterns-and-genres.md','references/role-modes.md','references/camera-lighting-vocabulary.md'}: mixed=True
        if conditional and not why and status=='CLASSIFIED':
            status='NEEDS_REVIEW'; notes.append('Conditional wording needs explicit case condition review.')
        if mixed and status=='CLASSIFIED':
            status='NEEDS_REVIEW'; notes.append('Mixed reference source requires rule-level scope review.')
        validator={'kind':'semantic','id':None}
        if effect=='FORBID': validator={'kind':'lexical' if re.search(r'(?i)vocab|word|term|cinematic|masterpiece|stunning|epic|high quality|professional',r['text']) else 'semantic','id':None}
        if effect in {'PROCESS','GATE'}: validator={'kind':'process','id':None}
        conflict_key='vocabulary.visual_style_quality' if re.search(r'(?i)photoreal|cinematic|masterpiece|stunning|epic|high quality|professional',r['text']) else None
        row={'rule_id':r['id'],'classification_status':status,'authority':auth,'effect':effect,'priority':prio,'when':c,'validator':validator,'conflict_key':conflict_key,'supersedes':[],
             'classification_provenance':{'method':'source_file_policy' if status=='CLASSIFIED' else 'rule_by_rule','reviewer':'APD-v3-autoclassifier','reviewed_at':now if status in {'CLASSIFIED','NON_NORMATIVE'} else None,'notes':'; '.join(notes+[effwhy]+why)[:1000]}}
        rows.append(row); st[status]+=1; byskill[r['skill']][status]+=1
        if status=='NEEDS_REVIEW': review.append({'rule':r,'metadata':row})
    OUT.write_text('\n'.join(json.dumps(x,ensure_ascii=False,sort_keys=True) for x in rows)+'\n',encoding='utf-8')
    (BUILD/'rule_review_remaining.json').write_text(json.dumps({'count':len(review),'items':review},ensure_ascii=False,indent=2),encoding='utf-8')
    print('total',len(rows)); print(dict(st));
    for s,c in sorted(byskill.items()): print(f'{s:28}',dict(c))
    print('review',len(review)); print('written',OUT)
if __name__=='__main__': main()
