# AI Production Director v3.3.2 — Production Package Dependency Reconstruction

## Why this patch exists

The original ZIP contains normative requirements in `skills/produccion-visual-sw30/SKILL.md` for:

- `production-package/RULES_MATRIX.md`
- `production-package/template_engine.py`
- `production-package/audit_gi2.py`

The original ZIP does **not** contain those artifacts. Its own `repo/.claude/hooks/README.md` explicitly records that they did not exist. v3.3.2 reconstructs them from the authoritative source instead of silently bypassing them.

## Reconstructed artifacts

- `repo/production-package/RULES_MATRIX.md`
  - exactly 26 rule rows × T1–T5
  - 6 explicit process obligations + 20 numbered SW30 critical rules
  - every row includes block/owner, applicability and source
  - ambiguous applicability is `COND`, not guessed as unconditional
- `repo/production-package/template_engine.py`
  - typed T1–T5 contracts
  - T1 locks `light_hard`, `skin_doc`, `usecase_doc`, `clean_doc`
  - rejects missing/unknown sections
  - rejects loose text for block-required sections
  - rejects prompt-body Model/Quality/Size/Aspect metadata
  - requires Notes
  - no-argument selftest: 6/6 PASS
- `repo/production-package/audit_gi2.py`
  - emits exactly 15 mechanical audit columns
  - covers every concern named by SW30 plus SW30-mandated word ceiling and one-job checks
  - fail-closed for required checks
  - selftest PASS
- `repo/production-package/dependency_closure.py`
  - blocks if reconstructed dependencies disappear or their selftests fail

## Important provenance limitation

These are `SOURCE_RECONSTRUCTED` artifacts. They are **not claimed to be byte-for-byte recovery of historical missing files**. The original ZIP does not contain the exact T2–T5 section lists, so the template engine uses the smallest source-supported contracts and documents that explicitly in `RULES_MATRIX.md` and `RECONSTRUCTION_MANIFEST.json`.

## Real production regression

The tennis Nano Banana candidate that had 121 words was audited by the reconstructed `audit_gi2.py`:

- 121/120 → **FAIL**
- same candidate with one nonessential word removed, 120/120 → **PASS**

This closes the exact gap that had been manually noticed before delivery.

## Regression status

- v3.3.2 reconstruction suite: PASS
- v3.3 decision routing suite: PASS
- v3.2 learning patch suite: PASS
- v3.1 exhaustive suite: 13/13 PASS
- legacy v3 suite: 18/18 PASS

## Publication

`ruleset-3.3.2.json` retains the existing 1,700 rule semantics and adds a verified dependency-closure manifest with hashes of the reconstructed production-package artifacts.
