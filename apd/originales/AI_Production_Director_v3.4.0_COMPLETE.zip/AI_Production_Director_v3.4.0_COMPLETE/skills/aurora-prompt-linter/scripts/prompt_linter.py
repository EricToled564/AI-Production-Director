#!/usr/bin/env python3
"""Aurora Prompt Linter v1.1 - 3-layer validation (refs redundancy + sections by platform+case + structure)."""
import re, sys, json, argparse
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Dict, Set, Tuple, Optional

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML required. pip install pyyaml --break-system-packages", file=sys.stderr)
    sys.exit(2)


@dataclass
class RefTag:
    file: str
    role: str
    tags: List[str]


@dataclass
class Override:
    term: str
    category: str
    reason: str
    source_text: str


@dataclass
class Violation:
    term: str
    category: str
    reason: str


@dataclass
class LinterResult:
    status: str
    case_type: str
    platform: str
    word_count: int
    word_budget: Tuple[int, int]
    covered_categories: List[str]
    sections_required: List[str]
    sections_present: List[str]
    sections_missing: List[str]
    violations: List[Violation]
    overrides_accepted: List[Override]
    warnings: List[str]
    suggestions: List[str]
    report: str

    def to_dict(self):
        return {
            "status": self.status, "case_type": self.case_type, "platform": self.platform,
            "word_count": self.word_count, "word_budget": list(self.word_budget),
            "covered_categories": self.covered_categories,
            "sections_required": self.sections_required,
            "sections_present": self.sections_present,
            "sections_missing": self.sections_missing,
            "violations": [asdict(v) for v in self.violations],
            "overrides_accepted": [asdict(o) for o in self.overrides_accepted],
            "warnings": self.warnings, "suggestions": self.suggestions,
        }


CASE_CONFIGS = {
    "1":  {"name": "Genesis (text-to-image)",  "budget": (75, 130), "requires_negative": True},
    "2":  {"name": "Anchor (image with refs)", "budget": (75, 130), "requires_negative": True},
    "3a": {"name": "I2V FF only",              "budget": (50, 90),  "requires_negative": True},
    "3b": {"name": "I2V FF + LF",              "budget": (50, 90),  "requires_negative": True},
    "3c": {"name": "I2V motion control",       "budget": (50, 90),  "requires_negative": True},
    "4":  {"name": "Video with dialogue",      "budget": (75, 130), "requires_negative": True},
}


def normalize_tag(tag: str) -> str:
    m = re.match(r"^([A-Z]+)\d*$", tag.strip())
    return m.group(1) if m else tag


def covered_categories(refs: List[RefTag]) -> Set[str]:
    cats = set()
    for ref in refs:
        for tag in ref.tags:
            cats.add(normalize_tag(tag))
    return cats


def split_main_and_negative(prompt: str) -> Tuple[str, str]:
    parts = re.split(r"(?i)\bnegative\s*:", prompt, maxsplit=1)
    return parts[0], (parts[1] if len(parts) > 1 else "")


def word_count_of(text: str) -> int:
    return len(text.split())


def find_term_in_text(term: str, text: str) -> List[Tuple[int, int]]:
    text_lower, term_lower = text.lower(), term.lower()
    spans = []
    if " " in term_lower:
        start = 0
        while True:
            idx = text_lower.find(term_lower, start)
            if idx == -1: break
            spans.append((idx, idx + len(term_lower)))
            start = idx + 1
    else:
        for m in re.finditer(r"\b" + re.escape(term_lower) + r"\b", text_lower):
            spans.append((m.start(), m.end()))
    return spans


DIRECTIONAL_PREPOSITIONS = [
    "away from", "toward", "towards", "off", "over", "behind",
    "in front of", "across", "past", "from her", "from his",
    "onto", "into", "above", "below", "beside",
]


def is_in_motion_context(text: str, span: Tuple[int, int], motion_prefixes: List[str]) -> bool:
    start = max(0, span[0] - 60)
    window_full = text[start:span[1]].lower()
    window_before = text[start:span[0]].lower()
    for prefix in motion_prefixes:
        pat = r"\b" + re.escape(prefix.lower()) + r"\b[^.]{0,50}$"
        if re.search(pat, window_full):
            return True
    for prep in DIRECTIONAL_PREPOSITIONS:
        pat = r"\b" + re.escape(prep) + r"\s+(?:her\s+|his\s+|the\s+)?$"
        if re.search(pat, window_before):
            return True
    return False


OVERRIDE_PATTERN = re.compile(
    r"OVERRIDE\s*:\s*(?P<term>[^\-\n]+?)\s*[\-]+\s*(?P<reason>[^\n]+)",
    re.IGNORECASE
)


def parse_overrides(user_message: str) -> List[Override]:
    overrides = []
    for m in OVERRIDE_PATTERN.finditer(user_message):
        term = m.group("term").strip().strip('"\'')
        reason = m.group("reason").strip()
        is_cat = bool(re.match(r"^[A-Z]{1,2}\d*$", term))
        overrides.append(Override(term=term, category=normalize_tag(term) if is_cat else "",
                                  reason=reason, source_text=m.group(0)))
    return overrides


def override_matches(v: Violation, overrides: List[Override]) -> Optional[Override]:
    for ovr in overrides:
        if ovr.term.lower() == v.term.lower(): return ovr
        if ovr.category and ovr.category == v.category: return ovr
    return None


def normalize_platform_case_key(platform: str, case_type: str) -> str:
    p = platform.strip().lower().replace("-", "_").replace(" ", "_").replace(".", "_")
    p = re.sub(r"_(\d+)_(\d+)", r"_\1.\2", p)
    return f"{p}__{case_type}"


def validate_sections(prompt_main: str, platform: str, case_type: str,
                     vocabs: Dict) -> Tuple[List[str], List[str], List[str]]:
    sections_db = vocabs.get("REQUIRED_SECTIONS_BY_PLATFORM_CASE", {})
    key = normalize_platform_case_key(platform, case_type)
    section_specs = sections_db.get(key)
    if section_specs is None:
        return [], [], []
    required, present, missing = list(section_specs.keys()), [], []
    main_lower = prompt_main.lower()
    for section_name, patterns in section_specs.items():
        if any(pat.lower() in main_lower for pat in patterns):
            present.append(section_name)
        else:
            missing.append(section_name)
    return required, present, missing


def validate(refs, prompt, case_type, platform, vocabs, overrides,
             require_sports_broadcast=False) -> LinterResult:
    config = CASE_CONFIGS.get(case_type)
    if not config:
        return LinterResult(status="FAIL", case_type=case_type, platform=platform,
            word_count=0, word_budget=(0, 0), covered_categories=[],
            sections_required=[], sections_present=[], sections_missing=[],
            violations=[], overrides_accepted=[], warnings=[], suggestions=[],
            report=f"ERROR: Unknown case_type {case_type}")

    main, negative = split_main_and_negative(prompt)
    cats = covered_categories(refs)
    motion_prefixes = vocabs.get("ALLOWED_MOTION_PREFIXES", [])

    violations: List[Violation] = []
    overrides_accepted: List[Override] = []
    overrides_used: Set[str] = set()
    warnings: List[str] = []

    # Layer 1: refs redundancy
    for cat in sorted(cats):
        for term in vocabs.get(cat, []):
            for span in find_term_in_text(term, main):
                if is_in_motion_context(main, span, motion_prefixes):
                    continue
                v = Violation(term=term, category=cat,
                              reason=f"Static descriptor of category {cat} (covered by refs)")
                ovr = override_matches(v, overrides)
                if ovr:
                    if ovr.source_text not in overrides_used:
                        overrides_accepted.append(ovr)
                        overrides_used.add(ovr.source_text)
                else:
                    violations.append(v)
                break

    # Layer 2: required sections by platform+case
    sec_req, sec_pres, sec_miss = validate_sections(main, platform, case_type, vocabs)
    if not sec_req and platform:
        warnings.append(
            f"No required-sections snapshot for platform '{platform}' + case '{case_type}'. "
            f"Update vocabularies.yaml REQUIRED_SECTIONS_BY_PLATFORM_CASE.{normalize_platform_case_key(platform, case_type)}")
    for ms in sec_miss:
        v = Violation(term=ms, category="SECTION",
                      reason=f"Required section '{ms}' for platform '{platform}' case {case_type} not detected in MAIN")
        ovr = override_matches(v, overrides)
        if ovr:
            if ovr.source_text not in overrides_used:
                overrides_accepted.append(ovr)
                overrides_used.add(ovr.source_text)
        else:
            violations.append(v)

    # Layer 3: banned vocab in MAIN
    for term in vocabs.get("BANNED", []):
        if find_term_in_text(term, main):
            v = Violation(term=term, category="BANNED",
                          reason="Cross-platform banned vocab in main prompt")
            ovr = override_matches(v, overrides)
            if ovr:
                if ovr.source_text not in overrides_used:
                    overrides_accepted.append(ovr)
                    overrides_used.add(ovr.source_text)
            else:
                violations.append(v)

    # Word count
    wc_main = word_count_of(main)
    if wc_main > config["budget"][1]:
        violations.append(Violation(term=f"word_count={wc_main}", category="STRUCTURE",
            reason=f"Above HARD MAX {config['budget'][1]} (Regla 10 v6.1)"))
    elif wc_main < config["budget"][0]:
        warnings.append(
            f"Word count {wc_main} below soft min {config['budget'][0]} (compression OK if intentional)")

    # Negative
    if config["requires_negative"] and not negative.strip():
        violations.append(Violation(term="negative_prompt", category="STRUCTURE",
            reason="Negative prompt block required"))

    # Sports broadcast
    if require_sports_broadcast:
        for kw in vocabs.get("REQUIRED_SPORTS_BROADCAST", []):
            if kw.lower() not in main.lower():
                violations.append(Violation(term=kw, category="REQUIRED",
                    reason="Required keyword for sports broadcast (Regla 26 v6.1)"))

    status = "PASS" if not violations else "FAIL"

    L = [
        "=" * 64,
        "AURORA PROMPT LINTER REPORT v1.1",
        "=" * 64,
        f"Case: {case_type} ({config['name']})",
        f"Platform: {platform if platform else '(none specified)'}",
        f"Word count (MAIN): {wc_main} / budget {config['budget']}",
        f"Negative prompt: {'present' if negative.strip() else 'MISSING'}",
        f"Categories covered by refs: {sorted(cats) if cats else '(none)'}",
        f"Sports broadcast mode: {'on' if require_sports_broadcast else 'off'}",
        ""
    ]
    if sec_req:
        L.append(f"REQUIRED SECTIONS for {platform} case {case_type}:")
        for s in sec_req:
            L.append(f"  {'PRESENT' if s in sec_pres else 'MISSING'} {s}")
        L.append("")
    if violations:
        L.append(f"VIOLATIONS ({len(violations)}):")
        for v in violations:
            L.append(f"  FAIL [{v.category}] '{v.term}' - {v.reason}")
    else:
        L.append("VIOLATIONS: none")
    if warnings:
        L.append("")
        L.append(f"WARNINGS ({len(warnings)}) non-blocking:")
        for w in warnings:
            L.append(f"  WARN {w}")
    if overrides_accepted:
        L.append("")
        L.append(f"OVERRIDES ACCEPTED ({len(overrides_accepted)}):")
        for o in overrides_accepted:
            L.append(f"  OK '{o.term}' - {o.reason[:100]}")
    suggestions: List[str] = []
    if violations:
        cat_vio: Dict[str, List[str]] = {}
        for v in violations:
            cat_vio.setdefault(v.category, []).append(v.term)
        for cat, terms in cat_vio.items():
            if cat in ("P", "O", "L", "PR", "S"):
                suggestions.append(f"Strip from MAIN: {terms} (category {cat} already covered by refs)")
            elif cat == "SECTION":
                suggestions.append(f"Add sections to MAIN: {terms} (required by platform '{platform}' case {case_type})")
            elif cat == "BANNED":
                suggestions.append(f"Move to NEGATIVE block: {terms}")
            elif cat == "STRUCTURE":
                suggestions.append(f"Fix structure: {terms}")
            elif cat == "REQUIRED":
                suggestions.append(f"Add to MAIN: {terms}")
        L.append("")
        L.append("SUGGESTIONS:")
        for s in suggestions:
            L.append(f"  -> {s}")
    L.append("")
    L.append(f"STATUS: {status}")
    L.append("Delivery BLOCKED. Iterate or grant OVERRIDE in current turn." if status == "FAIL" else "Delivery PERMITTED.")
    L.append("=" * 64)

    return LinterResult(status=status, case_type=case_type, platform=platform,
        word_count=wc_main, word_budget=config["budget"],
        covered_categories=sorted(cats), sections_required=sec_req,
        sections_present=sec_pres, sections_missing=sec_miss,
        violations=violations, overrides_accepted=overrides_accepted,
        warnings=warnings, suggestions=suggestions, report="\n".join(L))


def main():
    p = argparse.ArgumentParser(description="Aurora Prompt Linter v1.1")
    p.add_argument("--prompt", required=True)
    p.add_argument("--refs", required=True)
    p.add_argument("--case", required=True, choices=list(CASE_CONFIGS.keys()))
    p.add_argument("--platform", default="",
        help="Platform identifier (e.g., gpt_image_2, kling_3.0, veo_3.1, nano_banana_pro, sora_2)")
    p.add_argument("--vocab", default=None)
    p.add_argument("--overrides", default=None)
    p.add_argument("--sports-broadcast", action="store_true")
    p.add_argument("--json", action="store_true")
    args = p.parse_args()

    prompt = Path(args.prompt).read_text(encoding="utf-8")
    refs_data = yaml.safe_load(Path(args.refs).read_text(encoding="utf-8"))
    refs = [RefTag(**r) for r in refs_data]
    vocab_path = Path(args.vocab) if args.vocab else Path(__file__).parent / "vocabularies.yaml"
    vocabs = yaml.safe_load(vocab_path.read_text(encoding="utf-8"))
    overrides = []
    if args.overrides:
        overrides = parse_overrides(Path(args.overrides).read_text(encoding="utf-8"))
    result = validate(refs, prompt, args.case, args.platform, vocabs, overrides,
                      require_sports_broadcast=args.sports_broadcast)
    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(result.report)
    sys.exit(0 if result.status == "PASS" else 1)


if __name__ == "__main__":
    main()
